plugins {
    id("com.android.application") version "8.7.3" apply false
    // Kotlin 2.3 : exigé par le moteur d'IA LiteRT-LM (variante « Calepin IA »)
    id("org.jetbrains.kotlin.android") version "2.3.21" apply false
    id("org.jetbrains.kotlin.plugin.compose") version "2.3.21" apply false
}
