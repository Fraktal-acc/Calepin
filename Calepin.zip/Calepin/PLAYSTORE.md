# À faire avant de publier Calepin sur le Play Store

Ce fichier sert de pense-bête. Rien ici n'est nécessaire pour la version privée.

## 1. Envoi automatique WhatsApp (OBLIGATOIRE)
La version privée (Calepin IA) envoie les messages WhatsApp toute seule grâce à un **service d'accessibilité**
(`control/WhatsAppSender.kt`, déclaré dans `app/src/ia/AndroidManifest.xml`).
Google refuse presque toujours les applis qui utilisent l'accessibilité pour autre chose que l'aide aux personnes handicapées.

Avant publication :
- retirer le bloc `<service android:name="fr.jeremy.calepin.control.WhatsAppSender" …>` du manifeste `ia` ;
- garder seulement « ouvrir WhatsApp avec le message prêt » (l'utilisateur appuie lui-même sur Envoyer) ;
- retirer le réglage « Envoi automatique WhatsApp » de `ui/HomeSettings.kt`.

## 2. Autorisations à justifier dans la Play Console
- `CALL_PHONE` : appel lancé par l'assistant (« appelle Marc »). Sinon, passer à `ACTION_DIAL`.
- `READ_CONTACTS` : écran Contacts et liens notes ↔ contacts.
- `USE_EXACT_ALARM` / `SCHEDULE_EXACT_ALARM` : réservées aux applis d'alarme / d'agenda → déclarer Calepin comme agenda avec rappels.
- `USE_FULL_SCREEN_INTENT` : écran d'alarme (déclaration obligatoire depuis Android 14).
- `WRITE_SETTINGS`, `ACCESS_NOTIFICATION_POLICY` (Calepin IA) : réglages du téléphone à la voix.
- `TRANSMIT_IR` : télécommande infrarouge.
- `FOREGROUND_SERVICE_MEDIA_PLAYBACK` : sonnerie des alarmes.

## 3. Le reste
- Politique de confidentialité : `PRIVACY.md` (à publier, par exemple sur lintendantadomicile.fr/calepin-confidentialite).
- Signer avec une clé de version (pas la clé de débogage) et produire un fichier `.aab`.
- Fiche : captures d'écran, icône 512 px, bannière 1024 × 500, description courte et longue.
- Formulaire « Sécurité des données » : aucune donnée collectée ni partagée.
- Calepin IA : la taille des modèles (téléchargés à la demande) n'est pas comptée dans l'APK.
