# Calepin — bloc-notes Android intelligent

Application Android native (Kotlin + Jetpack Compose), données stockées sur le téléphone (SQLite), aucune connexion requise.

## Ce que fait l'appli

**Reconnaissance automatique dans le texte des notes**
- Téléphones : France (06 12 34 56 78, 06.12.34.56.78, +33 (0)4…), Monaco (+377 93…, +377 6…), international (+44…)
- Adresses : « 12 avenue Winston Churchill, 06190 Roquebrune-Cap-Martin », « place aux Herbes », « 98000 Monaco »
- Dates : 12/10, 12/10/2026, 2026-10-12, 14 octobre, 1er mai 2027, demain, après-demain, lundi prochain, avec heure (« à 14h30 »)
- E-mails et liens web

Les éléments reconnus sont soulignés dans la note et listés en bas : un appui ouvre les actions.

| Élément | Actions |
|---|---|
| Téléphone | Appeler, SMS, WhatsApp, créer un contact (nom = titre de la note, + mail et adresse trouvés dans la note), copier |
| Adresse | Voir sur la carte, itinéraire Google Maps, itinéraire Waze, ajouter à un contact, copier |
| Date | Ajouter à l'agenda (titre, description et lieu préremplis), ouvrir l'agenda à ce jour, régler une alarme (si c'est dans les 36 h), copier |
| E-mail | Écrire un mail, créer un contact, copier |
| Lien | Ouvrir, copier |

**Recherche**
- Insensible aux majuscules et aux accents (« electricien » trouve « Électricien », « oeufs » trouve « Œufs »)
- Tolérance aux fautes de frappe (désactivable) : « plombeir » trouve « plombier »
- Numéros : « 0612 » ou « 06 12 34 » trouvent « 06.12.34.56.78 »
- Syntaxe : `"expression exacte"`, `mot1 OU mot2`, `-exclure`, `titre:mot`, `contenu:mot`, `#etiquette`, `tag:clients`, `type:tel` / `type:adresse` / `type:date` / `type:mail` / `type:lien`, `date:14/10` (notes qui mentionnent ce jour), `apres:01/09`, `avant:31/12`, `est:epingle`
- Filtres (bouton à droite de la barre) : où chercher, types d'éléments, étiquettes, période, tri, épinglées
- Mots trouvés surlignés dans les résultats, extrait centré sur la correspondance

**Autres** : notes épinglées, étiquettes multiples, partage d'une note, et « Partager → Calepin » depuis n'importe quelle appli pour créer une note. Thème clair/sombre automatique. Trois notes d'exemple (étiquette « Exemple ») sont créées au premier lancement ; supprime-les quand tu veux.

## Compiler et installer

1. Installer **Android Studio** (version Ladybug 2024.2 ou plus récente).
2. Dézipper le dossier, puis *File → Open* → choisir le dossier `Calepin`. Laisser Gradle synchroniser (il télécharge les dépendances la première fois).
3. Brancher le téléphone en USB avec le *débogage USB* activé (Paramètres → À propos → appuyer 7 fois sur « Numéro de build », puis Options pour les développeurs), et cliquer sur ▶ *Run*.
   Ou bien : *Build → Build App Bundle(s) / APK(s) → Build APK(s)*, puis copier `app/build/outputs/apk/debug/app-debug.apk` sur le téléphone et l'ouvrir.

Android 8.0 minimum.

## Organisation du code

```
app/src/main/java/fr/jeremy/calepin/
├── MainActivity.kt          navigation entre liste et note, réception des partages
├── NotesViewModel.kt        état, recherche en arrière-plan, notes d'exemple
├── Actions.kt               ouverture de Maps, Waze, téléphone, contacts, agenda, alarme…
├── data/                    Note + base SQLite
├── detect/EntityDetector.kt reconnaissance des téléphones, adresses, dates, mails, liens
├── search/SearchEngine.kt   analyse de la requête, normalisation, scores, surlignage
└── ui/                      écrans Compose (liste + filtres, éditeur + actions), thème
```

`EntityDetector` et `SearchEngine` sont du Kotlin pur (sans Android) : faciles à tester ou à réutiliser.
