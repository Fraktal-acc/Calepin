# Calepin — bloc-notes Android intelligent

Application Android native (Kotlin + Jetpack Compose), données stockées sur le téléphone (SQLite), aucune connexion requise.

## Ce que fait l'appli

**Reconnaissance automatique dans le texte des notes**
- Téléphones : France (06 12 34 56 78, 06.12.34.56.78, +33 (0)4…), Monaco (+377 93…, +377 6…), international (+44…)
- Adresses : « 12 avenue Winston Churchill, 06190 Roquebrune-Cap-Martin », « place aux Herbes », « 98000 Monaco »
- Dates : 12/10, 12/10/2026, 2026-10-12, 14 octobre, 1er mai 2027, demain, après-demain, lundi prochain, avec heure (« à 14h30 »)
- E-mails et liens web

Les éléments reconnus sont soulignés dans la note et listés en bas : un appui ouvre les actions.

| Élément | Actions |
|---|---|
| Téléphone | Appeler, SMS, WhatsApp, créer un contact (nom = titre de la note, + mail et adresse trouvés dans la note), copier |
| Adresse | Voir sur la carte, itinéraire Google Maps, itinéraire Waze, ajouter à un contact, copier |
| Date | Ajouter à l'agenda (titre, description et lieu préremplis), ouvrir l'agenda à ce jour, régler une alarme (si c'est dans les 36 h), copier |
| E-mail | Écrire un mail, créer un contact, copier |
| Lien | Ouvrir, copier |

**Recherche**
- Insensible aux majuscules et aux accents (« electricien » trouve « Électricien », « oeufs » trouve « Œufs »)
- Tolérance aux fautes de frappe (désactivable) : « plombeir » trouve « plombier »
- Numéros : « 0612 » ou « 06 12 34 » trouvent « 06.12.34.56.78 »
- Syntaxe : `"expression exacte"`, `mot1 OU mot2`, `-exclure`, `titre:mot`, `contenu:mot`, `#etiquette`, `tag:clients`, `type:tel` / `type:adresse` / `type:date` / `type:mail` / `type:lien`, `date:14/10` (notes qui mentionnent ce jour), `apres:01/09`, `avant:31/12`, `est:epingle`
- Filtres (bouton à droite de la barre) : où chercher, types d'éléments, étiquettes, période, tri, épinglées
- Mots trouvés surlignés dans les résultats, extrait centré sur la correspondance

**Affichage** : cartes, liste compacte, grille sur deux colonnes ou liste dépliable (titres seuls, la flèche déplie le texte). Choix par l'icône en haut de l'accueil, mémorisé.

**Mémos vocaux** : dans une note, « Enregistrer un mémo vocal ». Format M4A ou MP3 et qualité au choix dans les paramètres. Écoute, partage, « Enregistrer sous… » et suppression depuis la note. L'encodeur MP3 est Shine (LGPL), compilé dans l'appli (dossier `app/src/main/cpp`).

**Export** : PDF, Word (.docx), Excel (.xlsx, une ligne par note avec téléphones, adresses, dates en colonnes), CSV, texte, Markdown, page web, sauvegarde JSON. Depuis une note (icône d'export), depuis une sélection (appui long), ou toutes les notes dans les paramètres. Restauration d'une sauvegarde JSON dans les paramètres.

**Sécurité** : code PIN (4 à 8 chiffres, stocké sous forme d'empreinte salée), empreinte digitale ou visage, l'un, l'autre ou les deux. Délai de reverrouillage, blocage 30 s après 5 erreurs, option pour masquer le contenu dans les applis récentes.

**Photos et vidéos** : dans une note, « Photo », « Vidéo » (appareil du téléphone) ou « Galerie » (plusieurs à la fois). Miniatures, affichage plein écran avec zoom, partage, enregistrement, suppression.

**Dictée et transcription** : bouton micro « Dicter » en mode écriture (reconnaissance vocale du téléphone). Les mémos vocaux peuvent être transcrits en texte hors ligne (Vosk, module français de 41 Mo téléchargé une fois), puis insérés dans la note.

**Agenda** : icône calendrier de l'accueil. Mois en grille, rendez-vous Calepin (points bleus) et dates repérées automatiquement dans les notes (points orange, « + Agenda » pour en faire un rendez-vous). Depuis une note : toucher une date reconnue, ou sélectionner du texte en mode écriture puis « Agenda » / « Alarme ».

**Périodes** : « du 10 octobre 2026 au 16 octobre 2026 », « du 10 au 16 octobre », « du 10/10 au 16/10/2026 », « 10/10/2026 - 16/10/2026 » sont reconnus comme une période. Dans l'agenda, une période s'affiche sur chacun de ses jours ; dans un rendez-vous, « Jusqu'au… » ajoute une date (et heure) de fin.

**Planning de travail** : dans l'agenda, icône d'import → choisir un PDF (ou une photo du planning). Les jours et horaires sont repérés (une ligne par jour, tableau en colonnes, postes de nuit, coupures, repos ignorés), affichés pour vérification, puis ajoutés en « Travail » avec un rappel au choix. PDF scanné ou photo : lecture par reconnaissance de caractères sur le téléphone (ML Kit). Lecture des PDF : PdfBox-Android.

**Rappels et alarmes** : par rendez-vous, rappel (à l'heure, 5/15/30 min, 1 h, la veille…), type « Notification » ou « Alarme » qui sonne en boucle même téléphone verrouillé (Arrêter / Répéter dans 5 min), sonnerie au choix parmi celles du téléphone. Les rappels sont reprogrammés après un redémarrage.

**Assistant** (icône robot de l'accueil) : comprend des demandes en français, à l'écrit ou à la voix, et agit dans Calepin — notes (« Note : … », « Ajoute du lait à la liste de courses », « Lis la note courses »), agenda (« Qu'est-ce que j'ai demain ? », « Mon planning la semaine prochaine »), travail (« Quand est-ce que je travaille ? », « Combien d'heures ce mois-ci ? »), rendez-vous, rappels (« Rappelle-moi dans 20 minutes de… »), alarmes (« Réveille-moi à 6h »), appels / SMS / itinéraires vers un contact noté, recherche. Fonctionne hors ligne : compréhension sur le téléphone, écoute avec le module vocal Vosk, réponses lues par la synthèse vocale du téléphone. Briefing du matin automatique (Paramètres → Assistant).

**Contacts** (icône carnet de l'accueil) : les contacts du téléphone dans Calepin, avec recherche par nom, numéro (avec ou sans espaces, 06… ou +33 6…), e-mail ou ville, et favoris en tête. La fiche d'un contact permet d'appeler, d'envoyer un SMS ou un WhatsApp, d'écrire un mail, d'ouvrir la carte, l'itinéraire ou Waze, et de copier. Elle liste les notes qui mentionnent le contact, permet de créer une note pré-remplie, d'ouvrir ou de modifier le contact dans l'appli Contacts. Accès en lecture seule, accordé une fois.

**Autres** : notes épinglées, étiquettes multiples, partage d'une note, et « Partager → Calepin » depuis n'importe quelle appli pour créer une note. Thème clair/sombre automatique. Trois notes d'exemple (étiquette « Exemple ») sont créées au premier lancement ; supprime-les quand tu veux.

## Compiler et installer

1. Installer **Android Studio** (version Ladybug 2024.2 ou plus récente).
2. Dézipper le dossier, puis *File → Open* → choisir le dossier `Calepin`. Laisser Gradle synchroniser (il télécharge les dépendances la première fois).
3. Brancher le téléphone en USB avec le *débogage USB* activé (Paramètres → À propos → appuyer 7 fois sur « Numéro de build », puis Options pour les développeurs), et cliquer sur ▶ *Run*.
   Ou bien : *Build → Build App Bundle(s) / APK(s) → Build APK(s)*, puis copier `app/build/outputs/apk/debug/app-debug.apk` sur le téléphone et l'ouvrir.

Android 8.0 minimum.

## Organisation du code

```
app/src/main/java/fr/jeremy/calepin/
├── MainActivity.kt          navigation entre liste et note, réception des partages
├── NotesViewModel.kt        état, recherche en arrière-plan, notes d'exemple
├── Actions.kt               ouverture de Maps, Waze, téléphone, contacts, agenda, alarme…
├── data/                    Note + base SQLite
├── detect/EntityDetector.kt reconnaissance des téléphones, adresses, dates, mails, liens
├── search/SearchEngine.kt   analyse de la requête, normalisation, scores, surlignage
└── ui/                      écrans Compose (liste + filtres, éditeur + actions), thème
```

`EntityDetector` et `SearchEngine` sont du Kotlin pur (sans Android) : faciles à tester ou à réutiliser.
