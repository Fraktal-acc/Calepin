package fr.jeremy.calepin.export

import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import java.io.ByteArrayOutputStream

/**
 * Petit générateur de PDF A4 (factures, devis, relevés d'heures) : texte, tableaux simples, traits,
 * pages ajoutées automatiquement.
 */
class SimplePdf(private val footer: String = "") {
    private val w = 595
    private val h = 842
    private val m = 46f
    private val doc = PdfDocument()
    private var page: PdfDocument.Page? = null
    private var pageNo = 0
    var y = 0f
        private set
    val width get() = w - 2 * m

    private fun paint(size: Float, bold: Boolean, color: Int) = TextPaint(TextPaint.ANTI_ALIAS_FLAG).apply {
        textSize = size; this.color = color; typeface = if (bold) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
    }

    private fun ensure(space: Float) {
        if (page == null || y + space > h - m - 18) {
            page?.let { finishPage(it) }
            pageNo++
            page = doc.startPage(PdfDocument.PageInfo.Builder(w, h, pageNo).create())
            y = m
        }
    }

    private fun finishPage(p: PdfDocument.Page) {
        val fp = paint(7.5f, false, Color.GRAY)
        if (footer.isNotBlank()) p.canvas.drawText(footer, m, h - 22f, fp)
        val n = "$pageNo"
        p.canvas.drawText(n, w - m - fp.measureText(n), h - 22f, fp)
        doc.finishPage(p)
    }

    private fun layout(text: String, p: TextPaint, width: Int, align: Layout.Alignment) =
        StaticLayout.Builder.obtain(text, 0, text.length, p, width).setAlignment(align).setLineSpacing(1.5f, 1f).build()

    /** Paragraphe (coupé en lignes ; [x] et [boxWidth] pour un bloc décalé). */
    fun text(
        s: String, size: Float = 10.5f, bold: Boolean = false, color: Int = Color.rgb(27, 35, 40),
        align: Layout.Alignment = Layout.Alignment.ALIGN_NORMAL, after: Float = 4f, x: Float = 0f, boxWidth: Float = width,
        advance: Boolean = true,
    ): Float {
        val l = layout(s, paint(size, bold, color), boxWidth.toInt(), align)
        ensure(l.height.toFloat())
        val c = page!!.canvas
        c.save(); c.translate(m + x, y); l.draw(c); c.restore()
        if (advance) y += l.height + after
        return l.height.toFloat()
    }

    /** Ligne de tableau : textes et largeurs relatives ; les colonnes après la première sont alignées à droite. */
    fun row(cols: List<String>, weights: List<Float>, bold: Boolean = false, size: Float = 10f, fill: Int? = null) {
        val total = weights.sum()
        val widths = weights.map { it / total * width }
        val p = paint(size, bold, Color.rgb(27, 35, 40))
        val layouts = cols.mapIndexed { i, s ->
            layout(s, p, (widths[i] - 6).toInt().coerceAtLeast(10), if (i == 0) Layout.Alignment.ALIGN_NORMAL else Layout.Alignment.ALIGN_OPPOSITE)
        }
        val rh = (layouts.maxOf { it.height } + 8).toFloat()
        ensure(rh)
        val c = page!!.canvas
        if (fill != null) c.drawRect(m, y, m + width, y + rh, Paint().apply { color = fill })
        var x = m
        layouts.forEachIndexed { i, l ->
            c.save(); c.translate(x + 3, y + 4); l.draw(c); c.restore()
            x += widths[i]
        }
        y += rh
        c.drawLine(m, y, m + width, y, Paint().apply { color = Color.rgb(220, 220, 220); strokeWidth = 0.6f })
    }

    fun line(color: Int = Color.rgb(31, 95, 122), stroke: Float = 1.2f, after: Float = 8f) {
        ensure(stroke + after)
        page!!.canvas.drawLine(m, y, m + width, y, Paint().apply { this.color = color; strokeWidth = stroke })
        y += after
    }

    fun space(v: Float) { ensure(v); y += v }

    fun build(): ByteArray {
        ensure(0f)
        page?.let { finishPage(it) }
        page = null
        val out = ByteArrayOutputStream()
        doc.writeTo(out)
        doc.close()
        return out.toByteArray()
    }
}
