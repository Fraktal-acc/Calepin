package fr.jeremy.calepin.ui.pro

import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowLeft
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.EventAvailable
import androidx.compose.material.icons.filled.Map
import androidx.compose.material.icons.filled.PhotoCamera
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import fr.jeremy.calepin.i18n.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import fr.jeremy.calepin.Files
import fr.jeremy.calepin.LockGuard
import fr.jeremy.calepin.NotesViewModel
import fr.jeremy.calepin.data.Event
import fr.jeremy.calepin.media.Media
import fr.jeremy.calepin.pro.ChecklistTemplates
import fr.jeremy.calepin.pro.Client
import fr.jeremy.calepin.pro.Intervention
import fr.jeremy.calepin.pro.ProStore
import fr.jeremy.calepin.pro.Status
import fr.jeremy.calepin.ui.Checklist
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.UUID

private val FR: Locale get() = fr.jeremy.calepin.i18n.I18n.locale
private fun fmt(p: String, t: Long) = SimpleDateFormat(fr.jeremy.calepin.i18n.I18n.pattern(p), FR).format(Date(t))
private fun hours(min: Int) = if (min % 60 == 0) "${min / 60} h" else "${min / 60} h %02d".format(min % 60)

/** Mode pro : clients et biens suivis, interventions, listes de contrôle, photos avant / après, heures et bilan. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProScreen(vm: NotesViewModel, onClose: () -> Unit, initialClient: String? = null) {
    val ctx = LocalContext.current
    val store = remember { ProStore.get(ctx) }
    val clients by store.clients.collectAsStateWithLifecycle()
    val interventions by store.interventions.collectAsStateWithLifecycle()
    var tab by remember { mutableIntStateOf(0) }
    var openClient by remember { mutableStateOf(initialClient) }
    var editClient by remember { mutableStateOf<Client?>(null) }
    var editIv by remember { mutableStateOf<Intervention?>(null) }

    editIv?.let { iv ->
        InterventionScreen(vm, store, iv, clients, onClose = { editIv = null })
        return
    }
    val oc = openClient?.let { id -> clients.firstOrNull { it.id == id } }
    if (oc != null) {
        ClientScreen(
            store, oc, interventions.filter { it.clientId == oc.id },
            onBack = { openClient = null },
            onEdit = { editClient = oc },
            onOpen = { editIv = it },
            onNew = { editIv = newIntervention(oc) },
        )
        editClient?.let { c -> ClientDialog(c, onDismiss = { editClient = null }, onSave = { store.upsert(it); editClient = null }, onDelete = { store.deleteClient(c.id); editClient = null; openClient = null }) }
        return
    }

    BackHandler { onClose() }
    Scaffold(
        topBar = {
            TopAppBar(
                title = { fr.jeremy.calepin.ui.FitText("Pro") },
                navigationIcon = { IconButton(onClick = onClose) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Retour") } },
            )
        },
        floatingActionButton = {
            when (tab) {
                0 -> ExtendedFloatingActionButton(
                    onClick = {
                        editIv = newIntervention(null)
                    },
                    icon = { Icon(Icons.Filled.Add, null) }, text = { Text("Intervention") },
                )
                1 -> ExtendedFloatingActionButton(onClick = { editClient = Client(name = "") }, icon = { Icon(Icons.Filled.Add, null) }, text = { Text("Client ou bien") })
                else -> {}
            }
        },
    ) { pad ->
        Column(Modifier.fillMaxSize().padding(pad)) {
            TabRow(selectedTabIndex = tab) {
                listOf("Interventions", "Clients", "Bilan").forEachIndexed { i, t -> Tab(selected = tab == i, onClick = { tab = i }, text = { Text(t) }) }
            }
            Column(
                Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp).padding(bottom = 80.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                when (tab) {
                    0 -> {
                        val todo = interventions.filter { it.status == Status.PLANIFIEE || it.status == Status.EN_COURS }.sortedBy { it.date }
                        val done = interventions.filter { it.status == Status.FAITE || it.status == Status.FACTUREE }
                        QuickJournal(store, clients)
                        if (interventions.isEmpty()) Empty("Aucune intervention. Note chaque passage (avec ou sans client) : heures, liste de contrôle, photos avant / après.")
                        if (todo.isNotEmpty()) Text("À venir et en cours", style = MaterialTheme.typography.titleSmall)
                        todo.forEach { IvCard(it, store.client(it.clientId)) { editIv = it } }
                        if (done.isNotEmpty()) Text("Terminées", style = MaterialTheme.typography.titleSmall)
                        done.take(40).forEach { IvCard(it, store.client(it.clientId)) { editIv = it } }
                    }
                    1 -> {
                        if (clients.isEmpty()) Empty("Aucun client. Ajoute un client, une villa, un appartement ou un bateau.")
                        clients.forEach { c ->
                            val n = interventions.count { it.clientId == c.id }
                            Card(border = fr.jeremy.calepin.ui.appBorder(), onClick = { openClient = c.id }, colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLow), modifier = Modifier.fillMaxWidth()) {
                                Column(Modifier.padding(14.dp)) {
                                    Text(c.name, style = MaterialTheme.typography.titleMedium)
                                    Text(listOf(c.kind, c.address).filter { it.isNotBlank() }.joinToString(" · "), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                    Text("$n intervention${if (n > 1) "s" else ""}", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
                                }
                            }
                        }
                    }
                    else -> {
                        Summary(clients, interventions)
                        BillingSection(store, clients)
                    }
                }
            }
        }
    }
    editClient?.let { c ->
        ClientDialog(c, onDismiss = { editClient = null }, onSave = { store.upsert(it); editClient = null }, onDelete = if (clients.any { it.id == c.id }) ({ store.deleteClient(c.id); editClient = null }) else null)
    }
}

private fun newIntervention(c: Client?): Intervention {
    val cal = Calendar.getInstance().apply { set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); add(Calendar.HOUR_OF_DAY, 1) }
    return Intervention(id = "new-" + UUID.randomUUID(), clientId = c?.id ?: "", title = "Passage", date = cal.timeInMillis)
}

@Composable
private fun Empty(t: String) = Text(t, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)

@Composable
private fun IvCard(iv: Intervention, c: Client?, onClick: () -> Unit) {
    val prog = Checklist.progress(iv.checklist)
    Card(border = fr.jeremy.calepin.ui.appBorder(), onClick = onClick, colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLow), modifier = Modifier.fillMaxWidth()) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(iv.title + (c?.let { " · " + it.name } ?: ""), style = MaterialTheme.typography.titleSmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(
                    fmt("EEE d MMM · HH'h'mm", iv.date) + (if (iv.minutes > 0) " · " + hours(iv.minutes) else "") +
                        (prog?.let { " · ${it.first}/${it.second} ✓" } ?: "") + (if (iv.timerStart > 0) " · ⏱ en cours" else ""),
                    style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            Text(iv.status.label, style = MaterialTheme.typography.labelMedium, color = when (iv.status) {
                Status.PLANIFIEE -> MaterialTheme.colorScheme.primary
                Status.EN_COURS -> MaterialTheme.colorScheme.tertiary
                Status.FAITE -> MaterialTheme.colorScheme.secondary
                Status.FACTUREE -> MaterialTheme.colorScheme.onSurfaceVariant
            })
        }
    }
}

// ---------------------------------------------------------------- Bilan

@Composable
private fun Summary(clients: List<Client>, all: List<Intervention>) {
    val ctx = LocalContext.current
    var month by remember { mutableStateOf(Calendar.getInstance().apply { set(Calendar.DAY_OF_MONTH, 1); set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0) }.timeInMillis) }
    val end = Calendar.getInstance().apply { timeInMillis = month; add(Calendar.MONTH, 1) }.timeInMillis
    val list = all.filter { it.date in month until end && it.status != Status.PLANIFIEE }
    val total = list.sumOf { it.minutes }
    Row(verticalAlignment = Alignment.CenterVertically) {
        IconButton(onClick = { month = Calendar.getInstance().apply { timeInMillis = month; add(Calendar.MONTH, -1) }.timeInMillis }) { Icon(Icons.AutoMirrored.Filled.KeyboardArrowLeft, "Mois précédent") }
        Text(fmt("MMMM yyyy", month).replaceFirstChar { it.uppercase() }, style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
        IconButton(onClick = { month = end }) { Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, "Mois suivant") }
    }
    Card(border = fr.jeremy.calepin.ui.appBorder(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp)) {
            Text(hours(total), style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.SemiBold)
            Text("${list.size} intervention${if (list.size > 1) "s" else ""} faites ce mois-ci", style = MaterialTheme.typography.bodyMedium)
            val amount = list.sumOf { iv -> (clients.firstOrNull { it.id == iv.clientId }?.rate ?: 0.0) * iv.minutes / 60.0 }
            val points = list.sumOf { iv -> iv.checklist.split('\n').count { Checklist.isDone(it) } }
            if (points > 0) Text("$points point${if (points > 1) "s" else ""} de contrôle effectué${if (points > 1) "s" else ""}", style = MaterialTheme.typography.bodyMedium)
            if (amount > 0) Text("≈ %.2f € selon les tarifs horaires".format(amount), style = MaterialTheme.typography.bodyMedium)
        }
    }
    list.groupBy { it.clientId }.forEach { (cid, ivs) ->
        val c = clients.firstOrNull { it.id == cid }
        val min = ivs.sumOf { it.minutes }
        Row(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
            Text(c?.name ?: "Sans client", modifier = Modifier.weight(1f))
            Text(hours(min) + (if ((c?.rate ?: 0.0) > 0) " · %.2f €".format(c!!.rate * min / 60.0) else ""), fontWeight = FontWeight.Medium)
        }
    }
    if (list.isNotEmpty()) {
        OutlinedButton(onClick = {
            val csv = buildString {
                append("Date;Client;Intervention;Durée (h);Statut;Tarif horaire;Montant\n")
                list.sortedBy { it.date }.forEach { iv ->
                    val c = clients.firstOrNull { it.id == iv.clientId }
                    val h = iv.minutes / 60.0
                    append(fmt("dd/MM/yyyy HH:mm", iv.date)).append(';').append(c?.name.orEmpty().replace(";", ","))
                        .append(';').append(iv.title.replace(";", ",")).append(';').append("%.2f".format(h))
                        .append(';').append(iv.status.label).append(';').append("%.2f".format(c?.rate ?: 0.0))
                        .append(';').append("%.2f".format((c?.rate ?: 0.0) * h)).append('\n')
                }
            }
            Files.shareBytes(ctx, ("﻿" + csv).toByteArray(), "Releve-" + fmt("yyyy-MM", month) + ".csv", "text/csv")
        }) { Icon(Icons.Filled.Share, null); Text(" Partager le relevé (Excel)") }
    }
}

// ---------------------------------------------------------------- Client

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun ClientDialog(c: Client, onDismiss: () -> Unit, onSave: (Client) -> Unit, onDelete: (() -> Unit)?) {
    var name by remember { mutableStateOf(c.name) }
    var kind by remember { mutableStateOf(c.kind) }
    var address by remember { mutableStateOf(c.address) }
    var phone by remember { mutableStateOf(c.phone) }
    var email by remember { mutableStateOf(c.email) }
    var rate by remember { mutableStateOf(if (c.rate > 0) c.rate.toString().removeSuffix(".0") else "") }
    var notes by remember { mutableStateOf(c.notes) }
    var confirm by remember { mutableStateOf(false) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (c.name.isBlank()) "Nouveau client ou bien" else "Modifier") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(name, { name = it }, label = { Text("Nom (ex. Villa Les Pins, M. Rossi)") }, singleLine = true)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("Client", "Villa", "Appartement", "Bateau", "Entreprise").forEach { k -> FilterChip(kind == k, { kind = k }, { Text(k) }) }
                }
                OutlinedTextField(address, { address = it }, label = { Text("Adresse") })
                OutlinedTextField(phone, { phone = it }, label = { Text("Téléphone") }, singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone))
                OutlinedTextField(email, { email = it }, label = { Text("E-mail") }, singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email))
                OutlinedTextField(rate, { rate = it.filter { ch -> ch.isDigit() || ch == ',' || ch == '.' } }, label = { Text("Tarif horaire (€, facultatif)") }, singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal))
                OutlinedTextField(notes, { notes = it }, label = { Text("Notes (codes, clés, consignes…)") })
                if (onDelete != null) TextButton(onClick = { confirm = true }) { Text("Supprimer", color = MaterialTheme.colorScheme.error) }
            }
        },
        confirmButton = {
            TextButton(enabled = name.isNotBlank(), onClick = {
                onSave(c.copy(name = name.trim(), kind = kind, address = address.trim(), phone = phone.trim(), email = email.trim(), notes = notes, rate = rate.replace(',', '.').toDoubleOrNull() ?: 0.0))
            }) { Text("Enregistrer") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Annuler") } },
    )
    if (confirm && onDelete != null) {
        AlertDialog(
            onDismissRequest = { confirm = false },
            title = { Text("Supprimer « ${c.name} » ?") },
            text = { Text("Ses interventions et leurs photos seront aussi effacées.") },
            confirmButton = { TextButton(onClick = { confirm = false; onDelete() }) { Text("Supprimer", color = MaterialTheme.colorScheme.error) } },
            dismissButton = { TextButton(onClick = { confirm = false }) { Text("Annuler") } },
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ClientScreen(store: ProStore, c: Client, ivs: List<Intervention>, onBack: () -> Unit, onEdit: () -> Unit, onOpen: (Intervention) -> Unit, onNew: () -> Unit) {
    val ctx = LocalContext.current
    var invoice by remember { mutableStateOf<fr.jeremy.calepin.pro.Invoice?>(null) }
    invoice?.let { inv ->
        InvoiceEditor(inv, store.clients.value, onDismiss = { invoice = null }) { saved ->
            val billing = fr.jeremy.calepin.pro.Billing.get(ctx)
            billing.upsert(saved)
            saved.interventions.forEach { id -> ivs.firstOrNull { it.id == id }?.let { store.upsert(it.copy(status = Status.FACTUREE)) } }
            invoice = null
            Files.shareBytes(ctx, billing.pdf(saved, c), "${saved.label}-${saved.number}.pdf", "application/pdf")
        }
    }
    BackHandler { onBack() }
    fun launch(i: Intent) { LockGuard.external(); runCatching { ctx.startActivity(i) } }
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(c.name, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Retour") } },
                actions = {
                    // Facture des interventions faites (pas encore facturées), ou devis
                    TextButton(onClick = { invoice = invoiceFor(fr.jeremy.calepin.pro.Billing.get(ctx), c, ivs) }) { Text("Facturer") }
                    TextButton(onClick = { invoice = invoiceFor(fr.jeremy.calepin.pro.Billing.get(ctx), c, ivs, quote = true) }) { Text("Devis") }
                    IconButton(onClick = onEdit) { Icon(Icons.Filled.Edit, "Modifier") }
                },
            )
        },
        floatingActionButton = { ExtendedFloatingActionButton(onClick = onNew, icon = { Icon(Icons.Filled.Add, null) }, text = { Text("Intervention") }) },
    ) { pad ->
        Column(Modifier.fillMaxSize().padding(pad).verticalScroll(rememberScrollState()).padding(16.dp).padding(bottom = 80.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(c.kind, style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary)
            if (c.address.isNotBlank()) Text(c.address)
            if (c.notes.isNotBlank()) Text(c.notes, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                if (c.phone.isNotBlank()) FilledTonalButton(onClick = { launch(Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + c.phone))) }) { Icon(Icons.Filled.Call, null); Text(" Appeler") }
                if (c.address.isNotBlank()) FilledTonalButton(onClick = { launch(Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=" + Uri.encode(c.address)))) }) { Icon(Icons.Filled.Map, null); Text(" Itinéraire") }
                if (c.email.isNotBlank()) IconButton(onClick = { launch(Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:" + c.email))) }) { Icon(Icons.Filled.Email, "E-mail") }
            }
            val total = ivs.filter { it.status != Status.PLANIFIEE }.sumOf { it.minutes }
            if (total > 0) Text("Temps passé au total : ${hours(total)}", style = MaterialTheme.typography.bodyMedium)
            HorizontalDivider()
            if (ivs.isEmpty()) Empty("Aucune intervention pour l'instant.")
            ivs.forEach { IvCard(it, c) { onOpen(it) } }
        }
    }
}

// ---------------------------------------------------------------- Intervention

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
private fun InterventionScreen(vm: NotesViewModel, store: ProStore, initial: Intervention, clients: List<Client>, onClose: () -> Unit) {
    val ctx = LocalContext.current
    val isNew = initial.id.startsWith("new-")
    var iv by remember { mutableStateOf(if (isNew) initial.copy(id = UUID.randomUUID().toString()) else initial) }
    var minutesText by remember { mutableStateOf(if (iv.minutes > 0) iv.minutes.toString() else "") }
    var newItem by remember { mutableStateOf("") }
    var confirmDelete by remember { mutableStateOf(false) }
    var pickClient by remember { mutableStateOf(false) }
    var pendingPhoto by remember { mutableStateOf<Pair<File, Boolean>?>(null) }
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(iv.timerStart) { while (iv.timerStart > 0) { now = System.currentTimeMillis(); delay(1000) } }

    fun save(close: Boolean = true) {
        store.upsert(iv.copy(minutes = minutesText.toIntOrNull() ?: iv.minutes))
        if (close) onClose()
    }
    BackHandler { save() }

    val takePhoto = rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()) { ok ->
        val (f, after) = pendingPhoto ?: return@rememberLauncherForActivityResult
        pendingPhoto = null
        if (ok && f.exists() && f.length() > 0) {
            iv = if (after) iv.copy(after = iv.after + f.name) else iv.copy(before = iv.before + f.name)
        } else {
            f.delete()
        }
    }
    var pickAfter by remember { mutableStateOf(false) }
    val pickPhoto = rememberLauncherForActivityResult(ActivityResultContracts.PickMultipleVisualMedia(20)) { uris ->
        val names = uris.mapNotNull { u ->
            runCatching {
                val f = File(store.photoDir, UUID.randomUUID().toString() + ".jpg")
                ctx.contentResolver.openInputStream(u)?.use { input -> f.outputStream().use { input.copyTo(it) } }
                f.name
            }.getOrNull()
        }
        iv = if (pickAfter) iv.copy(after = iv.after + names) else iv.copy(before = iv.before + names)
    }
    fun shoot(after: Boolean) {
        val f = File(store.photoDir, UUID.randomUUID().toString() + ".jpg")
        pendingPhoto = f to after
        LockGuard.external()
        runCatching { takePhoto.launch(Files.uriFor(ctx, f)) }.onFailure { pendingPhoto = null; fr.jeremy.calepin.i18n.I18n.toast(ctx, "Aucun appareil photo disponible", Toast.LENGTH_SHORT).show() }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { fr.jeremy.calepin.ui.FitText(if (isNew) "Nouvelle intervention" else "Intervention") },
                navigationIcon = { IconButton(onClick = { save() }) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Enregistrer et revenir") } },
                actions = { if (!isNew) IconButton(onClick = { confirmDelete = true }) { Icon(Icons.Filled.Delete, "Supprimer") } },
            )
        },
    ) { pad ->
        Column(Modifier.fillMaxSize().padding(pad).verticalScroll(rememberScrollState()).padding(16.dp).padding(bottom = 40.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            OutlinedTextField(iv.title, { iv = iv.copy(title = it) }, label = { Text("Intervention (ex. Passage, Ménage, Ouverture)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            OutlinedButton(onClick = { pickClient = true }, modifier = Modifier.fillMaxWidth()) { Text("Client : ${clients.firstOrNull { it.id == iv.clientId }?.name ?: "aucun (facultatif)"}") }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = {
                    val c = Calendar.getInstance().apply { timeInMillis = iv.date }
                    DatePickerDialog(ctx, { _, y, m, d ->
                        c.set(y, m, d); iv = iv.copy(date = c.timeInMillis)
                    }, c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH)).show()
                }) { Text(fmt("EEE d MMM yyyy", iv.date)) }
                OutlinedButton(onClick = {
                    val c = Calendar.getInstance().apply { timeInMillis = iv.date }
                    TimePickerDialog(ctx, { _, h, m ->
                        c.set(Calendar.HOUR_OF_DAY, h); c.set(Calendar.MINUTE, m); iv = iv.copy(date = c.timeInMillis)
                    }, c.get(Calendar.HOUR_OF_DAY), c.get(Calendar.MINUTE), true).show()
                }) { Text(fmt("HH'h'mm", iv.date)) }
            }
            FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Status.entries.forEach { st -> FilterChip(iv.status == st, { iv = iv.copy(status = st) }, { Text(st.label) }) }
            }

            // Temps passé et chronomètre
            Text("Temps passé", style = MaterialTheme.typography.titleSmall)
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(minutesText, { minutesText = it.filter { c -> c.isDigit() }.take(4) }, label = { Text("Minutes") }, singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.width(120.dp))
                if (iv.timerStart > 0) {
                    val run = ((now - iv.timerStart) / 1000).toInt()
                    Button(onClick = {
                        val add = ((System.currentTimeMillis() - iv.timerStart) / 60_000).toInt().coerceAtLeast(1)
                        val total = (minutesText.toIntOrNull() ?: 0) + add
                        minutesText = total.toString()
                        iv = iv.copy(timerStart = 0, minutes = total, status = if (iv.status == Status.EN_COURS) Status.FAITE else iv.status)
                        save(close = false)
                    }) { Icon(Icons.Filled.Stop, null); Text(" %d:%02d:%02d".format(run / 3600, run / 60 % 60, run % 60)) }
                } else {
                    FilledTonalButton(onClick = {
                        iv = iv.copy(timerStart = System.currentTimeMillis(), status = Status.EN_COURS)
                        save(close = false)
                    }) { Icon(Icons.Filled.PlayArrow, null); Text(" Chrono") }
                }
            }
            minutesText.toIntOrNull()?.takeIf { it > 0 }?.let { Text("= " + hours(it), style = MaterialTheme.typography.bodySmall) }

            // Liste de contrôle
            HorizontalDivider()
            Text("Liste de contrôle", style = MaterialTheme.typography.titleSmall)
            if (iv.checklist.isBlank()) {
                Text("Modèles :", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    ChecklistTemplates.ALL.keys.forEach { name ->
                        OutlinedButton(onClick = { iv = iv.copy(checklist = ChecklistTemplates.text(name), title = if (iv.title == "Passage") name else iv.title) }) { Text(name) }
                    }
                }
            }
            val lines = iv.checklist.split('\n').filter { it.isNotBlank() }
            lines.forEachIndexed { i, l ->
                val done = Checklist.isDone(l)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = done, onCheckedChange = {
                        val pos = iv.checklist.split('\n').filter { it.isNotBlank() }.take(i).sumOf { it.length + 1 }
                        iv = iv.copy(checklist = Checklist.toggleAt(lines.joinToString("\n"), pos))
                    })
                    Text(
                        if (Checklist.isItem(l)) l.drop(1).trim() else l,
                        modifier = Modifier.weight(1f),
                        textDecoration = if (done) TextDecoration.LineThrough else null,
                        color = if (done) MaterialTheme.colorScheme.onSurfaceVariant else MaterialTheme.colorScheme.onSurface,
                    )
                    IconButton(onClick = { iv = iv.copy(checklist = lines.filterIndexed { j, _ -> j != i }.joinToString("\n")) }) {
                        Icon(Icons.Filled.Delete, "Retirer", Modifier.size(18.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(newItem, { newItem = it }, label = { Text("Ajouter un point") }, singleLine = true, modifier = Modifier.weight(1f))
                IconButton(enabled = newItem.isNotBlank(), onClick = {
                    iv = iv.copy(checklist = (lines + (Checklist.OPEN + newItem.trim())).let { l -> l.filter { !Checklist.isDone(it) } + l.filter { Checklist.isDone(it) } }.joinToString("\n"))
                    newItem = ""
                }) { Icon(Icons.Filled.Add, "Ajouter") }
            }

            // Photos avant / après
            HorizontalDivider()
            PhotoRow("Photos avant", store, iv.before, onShoot = { shoot(false) }, onPick = {
                pickAfter = false; LockGuard.external(); pickPhoto.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
            }, onRemove = { n -> File(store.photoDir, n).delete(); iv = iv.copy(before = iv.before - n) })
            PhotoRow("Photos après", store, iv.after, onShoot = { shoot(true) }, onPick = {
                pickAfter = true; LockGuard.external(); pickPhoto.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
            }, onRemove = { n -> File(store.photoDir, n).delete(); iv = iv.copy(after = iv.after - n) })

            HorizontalDivider()
            OutlinedTextField(iv.notes, { iv = iv.copy(notes = it) }, label = { Text("Remarques (problèmes constatés, à prévoir…)") }, modifier = Modifier.fillMaxWidth())
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = {
                    val c = clients.firstOrNull { it.id == iv.clientId }
                    vm.saveEvent(Event(title = iv.title + (c?.let { " · " + it.name } ?: ""), start = iv.date, end = iv.date + ((minutesText.toIntOrNull() ?: 60).coerceAtLeast(15)) * 60_000L, remindMinutes = 30))
                    fr.jeremy.calepin.i18n.I18n.toast(ctx, "Ajouté à l'agenda avec un rappel 30 min avant", Toast.LENGTH_SHORT).show()
                }) { Icon(Icons.Filled.EventAvailable, null); Text(" Agenda") }
                OutlinedButton(onClick = { save(close = false); shareReport(ctx, store, iv.copy(minutes = minutesText.toIntOrNull() ?: iv.minutes), clients.firstOrNull { it.id == iv.clientId }) }) {
                    Icon(Icons.Filled.Share, null); Text(" Compte rendu")
                }
            }
            Button(onClick = { save() }, modifier = Modifier.fillMaxWidth()) { Text("Enregistrer") }
        }
    }

    if (pickClient) {
        AlertDialog(
            onDismissRequest = { pickClient = false },
            title = { Text("Client ou bien") },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState())) {
                    Text("Sans client", Modifier.fillMaxWidth().clickable { iv = iv.copy(clientId = ""); pickClient = false }.padding(vertical = 10.dp), color = MaterialTheme.colorScheme.primary)
                    clients.forEach { c ->
                        Text(c.name, Modifier.fillMaxWidth().clickable { iv = iv.copy(clientId = c.id); pickClient = false }.padding(vertical = 10.dp))
                    }
                }
            },
            confirmButton = { TextButton(onClick = { pickClient = false }) { Text("Fermer") } },
        )
    }
    if (confirmDelete) {
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            title = { Text("Supprimer cette intervention ?") },
            text = { Text("Ses photos seront aussi effacées.") },
            confirmButton = { TextButton(onClick = { store.deleteIntervention(iv.id); confirmDelete = false; onClose() }) { Text("Supprimer", color = MaterialTheme.colorScheme.error) } },
            dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text("Annuler") } },
        )
    }
}

@Composable
private fun PhotoRow(title: String, store: ProStore, names: List<String>, onShoot: () -> Unit, onPick: () -> Unit, onRemove: (String) -> Unit) {
    var viewing by remember { mutableStateOf<String?>(null) }
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(title, style = MaterialTheme.typography.titleSmall, modifier = Modifier.weight(1f))
        IconButton(onClick = onShoot) { Icon(Icons.Filled.PhotoCamera, "Prendre une photo") }
        IconButton(onClick = onPick) { Icon(Icons.Filled.PhotoLibrary, "Depuis la galerie") }
    }
    if (names.isNotEmpty()) {
        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            items(names, key = { it }) { n ->
                val f = File(store.photoDir, n)
                val bmp by produceState<Bitmap?>(null, n) { value = withContext(Dispatchers.IO) { Media.thumbnail(f, false, 300) } }
                Box(Modifier.size(92.dp).clip(RoundedCornerShape(10.dp)).background(MaterialTheme.colorScheme.surfaceContainer).clickable { viewing = n }) {
                    bmp?.let { Image(it.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop) }
                }
            }
        }
    }
    viewing?.let { n ->
        val f = File(store.photoDir, n)
        val big by produceState<Bitmap?>(null, n) { value = withContext(Dispatchers.IO) { Media.thumbnail(f, false, 1600) } }
        AlertDialog(
            onDismissRequest = { viewing = null },
            text = { big?.let { Image(it.asImageBitmap(), null, Modifier.fillMaxWidth().height(380.dp), contentScale = ContentScale.Fit) } },
            confirmButton = { TextButton(onClick = { viewing = null }) { Text("Fermer") } },
            dismissButton = { TextButton(onClick = { onRemove(n); viewing = null }) { Text("Supprimer", color = MaterialTheme.colorScheme.error) } },
        )
    }
}

/** Compte rendu texte + photos, à envoyer au client (mail, WhatsApp…). */
private fun shareReport(ctx: android.content.Context, store: ProStore, iv: Intervention, c: Client?) {
    val text = buildString {
        append(iv.title).append(c?.let { " – " + it.name } ?: "").append('\n')
        append(fmt("EEEE d MMMM yyyy 'à' HH'h'mm", iv.date)).append('\n')
        if (iv.minutes > 0) append("Durée : ").append(hours(iv.minutes)).append('\n')
        if (iv.checklist.isNotBlank()) {
            append("\nPoints vérifiés :\n")
            iv.checklist.split('\n').filter { it.isNotBlank() }.forEach { l ->
                append(if (Checklist.isDone(l)) "✅ " else "⬜ ").append(l.drop(1).trim()).append('\n')
            }
        }
        if (iv.notes.isNotBlank()) append("\nRemarques :\n").append(iv.notes).append('\n')
    }
    val uris = ArrayList((iv.before + iv.after).map { Files.uriFor(ctx, File(store.photoDir, it)) })
    LockGuard.external()
    val i = if (uris.isEmpty()) {
        Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, text)
    } else {
        Intent(Intent.ACTION_SEND_MULTIPLE).setType("image/*").putExtra(Intent.EXTRA_TEXT, text)
            .putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    }
    runCatching { ctx.startActivity(Intent.createChooser(i, fr.jeremy.calepin.i18n.I18n.tr("Envoyer le compte rendu")).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)) }
}

/**
 * Saisie rapide : une ligne = une intervention, sans fiche client obligatoire.
 * « 12/10 Ménage villa Les Pins 2h », « Jardin 1h30 », « hier Courses Mme Blanc 45 min ».
 * Un nom de client déjà enregistré présent dans la ligne y est rattaché automatiquement.
 */
@Composable
private fun QuickJournal(store: ProStore, clients: List<Client>) {
    val ctx = LocalContext.current
    var open by remember { mutableStateOf(false) }
    var text by remember { mutableStateOf("") }
    val lines = text.lines().map { it.trim() }.filter { it.isNotEmpty() }
    Card(border = fr.jeremy.calepin.ui.appBorder(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Saisie rapide", style = MaterialTheme.typography.titleSmall)
                    Text("Une ligne = une intervention, avec ou sans client.", style = MaterialTheme.typography.bodySmall)
                }
                TextButton(onClick = { open = !open }) { Text(if (open) "Fermer" else "Écrire") }
            }
            if (open) {
                OutlinedTextField(
                    text, { text = it },
                    label = { Text("Ex. : 12/10 Ménage villa Les Pins 2h") },
                    modifier = Modifier.fillMaxWidth().height(160.dp),
                )
                val parsed = lines.map { parseLine(it, clients) }
                val total = parsed.sumOf { it.minutes }
                Text(
                    "${lines.size} ligne${if (lines.size > 1) "s" else ""} = ${lines.size} intervention${if (lines.size > 1) "s" else ""}" +
                        (if (total > 0) " · ${hours(total)}" else ""),
                    style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary,
                )
                Button(enabled = lines.isNotEmpty(), onClick = {
                    parsed.forEach { store.upsert(it) }
                    fr.jeremy.calepin.i18n.I18n.toast(ctx, "${parsed.size} intervention(s) ajoutée(s)", Toast.LENGTH_SHORT).show()
                    text = ""; open = false
                }) { Text("Ajouter") }
            }
        }
    }
}

private val rxDate = Regex("""^(\d{1,2})[/.-](\d{1,2})(?:[/.-](\d{2,4}))?\s+""")
private val rxHours = Regex("""(?i)\b(\d{1,2})\s*h\s*(\d{1,2})?\b(?!\s*\d)""")
private val rxMin = Regex("""(?i)\b(\d{1,3})\s*(min|mn|minutes?)\b""")

private fun parseLine(raw: String, clients: List<Client>): Intervention {
    var line = raw
    val cal = Calendar.getInstance().apply { set(Calendar.HOUR_OF_DAY, 12); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0) }
    rxDate.find(line)?.let { m ->
        val d = m.groupValues[1].toInt(); val mo = m.groupValues[2].toInt()
        val y = m.groupValues[3].takeIf { it.isNotEmpty() }?.toInt()?.let { if (it < 100) 2000 + it else it }
        if (d in 1..31 && mo in 1..12) {
            cal.set(Calendar.DAY_OF_MONTH, 1); cal.set(Calendar.MONTH, mo - 1); y?.let { cal.set(Calendar.YEAR, it) }; cal.set(Calendar.DAY_OF_MONTH, d)
            line = line.substring(m.value.length)
        }
    }
    val low = line.lowercase()
    when {
        low.startsWith("hier ") -> { cal.add(Calendar.DAY_OF_YEAR, -1); line = line.substring(5) }
        low.startsWith("avant-hier ") -> { cal.add(Calendar.DAY_OF_YEAR, -2); line = line.substring(11) }
        low.startsWith("aujourd'hui ") -> line = line.substring(12)
    }
    var minutes = 0
    rxHours.find(line)?.let { m ->
        minutes = m.groupValues[1].toInt() * 60 + (m.groupValues[2].toIntOrNull() ?: 0)
        line = line.removeRange(m.range)
    } ?: rxMin.find(line)?.let { m ->
        minutes = m.groupValues[1].toInt()
        line = line.removeRange(m.range)
    }
    val title = line.replace(Regex("\\s+"), " ").trim().ifEmpty { "Intervention" }
    val norm = title.lowercase()
    val client = clients.filter { it.name.length >= 3 && norm.contains(it.name.lowercase()) }.maxByOrNull { it.name.length }
    return Intervention(clientId = client?.id ?: "", title = title.replaceFirstChar { it.uppercase() }, date = cal.timeInMillis, minutes = minutes, status = Status.FAITE)
}
