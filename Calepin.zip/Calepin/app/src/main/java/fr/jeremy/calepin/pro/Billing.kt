package fr.jeremy.calepin.pro

import android.content.Context
import android.graphics.Color
import android.text.Layout
import fr.jeremy.calepin.export.SimplePdf
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.UUID

/** Informations de l'entreprise imprimées sur les devis et factures. */
data class Business(
    val name: String = "",
    val owner: String = "",
    val address: String = "",
    val siret: String = "",
    val phone: String = "",
    val email: String = "",
    /** Mention de TVA (micro-entreprise : franchise en base). */
    val vatNote: String = "TVA non applicable, article 293 B du CGI",
    val paymentNote: String = "Paiement à réception, par virement ou chèque.",
    val iban: String = "",
    /** Taux de cotisations sociales (en %) pour estimer ce qu'il faut déclarer à l'URSSAF. */
    val urssafRate: Double = 21.2,
    /** Plafond annuel de chiffre d'affaires du régime (à vérifier chaque année sur urssaf.fr). */
    val ceiling: Double = 77700.0,
) {
    fun toJson(): JSONObject = JSONObject().put("name", name).put("owner", owner).put("address", address).put("siret", siret)
        .put("phone", phone).put("email", email).put("vat", vatNote).put("payment", paymentNote).put("iban", iban)
        .put("rate", urssafRate).put("ceiling", ceiling)

    companion object {
        fun fromJson(o: JSONObject?) = if (o == null) Business() else Business(
            o.optString("name"), o.optString("owner"), o.optString("address"), o.optString("siret"), o.optString("phone"),
            o.optString("email"), o.optString("vat", Business().vatNote), o.optString("payment", Business().paymentNote),
            o.optString("iban"), o.optDouble("rate", 21.2), o.optDouble("ceiling", 77700.0),
        )
    }
}

data class InvoiceLine(val label: String, val qty: Double, val unit: Double) {
    val total get() = qty * unit
    fun toJson(): JSONObject = JSONObject().put("label", label).put("qty", qty).put("unit", unit)

    companion object {
        fun fromJson(o: JSONObject) = InvoiceLine(o.optString("label"), o.optDouble("qty", 1.0), o.optDouble("unit", 0.0))
    }
}

/** Devis ou facture. */
data class Invoice(
    val id: String = UUID.randomUUID().toString(),
    val quote: Boolean,
    val number: String,
    val clientId: String,
    val date: Long = System.currentTimeMillis(),
    val lines: List<InvoiceLine>,
    val notes: String = "",
    /** Date d'encaissement (0 = pas encore payée). */
    val paidAt: Long = 0L,
    /** Interventions facturées (passées en « Facturée »). */
    val interventions: List<String> = emptyList(),
) {
    val total get() = lines.sumOf { it.total }
    val label get() = if (quote) "Devis" else "Facture"

    fun toJson(): JSONObject = JSONObject().put("id", id).put("quote", quote).put("number", number).put("clientId", clientId)
        .put("date", date).put("lines", JSONArray().apply { lines.forEach { put(it.toJson()) } }).put("notes", notes)
        .put("paidAt", paidAt).put("ivs", JSONArray(interventions))

    companion object {
        fun fromJson(o: JSONObject): Invoice {
            val l = o.optJSONArray("lines") ?: JSONArray()
            val iv = o.optJSONArray("ivs") ?: JSONArray()
            return Invoice(
                o.optString("id"), o.optBoolean("quote"), o.optString("number"), o.optString("clientId"), o.optLong("date"),
                (0 until l.length()).map { InvoiceLine.fromJson(l.getJSONObject(it)) }, o.optString("notes"), o.optLong("paidAt"),
                (0 until iv.length()).map { iv.optString(it) },
            )
        }
    }
}

/** Devis, factures et informations de l'entreprise (fichier billing.json, inclus dans la sauvegarde complète via pro). */
class Billing private constructor(private val ctx: Context) {
    private val file = File(ctx.filesDir, "billing.json")
    private val _business = MutableStateFlow(Business())
    val business: StateFlow<Business> = _business
    private val _invoices = MutableStateFlow<List<Invoice>>(emptyList())
    val invoices: StateFlow<List<Invoice>> = _invoices

    init {
        runCatching {
            val o = JSONObject(file.readText())
            _business.value = Business.fromJson(o.optJSONObject("business"))
            val a = o.optJSONArray("invoices") ?: JSONArray()
            _invoices.value = (0 until a.length()).map { Invoice.fromJson(a.getJSONObject(it)) }
        }
    }

    private fun persist() {
        val o = JSONObject().put("business", _business.value.toJson())
            .put("invoices", JSONArray().apply { _invoices.value.forEach { put(it.toJson()) } })
        file.writeText(o.toString())
    }

    fun setBusiness(b: Business) { _business.value = b; persist() }

    /** Prochain numéro : F-2026-001, D-2026-001… (suit la numérotation de l'année). */
    fun nextNumber(quote: Boolean, date: Long = System.currentTimeMillis()): String {
        val y = Calendar.getInstance().apply { timeInMillis = date }.get(Calendar.YEAR)
        val prefix = (if (quote) "D-" else "F-") + y + "-"
        val n = _invoices.value.filter { it.number.startsWith(prefix) }.mapNotNull { it.number.removePrefix(prefix).toIntOrNull() }.maxOrNull() ?: 0
        return prefix + "%03d".format(n + 1)
    }

    fun upsert(i: Invoice) {
        _invoices.value = _invoices.value.filter { it.id != i.id } + i
        persist()
    }

    fun delete(id: String) { _invoices.value = _invoices.value.filter { it.id != id }; persist() }

    /** Chiffre d'affaires encaissé entre deux dates (factures payées). */
    fun cashed(from: Long, to: Long) = _invoices.value.filter { !it.quote && it.paidAt in from until to }.sumOf { it.total }
    fun invoiced(from: Long, to: Long) = _invoices.value.filter { !it.quote && it.date in from until to }.sumOf { it.total }
    fun unpaid() = _invoices.value.filter { !it.quote && it.paidAt == 0L }

    /** PDF du devis ou de la facture. */
    fun pdf(i: Invoice, client: Client?): ByteArray {
        val b = _business.value
        val fr = Locale.FRANCE
        val d = SimpleDateFormat("dd/MM/yyyy", fr)
        fun eur(v: Double) = "%,.2f €".format(fr, v)
        val pdf = SimplePdf(listOf(b.name, b.siret.takeIf { it.isNotBlank() }?.let { "SIRET $it" }).filterNotNull().joinToString(" · "))
        val blue = Color.rgb(31, 95, 122)
        // En-tête : entreprise à gauche, titre à droite
        val top = pdf.y
        pdf.text(listOf(b.name.ifBlank { "Mon entreprise" }, b.owner, b.address, b.phone, b.email, b.siret.takeIf { it.isNotBlank() }?.let { "SIRET : $it" })
            .filter { !it.isNullOrBlank() }.joinToString("\n"), size = 10f, advance = false, boxWidth = pdf.width * 0.55f)
        pdf.text("${i.label.uppercase(fr)}\nN° ${i.number}\nDate : ${d.format(Date(i.date))}" + (if (i.quote) "\nValable 30 jours" else ""),
            size = 12f, bold = true, color = blue, align = Layout.Alignment.ALIGN_OPPOSITE)
        pdf.space(18f)
        // Client
        pdf.text("Client", size = 9f, bold = true, color = Color.GRAY, x = pdf.width * 0.5f, boxWidth = pdf.width * 0.5f, after = 2f)
        pdf.text(listOf(client?.name ?: "", client?.address ?: "", client?.email ?: "", client?.phone ?: "").filter { it.isNotBlank() }.joinToString("\n").ifBlank { "—" },
            size = 10.5f, x = pdf.width * 0.5f, boxWidth = pdf.width * 0.5f, after = 18f)
        if (top > pdf.y) pdf.space(0f)
        // Lignes
        val wts = listOf(5.5f, 1.2f, 1.8f, 1.8f)
        pdf.row(listOf("Désignation", "Qté", "Prix unitaire", "Total"), wts, bold = true, fill = Color.rgb(232, 240, 244))
        i.lines.forEach { l ->
            val q = if (l.qty % 1.0 == 0.0) "%.0f".format(fr, l.qty) else "%.2f".format(fr, l.qty)
            pdf.row(listOf(l.label, q, eur(l.unit), eur(l.total)), wts)
        }
        pdf.space(6f)
        pdf.row(listOf("Total à payer", "", "", eur(i.total)), wts, bold = true, size = 11.5f, fill = Color.rgb(232, 240, 244))
        pdf.space(10f)
        if (b.vatNote.isNotBlank()) pdf.text(b.vatNote, size = 9.5f, color = Color.DKGRAY)
        if (i.notes.isNotBlank()) pdf.text(i.notes, size = 10f, after = 8f)
        if (!i.quote) {
            pdf.text(b.paymentNote, size = 9.5f, color = Color.DKGRAY)
            if (b.iban.isNotBlank()) pdf.text("IBAN : ${b.iban}", size = 9.5f, color = Color.DKGRAY)
            pdf.text("En cas de retard de paiement, indemnité forfaitaire pour frais de recouvrement : 40 € (art. L441-10 du Code de commerce).", size = 8f, color = Color.GRAY)
            if (i.paidAt > 0) pdf.text("Payée le ${d.format(Date(i.paidAt))}", size = 10f, bold = true, color = Color.rgb(46, 125, 50))
        } else {
            pdf.space(14f)
            pdf.text("Bon pour accord (date et signature du client) :", size = 10f)
            pdf.space(50f)
        }
        return pdf.build()
    }

    companion object {
        @Volatile private var instance: Billing? = null
        fun get(ctx: Context): Billing = instance ?: synchronized(this) { instance ?: Billing(ctx.applicationContext).also { instance = it } }
    }
}
