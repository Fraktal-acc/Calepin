package fr.jeremy.calepin.reminders

import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import fr.jeremy.calepin.MainActivity
import fr.jeremy.calepin.data.Event
import fr.jeremy.calepin.data.NoteDb

/** Programmation des rappels avec AlarmManager (fonctionne appli fermée et téléphone en veille). */
object Reminders {
    const val EXTRA_EVENT = "event_id"
    const val EXTRA_NOTE = "note_id"

    private fun am(ctx: Context) = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager

    private fun firePending(ctx: Context, eventId: Long): PendingIntent =
        PendingIntent.getBroadcast(
            ctx, eventId.toInt(),
            Intent(ctx, ReminderReceiver::class.java).putExtra(EXTRA_EVENT, eventId),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )

    /** Ouvre la note liée (ou l'appli) quand on touche le rappel. */
    fun openPending(ctx: Context, e: Event): PendingIntent =
        PendingIntent.getActivity(
            ctx, 100_000 + e.id.toInt(),
            Intent(ctx, MainActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                .putExtra(EXTRA_NOTE, e.noteId),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )

    fun canExact(ctx: Context): Boolean = Build.VERSION.SDK_INT < 31 || am(ctx).canScheduleExactAlarms()

    /** Programme le rappel de [e] (ou l'annule s'il n'en a pas / s'il est passé). */
    fun schedule(ctx: Context, e: Event, at: Long? = e.remindAt) {
        cancel(ctx, e.id)
        if (at == null || at < System.currentTimeMillis() - 60_000) return
        val pi = firePending(ctx, e.id)
        val a = am(ctx)
        when {
            e.alarm && canExact(ctx) -> a.setAlarmClock(AlarmManager.AlarmClockInfo(at, openPending(ctx, e)), pi)
            canExact(ctx) -> a.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
            else -> a.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
        }
    }

    fun cancel(ctx: Context, eventId: Long) {
        am(ctx).cancel(firePending(ctx, eventId))
    }

    /** Après un redémarrage ou une mise à jour : tout reprogrammer. */
    fun rescheduleAll(ctx: Context) {
        NoteDb(ctx).events().forEach { schedule(ctx, it) }
    }

    // ------------------------------------------------------------ Sonneries

    fun defaultAlarmUri(): Uri = Settings.System.DEFAULT_ALARM_ALERT_URI

    fun resolve(ctx: Context, uri: String, alarm: Boolean): Uri =
        uri.takeIf { it.isNotBlank() }?.let { Uri.parse(it) }
            ?: if (alarm) {
                RingtoneManager.getActualDefaultRingtoneUri(ctx, RingtoneManager.TYPE_ALARM)
                    ?: RingtoneManager.getActualDefaultRingtoneUri(ctx, RingtoneManager.TYPE_RINGTONE)
                    ?: defaultAlarmUri()
            } else {
                Settings.System.DEFAULT_NOTIFICATION_URI
            }

    fun ringtoneName(ctx: Context, uri: String): String {
        if (uri.isBlank()) return "Sonnerie par défaut du téléphone"
        return runCatching { RingtoneManager.getRingtone(ctx, Uri.parse(uri))?.getTitle(ctx) }.getOrNull() ?: "Sonnerie choisie"
    }

    // ---------------------------------------------------------- Canaux

    const val CHANNEL_ALARM = "calepin_alarmes"

    /** Un canal de notification par sonnerie (Android fixe le son au niveau du canal). */
    fun notificationChannel(ctx: Context, ringtone: String): String {
        val nm = ctx.getSystemService(NotificationManager::class.java)
        val id = if (ringtone.isBlank()) "calepin_rappels" else "calepin_rappels_" + Integer.toHexString(ringtone.hashCode())
        if (nm.getNotificationChannel(id) == null) {
            val ch = NotificationChannel(
                id,
                if (ringtone.isBlank()) fr.jeremy.calepin.i18n.I18n.tr(ctx, "Rappels") else fr.jeremy.calepin.i18n.I18n.tr(ctx, "Rappels") + " · " + fr.jeremy.calepin.i18n.I18n.tr(ringtoneName(ctx, ringtone)),
                NotificationManager.IMPORTANCE_HIGH,
            )
            ch.setSound(
                resolve(ctx, ringtone, alarm = false),
                AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_NOTIFICATION_EVENT)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build(),
            )
            ch.enableVibration(true)
            nm.createNotificationChannel(ch)
        }
        return id
    }

    fun alarmChannel(ctx: Context): String {
        val nm = ctx.getSystemService(NotificationManager::class.java)
        if (nm.getNotificationChannel(CHANNEL_ALARM) == null) {
            val ch = NotificationChannel(CHANNEL_ALARM, fr.jeremy.calepin.i18n.I18n.tr(ctx, "Alarmes"), NotificationManager.IMPORTANCE_HIGH)
            ch.setSound(null, null) // la sonnerie est jouée par le service d'alarme
            ch.enableVibration(false)
            ch.lockscreenVisibility = android.app.Notification.VISIBILITY_PUBLIC
            nm.createNotificationChannel(ch)
        }
        return CHANNEL_ALARM
    }
}
