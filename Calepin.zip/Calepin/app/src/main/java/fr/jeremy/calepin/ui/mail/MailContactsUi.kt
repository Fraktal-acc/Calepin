package fr.jeremy.calepin.ui.mail

import fr.jeremy.calepin.ui.bubble
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Contacts
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.PersonAdd
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Checkbox
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import fr.jeremy.calepin.i18n.I18n
import fr.jeremy.calepin.i18n.RawText
import fr.jeremy.calepin.i18n.Text
import fr.jeremy.calepin.mail.MailContact
import fr.jeremy.calepin.mail.MailContacts
import fr.jeremy.calepin.search.TextNorm
import fr.jeremy.calepin.ui.appBorder
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

@Composable
private fun Initial(name: String, size: Int = 36) {
    val cs = MaterialTheme.colorScheme
    Box(Modifier.size(size.dp).clip(CircleShape).background(cs.tertiary), contentAlignment = Alignment.Center) {
        RawText(name.trim().take(1).uppercase().ifBlank { "@" }, color = cs.onTertiary, fontWeight = FontWeight.Bold)
    }
}

// ------------------------------------------------------------------ Rubrique « Contacts » des mails

/** Carnet d'adresses des mails : ajout, modification, suppression ; toucher un contact écrit un mail. */
@Composable
fun MailContactsCard(onWrite: (String) -> Unit) {
    val ctx = LocalContext.current
    remember { MailContacts.init(ctx) }
    val list by MailContacts.list.collectAsStateWithLifecycle()
    var editing by remember { mutableStateOf<MailContact?>(null) }
    var adding by remember { mutableStateOf(false) }
    var query by remember { mutableStateOf("") }
    var expanded by remember { mutableStateOf(false) }
    Surface(shape = MaterialTheme.shapes.large, color = MaterialTheme.colorScheme.surfaceContainerLow, border = appBorder(), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.Contacts, null, tint = MaterialTheme.colorScheme.primary)
                Spacer(Modifier.width(10.dp))
                Text("Contacts", style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
                IconButton(onClick = { adding = true }) { Icon(Icons.Filled.Add, "Ajouter un contact") }
            }
            if (list.isEmpty()) Text(
                "Ajoute tes contacts ici, ou avec le « + » à côté de l'expéditeur d'un mail. Tu les retrouveras en écrivant un nouveau mail.",
                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            if (list.size > 6) OutlinedTextField(
                query, { query = it }, singleLine = true, modifier = Modifier.fillMaxWidth(),
                placeholder = { Text("Rechercher un contact") }, leadingIcon = { Icon(Icons.Filled.Search, null) },
                trailingIcon = { if (query.isNotEmpty()) IconButton(onClick = { query = "" }) { Icon(Icons.Filled.Close, "Effacer") } },
            )
            val shown = if (query.isBlank()) list else MailContacts.search(ctx, query)
            val visible = if (expanded || query.isNotBlank()) shown else shown.take(6)
            visible.forEach { c ->
                Surface(onClick = { onWrite(c.email) }, shape = MaterialTheme.shapes.medium, color = MaterialTheme.colorScheme.surfaceContainerHigh.bubble(), modifier = Modifier.fillMaxWidth()) {
                    Row(Modifier.padding(start = 10.dp, top = 6.dp, bottom = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                        Initial(c.name.ifBlank { c.email })
                        Spacer(Modifier.width(10.dp))
                        Column(Modifier.weight(1f)) {
                            if (c.name.isNotBlank()) RawText(c.name, style = MaterialTheme.typography.titleSmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            RawText(c.email, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                        IconButton(onClick = { editing = c }) { Icon(Icons.Filled.Edit, "Modifier le contact") }
                    }
                }
            }
            if (!expanded && query.isBlank() && shown.size > 6) TextButton(onClick = { expanded = true }) { RawText(I18n.trf("Voir les {0} contacts", shown.size)) }
        }
    }
    if (adding) SaveMailContactDialog("", "") { adding = false }
    editing?.let { c -> SaveMailContactDialog(c.email, c.name, existing = true) { editing = null } }
}

/** Enregistrer (ou modifier) un contact mail. [email] vide : saisie libre. */
@Composable
fun SaveMailContactDialog(email: String, name: String, existing: Boolean = false, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    var e by remember { mutableStateOf(email) }
    var n by remember { mutableStateOf(name) }
    var confirmDelete by remember { mutableStateOf(false) }
    AlertDialog(
        onDismissRequest = onDismiss,
        icon = { Icon(Icons.Filled.PersonAdd, null) },
        title = { Text(if (existing) "Modifier le contact" else "Enregistrer le contact") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(n, { n = it }, label = { Text("Nom") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(
                    e, { e = it.trim() }, label = { Text("Adresse mail") }, singleLine = true, modifier = Modifier.fillMaxWidth(),
                    isError = e.isNotEmpty() && !MailContacts.valid(e),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
                )
                if (existing) TextButton(onClick = { confirmDelete = true }) {
                    Icon(Icons.Filled.Delete, null, tint = MaterialTheme.colorScheme.error); Text("  Supprimer le contact", color = MaterialTheme.colorScheme.error)
                }
            }
        },
        confirmButton = {
            TextButton(enabled = MailContacts.valid(e), onClick = {
                // Adresse modifiée : l'ancienne fiche est remplacée
                if (existing && !e.equals(email, true)) MailContacts.remove(ctx, email)
                MailContacts.put(ctx, e, n)
                I18n.toast(ctx, I18n.tr("Contact enregistré."), android.widget.Toast.LENGTH_SHORT).show()
                onDismiss()
            }) { Text("Enregistrer") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Annuler") } },
    )
    if (confirmDelete) AlertDialog(
        onDismissRequest = { confirmDelete = false },
        title = { Text("Supprimer ce contact ?") },
        text = { RawText(MailContact(email, name).display) },
        confirmButton = { TextButton(onClick = { MailContacts.remove(ctx, email); confirmDelete = false; onDismiss() }) { Text("Supprimer") } },
        dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text("Annuler") } },
    )
}

// ------------------------------------------------------------------ Choix des destinataires

/** Une adresse proposée : contact Calepin ou contact du téléphone. */
private data class Choice(val email: String, val name: String, val phone: Boolean)

/** Adresses mail des contacts du téléphone (si l'accès est autorisé et la rubrique Contacts non verrouillée). */
private fun phoneEmails(ctx: android.content.Context): List<Choice> {
    val granted = androidx.core.content.ContextCompat.checkSelfPermission(ctx, android.Manifest.permission.READ_CONTACTS) == android.content.pm.PackageManager.PERMISSION_GRANTED
    if (!granted || fr.jeremy.calepin.SectionLock.needs(fr.jeremy.calepin.SectionLock.CONTACTS)) return emptyList()
    return runCatching { fr.jeremy.calepin.contacts.PhoneContacts.load(ctx) }.getOrDefault(emptyList())
        .flatMap { c -> c.emails.map { Choice(it.value.trim().lowercase(), c.name, true) } }
        .filter { MailContacts.valid(it.email) }
}

/** Fenêtre de choix des destinataires : contacts mail de Calepin, puis ceux du téléphone. Plusieurs choix possibles. */
@Composable
fun MailContactPicker(already: String, onDismiss: () -> Unit, onPicked: (List<String>) -> Unit) {
    val ctx = LocalContext.current
    remember { MailContacts.init(ctx) }
    val mine by MailContacts.list.collectAsStateWithLifecycle()
    val phone by produceState(emptyList<Choice>()) { value = withContext(Dispatchers.IO) { phoneEmails(ctx) } }
    var query by remember { mutableStateOf("") }
    val present = remember(already) { already.lowercase() }
    var chosen by remember { mutableStateOf(emptySet<String>()) }
    val all = (mine.map { Choice(it.email, it.name, false) } + phone.filter { p -> mine.none { it.email.equals(p.email, true) } }).distinctBy { it.email + it.phone }
    val words = TextNorm.norm(query).lowercase().split(Regex("\\s+")).filter { it.isNotEmpty() }
    val shown = all.filter { c -> val t = TextNorm.norm(c.name + " " + c.email).lowercase(); words.all { it in t } }
    AlertDialog(
        onDismissRequest = onDismiss,
        icon = { Icon(Icons.Filled.Contacts, null) },
        title = { Text("Choisir les destinataires") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    query, { query = it }, singleLine = true, modifier = Modifier.fillMaxWidth(),
                    placeholder = { Text("Rechercher un contact") }, leadingIcon = { Icon(Icons.Filled.Search, null) },
                )
                if (all.isEmpty()) Text(
                    "Aucun contact pour l'instant. Enregistre des contacts dans Messages → Mails → Contacts, ou avec le « + » à côté de l'expéditeur d'un mail.",
                    style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                LazyColumn(Modifier.heightIn(max = 380.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    items(shown, key = { it.email + it.phone }) { c ->
                        Column {
                            if (c.phone && shown.firstOrNull { it.phone } == c) {
                                Text("Contacts du téléphone", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(top = 6.dp, bottom = 2.dp))
                            }
                            val on = c.email in chosen
                            val inField = present.contains(c.email)
                            Surface(
                                onClick = { if (!inField) chosen = if (on) chosen - c.email else chosen + c.email },
                                shape = MaterialTheme.shapes.medium,
                                color = if (on) MaterialTheme.colorScheme.secondaryContainer else MaterialTheme.colorScheme.surfaceContainerLow,
                                modifier = Modifier.fillMaxWidth(),
                            ) {
                                Row(Modifier.padding(6.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Checkbox(checked = on || inField, enabled = !inField, onCheckedChange = { v -> chosen = if (v) chosen + c.email else chosen - c.email })
                                    Column(Modifier.weight(1f)) {
                                        if (c.name.isNotBlank()) RawText(c.name, style = MaterialTheme.typography.titleSmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                        RawText(c.email, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        },
        confirmButton = { TextButton(enabled = chosen.isNotEmpty(), onClick = { onPicked(chosen.toList()); onDismiss() }) { RawText(I18n.trf("Ajouter ({0})", chosen.size)) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Annuler") } },
    )
}

/** Suggestions sous le champ des destinataires pendant la frappe (« Mar » → Marc Dupont). */
@Composable
fun RecipientSuggestions(field: String, onPick: (String) -> Unit) {
    val ctx = LocalContext.current
    remember { MailContacts.init(ctx) }
    val list by MailContacts.list.collectAsStateWithLifecycle()
    val token = MailContacts.lastToken(field)
    if (token.isEmpty() || token.contains('@') && MailContacts.valid(token)) return
    val words = TextNorm.norm(token).lowercase().split(Regex("\\s+")).filter { it.isNotEmpty() }
    val found = list.filter { c -> val t = TextNorm.norm(c.name + " " + c.email).lowercase(); words.all { it in t } && !field.contains(c.email, true) }.take(6)
    if (found.isEmpty()) return
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        found.forEach { c ->
            AssistChip(onClick = { onPick(c.email) }, label = { RawText(c.name.ifBlank { c.email }, maxLines = 1) }, leadingIcon = { Initial(c.name.ifBlank { c.email }, 20) })
        }
    }
}

/** Bouton « + » à côté de l'expéditeur d'un mail : enregistre l'adresse dans les contacts. */
@Composable
fun AddSenderButton(email: String, name: String) {
    val ctx = LocalContext.current
    remember { MailContacts.init(ctx) }
    val list by MailContacts.list.collectAsStateWithLifecycle()
    var saving by remember { mutableStateOf(false) }
    if (!MailContacts.valid(email)) return
    val known = list.any { it.email.equals(email, true) }
    if (known) {
        FilterChip(selected = true, onClick = { saving = true }, label = { Text("Dans mes contacts") })
    } else OutlinedButton(onClick = { saving = true }) {
        Icon(Icons.Filled.Add, null, Modifier.size(18.dp)); Text(" Contact")
    }
    if (saving) SaveMailContactDialog(email.lowercase(), if (name.equals(email, true)) "" else name, existing = known) { saving = false }
}
