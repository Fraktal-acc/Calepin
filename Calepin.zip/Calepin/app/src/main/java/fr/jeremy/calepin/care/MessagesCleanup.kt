package fr.jeremy.calepin.care

import android.content.Context
import java.io.File

/**
 * Le menu Messages (mails et SMS) a été retiré : on efface une fois ce qu'il gardait sur le téléphone
 * (adresses et mots de passe des boîtes mail, mails suivis, pièces jointes en cache, clé de chiffrement).
 */
object MessagesCleanup {
    fun run(ctx: Context) {
        val app = ctx.applicationContext
        val flags = app.getSharedPreferences("calepin_cleanup", Context.MODE_PRIVATE)
        if (flags.getBoolean("messages_removed", false)) return
        listOf("calepin_mail", "calepin_mail_contacts", "calepin_messages", "calepin_chat_sync").forEach { name ->
            runCatching { app.getSharedPreferences(name, Context.MODE_PRIVATE).edit().clear().commit() }
            runCatching { app.deleteSharedPreferences(name) }
        }
        runCatching { File(app.filesDir, "messages.json").delete() }
        runCatching { File(app.filesDir, "msg_media").deleteRecursively() }
        runCatching { File(app.cacheDir, "mail").deleteRecursively() }
        runCatching { File(app.cacheDir, "chat_import").deleteRecursively() }
        runCatching {
            val ks = java.security.KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
            if (ks.containsAlias("calepin_mail_key")) ks.deleteEntry("calepin_mail_key")
        }
        flags.edit().putBoolean("messages_removed", true).apply()
    }
}
