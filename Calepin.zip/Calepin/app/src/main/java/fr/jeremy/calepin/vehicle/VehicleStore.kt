package fr.jeremy.calepin.vehicle

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.UUID

data class Vehicle(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val kind: VehicleKind = VehicleKind.VOITURE,
    val plate: String = "",
    val km: Int = 0,
    val notes: String = "",
    val created: Long = System.currentTimeMillis(),
) {
    fun toJson(): JSONObject = JSONObject().put("id", id).put("name", name).put("kind", kind.name).put("plate", plate)
        .put("km", km).put("notes", notes).put("created", created)

    companion object {
        fun fromJson(o: JSONObject) = Vehicle(
            o.optString("id"), o.optString("name"),
            runCatching { VehicleKind.valueOf(o.optString("kind")) }.getOrDefault(VehicleKind.AUTRE),
            o.optString("plate"), o.optInt("km"), o.optString("notes"), o.optLong("created"),
        )
    }
}

/** Contrôle d'une pièce : photos, constats, verdict. */
data class Check(
    val id: String = UUID.randomUUID().toString(),
    val vehicleId: String,
    val part: Part,
    val position: String = "",
    val date: Long = System.currentTimeMillis(),
    val km: Int = 0,
    val photos: List<String> = emptyList(),
    val verdict: Verdict = Verdict.INCONNU,
    val findings: List<String> = emptyList(),
    val advice: String = "",
    /** Réponse complète de l'IA (vide : pas d'analyse). */
    val aiText: String = "",
    val treadMm: Float? = null,
    /** Semaine et année de fabrication du pneu (code DOT). */
    val dotWeek: Int = 0,
    val dotYear: Int = 0,
    val note: String = "",
) {
    val label: String get() = part.label + if (position.isNotBlank()) " · $position" else ""

    fun toJson(): JSONObject = JSONObject().put("id", id).put("vehicle", vehicleId).put("part", part.name).put("position", position)
        .put("date", date).put("km", km).put("photos", JSONArray(photos)).put("verdict", verdict.name)
        .put("findings", JSONArray(findings)).put("advice", advice).put("ai", aiText)
        .put("tread", treadMm?.toDouble() ?: JSONObject.NULL).put("dotWeek", dotWeek).put("dotYear", dotYear).put("note", note)

    companion object {
        private fun strings(a: JSONArray?) = a?.let { (0 until it.length()).map { i -> it.optString(i) } }.orEmpty()
        fun fromJson(o: JSONObject) = Check(
            o.optString("id"), o.optString("vehicle"),
            runCatching { Part.valueOf(o.optString("part")) }.getOrDefault(Part.AUTRE),
            o.optString("position"), o.optLong("date"), o.optInt("km"), strings(o.optJSONArray("photos")),
            runCatching { Verdict.valueOf(o.optString("verdict")) }.getOrDefault(Verdict.INCONNU),
            strings(o.optJSONArray("findings")), o.optString("advice"), o.optString("ai"),
            if (o.isNull("tread")) null else o.optDouble("tread").toFloat().takeIf { !it.isNaN() },
            o.optInt("dotWeek"), o.optInt("dotYear"), o.optString("note"),
        )
    }
}

/** Véhicules et contrôles, gardés sur le téléphone (vehicles.json + photos dans vehicle_photos). */
class VehicleStore private constructor(ctx: Context) {
    private val file = File(ctx.filesDir, FILE)
    val photoDir: File = File(ctx.filesDir, PHOTOS).apply { mkdirs() }

    private val _vehicles = MutableStateFlow<List<Vehicle>>(emptyList())
    val vehicles: StateFlow<List<Vehicle>> = _vehicles
    private val _checks = MutableStateFlow<List<Check>>(emptyList())
    val checks: StateFlow<List<Check>> = _checks

    init { load() }

    fun load() {
        val o = runCatching { JSONObject(file.readText()) }.getOrNull()
        _vehicles.value = o?.optJSONArray("vehicles")?.let { a -> (0 until a.length()).map { Vehicle.fromJson(a.getJSONObject(it)) } }.orEmpty()
        _checks.value = o?.optJSONArray("checks")?.let { a -> (0 until a.length()).map { Check.fromJson(a.getJSONObject(it)) } }.orEmpty()
    }

    @Synchronized
    private fun persist() {
        val o = JSONObject()
            .put("vehicles", JSONArray().apply { _vehicles.value.forEach { put(it.toJson()) } })
            .put("checks", JSONArray().apply { _checks.value.forEach { put(it.toJson()) } })
        val tmp = File(file.parentFile, "$FILE.tmp")
        tmp.writeText(o.toString())
        tmp.renameTo(file)
    }

    fun upsert(v: Vehicle) {
        val l = _vehicles.value.toMutableList()
        val i = l.indexOfFirst { it.id == v.id }
        if (i >= 0) l[i] = v else l += v
        _vehicles.value = l
        persist()
    }

    fun upsert(c: Check) {
        val l = _checks.value.toMutableList()
        val i = l.indexOfFirst { it.id == c.id }
        if (i >= 0) l[i] = c else l += c
        _checks.value = l
        // Kilométrage du contrôle plus élevé : celui du véhicule suit
        _vehicles.value.firstOrNull { it.id == c.vehicleId }?.let { v -> if (c.km > v.km) { upsert(v.copy(km = c.km)); return } }
        persist()
    }

    /** Retire un véhicule et ses contrôles ; renvoie de quoi les remettre (« Annuler »). */
    fun removeVehicle(id: String): Pair<Vehicle, List<Check>>? {
        val v = _vehicles.value.firstOrNull { it.id == id } ?: return null
        val cs = _checks.value.filter { it.vehicleId == id }
        _vehicles.value = _vehicles.value.filterNot { it.id == id }
        _checks.value = _checks.value.filterNot { it.vehicleId == id }
        persist()
        return v to cs
    }

    fun restore(v: Vehicle, cs: List<Check>) {
        _vehicles.value = _vehicles.value.filterNot { it.id == v.id } + v
        _checks.value = _checks.value.filterNot { c -> cs.any { it.id == c.id } } + cs
        persist()
    }

    fun removeCheck(id: String): Check? {
        val c = _checks.value.firstOrNull { it.id == id } ?: return null
        _checks.value = _checks.value.filterNot { it.id == id }
        persist()
        return c
    }

    fun restoreCheck(c: Check) = upsert(c)

    /** Efface pour de bon les photos qui ne servent plus. */
    fun dropPhotos(names: List<String>) {
        val used = _checks.value.flatMap { it.photos }.toSet()
        names.filter { it !in used }.forEach { runCatching { File(photoDir, it).delete() } }
    }

    fun photo(name: String) = File(photoDir, name)

    /** Dernier contrôle de chaque pièce (et position) d'un véhicule. */
    fun latest(vehicleId: String): List<Check> =
        _checks.value.filter { it.vehicleId == vehicleId }.groupBy { it.part to it.position }.map { (_, l) -> l.maxBy { it.date } }

    companion object {
        const val FILE = "vehicles.json"
        const val PHOTOS = "vehicle_photos"
        @Volatile private var instance: VehicleStore? = null
        fun get(ctx: Context): VehicleStore = instance ?: synchronized(this) { instance ?: VehicleStore(ctx.applicationContext).also { instance = it } }
    }
}
