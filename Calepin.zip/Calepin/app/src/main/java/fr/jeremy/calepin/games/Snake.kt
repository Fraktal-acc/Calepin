package fr.jeremy.calepin.games

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowLeft
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import kotlin.math.abs
import kotlin.random.Random

private class SnakeState {
    val n = 18
    val body = ArrayDeque<Pair<Int, Int>>()
    private var dx = 1
    private var dy = 0
    private val turns = ArrayDeque<Pair<Int, Int>>()
    var food = 0 to 0
    var score by mutableIntStateOf(0)
    var over by mutableStateOf(false)
    var frame by mutableIntStateOf(0)
    private var acc = 0f

    fun reset() {
        body.clear()
        val mid = n / 2
        body.addAll(listOf(mid to mid, mid - 1 to mid, mid - 2 to mid))
        dx = 1; dy = 0
        turns.clear()
        score = 0; acc = 0f; over = false
        placeFood()
        frame++
    }

    /** Partie en cours, pour la reprendre plus tard. */
    fun save(): String = org.json.JSONObject()
        .put("body", org.json.JSONArray(body.flatMap { listOf(it.first, it.second) }))
        .put("dx", dx).put("dy", dy).put("fx", food.first).put("fy", food.second).put("score", score)
        .toString()

    fun restore(text: String?): Boolean = runCatching {
        val o = org.json.JSONObject(text ?: return false)
        val b = o.getJSONArray("body")
        if (b.length() < 2) return false
        body.clear()
        for (i in 0 until b.length() / 2) body.addLast(b.getInt(2 * i) to b.getInt(2 * i + 1))
        dx = o.getInt("dx"); dy = o.getInt("dy")
        food = o.getInt("fx") to o.getInt("fy")
        score = o.getInt("score")
        turns.clear(); acc = 0f; over = false; frame++
        true
    }.getOrDefault(false)

    /** Accélère peu à peu avec le score. */
    private fun interval() = (160 - score * 3).coerceAtLeast(70).toFloat()

    fun update(dtMs: Float) {
        if (over) return
        acc += dtMs
        while (acc >= interval() && !over) {
            acc -= interval()
            step()
        }
    }

    fun turn(x: Int, y: Int) {
        val last = turns.lastOrNull() ?: (dx to dy)
        if ((x == -last.first && y == -last.second) || (x == last.first && y == last.second)) return
        if (turns.size < 2) turns.addLast(x to y)
    }

    private fun step() {
        turns.removeFirstOrNull()?.let { (x, y) -> dx = x; dy = y }
        val (hx, hy) = body.first()
        val next = (hx + dx) to (hy + dy)
        val eating = next == food
        val hitsWall = next.first !in 0 until n || next.second !in 0 until n
        val blocking = if (eating) body else body.dropLast(1)
        if (hitsWall || next in blocking) { over = true; frame++; return }
        body.addFirst(next)
        if (eating) { score++; placeFood() } else body.removeLast()
        frame++
    }

    private fun placeFood() {
        val free = (0 until n * n).map { (it % n) to (it / n) }.filter { it !in body }
        if (free.isEmpty()) { over = true; return }
        food = free[Random.nextInt(free.size)]
    }
}

@Composable
internal fun SnakeGame() {
    val ctx = LocalContext.current
    val g = remember { SnakeState().apply { if (!restore(GameSaves.load(ctx, "snake"))) reset() } }
    var paused by remember { mutableStateOf(true) }
    SaveOnLeave("snake", onPause = { paused = true }) { if (g.over) null else g.save() }
    var best by remember { mutableIntStateOf(GameScores.best(ctx, "snake")) }
    var record by remember { mutableStateOf(false) }

    GameLoop(running = !paused && !g.over) { g.update(it) }
    LaunchedEffect(g.over) {
        if (g.over) {
            record = GameScores.submit(ctx, "snake", g.score)
            if (record) best = g.score
        }
    }

    fun tap() {
        when {
            g.over -> { g.reset(); record = false; paused = false }
            else -> paused = !paused
        }
    }

    fun dir(x: Int, y: Int) {
        if (g.over) return
        if (paused) paused = false
        g.turn(x, y)
    }

    Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally) {
        ScoreBar(g.score, best)
        Box(
            Modifier
                .weight(1f)
                .fillMaxWidth(),
            contentAlignment = Alignment.Center,
        ) {
            Box(
                Modifier
                    .aspectRatio(1f, matchHeightConstraintsFirst = true)
                    .pointerInput(Unit) { detectTapGestures { tap() } }
                    .pointerInput(Unit) {
                        var drag = Offset.Zero
                        detectDragGestures(onDragStart = { drag = Offset.Zero }) { change, amount ->
                            change.consume()
                            drag += amount
                            val limit = 36f
                            if (abs(drag.x) > limit || abs(drag.y) > limit) {
                                if (abs(drag.x) > abs(drag.y)) dir(if (drag.x > 0) 1 else -1, 0)
                                else dir(0, if (drag.y > 0) 1 else -1)
                                drag = Offset.Zero
                            }
                        }
                    },
            ) {
                Canvas(Modifier.fillMaxSize()) {
                    g.frame // redessine à chaque pas
                    val c = size.width / g.n
                    drawRoundRect(BoardBackground, cornerRadius = CornerRadius(c * 0.6f))
                    for (i in 0 until g.n) for (j in 0 until g.n) {
                        if ((i + j) % 2 == 0) drawRect(GridLine, Offset(i * c, j * c), Size(c, c))
                    }
                    val (fx, fy) = g.food
                    drawCircle(Color(0xFFEF5350), radius = c * 0.38f, center = Offset((fx + 0.5f) * c, (fy + 0.5f) * c))
                    g.body.forEachIndexed { k, (x, y) ->
                        val color = if (k == 0) Color(0xFF9CCC65) else Color(0xFF66BB6A)
                        drawRoundRect(
                            color, Offset(x * c + c * 0.06f, y * c + c * 0.06f), Size(c * 0.88f, c * 0.88f),
                            CornerRadius(c * 0.28f),
                        )
                    }
                }
                when {
                    g.over -> Overlay(
                        if (record) "Nouveau record : ${g.score} !" else "Partie terminée",
                        "Touchez pour rejouer",
                    )
                    paused -> Overlay(
                        if (g.score == 0) "Snake" else "Pause",
                        "Glissez le doigt ou utilisez les flèches.\nTouchez pour jouer.",
                    )
                }
            }
        }
        Spacer(Modifier.size(8.dp))
        // Croix directionnelle
        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(6.dp)) {
            PadButton(Icons.Filled.KeyboardArrowUp, "Haut") { dir(0, -1) }
            Row(horizontalArrangement = Arrangement.spacedBy(70.dp)) {
                PadButton(Icons.AutoMirrored.Filled.KeyboardArrowLeft, "Gauche") { dir(-1, 0) }
                PadButton(Icons.AutoMirrored.Filled.KeyboardArrowRight, "Droite") { dir(1, 0) }
            }
            PadButton(Icons.Filled.KeyboardArrowDown, "Bas") { dir(0, 1) }
        }
    }
}
