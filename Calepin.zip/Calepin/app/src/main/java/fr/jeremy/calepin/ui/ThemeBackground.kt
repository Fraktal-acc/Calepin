package fr.jeremy.calepin.ui

import android.graphics.Matrix
import android.graphics.SurfaceTexture
import android.media.MediaPlayer
import android.os.Build
import android.view.Surface
import android.view.TextureView
import android.widget.ImageView
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.ColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import java.io.File
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sin

/** Dossier des fonds personnels (photos, images animées, vidéos). */
fun wallpaperDir(ctx: android.content.Context) = File(ctx.filesDir, "wallpaper").apply { mkdirs() }

private val VIDEO_EXT = setOf("mp4", "webm", "3gp", "mkv", "mov")

/** Fond de toute l'appli : couleur du thème, puis photo / vidéo personnelle ou décor (animé ou non). */
@Composable
fun ThemeBackground(look: Look, cs: ColorScheme) {
    val ctx = LocalContext.current
    val a = remember { Appearance.get(ctx) }
    val wall by a.wallpaper.collectAsStateWithLifecycle()
    val dim by a.wallDim.collectAsStateWithLifecycle()
    val scope by a.wallScope.collectAsStateWithLifecycle()
    val onHome by a.onHome.collectAsStateWithLifecycle()
    val file = remember(wall) { if (wall.isBlank()) null else File(wallpaperDir(ctx), wall).takeIf { it.exists() } }
    val showWall = file != null && (scope == WallScope.ALL || onHome)

    Box(Modifier.fillMaxSize().background(look.bg)) {
        if (showWall && file != null) {
            if (file.extension.lowercase() in VIDEO_EXT) WallVideo(file) else WallImage(file)
            Box(Modifier.fillMaxSize().background(look.bg.copy(alpha = dim)))
        } else if (look.deco != Deco.NONE) {
            DecoCanvas(look, cs)
        }
    }
}

@Composable
private fun DecoCanvas(look: Look, cs: ColorScheme) {
    var t by remember { mutableFloatStateOf(0f) }
    if (look.animate) {
        LaunchedEffect(look.deco) {
            val start = withFrameNanos { it }
            while (true) withFrameNanos { now -> t = (now - start) / 1_000_000_000f }
        }
    }
    Canvas(Modifier.fillMaxSize()) {
        DecoTint.set(look.decoColors)
        drawDeco(look.deco, cs, look.bg, t)
    }
}

// ------------------------------------------------------------------------ Photo, image animée, vidéo

@Composable
private fun WallImage(file: File) {
    AndroidView(
        factory = { c -> ImageView(c).apply { scaleType = ImageView.ScaleType.CENTER_CROP } },
        update = { iv ->
            if (iv.tag == file.path) return@AndroidView
            iv.tag = file.path
            val dm = iv.context.resources.displayMetrics
            val drawable = runCatching {
                if (Build.VERSION.SDK_INT >= 28) {
                    val src = android.graphics.ImageDecoder.createSource(file)
                    android.graphics.ImageDecoder.decodeDrawable(src) { dec, info, _ ->
                        // Taille réduite à celle de l'écran pour ménager la mémoire
                        val scale = max(info.size.width / dm.widthPixels.toFloat(), info.size.height / dm.heightPixels.toFloat())
                        if (scale > 1.5f) dec.setTargetSize((info.size.width / scale * 1.2f).toInt(), (info.size.height / scale * 1.2f).toInt())
                    }
                } else {
                    val o = android.graphics.BitmapFactory.Options().apply { inJustDecodeBounds = true }
                    android.graphics.BitmapFactory.decodeFile(file.path, o)
                    var sample = 1
                    while (o.outWidth / (sample * 2) >= dm.widthPixels && o.outHeight / (sample * 2) >= dm.heightPixels) sample *= 2
                    val bmp = android.graphics.BitmapFactory.decodeFile(file.path, android.graphics.BitmapFactory.Options().apply { inSampleSize = sample })
                    android.graphics.drawable.BitmapDrawable(iv.resources, bmp)
                }
            }.getOrNull()
            iv.setImageDrawable(drawable)
            if (Build.VERSION.SDK_INT >= 28) (drawable as? android.graphics.drawable.AnimatedImageDrawable)?.apply { repeatCount = android.graphics.drawable.AnimatedImageDrawable.REPEAT_INFINITE; start() }
        },
        modifier = Modifier.fillMaxSize(),
    )
}

/** Vidéo en boucle, sans le son, recadrée pour remplir l'écran. */
@Composable
private fun WallVideo(file: File) {
    val player = remember(file.path) { MediaPlayer() }
    DisposableEffect(file.path) { onDispose { runCatching { player.release() } } }
    AndroidView(
        factory = { c ->
            TextureView(c).apply {
                surfaceTextureListener = object : TextureView.SurfaceTextureListener {
                    override fun onSurfaceTextureAvailable(st: SurfaceTexture, w: Int, h: Int) {
                        runCatching {
                            player.setDataSource(file.path)
                            player.setSurface(Surface(st))
                            player.isLooping = true
                            player.setVolume(0f, 0f)
                            player.setOnVideoSizeChangedListener { _, vw, vh -> crop(this@apply, vw, vh) }
                            player.setOnPreparedListener { it.start() }
                            player.prepareAsync()
                        }
                    }
                    override fun onSurfaceTextureSizeChanged(st: SurfaceTexture, w: Int, h: Int) = crop(this@apply, player.videoWidth, player.videoHeight)
                    override fun onSurfaceTextureDestroyed(st: SurfaceTexture): Boolean { runCatching { player.pause() }; return true }
                    override fun onSurfaceTextureUpdated(st: SurfaceTexture) {}
                }
            }
        },
        modifier = Modifier.fillMaxSize(),
    )
}

private fun crop(v: TextureView, vw: Int, vh: Int) {
    if (vw <= 0 || vh <= 0 || v.width == 0 || v.height == 0) return
    val sx = v.width.toFloat() / vw
    val sy = v.height.toFloat() / vh
    val s = max(sx, sy)
    val m = Matrix()
    // La TextureView étire la vidéo à sa taille : on corrige pour garder les proportions et remplir
    m.setScale(vw * s / v.width, vh * s / v.height, v.width / 2f, v.height / 2f)
    v.setTransform(m)
}

// ------------------------------------------------------------------------ Décors

/** Hasard reproductible : la même particule garde ses caractéristiques d'une image à l'autre. */
private fun h(i: Int, k: Int): Float {
    var x = i * 374761393 + k * 668265263
    x = (x xor (x ushr 13)) * 1274126177
    return ((x xor (x ushr 16)) and 0xFFFFFF) / 16777215f
}

private fun wrap(v: Float, m: Float) = ((v % m) + m) % m

/**
 * Fond animé : paysages et décors culturels à part ; pour les autres, une lumière d'ambiance qui respire
 * derrière le décor et un léger vignettage autour, pour donner de la profondeur.
 */
fun DrawScope.drawDeco(deco: Deco, cs0: ColorScheme, bg: Color, t: Float) {
    if (deco in LANDSCAPE_DECOS) {
        DecoTint.landscape = true
        try { drawLandscape(deco, t) } finally { DecoTint.landscape = false }
        return
    }
    // Couleurs choisies pour ce décor : elles remplacent les trois couleurs du thème
    val cs = cs0.copy(
        primary = DecoTint.exact(0, cs0.primary),
        secondary = DecoTint.exact(1, cs0.secondary),
        tertiary = DecoTint.exact(2, cs0.tertiary),
    )
    val dark = (bg.red + bg.green + bg.blue) / 3f < 0.5f
    if (deco.animated && dark) ambient(cs, t)
    if (deco in CULTURE_DECOS) drawCulture(deco, cs, bg, t) else drawDecoBase(deco, cs, bg, t)
    if (deco.animated && dark) {
        drawRect(Brush.radialGradient(listOf(Color.Transparent, Color.Black.copy(alpha = 0.35f)), center = center, radius = size.maxDimension * 0.75f))
    }
}

/** Deux lueurs aux couleurs du thème qui dérivent très lentement. */
private fun DrawScope.ambient(cs: ColorScheme, t: Float) {
    val w = size.width
    val hgt = size.height
    val a = Offset(w * (0.25f + 0.15f * sin(t * 0.05f)), hgt * (0.3f + 0.1f * cos(t * 0.04f)))
    val b = Offset(w * (0.75f + 0.15f * cos(t * 0.045f)), hgt * (0.75f + 0.1f * sin(t * 0.035f)))
    drawRect(Brush.radialGradient(listOf(cs.primary.copy(alpha = 0.07f + 0.02f * sin(t * 0.3f)), Color.Transparent), center = a, radius = w * 0.9f))
    drawRect(Brush.radialGradient(listOf(cs.tertiary.copy(alpha = 0.06f + 0.02f * cos(t * 0.25f)), Color.Transparent), center = b, radius = w * 0.8f))
}

private fun DrawScope.drawDecoBase(deco: Deco, cs: ColorScheme, bg: Color, t: Float) {
    val w = size.width
    val hgt = size.height
    val dp = 1.dp.toPx()
    when (deco) {
        Deco.NONE -> Unit

        Deco.PAPER -> {
            var y = 120 * dp
            while (y < hgt) { drawLine(cs.primary.copy(alpha = 0.07f), Offset(0f, y), Offset(w, y), dp); y += 30 * dp }
            drawLine(DecoTint.exact(3, Color(0xFFB03030)).copy(alpha = 0.18f), Offset(10 * dp, 0f), Offset(10 * dp, hgt), dp)
        }

        Deco.NEON -> {
            drawRect(Brush.radialGradient(listOf(cs.secondary.copy(alpha = 0.16f), Color.Transparent), center = Offset(w * 0.9f, hgt * 0.05f), radius = w * 0.8f))
            drawRect(Brush.radialGradient(listOf(cs.primary.copy(alpha = 0.14f), Color.Transparent), center = Offset(0f, hgt * 0.55f), radius = w * 0.9f))
            stars(60, cs.secondary, t, 0.62f)
            grid(cs.primary.copy(alpha = 0.24f), hgt * 0.66f, t)
        }

        Deco.SUNSET -> {
            val horizon = hgt * 0.62f
            drawRect(Brush.verticalGradient(listOf(Color.Transparent, cs.primary.copy(alpha = 0.2f)), startY = 0f, endY = horizon))
            stars(50, DecoTint.exact(3, Color.White), t, 0.5f)
            val r = w * 0.32f
            val c = Offset(w * 0.5f, horizon - r * 0.35f)
            drawCircle(Brush.verticalGradient(listOf(cs.secondary.copy(alpha = 0.6f), cs.primary.copy(alpha = 0.5f)), startY = c.y - r, endY = c.y + r), r, c)
            var y = c.y + r * 0.05f
            var band = r * 0.05f
            // Les bandes du soleil défilent lentement vers le bas
            val shift = wrap(t * 6 * dp, band * 3.2f)
            y += shift
            while (y < c.y + r) { drawRect(bg, Offset(c.x - r, y), Size(2 * r, band)); y += band * 3.2f; band *= 1.3f }
            drawRect(bg, Offset(0f, horizon), Size(w, hgt - horizon))
            grid(cs.primary.copy(alpha = 0.38f), horizon, t)
        }

        Deco.GRIMOIRE -> {
            drawRect(Brush.radialGradient(listOf(cs.primary.copy(alpha = 0.16f), Color.Transparent), center = Offset(w * 0.5f, hgt * 0.18f), radius = w))
            drawRect(Brush.radialGradient(listOf(Color.Transparent, Color.Black.copy(alpha = 0.55f)), center = center, radius = size.maxDimension * 0.75f))
            val gold = DecoTint.exact(3, Color(0xFFD4AF37)).copy(alpha = 0.35f)
            val m = 18 * dp
            drawLine(gold, Offset(m, m), Offset(w - m, m), dp)
            drawLine(gold, Offset(m, m + 4 * dp), Offset(w - m, m + 4 * dp), 0.5f * dp)
            drawCircle(gold, 3 * dp, Offset(w / 2, m + 2 * dp))
            embers(45, listOf(cs.secondary, cs.primary, Color(0xFFFFA040)), t, 26f)
        }

        Deco.TERMINAL -> {
            drawRect(Brush.radialGradient(listOf(cs.primary.copy(alpha = 0.08f), Color.Transparent), center = center, radius = size.maxDimension * 0.7f))
            // Pluie de code
            val col = 16 * dp
            val cell = 14 * dp
            var i = 0
            var x = 4 * dp
            while (x < w) {
                if (h(i, 9) < 0.55f) {
                    val speed = (70 + h(i, 3) * 140) * dp
                    val head = wrap(h(i, 4) * hgt * 2 + t * speed, hgt * 1.6f) - hgt * 0.3f
                    for (k in 0 until 14) {
                        val y = head - k * cell
                        if (y < -cell || y > hgt) continue
                        val alpha = (if (k == 0) 0.55f else 0.28f) * (1f - k / 14f)
                        val gw = (3 + (h(i * 31 + k, (t * 3).toInt()) * 5)) * dp
                        drawRect(cs.primary.copy(alpha = alpha), Offset(x, y), Size(gw, 9 * dp))
                    }
                }
                x += col; i++
            }
            var y = 0f
            while (y < hgt) { drawLine(cs.primary.copy(alpha = 0.045f), Offset(0f, y), Offset(w, y), dp); y += 4 * dp }
            val beam = wrap(t * 120 * dp, hgt + 200 * dp) - 100 * dp
            drawRect(Brush.verticalGradient(listOf(Color.Transparent, cs.primary.copy(alpha = 0.06f), Color.Transparent), startY = beam - 60 * dp, endY = beam + 60 * dp))
        }

        Deco.AURORA -> {
            drawRect(Brush.radialGradient(listOf(cs.primary.copy(alpha = 0.24f), Color.Transparent), center = Offset(w * (0.2f + 0.15f * sin(t * 0.21f)), hgt * (0.1f + 0.05f * sin(t * 0.17f))), radius = w * 0.9f))
            drawRect(Brush.radialGradient(listOf(cs.secondary.copy(alpha = 0.2f), Color.Transparent), center = Offset(w * (0.8f + 0.12f * sin(t * 0.15f + 2)), hgt * (0.22f + 0.06f * cos(t * 0.13f))), radius = w * 0.85f))
            drawRect(Brush.radialGradient(listOf(cs.tertiary.copy(alpha = 0.16f), Color.Transparent), center = Offset(w * (0.5f + 0.2f * sin(t * 0.11f + 4)), hgt * 0.42f), radius = w))
            stars(70, DecoTint.exact(3, Color.White), t, 1f)
        }

        Deco.STARS -> {
            drawRect(Brush.radialGradient(listOf(cs.primary.copy(alpha = 0.12f), Color.Transparent), center = Offset(w * 0.15f, hgt * 0.25f), radius = w * 0.8f))
            drawRect(Brush.radialGradient(listOf(cs.secondary.copy(alpha = 0.10f), Color.Transparent), center = Offset(w * 0.9f, hgt * 0.75f), radius = w * 0.7f))
            // Voyage à travers les étoiles
            val c = center
            val maxR = size.maxDimension * 0.75f
            for (i in 0 until 140) {
                val ang = h(i, 1) * 2 * PI.toFloat()
                val z = wrap(h(i, 2) + t * 0.05f * (0.4f + h(i, 3)), 1f)
                val r = z.pow(2.2f) * maxR
                val p = Offset(c.x + cos(ang) * r, c.y + sin(ang) * r)
                val tail = Offset(c.x + cos(ang) * r * 0.92f, c.y + sin(ang) * r * 0.92f)
                val col = if (i % 11 == 0) cs.primary else DecoTint.exact(3, Color.White)
                drawLine(col.copy(alpha = min(1f, z * 1.4f) * 0.8f), tail, p, (0.6f + z * 2.2f) * dp, cap = StrokeCap.Round)
            }
            // Étoile filante de temps en temps
            run {
                val every = 6.5f
                val n = (t / every).toInt()
                val local = t % every
                if (local < 1f) {
                    val p = local
                    val sx = w * (0.1f + h(n, 21) * 0.6f)
                    val sy = hgt * (0.05f + h(n, 22) * 0.35f)
                    val len = w * 0.4f
                    val e = Offset(sx + len * p, sy + len * 0.4f * p)
                    val st = Offset(e.x - len * 0.25f, e.y - len * 0.1f)
                    drawLine(Brush.linearGradient(listOf(Color.Transparent, DecoTint.exact(3, Color.White).copy(alpha = 0.9f * sin(p * PI.toFloat()))), st, e), st, e, 1.6f * dp)
                }
            }
        }

        Deco.SNOW -> {
            drawRect(Brush.verticalGradient(listOf(cs.primary.copy(alpha = 0.10f), Color.Transparent, cs.secondary.copy(alpha = 0.10f))))
            // Trois plans de flocons (loin, milieu, près) et des rafales de vent
            val gust = sin(t * 0.23f) * sin(t * 0.07f) * 30 * dp
            for (layer in 0 until 3) {
                val n = listOf(70, 45, 18)[layer]
                val sizeK = listOf(0.8f, 1.6f, 3.0f)[layer]
                val speedK = listOf(0.6f, 1f, 1.7f)[layer]
                val alphaK = listOf(0.35f, 0.6f, 0.8f)[layer]
                for (i in 0 until n) {
                    val k = i + layer * 200
                    val speed = (18 + h(k, 4) * 30) * dp * speedK
                    val y = wrap(h(k, 2) * hgt + t * speed, hgt + 10 * dp) - 5 * dp
                    val x = wrap(h(k, 1) * w + sin(t * 0.7f + k) * 14 * dp + gust * speedK * (y / hgt), w)
                    drawCircle(DecoTint.exact(3, Color.White).copy(alpha = alphaK * (0.6f + h(k, 5) * 0.4f)), (0.8f + h(k, 6) * 1.6f) * dp * sizeK, Offset(x, y))
                }
            }
            // Neige qui s'accumule en bas
            drawRect(Brush.verticalGradient(listOf(Color.Transparent, DecoTint.exact(3, Color.White).copy(alpha = 0.12f)), startY = hgt * 0.85f, endY = hgt))
            embers(14, listOf(cs.secondary, Color(0xFFFFA040)), t, 22f)
        }

        Deco.FOG -> {
            for (i in 0 until 7) {
                val speed = (8 + h(i, 2) * 14) * dp
                val x = wrap(h(i, 1) * w * 1.6f + t * speed, w * 1.8f) - w * 0.4f
                val y = hgt * (0.25f + h(i, 3) * 0.7f)
                drawCircle(Brush.radialGradient(listOf(cs.primary.copy(alpha = 0.10f), Color.Transparent), center = Offset(x, y), radius = w * 0.55f), w * 0.55f, Offset(x, y))
            }
            drawRect(Brush.verticalGradient(listOf(Color.Transparent, Color(0xFF9AA58A).copy(alpha = 0.08f)), startY = hgt * 0.5f, endY = hgt))
            splatter(cs.secondary.copy(alpha = 0.22f), 9)
            drawRect(Brush.radialGradient(listOf(Color.Transparent, Color.Black.copy(alpha = 0.5f)), center = center, radius = size.maxDimension * 0.75f))
        }

        Deco.BLOOD -> {
            splatter(cs.primary.copy(alpha = 0.25f), 14)
            // Gouttes qui coulent du haut de l'écran
            for (i in 0 until 8) {
                val x = (0.06f + h(i, 1) * 0.88f) * w
                val period = 9f + h(i, 2) * 8f
                val ph = wrap(t + h(i, 3) * period, period) / period
                val len = (0.15f + h(i, 4) * 0.35f) * hgt * min(1f, ph * 1.4f)
                val alpha = 0.55f * (1f - max(0f, ph - 0.8f) * 5f)
                val wd = (2f + h(i, 5) * 3f) * dp
                drawLine(cs.primary.copy(alpha = alpha), Offset(x, 0f), Offset(x, len), wd, cap = StrokeCap.Round)
                drawCircle(cs.primary.copy(alpha = alpha), wd * 1.3f, Offset(x, len))
            }
        }

        Deco.RAIN, Deco.STORM -> {
            val flicker = 0.10f + 0.03f * sin(t * 9f) * sin(t * 2.3f)
            drawRect(Brush.radialGradient(listOf(cs.primary.copy(alpha = flicker), Color.Transparent), center = Offset(w * 0.75f, 0f), radius = w))
            val n = if (deco == Deco.STORM) 170 else 110
            for (i in 0 until n) {
                val speed = (650 + h(i, 4) * 300) * dp
                val y = wrap(h(i, 2) * hgt + t * speed, hgt + 30 * dp) - 15 * dp
                val x = wrap(h(i, 1) * w - y * 0.18f, w)
                drawLine(cs.secondary.copy(alpha = 0.18f + h(i, 5) * 0.15f), Offset(x, y), Offset(x - 2.5f * dp, y + 15 * dp), dp)
            }
            // Éclaboussures au sol
            for (i in 0 until 26) {
                val life = 0.6f
                val p = wrap(t + h(i, 7) * 5f, life) / life
                val x = h(i, 8) * w + (t / life).toInt() * 37 * dp % w
                val y = hgt * (0.82f + h(i, 9) * 0.16f)
                drawOval(cs.secondary.copy(alpha = 0.3f * (1f - p)), Offset(wrap(x, w) - 8 * dp * p, y - 2 * dp * p), Size(16 * dp * p, 4 * dp * p), style = Stroke(dp))
            }
            if (deco == Deco.STORM) {
                val cycle = 7f
                val k = (t / cycle).toInt()
                val local = t % cycle
                val flash = if (local > 6.2f) max(0f, 1f - (local - 6.2f) * 2.5f) * (0.6f + 0.4f * sin(local * 60f)) else 0f
                if (flash > 0f) {
                    drawRect(DecoTint.exact(3, Color.White).copy(alpha = 0.22f * flash))
                    val path = Path()
                    var px = w * (0.2f + h(k, 1) * 0.6f)
                    var py = 0f
                    path.moveTo(px, py)
                    var j = 0
                    while (py < hgt * 0.6f) { px += (h(k * 7 + j, 2) - 0.5f) * 60 * dp; py += (20 + h(k * 7 + j, 3) * 40) * dp; path.lineTo(px, py); j++ }
                    drawPath(path, DecoTint.exact(3, Color.White).copy(alpha = 0.9f * flash), style = Stroke(2.5f * dp))
                    drawPath(path, cs.primary.copy(alpha = 0.5f * flash), style = Stroke(9f * dp))
                }
            }
        }

        Deco.LEAVES, Deco.SAKURA -> {
            if (deco == Deco.LEAVES) drawRect(Brush.radialGradient(listOf(cs.primary.copy(alpha = 0.12f), Color.Transparent), center = Offset(w * 0.5f, hgt), radius = w))
            val colors = if (deco == Deco.SAKURA) listOf(Color(0xFFF7A8C4), Color(0xFFFFC9DA), Color(0xFFE884A8)).map { DecoTint.exact(3, it) } else listOf(cs.primary, cs.tertiary, DecoTint.exact(3, Color(0xFF8BC34A)))
            val n = if (deco == Deco.SAKURA) 36 else 24
            for (i in 0 until n) {
                val speed = (28 + h(i, 4) * 36) * dp
                val y = wrap(h(i, 2) * hgt + t * speed, hgt + 40 * dp) - 20 * dp
                val x = wrap(h(i, 1) * w + sin(t * 1.1f + i) * 28 * dp + t * 8 * dp, w)
                val s = (if (deco == Deco.SAKURA) 5f else 7f) * (0.7f + h(i, 5) * 0.6f) * dp
                rotate(t * 70f * (if (i % 2 == 0) 1 else -1) + i * 40f, Offset(x, y)) {
                    drawOval(colors[i % colors.size].copy(alpha = 0.55f), Offset(x - s, y - s * 0.45f), Size(2 * s, 0.9f * s))
                }
            }
        }

        Deco.ENERGY -> {
            val pulse = 1f + 0.12f * sin(t * 4f)
            val base = Offset(w / 2, hgt * 0.92f)
            drawCircle(Brush.radialGradient(listOf(cs.primary.copy(alpha = 0.30f), cs.secondary.copy(alpha = 0.10f), Color.Transparent), center = base, radius = w * 0.7f * pulse), w * 0.7f * pulse, base)
            // Lignes de vitesse qui tournent
            for (i in 0 until 28) {
                val ang = i / 28f * 2 * PI.toFloat() + t * 0.15f
                val r0 = size.maxDimension * (0.35f + h(i, 1) * 0.1f)
                val r1 = size.maxDimension * 0.9f
                drawLine(cs.primary.copy(alpha = 0.06f), Offset(center.x + cos(ang) * r0, center.y + sin(ang) * r0), Offset(center.x + cos(ang) * r1, center.y + sin(ang) * r1), (2 + h(i, 2) * 4) * dp)
            }
            // Flammes de l'aura
            for (i in 0 until 60) {
                val life = wrap(h(i, 2) + t * (0.35f + h(i, 3) * 0.5f), 1f)
                val spread = (h(i, 1) - 0.5f) * w * 0.8f * (1f - life * 0.5f)
                val x = base.x + spread + sin(t * 6 + i) * 6 * dp
                val y = base.y - life * hgt * 0.75f
                val col = if (i % 3 == 0) cs.secondary else cs.primary
                drawLine(col.copy(alpha = (1f - life) * 0.45f), Offset(x, y), Offset(x, y + (14 + h(i, 4) * 18) * dp), (2 + h(i, 5) * 3) * dp, cap = StrokeCap.Round)
            }
        }

        Deco.SHADOWS -> {
            val flicker = 0.10f + 0.04f * sin(t * 7.3f) * sin(t * 3.1f + 1)
            drawRect(Brush.radialGradient(listOf(DecoTint.exact(3, Color(0xFFFFC27A)).copy(alpha = flicker), Color.Transparent), center = Offset(w * 0.15f, hgt * 0.95f), radius = w * 0.9f))
            drawRect(Brush.radialGradient(listOf(cs.secondary.copy(alpha = 0.08f), Color.Transparent), center = Offset(w * 0.9f, hgt * 0.1f), radius = w * 0.7f))
            // Cendres qui tombent lentement
            for (i in 0 until 40) {
                val speed = (10 + h(i, 4) * 20) * dp
                val y = wrap(h(i, 2) * hgt + t * speed, hgt)
                val x = h(i, 1) * w + sin(t * 0.5f + i) * 20 * dp
                drawCircle(Color(0xFF9E9E9E).copy(alpha = 0.18f + h(i, 3) * 0.2f), (0.8f + h(i, 5) * 1.8f) * dp, Offset(x, y))
            }
            // Lignes d'écriture qui apparaissent et s'effacent
            for (i in 0 until 6) {
                val y = hgt * (0.2f + i * 0.12f)
                val a = max(0f, sin(t * 0.4f + i * 1.3f)) * 0.06f
                drawLine(cs.primary.copy(alpha = a), Offset(w * 0.1f, y), Offset(w * (0.5f + h(i, 7) * 0.4f), y), dp)
            }
            drawRect(Brush.radialGradient(listOf(Color.Transparent, Color.Black.copy(alpha = 0.6f)), center = center, radius = size.maxDimension * 0.7f))
        }

        Deco.FIREFLIES -> {
            drawRect(Brush.verticalGradient(listOf(Color.Transparent, cs.secondary.copy(alpha = 0.10f)), startY = hgt * 0.4f, endY = hgt))
            for (i in 0 until 34) {
                val x = w * (0.5f + 0.47f * sin(t * 0.09f * (1 + h(i, 1)) + 6.28f * h(i, 2)))
                val y = hgt * (0.5f + 0.47f * sin(t * 0.07f * (1 + h(i, 3)) + 6.28f * h(i, 4)))
                val glow = 0.5f + 0.5f * sin(t * (1.5f + h(i, 5) * 2) + i)
                drawCircle(Brush.radialGradient(listOf(cs.primary.copy(alpha = 0.55f * glow), Color.Transparent), center = Offset(x, y), radius = 14 * dp), 14 * dp, Offset(x, y))
                drawCircle(DecoTint.exact(3, Color(0xFFFFFDE0)).copy(alpha = 0.9f * glow), 1.6f * dp, Offset(x, y))
            }
        }

        Deco.WAVES -> {
            // Ciel qui s'éclaircit vers l'horizon, soleil voilé, vagues qui roulent
            drawRect(Brush.verticalGradient(listOf(cs.primary.copy(alpha = 0.10f), Color.Transparent), startY = 0f, endY = hgt * 0.55f))
            drawCircle(Brush.radialGradient(listOf(cs.secondary.copy(alpha = 0.35f), Color.Transparent), center = Offset(w * 0.78f, hgt * 0.22f), radius = w * 0.35f), w * 0.35f, Offset(w * 0.78f, hgt * 0.22f))
            for (layer in 0 until 5) {
                val baseY = hgt * (0.55f + layer * 0.09f)
                val amp = (10 + layer * 6) * dp
                val len = w * (0.55f + layer * 0.12f)
                val speed = (0.5f + layer * 0.25f) * (if (layer % 2 == 0) 1 else -1)
                val path = Path()
                path.moveTo(0f, hgt)
                var x = 0f
                while (x <= w + 8 * dp) {
                    val y = baseY + sin((x / len) * 2 * PI.toFloat() + t * speed) * amp + sin((x / len) * 5.3f + t * speed * 1.7f) * amp * 0.25f
                    path.lineTo(x, y)
                    x += 8 * dp
                }
                path.lineTo(w, hgt); path.close()
                drawPath(path, lerp2(cs.primary, cs.tertiary, layer / 4f).copy(alpha = 0.10f + layer * 0.035f))
            }
            // Reflets qui scintillent
            for (i in 0 until 30) {
                val x = h(i, 1) * w
                val y = hgt * (0.58f + h(i, 2) * 0.4f)
                val a = max(0f, sin(t * (1 + h(i, 3) * 2) + i)) * 0.35f
                drawLine(DecoTint.exact(3, Color.White).copy(alpha = a), Offset(x, y), Offset(x + (6 + h(i, 4) * 10) * dp, y), dp, cap = StrokeCap.Round)
            }
        }

        Deco.LAVA -> {
            drawRect(Brush.verticalGradient(listOf(Color.Transparent, cs.primary.copy(alpha = 0.16f)), startY = hgt * 0.3f, endY = hgt))
            // Grosses gouttes qui montent et redescendent lentement
            for (i in 0 until 9) {
                val period = 18f + h(i, 1) * 14f
                val ph = wrap(t / period + h(i, 2), 1f)
                val y = hgt * (1.05f - 1.1f * (0.5f - 0.5f * cos(ph * 2 * PI.toFloat())))
                val x = w * (0.12f + h(i, 3) * 0.76f) + sin(t * 0.3f + i) * 18 * dp
                val r = (34 + h(i, 4) * 46) * dp * (0.9f + 0.1f * sin(t * 0.8f + i))
                val col = if (i % 3 == 0) cs.secondary else if (i % 3 == 1) cs.primary else cs.tertiary
                drawCircle(Brush.radialGradient(listOf(col.copy(alpha = 0.55f), col.copy(alpha = 0.18f), Color.Transparent), center = Offset(x, y), radius = r * 1.4f), r * 1.4f, Offset(x, y))
            }
        }

        Deco.BOKEH -> {
            drawRect(Brush.verticalGradient(listOf(Color.Transparent, cs.primary.copy(alpha = 0.08f))))
            val cols = listOf(cs.primary, cs.secondary, cs.tertiary, DecoTint.exact(3, Color.White))
            for (i in 0 until 38) {
                val speed = (4 + h(i, 4) * 10) * dp
                val x = wrap(h(i, 1) * w + t * speed, w + 80 * dp) - 40 * dp
                val y = hgt * (0.15f + h(i, 2) * 0.8f) + sin(t * 0.3f + i) * 10 * dp
                val r = (10 + h(i, 3) * 34) * dp
                val a = (0.10f + h(i, 5) * 0.16f) * (0.7f + 0.3f * sin(t * (0.5f + h(i, 6)) + i))
                val c = cols[i % cols.size]
                drawCircle(c.copy(alpha = a), r, Offset(x, y))
                drawCircle(c.copy(alpha = a * 1.4f), r, Offset(x, y), style = Stroke(dp))
            }
        }

        Deco.CONFETTI -> {
            val cols = listOf(cs.primary, cs.secondary, cs.tertiary, DecoTint.exact(3, Color(0xFFFFC107)), Color(0xFF4CAF50))
            for (i in 0 until 70) {
                val speed = (40 + h(i, 4) * 60) * dp
                val y = wrap(h(i, 2) * hgt + t * speed, hgt + 30 * dp) - 15 * dp
                val x = wrap(h(i, 1) * w + sin(t * 1.4f + i) * 18 * dp, w)
                val s = (3 + h(i, 5) * 4) * dp
                val flip = abs(sin(t * (2 + h(i, 6) * 4) + i))
                rotate(t * 90f * (if (i % 2 == 0) 1 else -1) + i * 37f, Offset(x, y)) {
                    drawRect(cols[i % cols.size].copy(alpha = 0.7f), Offset(x - s, y - s * flip * 0.5f), Size(2 * s, s * flip + 0.5f * dp))
                }
            }
        }

        Deco.DUNES -> {
            // Soleil bas, dunes, sable qui vole
            val sun = Offset(w * 0.3f, hgt * 0.42f)
            drawCircle(Brush.radialGradient(listOf(cs.secondary.copy(alpha = 0.55f), cs.primary.copy(alpha = 0.15f), Color.Transparent), center = sun, radius = w * 0.45f), w * 0.45f, sun)
            for (layer in 0 until 3) {
                val baseY = hgt * (0.6f + layer * 0.12f)
                val path = Path()
                path.moveTo(0f, hgt)
                var x = 0f
                while (x <= w + 10 * dp) {
                    val y = baseY + sin(x / w * (2.2f + layer) * PI.toFloat() + layer * 1.7f) * (22 + layer * 10) * dp
                    path.lineTo(x, y); x += 10 * dp
                }
                path.lineTo(w, hgt); path.close()
                drawPath(path, lerp2(cs.primary, Color.Black, 0.3f + layer * 0.2f).copy(alpha = 0.35f + layer * 0.15f))
            }
            for (i in 0 until 70) {
                val speed = (90 + h(i, 4) * 160) * dp
                val x = wrap(h(i, 1) * w + t * speed, w + 20 * dp) - 10 * dp
                val y = hgt * (0.5f + h(i, 2) * 0.5f) + sin(t * 2 + i) * 4 * dp
                drawLine(cs.primary.copy(alpha = 0.18f + h(i, 3) * 0.2f), Offset(x, y), Offset(x - (4 + h(i, 5) * 10) * dp, y), dp)
            }
        }

        Deco.NEBULA -> {
            // Nuages colorés qui tournent lentement autour du centre
            for (i in 0 until 6) {
                val ang = t * 0.04f * (if (i % 2 == 0) 1 else -1) + i * 1.05f
                val r = size.minDimension * (0.18f + h(i, 1) * 0.25f)
                val c = Offset(center.x + cos(ang) * r, center.y * (0.8f + h(i, 2) * 0.4f) + sin(ang) * r)
                val col = listOf(cs.primary, cs.secondary, cs.tertiary)[i % 3]
                drawCircle(Brush.radialGradient(listOf(col.copy(alpha = 0.22f), Color.Transparent), center = c, radius = w * 0.6f), w * 0.6f, c)
            }
            stars(110, DecoTint.exact(3, Color.White), t, 1f)
            // Quelques étoiles plus brillantes, en croix
            for (i in 0 until 6) {
                val p = Offset(h(i, 11) * w, h(i, 12) * hgt)
                val a = 0.4f + 0.4f * sin(t * 1.3f + i)
                val l = (6 + h(i, 13) * 8) * dp
                drawLine(DecoTint.exact(3, Color.White).copy(alpha = a), Offset(p.x - l, p.y), Offset(p.x + l, p.y), dp)
                drawLine(DecoTint.exact(3, Color.White).copy(alpha = a), Offset(p.x, p.y - l), Offset(p.x, p.y + l), dp)
            }
        }

        Deco.FLAMES -> {
            drawRect(Brush.verticalGradient(listOf(Color.Transparent, cs.primary.copy(alpha = 0.22f), cs.secondary.copy(alpha = 0.18f)), startY = hgt * 0.45f, endY = hgt))
            // Langues de feu au bas de l'écran
            for (i in 0 until 26) {
                val x = (i + 0.5f) / 26f * w
                val fl = 0.6f + 0.4f * sin(t * (3 + h(i, 1) * 3) + i * 1.7f) * sin(t * 1.3f + i)
                val hh = hgt * (0.12f + h(i, 2) * 0.14f) * fl
                val wd = w / 26f * 1.6f
                val path = Path()
                path.moveTo(x - wd / 2, hgt)
                path.quadraticBezierTo(x - wd * 0.6f, hgt - hh * 0.5f, x + sin(t * 2 + i) * 6 * dp, hgt - hh)
                path.quadraticBezierTo(x + wd * 0.6f, hgt - hh * 0.5f, x + wd / 2, hgt)
                path.close()
                drawPath(path, (if (i % 2 == 0) cs.primary else cs.secondary).copy(alpha = 0.32f))
            }
            embers(55, listOf(cs.secondary, cs.primary, DecoTint.exact(3, Color(0xFFFFE082))), t, 60f)
        }

        Deco.HEARTS -> {
            val cols = listOf(cs.primary, cs.tertiary, cs.secondary)
            for (i in 0 until 26) {
                val speed = (18 + h(i, 4) * 30) * dp
                val y = hgt - wrap(h(i, 2) * hgt + t * speed, hgt + 40 * dp) + 20 * dp
                val x = h(i, 1) * w + sin(t * 0.8f + i) * 16 * dp
                val s = (5 + h(i, 5) * 8) * dp
                heart(Offset(x, y), s, cols[i % cols.size].copy(alpha = 0.22f + h(i, 6) * 0.2f))
            }
        }

        Deco.CIRCUIT -> {
            drawRect(Brush.radialGradient(listOf(cs.primary.copy(alpha = 0.10f), Color.Transparent), center = center, radius = size.maxDimension * 0.7f))
            // Pistes à angles droits, et impulsions qui les parcourent
            val step = 36 * dp
            for (i in 0 until 22) {
                var x = (h(i, 1) * (w / step)).toInt() * step
                var y = (h(i, 2) * (hgt / step)).toInt() * step
                val pts = mutableListOf(Offset(x, y))
                for (k in 0 until 4) {
                    if ((h(i * 7 + k, 3) < 0.5f)) x += (if (h(i * 7 + k, 4) < 0.5f) -1 else 1) * step * (1 + (h(i * 7 + k, 5) * 3).toInt())
                    else y += (if (h(i * 7 + k, 6) < 0.5f) -1 else 1) * step * (1 + (h(i * 7 + k, 8) * 3).toInt())
                    pts += Offset(x, y)
                }
                val col = if (i % 4 == 0) cs.secondary else cs.primary
                for (k in 0 until pts.size - 1) drawLine(col.copy(alpha = 0.16f), pts[k], pts[k + 1], 1.5f * dp)
                drawCircle(col.copy(alpha = 0.3f), 3 * dp, pts.first())
                drawCircle(col.copy(alpha = 0.3f), 3 * dp, pts.last(), style = Stroke(dp))
                // Impulsion
                val ph = wrap(t * (0.15f + h(i, 9) * 0.25f) + h(i, 10), 1f) * (pts.size - 1)
                val seg = ph.toInt().coerceAtMost(pts.size - 2)
                val f = ph - seg
                val p = Offset(pts[seg].x + (pts[seg + 1].x - pts[seg].x) * f, pts[seg].y + (pts[seg + 1].y - pts[seg].y) * f)
                drawCircle(Brush.radialGradient(listOf(col.copy(alpha = 0.8f), Color.Transparent), center = p, radius = 8 * dp), 8 * dp, p)
            }
        }

        Deco.GEARS -> {
            drawRect(Brush.radialGradient(listOf(cs.primary.copy(alpha = 0.12f), Color.Transparent), center = Offset(w * 0.5f, hgt * 0.4f), radius = w))
            // Engrenages qui tournent (chaque roue dans un sens)
            val gears = listOf(
                Triple(Offset(w * 0.12f, hgt * 0.14f), 70f, 1f), Triple(Offset(w * 0.37f, hgt * 0.07f), 44f, -1.6f),
                Triple(Offset(w * 0.92f, hgt * 0.5f), 90f, 0.8f), Triple(Offset(w * 0.75f, hgt * 0.62f), 50f, -1.45f),
                Triple(Offset(w * 0.08f, hgt * 0.86f), 80f, 0.9f), Triple(Offset(w * 0.32f, hgt * 0.95f), 46f, -1.55f),
            )
            gears.forEachIndexed { i, (c, rDp, dir) ->
                val r = rDp * dp
                val col = (if (i % 2 == 0) cs.primary else cs.secondary).copy(alpha = 0.22f)
                rotate(t * 14f * dir, c) {
                    drawCircle(col, r * 0.82f, c, style = Stroke(r * 0.16f))
                    drawCircle(col, r * 0.22f, c, style = Stroke(r * 0.08f))
                    val teeth = (rDp / 7).toInt().coerceAtLeast(8)
                    for (k in 0 until teeth) {
                        val ang = k * 2 * PI.toFloat() / teeth
                        drawLine(col, Offset(c.x + cos(ang) * r * 0.85f, c.y + sin(ang) * r * 0.85f), Offset(c.x + cos(ang) * r * 1.05f, c.y + sin(ang) * r * 1.05f), r * 0.14f)
                    }
                    for (k in 0 until 4) {
                        val ang = k * PI.toFloat() / 2
                        drawLine(col, Offset(c.x + cos(ang) * r * 0.22f, c.y + sin(ang) * r * 0.22f), Offset(c.x + cos(ang) * r * 0.75f, c.y + sin(ang) * r * 0.75f), r * 0.07f)
                    }
                }
            }
            embers(20, listOf(cs.secondary, DecoTint.exact(3, Color(0xFFFFE0B2))), t, 18f)
        }

        Deco.BUBBLES -> {
            val lx = w * (0.5f + 0.3f * sin(t * 0.2f))
            drawRect(Brush.radialGradient(listOf(cs.primary.copy(alpha = 0.16f), Color.Transparent), center = Offset(lx, 0f), radius = w))
            for (i in 0 until 42) {
                val speed = (30 + h(i, 4) * 60) * dp
                val y = hgt - wrap(h(i, 2) * hgt + t * speed, hgt + 40 * dp) + 20 * dp
                val x = h(i, 1) * w + sin(t * 1.3f + i) * 10 * dp
                val r = (3 + h(i, 5) * 9) * dp
                drawCircle(DecoTint.exact(3, Color.White).copy(alpha = 0.22f), r, Offset(x, y), style = Stroke(dp))
                drawCircle(DecoTint.exact(3, Color.White).copy(alpha = 0.3f), r * 0.25f, Offset(x - r * 0.35f, y - r * 0.35f))
            }
        }

        Deco.SUNNY -> {
            // Soleil en haut à droite : halo, rayons qui tournent lentement, poussières de lumière
            val c = Offset(w * 0.82f, hgt * 0.09f)
            val sun = cs.secondary
            drawRect(Brush.radialGradient(listOf(sun.copy(alpha = 0.30f), Color.Transparent), center = c, radius = w * 0.95f))
            rotate(t * 5f, c) {
                for (k in 0 until 14) {
                    val a = k * 2 * PI.toFloat() / 14
                    val len = w * (0.34f + 0.07f * sin(t * 0.7f + k))
                    drawLine(
                        sun.copy(alpha = 0.12f),
                        Offset(c.x + cos(a) * w * 0.13f, c.y + sin(a) * w * 0.13f),
                        Offset(c.x + cos(a) * len, c.y + sin(a) * len),
                        (8 + 4 * sin(t + k)) * dp,
                    )
                }
            }
            drawCircle(sun.copy(alpha = 0.40f + 0.05f * sin(t * 1.5f)), w * 0.085f, c)
            for (i in 0 until 26) {
                val speed = (6 + h(i, 4) * 12) * dp
                val y = hgt - wrap(h(i, 2) * hgt + t * speed, hgt + 20 * dp) + 10 * dp
                val x = h(i, 1) * w + sin(t * 0.5f + i) * 14 * dp
                drawCircle(sun.copy(alpha = 0.10f + h(i, 5) * 0.14f), (1.5f + h(i, 3) * 3f) * dp, Offset(x, y))
            }
        }

        Deco.CLOUDS -> {
            // Nuages doux qui passent lentement (gris sur fond clair, blancs sur fond sombre)
            val light = (bg.red + bg.green + bg.blue) / 3f > 0.5f
            val col = DecoTint.exact(3, if (light) cs.onSurface.copy(alpha = 0.055f) else Color.White.copy(alpha = 0.06f))
            for (i in 0 until 8) {
                val speed = (5 + h(i, 4) * 9) * dp
                val cw = (110 + h(i, 3) * 150) * dp
                val x = wrap(h(i, 1) * (w + 2 * cw) + t * speed, w + 2 * cw) - cw
                val y = hgt * (0.04f + h(i, 2) * 0.9f)
                val r = cw * 0.22f
                drawRoundRect(col, Offset(x - cw / 2, y), Size(cw, r * 1.3f), androidx.compose.ui.geometry.CornerRadius(r * 0.65f))
                drawCircle(col, r, Offset(x - cw * 0.18f, y + r * 0.2f))
                drawCircle(col, r * 1.3f, Offset(x + cw * 0.08f, y - r * 0.05f))
                drawCircle(col, r * 0.9f, Offset(x + cw * 0.3f, y + r * 0.35f))
            }
        }

        else -> Unit
    }
}

/** Étoiles qui scintillent dans la partie haute ([upTo] : fraction de la hauteur). */
private fun DrawScope.stars(n: Int, color: Color, t: Float, upTo: Float) {
    for (i in 0 until n) {
        val tw = 0.35f + 0.65f * abs(sin(t * (0.6f + h(i, 3) * 1.6f) + i))
        drawCircle(color.copy(alpha = 0.5f * tw), (0.6f + h(i, 4) * 1.4f) * 1.dp.toPx(), Offset(h(i, 1) * size.width, h(i, 2) * size.height * upTo))
    }
}

/** Grille en perspective qui avance vers l'écran. */
private fun DrawScope.grid(color: Color, horizon: Float, t: Float) {
    val w = size.width
    val hgt = size.height
    val vx = w / 2
    val stroke = 1.dp.toPx()
    for (i in -10..10) drawLine(color, Offset(vx + i * w * 0.02f, horizon), Offset(vx + i * w * 0.22f, hgt), stroke)
    val n = 12
    val phase = wrap(t * 0.5f, 1f)
    for (k in 0 until n) {
        val z = (k + phase) / n
        val y = horizon + (hgt - horizon) * z.pow(2.2f)
        drawLine(color.copy(alpha = color.alpha * (0.3f + z)), Offset(0f, y), Offset(w, y), stroke)
    }
    drawLine(color.copy(alpha = min(1f, color.alpha * 2)), Offset(0f, horizon), Offset(w, horizon), stroke * 1.5f)
}

/** Braises qui montent en ondulant. */
private fun DrawScope.embers(n: Int, colors: List<Color>, t: Float, speedDp: Float) {
    val dp = 1.dp.toPx()
    for (i in 0 until n) {
        val speed = (speedDp * (0.6f + h(i, 4) * 0.9f)) * dp
        val travel = size.height * 1.1f
        val p = wrap(h(i, 2) * travel + t * speed, travel)
        val y = size.height - p
        val x = h(i, 1) * size.width + sin(t * 0.9f + i) * 14 * dp
        val alpha = (1f - p / travel) * 0.8f
        drawCircle(colors[i % colors.size].copy(alpha = alpha), (1.2f + h(i, 5) * 1.8f) * dp, Offset(x, y))
    }
}

/** Taches fixes (éclaboussures). */
private fun DrawScope.splatter(color: Color, n: Int) {
    for (i in 0 until n) {
        val corner = i % 3
        val cx = if (corner == 0) h(i, 1) * size.width * 0.35f else if (corner == 1) size.width - h(i, 1) * size.width * 0.35f else h(i, 1) * size.width
        val cy = if (corner == 2) size.height - h(i, 2) * size.height * 0.2f else h(i, 2) * size.height * 0.3f
        val r = (3 + h(i, 3) * 16) * 1.dp.toPx()
        drawCircle(color, r, Offset(cx, cy))
        for (k in 0 until 5) {
            val a = h(i * 5 + k, 4) * 6.28f
            val d = r * (1.3f + h(i * 5 + k, 5) * 1.6f)
            drawCircle(color, r * (0.12f + h(i * 5 + k, 6) * 0.2f), Offset(cx + cos(a) * d, cy + sin(a) * d))
        }
    }
}

/** Mélange de deux couleurs (évite un import en conflit avec les noms locaux). */
private fun lerp2(a: Color, b: Color, f: Float): Color = androidx.compose.ui.graphics.lerp(a, b, f)

/** Petit cœur centré en [c], de demi-largeur [s]. */
private fun DrawScope.heart(c: Offset, s: Float, color: Color) {
    val p = Path()
    p.moveTo(c.x, c.y + s * 0.9f)
    p.cubicTo(c.x - s * 1.4f, c.y - s * 0.1f, c.x - s * 0.7f, c.y - s * 1.2f, c.x, c.y - s * 0.4f)
    p.cubicTo(c.x + s * 0.7f, c.y - s * 1.2f, c.x + s * 1.4f, c.y - s * 0.1f, c.x, c.y + s * 0.9f)
    p.close()
    drawPath(p, color)
}
