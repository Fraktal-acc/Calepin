package fr.jeremy.calepin

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import java.security.MessageDigest
import java.security.SecureRandom

enum class DisplayMode(val label: String) {
    CARDS("Cartes"), COMPACT("Liste compacte"), GRID("Grille"), EXPAND("Liste dépliable")
}

enum class AudioFormat(val label: String, val ext: String) {
    M4A("M4A (AAC) · recommandé", "m4a"), MP3("MP3", "mp3")
}

/** Paramètres de l'appli, enregistrés sur le téléphone. */
class AppSettings(context: Context) {
    private val p = context.getSharedPreferences("calepin_settings", Context.MODE_PRIVATE)

    private val _display = MutableStateFlow(enumOr(p.getString("display", null), DisplayMode.CARDS))
    val display: StateFlow<DisplayMode> = _display
    fun setDisplay(m: DisplayMode) { p.edit().putString("display", m.name).apply(); _display.value = m }

    private val _audioFormat = MutableStateFlow(enumOr(p.getString("audio_format", null), AudioFormat.M4A))
    val audioFormat: StateFlow<AudioFormat> = _audioFormat
    fun setAudioFormat(f: AudioFormat) { p.edit().putString("audio_format", f.name).apply(); _audioFormat.value = f }

    private val _audioBitrate = MutableStateFlow(p.getInt("audio_bitrate", 128))
    val audioBitrate: StateFlow<Int> = _audioBitrate
    fun setAudioBitrate(k: Int) { p.edit().putInt("audio_bitrate", k).apply(); _audioBitrate.value = k }

    /** Sonnerie proposée par défaut pour les nouveaux rappels (vide = celle du téléphone). */
    private val _ringtone = MutableStateFlow(p.getString("ringtone", "") ?: "")
    val ringtone: StateFlow<String> = _ringtone
    fun setRingtone(u: String) { p.edit().putString("ringtone", u).apply(); _ringtone.value = u }

    // ------------------------------------------------------------ Sécurité

    private val _pinEnabled = MutableStateFlow(p.getString("pin_hash", null) != null)
    val pinEnabled: StateFlow<Boolean> = _pinEnabled

    private val _bioEnabled = MutableStateFlow(p.getBoolean("bio", false))
    val bioEnabled: StateFlow<Boolean> = _bioEnabled
    fun setBio(on: Boolean) { p.edit().putBoolean("bio", on).apply(); _bioEnabled.value = on }

    /** Délai avant re-verrouillage quand l'appli passe en arrière-plan (secondes). */
    private val _lockDelay = MutableStateFlow(p.getInt("lock_delay", 0))
    val lockDelay: StateFlow<Int> = _lockDelay
    fun setLockDelay(s: Int) { p.edit().putInt("lock_delay", s).apply(); _lockDelay.value = s }

    private val _hideInRecents = MutableStateFlow(p.getBoolean("hide_recents", false))
    val hideInRecents: StateFlow<Boolean> = _hideInRecents
    fun setHideInRecents(on: Boolean) { p.edit().putBoolean("hide_recents", on).apply(); _hideInRecents.value = on }

    val lockActive: Boolean get() = _pinEnabled.value || _bioEnabled.value

    fun setPin(pin: String) {
        val salt = ByteArray(16).also { SecureRandom().nextBytes(it) }
        val saltHex = salt.joinToString("") { "%02x".format(it) }
        p.edit().putString("pin_salt", saltHex).putString("pin_hash", hash(pin, saltHex)).apply()
        _pinEnabled.value = true
    }

    fun clearPin() {
        p.edit().remove("pin_hash").remove("pin_salt").apply()
        _pinEnabled.value = false
    }

    fun checkPin(pin: String): Boolean {
        val salt = p.getString("pin_salt", null) ?: return false
        return hash(pin, salt) == p.getString("pin_hash", null)
    }

    /** Anti-essais à répétition : après 5 erreurs, attente de 30 s. */
    var failedAttempts: Int
        get() = p.getInt("pin_fails", 0)
        set(v) { p.edit().putInt("pin_fails", v).apply() }
    var lockedUntil: Long
        get() = p.getLong("pin_locked_until", 0)
        set(v) { p.edit().putLong("pin_locked_until", v).apply() }

    private fun hash(pin: String, salt: String): String {
        var bytes = (salt + pin).toByteArray()
        val md = MessageDigest.getInstance("SHA-256")
        repeat(10_000) { bytes = md.digest(bytes) }
        return bytes.joinToString("") { "%02x".format(it) }
    }

    private inline fun <reified T : Enum<T>> enumOr(name: String?, default: T): T =
        name?.let { n -> enumValues<T>().firstOrNull { it.name == n } } ?: default
}
