package fr.jeremy.calepin.ui

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import fr.jeremy.calepin.NotesViewModel
import fr.jeremy.calepin.control.CommandRules
import fr.jeremy.calepin.control.CustomCommand
import fr.jeremy.calepin.control.CustomCommands
import fr.jeremy.calepin.i18n.I18n
import fr.jeremy.calepin.i18n.RawText
import fr.jeremy.calepin.i18n.Text
import fr.jeremy.calepin.ui.tools.ToolHint
import fr.jeremy.calepin.ui.tools.ToolScaffold
import kotlinx.coroutines.launch

/** Modèles proposés : de quoi démarrer en un geste (modifiables ensuite). */
private val TEMPLATES = listOf(
    CustomCommand(id = "", triggers = listOf("boulot", "je pars au travail"), actions = listOf("mode silencieux", "ouvre mon planning"), reply = "Bonne journée !"),
    CustomCommand(id = "", triggers = listOf("courses {quoi}"), actions = listOf("ajoute {quoi} à la liste courses")),
    CustomCommand(id = "", triggers = listOf("je vais dormir"), actions = listOf("active ne pas déranger", "réveille-moi demain à 6h"), reply = "Bonne nuit !"),
    CustomCommand(id = "", triggers = listOf("ma journée"), actions = listOf("résumé de ma journée", "quelle météo aujourd'hui")),
)

/** Exemples d'actions (des commandes que Calepin comprend déjà). */
private val ACTION_HINTS = listOf(
    "mode silencieux", "active ne pas déranger", "ouvre mon planning", "résumé de ma journée", "quelle météo aujourd'hui",
    "note : …", "ajoute … à la liste courses", "rappelle-moi dans 20 minutes de …", "appelle …",
    "emmène-moi chez …", "ouvre les webradios", "remets la radio", "fond étoiles", "mode sombre", "pause 3",
)

/** Paramètres → Mes commandes : phrases personnelles reliées à des actions de Calepin. */
@Composable
fun CustomCommandsScreen(vm: NotesViewModel, onClose: () -> Unit) {
    val ctx = LocalContext.current
    remember { CustomCommands.init(ctx) }
    val list by CustomCommands.list.collectAsStateWithLifecycle()
    var editing by remember { mutableStateOf<CustomCommand?>(null) }
    ToolScaffold("Mes commandes", onClose) {
        ToolHint(
            "Crée tes propres phrases pour l'assistant, à dire ou à écrire. Chaque phrase lance une ou plusieurs actions que Calepin sait déjà faire. " +
                "Une partie variable s'écrit entre accolades : « courses {quoi} » → « ajoute {quoi} à la liste courses ». " +
                "Tu peux aussi les apprendre à la voix : « quand je dis boulot, mets le mode silencieux et ouvre mon planning ».",
        )
        Button(onClick = { editing = CustomCommand(triggers = emptyList(), actions = emptyList()) }, modifier = Modifier.fillMaxWidth()) {
            Icon(Icons.Filled.Add, null); Spacer(Modifier.width(6.dp)); Text("Nouvelle commande")
        }
        if (list.isEmpty()) {
            Text("Pour commencer, touche un modèle :", style = MaterialTheme.typography.labelLarge)
            TEMPLATES.forEach { t ->
                Surface(onClick = { editing = t.copy(id = java.util.UUID.randomUUID().toString()) }, shape = MaterialTheme.shapes.medium,
                    color = MaterialTheme.colorScheme.surfaceContainerLow, modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(12.dp)) {
                        RawText("« " + t.triggers.joinToString(" » / « ") + " »", style = MaterialTheme.typography.titleSmall)
                        RawText(t.actions.joinToString(" → "), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }
        // Appui long sur une commande puis glisser : elle change de place
        val cmdOrder = rememberReorderState { from, to -> CustomCommands.setOrder(ctx, list.map { it.id }.movedByKey({ it }, from, to)) }
        list.forEach { c ->
            Surface(onClick = { editing = c }, shape = MaterialTheme.shapes.large, color = MaterialTheme.colorScheme.surfaceContainerLow, border = appBorder(),
                modifier = Modifier.reorderItem(cmdOrder, c.id).fillMaxWidth()) {
                Row(Modifier.padding(start = 14.dp, top = 8.dp, bottom = 8.dp, end = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Filled.Bolt, null, tint = if (c.enabled) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline)
                    Spacer(Modifier.width(10.dp))
                    Column(Modifier.weight(1f)) {
                        RawText("« " + c.triggers.joinToString(" » / « ") + " »", style = MaterialTheme.typography.titleSmall, maxLines = 2, overflow = TextOverflow.Ellipsis)
                        RawText(
                            (c.actions.joinToString(" → ") + if (c.reply.isNotBlank()) "  💬 " + c.reply else "").ifBlank { I18n.tr("(aucune action)") },
                            style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 2, overflow = TextOverflow.Ellipsis,
                        )
                    }
                    Switch(checked = c.enabled, onCheckedChange = { CustomCommands.upsert(ctx, c.copy(enabled = it)) })
                }
            }
        }
    }
    editing?.let { c -> CommandEditor(vm, c, isNew = list.none { it.id == c.id }) { editing = null } }
}

/** Édition d'une commande : phrases, actions (dans l'ordre), réponse, essai. */
@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
private fun CommandEditor(vm: NotesViewModel, initial: CustomCommand, isNew: Boolean, onClose: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val triggers = remember { mutableStateListOf<String>().apply { addAll(initial.triggers.ifEmpty { listOf("") }) } }
    val actions = remember { mutableStateListOf<String>().apply { addAll(initial.actions.ifEmpty { listOf("") }) } }
    var reply by remember { mutableStateOf(initial.reply) }
    var enabled by remember { mutableStateOf(initial.enabled) }
    var tryText by remember { mutableStateOf("") }
    var tryResult by remember { mutableStateOf<String?>(null) }
    var running by remember { mutableStateOf(false) }
    var confirmDelete by remember { mutableStateOf(false) }

    fun current() = initial.copy(
        triggers = triggers.map { it.trim() }.filter { it.isNotEmpty() },
        actions = actions.map { it.trim() }.filter { it.isNotEmpty() },
        reply = reply.trim(), enabled = enabled,
    )
    val all by CustomCommands.list.collectAsStateWithLifecycle()
    // Phrases déjà utilisées par une autre commande
    val clashes = current().triggers.filter { t -> all.any { o -> o.id != initial.id && o.triggers.any { CommandRules.norm(it) == CommandRules.norm(t) } } }
    val valid = current().triggers.isNotEmpty() && (current().actions.isNotEmpty() || current().reply.isNotEmpty())

    androidx.compose.ui.window.Dialog(
        onDismissRequest = onClose,
        properties = androidx.compose.ui.window.DialogProperties(usePlatformDefaultWidth = false, decorFitsSystemWindows = false),
    ) {
        Scaffold(
            containerColor = MaterialTheme.colorScheme.surface,
            topBar = {
                TopAppBar(
                    title = { FitText(if (isNew) "Nouvelle commande" else "Modifier la commande") },
                    navigationIcon = { IconButton(onClick = onClose) { Icon(Icons.Filled.Close, "Fermer") } },
                    actions = {
                        if (!isNew) IconButton(onClick = { confirmDelete = true }) { Icon(Icons.Filled.Delete, "Supprimer") }
                        TextButton(enabled = valid, onClick = {
                            CustomCommands.upsert(ctx, current())
                            I18n.toast(ctx, I18n.tr("Commande enregistrée."), android.widget.Toast.LENGTH_SHORT).show()
                            onClose()
                        }) { Text("Enregistrer") }
                    },
                )
            },
        ) { pad ->
            Column(
                Modifier.fillMaxSize().padding(pad).imePadding().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                // ---------------------------------------------------------------- Phrases
                Text("Quand je dis…", style = MaterialTheme.typography.titleMedium)
                ToolHint("Une ou plusieurs phrases. Les accents, les majuscules et « s'il te plaît » ne comptent pas ; une petite faute est tolérée.")
                triggers.forEachIndexed { i, t ->
                    OutlinedTextField(
                        t, { triggers[i] = it }, singleLine = true, modifier = Modifier.fillMaxWidth(),
                        placeholder = { Text(if (i == 0) "boulot" else "autre façon de le dire") },
                        trailingIcon = { if (triggers.size > 1) IconButton(onClick = { triggers.removeAt(i) }) { Icon(Icons.Filled.Close, "Retirer") } },
                        isError = t.isNotBlank() && t.trim() in clashes,
                    )
                }
                if (clashes.isNotEmpty()) RawText(
                    I18n.trf("Déjà utilisé par une autre commande : {0}", clashes.joinToString(", ") { "« $it »" }),
                    style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error,
                )
                TextButton(onClick = { triggers.add("") }) { Icon(Icons.Filled.Add, null); Text(" Autre phrase") }

                HorizontalDivider()
                // ---------------------------------------------------------------- Actions
                Text("…Calepin fait", style = MaterialTheme.typography.titleMedium)
                ToolHint("Une action par ligne, dans l'ordre, comme tu le dirais à l'assistant. « pause 3 » attend 3 secondes. Les parties variables des phrases ({quoi}) se recopient ici.")
                // Poignée : glisser une action pour changer l'ordre
                val actOrder = rememberReorderState { from, to ->
                    val x = actions.removeAt(from as Int); actions.add(to as Int, x)
                }
                actions.forEachIndexed { i, a ->
                    Row(Modifier.reorderItem(actOrder, i, handleOnly = true), verticalAlignment = Alignment.CenterVertically) {
                        if (actions.size > 1) DragHandle(actOrder, i)
                        RawText("${i + 1}.", modifier = Modifier.width(22.dp), style = MaterialTheme.typography.labelLarge)
                        OutlinedTextField(a, { actions[i] = it }, modifier = Modifier.weight(1f), placeholder = { Text("mode silencieux") })
                        Column {
                            if (i > 0) IconButton(onClick = { val x = actions.removeAt(i); actions.add(i - 1, x) }, modifier = Modifier.size(32.dp)) {
                                Icon(Icons.Filled.ArrowUpward, "Monter", Modifier.size(18.dp))
                            }
                            if (i < actions.size - 1) IconButton(onClick = { val x = actions.removeAt(i); actions.add(i + 1, x) }, modifier = Modifier.size(32.dp)) {
                                Icon(Icons.Filled.ArrowDownward, "Descendre", Modifier.size(18.dp))
                            }
                        }
                        if (actions.size > 1) IconButton(onClick = { actions.removeAt(i) }) { Icon(Icons.Filled.Close, "Retirer") }
                    }
                }
                TextButton(onClick = { actions.add("") }) { Icon(Icons.Filled.Add, null); Text(" Autre action") }
                Text("Idées d'actions (touche pour ajouter) :", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    ACTION_HINTS.forEach { h ->
                        AssistChip(onClick = {
                            val empty = actions.indexOfFirst { it.isBlank() }
                            if (empty >= 0) actions[empty] = h else actions.add(h)
                        }, label = { Text(h) })
                    }
                }
                val vars = current().triggers.flatMap { CommandRules.variables(it) }.distinct()
                if (vars.isNotEmpty()) FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("Insérer :", style = MaterialTheme.typography.labelMedium)
                    vars.forEach { v ->
                        AssistChip(onClick = {
                            val last = actions.lastIndex
                            if (last >= 0) actions[last] = (actions[last].trimEnd() + " {" + v + "}").trim()
                        }, label = { RawText("{$v}") })
                    }
                }

                HorizontalDivider()
                // ---------------------------------------------------------------- Réponse
                Text("Réponse (facultative)", style = MaterialTheme.typography.titleMedium)
                OutlinedTextField(reply, { reply = it }, modifier = Modifier.fillMaxWidth(), placeholder = { Text("Bonne journée !") },
                    supportingText = { Text("Dite ou affichée à la place du compte rendu des actions.") })
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Commande active", modifier = Modifier.weight(1f))
                    Switch(checked = enabled, onCheckedChange = { enabled = it })
                }

                HorizontalDivider()
                // ---------------------------------------------------------------- Essai
                Text("Tester", style = MaterialTheme.typography.titleMedium)
                OutlinedTextField(tryText, { tryText = it; tryResult = null }, singleLine = true, modifier = Modifier.fillMaxWidth(),
                    placeholder = { RawText(current().triggers.firstOrNull()?.let { CommandRules.fill(it, CommandRules.variables(it).associateWith { "pain" }) } ?: I18n.tr("Une phrase à essayer")) })
                val test = tryText.takeIf { it.isNotBlank() }?.let { CommandRules.match(listOf(current().copy(enabled = true)), it) }
                if (tryText.isNotBlank()) {
                    if (test == null) Text("Cette phrase ne déclenche pas la commande.", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                    else RawText(
                        I18n.tr("Reconnue. Calepin fera :") + "\n" +
                            test.command.actions.mapIndexed { i, a -> "${i + 1}. " + CommandRules.fill(a, test.values) }.joinToString("\n") +
                            (if (test.values.isNotEmpty()) "\n" + test.values.entries.joinToString(" · ") { "{${it.key}} = ${it.value}" } else ""),
                        style = MaterialTheme.typography.bodySmall,
                    )
                }
                OutlinedButton(
                    enabled = test != null && !running,
                    onClick = {
                        // Enregistrée d'abord (la commande essayée est celle qui est à l'écran), puis exécutée pour de vrai
                        CustomCommands.upsert(ctx, current())
                        running = true
                        scope.launch {
                            tryResult = runCatching { vm.runCustom(tryText) }.getOrNull() ?: I18n.tr("Rien n'a été fait.")
                            running = false
                        }
                    },
                ) { Icon(Icons.Filled.PlayArrow, null); Text(" Enregistrer et exécuter") }
                if (running) LinearProgressIndicator(Modifier.fillMaxWidth())
                tryResult?.let { Surface(shape = MaterialTheme.shapes.medium, color = MaterialTheme.colorScheme.secondaryContainer.bubble(), modifier = Modifier.fillMaxWidth()) {
                    RawText(it, modifier = Modifier.padding(12.dp), style = MaterialTheme.typography.bodyMedium)
                } }
                Spacer(Modifier.size(40.dp))
            }
        }
    }
    if (confirmDelete) AlertDialog(
        onDismissRequest = { confirmDelete = false },
        title = { Text("Supprimer cette commande ?") },
        text = { RawText("« " + initial.title + " »") },
        confirmButton = { TextButton(onClick = { CustomCommands.delete(ctx, initial.id); confirmDelete = false; onClose() }) { Text("Supprimer") } },
        dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text("Annuler") } },
    )
}
