package fr.jeremy.calepin.tools

import android.Manifest
import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.os.Environment
import android.os.StatFs
import android.provider.Settings
import androidx.core.content.ContextCompat
import java.io.File

/** Taille lisible : « 12,4 Mo », « 1,2 Go ». */
fun formatSize(bytes: Long): String {
    if (bytes < 1024) return "$bytes o"
    val units = listOf("Ko", "Mo", "Go", "To")
    var v = bytes / 1024.0
    var i = 0
    while (v >= 1024 && i < units.lastIndex) { v /= 1024; i++ }
    val loc = fr.jeremy.calepin.i18n.I18n.locale
    val unit = if (fr.jeremy.calepin.i18n.I18n.language.value.code == "fr") units[i] else listOf("KB", "MB", "GB", "TB")[i]
    return if (v >= 100) String.format(loc, "%.0f %s", v, unit) else String.format(loc, "%.1f %s", v, unit)
}

/** Accès aux fichiers du téléphone (explorateur, nettoyeur). */
object StorageAccess {
    val root: File get() = Environment.getExternalStorageDirectory()

    fun granted(ctx: Context): Boolean =
        if (Build.VERSION.SDK_INT >= 30) Environment.isExternalStorageManager()
        else ContextCompat.checkSelfPermission(ctx, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED

    /** Android 11+ : écran « Accès à tous les fichiers » des réglages. */
    fun settingsIntent(ctx: Context): Intent =
        if (Build.VERSION.SDK_INT >= 30) {
            Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:" + ctx.packageName))
        } else {
            Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + ctx.packageName))
        }
}

data class StorageState(val total: Long, val free: Long) { val used get() = total - free }
data class RamState(val total: Long, val available: Long, val low: Boolean) { val used get() = total - available }
data class BatteryState(val level: Int, val charging: Boolean, val temperature: Float, val health: String, val voltage: Int)
data class AppSize(val pkg: String, val label: String, val size: Long, val system: Boolean)

/** État du téléphone : stockage, mémoire vive, batterie, applis. */
object PhoneInfo {
    fun storage(): StorageState {
        val st = StatFs(Environment.getDataDirectory().path)
        return StorageState(st.totalBytes, st.availableBytes)
    }

    fun ram(ctx: Context): RamState {
        val am = ctx.getSystemService(ActivityManager::class.java)
        val mi = ActivityManager.MemoryInfo()
        am.getMemoryInfo(mi)
        return RamState(mi.totalMem, mi.availMem, mi.lowMemory)
    }

    fun battery(ctx: Context): BatteryState? {
        val i = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED)) ?: return null
        val level = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
        val scale = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100).coerceAtLeast(1)
        val status = i.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
        val health = when (i.getIntExtra(BatteryManager.EXTRA_HEALTH, 0)) {
            BatteryManager.BATTERY_HEALTH_GOOD -> "Bon état"
            BatteryManager.BATTERY_HEALTH_OVERHEAT -> "Surchauffe"
            BatteryManager.BATTERY_HEALTH_DEAD -> "Usée"
            BatteryManager.BATTERY_HEALTH_OVER_VOLTAGE -> "Surtension"
            BatteryManager.BATTERY_HEALTH_COLD -> "Trop froide"
            else -> "Inconnu"
        }
        return BatteryState(
            level = level * 100 / scale,
            charging = status == BatteryManager.BATTERY_STATUS_CHARGING || status == BatteryManager.BATTERY_STATUS_FULL,
            temperature = i.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) / 10f,
            health = health,
            voltage = i.getIntExtra(BatteryManager.EXTRA_VOLTAGE, 0),
        )
    }

    /** Applis installées, les plus lourdes d'abord (taille du programme installé). */
    fun apps(ctx: Context): List<AppSize> {
        val pm = ctx.packageManager
        @Suppress("DEPRECATION")
        return pm.getInstalledApplications(0).mapNotNull { ai ->
            val size = runCatching {
                var s = File(ai.sourceDir).length()
                ai.splitSourceDirs?.forEach { s += File(it).length() }
                s
            }.getOrDefault(0L)
            val system = (ai.flags and ApplicationInfo.FLAG_SYSTEM) != 0 && (ai.flags and ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) == 0
            AppSize(ai.packageName, pm.getApplicationLabel(ai).toString(), size, system)
        }.sortedByDescending { it.size }
    }

    /**
     * Ferme les applis qui tournent en arrière-plan (Android les relance si besoin).
     * Renvoie la mémoire vive gagnée, en octets (estimation).
     */
    fun freeMemory(ctx: Context): Long {
        val before = ram(ctx).available
        val am = ctx.getSystemService(ActivityManager::class.java)
        val pm = ctx.packageManager
        @Suppress("DEPRECATION")
        pm.getInstalledApplications(0).forEach { ai ->
            if (ai.packageName != ctx.packageName) runCatching { am.killBackgroundProcesses(ai.packageName) }
        }
        System.gc()
        Thread.sleep(800)
        return (ram(ctx).available - before).coerceAtLeast(0L)
    }

    /** Cache de Calepin (fichiers temporaires, exports déjà partagés…). */
    fun appCacheSize(ctx: Context): Long = dirSize(ctx.cacheDir) + (ctx.externalCacheDir?.let { dirSize(it) } ?: 0L)

    fun clearAppCache(ctx: Context): Long {
        val size = appCacheSize(ctx)
        ctx.cacheDir.listFiles()?.forEach { it.deleteRecursively() }
        ctx.externalCacheDir?.listFiles()?.forEach { it.deleteRecursively() }
        return size
    }

    fun dirSize(f: File): Long = if (f.isFile) f.length() else f.listFiles()?.sumOf { dirSize(it) } ?: 0L

    fun uninstallIntent(pkg: String) = Intent(Intent.ACTION_DELETE, Uri.parse("package:$pkg"))
    fun appDetailsIntent(pkg: String) = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$pkg"))
}
