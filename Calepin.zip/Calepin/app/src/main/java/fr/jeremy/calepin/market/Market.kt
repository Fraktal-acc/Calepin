package fr.jeremy.calepin.market

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.job.JobInfo
import android.app.job.JobParameters
import android.app.job.JobScheduler
import android.app.job.JobService
import android.content.ComponentName
import android.content.Context
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale
import java.util.UUID

/** Signal du robot (ou opération automatique : stop, objectif). */
data class Signal(
    val t: Long,
    val ruleName: String,
    val symbol: String,
    val name: String,
    val action: Action,
    val price: Double,
    val currency: String,
    val detail: String,
    /** Ce qui a été fait dans la simulation (vide : simple alerte). */
    val done: String = "",
)

/**
 * Bourse : instruments suivis, règles du robot, portefeuille de simulation et journal des signaux.
 * Tout reste sur le téléphone. Aucun ordre réel n'est passé : le robot prévient et joue en simulation.
 */
object Market {
    private const val PREFS = "market"
    private const val CHANNEL = "calepin_bourse"
    const val JOB_ID = 7300

    private fun p(ctx: Context): SharedPreferences = ctx.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    private val _watch = MutableStateFlow<List<Instrument>>(emptyList())
    val watch: StateFlow<List<Instrument>> = _watch
    private val _rules = MutableStateFlow<List<Rule>>(emptyList())
    val rules: StateFlow<List<Rule>> = _rules
    private val _portfolio = MutableStateFlow(Portfolio())
    val portfolio: StateFlow<Portfolio> = _portfolio
    private val _signals = MutableStateFlow<List<Signal>>(emptyList())
    val signals: StateFlow<List<Signal>> = _signals
    private val _robotOn = MutableStateFlow(false)
    val robotOn: StateFlow<Boolean> = _robotOn
    /** Minutes entre deux vérifications automatiques (15 au minimum, limite d'Android). */
    private val _every = MutableStateFlow(30)
    val every: StateFlow<Int> = _every
    private val _lastCheck = MutableStateFlow(0L)
    val lastCheck: StateFlow<Long> = _lastCheck
    private val _lastError = MutableStateFlow("")
    val lastError: StateFlow<String> = _lastError

    @Volatile private var loaded = false

    fun init(ctx: Context) {
        if (loaded) return
        synchronized(this) {
            if (loaded) return
            val s = p(ctx)
            _watch.value = runCatching { parseWatch(JSONArray(s.getString("watch", null) ?: defaultWatch())) }.getOrDefault(emptyList())
            _rules.value = runCatching { JSONArray(s.getString("rules", "[]")).let { a -> (0 until a.length()).mapNotNull { ruleFrom(a.optJSONObject(it)) } } }.getOrDefault(emptyList())
            _portfolio.value = runCatching { s.getString("portfolio", null)?.let { portfolioFrom(JSONObject(it)) } }.getOrNull() ?: Portfolio()
            _signals.value = runCatching { JSONArray(s.getString("signals", "[]")).let { a -> (0 until a.length()).mapNotNull { signalFrom(a.optJSONObject(it)) } } }.getOrDefault(emptyList())
            _robotOn.value = s.getBoolean("robot", false)
            _every.value = s.getInt("every", 30)
            _lastCheck.value = s.getLong("last_check", 0L)
            _lastError.value = s.getString("last_error", "") ?: ""
            loaded = true
        }
    }

    /** Quelques instruments pour démarrer : CAC 40, S&P 500, euro/dollar, or, bitcoin. */
    private fun defaultWatch() = JSONArray().apply {
        listOf(
            Instrument("^FCHI", "CAC 40", "Paris", "Indice"),
            Instrument("^GSPC", "S&P 500", "New York", "Indice"),
            Instrument("EURUSD=X", "Euro / Dollar", "Devises", "Devise"),
            Instrument("GC=F", "Or", "COMEX", "Contrat à terme"),
            Instrument("BTC-EUR", "Bitcoin en euros", "Crypto", "Crypto"),
        ).forEach { put(instJson(it)) }
    }.toString()

    // ------------------------------------------------------------------ Instruments suivis

    fun addWatch(ctx: Context, i: Instrument) {
        if (_watch.value.any { it.symbol == i.symbol }) return
        _watch.value = _watch.value + i
        saveWatch(ctx)
    }

    fun removeWatch(ctx: Context, symbol: String) {
        _watch.value = _watch.value.filter { it.symbol != symbol }
        saveWatch(ctx)
    }

    fun moveWatch(ctx: Context, symbol: String, delta: Int) {
        val l = _watch.value.toMutableList()
        val i = l.indexOfFirst { it.symbol == symbol }
        val j = i + delta
        if (i < 0 || j !in l.indices) return
        val x = l.removeAt(i); l.add(j, x)
        _watch.value = l
        saveWatch(ctx)
    }

    private fun saveWatch(ctx: Context) =
        p(ctx).edit().putString("watch", JSONArray().apply { _watch.value.forEach { put(instJson(it)) } }.toString()).apply()

    private fun instJson(i: Instrument) = JSONObject().put("s", i.symbol).put("n", i.name).put("e", i.exchange).put("t", i.type)
    private fun parseWatch(a: JSONArray) = (0 until a.length()).mapNotNull { k ->
        a.optJSONObject(k)?.let { o -> Instrument(o.optString("s"), o.optString("n"), o.optString("e"), o.optString("t")).takeIf { it.symbol.isNotBlank() } }
    }

    // ------------------------------------------------------------------ Règles

    fun saveRule(ctx: Context, r: Rule) {
        val rule = if (r.id.isBlank()) r.copy(id = UUID.randomUUID().toString()) else r
        val l = _rules.value
        _rules.value = if (l.any { it.id == rule.id }) l.map { if (it.id == rule.id) rule else it } else l + rule
        // Règle modifiée : ses états repartent de zéro (le prochain signal compte)
        clearStates(ctx, rule.id)
        saveRules(ctx)
        schedule(ctx)
    }

    fun deleteRule(ctx: Context, id: String) {
        _rules.value = _rules.value.filter { it.id != id }
        clearStates(ctx, id)
        saveRules(ctx)
        schedule(ctx)
    }

    fun setRuleEnabled(ctx: Context, id: String, on: Boolean) {
        _rules.value = _rules.value.map { if (it.id == id) it.copy(enabled = on) else it }
        saveRules(ctx)
        schedule(ctx)
    }

    private fun saveRules(ctx: Context) =
        p(ctx).edit().putString("rules", JSONArray().apply { _rules.value.forEach { put(ruleJson(it)) } }.toString()).apply()

    private fun ruleJson(r: Rule) = JSONObject()
        .put("id", r.id).put("name", r.name)
        .put("symbols", JSONArray(r.symbols))
        .put("tf", r.timeframe.name).put("action", r.action.name).put("all", r.all)
        .put("conds", JSONArray().apply { r.conditions.forEach { c -> put(JSONObject().put("t", c.type.name).put("a", c.a).put("b", c.b)) } })
        .put("sim", r.simulate).put("smart", r.smartExit).put("amount", r.amount).put("sl", r.stopLoss).put("tp", r.takeProfit).put("on", r.enabled)

    private fun ruleFrom(o: JSONObject?): Rule? {
        o ?: return null
        val syms = o.optJSONArray("symbols")?.let { a -> (0 until a.length()).map { a.optString(it) }.filter { it.isNotBlank() } } ?: emptyList()
        val conds = o.optJSONArray("conds")?.let { a ->
            (0 until a.length()).mapNotNull { k ->
                val c = a.optJSONObject(k) ?: return@mapNotNull null
                val t = runCatching { CondType.valueOf(c.optString("t")) }.getOrNull() ?: return@mapNotNull null
                Condition(t, c.optDouble("a", t.da), c.optDouble("b", t.db))
            }
        } ?: emptyList()
        return Rule(
            id = o.optString("id").ifBlank { return null },
            name = o.optString("name"),
            symbols = syms,
            timeframe = runCatching { Timeframe.valueOf(o.optString("tf")) }.getOrDefault(Timeframe.D1),
            action = runCatching { Action.valueOf(o.optString("action")) }.getOrDefault(Action.ALERT),
            all = o.optBoolean("all", true),
            conditions = conds,
            simulate = o.optBoolean("sim", true),
            smartExit = o.optBoolean("smart", false),
            amount = o.optDouble("amount", 1000.0),
            stopLoss = o.optDouble("sl", 0.0),
            takeProfit = o.optDouble("tp", 0.0),
            enabled = o.optBoolean("on", true),
        )
    }

    // ------------------------------------------------------------------ Portefeuille de simulation

    fun resetPortfolio(ctx: Context, capital: Double) {
        _portfolio.value = Portfolio(start = capital, cash = capital)
        savePortfolio(ctx)
    }

    /** Achat ou vente à la main dans la simulation (depuis la fiche d'un instrument). */
    fun manualTrade(ctx: Context, s: Series, buy: Boolean, amountEur: Double): String {
        val fx = MarketData.fx(s.currency)
        if (fx <= 0) return "Taux de change introuvable pour ${s.currency}"
        val now = System.currentTimeMillis()
        val next = if (buy) _portfolio.value.buy(s.symbol, s.name, s.price, s.currency, fx, amountEur, 0.0, 0.0, "À la main", now)
        else _portfolio.value.sell(s.symbol, s.price, fx, "À la main", now)
        if (next == null) return if (buy) "Achat impossible (déjà en portefeuille ou pas assez de liquidités)" else "Rien à vendre"
        _portfolio.value = next
        savePortfolio(ctx)
        return if (buy) "Acheté en simulation" else "Vendu en simulation"
    }

    private fun savePortfolio(ctx: Context) = p(ctx).edit().putString("portfolio", portfolioJson(_portfolio.value).toString()).apply()

    private fun portfolioJson(pf: Portfolio) = JSONObject()
        .put("start", pf.start).put("cash", pf.cash)
        .put("pos", JSONArray().apply {
            pf.positions.forEach { x ->
                put(JSONObject().put("s", x.symbol).put("n", x.name).put("q", x.qty).put("avg", x.avg).put("cur", x.currency)
                    .put("cost", x.costEur).put("at", x.openedAt).put("stop", x.stop).put("take", x.take).put("rule", x.ruleId))
            }
        })
        .put("trades", JSONArray().apply {
            pf.trades.forEach { t ->
                put(JSONObject().put("t", t.t).put("s", t.symbol).put("n", t.name).put("buy", t.buy).put("q", t.qty).put("p", t.price)
                    .put("cur", t.currency).put("eur", t.eur).put("pnl", t.pnl).put("why", t.reason))
            }
        })

    private fun portfolioFrom(o: JSONObject): Portfolio {
        val pos = o.optJSONArray("pos")?.let { a ->
            (0 until a.length()).mapNotNull { k ->
                a.optJSONObject(k)?.let { x ->
                    Position(x.optString("s"), x.optString("n"), x.optDouble("q"), x.optDouble("avg"), x.optString("cur"),
                        x.optDouble("cost"), x.optLong("at"), x.optDouble("stop", 0.0), x.optDouble("take", 0.0), x.optString("rule"))
                }
            }
        } ?: emptyList()
        val trades = o.optJSONArray("trades")?.let { a ->
            (0 until a.length()).mapNotNull { k ->
                a.optJSONObject(k)?.let { x ->
                    Trade(x.optLong("t"), x.optString("s"), x.optString("n"), x.optBoolean("buy"), x.optDouble("q"), x.optDouble("p"),
                        x.optString("cur"), x.optDouble("eur"), x.optDouble("pnl"), x.optString("why"))
                }
            }
        } ?: emptyList()
        return Portfolio(o.optDouble("start", 10_000.0), o.optDouble("cash", 10_000.0), pos, trades)
    }

    // ------------------------------------------------------------------ Signaux

    private fun addSignal(ctx: Context, s: Signal) {
        _signals.value = (listOf(s) + _signals.value).take(300)
        p(ctx).edit().putString("signals", JSONArray().apply { _signals.value.forEach { put(signalJson(it)) } }.toString()).apply()
    }

    fun clearSignals(ctx: Context) {
        _signals.value = emptyList()
        p(ctx).edit().putString("signals", "[]").apply()
    }

    private fun signalJson(s: Signal) = JSONObject().put("t", s.t).put("r", s.ruleName).put("s", s.symbol).put("n", s.name)
        .put("a", s.action.name).put("p", s.price).put("cur", s.currency).put("d", s.detail).put("done", s.done)

    private fun signalFrom(o: JSONObject?): Signal? = o?.let {
        Signal(it.optLong("t"), it.optString("r"), it.optString("s"), it.optString("n"),
            runCatching { Action.valueOf(it.optString("a")) }.getOrDefault(Action.ALERT),
            it.optDouble("p"), it.optString("cur"), it.optString("d"), it.optString("done"))
    }

    // ------------------------------------------------------------------ Robot

    fun setRobot(ctx: Context, on: Boolean) {
        _robotOn.value = on
        p(ctx).edit().putBoolean("robot", on).apply()
        schedule(ctx)
    }

    fun setEvery(ctx: Context, minutes: Int) {
        val m = minutes.coerceAtLeast(5)
        _every.value = m
        p(ctx).edit().putInt("every", m).apply()
        schedule(ctx, force = true)
    }

    private fun alarmIntent(ctx: Context) = android.app.PendingIntent.getBroadcast(
        ctx, JOB_ID, android.content.Intent(ctx, MarketAlarmReceiver::class.java),
        android.app.PendingIntent.FLAG_UPDATE_CURRENT or android.app.PendingIntent.FLAG_IMMUTABLE,
    )

    /**
     * Vérifications plus fréquentes que 15 minutes (limite des tâches Android) : réveil à l'heure exacte,
     * reprogrammé après chaque vérification.
     */
    fun scheduleAlarm(ctx: Context) {
        val am = ctx.getSystemService(android.app.AlarmManager::class.java) ?: return
        val at = System.currentTimeMillis() + _every.value * 60_000L
        val pi = alarmIntent(ctx)
        val exact = Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms()
        runCatching {
            if (exact) am.setExactAndAllowWhileIdle(android.app.AlarmManager.RTC_WAKEUP, at, pi)
            else am.setAndAllowWhileIdle(android.app.AlarmManager.RTC_WAKEUP, at, pi)
        }
    }

    /** Le robot doit-il tourner (actif, avec des règles ou des stops à surveiller) ? */
    fun needed(ctx: Context): Boolean {
        init(ctx)
        return _robotOn.value && (_rules.value.any { it.enabled && it.symbols.isNotEmpty() } || _portfolio.value.positions.any { it.stop > 0 || it.take > 0 })
    }

    /** Programme (ou annule) la vérification automatique en arrière-plan. */
    fun schedule(ctx: Context, force: Boolean = false) {
        init(ctx)
        val js = ctx.getSystemService(JobScheduler::class.java) ?: return
        val am = ctx.getSystemService(android.app.AlarmManager::class.java)
        val needed = needed(ctx)
        if (!needed || _every.value >= 15) runCatching { am?.cancel(alarmIntent(ctx)) }
        if (!needed) { js.cancel(JOB_ID); return }
        if (_every.value < 15) {
            js.cancel(JOB_ID)
            scheduleAlarm(ctx)
            return
        }
        val existing = js.allPendingJobs.firstOrNull { it.id == JOB_ID }
        val period = _every.value * 60_000L
        if (existing != null && !force && existing.intervalMillis == period) return
        runCatching {
            js.schedule(
                JobInfo.Builder(JOB_ID, ComponentName(ctx, MarketJob::class.java))
                    .setRequiredNetworkType(JobInfo.NETWORK_TYPE_ANY)
                    .setPeriodic(period)
                    .setPersisted(true)
                    .build()
            )
        }
    }

    private fun stateKey(ruleId: String, symbol: String) = "st_${ruleId}_$symbol"

    private fun clearStates(ctx: Context, ruleId: String) {
        val s = p(ctx)
        val e = s.edit()
        s.all.keys.filter { it.startsWith("st_${ruleId}_") }.forEach { e.remove(it) }
        e.apply()
    }

    /** Résultat d'une vérification : instrument, règle remplie ou non, détail. */
    data class Check(val rule: Rule, val symbol: String, val ok: Boolean, val results: List<CondResult>, val price: Double, val currency: String, val error: String = "")

    /** Évalue une règle tout de suite, sans rien déclencher (bouton « Tester »). */
    fun test(rule: Rule): List<Check> = rule.symbols.map { sym ->
        try {
            val s = MarketData.series(sym, rule.timeframe)
            val (ok, res) = Strategy.evaluate(rule, s.candles)
            Check(rule, sym, ok, res, s.price, s.currency)
        } catch (e: Exception) {
            Check(rule, sym, false, emptyList(), 0.0, "", e.message ?: "erreur")
        }
    }

    private fun money(x: Double, cur: String) = String.format(Locale.FRANCE, "%.2f %s", x, cur).trim()

    /**
     * Vérifie toutes les règles actives et les stops des positions simulées. Un signal part quand les conditions
     * d'une règle deviennent vraies (pas à chaque vérification tant qu'elles le restent).
     */
    fun runChecks(ctx: Context): Int {
        init(ctx)
        fr.jeremy.calepin.i18n.I18n.init(ctx)
        val prefs = p(ctx)
        val now = System.currentTimeMillis()
        val cache = HashMap<String, Series>()
        var fired = 0
        val errors = ArrayList<String>()
        fun load(sym: String, tf: Timeframe): Series? {
            val k = "$sym|${tf.name}"
            cache[k]?.let { return it }
            return try {
                MarketData.series(sym, tf).also { cache[k] = it }
            } catch (e: Exception) {
                errors += "$sym : ${e.message ?: "erreur"}"
                null
            }
        }
        val names = _watch.value.associate { it.symbol to it.name }
        for (rule in _rules.value.filter { it.enabled && it.conditions.isNotEmpty() }) {
            for (sym in rule.symbols) {
                val s = load(sym, rule.timeframe) ?: continue
                val (ok, res) = Strategy.evaluate(rule, s.candles)
                if (res.any { !it.known }) continue
                val key = stateKey(rule.id, sym)
                val was = prefs.getBoolean(key, false)
                if (ok != was) prefs.edit().putBoolean(key, ok).apply()
                if (!ok || was) continue
                // Les conditions viennent d'être réunies : signal
                val name = names[sym] ?: s.name
                val detail = res.filter { it.ok }.joinToString(" · ") { it.detail }
                var done = ""
                if (rule.simulate && rule.action != Action.ALERT) {
                    val fx = MarketData.fx(s.currency)
                    if (fx > 0) {
                        val pf = _portfolio.value
                        val next = if (rule.action == Action.BUY)
                            run {
                                // Stop et objectif calculés par l'analyse (supports, résistances, Fibonacci) si demandé
                                var sl = rule.stopLoss
                                var tp = rule.takeProfit
                                if (rule.smartExit) {
                                    Analyzer(s.candles).analyze(withBacktest = false)?.let { an ->
                                        val plan = an.plan?.takeIf { it.buy }
                                        val atr = an.atr.takeIf { !it.isNaN() && it > 0 } ?: 0.0
                                        val stop = plan?.stop ?: (s.price - 2 * atr)
                                        val target = plan?.target1 ?: (s.price + 3 * atr)
                                        if (s.price > 0 && stop < s.price && target > s.price) {
                                            sl = (s.price - stop) / s.price * 100
                                            tp = (target - s.price) / s.price * 100
                                        }
                                    }
                                }
                                pf.buy(sym, name, s.price, s.currency, fx, rule.amount, sl, tp, rule.name, now, rule.id)
                            }
                        else pf.sell(sym, s.price, fx, rule.name, now)
                        if (next != null) {
                            _portfolio.value = next
                            savePortfolio(ctx)
                            done = if (rule.action == Action.BUY) "Acheté en simulation" else "Vendu en simulation"
                        } else {
                            done = if (rule.action == Action.BUY) "Pas d'achat simulé (déjà détenu ou liquidités insuffisantes)" else "Pas de vente simulée (rien en portefeuille)"
                        }
                    }
                }
                val sig = Signal(now, rule.name, sym, name, rule.action, s.price, s.currency, detail, done)
                addSignal(ctx, sig)
                notify(ctx, sig)
                fired++
            }
        }
        // Stops de perte et objectifs de gain des positions simulées
        for (pos in _portfolio.value.positions) {
            if (pos.stop <= 0 && pos.take <= 0) continue
            val s = load(pos.symbol, Timeframe.D1) ?: continue
            val hitStop = pos.stop > 0 && s.price <= pos.stop
            val hitTake = pos.take > 0 && s.price >= pos.take
            if (!hitStop && !hitTake) continue
            val fx = MarketData.fx(s.currency)
            if (fx <= 0) continue
            val why = if (hitStop) "Stop de perte" else "Objectif atteint"
            val next = _portfolio.value.sell(pos.symbol, s.price, fx, why, now) ?: continue
            _portfolio.value = next
            savePortfolio(ctx)
            val pnl = next.trades.firstOrNull()?.pnl ?: 0.0
            val sig = Signal(now, why, pos.symbol, pos.name, Action.SELL, s.price, s.currency,
                "${money(s.price, s.currency)} · " + (if (hitStop) "stop ${money(pos.stop, pos.currency)}" else "objectif ${money(pos.take, pos.currency)}"),
                "Vendu en simulation (${if (pnl >= 0) "+" else ""}${money(pnl, "€")})")
            addSignal(ctx, sig)
            notify(ctx, sig)
            fired++
        }
        _lastCheck.value = now
        _lastError.value = errors.distinct().take(3).joinToString("\n")
        prefs.edit().putLong("last_check", now).putString("last_error", _lastError.value).apply()
        return fired
    }

    private fun notify(ctx: Context, s: Signal) {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) return
        fun tr(x: String) = fr.jeremy.calepin.i18n.I18n.tr(x)
        val nm = ctx.getSystemService(NotificationManager::class.java)
        if (nm.getNotificationChannel(CHANNEL) == null) {
            nm.createNotificationChannel(NotificationChannel(CHANNEL, tr("Bourse : signaux du robot"), NotificationManager.IMPORTANCE_HIGH))
        }
        val head = when (s.action) {
            Action.BUY -> tr("Signal d'achat")
            Action.SELL -> tr("Signal de vente")
            Action.ALERT -> tr("Alerte")
        }
        val title = "$head · ${s.name} (${s.symbol})"
        val body = buildString {
            append(money(s.price, s.currency)).append(" — ").append(s.ruleName)
            if (s.detail.isNotBlank()) append("\n").append(s.detail)
            if (s.done.isNotBlank()) append("\n").append(tr(s.done))
        }
        val n = NotificationCompat.Builder(ctx, CHANNEL)
            .setSmallIcon(fr.jeremy.calepin.R.drawable.ic_notification)
            .setContentTitle(title)
            .setContentText(body.lineSequence().first())
            .setStyle(NotificationCompat.BigTextStyle().bigText(body))
            .setContentIntent(fr.jeremy.calepin.widgets.Widgets.open(ctx, "market", 7301))
            .setAutoCancel(true)
            .build()
        runCatching { NotificationManagerCompat.from(ctx).notify((s.symbol + s.ruleName + s.t).hashCode(), n) }
    }
}

/** Vérification du robot toutes les 5 ou 10 minutes : réveil exact, puis le suivant est reprogrammé. */
class MarketAlarmReceiver : android.content.BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: android.content.Intent) {
        val app = ctx.applicationContext
        val pending = goAsync()
        Thread {
            runCatching { Market.runChecks(app) }
            runCatching { if (Market.needed(app) && Market.every.value < 15) Market.scheduleAlarm(app) }
            pending.finish()
        }.start()
    }
}

/** Vérification du robot de bourse, réveillée par Android à intervalle régulier. */
class MarketJob : JobService() {
    override fun onStartJob(params: JobParameters): Boolean {
        Thread {
            runCatching { Market.runChecks(applicationContext) }
            jobFinished(params, false)
        }.start()
        return true
    }

    override fun onStopJob(params: JobParameters): Boolean = true
}
