package fr.jeremy.calepin.ui

import android.graphics.Bitmap
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.awaitLongPressOrCancellation
import androidx.compose.foundation.gestures.drag
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.FormatColorReset
import androidx.compose.material.icons.filled.PlayCircle
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.input.pointer.changedToUp
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChange
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.ParagraphStyle
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.Constraints
import androidx.compose.ui.unit.dp
import fr.jeremy.calepin.i18n.Text
import fr.jeremy.calepin.media.Media
import fr.jeremy.calepin.text.NoteLayout
import fr.jeremy.calepin.text.RichText
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.math.roundToInt

/** Couleurs du texte proposées (gardées telles quelles, quel que soit le thème). */
val TEXT_COLORS = listOf(
    "#000000", "#616161", "#FFFFFF", "#E53935", "#FB8C00", "#FDD835", "#43A047", "#00897B",
    "#039BE5", "#1E88E5", "#3949AB", "#8E24AA", "#D81B60", "#6D4C41", "#C9A227",
)

/** Couleurs de surlignage proposées. */
val HIGHLIGHT_COLORS = listOf("#FFF59D", "#FFE082", "#FFCC80", "#F8BBD0", "#E1BEE7", "#B3E5FC", "#C8E6C9", "#E0E0E0")

fun hexColor(hex: String): Color = runCatching { Color(0xFF000000L or hex.removePrefix("#").toLong(16)) }.getOrDefault(Color.Unspecified)

/** Mise en forme enrichie (couleurs, surlignage, souligné, alignement) appliquée à un texte de note. */
object RichStyle {
    /** Texte foncé sur un surlignage clair, lisible aussi avec un thème sombre. */
    private val ON_HIGHLIGHT = Color(0xFF1B1B1B)

    /** Couleurs, surlignage et souligné ; [tokens] : style des repères (null : laissés tels quels). */
    fun spansInto(b: AnnotatedString.Builder, text: String, tokens: SpanStyle?) {
        if ('[' !in text) return
        val spans = RichText.spans(text)
        spans.filter { it.kind == "bg" }.forEach { b.addStyle(SpanStyle(background = hexColor(it.value), color = ON_HIGHLIGHT), it.start, it.end) }
        spans.filter { it.kind == "c" }.forEach { b.addStyle(SpanStyle(color = hexColor(it.value)), it.start, it.end) }
        spans.filter { it.kind == "u" }.forEach { b.addStyle(SpanStyle(textDecoration = TextDecoration.Underline), it.start, it.end) }
        if (tokens != null) RichText.tokens(text).forEach { b.addStyle(tokens, it.start, it.end) }
    }

    /** Lignes centrées ou à droite ([map] : position dans le texte affiché). */
    fun alignInto(b: AnnotatedString.Builder, text: String, map: (Int) -> Int = { it }) {
        if ('[' !in text) return
        RichText.aligns(text).forEach { (s, e, a) ->
            val ms = map(s)
            val me = map(e)
            if (me > ms) b.addStyle(ParagraphStyle(textAlign = if (a == RichText.CENTER) TextAlign.Center else TextAlign.End), ms, me)
        }
    }
}

/** Photo ou vidéo d'une note, à la taille donnée. */
@Composable
fun NotePhoto(file: File, isVideo: Boolean, modifier: Modifier, maxSide: Int = 1024, alpha: Float = 1f) {
    val bmp by produceState<Bitmap?>(null, file, maxSide) { value = withContext(Dispatchers.IO) { Media.thumbnail(file, isVideo, maxSide) } }
    Box(
        modifier.clip(RoundedCornerShape(10.dp)).background(MaterialTheme.colorScheme.surfaceContainer),
        contentAlignment = Alignment.Center,
    ) {
        bmp?.let { Image(it.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop, alpha = alpha) }
        if (isVideo) Icon(Icons.Filled.PlayCircle, "Vidéo", tint = Color.White.copy(alpha = alpha), modifier = Modifier.size(36.dp))
    }
}

/**
 * Gestes sur une photo de la note : toucher = l'ouvrir ; appui long = la soulever, puis la faire glisser
 * ([onDrag]) et la lâcher ([onDrop], vrai si elle a bougé).
 */
fun Modifier.photoGestures(
    key: Any,
    onTap: () -> Unit,
    onLift: (androidx.compose.ui.geometry.Offset) -> Unit,
    onDrag: (androidx.compose.ui.geometry.Offset) -> Unit,
    onDrop: (Boolean) -> Unit,
): Modifier = pointerInput(key) {
    awaitEachGesture {
        val down = awaitFirstDown(requireUnconsumed = false)
        val lp = awaitLongPressOrCancellation(down.id)
        if (lp == null) {
            val up = currentEvent.changes.firstOrNull { it.id == down.id }
            if (up != null && up.changedToUp() && !up.isConsumed) { up.consume(); onTap() }
            return@awaitEachGesture
        }
        lp.consume()
        onLift(lp.position)
        var total = androidx.compose.ui.geometry.Offset.Zero
        drag(lp.id) { c ->
            val d = c.positionChange()
            total += d
            onDrag(d)
            c.consume()
        }
        onDrop(total.getDistance() > viewConfiguration.touchSlop)
    }
}

/**
 * Photo placée à gauche ou à droite : le texte qui suit passe à côté d'elle, puis reprend toute la largeur
 * sous la photo. Pleine largeur : la photo, puis le texte. [part] affiche un morceau de [text] (début, fin).
 */
@Composable
fun FloatLayout(
    file: File,
    isVideo: Boolean,
    spec: NoteLayout.Spec,
    text: AnnotatedString,
    style: TextStyle,
    photoModifier: Modifier,
    photoAlpha: Float,
    /** Taille maximale de l'image chargée (plus petite pour les aperçus de la liste). */
    maxSide: Int = 1024,
    part: @Composable (Int, Int, Modifier) -> Unit,
) {
    val aspect by produceState(4f / 3f, file) {
        value = withContext(Dispatchers.IO) { runCatching { Media.aspect(file, isVideo) }.getOrDefault(4f / 3f) }.takeIf { it in 0.1f..10f } ?: (4f / 3f)
    }
    BoxWithConstraints(Modifier.fillMaxWidth()) {
        val density = LocalDensity.current
        val w = constraints.maxWidth
        val gap = with(density) { 12.dp.roundToPx() }
        val minText = with(density) { 96.dp.roundToPx() }
        val pw = (w * spec.width / 100f).roundToInt().coerceIn(1, maxOf(1, w))
        val ph = (pw / aspect).roundToInt().coerceAtLeast(1)
        val photoSize = with(density) { Modifier.size(pw.toDp(), ph.toDp()) }
        val photo = @Composable { NotePhoto(file, isVideo, photoSize.then(photoModifier), maxSide = maxSide, alpha = photoAlpha) }
        val side = spec.side
        if (side == null || side == NoteLayout.Side.FULL || w - pw - gap < minText) {
            Column(Modifier.fillMaxWidth()) {
                Box(
                    Modifier.fillMaxWidth(),
                    contentAlignment = when (side) {
                        NoteLayout.Side.LEFT -> Alignment.TopStart
                        NoteLayout.Side.RIGHT -> Alignment.TopEnd
                        else -> Alignment.TopCenter
                    },
                ) { photo() }
                if (text.isNotEmpty()) part(0, text.length, Modifier.fillMaxWidth().padding(top = 8.dp))
            }
        } else {
            val tw = w - pw - gap
            val measurer = rememberTextMeasurer()
            // Lignes qui commencent à côté de la photo : affichées dans la colonne étroite
            val cut = remember(text, tw, ph, style, density) {
                if (text.isEmpty()) 0 to 0f
                else {
                    val l = measurer.measure(text, style, constraints = Constraints(maxWidth = tw))
                    var last = -1
                    for (i in 0 until l.lineCount) { if (l.getLineTop(i) < ph) last = i else break }
                    if (last < 0) 0 to 0f else l.getLineEnd(last) to l.getLineBottom(last)
                }
            }
            val split = cut.first.coerceIn(0, text.length)
            val narrowEnd = if (split > 0 && text[split - 1] == '\n') split - 1 else split
            // Le retour à la ligne entre les deux morceaux n'ajoute pas de ligne vide
            val restStart = if (narrowEnd == split && split < text.length && text[split] == '\n') split + 1 else split
            Column(Modifier.fillMaxWidth()) {
                Row(Modifier.fillMaxWidth()) {
                    if (side == NoteLayout.Side.LEFT) { photo(); Spacer(Modifier.width(with(density) { gap.toDp() })) }
                    Box(Modifier.weight(1f)) { if (narrowEnd > 0) part(0, narrowEnd, Modifier.fillMaxWidth()) }
                    if (side == NoteLayout.Side.RIGHT) { Spacer(Modifier.width(with(density) { gap.toDp() })); photo() }
                }
                if (restStart < text.length) part(restStart, text.length, Modifier.fillMaxWidth().padding(top = if (ph > cut.second) 6.dp else 0.dp))
            }
        }
    }
}

/** Mise en page d'une photo du texte (appui long sans la déplacer). */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun PhotoLayoutDialog(
    spec: NoteLayout.Spec,
    onSide: (NoteLayout.Side?) -> Unit,
    onWidth: (Int) -> Unit,
    onUnplace: () -> Unit,
    onDelete: () -> Unit,
    onDismiss: () -> Unit,
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (spec.video) "Mise en page de la vidéo" else "Mise en page de la photo") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Position", style = MaterialTheme.typography.labelLarge)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf(
                        null to "Vignette",
                        NoteLayout.Side.LEFT to "À gauche",
                        NoteLayout.Side.RIGHT to "À droite",
                        NoteLayout.Side.FULL to "Pleine largeur",
                    ).forEach { (s, label) -> FilterChip(selected = spec.side == s, onClick = { onSide(s) }, label = { Text(label) }) }
                }
                if (spec.side != null) {
                    Text("Taille", style = MaterialTheme.typography.labelLarge)
                    val sizes = if (spec.side == NoteLayout.Side.FULL) listOf(50 to "Petite", 75 to "Moyenne", 100 to "Toute la largeur")
                    else listOf(30 to "Petite", 40 to "Moyenne", 55 to "Grande")
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        sizes.forEach { (wv, label) -> FilterChip(selected = spec.width == wv, onClick = { onWidth(wv) }, label = { Text(label) }) }
                    }
                }
                Text(
                    "Astuce : maintiens la photo puis fais-la glisser où tu veux dans la note. À gauche ou à droite, le texte passe à côté puis dessous.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                Row {
                    TextButton(onClick = onUnplace) { Text("Retirer du texte") }
                    TextButton(onClick = onDelete) { Text("Supprimer", color = MaterialTheme.colorScheme.error) }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Fermer") } },
    )
}

/** Pastilles de couleur (barre d'écriture) : [current] est entourée ; « sans couleur » en premier. */
@Composable
fun ColorSwatches(colors: List<String>, current: String?, onPick: (String?) -> Unit) {
    val cs = MaterialTheme.colorScheme
    Box(
        Modifier.padding(horizontal = 4.dp).size(32.dp).clip(CircleShape).border(BorderStroke(1.dp, cs.outline), CircleShape).clickable { onPick(null) },
        contentAlignment = Alignment.Center,
    ) { Icon(Icons.Filled.FormatColorReset, "Sans couleur", Modifier.size(18.dp)) }
    colors.forEach { hex ->
        val selected = current.equals(hex, ignoreCase = true)
        Box(
            Modifier
                .padding(horizontal = 4.dp)
                .size(32.dp)
                .clip(CircleShape)
                .background(hexColor(hex))
                .border(BorderStroke(if (selected) 3.dp else 1.dp, if (selected) cs.primary else cs.outlineVariant), CircleShape)
                .clickable { onPick(hex) },
        )
    }
}
