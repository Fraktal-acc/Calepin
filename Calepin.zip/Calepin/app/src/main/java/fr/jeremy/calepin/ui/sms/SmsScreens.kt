package fr.jeremy.calepin.ui.sms

import fr.jeremy.calepin.ui.bubble
import android.app.Activity
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.database.ContentObserver
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.OpenInNew
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PersonAdd
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.automirrored.filled.Forward
import androidx.compose.material.icons.filled.Sms
import androidx.compose.material3.Button
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.LinkAnnotation
import androidx.compose.ui.text.LinkInteractionListener
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextLinkStyles
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.withLink
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.core.content.ContextCompat
import fr.jeremy.calepin.Actions
import fr.jeremy.calepin.detect.EntityDetector
import fr.jeremy.calepin.detect.EntityType
import fr.jeremy.calepin.i18n.I18n
import fr.jeremy.calepin.i18n.RawText
import fr.jeremy.calepin.i18n.Text
import fr.jeremy.calepin.sms.SmsContact
import fr.jeremy.calepin.sms.SmsMessage
import fr.jeremy.calepin.sms.SmsStore
import fr.jeremy.calepin.sms.SmsThread
import fr.jeremy.calepin.ui.appBorder
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/** Change à chaque nouveau SMS ou MMS (reçu, envoyé, supprimé) : les écrans se rechargent. */
@Composable
fun rememberSmsVersion(): Int {
    val ctx = LocalContext.current
    var version by remember { mutableIntStateOf(0) }
    DisposableEffect(Unit) {
        val obs = object : ContentObserver(Handler(Looper.getMainLooper())) {
            override fun onChange(selfChange: Boolean) { version++ }
        }
        try { ctx.contentResolver.registerContentObserver(Uri.parse("content://mms-sms/"), true, obs) } catch (_: Exception) { }
        try { ctx.contentResolver.registerContentObserver(Uri.parse("content://sms/"), true, obs) } catch (_: Exception) { }
        onDispose { try { ctx.contentResolver.unregisterContentObserver(obs) } catch (_: Exception) { } }
    }
    return version
}

private fun shortWhen(t: Long): String {
    if (t <= 0) return ""
    val c = Calendar.getInstance().apply { timeInMillis = t }
    val now = Calendar.getInstance()
    val pattern = when {
        c.get(Calendar.YEAR) == now.get(Calendar.YEAR) && c.get(Calendar.DAY_OF_YEAR) == now.get(Calendar.DAY_OF_YEAR) -> "HH:mm"
        c.get(Calendar.YEAR) == now.get(Calendar.YEAR) -> "d MMM"
        else -> "dd/MM/yy"
    }
    return SimpleDateFormat(pattern, I18n.locale).format(Date(t))
}

private fun dayLabel(t: Long): String {
    val now = System.currentTimeMillis()
    return when {
        sameDay(t, now) -> I18n.tr("Aujourd'hui")
        sameDay(t, Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, -1) }.timeInMillis) -> I18n.tr("Hier")
        else -> SimpleDateFormat("EEEE d MMMM yyyy", I18n.locale).format(Date(t)).replaceFirstChar { it.uppercase() }
    }
}

private fun sameDay(a: Long, b: Long): Boolean {
    val x = Calendar.getInstance().apply { timeInMillis = a }
    val y = Calendar.getInstance().apply { timeInMillis = b }
    return x.get(Calendar.YEAR) == y.get(Calendar.YEAR) && x.get(Calendar.DAY_OF_YEAR) == y.get(Calendar.DAY_OF_YEAR)
}

/** Nom affiché d'une conversation : noms des contacts, sinon numéros. */
private fun threadName(ctx: Context, addresses: List<String>): String =
    if (addresses.isEmpty()) I18n.tr("Inconnu")
    else addresses.joinToString(", ") { a -> SmsStore.contact(ctx, a)?.name ?: a }

// ------------------------------------------------------------------ Liste des conversations

/**
 * Rubrique SMS de Messages : conversations du téléphone, recherche, nouveau message.
 */
@Composable
fun SmsTab(onOpen: (threadId: Long, address: String) -> Unit, onNew: () -> Unit, header: @Composable () -> Unit) {
    val ctx = LocalContext.current
    var allowed by remember { mutableStateOf(SmsStore.canRead(ctx)) }
    val ask = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        allowed = SmsStore.canRead(ctx)
        SmsStore.clearCache()
    }
    val version = rememberSmsVersion()
    var query by rememberSaveable { mutableStateOf("") }
    val threads by produceState<List<SmsThread>?>(null, version, allowed) {
        value = if (!allowed) emptyList() else withContext(Dispatchers.IO) {
            SmsStore.threads(ctx).also { list -> list.take(80).forEach { t -> t.addresses.forEach { SmsStore.contact(ctx, it) } } }
        }
    }
    val found by produceState<List<Pair<Long, SmsMessage>>>(emptyList(), query, version, allowed) {
        value = if (!allowed || query.trim().length < 2) emptyList() else withContext(Dispatchers.IO) {
            delay(250)
            SmsStore.search(ctx, query).also { l -> l.forEach { SmsStore.contact(ctx, it.second.address) } }
        }
    }
    Box(Modifier.fillMaxSize()) {
        LazyColumn(
            Modifier.fillMaxSize(),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 96.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            item { header() }
            if (!allowed) {
                item {
                    Surface(shape = MaterialTheme.shapes.large, color = MaterialTheme.colorScheme.surfaceContainerLow, border = appBorder(), modifier = Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Filled.Sms, null, tint = MaterialTheme.colorScheme.primary)
                                Spacer(Modifier.width(10.dp))
                                Text("SMS du téléphone", style = MaterialTheme.typography.titleMedium)
                            }
                            Text(
                                "Pour afficher tes conversations, en écrire et y répondre ici, Calepin a besoin de l'accès aux SMS et aux contacts. Rien ne quitte le téléphone.",
                                style = MaterialTheme.typography.bodyMedium,
                            )
                            Button(onClick = { ask.launch(SmsStore.PERMISSIONS) }) { Text("Autoriser l'accès aux SMS") }
                        }
                    }
                }
                return@LazyColumn
            }
            item {
                OutlinedTextField(
                    query, { query = it },
                    placeholder = { Text("Rechercher dans les SMS") },
                    leadingIcon = { Icon(Icons.Filled.Search, null) },
                    trailingIcon = { if (query.isNotEmpty()) IconButton(onClick = { query = "" }) { Icon(Icons.Filled.Close, "Effacer") } },
                    singleLine = true,
                    shape = RoundedCornerShape(28.dp),
                    modifier = Modifier.fillMaxWidth(),
                )
            }
            val q = query.trim()
            if (q.length >= 2) {
                val list = threads.orEmpty()
                val byName = list.filter { t -> threadName(ctx, t.addresses).contains(q, true) || t.addresses.any { it.contains(q) } }
                if (byName.isNotEmpty()) items(byName, key = { "n" + it.id }) { t -> ThreadRow(t) { onOpen(t.id, t.addresses.firstOrNull().orEmpty()) } }
                if (found.isNotEmpty()) {
                    item { Text("Messages", style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.onSurfaceVariant) }
                    items(found, key = { "m" + it.second.id }) { (tid, m) -> FoundRow(m, q) { onOpen(tid, m.address) } }
                }
                if (byName.isEmpty() && found.isEmpty()) item { Text("Aucun résultat.", color = MaterialTheme.colorScheme.onSurfaceVariant) }
            } else {
                val list = threads
                when {
                    list == null -> item { Text("Chargement…", color = MaterialTheme.colorScheme.onSurfaceVariant) }
                    list.isEmpty() -> item { Text("Aucune conversation.", color = MaterialTheme.colorScheme.onSurfaceVariant) }
                    else -> items(list, key = { it.id }) { t -> ThreadRow(t) { onOpen(t.id, t.addresses.firstOrNull().orEmpty()) } }
                }
            }
        }
        if (allowed) ExtendedFloatingActionButton(
            onClick = onNew,
            icon = { Icon(Icons.Filled.Edit, null) },
            text = { Text("Nouveau message") },
            modifier = Modifier.align(Alignment.BottomEnd).padding(16.dp).navigationBarsPadding(),
        )
    }
}

@Composable
private fun Avatar(contact: SmsContact?, label: String, size: Int = 44) {
    val ctx = LocalContext.current
    val photo by produceState<Bitmap?>(null, contact?.photo) {
        value = contact?.photo?.let { u -> withContext(Dispatchers.IO) { uriBitmap(ctx, u, 160) } }
    }
    val p = photo
    if (p != null) {
        Image(p.asImageBitmap(), null, contentScale = ContentScale.Crop, modifier = Modifier.size(size.dp).clip(CircleShape))
    } else {
        val palette = listOf(0xFF5C6BC0, 0xFF26A69A, 0xFFEF6C00, 0xFF8E24AA, 0xFF43A047, 0xFFD81B60, 0xFF1E88E5, 0xFF6D4C41)
        val color = Color(palette[(label.hashCode() and 0x7fffffff) % palette.size])
        Box(Modifier.size(size.dp).clip(CircleShape).background(color), contentAlignment = Alignment.Center) {
            val first = label.firstOrNull { it.isLetter() }
            if (contact != null && first != null) RawText(first.uppercase(), color = Color.White, style = MaterialTheme.typography.titleMedium)
            else Icon(Icons.Filled.Person, null, tint = Color.White)
        }
    }
}

@Composable
private fun ThreadRow(t: SmsThread, onClick: () -> Unit) {
    val ctx = LocalContext.current
    val name = remember(t.addresses) { threadName(ctx, t.addresses) }
    val contact = remember(t.addresses) { if (t.addresses.size == 1) SmsStore.contact(ctx, t.addresses[0]) else null }
    Surface(onClick = onClick, shape = MaterialTheme.shapes.large, color = MaterialTheme.colorScheme.surfaceContainerLow, border = appBorder(), modifier = Modifier.fillMaxWidth()) {
        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Avatar(contact, name)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    RawText(
                        name, style = MaterialTheme.typography.titleSmall,
                        fontWeight = if (t.unread) FontWeight.Bold else FontWeight.Medium,
                        maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f),
                    )
                    RawText(
                        shortWhen(t.date), style = MaterialTheme.typography.labelSmall,
                        color = if (t.unread) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    RawText(
                        t.snippet.ifBlank { I18n.tr("(photo ou pièce jointe)") }.replace('\n', ' '),
                        style = MaterialTheme.typography.bodyMedium,
                        color = if (t.unread) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurfaceVariant,
                        fontWeight = if (t.unread) FontWeight.SemiBold else FontWeight.Normal,
                        maxLines = 2, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f),
                    )
                    if (t.unread) Box(Modifier.padding(start = 8.dp).size(10.dp).clip(CircleShape).background(MaterialTheme.colorScheme.primary))
                }
            }
        }
    }
}

@Composable
private fun FoundRow(m: SmsMessage, q: String, onClick: () -> Unit) {
    val ctx = LocalContext.current
    val name = remember(m.address) { SmsStore.contact(ctx, m.address)?.name ?: m.address }
    val hl = MaterialTheme.colorScheme.tertiaryContainer
    val text = remember(m.body, q) {
        val b = m.body.replace('\n', ' ')
        val i = b.indexOf(q, ignoreCase = true)
        val start = (i - 40).coerceAtLeast(0)
        val shown = (if (start > 0) "…" else "") + b.substring(start)
        buildAnnotatedString {
            append(shown)
            val j = shown.indexOf(q, ignoreCase = true)
            if (j >= 0) addStyle(SpanStyle(background = hl, fontWeight = FontWeight.SemiBold), j, j + q.length)
        }
    }
    Surface(onClick = onClick, shape = MaterialTheme.shapes.large, color = MaterialTheme.colorScheme.surfaceContainerLow, border = appBorder(), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp)) {
            Row {
                RawText(name, style = MaterialTheme.typography.titleSmall, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
                RawText(shortWhen(m.date), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            androidx.compose.material3.Text(text, style = MaterialTheme.typography.bodyMedium, maxLines = 3, overflow = TextOverflow.Ellipsis)
        }
    }
}

// ------------------------------------------------------------------ Conversation

/**
 * Une conversation : bulles, liens et numéros cliquables, photos des MMS, réponse par SMS.
 * [threadId] null : nouvelle conversation avec [address].
 */
@OptIn(ExperimentalMaterial3Api::class, ExperimentalFoundationApi::class)
@Composable
fun SmsThreadScreen(threadId: Long?, address: String, initialText: String = "", onBack: () -> Unit, onForward: (String) -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val version = rememberSmsVersion()
    var tid by remember { mutableStateOf(threadId) }
    // Adresses de la conversation (plusieurs pour un groupe)
    val addresses by produceState(listOfNotNull(address.takeIf { it.isNotBlank() }), tid, version) {
        val id = tid
        if (id != null) withContext(Dispatchers.IO) {
            SmsStore.threads(ctx).firstOrNull { it.id == id }?.addresses?.takeIf { it.isNotEmpty() }
        }?.let { value = it }
    }
    // Nouvelle conversation : on la retrouve dès que le premier message est enregistré
    LaunchedEffect(version, address) {
        if (tid == null && address.isNotBlank()) tid = withContext(Dispatchers.IO) { SmsStore.threadIdFor(ctx, address) }
    }
    val messages by produceState<List<SmsMessage>?>(null, tid, version) {
        val id = tid
        value = if (id == null) emptyList() else withContext(Dispatchers.IO) { SmsStore.messages(ctx, id) }
    }
    LaunchedEffect(tid, messages?.size) { tid?.let { id -> withContext(Dispatchers.IO) { SmsStore.markRead(ctx, id) } } }
    val group = addresses.size > 1
    val main = addresses.firstOrNull() ?: address
    val contact = remember(main) { if (group) null else SmsStore.contact(ctx, main) }
    val title = remember(addresses) { threadName(ctx, addresses) }
    var input by rememberSaveable { mutableStateOf(initialText) }
    var menu by remember { mutableStateOf(false) }
    var viewer by remember { mutableStateOf<Uri?>(null) }
    // Résultat de l'envoi
    DisposableEffect(Unit) {
        val r = object : BroadcastReceiver() {
            override fun onReceive(c: Context, i: Intent) {
                if (resultCode != Activity.RESULT_OK) I18n.toast(ctx, "Échec de l'envoi du SMS", Toast.LENGTH_LONG).show()
            }
        }
        ContextCompat.registerReceiver(ctx, r, IntentFilter(SmsStore.ACTION_SENT), ContextCompat.RECEIVER_NOT_EXPORTED)
        onDispose { try { ctx.unregisterReceiver(r) } catch (_: Exception) { } }
    }
    fun send(text: String) {
        val to = main
        if (text.isBlank() || to.isBlank()) return
        scope.launch {
            val ok = withContext(Dispatchers.IO) { SmsStore.send(ctx, to, text.trim()) }
            if (!ok) I18n.toast(ctx, "Envoi impossible : vérifie l'autorisation d'envoyer des SMS", Toast.LENGTH_LONG).show()
        }
    }
    val sendPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok && input.isNotBlank()) { send(input); input = "" }
    }
    BackHandler { onBack() }
    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Avatar(contact, title, 36)
                        Spacer(Modifier.width(10.dp))
                        Column {
                            RawText(title, style = MaterialTheme.typography.titleMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            if (contact != null) RawText(main, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1)
                        }
                    }
                },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Retour") } },
                actions = {
                    if (!group && main.any { it.isDigit() }) IconButton(onClick = { Actions.call(ctx, main) }) { Icon(Icons.Filled.Call, "Appeler") }
                    Box {
                        IconButton(onClick = { menu = true }) { Icon(Icons.Filled.MoreVert, "Plus") }
                        DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                            if (contact != null) DropdownMenuItem(
                                text = { Text("Voir le contact") }, leadingIcon = { Icon(Icons.Filled.Person, null) },
                                onClick = { menu = false; Actions.openContact(ctx, contact.id, contact.lookup) },
                            )
                            else if (!group && main.isNotBlank()) DropdownMenuItem(
                                text = { Text("Ajouter aux contacts") }, leadingIcon = { Icon(Icons.Filled.PersonAdd, null) },
                                onClick = { menu = false; Actions.addContact(ctx, "", main, null, null, null) },
                            )
                            if (!group && main.isNotBlank()) DropdownMenuItem(
                                text = { Text("Copier le numéro") }, leadingIcon = { Icon(Icons.Filled.ContentCopy, null) },
                                onClick = { menu = false; Actions.copy(ctx, main) },
                            )
                            DropdownMenuItem(
                                text = { Text("Ouvrir dans l'appli Messages") }, leadingIcon = { Icon(Icons.AutoMirrored.Filled.OpenInNew, null) },
                                onClick = { menu = false; openInNativeApp(ctx, tid, main) },
                            )
                        }
                    }
                },
            )
        },
    ) { pad ->
        Column(Modifier.fillMaxSize().padding(pad).imePadding()) {
            val list = messages.orEmpty()
            val state = rememberLazyListState()
            LaunchedEffect(list.size) { if (list.isNotEmpty()) state.scrollToItem(0) }
            LazyColumn(
                Modifier.weight(1f).fillMaxWidth(),
                state = state,
                reverseLayout = true,
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp),
            ) {
                val rev = list.asReversed()
                items(rev.size, key = { i -> (if (rev[i].mms) "m" else "s") + rev[i].id }) { i ->
                    val m = rev[i]
                    val older = rev.getOrNull(i + 1)
                    Column {
                        if (older == null || !sameDay(older.date, m.date)) {
                            RawText(
                                dayLabel(m.date), style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.align(Alignment.CenterHorizontally).padding(vertical = 10.dp),
                            )
                        }
                        Bubble(
                            m, showSender = group && m.incoming,
                            onImage = { viewer = it },
                            onForward = onForward,
                            onRetry = { send(m.body) },
                        )
                    }
                }
                if (messages != null && list.isEmpty()) item {
                    Text(
                        if (tid == null) "Nouvelle conversation" else "Aucun message",
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.fillMaxWidth().padding(24.dp),
                    )
                }
            }
            HorizontalDivider()
            if (group) {
                Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("Conversation de groupe : réponds depuis l'appli Messages.", style = MaterialTheme.typography.bodySmall, modifier = Modifier.weight(1f))
                    IconButton(onClick = { openInNativeApp(ctx, tid, main) }) { Icon(Icons.AutoMirrored.Filled.OpenInNew, "Ouvrir dans l'appli Messages") }
                }
            } else {
                val parts = remember(input) { if (input.length > 60) SmsStore.parts(ctx, input) else 1 }
                val counter: (@Composable () -> Unit)? = if (input.length > 60) {
                    { RawText("${input.length} · " + (if (parts > 1) I18n.tr("%d SMS").replace("%d", parts.toString()) else "1 SMS")) }
                } else null
                Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 6.dp).navigationBarsPadding(), verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(
                        input, { input = it },
                        placeholder = { Text("Message") },
                        shape = RoundedCornerShape(24.dp),
                        maxLines = 6,
                        keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Sentences),
                        supportingText = counter,
                        modifier = Modifier.weight(1f),
                    )
                    IconButton(
                        enabled = input.isNotBlank() && main.isNotBlank(),
                        onClick = {
                            if (!SmsStore.canSend(ctx)) sendPerm.launch(android.Manifest.permission.SEND_SMS)
                            else { send(input); input = "" }
                        },
                    ) { Icon(Icons.AutoMirrored.Filled.Send, "Envoyer", tint = if (input.isNotBlank()) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant) }
                }
            }
        }
    }
    viewer?.let { u -> ImageViewer(u) { viewer = null } }
}

/** Ouvre la conversation dans l'appli SMS par défaut du téléphone. */
private fun openInNativeApp(ctx: Context, threadId: Long?, address: String) {
    val pkg = SmsStore.defaultApp(ctx)
    val i = if (threadId != null) Intent(Intent.ACTION_VIEW, Uri.parse("content://mms-sms/conversations/$threadId"))
    else Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:" + Uri.encode(address)))
    if (pkg != null) i.setPackage(pkg)
    try { ctx.startActivity(i) } catch (_: Exception) { Actions.sms(ctx, address) }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun Bubble(m: SmsMessage, showSender: Boolean, onImage: (Uri) -> Unit, onForward: (String) -> Unit, onRetry: () -> Unit) {
    val ctx = LocalContext.current
    var menu by remember { mutableStateOf(false) }
    val cs = MaterialTheme.colorScheme
    val bg = when {
        m.failed -> cs.errorContainer
        m.incoming -> cs.surfaceContainerHigh
        else -> cs.primaryContainer
    }.bubble()
    val fg = when {
        m.failed -> cs.onErrorContainer
        m.incoming -> cs.onSurface
        else -> cs.onPrimaryContainer
    }
    val linkColor = if (m.incoming) cs.primary else cs.onPrimaryContainer
    val text = remember(m.body, linkColor) { linkedBody(ctx, m.body, linkColor) }
    Box(Modifier.fillMaxWidth(), contentAlignment = if (m.incoming) Alignment.CenterStart else Alignment.CenterEnd) {
        Column(horizontalAlignment = if (m.incoming) Alignment.Start else Alignment.End) {
            if (showSender && m.address.isNotBlank()) {
                RawText(SmsStore.contact(ctx, m.address)?.name ?: m.address, style = MaterialTheme.typography.labelSmall, color = cs.primary, modifier = Modifier.padding(start = 12.dp, bottom = 2.dp))
            }
            Surface(
                shape = RoundedCornerShape(
                    topStart = 18.dp, topEnd = 18.dp,
                    bottomStart = if (m.incoming) 4.dp else 18.dp, bottomEnd = if (m.incoming) 18.dp else 4.dp,
                ),
                color = bg,
                modifier = Modifier
                    .widthIn(max = 300.dp)
                    .clip(RoundedCornerShape(18.dp))
                    .combinedClickable(onClick = { if (m.failed) onRetry() }, onLongClick = { menu = true }),
            ) {
                Column(Modifier.padding(horizontal = 12.dp, vertical = 8.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    m.images.forEach { u -> MmsImage(u) { onImage(u) } }
                    if (m.body.isNotBlank()) androidx.compose.material3.Text(text, color = fg, style = MaterialTheme.typography.bodyLarge)
                }
            }
            Row(Modifier.padding(horizontal = 6.dp, vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
                if (m.failed) {
                    Icon(Icons.Filled.ErrorOutline, null, tint = cs.error, modifier = Modifier.size(14.dp))
                    Spacer(Modifier.width(4.dp))
                    Text("Non envoyé · toucher pour renvoyer", style = MaterialTheme.typography.labelSmall, color = cs.error)
                } else {
                    RawText(
                        SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(m.date)) + if (m.pending) " · " + I18n.tr("Envoi…") else "",
                        style = MaterialTheme.typography.labelSmall, color = cs.onSurfaceVariant,
                    )
                }
            }
            DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                if (m.body.isNotBlank()) {
                    DropdownMenuItem(text = { Text("Copier") }, leadingIcon = { Icon(Icons.Filled.ContentCopy, null) }, onClick = { menu = false; Actions.copy(ctx, m.body) })
                    DropdownMenuItem(text = { Text("Transférer") }, leadingIcon = { Icon(Icons.AutoMirrored.Filled.Forward, null) }, onClick = { menu = false; onForward(m.body) })
                    DropdownMenuItem(text = { Text("Partager") }, leadingIcon = { Icon(Icons.Filled.Share, null) }, onClick = { menu = false; Actions.share(ctx, "", m.body) })
                }
                if (m.failed) DropdownMenuItem(text = { Text("Renvoyer") }, leadingIcon = { Icon(Icons.AutoMirrored.Filled.Send, null) }, onClick = { menu = false; onRetry() })
            }
        }
    }
}

/** Texte d'un SMS avec liens, numéros et adresses mail cliquables. */
private fun linkedBody(ctx: Context, body: String, color: Color): AnnotatedString {
    val entities = try { EntityDetector.detect(body).filter { it.type == EntityType.URL || it.type == EntityType.PHONE || it.type == EntityType.EMAIL } } catch (_: Exception) { emptyList() }
    if (entities.isEmpty()) return AnnotatedString(body)
    val style = TextLinkStyles(SpanStyle(color = color, textDecoration = TextDecoration.Underline))
    return buildAnnotatedString {
        var pos = 0
        entities.sortedBy { it.start }.forEach { e ->
            if (e.start < pos || e.end > body.length) return@forEach
            append(body.substring(pos, e.start))
            withLink(LinkAnnotation.Clickable("l${e.start}", style, LinkInteractionListener {
                when (e.type) {
                    EntityType.PHONE -> Actions.dial(ctx, e.value)
                    EntityType.EMAIL -> Actions.email(ctx, e.value, "")
                    else -> Actions.openUrl(ctx, e.value.let { v -> if (v.contains("://")) v else "https://$v" })
                }
            })) { append(body.substring(e.start, e.end)) }
            pos = e.end
        }
        append(body.substring(pos))
    }
}

/** Image d'un fichier du téléphone, réduite à [maxSide] pixels. */
private fun uriBitmap(ctx: Context, uri: Uri, maxSide: Int): Bitmap? = try {
    val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o) }
    var sample = 1
    while (o.outWidth / (sample * 2) >= maxSide || o.outHeight / (sample * 2) >= maxSide) sample *= 2
    ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = sample }) }
} catch (_: Exception) { null }

@Composable
private fun MmsImage(uri: Uri, onClick: () -> Unit) {
    val ctx = LocalContext.current
    val bmp by produceState<Bitmap?>(null, uri) { value = withContext(Dispatchers.IO) { uriBitmap(ctx, uri, 600) } }
    val b = bmp
    if (b != null) Image(
        b.asImageBitmap(), null, contentScale = ContentScale.Fit,
        modifier = Modifier.widthIn(max = 260.dp).heightIn(max = 320.dp).clip(RoundedCornerShape(12.dp)).clickable(onClick = onClick),
    )
    else Box(Modifier.size(120.dp).clip(RoundedCornerShape(12.dp)).background(MaterialTheme.colorScheme.surfaceVariant))
}

@Composable
private fun ImageViewer(uri: Uri, onClose: () -> Unit) {
    val ctx = LocalContext.current
    val bmp by produceState<Bitmap?>(null, uri) { value = withContext(Dispatchers.IO) { uriBitmap(ctx, uri, 2048) } }
    Dialog(onDismissRequest = onClose, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Box(Modifier.fillMaxSize().background(Color.Black).clickable(onClick = onClose), contentAlignment = Alignment.Center) {
            bmp?.let { Image(it.asImageBitmap(), null, contentScale = ContentScale.Fit, modifier = Modifier.fillMaxSize()) }
            IconButton(onClick = onClose, modifier = Modifier.align(Alignment.TopEnd).padding(12.dp)) { Icon(Icons.Filled.Close, "Fermer", tint = Color.White) }
        }
    }
}

// ------------------------------------------------------------------ Nouveau message

/** Choix du destinataire d'un nouveau SMS : contact ou numéro tapé. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SmsNewScreen(onPick: (String) -> Unit, onBack: () -> Unit) {
    val ctx = LocalContext.current
    var q by rememberSaveable { mutableStateOf("") }
    val found by produceState<List<Pair<String, String>>>(emptyList(), q) {
        value = withContext(Dispatchers.IO) { delay(150); SmsStore.findContacts(ctx, q) }
    }
    val typedNumber = q.trim().takeIf { s -> s.count { it.isDigit() } >= 3 && s.all { it.isDigit() || it in "+ ()-." } }
    BackHandler { onBack() }
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Nouveau message") },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Retour") } },
            )
        },
    ) { pad ->
        LazyColumn(Modifier.fillMaxSize().padding(pad).imePadding(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            item {
                OutlinedTextField(
                    q, { q = it },
                    label = { Text("À : nom ou numéro") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Text),
                    modifier = Modifier.fillMaxWidth(),
                )
            }
            if (typedNumber != null) item {
                Surface(onClick = { onPick(typedNumber.filter { it.isDigit() || it == '+' }) }, shape = MaterialTheme.shapes.large, color = MaterialTheme.colorScheme.secondaryContainer.bubble(), modifier = Modifier.fillMaxWidth()) {
                    Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Filled.Sms, null)
                        Spacer(Modifier.width(10.dp))
                        RawText(I18n.tr("Envoyer à") + " " + typedNumber)
                    }
                }
            }
            items(found, key = { it.second }) { (name, number) ->
                Surface(onClick = { onPick(number) }, shape = MaterialTheme.shapes.large, color = MaterialTheme.colorScheme.surfaceContainerLow, border = appBorder(), modifier = Modifier.fillMaxWidth()) {
                    Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Avatar(SmsStore.contact(ctx, number), name, 40)
                        Spacer(Modifier.width(12.dp))
                        Column {
                            RawText(name, style = MaterialTheme.typography.titleSmall)
                            RawText(number, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }
        }
    }
}
