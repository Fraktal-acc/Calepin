package fr.jeremy.calepin.control

import android.content.Context
import android.hardware.ConsumerIrManager
import kotlinx.coroutines.delay

/**
 * Télécommande infrarouge pour les téléphones qui ont un émetteur (beaucoup de Xiaomi, Redmi, Poco, Honor…).
 * Les codes sont produits ici à partir des protocoles des grandes marques (NEC, Samsung, Sony SIRC, Philips RC5).
 */
object Infrared {
    fun manager(ctx: Context): ConsumerIrManager? =
        (ctx.applicationContext.getSystemService(Context.CONSUMER_IR_SERVICE) as? ConsumerIrManager)?.takeIf { runCatching { it.hasIrEmitter() }.getOrDefault(false) }

    fun available(ctx: Context) = manager(ctx) != null

    /** Une marque : protocole, adresse et codes des touches. */
    enum class Brand(val label: String, val protocol: Protocol, val address: Int, val codes: Map<RemoteKey, Int>) {
        SAMSUNG(
            "Samsung", Protocol.SAMSUNG32, 0x07,
            mapOf(
                RemoteKey.POWER to 0x02, RemoteKey.VOL_UP to 0x07, RemoteKey.VOL_DOWN to 0x0B, RemoteKey.MUTE to 0x0F,
                RemoteKey.CH_UP to 0x12, RemoteKey.CH_DOWN to 0x10, RemoteKey.UP to 0x60, RemoteKey.DOWN to 0x61,
                RemoteKey.LEFT to 0x65, RemoteKey.RIGHT to 0x62, RemoteKey.OK to 0x68, RemoteKey.MENU to 0x1A,
                RemoteKey.BACK to 0x58, RemoteKey.HOME to 0x79, RemoteKey.INPUT to 0x01, RemoteKey.GUIDE to 0x4F,
                RemoteKey.INFO to 0x1F, RemoteKey.PLAY_PAUSE to 0x47, RemoteKey.REWIND to 0x45, RemoteKey.FORWARD to 0x48,
                RemoteKey.D1 to 0x04, RemoteKey.D2 to 0x05, RemoteKey.D3 to 0x06, RemoteKey.D4 to 0x08, RemoteKey.D5 to 0x09,
                RemoteKey.D6 to 0x0A, RemoteKey.D7 to 0x0C, RemoteKey.D8 to 0x0D, RemoteKey.D9 to 0x0E, RemoteKey.D0 to 0x11,
            ),
        ),
        LG(
            "LG", Protocol.NEC, 0x04,
            mapOf(
                RemoteKey.POWER to 0x08, RemoteKey.VOL_UP to 0x02, RemoteKey.VOL_DOWN to 0x03, RemoteKey.MUTE to 0x09,
                RemoteKey.CH_UP to 0x00, RemoteKey.CH_DOWN to 0x01, RemoteKey.UP to 0x40, RemoteKey.DOWN to 0x41,
                RemoteKey.LEFT to 0x07, RemoteKey.RIGHT to 0x06, RemoteKey.OK to 0x44, RemoteKey.BACK to 0x28,
                RemoteKey.HOME to 0x7C, RemoteKey.MENU to 0x43, RemoteKey.INPUT to 0x0B, RemoteKey.GUIDE to 0xA9,
                RemoteKey.INFO to 0xAA, RemoteKey.PLAY_PAUSE to 0xB0, RemoteKey.REWIND to 0x8F, RemoteKey.FORWARD to 0x8E,
            ) + (0..9).associate { RemoteKey.digit(it) to 0x10 + it },
        ),
        SONY(
            "Sony", Protocol.SIRC12, 0x01,
            mapOf(
                RemoteKey.POWER to 21, RemoteKey.VOL_UP to 18, RemoteKey.VOL_DOWN to 19, RemoteKey.MUTE to 20,
                RemoteKey.CH_UP to 16, RemoteKey.CH_DOWN to 17, RemoteKey.UP to 116, RemoteKey.DOWN to 117,
                RemoteKey.LEFT to 52, RemoteKey.RIGHT to 51, RemoteKey.OK to 101, RemoteKey.INPUT to 37,
                RemoteKey.HOME to 96, RemoteKey.INFO to 58,
            ) + (1..9).associate { RemoteKey.digit(it) to it - 1 } + (RemoteKey.D0 to 9),
        ),
        PHILIPS(
            "Philips", Protocol.RC5, 0x00,
            mapOf(
                RemoteKey.POWER to 12, RemoteKey.VOL_UP to 16, RemoteKey.VOL_DOWN to 17, RemoteKey.MUTE to 13,
                RemoteKey.CH_UP to 32, RemoteKey.CH_DOWN to 33, RemoteKey.UP to 80, RemoteKey.DOWN to 81,
                RemoteKey.LEFT to 85, RemoteKey.RIGHT to 86, RemoteKey.OK to 87, RemoteKey.MENU to 82, RemoteKey.INFO to 15,
            ) + (0..9).associate { RemoteKey.digit(it) to it },
        ),
    }

    enum class Protocol(val carrier: Int) { NEC(38_000), SAMSUNG32(38_000), SIRC12(40_000), RC5(36_000) }

    private var rc5Toggle = false

    /** Durées en microsecondes, alternance émission / silence, en commençant par une émission. */
    fun pattern(brand: Brand, code: Int): IntArray = when (brand.protocol) {
        Protocol.NEC -> nec(9000, 4500, brand.address, brand.address.inv() and 0xFF, code)
        Protocol.SAMSUNG32 -> nec(4500, 4500, brand.address, brand.address, code)
        Protocol.SIRC12 -> sirc(code, brand.address)
        Protocol.RC5 -> rc5(brand.address, code)
    }

    private fun nec(leadOn: Int, leadOff: Int, a1: Int, a2: Int, cmd: Int): IntArray {
        val out = mutableListOf(leadOn, leadOff)
        val bytes = listOf(a1, a2, cmd and 0xFF, cmd.inv() and 0xFF)
        for (b in bytes) for (i in 0 until 8) {
            out += 562
            out += if ((b shr i) and 1 == 1) 1687 else 562
        }
        out += 562
        out += 40_000 // silence de fin de trame
        return out.toIntArray()
    }

    private fun sirc(cmd: Int, dev: Int): IntArray {
        val frame = mutableListOf(2400, 600)
        val bits = (0 until 7).map { (cmd shr it) and 1 } + (0 until 5).map { (dev shr it) and 1 }
        bits.forEach { frame += if (it == 1) 1200 else 600; frame += 600 }
        // Une trame dure 45 ms ; Sony demande de l'envoyer trois fois
        val used = frame.sum()
        frame[frame.lastIndex] += (45_000 - used).coerceAtLeast(600)
        return (frame + frame + frame).toIntArray()
    }

    private fun rc5(addr: Int, cmd: Int): IntArray {
        rc5Toggle = !rc5Toggle
        val bits = mutableListOf(1, if (cmd < 64) 1 else 0, if (rc5Toggle) 1 else 0)
        for (i in 4 downTo 0) bits += (addr shr i) and 1
        for (i in 5 downTo 0) bits += (cmd shr i) and 1
        // Codage Manchester : 1 = silence puis émission, 0 = émission puis silence (889 µs chacun)
        val levels = bits.flatMap { if (it == 1) listOf(false, true) else listOf(true, false) }.dropWhile { !it }
        val out = mutableListOf<Int>()
        var cur = levels.first()
        var len = 0
        for (l in levels) {
            if (l == cur) len += 889 else { out += len; cur = l; len = 889 }
        }
        out += len
        if (!cur) out[out.lastIndex] += 90_000 else out += 90_000
        return out.toIntArray()
    }

    fun send(ctx: Context, brand: Brand, key: RemoteKey): Boolean {
        val ir = manager(ctx) ?: return false
        val code = brand.codes[key] ?: return false
        return runCatching { ir.transmit(brand.protocol.carrier, pattern(brand, code)); true }.getOrDefault(false)
    }

    fun brandOf(d: HomeDevice): Brand = runCatching { Brand.valueOf(d.extraJson.optString("brand")) }.getOrDefault(Brand.SAMSUNG)
}

/** Télécommande à l'écran par infrarouge. */
class IrRemote(private val ctx: Context, private val brand: Infrared.Brand) : RemoteSession {
    override val keys = brand.codes.keys
    override suspend fun press(k: RemoteKey) = Infrared.send(ctx, brand, k)
    override val lastError: String?
        get() = if (!Infrared.available(ctx)) "ce téléphone n'a pas d'émetteur infrarouge" else "vise la télé avec le haut du téléphone"
}

/** Commandes vocales par infrarouge (« allume la télé », « monte le son »…). */
class IrTv(private val ctx: Context, private val brand: Infrared.Brand) : TvControl {
    private fun k(key: RemoteKey) = Infrared.send(ctx, brand, key)
    override suspend fun power(on: Boolean) = k(RemoteKey.POWER)
    override suspend fun volume(steps: Int): Boolean {
        if (steps == 0) return k(RemoteKey.MUTE)
        repeat(kotlin.math.abs(steps).coerceAtMost(15)) { if (!k(if (steps > 0) RemoteKey.VOL_UP else RemoteKey.VOL_DOWN)) return false; delay(180) }
        return true
    }
    override suspend fun channel(number: Int, named: OrangeDecoder.Channel?): Boolean {
        number.toString().forEach { c -> if (!k(RemoteKey.digit(c.digitToInt()))) return false; delay(350) }
        return true
    }
    override suspend fun channelStep(up: Boolean) = k(if (up) RemoteKey.CH_UP else RemoteKey.CH_DOWN)
    override suspend fun playPause() = k(RemoteKey.PLAY_PAUSE)
}
