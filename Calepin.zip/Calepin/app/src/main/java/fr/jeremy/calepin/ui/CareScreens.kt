package fr.jeremy.calepin.ui

import android.Manifest
import android.app.TimePickerDialog
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowLeft
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.Alarm
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.DeleteForever
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.MyLocation
import androidx.compose.material.icons.filled.Place
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.Restore
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.TableChart
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import fr.jeremy.calepin.Files
import fr.jeremy.calepin.NotesViewModel
import fr.jeremy.calepin.care.CrashLog
import fr.jeremy.calepin.care.MonthHours
import fr.jeremy.calepin.care.PlaceReminder
import fr.jeremy.calepin.care.PlaceReminders
import fr.jeremy.calepin.care.PlanningLog
import fr.jeremy.calepin.care.WakeAlarm
import fr.jeremy.calepin.care.WorkHours
import fr.jeremy.calepin.data.Note
import fr.jeremy.calepin.export.SimplePdf
import fr.jeremy.calepin.i18n.I18n
import fr.jeremy.calepin.i18n.RawText
import fr.jeremy.calepin.i18n.Text
import fr.jeremy.calepin.reminders.Reminders
import fr.jeremy.calepin.ui.tools.ToolHint
import fr.jeremy.calepin.ui.tools.ToolScaffold
import fr.jeremy.calepin.weather.WeatherPlace
import fr.jeremy.calepin.weather.WeatherRepo
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date

// ------------------------------------------------------------------ Petits éléments communs

/** « 21h00 » (ou « 21:00 » hors français). */
internal fun hhmm(min: Int): String {
    val m = ((min % 1440) + 1440) % 1440
    return "%d:%02d".format(m / 60, m % 60).let { if (I18n.language.value.code == "fr") it.replace(":", "h") else it }
}

/** Bouton qui affiche une heure et ouvre l'horloge d'Android pour la changer. */
@Composable
internal fun TimeButton(label: String, minutes: Int, onPick: (Int) -> Unit) {
    val ctx = LocalContext.current
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(label, style = MaterialTheme.typography.bodyLarge, modifier = Modifier.weight(1f))
        OutlinedButton(onClick = {
            TimePickerDialog(ctx, { _, h, m -> onPick(h * 60 + m) }, minutes / 60, minutes % 60, true).show()
        }) { RawText(hhmm(minutes)) }
    }
}

/** Valeur réglable par « − » et « + ». */
@Composable
internal fun StepRow(label: String, value: String, onMinus: () -> Unit, onPlus: () -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(label, style = MaterialTheme.typography.bodyLarge, modifier = Modifier.weight(1f))
        OutlinedButton(onClick = onMinus, modifier = Modifier.size(44.dp), contentPadding = androidx.compose.foundation.layout.PaddingValues(0.dp)) { RawText("−") }
        RawText(value, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(horizontal = 12.dp))
        OutlinedButton(onClick = onPlus, modifier = Modifier.size(44.dp), contentPadding = androidx.compose.foundation.layout.PaddingValues(0.dp)) { RawText("+") }
    }
}

@Composable
private fun ToggleRow(title: String, subtitle: String?, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.bodyLarge)
            if (subtitle != null) Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

/** Carte d'un chiffre clé : « 151 h · Total ». */
@Composable
private fun StatTile(value: String, label: String, modifier: Modifier = Modifier) {
    Surface(shape = MaterialTheme.shapes.medium, color = MaterialTheme.colorScheme.surfaceContainerHigh, modifier = modifier) {
        Column(Modifier.padding(horizontal = 12.dp, vertical = 10.dp)) {
            RawText(value, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary, maxLines = 1)
            Text(label, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1)
        }
    }
}

@Composable
private fun InfoCard(content: @Composable () -> Unit) {
    Surface(shape = MaterialTheme.shapes.large, color = MaterialTheme.colorScheme.surfaceContainerLow, border = appBorder(), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) { content() }
    }
}

// ------------------------------------------------------------------ Journal des plantages

/** Erreurs enregistrées par Calepin (plantages et échecs en arrière-plan), à partager pour corriger. */
@Composable
fun CrashLogScreen(onClose: () -> Unit) {
    val ctx = LocalContext.current
    var text by remember { mutableStateOf(CrashLog.read(ctx)) }
    var confirm by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { CrashLog.markSeen(ctx) }
    ToolScaffold("Journal des plantages", onClose, actions = {
        if (text.isNotBlank()) {
            IconButton(onClick = { Files.shareBytes(ctx, text.toByteArray(), "calepin-plantages.txt", "text/plain") }) { Icon(Icons.Filled.Share, "Partager") }
            IconButton(onClick = { confirm = true }) { Icon(Icons.Filled.Delete, "Effacer") }
        }
    }) {
        ToolHint("Quand Calepin plante ou qu'une tâche automatique échoue (sauvegarde, réveil…), le détail est noté ici. Partage-le pour qu'on corrige le problème : il ne contient pas le texte de tes notes.")
        if (text.isBlank()) {
            InfoCard { Text("Aucun plantage enregistré. 👍") }
        } else {
            Text(I18n.trf("{0} erreur(s) enregistrée(s)", CrashLog.count(ctx)), style = MaterialTheme.typography.titleSmall)
            Surface(shape = MaterialTheme.shapes.medium, color = MaterialTheme.colorScheme.surfaceContainerHighest, modifier = Modifier.fillMaxWidth()) {
                androidx.compose.foundation.text.selection.SelectionContainer {
                    androidx.compose.material3.Text(text.take(60_000), fontFamily = FontFamily.Monospace, fontSize = 11.sp, modifier = Modifier.padding(10.dp))
                }
            }
        }
    }
    if (confirm) {
        AlertDialog(
            onDismissRequest = { confirm = false },
            title = { Text("Effacer le journal ?") },
            confirmButton = { TextButton(onClick = { CrashLog.clear(ctx); text = ""; confirm = false }) { Text("Effacer") } },
            dismissButton = { TextButton(onClick = { confirm = false }) { Text("Annuler") } },
        )
    }
}

// ------------------------------------------------------------------ Corbeille

/** Notes supprimées : gardées 30 jours, puis effacées pour de bon. */
@Composable
fun TrashScreen(vm: NotesViewModel, onClose: () -> Unit) {
    var items by remember { mutableStateOf<List<Pair<Note, Long>>?>(null) }
    var version by remember { mutableIntStateOf(0) }
    var emptyAll by remember { mutableStateOf(false) }
    LaunchedEffect(version) { items = vm.trash() }
    val list = items.orEmpty()
    val f = remember { SimpleDateFormat(I18n.pattern("d MMMM 'à' HH'h'mm"), I18n.locale) }
    ToolScaffold("Corbeille", onClose, actions = {
        if (list.isNotEmpty()) IconButton(onClick = { emptyAll = true }) { Icon(Icons.Filled.DeleteForever, "Vider la corbeille") }
    }) {
        ToolHint("Les notes supprimées restent ici 30 jours : tu peux les remettre à leur place ou les effacer définitivement.")
        if (items == null) LinearProgressIndicator(Modifier.fillMaxWidth())
        else if (list.isEmpty()) InfoCard { Text("La corbeille est vide.") }
        list.forEach { (n, at) ->
            val left = (30 - ((System.currentTimeMillis() - at) / 86_400_000L)).coerceAtLeast(0)
            InfoCard {
                RawText(n.title.ifBlank { n.content.lineSequence().firstOrNull { it.isNotBlank() }?.take(60) ?: I18n.tr("Sans titre") }, style = MaterialTheme.typography.titleMedium, maxLines = 1)
                if (n.content.isNotBlank()) RawText(n.content.take(140).replace('\n', ' '), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 2)
                RawText(I18n.trf("Supprimée le {0} · effacée dans {1} jour(s)", f.format(Date(at)), left), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { vm.restoreNote(n.id); items = list.filter { it.first.id != n.id } }) {
                        Icon(Icons.Filled.Restore, null, Modifier.size(18.dp)); Text("  Restaurer")
                    }
                    TextButton(onClick = { vm.destroy(listOf(n.id)); items = list.filter { it.first.id != n.id } }) { Text("Effacer définitivement") }
                }
            }
        }
    }
    if (emptyAll) {
        AlertDialog(
            onDismissRequest = { emptyAll = false },
            title = { Text("Vider la corbeille ?") },
            text = { Text(I18n.trf("{0} note(s) seront effacées définitivement.", list.size)) },
            confirmButton = { TextButton(onClick = { vm.destroy(list.map { it.first.id }); items = emptyList(); emptyAll = false }) { Text("Vider") } },
            dismissButton = { TextButton(onClick = { emptyAll = false }) { Text("Annuler") } },
        )
    }
}

// ------------------------------------------------------------------ Heures de travail

/** Relevé d'heures du mois (total, nuit, dimanches, fériés, heures au-delà du contrat), réveil automatique et changements de planning. */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun WorkHoursScreen(vm: NotesViewModel, onClose: () -> Unit) {
    val ctx = LocalContext.current
    val events by vm.events.collectAsStateWithLifecycle()
    val now = remember { Calendar.getInstance() }
    var ym by rememberSaveable { mutableIntStateOf(now.get(Calendar.YEAR) * 12 + now.get(Calendar.MONTH)) }
    var weekly by remember { mutableIntStateOf(WorkHours.weeklyMinutes(ctx)) }
    var ns by remember { mutableIntStateOf(WorkHours.nightStart(ctx)) }
    var ne by remember { mutableIntStateOf(WorkHours.nightEnd(ctx)) }
    val year = ym / 12
    val month = ym % 12
    val m = remember(events, ym, weekly, ns, ne) { WorkHours.month(events, year, month, weekly, ns, ne) }
    val monthName = remember(ym) {
        SimpleDateFormat(I18n.pattern("MMMM yyyy"), I18n.locale).format(Calendar.getInstance().apply { clear(); set(year, month, 1) }.time).replaceFirstChar { it.uppercase() }
    }
    fun saveRules() = WorkHours.setRules(ctx, weekly, ns, ne)

    ToolScaffold("Heures de travail", onClose) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = { ym-- }) { Icon(Icons.AutoMirrored.Filled.KeyboardArrowLeft, "Mois précédent") }
            RawText(monthName, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f), textAlign = androidx.compose.ui.text.style.TextAlign.Center)
            IconButton(onClick = { ym++ }) { Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, "Mois suivant") }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            StatTile(WorkHours.hm(m.total), "Total", Modifier.weight(1f))
            StatTile("${m.shifts.size}", "Vacations", Modifier.weight(1f))
            StatTile(WorkHours.hm(m.over), "Au-delà du contrat", Modifier.weight(1f))
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            StatTile(WorkHours.hm(m.night), "Nuit", Modifier.weight(1f))
            StatTile(WorkHours.hm(m.sunday), "Dimanches", Modifier.weight(1f))
            StatTile(WorkHours.hm(m.holiday), "Jours fériés", Modifier.weight(1f))
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = { Files.shareBytes(ctx, workHoursPdf(m, monthName, weekly, ns, ne), "heures-$year-${"%02d".format(month + 1)}.pdf", "application/pdf") }, modifier = Modifier.weight(1f)) {
                Icon(Icons.Filled.PictureAsPdf, null, Modifier.size(18.dp)); Text("  PDF")
            }
            OutlinedButton(onClick = { Files.shareBytes(ctx, ("﻿" + WorkHours.csv(m)).toByteArray(), "heures-$year-${"%02d".format(month + 1)}.csv", "text/csv") }, modifier = Modifier.weight(1f)) {
                Icon(Icons.Filled.TableChart, null, Modifier.size(18.dp)); Text("  Tableur")
            }
        }
        if (m.shifts.isEmpty()) {
            ToolHint("Aucune vacation ce mois-ci. Les vacations sont les rendez-vous de la catégorie « Travail » de l'agenda (ajoutés à la main ou par l'import du planning).")
        }

        FoldSection("Semaines", Icons.Filled.BarChart, summary = I18n.trf("Contrat : {0} par semaine", WorkHours.hm(weekly))) {
            val wf = SimpleDateFormat(I18n.pattern("d MMM"), I18n.locale)
            m.weeks.forEach { w ->
                Row(verticalAlignment = Alignment.CenterVertically) {
                    RawText(I18n.trf("Semaine du {0}", wf.format(Date(w.monday))), modifier = Modifier.weight(1f))
                    RawText(WorkHours.hm(w.minutes), fontWeight = FontWeight.SemiBold)
                    if (w.over > 0) RawText("  +" + WorkHours.hm(w.over), color = MaterialTheme.colorScheme.error, fontWeight = FontWeight.SemiBold)
                }
            }
        }
        if (m.shifts.isNotEmpty()) {
            FoldSection("Détail des vacations", Icons.Filled.History, summary = I18n.trf("{0} vacation(s)", m.shifts.size)) {
                val df = SimpleDateFormat(I18n.pattern("EEE d"), I18n.locale)
                val tf = SimpleDateFormat(I18n.pattern("HH'h'mm"), I18n.locale)
                m.shifts.forEach { s ->
                    Column {
                        Row {
                            RawText(df.format(Date(s.start)).replaceFirstChar { it.uppercase() } + " · " + tf.format(Date(s.start)) + "–" + tf.format(Date(s.end)), modifier = Modifier.weight(1f))
                            RawText(WorkHours.hm(s.minutes), fontWeight = FontWeight.SemiBold)
                        }
                        val extra = listOfNotNull(
                            s.night.takeIf { it > 0 }?.let { I18n.trf("nuit {0}", WorkHours.hm(it)) },
                            s.sunday.takeIf { it > 0 }?.let { I18n.trf("dimanche {0}", WorkHours.hm(it)) },
                            s.holiday.takeIf { it > 0 }?.let { I18n.trf("férié {0}", WorkHours.hm(it)) },
                        )
                        if (extra.isNotEmpty()) RawText(extra.joinToString(" · "), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }

        FoldSection("Règles du contrat", Icons.Filled.Tune, summary = I18n.trf("Nuit de {0} à {1}", hhmm(ns), hhmm(ne))) {
            StepRow("Durée par semaine", WorkHours.hm(weekly), { weekly = (weekly - 30).coerceAtLeast(60); saveRules() }, { weekly = (weekly + 30).coerceAtMost(80 * 60); saveRules() })
            TimeButton("Début des heures de nuit", ns) { ns = it; saveRules() }
            TimeButton("Fin des heures de nuit", ne) { ne = it; saveRules() }
            ToolHint("Les heures au-delà du contrat sont comptées par semaine entière (du lundi au dimanche). Les jours fériés sont ceux de France.")
        }

        WakeAlarmSection(events)

        FoldSection("Changements de planning", Icons.Filled.History, summary = "Ce que chaque import a modifié") {
            val log = remember { PlanningLog.all(ctx) }
            val lf = SimpleDateFormat(I18n.pattern("d MMM yyyy 'à' HH'h'mm"), I18n.locale)
            if (log.isEmpty()) ToolHint("Aucun import de planning pour l'instant. Quand un nouveau planning change une vacation à venir, tu reçois une notification.")
            log.forEach { e ->
                Column {
                    RawText(I18n.trf("Import du {0}", lf.format(Date(e.time))), style = MaterialTheme.typography.titleSmall)
                    RawText(I18n.trf("{0} ajoutée(s), {1} modifiée(s), {2} retirée(s)", e.added, e.changed, e.removed), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    e.details.take(12).forEach { RawText("• " + I18n.tr(it.substringBefore(" : ") + " :") + " " + it.substringAfter(" : "), style = MaterialTheme.typography.bodySmall) }
                }
            }
        }
    }
}

/** Réveil réglé tout seul avant chaque vacation. */
@Composable
private fun WakeAlarmSection(events: List<fr.jeremy.calepin.data.Event>) {
    val ctx = LocalContext.current
    var on by remember { mutableStateOf(WakeAlarm.enabled(ctx)) }
    var prep by remember { mutableIntStateOf(WakeAlarm.prep(ctx)) }
    var travel by remember { mutableIntStateOf(WakeAlarm.travel(ctx)) }
    var before by remember { mutableIntStateOf(WakeAlarm.before(ctx)) }
    var ring by remember { mutableStateOf(WakeAlarm.ringtone(ctx)) }
    var picker by remember { mutableStateOf(false) }
    fun save() = WakeAlarm.set(ctx, on, prep, travel, before, ring)
    FoldSection("Réveil avant chaque vacation", Icons.Filled.Alarm, summary = if (on) I18n.trf("Activé · {0} avant la prise de poste", WorkHours.hm(prep + travel)) else I18n.tr("Désactivé")) {
        ToggleRow("Réveil automatique", "Réglé chaque soir pour la vacation du lendemain, rien les jours de repos", on) { on = it; save() }
        if (on) {
            StepRow("Préparation", WorkHours.hm(prep), { prep = (prep - 5).coerceAtLeast(0); save() }, { prep = (prep + 5).coerceAtMost(240); save() })
            StepRow("Trajet", WorkHours.hm(travel), { travel = (travel - 5).coerceAtLeast(0); save() }, { travel = (travel + 5).coerceAtMost(240); save() })
            TimeButton("Seulement pour les vacations avant", before) { before = it; save() }
            OutlinedButton(onClick = { picker = true }, modifier = Modifier.fillMaxWidth()) {
                Icon(Icons.Filled.MusicNote, null, Modifier.padding(end = 8.dp)); RawText(Reminders.ringtoneName(ctx, ring), maxLines = 1)
            }
            val now = System.currentTimeMillis()
            val next = events.filter { it.category == WakeAlarm.CATEGORY && it.start > now }.sortedBy { it.start }.take(5)
            val f = SimpleDateFormat(I18n.pattern("EEEE d MMMM 'à' HH'h'mm"), I18n.locale)
            if (next.isEmpty()) ToolHint("Aucun réveil prévu pour les 8 prochains jours (pas de vacation, ou elles commencent après l'heure choisie).")
            next.forEach { RawText("⏰ " + f.format(Date(it.start)).replaceFirstChar { c -> c.uppercase() }, style = MaterialTheme.typography.bodyMedium) }
        }
    }
    if (picker) SoundPickerDialog(current = ring, alarm = true, onDismiss = { picker = false }, onPick = { ring = it; picker = false; save() })
}

/** Relevé d'heures du mois en PDF. */
private fun workHoursPdf(m: MonthHours, monthName: String, weekly: Int, ns: Int, ne: Int): ByteArray {
    val pdf = SimplePdf("Calepin · " + I18n.tr("Relevé d'heures"))
    val blue = android.graphics.Color.rgb(31, 95, 122)
    pdf.text(I18n.tr("Relevé d'heures") + " — " + monthName, size = 18f, bold = true, color = blue, after = 2f)
    pdf.text(I18n.trf("Contrat : {0} par semaine · heures de nuit de {1} à {2}", WorkHours.hm(weekly), hhmm(ns), hhmm(ne)), size = 9.5f, color = android.graphics.Color.DKGRAY, after = 10f)
    pdf.line()
    val w2 = listOf(4f, 2f)
    listOf(
        "Total travaillé" to m.total, "Heures de jour" to m.day, "Heures de nuit" to m.night,
        "Heures le dimanche" to m.sunday, "Heures les jours fériés" to m.holiday, "Heures au-delà du contrat" to m.over,
    ).forEach { (l, v) -> pdf.row(listOf(I18n.tr(l), WorkHours.hm(v)), w2, bold = l == "Total travaillé") }
    pdf.space(14f)
    pdf.text(I18n.tr("Par semaine"), size = 12f, bold = true, color = blue)
    val wf = SimpleDateFormat(I18n.pattern("d MMM yyyy"), I18n.locale)
    pdf.row(listOf(I18n.tr("Semaine du"), I18n.tr("Heures"), I18n.tr("Au-delà")), listOf(3f, 1.5f, 1.5f), bold = true, fill = android.graphics.Color.rgb(232, 240, 244))
    m.weeks.forEach { w -> pdf.row(listOf(wf.format(Date(w.monday)), WorkHours.hm(w.minutes), if (w.over > 0) WorkHours.hm(w.over) else "—"), listOf(3f, 1.5f, 1.5f)) }
    pdf.space(14f)
    pdf.text(I18n.tr("Vacations"), size = 12f, bold = true, color = blue)
    val df = SimpleDateFormat(I18n.pattern("EEE d MMM"), I18n.locale)
    val tf = SimpleDateFormat(I18n.pattern("HH'h'mm"), I18n.locale)
    val wts = listOf(2.2f, 2f, 1.2f, 1.2f, 1.2f, 1.2f)
    pdf.row(listOf(I18n.tr("Jour"), I18n.tr("Horaires"), I18n.tr("Durée"), I18n.tr("Nuit"), I18n.tr("Dim."), I18n.tr("Férié")), wts, bold = true, size = 9f, fill = android.graphics.Color.rgb(232, 240, 244))
    fun z(v: Int) = if (v == 0) "—" else WorkHours.hm(v)
    m.shifts.forEach { s ->
        pdf.row(listOf(df.format(Date(s.start)), tf.format(Date(s.start)) + "–" + tf.format(Date(s.end)), WorkHours.hm(s.minutes), z(s.night), z(s.sunday), z(s.holiday)), wts, size = 9f)
    }
    return pdf.build()
}

// ------------------------------------------------------------------ Rappels par lieu

/** « En arrivant à la pharmacie, rappelle-moi… » : rappels déclenchés par la position. */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun PlaceRemindersScreen(onClose: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var list by remember { mutableStateOf(PlaceReminders.all(ctx)) }
    var text by rememberSaveable { mutableStateOf("") }
    var query by rememberSaveable { mutableStateOf("") }
    var results by remember { mutableStateOf<List<WeatherPlace>>(emptyList()) }
    var chosen by remember { mutableStateOf<WeatherPlace?>(null) }
    var radius by rememberSaveable { mutableIntStateOf(200) }
    var always by rememberSaveable { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }
    var perm by remember { mutableStateOf(PlaceReminders.hasPermission(ctx)) }
    var bg by remember { mutableStateOf(PlaceReminders.hasBackground(ctx)) }
    var msg by remember { mutableStateOf<String?>(null) }

    val bgLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {
        bg = PlaceReminders.hasBackground(ctx)
        if (bg) PlaceReminders.registerAll(ctx)
    }
    val fineLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        perm = PlaceReminders.hasPermission(ctx)
        if (perm) PlaceReminders.registerAll(ctx)
    }

    ToolScaffold("Rappels par lieu", onClose) {
        ToolHint("Calepin te prévient en arrivant à un endroit (« au supermarché : acheter du pain »). Ça marche appli fermée, sans service Google, avec la localisation du téléphone.")
        if (!perm) {
            InfoCard {
                Text("Calepin a besoin de la position précise pour savoir quand tu arrives.")
                Button(onClick = { fineLauncher.launch(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION)) }) { Text("Autoriser la localisation") }
            }
        } else if (!bg && Build.VERSION.SDK_INT >= 29) {
            InfoCard {
                Text("Pour les rappels appli fermée, choisis « Toujours autoriser » dans la page qui va s'ouvrir.")
                Button(onClick = { fr.jeremy.calepin.LockGuard.external(); bgLauncher.launch(Manifest.permission.ACCESS_BACKGROUND_LOCATION) }) { Text("Autoriser en arrière-plan") }
            }
        }

        InfoCard {
            SubTitle("Nouveau rappel")
            OutlinedTextField(text, { text = it }, label = { Text("Me rappeler…") }, modifier = Modifier.fillMaxWidth())
            if (chosen == null) {
                OutlinedTextField(
                    query, { query = it }, label = { Text("Lieu (ville, adresse, code postal)") }, singleLine = true, modifier = Modifier.fillMaxWidth(),
                    trailingIcon = {
                        IconButton(enabled = query.isNotBlank() && !busy, onClick = {
                            busy = true
                            scope.launch { results = WeatherRepo.search(ctx, query); busy = false; if (results.isEmpty()) msg = I18n.tr("Aucun lieu trouvé.") }
                        }) { Icon(Icons.Filled.Search, "Chercher") }
                    },
                )
                TextButton(enabled = perm && !busy, onClick = {
                    busy = true
                    scope.launch {
                        val here = WeatherRepo.locate(ctx)
                        busy = false
                        if (here != null) chosen = here.copy(name = I18n.tr("Ma position actuelle") + " (" + here.name + ")") else msg = I18n.tr("Position introuvable : active la localisation du téléphone.")
                    }
                }) { Icon(Icons.Filled.MyLocation, null, Modifier.size(18.dp)); Text("  Ici, là où je suis") }
                if (busy) LinearProgressIndicator(Modifier.fillMaxWidth())
                results.forEach { p ->
                    Surface(onClick = { chosen = p; results = emptyList() }, shape = MaterialTheme.shapes.medium, color = MaterialTheme.colorScheme.surfaceContainerHigh, modifier = Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(10.dp)) {
                            RawText(p.name, style = MaterialTheme.typography.bodyLarge)
                            if (p.detail.isNotBlank()) RawText(p.detail, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            } else {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Filled.Place, null, tint = MaterialTheme.colorScheme.primary)
                    Spacer(Modifier.width(6.dp))
                    RawText(chosen!!.name, modifier = Modifier.weight(1f))
                    TextButton(onClick = { chosen = null }) { Text("Changer") }
                }
            }
            Text("Distance de déclenchement", style = MaterialTheme.typography.bodyMedium)
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(100, 200, 500, 1000).forEach { r -> FilterChip(selected = radius == r, onClick = { radius = r }, label = { RawText(if (r < 1000) "$r m" else "1 km") }) }
            }
            ToggleRow("À chaque arrivée", "Sinon, une seule fois puis le rappel disparaît", always) { always = it }
            Button(
                enabled = text.isNotBlank() && chosen != null,
                onClick = {
                    val p = chosen ?: return@Button
                    PlaceReminders.add(ctx, PlaceReminder(text = text.trim(), place = p.name, lat = p.lat, lon = p.lon, radius = radius.toFloat(), always = always))
                    list = PlaceReminders.all(ctx); text = ""; query = ""; chosen = null
                    msg = I18n.tr("Rappel ajouté.")
                },
                modifier = Modifier.fillMaxWidth(),
            ) { Text("Ajouter le rappel") }
            msg?.let { RawText(it, color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.bodySmall) }
        }

        if (list.isNotEmpty()) SubTitle("Rappels actifs")
        list.forEach { r ->
            InfoCard {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        RawText(r.text, style = MaterialTheme.typography.titleMedium)
                        RawText("📍 " + r.place + " · " + (if (r.radius < 1000) "${r.radius.toInt()} m" else "1 km") + " · " + I18n.tr(if (r.always) "à chaque fois" else "une fois"),
                            style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    IconButton(onClick = { PlaceReminders.remove(ctx, r.id); list = PlaceReminders.all(ctx) }) { Icon(Icons.Filled.Delete, "Supprimer") }
                }
            }
        }
    }
}

// ------------------------------------------------------------------ Sauvegarde automatique

/** Réglages de la sauvegarde automatique chaque nuit (affichés dans l'écran Sauvegarde). */
@Composable
fun AutoBackupSection() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var on by remember { mutableStateOf(fr.jeremy.calepin.care.AutoBackup.enabled(ctx)) }
    var pwd by remember { mutableStateOf(fr.jeremy.calepin.care.AutoBackup.password(ctx)) }
    var hour by remember { mutableIntStateOf(fr.jeremy.calepin.care.AutoBackup.hour(ctx)) }
    var last by remember { mutableStateOf(fr.jeremy.calepin.care.AutoBackup.last(ctx)) }
    var result by remember { mutableStateOf(fr.jeremy.calepin.care.AutoBackup.lastError(ctx)?.let { I18n.tr("Dernier échec :") + " " + it }) }
    var running by remember { mutableStateOf(false) }
    fun save() = fr.jeremy.calepin.care.AutoBackup.set(ctx, on, pwd, hour)
    Text("Sauvegarde automatique", style = MaterialTheme.typography.titleMedium)
    ToggleRow("Chaque nuit", "Dans Téléchargements/Calepin ; les 7 dernières sont gardées", on) { on = it; save() }
    if (on) {
        StepRow("Heure", hhmm(hour * 60), { hour = (hour + 23) % 24; save() }, { hour = (hour + 1) % 24; save() })
        OutlinedTextField(
            pwd, { pwd = it; save() }, label = { Text("Mot de passe (recommandé)") }, singleLine = true,
            visualTransformation = androidx.compose.ui.text.input.PasswordVisualTransformation(),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password), modifier = Modifier.fillMaxWidth(),
        )
        ToolHint("Note ce mot de passe quelque part : sans lui, les sauvegardes automatiques sont illisibles. Pour les garder hors du téléphone, l'appli Google Drive peut synchroniser le dossier.")
    }
    if (last > 0) {
        RawText(I18n.tr("Dernière sauvegarde automatique :") + " " + SimpleDateFormat(I18n.pattern("EEEE d MMMM 'à' HH'h'mm"), I18n.locale).format(Date(last)),
            style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary)
    }
    OutlinedButton(enabled = !running, onClick = {
        running = true
        scope.launch {
            val r = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) { fr.jeremy.calepin.care.AutoBackup.run(ctx) }
            running = false; result = r; last = fr.jeremy.calepin.care.AutoBackup.last(ctx)
        }
    }, modifier = Modifier.fillMaxWidth()) { Text(if (running) "Sauvegarde en cours…" else "Sauvegarder maintenant dans Téléchargements") }
    result?.let { RawText(it, style = MaterialTheme.typography.bodySmall) }
}
