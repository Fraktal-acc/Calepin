package fr.jeremy.calepin.ui

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.graphics.BitmapFactory
import android.net.Uri
import android.provider.Settings
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Directions
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Map
import androidx.compose.material.icons.filled.Navigation
import androidx.compose.material.icons.filled.PersonAdd
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Sms
import androidx.compose.material.icons.filled.Subject
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import fr.jeremy.calepin.Actions
import fr.jeremy.calepin.LockGuard
import fr.jeremy.calepin.NotesViewModel
import fr.jeremy.calepin.contacts.PhoneContact
import fr.jeremy.calepin.contacts.PhoneContacts
import fr.jeremy.calepin.detect.EntityDetector
import fr.jeremy.calepin.detect.EntityType
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** Contacts du téléphone, consultables et utilisables sans quitter Calepin. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ContactsScreen(
    vm: NotesViewModel,
    onOpenNote: (Long) -> Unit,
    onNewNote: (title: String, text: String) -> Unit,
    onClose: () -> Unit,
) {
    val ctx = LocalContext.current
    var granted by remember { mutableStateOf(PhoneContacts.hasPermission(ctx)) }
    var asked by remember { mutableStateOf(false) }
    var reload by remember { mutableIntStateOf(0) }
    var contacts by remember { mutableStateOf<List<PhoneContact>?>(null) }
    var query by remember { mutableStateOf("") }
    var selected by remember { mutableStateOf<PhoneContact?>(null) }

    BackHandler { if (selected != null) selected = null else onClose() }

    val permission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        granted = ok
        asked = true
    }

    // Recharger au retour de l'appli Contacts (contact ajouté ou modifié)
    val lifecycleOwner = LocalLifecycleOwner.current
    DisposableEffect(lifecycleOwner) {
        val obs = LifecycleEventObserver { _, e ->
            if (e == Lifecycle.Event.ON_RESUME) {
                granted = PhoneContacts.hasPermission(ctx)
                reload++
            }
        }
        lifecycleOwner.lifecycle.addObserver(obs)
        onDispose { lifecycleOwner.lifecycle.removeObserver(obs) }
    }

    LaunchedEffect(granted, reload) {
        if (granted) {
            val list = withContext(Dispatchers.IO) { runCatching { PhoneContacts.load(ctx) }.getOrDefault(emptyList()) }
            contacts = list
            // La fiche ouverte suit les modifications
            selected = selected?.let { s -> list.firstOrNull { it.id == s.id } ?: s }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Contacts") },
                navigationIcon = {
                    IconButton(onClick = onClose) { Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Retour") }
                },
                actions = {
                    IconButton(onClick = { Actions.addContact(ctx, "", null, null, null, null) }) {
                        Icon(Icons.Filled.PersonAdd, contentDescription = "Nouveau contact")
                    }
                },
            )
        },
    ) { pad ->
        Column(
            Modifier
                .fillMaxSize()
                .padding(pad),
        ) {
            if (!granted) {
                Column(
                    Modifier
                        .fillMaxWidth()
                        .padding(24.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    Text("Accès aux contacts", style = MaterialTheme.typography.titleLarge)
                    Text(
                        "Calepin affiche vos contacts pour appeler, écrire, trouver une adresse ou retrouver les notes " +
                            "qui parlent d'eux. Les contacts restent sur le téléphone : rien n'est copié ni envoyé.",
                        style = MaterialTheme.typography.bodyMedium,
                    )
                    Button(onClick = {
                        LockGuard.external()
                        permission.launch(Manifest.permission.READ_CONTACTS)
                    }) { Text("Autoriser l'accès aux contacts") }
                    if (asked) {
                        // Refus définitif : seule la page de l'appli dans les réglages permet de l'accorder
                        OutlinedButton(onClick = {
                            LockGuard.external()
                            runCatching {
                                ctx.startActivity(
                                    Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + ctx.packageName))
                                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
                                )
                            }
                        }) { Text("Ouvrir les réglages de Calepin") }
                        Text(
                            "Si rien ne s'affiche : Autorisations → Contacts → Autoriser.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }
            } else {
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 4.dp),
                singleLine = true,
                placeholder = { Text("Nom, numéro, e-mail, ville…") },
                leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
                trailingIcon = {
                    if (query.isNotEmpty()) {
                        IconButton(onClick = { query = "" }) { Icon(Icons.Filled.Close, contentDescription = "Effacer") }
                    }
                },
            )

            val all = contacts
            val shown = if (all == null) emptyList() else PhoneContacts.filter(all, query)
            val favorites = if (all != null && query.isBlank()) all.filter { it.starred } else emptyList()

            if (all == null) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
            } else if (shown.isEmpty()) {
                Text(
                    if (all.isEmpty()) "Aucun contact sur ce téléphone." else "Aucun contact ne correspond.",
                    modifier = Modifier.padding(24.dp),
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            } else LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(bottom = 24.dp),
            ) {
                if (favorites.isNotEmpty()) {
                    item(key = "h-fav") { SectionHeader("★ Favoris") }
                    items(favorites, key = { "f" + it.id }) { c ->
                        ContactRow(c, onClick = { selected = c }, onCall = { Actions.dial(ctx, it) })
                    }
                }
                var letter = ""
                shown.forEach { c ->
                    val l = c.initial.let { if (it.first().isLetter()) fr.jeremy.calepin.search.TextNorm.norm(it).uppercase() else "#" }
                    if (query.isBlank() && l != letter) {
                        letter = l
                        item(key = "h-" + c.id) { SectionHeader(l) }
                    }
                    item(key = "c" + c.id) {
                        ContactRow(c, onClick = { selected = c }, onCall = { Actions.dial(ctx, it) })
                    }
                }
                item(key = "count") {
                    Text(
                        "${shown.size} contact" + if (shown.size > 1) "s" else "",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(16.dp),
                    )
                }
            }
            }
        }
    }

    selected?.let { c ->
        ContactSheet(
            contact = c,
            vm = vm,
            onDismiss = { selected = null },
            onOpenNote = { id -> selected = null; onOpenNote(id) },
            onNewNote = { title, text -> selected = null; onNewNote(title, text) },
        )
    }
}

@Composable
private fun SectionHeader(text: String) {
    Text(
        text,
        style = MaterialTheme.typography.labelLarge,
        color = MaterialTheme.colorScheme.primary,
        modifier = Modifier.padding(start = 16.dp, top = 12.dp, bottom = 4.dp),
    )
}

@Composable
private fun ContactRow(c: PhoneContact, onClick: () -> Unit, onCall: (String) -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Avatar(c, 40.dp)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(c.name, style = MaterialTheme.typography.bodyLarge, maxLines = 1, overflow = TextOverflow.Ellipsis)
            val sub = c.phones.firstOrNull()?.value ?: c.organization ?: c.emails.firstOrNull()?.value
            if (sub != null) {
                Text(
                    sub,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            }
        }
        val phone = c.phones.firstOrNull()
        if (phone != null) {
            IconButton(onClick = { onCall(phone.value) }) {
                Icon(Icons.Filled.Phone, contentDescription = "Appeler", tint = MaterialTheme.colorScheme.primary)
            }
        }
    }
}

@Composable
private fun Avatar(c: PhoneContact, size: Dp) {
    val ctx = LocalContext.current
    val photo by produceState<ImageBitmap?>(null, c.photo) {
        value = c.photo?.let { uri ->
            withContext(Dispatchers.IO) {
                runCatching {
                    ctx.contentResolver.openInputStream(Uri.parse(uri))?.use { BitmapFactory.decodeStream(it) }?.asImageBitmap()
                }.getOrNull()
            }
        }
    }
    val p = photo
    if (p != null) {
        Image(
            p,
            contentDescription = null,
            contentScale = ContentScale.Crop,
            modifier = Modifier
                .size(size)
                .clip(CircleShape),
        )
    } else {
        Box(
            Modifier
                .size(size)
                .clip(CircleShape)
                .background(MaterialTheme.colorScheme.primaryContainer),
            contentAlignment = Alignment.Center,
        ) {
            Text(
                c.initial,
                color = MaterialTheme.colorScheme.onPrimaryContainer,
                fontWeight = FontWeight.SemiBold,
                style = if (size > 48.dp) MaterialTheme.typography.titleLarge else MaterialTheme.typography.titleMedium,
            )
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ContactSheet(
    contact: PhoneContact,
    vm: NotesViewModel,
    onDismiss: () -> Unit,
    onOpenNote: (Long) -> Unit,
    onNewNote: (String, String) -> Unit,
) {
    val ctx = LocalContext.current
    val related = remember(contact) { vm.notesForContact(contact.name, contact.phones.map { it.value }) }
    ModalBottomSheet(onDismissRequest = onDismiss, sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)) {
        Column(
            Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .navigationBarsPadding()
                .padding(horizontal = 16.dp)
                .padding(bottom = 24.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp),
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Avatar(contact, 56.dp)
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) {
                    Text(contact.name, style = MaterialTheme.typography.titleLarge)
                    contact.organization?.let {
                        Text(it, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }

            contact.phones.forEach { p ->
                val country = remember(p.value) {
                    EntityDetector.detect(p.value).firstOrNull { it.type == EntityType.PHONE }?.country
                }
                InfoLine(p.value, listOfNotNull(p.label, country).joinToString(" · "), Icons.Filled.Phone) {
                    IconButton(onClick = { Actions.dial(ctx, p.value) }) { Icon(Icons.Filled.Phone, contentDescription = "Appeler") }
                    IconButton(onClick = { Actions.sms(ctx, p.value) }) { Icon(Icons.Filled.Sms, contentDescription = "SMS") }
                    IconButton(onClick = { Actions.whatsapp(ctx, p.value) }) { Icon(Icons.Filled.Chat, contentDescription = "WhatsApp") }
                    IconButton(onClick = { Actions.copy(ctx, p.value) }) { Icon(Icons.Filled.ContentCopy, contentDescription = "Copier") }
                }
            }
            contact.emails.forEach { e ->
                InfoLine(e.value, e.label, Icons.Filled.Email) {
                    IconButton(onClick = { Actions.email(ctx, e.value, "") }) { Icon(Icons.Filled.Email, contentDescription = "Écrire") }
                    IconButton(onClick = { Actions.copy(ctx, e.value) }) { Icon(Icons.Filled.ContentCopy, contentDescription = "Copier") }
                }
            }
            contact.addresses.forEach { a ->
                InfoLine(a.value, a.label, Icons.Filled.Map) {
                    IconButton(onClick = { Actions.showOnMap(ctx, a.value) }) { Icon(Icons.Filled.Map, contentDescription = "Carte") }
                    IconButton(onClick = { Actions.directions(ctx, a.value) }) { Icon(Icons.Filled.Directions, contentDescription = "Itinéraire") }
                    IconButton(onClick = { Actions.waze(ctx, a.value) }) { Icon(Icons.Filled.Navigation, contentDescription = "Waze") }
                    IconButton(onClick = { Actions.copy(ctx, a.value) }) { Icon(Icons.Filled.ContentCopy, contentDescription = "Copier") }
                }
            }

            HorizontalDivider(Modifier.padding(vertical = 6.dp))
            Text(
                if (related.isEmpty()) "Aucune note ne mentionne ce contact" else "Notes qui le mentionnent (${related.size})",
                style = MaterialTheme.typography.titleSmall,
            )
            related.take(20).forEach { n ->
                Row(
                    Modifier
                        .fillMaxWidth()
                        .clickable { onOpenNote(n.id) }
                        .padding(vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Icon(Icons.Filled.Subject, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                    Spacer(Modifier.width(10.dp))
                    Column(Modifier.weight(1f)) {
                        Text(n.title.ifBlank { "Sans titre" }, style = MaterialTheme.typography.bodyLarge, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(
                            n.content.replace('\n', ' '),
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                        )
                    }
                }
            }

            Spacer(Modifier.size(4.dp))
            Button(onClick = { onNewNote(contact.name, contactText(contact)) }, modifier = Modifier.fillMaxWidth()) {
                Text("Nouvelle note pour ce contact")
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { Actions.openContact(ctx, contact.id, contact.lookupKey) }, modifier = Modifier.weight(1f)) {
                    Text("Ouvrir dans Contacts")
                }
                OutlinedButton(onClick = { Actions.editContact(ctx, contact.id, contact.lookupKey) }, modifier = Modifier.weight(1f)) {
                    Icon(Icons.Filled.Edit, contentDescription = null, modifier = Modifier.size(18.dp))
                    Text(" Modifier")
                }
            }
            TextButton(onClick = { Actions.copy(ctx, contactText(contact)) }) { Text("Copier toute la fiche") }
        }
    }
}

@Composable
private fun InfoLine(
    value: String,
    label: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    actions: @Composable () -> Unit,
) {
    Column(Modifier.fillMaxWidth()) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(18.dp))
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text(value, style = MaterialTheme.typography.bodyLarge)
                if (label.isNotBlank()) {
                    Text(label, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
        Row(Modifier.padding(start = 20.dp)) { actions() }
    }
}

/** Fiche du contact en texte : reprise telle quelle dans une note (numéros et adresses y seront reconnus). */
private fun contactText(c: PhoneContact): String = buildString {
    append(c.name)
    c.organization?.let { append("\n").append(it) }
    c.phones.forEach { append("\n").append(it.label).append(" : ").append(it.value) }
    c.emails.forEach { append("\n").append(it.value) }
    c.addresses.forEach { append("\n").append(it.value) }
    append("\n\n")
}
