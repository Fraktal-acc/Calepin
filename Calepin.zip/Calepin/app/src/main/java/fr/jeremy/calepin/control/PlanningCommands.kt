package fr.jeremy.calepin.control

import android.content.Context
import android.net.Uri
import fr.jeremy.calepin.assistant.AssistantAction
import fr.jeremy.calepin.assistant.Reply
import fr.jeremy.calepin.data.Event
import fr.jeremy.calepin.detect.GridPlanningParser
import fr.jeremy.calepin.detect.PlanningParser
import fr.jeremy.calepin.detect.PlanningReport
import fr.jeremy.calepin.detect.Shift
import fr.jeremy.calepin.i18n.AppLanguage
import fr.jeremy.calepin.i18n.I18n
import fr.jeremy.calepin.office.PdfDownloads
import fr.jeremy.calepin.office.PdfEntry
import fr.jeremy.calepin.office.PdfLibrary
import fr.jeremy.calepin.search.TextNorm
import fr.jeremy.calepin.ui.ShiftStatus
import fr.jeremy.calepin.ui.planningDiff
import fr.jeremy.calepin.ui.planningEvent
import fr.jeremy.calepin.ui.planningTitle
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date

/**
 * Plannings de travail en PDF, à la voix ou par écrit (assistant de base, et IA via « ACTION: » / « CMD: ») :
 *  - « importe mon planning », « mets le planning d'octobre dans l'agenda », « mets à jour l'agenda avec le nouveau planning »,
 *    « importe le PDF planning_octobre dans l'agenda » : vacations et absences reportées dans l'agenda ;
 *    créneaux modifiés remplacés ; ceux qui ont disparu du planning ne sont supprimés qu'après un « oui » ;
 *  - « analyse mon planning », « vérifie le planning d'octobre » : heures, nuits, dimanches, sites, repos,
 *    et comparaison avec les totaux imprimés sur le planning.
 * La lecture du PDF est faite par Calepin (grille lue caractère par caractère), jamais par le modèle d'IA :
 * les petits modèles (Qwen, Gemma) se tromperaient dans un tableau de 31 colonnes.
 */
class PlanningCommands(context: Context, private val host: Host) {
    private val ctx = context.applicationContext
    private val lib get() = PdfLibrary.get(ctx)

    /** Ce que l'appli fournit : l'agenda, la sonnerie par défaut et l'enregistrement des changements. */
    interface Host {
        val events: List<Event>
        val ringtone: String
        suspend fun apply(add: List<Event>, replace: List<Pair<Event, Event>>, delete: List<Event>)
    }

    data class Result(val reply: Reply, val navigate: String? = null)

    /** Un planning lu dans un PDF. */
    class Read(val entry: PdfEntry, val shifts: List<Shift>, val text: String, val keywords: String?) {
        val work get() = shifts.filter { !it.absence }
    }

    /** Créneaux disparus du planning, en attente du « oui ». */
    private var pendingRemoval: List<Event>? = null
    val awaitingConfirmation get() = pendingRemoval != null

    private val cache = HashMap<String, Read?>()

    // ------------------------------------------------------------------ Phrases

    private val verbsImport = "importe|importer|ajoute|ajouter|mets|mettre|met|reporte|reporter|integre|integrer|charge|charger|" +
        "enregistre|enregistrer|copie|copier|transfere|transferer|synchronise|synchroniser|recupere|recuperer|prends|rentre|entre|place"
    private val verbsAnalyse = "analyse|analyser|verifie|verifier|controle|controler|etudie|etudier|decortique|resume|resumer|" +
        "detaille|detailler|explique|expliquer|decris|decrire|compte|calcule|bilan de|fais le bilan de|fais l'analyse de|fais un bilan de"
    private val agenda = "(?:l'agenda|l agenda|agenda|mon agenda|le calendrier|calendrier|mon calendrier|l'agenda du telephone)"
    private val doc = "(?:pdf|document|fichier)"
    /** Mots de date : « résume mon planning de la semaine » parle de l'agenda, pas d'un PDF. */
    private val dayWords = Regex("\\b(aujourd'hui|demain|apres-demain|hier|ce soir|cette semaine|la semaine|semaine prochaine|ce week-end|lundi|mardi|mercredi|jeudi|vendredi|samedi|dimanche)\\b")

    private val months = listOf("janvier", "fevrier", "mars", "avril", "mai", "juin", "juillet", "aout", "septembre", "octobre", "novembre", "decembre")

    suspend fun handle(raw: String): Result? {
        val n = TextNorm.norm(raw).lowercase().replace('_', ' ').replace(Regex("\\s+"), " ").trim().trimEnd('.', '!', '?').trim()
        pendingRemoval?.let { list ->
            when {
                Regex("^(oui|ok|okay|d'accord|vas-y|vas y|supprime(-les| les)?|efface(-les| les)?|confirme|yes|si|sì|ja|claro|certo)\\b").containsMatchIn(n) -> {
                    pendingRemoval = null
                    host.apply(emptyList(), emptyList(), list)
                    return Result(Reply(I18n.trf("C'est fait : {0} créneau(x) supprimé(s) de l'agenda.", list.size), listOf(AssistantAction.OpenCalendar)))
                }
                Regex("^(non|annule|laisse|garde(-les| les)?|no|nein|pas question)\\b").containsMatchIn(n) -> {
                    pendingRemoval = null
                    return Result(Reply(I18n.tr("D'accord, je les garde dans l'agenda.")))
                }
                else -> pendingRemoval = null // autre demande : la question est abandonnée
            }
        }
        if (!Regex("\\bplannings?\\b").containsMatchIn(n) && !Regex("\\b$doc\\b").containsMatchIn(n)) return null

        // « mets à jour l'agenda avec le nouveau planning », « mets à jour mon planning »
        Regex("^(?:mets|mettre|met|fais) a jour (?:$agenda|mon planning|le planning|les horaires)(?: (?:avec|depuis|d'apres|selon) (.+))?$").find(n)?.let { m ->
            val rest = m.groupValues[1]
            if (rest.isNotEmpty() && !Regex("\\b(plannings?|$doc)\\b").containsMatchIn(rest)) return null
            return import(rest)
        }
        // Import
        Regex("^(?:$verbsImport)(?: moi| nous)?(?: le| la| mon| ma| ce| cet| mes| les| tout le| tout mon)?(?: nouveau| nouvel| dernier| prochain)? (?:$doc (?:du |de |d')?(?:mon |ma )?)?(plannings?(?: de travail)?(?: .*)?|$doc .*planning.*)$").find(n)?.let { m ->
            val rest = m.groupValues[1]
            if (dayWords.containsMatchIn(rest)) return null
            return import(rest)
        }
        // Analyse
        Regex("^(?:$verbsAnalyse)(?: moi)?(?: le| la| mon| ma| ce| cet| mes| les| du)?(?: nouveau| dernier)? ((?:$doc (?:du |de |d')?(?:mon |ma )?)?plannings?(?: .*)?|$doc .*)$").find(n)?.let { m ->
            val rest = m.groupValues[1]
            if (dayWords.containsMatchIn(rest)) return null
            val planningWord = Regex("\\bplannings?\\b").containsMatchIn(rest)
            val r = locate(rest) ?: return if (planningWord) analyseAgenda(rest) else null
            return Result(Reply(report(r)))
        }
        return null
    }

    // ------------------------------------------------------------------ Import

    private suspend fun import(rest: String): Result {
        val r = locate(rest) ?: return notFound(rest)
        return importRead(r)
    }

    /** Pour DocCommands : « importe le PDF X dans l'agenda » — null si ce PDF n'est pas un planning. */
    suspend fun importEntry(e: PdfEntry): Result? {
        val r = read(e) ?: return null
        return importRead(r)
    }

    private suspend fun importRead(r: Read): Result {
        val existing = host.events.filter { it.isWork || it.isAbsence }
        val diff = planningDiff(r.shifts, existing) { planningTitle(it) }
        val add = mutableListOf<Event>()
        val replace = mutableListOf<Pair<Event, Event>>()
        val remind = 60
        r.shifts.forEachIndexed { i, sh ->
            val ev = planningEvent(sh, planningTitle(sh), remind, false, host.ringtone)
            val old = diff.replaces[i]
            when {
                old != null -> replace += old to ev
                diff.status[i] == ShiftStatus.SAME -> Unit
                else -> add += ev
            }
        }
        if (add.isNotEmpty() || replace.isNotEmpty()) host.apply(add, replace, emptyList())

        val workAdded = add.count { it.isWork }
        val absAdded = add.count { it.isAbsence }
        val same = diff.status.values.count { it == ShiftStatus.SAME }
        val sb = StringBuilder()
        if (add.isEmpty() && replace.isEmpty()) {
            sb.append(I18n.trf("Ton agenda est déjà à jour avec le planning « {0} » ({1} vacations).", r.entry.name, r.work.size))
        } else {
            val parts = buildList {
                if (workAdded > 0) add(I18n.trf("{0} vacation(s) ajoutée(s)", workAdded))
                if (replace.isNotEmpty()) add(I18n.trf("{0} créneau(x) modifié(s)", replace.size))
                if (absAdded > 0) add(I18n.trf("{0} absence(s) ajoutée(s)", absAdded))
                if (same > 0) add(I18n.trf("{0} déjà à jour", same))
            }
            sb.append(I18n.trf("Planning « {0} » reporté dans l'agenda :", r.entry.name)).append(' ').append(parts.joinToString(", ")).append('.')
            r.work.minByOrNull { it.start }?.let { first ->
                sb.append(' ').append(I18n.trf("Première vacation : {0}.", whenText(first.start)))
            }
            val absences = r.shifts.filter { it.absence }
            if (absences.isNotEmpty()) {
                sb.append(' ').append(I18n.trf("Absences : {0}.", absences.joinToString(" ; ") { absenceText(it) }))
            }
            if (replace.isNotEmpty()) {
                sb.append(' ').append(I18n.trf("Changements : {0}.", replace.take(4).joinToString(" ; ") { (o, nw) -> changeText(o, nw) }))
            }
        }
        if (diff.removed.isNotEmpty()) {
            pendingRemoval = diff.removed
            sb.append("\n\n").append(
                I18n.trf(
                    "{0} créneau(x) de l'agenda ne figure(nt) plus dans ce planning : {1}. Je les supprime ? (oui / non)",
                    diff.removed.size, diff.removed.take(5).joinToString(" ; ") { whenText(it.start) + " " + it.title },
                ),
            )
        }
        return Result(Reply(sb.toString(), listOf(AssistantAction.OpenCalendar)))
    }

    private fun notFound(rest: String): Result {
        val access = fr.jeremy.calepin.tools.StorageAccess.granted(ctx)
        val what = cleanName(rest).ifBlank { I18n.tr("planning") }
        return Result(
            Reply(
                if (access) I18n.trf("Je ne trouve pas de planning « {0} » dans le Bureau ni dans Téléchargements. Ouvre le PDF ou partage-le vers Calepin, puis redemande.", what)
                else I18n.trf("Je ne trouve pas de planning « {0} » dans le Bureau. Pour que je cherche aussi dans Téléchargements, autorise l'accès aux fichiers (Téléphone → Fichiers).", what),
            ),
            "pdf",
        )
    }

    // ------------------------------------------------------------------ Recherche et lecture du PDF

    /** Nom cherché, sans les mots de liaison : « d'octobre dans l'agenda » → « octobre ». */
    private fun cleanName(rest: String): String = rest
        .replace(Regex("\\s(?:dans|a|sur|vers|en|au|avec) $agenda(?: du telephone)?(?: automatiquement)?$"), "")
        .replace(Regex("\\s(?:depuis|dans) (?:les |mes |le dossier )?(?:telechargements|download)$"), "")
        .replace(Regex("\\b(plannings?|de travail|$doc|nomme|appele|intitule)\\b"), " ")
        .replace(Regex("(^|\\s)(?:d'|du |de la |de |des |le |la |les |mon |ma |ce |cet |nouveau |dernier |pour |mois de |mois d')+"), " ")
        .replace(Regex("[«»\"]"), " ")
        .replace(Regex("\\s+"), " ").trim()

    /** Mois demandé : « d'octobre », « du mois prochain », « de ce mois ». */
    private fun monthOf(rest: String): Int? {
        months.forEachIndexed { i, m -> if (Regex("\\b$m\\b").containsMatchIn(rest)) return i }
        val now = Calendar.getInstance()
        return when {
            Regex("\\bmois prochain\\b").containsMatchIn(rest) -> (now.get(Calendar.MONTH) + 1) % 12
            Regex("\\b(ce mois|du mois|mois en cours)\\b").containsMatchIn(rest) -> now.get(Calendar.MONTH)
            else -> null
        }
    }

    private fun monthOfShifts(r: Read): Int? = r.work.groupBy { Calendar.getInstance().apply { timeInMillis = it.start }.get(Calendar.MONTH) }
        .maxByOrNull { it.value.size }?.key

    /**
     * Le PDF voulu : celui ouvert à l'écran, celui dont le nom correspond, sinon le planning le plus récent
     * (du mois demandé) parmi le Bureau et le dossier Téléchargements.
     */
    private suspend fun locate(rest: String): Read? = withContext(Dispatchers.IO) {
        val name = cleanName(rest)
        val month = monthOf(rest)
        val explicitPdf = Regex("\\b$doc\\b").containsMatchIn(rest)
        // PDF affiché à l'écran (« analyse ce planning » depuis la visionneuse)
        if (name.isEmpty() && fr.jeremy.calepin.ScreenContext.screen == "pdf") {
            fr.jeremy.calepin.ScreenContext.pdfId?.let { id -> lib.get(id)?.let { e -> read(e)?.let { return@withContext it } } }
        }
        val norm = TextNorm.norm(name).lowercase().replace('_', ' ').replace('-', ' ')
        val words = norm.split(' ').filter { it.length > 2 && it !in months }
        // 1) Par le nom (Bureau, puis Téléchargements)
        if (words.isNotEmpty() || (explicitPdf && name.isNotEmpty())) {
            val all = norm.split(' ').filter { it.length > 2 }
            fun match(s: String): Boolean { val t = TextNorm.norm(s).lowercase().replace('_', ' ').replace('-', ' '); return all.isNotEmpty() && all.all { t.contains(it) } }
            lib.items.value.sortedByDescending { it.added }.firstOrNull { match(it.name) }?.let { e -> read(e)?.let { return@withContext it } }
            if (fr.jeremy.calepin.tools.StorageAccess.granted(ctx)) {
                PdfDownloads.list().firstOrNull { match(it.nameWithoutExtension) }?.let { f -> readDownload(f)?.let { return@withContext it } }
            }
            // PDF nommé qui n'est pas un planning (« analyse le PDF contrat ») : rien
            if (explicitPdf && words.isNotEmpty()) return@withContext null
        }
        // 2) Le planning le plus récent, du mois demandé s'il y en a un
        val found = mutableListOf<Read>()
        val pdfs = lib.items.value.sortedByDescending { it.added }
        val likely = pdfs.filter { TextNorm.norm(it.name).lowercase().contains("planning") } + pdfs.filterNot { TextNorm.norm(it.name).lowercase().contains("planning") }
        for (e in likely.take(10)) {
            val r = read(e) ?: continue
            if (month == null || monthOfShifts(r) == month) return@withContext r
            found += r
        }
        if (fr.jeremy.calepin.tools.StorageAccess.granted(ctx)) {
            for (f in PdfDownloads.list().take(6)) {
                val r = readDownload(f) ?: continue
                if (month == null || monthOfShifts(r) == month) return@withContext r
            }
        }
        if (month == null) found.firstOrNull() else null
    }

    /** PDF du dossier Download : lu sur place, ajouté au Bureau seulement si c'est un planning. */
    private suspend fun readDownload(f: File): Read? {
        val r = parse(Uri.fromFile(f)) ?: return null
        val e = runCatching { PdfDownloads.import(ctx, f) }.getOrNull() ?: return null
        return Read(e, r.first, r.second, r.third).also { cache[e.id + "|" + lib.file(e.id).lastModified()] = it }
    }

    /** Lit un PDF du Bureau ; null si ce n'est pas un planning. */
    suspend fun read(e: PdfEntry): Read? = withContext(Dispatchers.IO) {
        val f = lib.file(e.id)
        val key = e.id + "|" + f.lastModified()
        if (cache.containsKey(key)) return@withContext cache[key]
        val r = parse(Uri.fromFile(f))?.let { Read(e, it.first, it.second, it.third) }
        cache[key] = r
        r
    }

    /** Vacations et absences d'un PDF (grille d'abord, sinon lecture ligne par ligne), texte et mots-clés. */
    private suspend fun parse(uri: Uri): Triple<List<Shift>, String, String?>? {
        val pdf = runCatching { fr.jeremy.calepin.media.PdfText.extract(ctx, uri) }.getOrNull() ?: return null
        val grid = runCatching { GridPlanningParser.parse(pdf.glyphs) }.getOrDefault(emptyList())
        val lines = runCatching { PlanningParser.parse(pdf.text) }.getOrDefault(emptyList())
        val shifts = if (grid.any { !it.absence } && grid.size >= lines.size) grid else lines
        val work = shifts.count { !it.absence }
        val looksLikePlanning = grid.any { !it.absence } || Regex("(?i)\\b(planning|vacations?|horaires|services?|prise de poste)\\b").containsMatchIn(pdf.text)
        if (work < 2 || !looksLikePlanning) return null
        return Triple(shifts, pdf.text, pdf.keywords)
    }

    // ------------------------------------------------------------------ Analyse

    /** Analyse lisible (et lue à voix haute) d'un planning PDF. */
    fun report(r: Read): String {
        val f = PlanningReport.analyse(r.shifts, r.text, r.keywords)
        val sb = StringBuilder(facts(f, r.entry.name))
        // Déjà dans l'agenda ?
        val diff = planningDiff(r.shifts, host.events.filter { it.isWork || it.isAbsence }) { planningTitle(it) }
        val todo = diff.status.values.count { it != ShiftStatus.SAME } + diff.removed.size
        sb.append("\n\n").append(
            if (todo == 0) I18n.tr("Ce planning est déjà dans ton agenda.")
            else I18n.trf("{0} changement(s) à reporter dans l'agenda : dis « importe le planning » pour le faire.", todo),
        )
        return sb.toString()
    }

    /** « Analyse mon planning » sans PDF : les vacations du mois (ou du mois demandé) déjà dans l'agenda. */
    private fun analyseAgenda(rest: String): Result {
        val now = Calendar.getInstance()
        val month = monthOf(rest) ?: now.get(Calendar.MONTH)
        val year = now.get(Calendar.YEAR) + if (month < now.get(Calendar.MONTH) - 6) 1 else 0
        val text = agendaFacts(month, year)
            ?: return Result(Reply(I18n.tr("Je ne trouve ni planning en PDF ni vacations dans l'agenda pour ce mois. Ajoute le PDF du planning au Bureau, puis dis « importe mon planning ».")))
        return Result(Reply(text, listOf(AssistantAction.OpenCalendar)))
    }

    /** Analyse des vacations de l'agenda pour un mois (null s'il n'y en a pas). Sert aussi de contexte à l'IA. */
    fun agendaFacts(month: Int, year: Int): String? {
        val c = Calendar.getInstance().apply { clear(); set(year, month, 1) }
        val from = c.timeInMillis
        val to = c.apply { add(Calendar.MONTH, 1) }.timeInMillis
        val shifts = host.events.filter { (it.isWork || it.isAbsence) && it.start in from until to }.map { e ->
            Shift(
                e.start, if (e.end > e.start) e.end else e.start,
                if (e.isWork) e.title.substringAfter(" · ", e.title) else e.title, "",
                absence = e.isAbsence, allDay = e.allDay,
            )
        }
        if (shifts.none { !it.absence }) return null
        val label = SimpleDateFormat("MMMM yyyy", I18n.locale).format(Date(from))
        return facts(PlanningReport.analyse(shifts), label, fromAgenda = true)
    }

    private fun facts(f: PlanningReport.Facts, name: String, fromAgenda: Boolean = false): String {
        val sb = StringBuilder()
        val period = f.shifts.firstOrNull()?.let { SimpleDateFormat("MMMM yyyy", I18n.locale).format(Date(it.start)) } ?: ""
        sb.append(
            if (fromAgenda) I18n.trf("Agenda, {0} : {1} vacations sur {2} jours, {3} de travail.", name, f.shifts.size, f.daysWorked, dur(f.totalMin))
            else I18n.trf("Planning « {0} » ({1}) : {2} vacations sur {3} jours, {4} de travail.", name, period, f.shifts.size, f.daysWorked, dur(f.totalMin)),
        )
        sb.append('\n').append(I18n.trf("Nuit : {0} · dimanche : {1} · vacations de 10 h ou plus : {2}.", dur(f.nightMin), dur(f.sundayMin), f.longShifts))
        if (f.sites.isNotEmpty()) {
            sb.append('\n').append(
                I18n.trf("Par site : {0}.", f.sites.joinToString(" ; ") { s -> I18n.trf("{0} : {1} vacation(s), {2}", prettySite(s.name), s.count, dur(s.minutes)) }),
            )
        }
        val restParts = buildList {
            add(I18n.trf("{0} jour(s) sans travail", f.daysOff))
            add(I18n.trf("au plus {0} jour(s) de travail d'affilée", f.longestStreak))
            f.shortestRestMin?.let { m ->
                val after = f.shortestRestAfter?.let { " " + I18n.trf("(après le {0})", dayText(it.start)) } ?: ""
                add(I18n.trf("repos le plus court entre deux journées : {0}", dur(m)) + after)
            }
        }
        sb.append('\n').append(I18n.trf("Repos : {0}.", restParts.joinToString(" ; ")))
        f.shortestRestMin?.let { if (it < 11 * 60) sb.append(' ').append(I18n.tr("Attention : moins de 11 h de repos entre deux journées.")) }
        if (f.absences.isNotEmpty()) sb.append('\n').append(I18n.trf("Absences : {0}.", f.absences.joinToString(" ; ") { absenceText(it) }))
        val d = f.declared
        d.overtimeMin?.takeIf { it > 0 }?.let { sb.append('\n').append(I18n.trf("Heures sup annoncées par le planning : {0}.", dur(it))) }
        if (!d.isEmpty) {
            val bad = f.mismatches
            sb.append('\n').append(
                if (bad.isEmpty()) I18n.tr("Vérifié : mêmes totaux que ceux imprimés sur le planning (services, heures, nuit, dimanche).")
                else I18n.trf("Attention, écart avec les totaux imprimés : {0}. Vérifie le planning à l'écran.", bad.joinToString(" ; ") { mismatchText(it, f) }),
            )
        }
        return sb.toString()
    }

    private fun mismatchText(key: String, f: PlanningReport.Facts): String = when (key) {
        "services" -> I18n.trf("{0} services annoncés, {1} lus", f.declared.services, f.shifts.size)
        "worked" -> I18n.trf("{0} travaillées annoncées, {1} lues", dur(f.declared.workedMin ?: 0), dur(f.totalMin + f.paidAbsenceMin))
        "payable" -> I18n.trf("{0} payables annoncées, {1} lues", dur(f.declared.payableMin ?: 0), dur(f.totalMin))
        "night" -> I18n.trf("nuit : {0} annoncées, {1} lues", dur(f.declared.nightMin ?: 0), dur(f.nightMin))
        "sunday" -> I18n.trf("dimanche : {0} annoncées, {1} lues", dur(f.declared.sundayMin ?: 0), dur(f.sundayMin))
        else -> I18n.trf("{0} cases annoncées, {1} lues", f.declared.items, f.cells)
    }

    // ------------------------------------------------------------------ Mise en forme

    private fun dur(min: Int): String {
        val h = min / 60; val m = min % 60
        return if (I18n.language.value == AppLanguage.FR) (if (m == 0) "$h h" else "$h h ${"%02d".format(m)}") else "$h:${"%02d".format(m)} h"
    }

    private fun dayText(t: Long) = SimpleDateFormat(I18n.pattern("EEEE d MMMM"), I18n.locale).format(Date(t))
    private fun hmText(t: Long) = SimpleDateFormat(I18n.pattern("HH'h'mm"), I18n.locale).format(Date(t))
    private fun whenText(t: Long) = dayText(t) + " " + I18n.trf("à {0}", hmText(t))

    private fun absenceText(a: Shift): String {
        val title = fr.jeremy.calepin.ui.absenceTitle(a.label)
        return when {
            a.allDay && PlanningReport.daysBetween(a.start, a.end) > 0 -> I18n.trf("{0} du {1} au {2}", title, dayText(a.start), dayText(a.end))
            a.allDay -> I18n.trf("{0} le {1}", title, dayText(a.start))
            else -> I18n.trf("{0} le {1} de {2} à {3}", title, dayText(a.start), hmText(a.start), hmText(a.end))
        }
    }

    private fun changeText(old: Event, new: Event): String =
        I18n.trf("{0} : {1}–{2} au lieu de {3}–{4}", dayText(new.start), hmText(new.start), hmText(new.end), hmText(old.start), if (old.end > old.start) hmText(old.end) else "?")

    /** « CONSULAT D'ITALIE » → « Consulat d'Italie ». */
    private fun prettySite(s: String): String {
        if (s.any { it.isLowerCase() }) return s
        val small = setOf("de", "du", "des", "la", "le", "les", "et", "a", "à", "en", "sur", "aux", "au")
        return s.lowercase().split(' ').mapIndexed { i, w ->
            val elided = Regex("^([dl])'(.+)$").find(w)
            val x = when {
                // « d'italie » → « d'Italie »
                elided != null -> elided.groupValues[1] + "'" + elided.groupValues[2].replaceFirstChar { it.uppercase() }
                i > 0 && w in small -> w
                else -> w.replaceFirstChar { it.uppercase() }
            }
            if (i == 0) x.replaceFirstChar { it.uppercase() } else x
        }.joinToString(" ")
    }
}
