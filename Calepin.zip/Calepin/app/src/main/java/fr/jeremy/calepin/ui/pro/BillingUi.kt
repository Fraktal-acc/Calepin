package fr.jeremy.calepin.ui.pro

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.RequestQuote
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Store
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import fr.jeremy.calepin.Files
import fr.jeremy.calepin.care.Urssaf
import fr.jeremy.calepin.i18n.I18n
import fr.jeremy.calepin.i18n.RawText
import fr.jeremy.calepin.i18n.Text
import fr.jeremy.calepin.pro.Billing
import fr.jeremy.calepin.pro.Business
import fr.jeremy.calepin.pro.Client
import fr.jeremy.calepin.pro.Intervention
import fr.jeremy.calepin.pro.Invoice
import fr.jeremy.calepin.pro.InvoiceLine
import fr.jeremy.calepin.pro.ProStore
import fr.jeremy.calepin.pro.Status
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

private fun eur(v: Double) = "%,.2f €".format(Locale.FRANCE, v)
private fun day(t: Long) = SimpleDateFormat("dd/MM/yyyy", Locale.FRANCE).format(Date(t))

/** Facture préremplie avec les interventions faites et pas encore facturées d'un client. */
fun invoiceFor(billing: Billing, client: Client?, ivs: List<Intervention>, quote: Boolean = false): Invoice {
    val todo = ivs.filter { it.status == Status.FAITE }
    val lines = todo.sortedBy { it.date }.map { iv ->
        InvoiceLine("${iv.title} du ${day(iv.date)}", (iv.minutes / 60.0).let { if (it <= 0) 1.0 else Math.round(it * 100) / 100.0 }, client?.rate ?: 0.0)
    }.ifEmpty { listOf(InvoiceLine("", 1.0, client?.rate ?: 0.0)) }
    return Invoice(
        quote = quote, number = billing.nextNumber(quote), clientId = client?.id ?: "",
        lines = lines, interventions = if (quote) emptyList() else todo.map { it.id },
    )
}

/** Partie « Facturation » du bilan : chiffre d'affaires, URSSAF, devis et factures. */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun BillingSection(store: ProStore, clients: List<Client>) {
    val ctx = LocalContext.current
    val billing = remember { Billing.get(ctx) }
    val business by billing.business.collectAsStateWithLifecycle()
    val invoices by billing.invoices.collectAsStateWithLifecycle()
    var editing by remember { mutableStateOf<Invoice?>(null) }
    var editBusiness by remember { mutableStateOf(false) }
    var urssafOn by remember { mutableStateOf(Urssaf.enabled(ctx)) }
    var quarterly by remember { mutableStateOf(Urssaf.quarterly(ctx)) }
    val cs = MaterialTheme.colorScheme

    val yearStart = Calendar.getInstance().apply { set(Calendar.DAY_OF_YEAR, 1); set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0) }.timeInMillis
    val now = System.currentTimeMillis() + 1
    // Période de déclaration en cours : le mois ou le trimestre
    val periodStart = Calendar.getInstance().apply {
        set(Calendar.DAY_OF_MONTH, 1); set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
        if (quarterly) set(Calendar.MONTH, get(Calendar.MONTH) / 3 * 3)
    }.timeInMillis
    val yearCash = billing.cashed(yearStart, now)
    val periodCash = billing.cashed(periodStart, now)
    val unpaid = invoices.filter { !it.quote && it.paidAt == 0L }

    HorizontalDivider()
    Text("Facturation", style = MaterialTheme.typography.titleMedium, color = cs.primary)
    Card(colors = CardDefaults.cardColors(containerColor = cs.secondaryContainer), border = fr.jeremy.calepin.ui.appBorder(), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text("Chiffre d'affaires encaissé cette année", style = MaterialTheme.typography.labelLarge)
            RawText(eur(yearCash), style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.SemiBold)
            if (business.ceiling > 0) {
                LinearProgressIndicator(progress = { (yearCash / business.ceiling).toFloat().coerceIn(0f, 1f) }, modifier = Modifier.fillMaxWidth())
                Text(I18n.trf("{0} % du plafond de la micro-entreprise ({1})", "%.0f".format(yearCash / business.ceiling * 100), eur(business.ceiling)), style = MaterialTheme.typography.bodySmall)
            }
            Text(
                I18n.trf(if (quarterly) "Ce trimestre : {0} encaissés · cotisations estimées {1}" else "Ce mois-ci : {0} encaissés · cotisations estimées {1}",
                    eur(periodCash), eur(periodCash * business.urssafRate / 100)),
                style = MaterialTheme.typography.bodyMedium,
            )
            if (unpaid.isNotEmpty()) {
                Text(I18n.trf("{0} facture(s) en attente de paiement : {1}", unpaid.size, eur(unpaid.sumOf { it.total })), style = MaterialTheme.typography.bodyMedium, color = cs.error)
            }
        }
    }
    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Button(onClick = { editing = invoiceFor(billing, null, emptyList()) }) { Icon(Icons.Filled.ReceiptLong, null); Text(" Facture") }
        OutlinedButton(onClick = { editing = invoiceFor(billing, null, emptyList(), quote = true) }) { Icon(Icons.Filled.RequestQuote, null); Text(" Devis") }
        OutlinedButton(onClick = { editBusiness = true }) { Icon(Icons.Filled.Store, null); Text(" Mon entreprise") }
    }
    if (business.name.isBlank()) {
        Text("Renseigne d'abord « Mon entreprise » (nom, SIRET, adresse) : ces informations s'impriment sur les devis et factures.", style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
    }
    Row(verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text("Rappel des déclarations URSSAF", style = MaterialTheme.typography.bodyLarge)
            Text(if (urssafOn) I18n.trf("Prochaine échéance : {0}", day(Urssaf.nextDeadline(ctx))) else "Une notification une semaine avant chaque échéance",
                style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
        }
        Switch(checked = urssafOn, onCheckedChange = { urssafOn = it; Urssaf.set(ctx, it, quarterly, 7) })
    }
    if (urssafOn) {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(selected = !quarterly, onClick = { quarterly = false; Urssaf.set(ctx, true, false, 7) }, label = { Text("Mensuelle") })
            FilterChip(selected = quarterly, onClick = { quarterly = true; Urssaf.set(ctx, true, true, 7) }, label = { Text("Trimestrielle") })
        }
    }

    invoices.sortedByDescending { it.date }.take(40).forEach { inv ->
        val c = clients.firstOrNull { it.id == inv.clientId }
        Card(
            onClick = { editing = inv },
            border = fr.jeremy.calepin.ui.appBorder(),
            colors = CardDefaults.cardColors(containerColor = cs.surfaceContainerLow),
            modifier = Modifier.fillMaxWidth(),
        ) {
            Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    RawText("${I18n.tr(inv.label)} ${inv.number} · ${c?.name ?: "—"}", style = MaterialTheme.typography.titleSmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    RawText(day(inv.date) + " · " + eur(inv.total), style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
                }
                when {
                    inv.quote -> Text("Devis", style = MaterialTheme.typography.labelMedium, color = cs.tertiary)
                    inv.paidAt > 0 -> Text("Payée", style = MaterialTheme.typography.labelMedium, color = cs.primary)
                    else -> TextButton(onClick = { billing.upsert(inv.copy(paidAt = System.currentTimeMillis())) }) { Text("Marquer payée") }
                }
                IconButton(onClick = { Files.shareBytes(ctx, billing.pdf(inv, c), "${inv.label}-${inv.number}.pdf", "application/pdf") }) {
                    Icon(Icons.Filled.Share, "Partager le PDF")
                }
            }
        }
    }

    editing?.let { inv ->
        InvoiceEditor(inv, clients, onDismiss = { editing = null }) { saved ->
            billing.upsert(saved)
            // Interventions facturées
            saved.interventions.forEach { id -> store.interventions.value.firstOrNull { it.id == id }?.let { store.upsert(it.copy(status = Status.FACTUREE)) } }
            editing = null
            Files.shareBytes(ctx, billing.pdf(saved, clients.firstOrNull { it.id == saved.clientId }), "${saved.label}-${saved.number}.pdf", "application/pdf")
        }
    }
    if (editBusiness) BusinessDialog(business, onDismiss = { editBusiness = false }) { billing.setBusiness(it); editBusiness = false }
}

/** Rédaction d'un devis ou d'une facture. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun InvoiceEditor(initial: Invoice, clients: List<Client>, onDismiss: () -> Unit, onSave: (Invoice) -> Unit) {
    val ctx = LocalContext.current
    val billing = remember { Billing.get(ctx) }
    var clientId by remember { mutableStateOf(initial.clientId) }
    var lines by remember { mutableStateOf(initial.lines.map { Triple(it.label, fmtNum(it.qty), fmtNum(it.unit)) }) }
    var notes by remember { mutableStateOf(initial.notes) }
    var paid by remember { mutableStateOf(initial.paidAt > 0) }
    var confirmDelete by remember { mutableStateOf(false) }
    var menu by remember { mutableStateOf(false) }
    val existing = billing.invoices.value.any { it.id == initial.id }
    fun parse(s: String) = s.replace(',', '.').replace(" ", "").toDoubleOrNull() ?: 0.0
    val total = lines.sumOf { parse(it.second) * parse(it.third) }

    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { RawText("${I18n.tr(initial.label)} ${initial.number}") },
                    navigationIcon = { IconButton(onClick = onDismiss) { Icon(Icons.Filled.Close, "Fermer") } },
                    actions = {
                        if (existing) IconButton(onClick = { confirmDelete = true }) { Icon(Icons.Filled.Delete, "Supprimer") }
                        TextButton(onClick = {
                            onSave(initial.copy(
                                clientId = clientId,
                                lines = lines.filter { it.first.isNotBlank() }.map { InvoiceLine(it.first.trim(), parse(it.second), parse(it.third)) },
                                notes = notes.trim(),
                                paidAt = if (paid) (initial.paidAt.takeIf { it > 0 } ?: System.currentTimeMillis()) else 0L,
                            ))
                        }) { Text("Enregistrer et partager") }
                    },
                )
            },
        ) { pad ->
            Column(
                Modifier.fillMaxSize().padding(pad).verticalScroll(rememberScrollState()).padding(16.dp).padding(bottom = 40.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                ExposedDropdownMenuBox(expanded = menu, onExpandedChange = { menu = it }) {
                    OutlinedTextField(
                        value = clients.firstOrNull { it.id == clientId }?.name ?: I18n.tr("Choisir le client"),
                        onValueChange = {}, readOnly = true, label = { Text("Client") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = menu) },
                        modifier = Modifier.menuAnchor().fillMaxWidth(),
                    )
                    ExposedDropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                        clients.forEach { c -> DropdownMenuItem(text = { RawText(c.name) }, onClick = { clientId = c.id; menu = false }) }
                    }
                }
                Text("Lignes", style = MaterialTheme.typography.titleSmall)
                lines.forEachIndexed { i, (label, qty, unit) ->
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        OutlinedTextField(label, { v -> lines = lines.toMutableList().also { it[i] = Triple(v, qty, unit) } }, label = { Text("Désignation") }, modifier = Modifier.fillMaxWidth())
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                            OutlinedTextField(qty, { v -> lines = lines.toMutableList().also { it[i] = Triple(label, v, unit) } }, label = { Text("Qté / heures") },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), singleLine = true, modifier = Modifier.weight(1f))
                            OutlinedTextField(unit, { v -> lines = lines.toMutableList().also { it[i] = Triple(label, qty, v) } }, label = { Text("Prix unitaire €") },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), singleLine = true, modifier = Modifier.weight(1f))
                            IconButton(onClick = { lines = lines.filterIndexed { k, _ -> k != i } }) { Icon(Icons.Filled.Delete, "Retirer la ligne") }
                        }
                        HorizontalDivider()
                    }
                }
                OutlinedButton(onClick = { lines = lines + Triple("", "1", fmtNum(clients.firstOrNull { it.id == clientId }?.rate ?: 0.0)) }) {
                    Icon(Icons.Filled.Add, null); Text(" Ajouter une ligne")
                }
                RawText(I18n.tr("Total") + " : " + eur(total), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold)
                OutlinedTextField(notes, { notes = it }, label = { Text("Remarque (facultatif)") }, modifier = Modifier.fillMaxWidth())
                if (!initial.quote) {
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.clickable { paid = !paid }) {
                        Checkbox(checked = paid, onCheckedChange = { paid = it })
                        Text("Facture déjà payée")
                    }
                }
            }
        }
    }
    if (confirmDelete) {
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            title = { Text("Supprimer ce document ?") },
            text = { Text("Pour une facture, il vaut mieux la garder et faire un avoir : la numérotation doit rester continue.") },
            confirmButton = { TextButton(onClick = { billing.delete(initial.id); confirmDelete = false; onDismiss() }) { Text("Supprimer", color = MaterialTheme.colorScheme.error) } },
            dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text("Annuler") } },
        )
    }
}

private fun fmtNum(v: Double): String = if (v % 1.0 == 0.0) "%.0f".format(Locale.FRANCE, v) else "%.2f".format(Locale.FRANCE, v)

@Composable
private fun BusinessDialog(b: Business, onDismiss: () -> Unit, onSave: (Business) -> Unit) {
    var name by remember { mutableStateOf(b.name) }
    var owner by remember { mutableStateOf(b.owner) }
    var address by remember { mutableStateOf(b.address) }
    var siret by remember { mutableStateOf(b.siret) }
    var phone by remember { mutableStateOf(b.phone) }
    var email by remember { mutableStateOf(b.email) }
    var iban by remember { mutableStateOf(b.iban) }
    var vat by remember { mutableStateOf(b.vatNote) }
    var rate by remember { mutableStateOf(b.urssafRate.toString()) }
    var ceiling by remember { mutableStateOf(b.ceiling.toInt().toString()) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Mon entreprise") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                OutlinedTextField(name, { name = it }, label = { Text("Nom commercial") }, singleLine = true)
                OutlinedTextField(owner, { owner = it }, label = { Text("Nom et prénom") }, singleLine = true)
                OutlinedTextField(address, { address = it }, label = { Text("Adresse") })
                OutlinedTextField(siret, { siret = it }, label = { Text("SIRET") }, singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
                OutlinedTextField(phone, { phone = it }, label = { Text("Téléphone") }, singleLine = true)
                OutlinedTextField(email, { email = it }, label = { Text("E-mail") }, singleLine = true)
                OutlinedTextField(iban, { iban = it }, label = { Text("IBAN (facultatif)") }, singleLine = true)
                OutlinedTextField(vat, { vat = it }, label = { Text("Mention de TVA") })
                OutlinedTextField(rate, { rate = it }, label = { Text("Taux de cotisations URSSAF (%)") }, singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal))
                OutlinedTextField(ceiling, { ceiling = it }, label = { Text("Plafond annuel du régime (€)") }, singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
                Text("Vérifie chaque année le taux et le plafond sur urssaf.fr : ils changent.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        },
        confirmButton = {
            TextButton(onClick = {
                onSave(b.copy(
                    name = name.trim(), owner = owner.trim(), address = address.trim(), siret = siret.trim(), phone = phone.trim(),
                    email = email.trim(), iban = iban.trim(), vatNote = vat.trim(),
                    urssafRate = rate.replace(',', '.').toDoubleOrNull() ?: b.urssafRate,
                    ceiling = ceiling.replace(" ", "").toDoubleOrNull() ?: b.ceiling,
                ))
            }) { Text("Enregistrer") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Annuler") } },
    )
}
