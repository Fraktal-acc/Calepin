package fr.jeremy.calepin.ui.tools

import android.content.Context
import android.content.Intent
import android.os.Environment
import android.webkit.MimeTypeMap
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.InsertDriveFile
import androidx.compose.material.icons.filled.Android
import androidx.compose.material.icons.filled.AudioFile
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.ContentPaste
import androidx.compose.material.icons.filled.CreateNewFolder
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.DriveFileMove
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.FolderZip
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.SelectAll
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.VideoFile
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.AssistChip
import androidx.compose.material3.BottomAppBar
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import fr.jeremy.calepin.LockGuard
import fr.jeremy.calepin.i18n.I18n
import fr.jeremy.calepin.i18n.RawText
import fr.jeremy.calepin.i18n.Text
import fr.jeremy.calepin.tools.StorageAccess
import fr.jeremy.calepin.tools.formatSize
import fr.jeremy.calepin.ui.FitText
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.text.DateFormat
import java.util.Date

private enum class SortBy(val label: String) { NAME("Nom"), DATE("Date"), SIZE("Taille"), TYPE("Type") }

private data class Entry(val file: File, val isDir: Boolean, val size: Long, val modified: Long, val children: Int)

/** Copier / couper en attente de « Coller ici ». */
private data class Clip(val files: List<File>, val move: Boolean)

/** Explorateur des fichiers du téléphone : parcourir, ouvrir, partager, copier, déplacer, renommer, supprimer. */
@OptIn(ExperimentalMaterial3Api::class, ExperimentalFoundationApi::class)
@Composable
fun FilesScreen(onClose: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val (granted, ask) = rememberStorageGranted()
    val root = remember { StorageAccess.root }
    var path by rememberSaveable { mutableStateOf(root.absolutePath) }
    val dir = File(path)
    var sort by rememberSaveable { mutableStateOf(SortBy.NAME) }
    var showHidden by rememberSaveable { mutableStateOf(false) }
    var filter by rememberSaveable { mutableStateOf("") }
    var searchOpen by rememberSaveable { mutableStateOf(false) }
    var entries by remember { mutableStateOf<List<Entry>>(emptyList()) }
    var selection by remember { mutableStateOf<Set<String>>(emptySet()) }
    var clip by remember { mutableStateOf<Clip?>(null) }
    var refresh by remember { mutableStateOf(0) }
    var menu by remember { mutableStateOf(false) }
    var newFolder by remember { mutableStateOf(false) }
    var renaming by remember { mutableStateOf<File?>(null) }
    var deleting by remember { mutableStateOf<List<File>?>(null) }
    var busy by remember { mutableStateOf(false) }

    LaunchedEffect(path, showHidden, sort, granted, refresh) {
        entries = withContext(Dispatchers.IO) { list(File(path), showHidden, sort) }
    }
    val atRoot = path == root.absolutePath
    BackHandler {
        when {
            selection.isNotEmpty() -> selection = emptySet()
            !atRoot -> path = File(path).parent ?: root.absolutePath
            else -> onClose()
        }
    }
    val shown = if (filter.isBlank()) entries else entries.filter { it.file.name.contains(filter.trim(), ignoreCase = true) }
    val selected = entries.filter { it.file.absolutePath in selection }.map { it.file }

    fun toast(msg: String) = I18n.toast(ctx, msg, Toast.LENGTH_SHORT).show()

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    if (selection.isNotEmpty()) RawText(I18n.trf("{0} sélectionné(s)", selection.size))
                    else FitText("Fichiers")
                },
                navigationIcon = {
                    IconButton(onClick = {
                        when {
                            selection.isNotEmpty() -> selection = emptySet()
                            !atRoot -> path = File(path).parent ?: root.absolutePath
                            else -> onClose()
                        }
                    }) { Icon(if (selection.isNotEmpty()) Icons.Filled.Close else Icons.AutoMirrored.Filled.ArrowBack, "Retour") }
                },
                actions = {
                    if (selection.isEmpty()) {
                        IconButton(onClick = { searchOpen = !searchOpen; if (!searchOpen) filter = "" }) { Icon(Icons.Filled.Search, "Rechercher") }
                        IconButton(onClick = { newFolder = true }, enabled = granted) { Icon(Icons.Filled.CreateNewFolder, "Nouveau dossier") }
                        Box {
                            IconButton(onClick = { menu = true }) { Icon(Icons.Filled.MoreVert, "Options") }
                            DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                                SortBy.entries.forEach { s ->
                                    DropdownMenuItem(
                                        text = { Text(I18n.trf("Trier par : {0}", I18n.tr(s.label))) },
                                        leadingIcon = { if (s == sort) Icon(Icons.Filled.CheckCircle, null) },
                                        onClick = { sort = s; menu = false },
                                    )
                                }
                                DropdownMenuItem(
                                    text = { Text(if (showHidden) "Masquer les fichiers cachés" else "Afficher les fichiers cachés") },
                                    onClick = { showHidden = !showHidden; menu = false },
                                )
                            }
                        }
                    } else {
                        IconButton(onClick = { selection = entries.map { it.file.absolutePath }.toSet() }) { Icon(Icons.Filled.SelectAll, "Tout sélectionner") }
                    }
                },
            )
        },
        bottomBar = {
            when {
                selection.isNotEmpty() -> BottomAppBar {
                    BarAction(Icons.Filled.Share, "Partager", selected.none { it.isDirectory }) { share(ctx, selected) }
                    BarAction(Icons.Filled.ContentCopy, "Copier") { clip = Clip(selected, move = false); selection = emptySet() }
                    BarAction(Icons.Filled.DriveFileMove, "Déplacer") { clip = Clip(selected, move = true); selection = emptySet() }
                    BarAction(Icons.Filled.Edit, "Renommer", selected.size == 1) { renaming = selected.first() }
                    BarAction(Icons.Filled.Delete, "Supprimer") { deleting = selected }
                }
                clip != null -> BottomAppBar {
                    val c = clip!!
                    Text(
                        I18n.trf(if (c.move) "{0} élément(s) à déplacer" else "{0} élément(s) à copier", c.files.size),
                        modifier = Modifier.weight(1f).padding(start = 16.dp), style = MaterialTheme.typography.bodyMedium,
                    )
                    TextButton(onClick = { clip = null }) { Text("Annuler") }
                    TextButton(enabled = !busy, onClick = {
                        busy = true
                        scope.launch {
                            val n = withContext(Dispatchers.IO) { paste(c, File(path)) }
                            busy = false
                            clip = null
                            refresh++
                            toast(I18n.trf(if (c.move) "{0} élément(s) déplacé(s)" else "{0} élément(s) copié(s)", n))
                        }
                    }) {
                        Icon(Icons.Filled.ContentPaste, null, Modifier.size(18.dp)); Text(" Coller ici")
                    }
                }
            }
        },
    ) { pad ->
        Column(Modifier.fillMaxSize().padding(pad)) {
            if (!granted) {
                Column(Modifier.padding(16.dp)) { StorageAccessCard(ask) }
                return@Column
            }
            // Fil d'Ariane : Stockage interne › DCIM › Camera
            val crumbs = remember(path) {
                val rel = path.removePrefix(root.absolutePath).trim('/')
                val parts = if (rel.isEmpty()) emptyList() else rel.split('/')
                listOf(I18n.tr("Stockage interne") to root.absolutePath) +
                    parts.mapIndexed { i, p -> p to (root.absolutePath + "/" + parts.take(i + 1).joinToString("/")) }
            }
            Row(
                Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 12.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                crumbs.forEachIndexed { i, (name, p) ->
                    if (i > 0) RawText(" › ", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    RawText(
                        name,
                        modifier = Modifier.clip(RoundedCornerShape(8.dp)).combinedClickable(onClick = { path = p }).padding(horizontal = 6.dp, vertical = 4.dp),
                        style = MaterialTheme.typography.labelLarge,
                        color = if (i == crumbs.lastIndex) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                        fontWeight = if (i == crumbs.lastIndex) FontWeight.SemiBold else FontWeight.Normal,
                    )
                }
            }
            if (searchOpen) {
                OutlinedTextField(
                    value = filter, onValueChange = { filter = it },
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp),
                    singleLine = true, placeholder = { Text("Filtrer ce dossier") },
                    leadingIcon = { Icon(Icons.Filled.Search, null) },
                    shape = MaterialTheme.shapes.large,
                )
            }
            if (atRoot) {
                // Raccourcis vers les dossiers courants
                Row(
                    Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 12.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    SHORTCUTS.forEach { (label, dirName) ->
                        val f = File(root, dirName)
                        if (f.isDirectory) AssistChip(onClick = { path = f.absolutePath }, label = { Text(label) }, leadingIcon = { Icon(Icons.Filled.Folder, null, Modifier.size(18.dp)) })
                    }
                }
            }
            LazyColumn(
                Modifier.fillMaxSize(),
                contentPadding = PaddingValues(start = 8.dp, end = 8.dp, bottom = 24.dp),
            ) {
                if (shown.isEmpty()) item {
                    Box(Modifier.fillMaxWidth().padding(32.dp), contentAlignment = Alignment.Center) {
                        Text(if (filter.isBlank()) "Dossier vide" else "Aucun fichier ne correspond", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
                items(shown, key = { it.file.absolutePath }) { e ->
                    val sel = e.file.absolutePath in selection
                    EntryRow(
                        e, sel,
                        onClick = {
                            when {
                                selection.isNotEmpty() -> selection = if (sel) selection - e.file.absolutePath else selection + e.file.absolutePath
                                e.isDir -> { path = e.file.absolutePath; filter = "" }
                                else -> open(ctx, e.file)
                            }
                        },
                        onLongClick = { selection = if (sel) selection - e.file.absolutePath else selection + e.file.absolutePath },
                    )
                }
            }
        }
    }

    if (newFolder) {
        NameInput("Nouveau dossier", "", onDismiss = { newFolder = false }) { name ->
            newFolder = false
            val ok = File(path, name).mkdirs()
            if (!ok) toast("Impossible de créer le dossier")
            refresh++
        }
    }
    renaming?.let { f ->
        NameInput("Renommer", f.name, onDismiss = { renaming = null }) { name ->
            renaming = null
            val target = File(f.parentFile, name)
            if (target.exists() || !f.renameTo(target)) toast("Impossible de renommer : ce nom existe peut-être déjà")
            selection = emptySet()
            refresh++
        }
    }
    deleting?.let { list ->
        AlertDialog(
            onDismissRequest = { deleting = null },
            title = { Text(I18n.trf("Supprimer {0} élément(s) ?", list.size)) },
            text = {
                RawText(
                    list.take(5).joinToString("\n") { it.name } + if (list.size > 5) "\n…" else "",
                    style = MaterialTheme.typography.bodyMedium,
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    deleting = null
                    scope.launch {
                        val n = withContext(Dispatchers.IO) { list.count { if (it.isDirectory) it.deleteRecursively() else it.delete() } }
                        selection = emptySet()
                        refresh++
                        toast(I18n.trf("{0} élément(s) supprimé(s)", n))
                    }
                }) { Text("Supprimer", color = MaterialTheme.colorScheme.error) }
            },
            dismissButton = { TextButton(onClick = { deleting = null }) { Text("Annuler") } },
        )
    }
}

private val SHORTCUTS = listOf(
    "Téléchargements" to Environment.DIRECTORY_DOWNLOADS,
    "Appareil photo" to "DCIM/Camera",
    "Images" to Environment.DIRECTORY_PICTURES,
    "Documents" to Environment.DIRECTORY_DOCUMENTS,
    "Musique" to Environment.DIRECTORY_MUSIC,
    "Sonneries" to Environment.DIRECTORY_RINGTONES,
    "Films" to Environment.DIRECTORY_MOVIES,
)

private fun list(dir: File, hidden: Boolean, sort: SortBy): List<Entry> {
    val files = dir.listFiles()?.filter { hidden || !it.name.startsWith(".") } ?: return emptyList()
    val entries = files.map { f ->
        val isDir = f.isDirectory
        Entry(f, isDir, if (isDir) 0L else f.length(), f.lastModified(), if (isDir) (f.list()?.size ?: 0) else 0)
    }
    val bySort = when (sort) {
        SortBy.NAME -> entries.sortedBy { it.file.name.lowercase() }
        SortBy.DATE -> entries.sortedByDescending { it.modified }
        SortBy.SIZE -> entries.sortedByDescending { it.size }
        SortBy.TYPE -> entries.sortedWith(compareBy<Entry> { it.file.extension.lowercase() }.thenBy { it.file.name.lowercase() })
    }
    // Dossiers d'abord
    return bySort.filter { it.isDir } + bySort.filter { !it.isDir }
}

private fun mimeOf(f: File): String =
    MimeTypeMap.getSingleton().getMimeTypeFromExtension(f.extension.lowercase()) ?: "*/*"

private fun uriOf(ctx: Context, f: File) = FileProvider.getUriForFile(ctx, ctx.packageName + ".files", f)

private fun open(ctx: Context, f: File) {
    val i = Intent(Intent.ACTION_VIEW).setDataAndType(uriOf(ctx, f), mimeOf(f)).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    LockGuard.external()
    runCatching { ctx.startActivity(Intent.createChooser(i, I18n.tr("Ouvrir avec"))) }
        .onFailure { I18n.toast(ctx, "Aucune appli ne sait ouvrir ce fichier", Toast.LENGTH_SHORT).show() }
}

private fun share(ctx: Context, files: List<File>) {
    if (files.isEmpty()) return
    val uris = ArrayList(files.map { uriOf(ctx, it) })
    val i = if (uris.size == 1) {
        Intent(Intent.ACTION_SEND).setType(mimeOf(files[0])).putExtra(Intent.EXTRA_STREAM, uris[0])
    } else {
        Intent(Intent.ACTION_SEND_MULTIPLE).setType("*/*").putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris)
    }
    i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    LockGuard.external()
    runCatching { ctx.startActivity(Intent.createChooser(i, I18n.tr("Partager"))) }
}

/** Colle les fichiers copiés ou coupés ; un nom déjà pris devient « nom (2) ». Renvoie le nombre réussi. */
private fun paste(c: Clip, dest: File): Int {
    var n = 0
    c.files.forEach { src ->
        if (!src.exists()) return@forEach
        // Pas de copie d'un dossier dans lui-même
        if (src.isDirectory && (dest.absolutePath + "/").startsWith(src.absolutePath + "/")) return@forEach
        var target = File(dest, src.name)
        if (target.absolutePath == src.absolutePath && c.move) return@forEach
        var k = 2
        while (target.exists()) {
            target = File(dest, if (src.isDirectory || src.extension.isEmpty()) "${src.name} ($k)" else "${src.nameWithoutExtension} ($k).${src.extension}")
            k++
        }
        val ok = runCatching {
            if (c.move && src.renameTo(target)) {
                true
            } else {
                val copied = if (src.isDirectory) src.copyRecursively(target) else { src.copyTo(target); true }
                // Déplacement entre deux emplacements : copie puis suppression de l'original
                if (copied && c.move) src.deleteRecursively()
                copied
            }
        }.getOrDefault(false)
        if (ok) n++
    }
    return n
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun EntryRow(e: Entry, selected: Boolean, onClick: () -> Unit, onLongClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(if (selected) cs.secondaryContainer else androidx.compose.ui.graphics.Color.Transparent)
            .combinedClickable(onClick = onClick, onLongClick = onLongClick)
            .padding(horizontal = 8.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        val (icon, tint) = iconOf(e)
        Box(Modifier.size(42.dp).clip(RoundedCornerShape(10.dp)).background(tint.copy(alpha = 0.15f)), contentAlignment = Alignment.Center) {
            Icon(if (selected) Icons.Filled.CheckCircle else icon, null, tint = tint)
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            RawText(e.file.name, style = MaterialTheme.typography.bodyLarge, maxLines = 1, overflow = TextOverflow.Ellipsis)
            val date = DateFormat.getDateInstance(DateFormat.MEDIUM, I18n.locale).format(Date(e.modified))
            RawText(
                if (e.isDir) I18n.trf("{0} élément(s)", e.children) + " · " + date else formatSize(e.size) + " · " + date,
                style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant, maxLines = 1,
            )
        }
    }
}

@Composable
private fun iconOf(e: Entry): Pair<ImageVector, androidx.compose.ui.graphics.Color> {
    val cs = MaterialTheme.colorScheme
    if (e.isDir) return Icons.Filled.Folder to cs.primary
    return when (e.file.extension.lowercase()) {
        "jpg", "jpeg", "png", "gif", "webp", "heic", "heif", "bmp" -> Icons.Filled.Image to cs.tertiary
        "mp4", "mkv", "mov", "avi", "webm", "3gp" -> Icons.Filled.VideoFile to cs.tertiary
        "mp3", "m4a", "aac", "ogg", "opus", "flac", "wav", "amr", "mid", "midi" -> Icons.Filled.AudioFile to cs.secondary
        "pdf" -> Icons.Filled.PictureAsPdf to cs.error
        "doc", "docx", "odt", "txt", "rtf", "xls", "xlsx", "ods", "csv", "ppt", "pptx", "md", "json" -> Icons.Filled.Description to cs.primary
        "zip", "rar", "7z", "tar", "gz" -> Icons.Filled.FolderZip to cs.secondary
        "apk", "xapk", "apks" -> Icons.Filled.Android to cs.secondary
        else -> Icons.Filled.InsertDriveFile to cs.onSurfaceVariant
    }
}

@Composable
private fun BarAction(icon: ImageVector, label: String, enabled: Boolean = true, onClick: () -> Unit) {
    IconButton(onClick = onClick, enabled = enabled) { Icon(icon, label) }
}

@Composable
private fun NameInput(title: String, initial: String, onDismiss: () -> Unit, onOk: (String) -> Unit) {
    var name by remember { mutableStateOf(initial) }
    val valid = name.isNotBlank() && !name.contains('/')
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = { OutlinedTextField(value = name, onValueChange = { name = it }, singleLine = true) },
        confirmButton = { TextButton(enabled = valid, onClick = { onOk(name.trim()) }) { Text("OK") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Annuler") } },
    )
}
