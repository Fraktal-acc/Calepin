package fr.jeremy.calepin.ui

import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Sync
import androidx.compose.material.icons.filled.UploadFile
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import fr.jeremy.calepin.control.ChatImport
import fr.jeremy.calepin.control.ChatImportTarget
import fr.jeremy.calepin.control.Conv
import fr.jeremy.calepin.control.MessageHub
import fr.jeremy.calepin.i18n.I18n
import fr.jeremy.calepin.i18n.RawText
import fr.jeremy.calepin.i18n.Text
import fr.jeremy.calepin.search.TextNorm
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date

private fun appName(app: String) = if (app == Conv.TELEGRAM) "Telegram" else "WhatsApp"
private fun day(t: Long) = SimpleDateFormat(I18n.pattern("d MMM yyyy"), I18n.locale).format(Date(t))

/** Ce que l'import doit lire : fichiers partagés / choisis, ou export trouvé dans le téléphone. */
sealed interface ImportSource {
    data class Files(val request: ChatImportTarget.Request) : ImportSource
    data class Found(val found: ChatImport.Found) : ImportSource
}

/**
 * Import d'un historique : lecture, choix de la conversation (suivie ou nouvelle) et de « qui est moi »,
 * puis ajout sans doublon. [onDone] reçoit la clé de la conversation remplie (null si annulé).
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ChatImportDialog(source: ImportSource, onDone: (String?) -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val convs by MessageHub.convs.collectAsStateWithLifecycle()
    var loaded by remember { mutableStateOf<ChatImport.Loaded?>(null) }
    var failed by remember { mutableStateOf(false) }
    var chatIdx by remember { mutableStateOf(0) }
    var targetKey by remember { mutableStateOf<String?>(null) }   // null = nouvelle conversation
    var me by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }

    LaunchedEffect(source) {
        val l = runCatching {
            when (source) {
                is ImportSource.Files -> ChatImport.load(ctx, source.request.uris, source.request.subject)
                is ImportSource.Found -> ChatImport.loadFound(ctx, source.found)
            }
        }.getOrNull()
        loaded = l
        failed = l == null
    }
    DisposableEffect(Unit) { onDispose { loaded?.let { if (!busy) ChatImport.cleanup(it) } } }

    val l = loaded
    val chat = l?.chats?.getOrNull(chatIdx)
    // Conversation proposée : celle demandée, sinon celle au même nom, sinon une nouvelle
    LaunchedEffect(chat) {
        if (chat == null) return@LaunchedEffect
        val preset = (source as? ImportSource.Files)?.request?.convKey
        val match = convs.firstOrNull { it.key == preset }
            ?: convs.firstOrNull { it.app == chat.app && chat.title.isNotBlank() && TextNorm.norm(it.name) == TextNorm.norm(chat.title) }
        targetKey = match?.key
        me = ChatImport.guessMe(chat, match)
    }

    AlertDialog(
        onDismissRequest = { if (!busy) onDone(null) },
        icon = { Icon(Icons.Filled.History, null) },
        title = { Text("Importer un historique") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                when {
                    failed -> Text(
                        "Ce fichier n'est pas un historique WhatsApp ou Telegram reconnu. Dans WhatsApp : discussion → ⋮ → Plus → Exporter la discussion. " +
                            "Dans Telegram Desktop (ordinateur) : ⋮ → Exporter l'historique, format JSON.",
                    )
                    l == null || chat == null -> { Text("Lecture de l'historique…"); LinearProgressIndicator(Modifier.fillMaxWidth()) }
                    else -> {
                        if (l.chats.size > 1) {
                            Text("Discussion à importer", style = MaterialTheme.typography.labelLarge)
                            FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                l.chats.forEachIndexed { i, c -> FilterChip(selected = i == chatIdx, onClick = { chatIdx = i }, label = { RawText(c.title.ifBlank { "?" }, maxLines = 1) }) }
                            }
                        }
                        val msgs = chat.messages
                        RawText(
                            appName(chat.app) + (if (chat.title.isNotBlank()) " · " + chat.title else "") + "\n" +
                                I18n.trf("{0} messages, du {1} au {2}", msgs.size, day(msgs.first().time), day(msgs.last().time)) +
                                msgs.count { it.media.isNotEmpty() }.let { n -> if (n > 0) "\n" + I18n.trf("{0} avec fichier (photo, vocal…)", n) else "" },
                            style = MaterialTheme.typography.bodyMedium,
                        )
                        Text("Dans quelle conversation ?", style = MaterialTheme.typography.labelLarge)
                        FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            convs.filter { it.app == chat.app }.forEach { c ->
                                FilterChip(selected = targetKey == c.key, onClick = { targetKey = c.key; me = ChatImport.guessMe(chat, c) ?: me }, label = { RawText(c.name, maxLines = 1) })
                            }
                            FilterChip(
                                selected = targetKey == null, onClick = { targetKey = null },
                                label = { RawText(I18n.trf("Nouvelle : {0}", chat.title.ifBlank { I18n.tr("sans nom") }), maxLines = 1) },
                            )
                        }
                        if (chat.senders.size > 1) {
                            Text("Lequel est toi ? (tes messages s'afficheront à droite)", style = MaterialTheme.typography.labelLarge)
                            FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                chat.senders.take(12).forEach { (name, n) ->
                                    FilterChip(selected = me == name, onClick = { me = if (me == name) null else name }, label = { RawText("$name ($n)", maxLines = 1) })
                                }
                            }
                        }
                        Text(
                            "Les messages déjà dans Calepin ne sont pas doublés. Les nouveaux messages continueront d'arriver par les notifications.",
                            style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                        if (busy) LinearProgressIndicator(Modifier.fillMaxWidth())
                    }
                }
            }
        },
        confirmButton = {
            if (chat != null && l != null) TextButton(enabled = !busy, onClick = {
                busy = true
                scope.launch {
                    val target = convs.firstOrNull { it.key == targetKey } ?: Conv(chat.app, chat.title.ifBlank { appName(chat.app) })
                    val r = runCatching { ChatImport.importInto(ctx, target, chat, me, l.dir) }.getOrNull()
                    (source as? ImportSource.Found)?.let { ChatImport.markFile(ctx, it.found.file) }
                    ChatImport.cleanup(l)
                    busy = false
                    Toast.makeText(
                        ctx,
                        if (r == null) I18n.tr("L'import a échoué.")
                        else I18n.trf("{0} message(s) ajouté(s), {1} déjà présent(s).", r.added, r.already),
                        Toast.LENGTH_LONG,
                    ).show()
                    onDone(if (r == null) null else target.key)
                }
            }) { Text("Importer") }
        },
        dismissButton = { TextButton(enabled = !busy, onClick = { onDone(null) }) { Text(if (failed) "Fermer" else "Annuler") } },
    )
}

/**
 * Historique des conversations : import d'un export WhatsApp / Telegram, synchronisation des exports
 * présents dans le téléphone, et exports trouvés à rattacher.
 */
@Composable
fun ChatHistoryCard(onImport: (ImportSource) -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var syncing by remember { mutableStateOf(false) }
    var found by remember { mutableStateOf<List<ChatImport.Found>>(emptyList()) }
    var help by remember { mutableStateOf(false) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        if (uris.isNotEmpty()) onImport(ImportSource.Files(ChatImportTarget.Request(uris)))
    }
    fun sync(manual: Boolean) {
        syncing = true
        scope.launch {
            val r = runCatching { ChatImport.sync(ctx) }.getOrNull()
            syncing = false
            found = r?.unmatched.orEmpty()
            val total = r?.added?.values?.sum() ?: 0
            if (total > 0) Toast.makeText(
                ctx, I18n.trf("Historique synchronisé : {0} nouveau(x) message(s) ({1}).", total, r!!.added.keys.joinToString(", ")), Toast.LENGTH_LONG,
            ).show()
            else if (manual) Toast.makeText(
                ctx,
                if (!fr.jeremy.calepin.tools.StorageAccess.granted(ctx)) I18n.tr("Pour chercher les exports dans le téléphone, autorise l'accès aux fichiers (Téléphone → Fichiers).")
                else I18n.tr("Rien de nouveau à synchroniser."),
                Toast.LENGTH_LONG,
            ).show()
        }
    }
    // À l'ouverture : les nouveaux exports rangés dans Téléchargements sont ajoutés tout seuls
    LaunchedEffect(Unit) { if (fr.jeremy.calepin.tools.StorageAccess.granted(ctx)) sync(false) }

    Surface(shape = MaterialTheme.shapes.large, color = MaterialTheme.colorScheme.surfaceContainerLow, border = appBorder(), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.History, null, tint = MaterialTheme.colorScheme.primary)
                Spacer(Modifier.width(10.dp))
                Text("Historique des conversations", style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
                TextButton(onClick = { help = !help }) { Text(if (help) "Masquer" else "Comment ?") }
            }
            if (help) Text(
                "WhatsApp : ouvre la discussion → ⋮ → Plus → Exporter la discussion (avec les médias pour garder photos et vocaux) → choisis Calepin. " +
                    "Tu peux aussi l'enregistrer dans Téléchargements : Calepin la synchronise tout seul.\n" +
                    "Telegram : l'appli du téléphone ne sait pas exporter. Sur ordinateur, Telegram Desktop → discussion → ⋮ → Exporter l'historique, format JSON, " +
                    "puis copie le dossier ChatExport dans Téléchargements du téléphone (ou choisis result.json / le .zip ici).\n" +
                    "Les messages déjà présents ne sont jamais doublés : tu peux réimporter un export plus récent pour compléter.",
                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { fr.jeremy.calepin.LockGuard.external(); picker.launch(arrayOf("*/*")) }, modifier = Modifier.weight(1f)) {
                    Icon(Icons.Filled.UploadFile, null, Modifier.size(18.dp)); Text(" Importer")
                }
                OutlinedButton(enabled = !syncing, onClick = { sync(true) }, modifier = Modifier.weight(1f)) {
                    Icon(Icons.Filled.Sync, null, Modifier.size(18.dp)); Text(" Synchroniser")
                }
            }
            if (syncing) LinearProgressIndicator(Modifier.fillMaxWidth())
            if (found.isNotEmpty()) {
                Text("Exports trouvés dans le téléphone :", style = MaterialTheme.typography.labelLarge)
                found.forEach { f ->
                    Surface(onClick = { onImport(ImportSource.Found(f)); found = found - f }, shape = MaterialTheme.shapes.medium, color = MaterialTheme.colorScheme.surfaceContainerHigh, modifier = Modifier.fillMaxWidth()) {
                        Row(Modifier.padding(start = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f).padding(vertical = 8.dp)) {
                                RawText(appName(f.app) + " · " + f.title.ifBlank { f.file.name }, style = MaterialTheme.typography.titleSmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                RawText(I18n.tr("Toucher pour l'importer"), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            IconButton(onClick = { ChatImport.dismiss(ctx, f.file); found = found - f }) { Icon(Icons.Filled.Close, "Ne plus proposer") }
                        }
                    }
                }
            }
        }
    }
}
