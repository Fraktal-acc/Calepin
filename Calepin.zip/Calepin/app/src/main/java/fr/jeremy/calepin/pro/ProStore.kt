package fr.jeremy.calepin.pro

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.UUID

/** Un client ou un bien suivi (villa, appartement, bateau…). */
data class Client(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val kind: String = "Client",
    val address: String = "",
    val phone: String = "",
    val email: String = "",
    val notes: String = "",
    /** Tarif horaire en euros (0 = non renseigné). */
    val rate: Double = 0.0,
    val createdAt: Long = System.currentTimeMillis(),
) {
    fun toJson(): JSONObject = JSONObject().put("id", id).put("name", name).put("kind", kind).put("address", address)
        .put("phone", phone).put("email", email).put("notes", notes).put("rate", rate).put("createdAt", createdAt)

    companion object {
        fun fromJson(o: JSONObject) = Client(
            o.optString("id"), o.optString("name"), o.optString("kind", "Client"), o.optString("address"), o.optString("phone"),
            o.optString("email"), o.optString("notes"), o.optDouble("rate", 0.0).let { if (it.isNaN()) 0.0 else it }, o.optLong("createdAt"),
        )
    }
}

enum class Status(val label: String) { PLANIFIEE("Prévue"), EN_COURS("En cours"), FAITE("Faite"), FACTUREE("Facturée") }

/** Une intervention chez un client : date, durée, liste de contrôle, photos avant / après. */
data class Intervention(
    val id: String = UUID.randomUUID().toString(),
    val clientId: String,
    val title: String,
    val date: Long,
    val minutes: Int = 0,
    val status: Status = Status.PLANIFIEE,
    /** Lignes « ☐ … » / « ☑ … ». */
    val checklist: String = "",
    val notes: String = "",
    val before: List<String> = emptyList(),
    val after: List<String> = emptyList(),
    /** Chronomètre lancé (heure de départ), 0 sinon. */
    val timerStart: Long = 0L,
) {
    fun toJson(): JSONObject = JSONObject().put("id", id).put("clientId", clientId).put("title", title).put("date", date)
        .put("minutes", minutes).put("status", status.name).put("checklist", checklist).put("notes", notes)
        .put("before", JSONArray(before)).put("after", JSONArray(after)).put("timerStart", timerStart)

    companion object {
        private fun list(a: JSONArray?) = a?.let { (0 until it.length()).map { i -> it.optString(i) } }.orEmpty()
        fun fromJson(o: JSONObject) = Intervention(
            o.optString("id"), o.optString("clientId"), o.optString("title"), o.optLong("date"), o.optInt("minutes"),
            runCatching { Status.valueOf(o.optString("status")) }.getOrDefault(Status.PLANIFIEE),
            o.optString("checklist"), o.optString("notes"), list(o.optJSONArray("before")), list(o.optJSONArray("after")),
            o.optLong("timerStart"),
        )
    }
}

/** Listes de contrôle toutes prêtes. */
object ChecklistTemplates {
    val ALL = linkedMapOf(
        "Ouverture de villa" to listOf(
            "Ouvrir volets et aérer", "Remettre l'eau et le chauffe-eau", "Vérifier l'électricité et le tableau",
            "Contrôler fuites et humidité", "Faire les lits", "Courses d'accueil", "Vérifier piscine et jardin", "Relever les compteurs",
        ),
        "Fermeture de villa" to listOf(
            "Vider et débrancher le réfrigérateur", "Couper l'eau", "Fermer volets et fenêtres", "Vérifier les poubelles",
            "Débrancher les appareils", "Activer l'alarme", "Relever les compteurs", "Photos des pièces",
        ),
        "Passage de contrôle" to listOf(
            "Faire le tour extérieur", "Vérifier portes et fenêtres", "Contrôler fuites et humidité", "Aérer 15 minutes",
            "Relever le courrier", "Faire couler l'eau", "Vérifier l'alarme", "Photos",
        ),
        "Ménage" to listOf("Poussières", "Sols", "Cuisine", "Salles de bain et WC", "Linge et lits", "Vitres", "Poubelles"),
        "Jardin et piscine" to listOf("Tonte", "Taille des haies", "Arrosage", "Ramassage des feuilles", "Analyse de l'eau", "Nettoyage du bassin", "Skimmers et filtre"),
        "Accueil de locataires" to listOf("Remise des clés", "État des lieux d'entrée", "Explications (Wi-Fi, chauffage, alarme)", "Photos", "Caution"),
    )

    fun text(name: String) = ALL[name].orEmpty().joinToString("\n") { "☐ $it" }
}

/** Stockage du mode pro (fichier JSON sur le téléphone, inclus dans la sauvegarde complète). */
class ProStore private constructor(ctx: Context) {
    private val file = File(ctx.filesDir, "pro.json")
    val photoDir: File = File(ctx.filesDir, "pro_photos").apply { mkdirs() }

    private val _clients = MutableStateFlow<List<Client>>(emptyList())
    val clients: StateFlow<List<Client>> = _clients
    private val _interventions = MutableStateFlow<List<Intervention>>(emptyList())
    val interventions: StateFlow<List<Intervention>> = _interventions

    init { load() }

    fun load() {
        val o = runCatching { JSONObject(file.readText()) }.getOrNull()
        _clients.value = o?.optJSONArray("clients")?.let { a -> (0 until a.length()).map { Client.fromJson(a.getJSONObject(it)) } }.orEmpty()
        _interventions.value = o?.optJSONArray("interventions")?.let { a -> (0 until a.length()).map { Intervention.fromJson(a.getJSONObject(it)) } }.orEmpty()
    }

    @Synchronized
    private fun persist() {
        val o = JSONObject()
            .put("clients", JSONArray().apply { _clients.value.forEach { put(it.toJson()) } })
            .put("interventions", JSONArray().apply { _interventions.value.forEach { put(it.toJson()) } })
        val tmp = File(file.parentFile, "pro.json.tmp")
        tmp.writeText(o.toString())
        tmp.renameTo(file)
    }

    fun upsert(c: Client) {
        val l = _clients.value.toMutableList()
        val i = l.indexOfFirst { it.id == c.id }
        if (i >= 0) l[i] = c else l += c
        _clients.value = l.sortedBy { it.name.lowercase() }
        persist()
    }

    fun deleteClient(id: String) {
        _interventions.value.filter { it.clientId == id }.forEach { deletePhotos(it) }
        _interventions.value = _interventions.value.filter { it.clientId != id }
        _clients.value = _clients.value.filter { it.id != id }
        persist()
    }

    fun upsert(iv: Intervention) {
        val l = _interventions.value.toMutableList()
        val i = l.indexOfFirst { it.id == iv.id }
        if (i >= 0) l[i] = iv else l += iv
        _interventions.value = l.sortedByDescending { it.date }
        persist()
    }

    fun deleteIntervention(id: String) {
        _interventions.value.firstOrNull { it.id == id }?.let { deletePhotos(it) }
        _interventions.value = _interventions.value.filter { it.id != id }
        persist()
    }

    private fun deletePhotos(iv: Intervention) = (iv.before + iv.after).forEach { File(photoDir, it).delete() }

    fun client(id: String) = _clients.value.firstOrNull { it.id == id }

    companion object {
        @Volatile private var instance: ProStore? = null
        fun get(ctx: Context): ProStore = instance ?: synchronized(this) { instance ?: ProStore(ctx.applicationContext).also { instance = it } }
    }
}
