package fr.jeremy.calepin.mail

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import org.json.JSONArray
import org.json.JSONObject
import java.security.KeyStore
import java.util.UUID
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/** Chiffrement SSL direct (port 993 / 465) ou STARTTLS (port 143 / 587). */
enum class Security { SSL, STARTTLS }

/** Une adresse mail de l'utilisateur, utilisée pour recevoir (IMAP) et envoyer (SMTP). */
data class MailAccount(
    val id: String = UUID.randomUUID().toString(),
    val email: String,
    val name: String = "",
    val user: String = email,
    val imapHost: String,
    val imapPort: Int = 993,
    val imapSec: Security = Security.SSL,
    val smtpHost: String,
    val smtpPort: Int = 465,
    val smtpSec: Security = Security.SSL,
) {
    val isGmail get() = imapHost.endsWith("gmail.com")

    fun toJson(): JSONObject = JSONObject().put("id", id).put("email", email).put("name", name).put("user", user)
        .put("ih", imapHost).put("ip", imapPort).put("is", imapSec.name)
        .put("sh", smtpHost).put("sp", smtpPort).put("ss", smtpSec.name)

    companion object {
        fun fromJson(o: JSONObject) = MailAccount(
            o.optString("id"), o.optString("email"), o.optString("name"), o.optString("user"),
            o.optString("ih"), o.optInt("ip", 993), runCatching { Security.valueOf(o.optString("is")) }.getOrDefault(Security.SSL),
            o.optString("sh"), o.optInt("sp", 465), runCatching { Security.valueOf(o.optString("ss")) }.getOrDefault(Security.SSL),
        )
    }
}

/** Réglages connus des fournisseurs courants (France surtout). [note] : conseil affiché à l'ajout. */
data class MailPreset(val label: String, val domains: List<String>, val imap: String, val imapPort: Int, val imapSec: Security, val smtp: String, val smtpPort: Int, val smtpSec: Security, val note: String = "")

object MailPresets {
    private const val APP_PWD = "Utilise un « mot de passe d'application » (créé dans la sécurité du compte, validation en deux étapes activée), pas ton mot de passe habituel."
    val ALL = listOf(
        MailPreset("Gmail", listOf("gmail.com", "googlemail.com"), "imap.gmail.com", 993, Security.SSL, "smtp.gmail.com", 465, Security.SSL,
            "Gmail : Compte Google → Sécurité → Validation en deux étapes → Mots de passe des applications. " + APP_PWD),
        MailPreset("Outlook / Hotmail", listOf("outlook.com", "outlook.fr", "hotmail.com", "hotmail.fr", "live.com", "live.fr", "msn.com"),
            "outlook.office365.com", 993, Security.SSL, "smtp-mail.outlook.com", 587, Security.STARTTLS,
            "Microsoft limite l'accès des applis de mail tierces : si la connexion est refusée, crée un mot de passe d'application dans la sécurité du compte Microsoft."),
        MailPreset("Yahoo", listOf("yahoo.com", "yahoo.fr", "ymail.com"), "imap.mail.yahoo.com", 993, Security.SSL, "smtp.mail.yahoo.com", 465, Security.SSL, APP_PWD),
        MailPreset("iCloud", listOf("icloud.com", "me.com", "mac.com"), "imap.mail.me.com", 993, Security.SSL, "smtp.mail.me.com", 587, Security.STARTTLS, APP_PWD),
        MailPreset("Orange", listOf("orange.fr", "wanadoo.fr"), "imap.orange.fr", 993, Security.SSL, "smtp.orange.fr", 465, Security.SSL),
        MailPreset("SFR", listOf("sfr.fr", "neuf.fr", "cegetel.net"), "imap.sfr.fr", 993, Security.SSL, "smtp.sfr.fr", 465, Security.SSL),
        MailPreset("Free", listOf("free.fr"), "imap.free.fr", 993, Security.SSL, "smtp.free.fr", 465, Security.SSL),
        MailPreset("Bouygues (bbox)", listOf("bbox.fr"), "imap4.bbox.fr", 993, Security.SSL, "smtp.bbox.fr", 587, Security.STARTTLS),
        MailPreset("La Poste", listOf("laposte.net"), "imap.laposte.net", 993, Security.SSL, "smtp.laposte.net", 465, Security.SSL),
        MailPreset("GMX", listOf("gmx.fr", "gmx.com", "gmx.net"), "imap.gmx.net", 993, Security.SSL, "mail.gmx.net", 465, Security.SSL),
        MailPreset("OVH (nom de domaine)", emptyList(), "ssl0.ovh.net", 993, Security.SSL, "ssl0.ovh.net", 465, Security.SSL,
            "Pour une adresse à ton nom de domaine hébergée chez OVH (identifiant = adresse complète)."),
    )

    fun forEmail(email: String): MailPreset? {
        val d = email.substringAfter('@', "").lowercase().trim()
        return ALL.firstOrNull { d in it.domains }
    }
}

/** Mots de passe chiffrés avec une clé du coffre Android (jamais en clair, jamais sauvegardés ailleurs). */
private object Secret {
    private const val ALIAS = "calepin_mail_key"

    private fun key(): SecretKey {
        val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (ks.getKey(ALIAS, null) as? SecretKey)?.let { return it }
        val kg = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        kg.init(
            KeyGenParameterSpec.Builder(ALIAS, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .build(),
        )
        return kg.generateKey()
    }

    fun encrypt(plain: String): String {
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        c.init(Cipher.ENCRYPT_MODE, key())
        val out = c.doFinal(plain.toByteArray(Charsets.UTF_8))
        return Base64.encodeToString(c.iv, Base64.NO_WRAP) + ":" + Base64.encodeToString(out, Base64.NO_WRAP)
    }

    fun decrypt(s: String): String? = runCatching {
        val iv = Base64.decode(s.substringBefore(':'), Base64.NO_WRAP)
        val data = Base64.decode(s.substringAfter(':'), Base64.NO_WRAP)
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        c.init(Cipher.DECRYPT_MODE, key(), GCMParameterSpec(128, iv))
        String(c.doFinal(data), Charsets.UTF_8)
    }.getOrNull()
}

object MailAccounts {
    private val _accounts = MutableStateFlow<List<MailAccount>>(emptyList())
    val accounts: StateFlow<List<MailAccount>> = _accounts
    @Volatile private var loaded = false
    private lateinit var app: Context

    private fun p() = app.getSharedPreferences("calepin_mail", Context.MODE_PRIVATE)

    fun init(ctx: Context) {
        if (loaded) return
        synchronized(this) {
            if (loaded) return
            app = ctx.applicationContext
            _accounts.value = runCatching {
                val a = JSONArray(p().getString("accounts", "[]"))
                (0 until a.length()).map { MailAccount.fromJson(a.getJSONObject(it)) }
            }.getOrDefault(emptyList())
            loaded = true
        }
    }

    private fun save(l: List<MailAccount>) {
        p().edit().putString("accounts", JSONArray().apply { l.forEach { put(it.toJson()) } }.toString()).apply()
        _accounts.value = l
    }

    fun put(ctx: Context, a: MailAccount, password: String?) {
        init(ctx)
        if (password != null) p().edit().putString("pwd_" + a.id, Secret.encrypt(password)).apply()
        save(_accounts.value.filter { it.id != a.id } + a)
    }

    fun remove(ctx: Context, a: MailAccount) {
        init(ctx)
        p().edit().remove("pwd_" + a.id).apply()
        save(_accounts.value.filter { it.id != a.id })
        MailClient.forget(a.id)
    }

    fun password(ctx: Context, a: MailAccount): String? {
        init(ctx)
        return p().getString("pwd_" + a.id, null)?.let { Secret.decrypt(it) }
    }
}
