package fr.jeremy.calepin.text

/**
 * Texte affiché pendant l'écriture d'une note : certaines parties du texte enregistré sont cachées
 * (repères de couleur, repères de photos) et des retours à la ligne sont ajoutés à l'affichage seulement
 * (texte qui passe à côté d'une photo, place réservée aux photos). Donne la correspondance des positions
 * dans les deux sens, pour le curseur et la sélection.
 */
class DisplayMap(val text: String, hidden: List<Hidden>, inserts: List<Insert>) {
    /**
     * Partie cachée [start, end). [after] : un curseur posé juste devant va après elle
     * (repère de photo) ; sinon il reste avant (repères de couleur : on écrit avec la mise en forme d'avant).
     */
    data class Hidden(val start: Int, val end: Int, val after: Boolean)

    /**
     * Texte ajouté à l'affichage en [pos]. [after] : le curseur en [pos] s'affiche après lui (après le dernier
     * ajout [after] posé en [pos] : ceux qui suivent restent après le curseur).
     */
    data class Insert(val pos: Int, val text: String, val after: Boolean)

    /** Morceau du texte affiché : soit du texte enregistré [start, end), soit du texte ajouté. */
    sealed class Piece {
        data class Orig(val start: Int, val end: Int) : Piece()
        data class Added(val text: String) : Piece()
    }

    val visible: String
    val pieces: List<Piece>
    private val o2v: IntArray
    /** Pour chaque caractère affiché : sa position dans le texte enregistré, ou -(pos + 1) s'il est ajouté en pos. */
    private val src: IntArray
    private val afterHiddenEnd = HashMap<Int, Int>()

    val isIdentity: Boolean

    init {
        val n = text.length
        val hide = BooleanArray(n)
        hidden.forEach { h ->
            for (i in h.start.coerceIn(0, n) until h.end.coerceIn(0, n)) hide[i] = true
            if (h.after && h.end > h.start) afterHiddenEnd[h.start] = h.end
        }
        val ins = inserts.filter { it.pos in 0..n && it.text.isNotEmpty() }.sortedBy { it.pos }
        isIdentity = ins.isEmpty() && hidden.none { it.end > it.start }
        val sb = StringBuilder(n + 16)
        val srcList = IntArray(n + ins.sumOf { it.text.length } + 1)
        val o = IntArray(n + 1)
        val ps = ArrayList<Piece>()
        var origStart = -1
        fun closeOrig(endAt: Int) { if (origStart >= 0) { ps += Piece.Orig(origStart, endAt); origStart = -1 } }
        var k = 0
        for (p in 0..n) {
            val before = sb.length
            var afterLen = -1
            while (k < ins.size && ins[k].pos == p) {
                closeOrig(p)
                val t = ins[k].text
                t.forEach { ch -> srcList[sb.length] = -(p + 1); sb.append(ch) }
                ps += Piece.Added(t)
                if (ins[k].after) afterLen = sb.length
                k++
            }
            o[p] = if (afterLen >= 0) afterLen else before
            if (p < n) {
                if (hide[p]) closeOrig(p)
                else {
                    if (origStart < 0) origStart = p
                    srcList[sb.length] = p
                    sb.append(text[p])
                }
            }
        }
        closeOrig(n)
        visible = sb.toString()
        pieces = ps
        o2v = o
        src = srcList.copyOf(visible.length)
    }

    fun toVisible(offset: Int): Int = if (isIdentity) offset.coerceIn(0, text.length) else o2v[offset.coerceIn(0, text.length)]

    fun toOriginal(offset: Int): Int {
        if (isIdentity) return offset.coerceIn(0, text.length)
        val t = offset.coerceIn(0, visible.length)
        var base = if (t == 0) 0 else src[t - 1].let { if (it >= 0) it + 1 else -it - 1 }
        var guard = 0
        while (guard++ < 1000) base = afterHiddenEnd[base] ?: break
        return base.coerceIn(0, text.length)
    }
}
