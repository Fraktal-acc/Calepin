package fr.jeremy.calepin.places

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import android.location.Geocoder
import android.location.Location
import android.location.LocationManager
import android.os.Build
import androidx.core.content.ContextCompat
import fr.jeremy.calepin.i18n.I18n
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import okhttp3.HttpUrl.Companion.toHttpUrl
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit
import kotlin.coroutines.resume

/** Lieu trouvé : ville, code postal ou position du téléphone (rappels par lieu). */
data class GeoPlace(val name: String, val detail: String, val lat: Double, val lon: Double)

/** Recherche d'un lieu par son nom ou son code postal, et position actuelle du téléphone. */
object PlaceSearch {
    private val http by lazy {
        OkHttpClient.Builder().connectTimeout(8, TimeUnit.SECONDS).readTimeout(12, TimeUnit.SECONDS).build()
    }

    fun hasLocationPermission(ctx: Context) =
        ContextCompat.checkSelfPermission(ctx, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED

    /** Recherche d'une ville ou d'un code postal (Open-Meteo, complété par le géocodeur du téléphone). */
    suspend fun search(ctx: Context, q: String): List<GeoPlace> = withContext(Dispatchers.IO) {
        val out = ArrayList<GeoPlace>()
        runCatching {
            val url = "https://geocoding-api.open-meteo.com/v1/search".toHttpUrl().newBuilder()
                .addQueryParameter("name", q.trim())
                .addQueryParameter("count", "10")
                .addQueryParameter("language", I18n.language.value.code)
                .addQueryParameter("format", "json")
                .build()
            val text = http.newCall(Request.Builder().url(url).build()).execute().use { it.body?.string().orEmpty() }
            val arr = JSONObject(text).optJSONArray("results") ?: JSONArray()
            for (i in 0 until arr.length()) {
                val r = arr.getJSONObject(i)
                val pcs = r.optJSONArray("postcodes")
                val pc = if (pcs != null && pcs.length() > 0) pcs.optString(0) else ""
                val detail = listOf(pc, r.optString("admin2"), r.optString("admin1"), r.optString("country"))
                    .filter { it.isNotBlank() }.distinct().joinToString(", ")
                out += GeoPlace(r.optString("name"), detail, r.optDouble("latitude"), r.optDouble("longitude"))
            }
        }
        // Codes postaux et adresses : le géocodeur du téléphone les connaît souvent mieux
        if (out.size < 3 && Geocoder.isPresent()) {
            runCatching {
                @Suppress("DEPRECATION")
                Geocoder(ctx, I18n.locale).getFromLocationName(q.trim(), 5)?.forEach { a ->
                    val name = a.locality ?: a.subAdminArea ?: a.featureName ?: q.trim()
                    val detail = listOfNotNull(a.postalCode, a.adminArea, a.countryName).filter { it.isNotBlank() }.joinToString(", ")
                    if (out.none { kotlin.math.abs(it.lat - a.latitude) < 0.02 && kotlin.math.abs(it.lon - a.longitude) < 0.02 }) {
                        out += GeoPlace(name, detail, a.latitude, a.longitude)
                    }
                }
            }
        }
        out
    }

    /** Position actuelle du téléphone (réseau ou GPS), avec le nom de la ville. */
    @SuppressLint("MissingPermission")
    suspend fun locate(ctx: Context): GeoPlace? {
        if (!hasLocationPermission(ctx)) return null
        val lm = ctx.getSystemService(LocationManager::class.java) ?: return null
        val providers = buildList {
            if (Build.VERSION.SDK_INT >= 31) add(LocationManager.FUSED_PROVIDER)
            add(LocationManager.NETWORK_PROVIDER)
            add(LocationManager.GPS_PROVIDER)
        }.filter { runCatching { lm.isProviderEnabled(it) }.getOrDefault(false) }
        var loc: Location? = null
        if (Build.VERSION.SDK_INT >= 30) {
            for (pr in providers) {
                loc = withTimeoutOrNull(12_000) {
                    suspendCancellableCoroutine<Location?> { cont ->
                        val signal = android.os.CancellationSignal()
                        cont.invokeOnCancellation { signal.cancel() }
                        runCatching {
                            lm.getCurrentLocation(pr, signal, ContextCompat.getMainExecutor(ctx)) { l -> if (cont.isActive) cont.resume(l) }
                        }.onFailure { if (cont.isActive) cont.resume(null) }
                    }
                }
                if (loc != null) break
            }
        }
        if (loc == null) {
            loc = (providers + LocationManager.PASSIVE_PROVIDER).mapNotNull { runCatching { lm.getLastKnownLocation(it) }.getOrNull() }
                .maxByOrNull { it.time }
        }
        val l = loc ?: return null
        val name = withContext(Dispatchers.IO) {
            runCatching {
                if (!Geocoder.isPresent()) null
                else {
                    @Suppress("DEPRECATION")
                    Geocoder(ctx, I18n.locale).getFromLocation(l.latitude, l.longitude, 1)?.firstOrNull()
                }
            }.getOrNull()
        }
        return GeoPlace(
            name = name?.locality ?: name?.subAdminArea ?: I18n.tr("Ma position"),
            detail = listOfNotNull(name?.postalCode, name?.countryName).joinToString(", "),
            lat = l.latitude, lon = l.longitude,
        )
    }
}
