package fr.jeremy.calepin.detect

import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

enum class EntityType(val label: String) {
    PHONE("Téléphone"),
    EMAIL("E-mail"),
    URL("Lien"),
    DATE("Date"),
    ADDRESS("Adresse"),
}

/**
 * Élément reconnu dans le texte d'une note.
 * [start]/[end] : position dans le texte (fin exclusive).
 * [value] : valeur exploitable (numéro nettoyé, URL complète, adresse, date lisible).
 */
data class Entity(
    val type: EntityType,
    val start: Int,
    val end: Int,
    val text: String,
    val value: String,
    val timeMillis: Long? = null,
    val hasTime: Boolean = false,
    /** Pour un téléphone : « 🇮🇹 Italie (+39) ». */
    val country: String? = null,
)

/**
 * Reconnaît téléphones (français et internationaux, avec le pays), , e-mails, liens,
 * dates en français (12/10, 12/10/2026, 2026-10-12, 12 octobre, 1er mai 2027,
 * demain, après-demain, lundi prochain, avec heure « à 14h30 ») et adresses
 * françaises (12 avenue Winston Churchill, 06190 Roquebrune-Cap-Martin).
 */
object EntityDetector {

    private const val UP = "A-ZÀ-ÖØ-Ý"
    private const val WEEKDAYS = "lundi|mardi|mercredi|jeudi|vendredi|samedi|dimanche"
    private const val MONTHS =
        "janvier|janv|février|fevrier|févr|fevr|fév|fev|mars|avril|avr|mai|juin|juillet|juil|août|aout|" +
            "septembre|sept|octobre|oct|novembre|nov|décembre|decembre|déc|dec"
    private const val TIME =
        """(?:[ \t]*(?:à|a|vers|dès|de|,|-)?[ \t]*([01]?\d|2[0-3])[ \t]*[hH:][ \t]*([0-5]\d)?(?!\d))?"""
    private const val STREET =
        """rue|avenue|av\.|boulevard|bd|bld|chemin|chem\.|ch\.|place|pl\.|allée|allee|impasse|imp\.|route|rte|""" +
            """quai|cours|square|promenade|prom\.|montée|montee|traverse|sentier|passage|esplanade|corniche|""" +
            """lotissement|résidence|residence|rond-point|voie|villa|domaine|hameau"""
    private const val WORD =
        """(?:[$UP][\p{L}\d'’\-.]*|\d{1,4}(?:er|e)?(?![\d\p{L}])|d[eu]|des|la|le|les|[ldLD]['’][\p{L}\-]+|et|sur|sous|en|aux?|saint|sainte)"""

    private val rxEmail = Regex("""[A-Za-z0-9._%+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,}""")
    private val rxUrl = Regex("""(?i)(?<![\p{L}\d@./])(?:https?://|www\.)[^\s<>"]+""")

    /** Numéro français national : 0 + 9 chiffres, espaces/points/tirets facultatifs et placés n'importe où. */
    private val rxPhoneNational = Regex("""(?<![\d+\p{L}])0[1-9](?:[ .\-]?\d){8}(?!\d)""")

    /** Numéro international : +XX ou 00XX, puis chiffres avec ou sans séparateurs. */
    private val rxPhoneIntl = Regex(
        """(?<![\d+\p{L}])(?:\+|00)[ ]?(?:\(0\)[ ]?)?\d(?:[ .\-]?(?:\(0\)[ ]?)?\(?\d\)?){6,17}(?!\d)"""
    )

    private val rxDateNum = Regex("""(?<![\d/.\-])(\d{1,2})([/.\-])(\d{1,2})(?:\2(\d{4}|\d{2}))?(?![\d/.\-]\d)(?!\d)$TIME""")
    private val rxDateIso = Regex("""(?<!\d)(\d{4})-(\d{2})-(\d{2})(?:[T ](\d{2}):(\d{2}))?(?!\d)""")
    private val rxDateText = Regex(
        """(?i)(?<![\p{L}\d])(?:($WEEKDAYS)[ \t]+)?(1er|\d{1,2})[ \t]+($MONTHS)(?!\p{L})\.?(?:[ \t]+(\d{4}))?(?!\d)$TIME"""
    )
    private val rxDateRel = Regex(
        """(?i)(?<![\p{L}\d])(aujourd['’]hui|apr[èe]s-demain|demain|(?:$WEEKDAYS)(?:[ \t]+prochain)?)(?!\p{L})$TIME"""
    )

    private val rxAddress = Regex(
        """(?<![\p{L}\d])(?:\d{1,4}(?:[ ]?(?:bis|ter|b|t))?[ \t]*,?[ \t]+)?(?i:$STREET)(?!\p{L})(?:[ \t]+$WORD){1,8}""" +
            """(?:[ \t]*,?[ \t]*\d{5}(?:[ \t]+[$UP][\p{L}'’\-]*(?:[ \-]+(?:[$UP][\p{L}'’\-]*|sur|sous|en|le|la|les|de|du|des|lès)){0,5})?)?"""
    )
    private val rxPostalCity = Regex(
        """(?<![\d.\-/])(\d{5})[ \t]+([$UP][\p{L}'’\-]*(?:[ \-]+(?:[$UP][\p{L}'’\-]*|sur|sous|en|le|la|les|de|du|des|lès)){0,5})(?!\p{L})"""
    )

    private val CONNECTORS = setOf(
        "de", "du", "des", "la", "le", "les", "et", "sur", "sous", "en", "a", "à", "au", "aux", "lès", "l", "d",
    )
    private val NOT_CITIES = setOf("euros", "eur", "km", "kg", "habitants", "personnes", "mètres", "metres", "pages")

    private val MONTH_INDEX: Map<String, Int> = mapOf(
        "janvier" to 0, "janv" to 0,
        "février" to 1, "fevrier" to 1, "févr" to 1, "fevr" to 1, "fév" to 1, "fev" to 1,
        "mars" to 2, "avril" to 3, "avr" to 3, "mai" to 4, "juin" to 5,
        "juillet" to 6, "juil" to 6, "août" to 7, "aout" to 7,
        "septembre" to 8, "sept" to 8, "octobre" to 9, "oct" to 9,
        "novembre" to 10, "nov" to 10, "décembre" to 11, "decembre" to 11, "déc" to 11, "dec" to 11,
    )
    private val WEEKDAY_INDEX: Map<String, Int> = mapOf(
        "lundi" to Calendar.MONDAY, "mardi" to Calendar.TUESDAY, "mercredi" to Calendar.WEDNESDAY,
        "jeudi" to Calendar.THURSDAY, "vendredi" to Calendar.FRIDAY, "samedi" to Calendar.SATURDAY,
        "dimanche" to Calendar.SUNDAY,
    )

    /** Horloge injectable pour les tests. */
    var now: () -> Long = { System.currentTimeMillis() }

    fun detect(text: String): List<Entity> {
        if (text.isBlank()) return emptyList()

        // 1) Éléments « forts » : jamais coupés par une date ou une adresse.
        val strong = mutableListOf<Entity>()
        rxEmail.findAll(text).forEach { m ->
            strong += Entity(EntityType.EMAIL, m.range.first, m.range.last + 1, m.value, m.value)
        }
        rxUrl.findAll(text).forEach { m ->
            val t = m.value.trimEnd('.', ',', ';', ':', '!', '?', ')', ']', '»', '\'', '’')
            if (t.length > 4) {
                val url = if (t.startsWith("www.", ignoreCase = true)) "https://$t" else t
                strong += Entity(EntityType.URL, m.range.first, m.range.first + t.length, t, url)
            }
        }
        rxPhoneIntl.findAll(text).forEach { m ->
            intlPhone(text, m.range.first, m.range.last + 1)?.let { strong += it }
        }
        rxPhoneNational.findAll(text).forEach { m ->
            strong += Entity(
                EntityType.PHONE, m.range.first, m.range.last + 1, m.value,
                m.value.filter { it.isDigit() }, country = PhoneCountries.france.label,
            )
        }
        val result = pickNonOverlapping(strong).toMutableList()

        // 2) Dates et adresses.
        val weak = mutableListOf<Entity>()
        weak += findDates(text)
        weak += findAddresses(text)

        val ordered = weak.sortedWith(compareBy<Entity>({ it.start }, { -(it.end - it.start) }))
        for (e in ordered) {
            val clashes = result.filter { it.start < e.end && e.start < it.end }
            val candidate: Entity? = when {
                clashes.isEmpty() -> e
                e.type == EntityType.ADDRESS -> {
                    val cut = clashes.minOf { it.start }
                    if (cut > e.start) truncateAddress(text, e, cut) else null
                }
                else -> null
            }
            if (candidate != null && result.none { it.start < candidate.end && candidate.start < it.end }) {
                result += candidate
            }
        }
        return result.sortedBy { it.start }
    }

    private fun pickNonOverlapping(list: List<Entity>): List<Entity> {
        val out = mutableListOf<Entity>()
        for (e in list.sortedWith(compareBy<Entity>({ it.start }, { -(it.end - it.start) }))) {
            if (out.none { it.start < e.end && e.start < it.end }) out += e
        }
        return out
    }

    /**
     * Valide un numéro international, identifie le pays par son indicatif et retire les chiffres
     * en trop collés à la fin (« +44 7911 123456 2 fois » → « +44 7911 123456 »).
     */
    private fun intlPhone(text: String, start: Int, endRaw: Int): Entity? {
        var end = endRaw
        fun digitsOf(e: Int): String {
            val d = text.substring(start, e).replace("(0)", "").filter { it.isDigit() }
            return if (d.startsWith("00")) d.substring(2) else d
        }
        var d = digitsOf(end)
        val c = PhoneCountries.find(d) ?: return null
        val max = c.code.length + c.maxLen
        while (d.length > max) {
            val cut = text.lastIndexOfAny(charArrayOf(' ', '.', '-'), end - 1)
            if (cut <= start) return null
            end = cut
            while (end > start && !text[end - 1].isDigit() && text[end - 1] != ')') end--
            d = digitsOf(end)
        }
        if (d.length < c.code.length + c.minLen) return null
        val shown = text.substring(start, end)
        return Entity(EntityType.PHONE, start, end, shown, "+$d", country = c.label)
    }

    // ---------------------------------------------------------------- Dates

    private fun findDates(text: String): List<Entity> {
        val out = mutableListOf<Entity>()

        rxDateNum.findAll(text).forEach { m ->
            val g = m.groupValues
            val day = g[1].toInt()
            val month = g[3].toInt()
            val sep = g[2]
            val yearRaw = g[4]
            if (yearRaw.isEmpty() && sep != "/") return@forEach
            if (month !in 1..12 || day !in 1..31) return@forEach
            val year = yearRaw.takeIf { it.isNotEmpty() }?.toInt()?.let { if (it < 100) 2000 + it else it }
            val h = g[5].takeIf { it.isNotEmpty() }?.toInt()
            val mi = g[6].takeIf { it.isNotEmpty() }?.toInt()
            makeDate(year, month - 1, day, h, mi)?.let { t ->
                out += dateEntity(text, m.range.first, m.range.last + 1, t, h != null)
            }
        }

        rxDateIso.findAll(text).forEach { m ->
            val g = m.groupValues
            val h = g[4].takeIf { it.isNotEmpty() }?.toInt()
            val mi = g[5].takeIf { it.isNotEmpty() }?.toInt()
            makeDate(g[1].toInt(), g[2].toInt() - 1, g[3].toInt(), h, mi)?.let { t ->
                out += dateEntity(text, m.range.first, m.range.last + 1, t, h != null)
            }
        }

        rxDateText.findAll(text).forEach { m ->
            val g = m.groupValues
            val day = if (g[2].equals("1er", ignoreCase = true)) 1 else g[2].toInt()
            val month = MONTH_INDEX[g[3].lowercase()] ?: return@forEach
            val year = g[4].takeIf { it.isNotEmpty() }?.toInt()
            val h = g[5].takeIf { it.isNotEmpty() }?.toInt()
            val mi = g[6].takeIf { it.isNotEmpty() }?.toInt()
            makeDate(year, month, day, h, mi)?.let { t ->
                out += dateEntity(text, m.range.first, m.range.last + 1, t, h != null)
            }
        }

        rxDateRel.findAll(text).forEach { m ->
            val g = m.groupValues
            val word = g[1].lowercase().replace('’', '\'')
            val h = g[2].takeIf { it.isNotEmpty() }?.toInt()
            val mi = g[3].takeIf { it.isNotEmpty() }?.toInt()
            val cal = Calendar.getInstance().apply {
                timeInMillis = now()
                set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0)
                set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
            }
            when {
                word == "aujourd'hui" -> Unit
                word == "demain" -> cal.add(Calendar.DAY_OF_YEAR, 1)
                word.startsWith("apr") -> cal.add(Calendar.DAY_OF_YEAR, 2)
                else -> {
                    val wd = WEEKDAY_INDEX[word.substringBefore(' ').substringBefore('\t')] ?: return@forEach
                    // Un jour seul (« mardi ») n'est retenu qu'avec « prochain » ou une heure.
                    if (!word.contains("prochain") && h == null) return@forEach
                    var diff = (wd - cal.get(Calendar.DAY_OF_WEEK) + 7) % 7
                    if (diff == 0) diff = 7
                    cal.add(Calendar.DAY_OF_YEAR, diff)
                }
            }
            if (h != null) {
                cal.set(Calendar.HOUR_OF_DAY, h)
                cal.set(Calendar.MINUTE, mi ?: 0)
            }
            out += dateEntity(text, m.range.first, m.range.last + 1, cal.timeInMillis, h != null)
        }
        return out
    }

    private fun dateEntity(text: String, start: Int, endRaw: Int, t: Long, hasTime: Boolean): Entity {
        var end = endRaw
        while (end > start && text[end - 1].isWhitespace()) end--
        return Entity(EntityType.DATE, start, end, text.substring(start, end), formatDate(t, hasTime), t, hasTime)
    }

    private fun makeDate(year: Int?, month: Int, day: Int, h: Int?, mi: Int?): Long? {
        fun build(y: Int): Long? = try {
            Calendar.getInstance().apply {
                isLenient = false
                clear()
                set(y, month, day, h ?: 0, mi ?: 0)
            }.timeInMillis
        } catch (e: IllegalArgumentException) {
            null
        }
        if (year != null) return build(year)
        val current = Calendar.getInstance().apply { timeInMillis = now() }
        val y = current.get(Calendar.YEAR)
        val t = build(y) ?: return build(y + 1)
        // Sans année : on prend la prochaine occurrence (une date passée de plus d'un jour bascule à l'an prochain).
        return if (t < now() - 86_400_000L) build(y + 1) ?: t else t
    }

    fun formatDate(t: Long, hasTime: Boolean): String {
        val d = SimpleDateFormat("EEEE d MMMM yyyy", Locale.FRANCE).format(Date(t))
        val s = if (hasTime) d + " à " + SimpleDateFormat("HH'h'mm", Locale.FRANCE).format(Date(t)) else d
        return s.replaceFirstChar { it.uppercase() }
    }

    // ------------------------------------------------------------- Adresses

    private fun findAddresses(text: String): List<Entity> {
        val out = mutableListOf<Entity>()
        rxAddress.findAll(text).forEach { m ->
            addressEntity(text, m.range.first, m.range.last + 1)?.let { out += it }
        }
        rxPostalCity.findAll(text).forEach { m ->
            val firstWord = m.groupValues[2].substringBefore(' ').lowercase()
            if (firstWord in NOT_CITIES) return@forEach
            addressEntity(text, m.range.first, m.range.last + 1, requireStreetName = false)?.let { out += it }
        }
        return out
    }

    private fun addressEntity(text: String, start: Int, end: Int, requireStreetName: Boolean = true): Entity? {
        val cleaned = trimTail(text.substring(start, end))
        if (cleaned.isEmpty()) return null
        if (requireStreetName) {
            // Il faut au moins un mot avec majuscule (nom de voie) après le type de voie.
            val afterType = cleaned.replaceFirst(Regex("""^\d{1,4}\S*[ \t,]*"""), "").substringAfter(' ', "")
            if (afterType.isBlank() || afterType.none { it.isUpperCase() || it.isDigit() }) return null
        }
        val value = cleaned.replace(Regex("""\s+"""), " ")
        return Entity(EntityType.ADDRESS, start, start + cleaned.length, cleaned, value)
    }

    private fun truncateAddress(text: String, e: Entity, cut: Int): Entity? =
        addressEntity(text, e.start, cut)

    private fun trimTail(s: String): String {
        val punct = charArrayOf(' ', '\t', '\n', ',', '.', ';', ':', '-', '(')
        var t = s.trimEnd(*punct)
        while (true) {
            val idx = t.lastIndexOfAny(charArrayOf(' ', '\t'))
            if (idx < 0) break
            val last = t.substring(idx + 1).lowercase()
            if (last in CONNECTORS || last.matches(Regex("""[ld]['’]"""))) {
                t = t.substring(0, idx).trimEnd(*punct)
            } else {
                break
            }
        }
        return t
    }
}
