package fr.jeremy.calepin.control

import org.json.JSONArray
import org.json.JSONObject
import java.util.Calendar
import java.util.TimeZone

/**
 * Lecture des historiques exportés :
 *  - WhatsApp : « Exporter la discussion » → fichier .txt (ou .zip avec les photos, vocaux…), toutes langues,
 *    formats Android et iPhone (« 13/10/2026 09:04 - Marc: Salut », « [13/10/2026 09:04:12] Marc: Salut »,
 *    « 10/13/26, 9:04 AM - Marc: Hi », « 13.10.26, 09:04 - Marc: Hallo ») ;
 *  - Telegram : export de Telegram Desktop (« Exporter l'historique ») en JSON (result.json) ou HTML (messages.html).
 * Rien ici ne dépend d'Android : c'est testable sur ordinateur.
 */
object ChatParsers {

    /** Un message lu dans un export. [media] : nom du fichier joint (dans le .zip ou le dossier d'export). */
    data class Raw(val time: Long, val from: String, val text: String, val media: String = "")

    /** Une discussion exportée : appli, nom de la discussion (si connu) et messages, du plus ancien au plus récent. */
    data class Chat(val app: String, val title: String, val messages: List<Raw>) {
        /** Participants, du plus bavard au moins bavard. */
        val senders: List<Pair<String, Int>>
            get() = messages.filter { it.from.isNotBlank() }.groupingBy { it.from }.eachCount().toList().sortedByDescending { it.second }
    }

    // ------------------------------------------------------------------ Nom de la discussion

    private val WA_TITLE = Regex(
        "(?i)(?:discussion whatsapp avec|whatsapp chat with|whatsapp-chat mit|chat de whatsapp con|chat whatsapp con|conversa do whatsapp com|whatsapp-chat met)\\s+(.+?)\\s*(?:\\(\\d+\\))?(?:\\.(?:txt|zip))?\\s*$",
    )

    /** « Discussion WhatsApp avec Marc.txt », « WhatsApp Chat with Famille.zip » → « Marc », « Famille ». */
    fun whatsAppTitle(nameOrSubject: String?): String? =
        nameOrSubject?.let { WA_TITLE.find(it.trim())?.groupValues?.get(1)?.trim()?.takeIf { t -> t.isNotEmpty() } }

    // ------------------------------------------------------------------ WhatsApp

    private val INVISIBLE = Regex("[\\u200e\\u200f\\u202a-\\u202e\\u2066-\\u2069\\ufeff]")
    private val WA_LINE = Regex(
        "^\\[?(\\d{1,4})[./\\-](\\d{1,2})[./\\-](\\d{2,4})[,\\s]+(\\d{1,2})[:.](\\d{2})(?:[:.](\\d{2}))?\\s*([AaPp]\\.?\\s?[Mm]\\.?)?\\]?\\s*(?:[-–]\\s*)?(.*)$",
    )
    private val WA_ATTACHED = Regex(
        "(?is)^([^<>\\n:]+?\\.[A-Za-z0-9]{2,5})\\s*\\((?:fichier joint|file attached|datei angeh[äa]ngt|archivo adjunto|file allegato|arquivo anexado|bestand bijgevoegd)\\)\\s*(.*)$",
    )
    private val WA_ATTACHED_IOS = Regex(
        "(?is)^<(?:attached|pi[èe]ce jointe|anhang|adjunto|allegato|anexo|bijlage)\\s*:\\s*([^>]+)>\\s*(.*)$",
    )
    private val WA_OMITTED = Regex(
        "(?i)^<?(?:m[ée]dias? omis|media omitted|medien ausgeschlossen|multimedia omitido|media omessi|m[íi]dia oculta|media weggelaten|image absente|image omitted|vid[ée]o absente|video omitted|audio omitted|audio absent|sticker omitted|document omitted|gif omitted)>?$",
    )

    private class Line(val a: Int, val b: Int, val y: Int, val h: Int, val mi: Int, val s: Int, val ampm: String, val rest: String)

    private fun clean(s: String) = s.replace(INVISIBLE, "").replace(' ', ' ').replace(' ', ' ')

    /** Lit le texte d'un export WhatsApp. [zone] : fuseau du téléphone (les heures de l'export sont locales). */
    fun parseWhatsApp(text: String, zone: TimeZone = TimeZone.getDefault()): List<Raw> {
        // 1) Lignes qui commencent par une date ; les autres continuent le message précédent
        val entries = mutableListOf<Pair<Line, StringBuilder>>()
        for (raw in text.lineSequence()) {
            val l = clean(raw).trimEnd('\r')
            val m = WA_LINE.matchEntire(l.trimStart())
            if (m != null) {
                val g = m.groupValues
                val y = g[3].toInt()
                // Année en premier (2026-10-13) : on remet dans l'ordre jour, mois, année
                val line = if (g[1].length == 4) Line(g[3].toInt(), g[2].toInt(), g[1].toInt(), g[4].toInt(), g[5].toInt(), g[6].toIntOrNull() ?: 0, g[7], g[8])
                else Line(g[1].toInt(), g[2].toInt(), y, g[4].toInt(), g[5].toInt(), g[6].toIntOrNull() ?: 0, g[7], g[8])
                entries += line to StringBuilder(line.rest)
            } else if (entries.isNotEmpty()) {
                entries.last().second.append('\n').append(l)
            }
        }
        if (entries.isEmpty()) return emptyList()
        // 2) Jour/mois ou mois/jour : décidé sur tout le fichier
        val dayFirst = when {
            entries.any { it.first.a > 12 } -> true
            entries.any { it.first.b > 12 } -> false
            entries.any { it.first.ampm.isNotEmpty() } -> false
            else -> true
        }
        val cal = Calendar.getInstance(zone)
        val out = mutableListOf<Raw>()
        for ((ln, body) in entries) {
            val all = body.toString()
            val sep = all.indexOf(": ")
            // Sans « Nom: » : message du système (chiffrement, ajout au groupe…) — ignoré
            if (sep <= 0 || sep > 80 || all.substring(0, sep).contains('\n')) continue
            val from = all.substring(0, sep).trim()
            var msg = all.substring(sep + 2).trimEnd()
            val day = if (dayFirst) ln.a else ln.b
            val month = if (dayFirst) ln.b else ln.a
            val year = if (ln.y < 100) 2000 + ln.y else ln.y
            var hour = ln.h
            val pm = ln.ampm.lowercase().startsWith("p")
            if (ln.ampm.isNotEmpty()) { if (pm && hour < 12) hour += 12; if (!pm && hour == 12) hour = 0 }
            if (month !in 1..12 || day !in 1..31 || hour > 23) continue
            cal.clear(); cal.set(year, month - 1, day, hour, ln.mi, ln.s)
            var media = ""
            val att = WA_ATTACHED.find(msg) ?: WA_ATTACHED_IOS.find(msg)
            if (att != null) {
                media = att.groupValues[1].trim()
                val caption = att.groupValues[2].trim()
                msg = label(media) + if (caption.isNotEmpty()) "\n$caption" else ""
            } else if (WA_OMITTED.matches(msg.trim())) {
                msg = "📎 Média non exporté"
            }
            out += Raw(cal.timeInMillis, from, msg, media)
        }
        return out
    }

    /** Libellé d'un fichier joint, comme les notifications (le type est reconnu par l'emoji). */
    fun label(fileName: String): String = when (fileName.substringAfterLast('.', "").lowercase()) {
        "jpg", "jpeg", "png", "webp", "heic", "gif" -> if (fileName.contains("STK-", true) || fileName.contains("sticker", true)) "🖼 Sticker" else "📷 Photo"
        "mp4", "3gp", "mov", "mkv", "webm" -> "🎥 Vidéo"
        "opus", "ogg", "oga", "m4a", "mp3", "aac", "amr", "wav" -> "🎤 Message vocal"
        "vcf" -> "👤 Contact"
        else -> "📄 $fileName"
    }

    // ------------------------------------------------------------------ Telegram (JSON)

    /** Texte d'un message Telegram : chaîne simple, ou liste de morceaux (liens, gras…). */
    private fun tgText(v: Any?): String = when (v) {
        null -> ""
        is String -> v
        is JSONArray -> (0 until v.length()).joinToString("") { i ->
            when (val p = v.opt(i)) {
                is String -> p
                is JSONObject -> p.optString("text")
                else -> ""
            }
        }
        else -> v.toString()
    }

    /**
     * Export Telegram Desktop en JSON : une discussion (« name », « messages ») ou un export complet
     * (« chats » → « list »). Renvoie toutes les discussions trouvées.
     */
    fun parseTelegramJson(json: String): List<Chat> {
        val root = JSONObject(json)
        val chats = mutableListOf<JSONObject>()
        if (root.has("messages")) chats += root
        root.optJSONObject("chats")?.optJSONArray("list")?.let { l -> for (i in 0 until l.length()) l.optJSONObject(i)?.let { chats += it } }
        root.optJSONObject("left_chats")?.optJSONArray("list")?.let { l -> for (i in 0 until l.length()) l.optJSONObject(i)?.let { chats += it } }
        return chats.mapNotNull { c ->
            val arr = c.optJSONArray("messages") ?: return@mapNotNull null
            val out = mutableListOf<Raw>()
            for (i in 0 until arr.length()) {
                val m = arr.optJSONObject(i) ?: continue
                if (m.optString("type", "message") != "message") continue
                val unix = m.optString("date_unixtime").toLongOrNull()
                val time = if (unix != null) unix * 1000 else parseIsoLocal(m.optString("date")) ?: continue
                val from = m.optString("from").takeIf { it.isNotBlank() && it != "null" } ?: m.optString("actor")
                var text = tgText(m.opt("text"))
                val file = m.optString("photo").takeIf { it.isNotBlank() && !it.startsWith("(") } ?: m.optString("file").takeIf { it.isNotBlank() && !it.startsWith("(") } ?: ""
                if (file.isNotEmpty() || m.has("photo") || m.has("file")) {
                    val kind = when (m.optString("media_type")) {
                        "voice_message", "audio_file" -> "🎤 Message vocal"
                        "video_file", "video_message", "animation" -> "🎥 Vidéo"
                        "sticker" -> "🖼 Sticker"
                        else -> if (m.has("photo")) "📷 Photo" else "📄 " + (m.optString("file_name").ifBlank { file.substringAfterLast('/') })
                    }
                    text = kind + if (text.isNotBlank()) "\n$text" else ""
                }
                if (text.isBlank()) continue
                out += Raw(time, from, text, file)
            }
            Chat(Conv.TELEGRAM, c.optString("name").takeIf { it != "null" } ?: "", out.sortedBy { it.time })
        }.filter { it.messages.isNotEmpty() }
    }

    private fun parseIsoLocal(s: String): Long? {
        val m = Regex("^(\\d{4})-(\\d{2})-(\\d{2})T(\\d{2}):(\\d{2}):(\\d{2})").find(s) ?: return null
        val g = m.groupValues.drop(1).map { it.toInt() }
        return Calendar.getInstance().apply { clear(); set(g[0], g[1] - 1, g[2], g[3], g[4], g[5]) }.timeInMillis
    }

    // ------------------------------------------------------------------ Telegram (HTML)

    private fun unescape(s: String) = s
        .replace(Regex("(?i)<br\\s*/?>"), "\n").replace(Regex("<[^>]+>"), "")
        .replace("&lt;", "<").replace("&gt;", ">").replace("&quot;", "\"").replace("&#39;", "'").replace("&apos;", "'").replace("&nbsp;", " ")
        .replace(Regex("&#(\\d+);")) { m -> m.groupValues[1].toIntOrNull()?.let { String(Character.toChars(it)) } ?: "" }
        .replace("&amp;", "&")
        .trim()

    private val TG_DATE = Regex("title=\"(\\d{2})\\.(\\d{2})\\.(\\d{4}) (\\d{2}):(\\d{2}):(\\d{2})(?: UTC([+-])(\\d{2}):(\\d{2}))?\"")

    /** Export Telegram Desktop en HTML (messages.html, messages2.html…). */
    fun parseTelegramHtml(html: String): Chat {
        val title = Regex("(?s)<div class=\"text bold\">\\s*(.*?)\\s*</div>").find(html)?.groupValues?.get(1)?.let { unescape(it) } ?: ""
        val out = mutableListOf<Raw>()
        var lastFrom = ""
        val blocks = html.split("<div class=\"message ").drop(1)
        for (b in blocks) {
            if (b.startsWith("service")) continue
            val d = TG_DATE.find(b) ?: continue
            val g = d.groupValues
            val time = if (g[7].isNotEmpty()) {
                val c = Calendar.getInstance(TimeZone.getTimeZone("UTC")).apply { clear(); set(g[3].toInt(), g[2].toInt() - 1, g[1].toInt(), g[4].toInt(), g[5].toInt(), g[6].toInt()) }
                val off = (g[8].toInt() * 60 + g[9].toInt()) * 60_000L * (if (g[7] == "+") 1 else -1)
                c.timeInMillis - off
            } else Calendar.getInstance().apply { clear(); set(g[3].toInt(), g[2].toInt() - 1, g[1].toInt(), g[4].toInt(), g[5].toInt(), g[6].toInt()) }.timeInMillis
            // Messages groupés (« joined ») : même expéditeur que le précédent
            val from = Regex("(?s)<div class=\"from_name\">\\s*(.*?)\\s*</div>").find(b)?.groupValues?.get(1)?.let { unescape(it.substringBefore("<span")) } ?: lastFrom
            lastFrom = from
            var text = Regex("(?s)<div class=\"text\">\\s*(.*?)\\s*</div>").find(b)?.groupValues?.get(1)?.let { unescape(it) } ?: ""
            val href = Regex("<a class=\"(photo_wrap|video_file_wrap|media_wrap[^\"]*|animated_wrap)[^\"]*\" href=\"([^\"]+)\"").find(b)
            var media = ""
            if (href != null) {
                media = href.groupValues[2]
                val kind = when {
                    href.groupValues[1].startsWith("photo") -> "📷 Photo"
                    href.groupValues[1].startsWith("video") || href.groupValues[1].startsWith("animated") -> "🎥 Vidéo"
                    b.contains("media_voice_message") || b.contains("media_audio_file") -> "🎤 Message vocal"
                    else -> label(media.substringAfterLast('/'))
                }
                text = kind + if (text.isNotBlank()) "\n$text" else ""
            }
            if (text.isBlank()) continue
            out += Raw(time, from, text, media)
        }
        return Chat(Conv.TELEGRAM, title, out.sortedBy { it.time })
    }

    // ------------------------------------------------------------------ Fusion avec les messages déjà là

    /** Textes comparables : espaces, majuscules et ponctuation finale ignorés. */
    fun sameText(a: String, b: String): Boolean {
        fun n(s: String) = s.lowercase().replace(Regex("\\s+"), " ").trim().trimEnd('.', '!', '?', ' ')
        return n(a) == n(b)
    }

    /** Message de photo, vocal… (reconnu par son emoji ou son libellé). */
    fun isMedia(text: String) = MessageHub.kindOf(text) != null || text.startsWith("📎")
}
