package fr.jeremy.calepin.market

import okhttp3.HttpUrl.Companion.toHttpUrl

/**
 * Actualités d'un instrument, cherchées sur internet : Yahoo Finance (articles liés au symbole) et
 * Google Actualités (en français et en anglais). Gardées 10 minutes.
 */
object News {
    private val cache = HashMap<String, Pair<NewsTone, Long>>()

    fun forInstrument(symbol: String, name: String, force: Boolean = false): NewsTone {
        val key = symbol.uppercase()
        if (!force) synchronized(cache) { cache[key]?.let { (t, at) -> if (System.currentTimeMillis() - at < 600_000L) return t } }
        val q = NewsText.queryName(name, symbol)
        val all = ArrayList<NewsItem>()
        // 1. Yahoo Finance : articles rattachés au symbole
        runCatching {
            val url = "https://query1.finance.yahoo.com/v1/finance/search".toHttpUrl().newBuilder()
                .addQueryParameter("q", symbol).addQueryParameter("quotesCount", "0").addQueryParameter("newsCount", "20")
                .build().toString()
            val arr = MarketData.fetchJson(url).optJSONArray("news")
            if (arr != null) for (i in 0 until arr.length()) {
                val o = arr.optJSONObject(i) ?: continue
                val title = o.optString("title").ifBlank { null } ?: continue
                all += NewsItem(title, o.optString("publisher", "Yahoo Finance"), o.optString("link"), o.optLong("providerPublishTime") * 1000L, NewsText.scoreTitle(title))
            }
        }
        // 2. Google Actualités, en français puis en anglais
        fun google(query: String, hl: String, gl: String, ceid: String) = runCatching {
            val url = "https://news.google.com/rss/search".toHttpUrl().newBuilder()
                .addQueryParameter("q", "$query when:7d")
                .addQueryParameter("hl", hl).addQueryParameter("gl", gl).addQueryParameter("ceid", ceid)
                .build().toString()
            all += NewsText.parseRss(MarketData.fetchText(url, "application/rss+xml"), "Google Actualités").take(25)
        }
        // 2 bis. Flux RSS de Yahoo Finance pour le symbole
        runCatching {
            val url = "https://feeds.finance.yahoo.com/rss/2.0/headline".toHttpUrl().newBuilder()
                .addQueryParameter("s", symbol).addQueryParameter("region", "US").addQueryParameter("lang", "en-US").build().toString()
            all += NewsText.parseRss(MarketData.fetchText(url, "application/rss+xml"), "Yahoo Finance").take(20)
        }
        // 2 ter. Bing Actualités (autres journaux et agences)
        runCatching {
            val url = "https://www.bing.com/news/search".toHttpUrl().newBuilder()
                .addQueryParameter("q", q).addQueryParameter("format", "rss").addQueryParameter("setlang", "fr").build().toString()
            all += NewsText.parseRss(MarketData.fetchText(url, "application/rss+xml"), "Bing Actualités").take(20)
        }
        google("\"$q\" bourse OR cours OR action", "fr", "FR", "FR:fr")
        google("\"$q\" stock OR shares OR price", "en-US", "US", "US:en")
        val weekAgo = System.currentTimeMillis() - 7 * 86_400_000L
        val items = NewsText.dedupe(all.filter { it.time == 0L || it.time >= weekAgo }).take(40)
        val tone = NewsText.tone(items)
        synchronized(cache) { cache[key] = tone to System.currentTimeMillis() }
        return tone
    }

    fun factor(t: NewsTone): Factor? = NewsText.factor(t)
}
