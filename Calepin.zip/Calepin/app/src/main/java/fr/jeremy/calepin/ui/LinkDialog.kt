package fr.jeremy.calepin.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Notes
import androidx.compose.material.icons.filled.Language
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import fr.jeremy.calepin.i18n.RawText
import fr.jeremy.calepin.i18n.Text
import fr.jeremy.calepin.i18n.tr

/**
 * « Créer un lien » : vers un site (ou une adresse mail, un numéro), ou vers une autre note.
 * Le texte sélectionné devient le texte du lien ; seul ce texte se voit dans la note.
 */
@Composable
fun LinkDialog(
    initialLabel: String,
    noteTitles: List<String>,
    onWeb: (label: String, url: String) -> Unit,
    onNote: (title: String) -> Unit,
    onDismiss: () -> Unit,
) {
    // Sélection qui ressemble déjà à une adresse : on la propose comme adresse
    val looksLikeUrl = remember(initialLabel) { ' ' !in initialLabel.trim() && Markdown.normalizeUrl(initialLabel) != null }
    var toNote by remember { mutableStateOf(false) }
    var label by remember { mutableStateOf(initialLabel) }
    var address by remember { mutableStateOf(if (looksLikeUrl) initialLabel.trim() else "") }
    var noteTitle by remember { mutableStateOf(initialLabel) }
    val url = Markdown.normalizeUrl(address)
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Créer un lien") },
        text = {
            Column {
                Row {
                    FilterChip(
                        selected = !toNote, onClick = { toNote = false },
                        label = { Text("Site web") },
                        leadingIcon = { Icon(Icons.Filled.Language, null) },
                        modifier = Modifier.padding(end = 8.dp),
                    )
                    FilterChip(
                        selected = toNote, onClick = { toNote = true },
                        label = { Text("Autre note") },
                        leadingIcon = { Icon(Icons.AutoMirrored.Filled.Notes, null) },
                    )
                }
                if (!toNote) {
                    OutlinedTextField(
                        value = address, onValueChange = { address = it },
                        label = { Text("Adresse (site, e-mail ou numéro)") },
                        placeholder = { RawText("www.exemple.fr") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri),
                        isError = address.isNotBlank() && url == null,
                        modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
                    )
                    OutlinedTextField(
                        value = label, onValueChange = { label = it },
                        label = { Text("Texte affiché") },
                        placeholder = { RawText(address.ifBlank { tr("Texte du lien") }) },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
                    )
                } else {
                    OutlinedTextField(
                        value = noteTitle, onValueChange = { noteTitle = it },
                        label = { Text("Titre de la note") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
                    )
                    val q = noteTitle.trim()
                    val found = remember(q, noteTitles) {
                        noteTitles.filter { q.isEmpty() || it.contains(q, ignoreCase = true) }.take(30)
                    }
                    if (found.isNotEmpty()) {
                        LazyColumn(Modifier.heightIn(max = 220.dp).padding(top = 6.dp)) {
                            items(found) { t ->
                                RawText(
                                    t,
                                    style = MaterialTheme.typography.bodyLarge,
                                    color = if (t.equals(q, ignoreCase = true)) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface,
                                    modifier = Modifier.fillMaxWidth().clickable { noteTitle = t }.padding(vertical = 10.dp, horizontal = 4.dp),
                                )
                            }
                        }
                    } else if (q.isNotEmpty()) {
                        Text(
                            "Aucune note à ce titre : elle sera créée en touchant le lien.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(top = 6.dp),
                        )
                    }
                }
            }
        },
        confirmButton = {
            TextButton(
                enabled = if (toNote) noteTitle.isNotBlank() else url != null,
                onClick = {
                    if (toNote) onNote(noteTitle.trim())
                    else url?.let { onWeb(label.trim().ifEmpty { address.trim() }, it) }
                },
            ) { Text("Créer le lien") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Annuler") } },
    )
}
