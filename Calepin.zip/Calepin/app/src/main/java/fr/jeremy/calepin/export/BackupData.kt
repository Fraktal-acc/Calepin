package fr.jeremy.calepin.export

import fr.jeremy.calepin.data.NoteDb

/** Contenu de la sauvegarde complète (notes, dossiers, agenda, pièces jointes, mémos), sans écran. */
object BackupData {
    fun export(db: NoteDb): org.json.JSONObject {
        val o = org.json.JSONObject()
        o.put("notes", org.json.JSONArray().apply {
            db.all().forEach { n ->
                put(org.json.JSONObject().put("id", n.id).put("title", n.title).put("content", n.content).put("tag", n.tag)
                    .put("pinned", n.pinned).put("folder", n.folder).put("createdAt", n.createdAt).put("updatedAt", n.updatedAt))
            }
        })
        o.put("folders", org.json.JSONArray(db.folders()))
        o.put("attachments", org.json.JSONArray().apply {
            db.attachments().forEach { a -> put(org.json.JSONObject().put("noteId", a.noteId).put("file", a.fileName).put("video", a.isVideo).put("createdAt", a.createdAt)) }
        })
        o.put("recordings", org.json.JSONArray().apply {
            db.recordings().forEach { r ->
                put(org.json.JSONObject().put("noteId", r.noteId).put("file", r.fileName).put("format", r.format)
                    .put("duration", r.durationMs).put("createdAt", r.createdAt).put("transcript", r.transcript))
            }
        })
        o.put("events", org.json.JSONArray().apply {
            db.events().forEach { e ->
                put(org.json.JSONObject().put("noteId", e.noteId).put("title", e.title).put("start", e.start).put("allDay", e.allDay)
                    .put("remind", e.remindMinutes).put("alarm", e.alarm).put("ringtone", e.ringtone).put("createdAt", e.createdAt)
                    .put("end", e.end).put("category", e.category).put("repeat", e.repeat))
            }
        })
        return o
    }
}
