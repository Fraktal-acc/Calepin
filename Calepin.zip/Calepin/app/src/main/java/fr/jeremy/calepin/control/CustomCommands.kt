package fr.jeremy.calepin.control

import android.content.Context
import fr.jeremy.calepin.search.TextNorm
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

/**
 * Commande personnelle (Paramètres → Mes commandes) : des phrases déclencheuses, une ou plusieurs
 * actions (des commandes que Calepin comprend déjà) et une réponse facultative.
 * Les parties variables s'écrivent entre accolades : « courses {quoi} » → « ajoute {quoi} à la liste courses ».
 */
data class CustomCommand(
    val id: String = UUID.randomUUID().toString(),
    val triggers: List<String>,
    val actions: List<String>,
    val reply: String = "",
    val enabled: Boolean = true,
) {
    /** Nom affiché : la première phrase. */
    val title: String get() = triggers.firstOrNull().orEmpty()

    fun toJson(): JSONObject = JSONObject().put("id", id).put("t", JSONArray(triggers)).put("a", JSONArray(actions)).put("r", reply).put("on", enabled)

    companion object {
        private fun list(a: JSONArray?) = a?.let { (0 until it.length()).map { i -> it.optString(i) } }.orEmpty().map { it.trim() }.filter { it.isNotEmpty() }
        fun fromJson(o: JSONObject) = CustomCommand(
            id = o.optString("id").ifBlank { UUID.randomUUID().toString() },
            triggers = list(o.optJSONArray("t")),
            actions = list(o.optJSONArray("a")),
            reply = o.optString("r"),
            enabled = o.optBoolean("on", true),
        )
    }
}

/** Reconnaissance des phrases et apprentissage à la voix. Sans Android : testable sur ordinateur. */
object CommandRules {

    /** Une commande reconnue : la commande, la phrase qui a servi, les valeurs des parties variables. */
    data class Match(val command: CustomCommand, val trigger: String, val values: Map<String, String>)

    private val VAR = Regex("\\{\\s*([\\p{L}\\p{N}_ -]{1,30}?)\\s*\\}")
    private val POLITE = Regex("^(?:(?:ok |dis |he |hey )?calepin[ ,]+|s'il te plait[ ,]+|stp[ ,]+|svp[ ,]+)+")
    private val POLITE_END = Regex("(?:[ ,]+(?:s'il te plait|s'il vous plait|stp|svp|merci))+$")

    /** Forme comparable : sans accents ni majuscules, ponctuation retirée, « s'il te plaît » et « Calepin, » ignorés. */
    fun norm(s: String): String {
        var t = TextNorm.norm(s).lowercase().replace('’', '\'').replace(Regex("[.!?;:,«»\"]+"), " ").replace(Regex("\\s+"), " ").trim()
        t = POLITE.replace(t, "").let { POLITE_END.replace(it, "") }.trim()
        return t
    }

    /** Noms des parties variables d'une phrase (« courses {quoi} » → [quoi]). */
    fun variables(trigger: String): List<String> = VAR.findAll(trigger).map { it.groupValues[1].trim().lowercase() }.toList()

    /** Expression qui reconnaît une phrase déclencheuse ; les variables prennent n'importe quel texte. */
    private fun regexFor(trigger: String): Regex {
        val sb = StringBuilder("^")
        var last = 0
        for (m in VAR.findAll(trigger)) {
            val lit = norm(trigger.substring(last, m.range.first))
            if (lit.isNotEmpty()) sb.append(Regex.escape(lit)).append("\\s*")
            sb.append("(.+?)\\s*")
            last = m.range.last + 1
        }
        val tail = norm(trigger.substring(last))
        if (tail.isNotEmpty()) sb.append(Regex.escape(tail))
        // « \\s* » avant la fin : une variable en dernière position garde tout le reste de la phrase
        return Regex(sb.toString().removeSuffix("\\s*") + "$")
    }

    /** Distance d'édition (fautes de frappe, mots mal entendus par la reconnaissance vocale). */
    fun distance(a: String, b: String): Int {
        val d = IntArray(b.length + 1) { it }
        for (i in 1..a.length) {
            var prev = d[0]; d[0] = i
            for (j in 1..b.length) {
                val tmp = d[j]
                d[j] = minOf(d[j] + 1, d[j - 1] + 1, prev + if (a[i - 1] == b[j - 1]) 0 else 1)
                prev = tmp
            }
        }
        return d[b.length]
    }

    /**
     * Commande personnelle correspondant à [text], ou null. Exacte d'abord (variables comprises),
     * puis approchée pour les phrases sans variable (au plus une faute tous les 6 caractères environ).
     * [original] : le texte d'origine, pour garder les accents des valeurs (« pain, œufs »).
     */
    fun match(commands: List<CustomCommand>, text: String): Match? {
        val n = norm(text)
        if (n.isEmpty()) return null
        val active = commands.filter { it.enabled && it.actions.isNotEmpty() || it.enabled && it.reply.isNotBlank() }
        // 1) Exacte (les phrases les plus longues d'abord : « bonne nuit les enfants » avant « bonne nuit »)
        val all = active.flatMap { c -> c.triggers.map { c to it } }.sortedByDescending { norm(it.second.replace(VAR, "")).length }
        for ((c, t) in all) {
            val m = regexFor(t).matchEntire(n) ?: continue
            val names = variables(t)
            val values = names.mapIndexed { i, name -> name to original(text, n, m.groups[i + 1]?.range, m.groupValues[i + 1]) }.toMap()
            if (values.values.any { it.isBlank() }) continue
            return Match(c, t, values)
        }
        // 2) Approchée (sans variable)
        var best: Triple<CustomCommand, String, Int>? = null
        for ((c, t) in all) {
            if (variables(t).isNotEmpty()) continue
            val nt = norm(t)
            if (nt.length < 4) continue
            val d = distance(n, nt)
            val allowed = maxOf(1, nt.length / 6)
            if (d <= allowed && (best == null || d < best.third)) best = Triple(c, t, d)
        }
        return best?.let { Match(it.first, it.second, emptyMap()) }
    }

    /** Valeur prise dans le texte d'origine quand c'est possible (accents, majuscules), sinon la forme comparable. */
    private fun original(raw: String, n: String, range: IntRange?, fallback: String): String {
        if (range == null) return fallback.trim()
        val r = raw.trim().replace(Regex("\\s+"), " ")
        // Même texte une fois retirés les accents et la ponctuation : on retrouve les mots d'origine
        val words = fallback.trim().split(' ').filter { it.isNotEmpty() }
        if (words.isEmpty()) return fallback.trim()
        val rawWords = r.split(' ')
        val normWords = rawWords.map { norm(it) }
        for (i in normWords.indices) {
            if (i + words.size > normWords.size) break
            if ((0 until words.size).all { k -> normWords[i + k] == words[k] }) {
                return rawWords.subList(i, i + words.size).joinToString(" ").trim().trimEnd('.', '!', '?', ',')
            }
        }
        return fallback.trim()
    }

    /** Remplace {quoi} dans une action par la valeur reconnue. */
    fun fill(action: String, values: Map<String, String>): String =
        VAR.replace(action) { m -> values[m.groupValues[1].trim().lowercase()] ?: m.value }

    // ------------------------------------------------------------------ Apprentissage à la voix

    /** Verbes qui commencent une nouvelle action (« … et ouvre mon planning »). */
    private val VERBS = "ouvre|ouvrir|mets|mettre|met|active|activer|desactive|desactiver|allume|allumer|eteins|eteindre|envoie|envoyer|appelle|appeler|" +
        "ajoute|ajouter|lance|lancer|lis|lire|note|noter|rappelle|rappelle-moi|reveille|reveille-moi|cree|creer|affiche|afficher|montre|montrer|coupe|couper|" +
        "remets|monte|baisse|cherche|chercher|supprime|supprimer|importe|importer|analyse|analyser|dis|dire|ecris|ecrire|joue|jouer|passe|passer|demarre|" +
        "arrete|arreter|pause|attends|emmene|emmene-moi|sms|whatsapp|telegram|theme|mode|quelle|quel|resume|donne"

    private const val LEARN_HEAD = "(?i)^(?:apprends(?:-moi)?(?:\\s+que)?\\s*:?\\s*|retiens(?:\\s+que)?\\s*:?\\s*|nouvelle commande\\s*:?\\s*)?" +
        "(?:quand|lorsque|si|chaque fois que)\\s+je\\s+(?:te\\s+)?(?:dis|dirai|tape|taperai|[ée]cris|[ée]crirai)\\s+"
    private val LEARN_QUOTED = Regex(LEARN_HEAD + "[«\"“]\\s*(.+?)\\s*[»\"”]\\s*,?\\s*(?:alors\\s+)?(?:tu\\s+(?:dois\\s+)?)?(?:fais\\s+|il faut\\s+)?(.+)$")
    private val LEARN_PLAIN = Regex(LEARN_HEAD + "(.+?)\\s*(?:,|:|\\s+alors\\s+|\\s+tu dois\\s+|\\s+tu\\s+|\\s+il faut\\s+|\\s+fais\\s+)\\s*(.+)$")

    /** « quand je dis X, fais Y puis Z » → (X, [Y, Z]) ; null si la phrase n'apprend rien. */
    fun parseLearn(text: String): Pair<String, List<String>>? {
        val t = text.trim().trimEnd('.', '!')
        val m = LEARN_QUOTED.find(t) ?: LEARN_PLAIN.find(t) ?: return null
        val trigger = m.groupValues[1].trim().trim('«', '»', '"', ' ')
        val actions = splitActions(m.groupValues[2].trim().removePrefix("alors ").trim()).map { imperative(it) }
        if (trigger.isEmpty() || actions.isEmpty()) return null
        return trigger to actions
    }

    /** « tu allumes la télé » → « allume la télé » (forme comprise par l'assistant). */
    fun imperative(action: String): String {
        val a = action.replace(Regex("(?i)^tu\\s+"), "")
        val first = a.substringBefore(' ')
        return if (first.length >= 4 && first.endsWith("es") && first.none { it.isUpperCase() }) first.dropLast(1) + a.substring(first.length) else a
    }

    /** Découpe « mode silencieux et ouvre mon planning puis envoie… » en actions. */
    fun splitActions(text: String): List<String> {
        val chunks = text.split(Regex("(?i)\\s*(?:;|\\bpuis\\b|\\bet ensuite\\b|\\bensuite\\b|\\bapr[eè]s [cç]a\\b)\\s*"))
        val out = mutableListOf<String>()
        val andVerb = Regex("\\s+et\\s+(?:tu\\s+)?(?=(?:$VERBS)s?\\b)")
        for (p in chunks) {
            // « et » ne coupe que devant un verbe d'action (« envoie à Julie : toi et moi » reste entier)
            var rest = p
            while (true) {
                val n = TextNorm.norm(rest).lowercase()
                if (n.length != rest.length) break
                val m = andVerb.find(n) ?: break
                if (m.range.first <= 0) break
                out += rest.substring(0, m.range.first)
                rest = rest.substring(m.range.last + 1)
            }
            out += rest
        }
        return out.map { it.trim().trim(',', '.').trim() }.filter { it.isNotEmpty() }
    }

    /** « oublie la commande boulot », « supprime ma commande boulot » → « boulot ». */
    fun parseForget(text: String): String? =
        Regex("^(?:oublie|supprime|efface|retire)\\s+(?:la |ma |cette )?commande\\s+(?:personnelle\\s+)?(.+)$").find(norm(text))?.groupValues?.get(1)?.trim()

    /** « quelles sont mes commandes », « liste mes commandes », « mes commandes ». */
    fun isList(text: String): Boolean =
        Regex("^(?:quelles sont |liste |montre |affiche |dis moi |donne moi )?(?:la liste de )?mes commandes(?: personnelles)?$").matches(norm(text))
}

/** Les commandes personnelles, gardées sur le téléphone. */
object CustomCommands {
    private const val PREFS = "calepin_custom_commands"
    private val _list = MutableStateFlow<List<CustomCommand>>(emptyList())
    val list: StateFlow<List<CustomCommand>> = _list
    @Volatile private var loaded = false

    fun init(ctx: Context) {
        if (loaded) return
        synchronized(this) {
            if (loaded) return
            val p = ctx.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            _list.value = runCatching {
                val a = JSONArray(p.getString("list", "[]"))
                (0 until a.length()).map { CustomCommand.fromJson(a.getJSONObject(it)) }
            }.getOrDefault(emptyList())
            // Une seule fois : les scénarios créés par l'utilisateur deviennent aussi des commandes (« lance soirée film »)
            if (!p.getBoolean("scenarios_imported", false)) {
                val saved = ctx.applicationContext.getSharedPreferences("calepin_scenarios", Context.MODE_PRIVATE).getString("list", null)
                if (saved != null) {
                    val sc = runCatching { Scenarios.all(ctx) }.getOrDefault(emptyList()).filter { s -> s.name.isNotBlank() && s.steps.isNotEmpty() }
                    val fresh = sc.filter { s -> _list.value.none { c -> c.triggers.any { CommandRules.norm(it) == CommandRules.norm(s.name) } } }.map { s ->
                        CustomCommand(triggers = listOf(s.name, "lance " + s.name.lowercase()), actions = s.steps)
                    }
                    if (fresh.isNotEmpty()) _list.value = _list.value + fresh
                }
                p.edit().putBoolean("scenarios_imported", true).apply()
                save(ctx)
            }
            loaded = true
        }
    }

    private fun save(ctx: Context) {
        val a = JSONArray().apply { _list.value.forEach { put(it.toJson()) } }
        ctx.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString("list", a.toString()).apply()
    }

    fun upsert(ctx: Context, c: CustomCommand) {
        init(ctx)
        val l = _list.value.toMutableList()
        val i = l.indexOfFirst { it.id == c.id }
        if (i >= 0) l[i] = c else l += c
        _list.value = l
        save(ctx)
    }

    fun delete(ctx: Context, id: String) {
        init(ctx)
        _list.value = _list.value.filter { it.id != id }
        save(ctx)
    }

    fun match(ctx: Context, text: String): CommandRules.Match? {
        init(ctx)
        return CommandRules.match(_list.value, text)
    }

    /** Commande dont une phrase est [trigger] (pour l'apprentissage : « quand je dis boulot » remplace l'ancienne « boulot »). */
    fun byTrigger(ctx: Context, trigger: String): CustomCommand? {
        init(ctx)
        val t = CommandRules.norm(trigger)
        return _list.value.firstOrNull { c -> c.triggers.any { CommandRules.norm(it) == t } }
    }

    /** Liste pour l'IA : « phrase → actions », une par ligne (les plus courtes pour ne pas allonger la consigne). */
    fun forAi(ctx: Context): String {
        init(ctx)
        return _list.value.filter { it.enabled }.take(40).joinToString("\n") { c ->
            "- " + c.triggers.take(3).joinToString(" | ") { "« $it »" } + " → " + c.actions.take(4).joinToString(" ; ").take(160)
        }
    }
}
