package fr.jeremy.calepin.contacts

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.provider.ContactsContract
import android.provider.ContactsContract.CommonDataKinds.Email
import android.provider.ContactsContract.CommonDataKinds.Organization
import android.provider.ContactsContract.CommonDataKinds.Phone
import android.provider.ContactsContract.CommonDataKinds.StructuredName
import android.provider.ContactsContract.CommonDataKinds.StructuredPostal
import androidx.core.content.ContextCompat
import fr.jeremy.calepin.search.TextNorm

/** Une valeur et son étiquette (« Mobile », « Domicile »…). */
data class Labeled(val value: String, val label: String)

/** Un contact du téléphone, avec ses numéros, e-mails et adresses. */
data class PhoneContact(
    val id: Long,
    val lookupKey: String?,
    val name: String,
    val starred: Boolean,
    val photo: String?,
    val organization: String?,
    val phones: List<Labeled>,
    val emails: List<Labeled>,
    val addresses: List<Labeled>,
) {
    /** Texte normalisé pour la recherche (nom, société, e-mails, adresses). */
    val searchText: String by lazy {
        TextNorm.norm(listOfNotNull(name, organization).plus(emails.map { it.value }).plus(addresses.map { it.value }).joinToString(" "))
    }
    val phoneDigits: List<String> by lazy { phones.map { p -> p.value.filter { it.isDigit() } } }

    val initial: String
        get() = name.trim().firstOrNull { it.isLetterOrDigit() }?.uppercase() ?: "#"
}

/** Lecture des contacts du téléphone (lecture seule : ajout et modification passent par l'appli Contacts). */
object PhoneContacts {

    fun hasPermission(ctx: Context): Boolean =
        ContextCompat.checkSelfPermission(ctx, Manifest.permission.READ_CONTACTS) == PackageManager.PERMISSION_GRANTED

    private class Builder(val id: Long, val lookup: String?, val name: String, val starred: Boolean, val photo: String?) {
        var organization: String? = null
        val phones = mutableListOf<Labeled>()
        val emails = mutableListOf<Labeled>()
        val addresses = mutableListOf<Labeled>()
    }

    fun load(ctx: Context): List<PhoneContact> {
        if (!hasPermission(ctx)) return emptyList()
        val res = ctx.resources
        val mimes = arrayOf(
            Phone.CONTENT_ITEM_TYPE,
            Email.CONTENT_ITEM_TYPE,
            StructuredPostal.CONTENT_ITEM_TYPE,
            Organization.CONTENT_ITEM_TYPE,
            StructuredName.CONTENT_ITEM_TYPE,
        )
        // Noms de colonnes publics et stables de ContactsContract.Data
        val projection = arrayOf(
            "contact_id", "lookup", "display_name", "starred", "photo_thumb_uri",
            "mimetype", "data1", "data2", "data3",
        )
        val selection = "mimetype IN (" + mimes.joinToString(",") { "?" } + ")"
        val byId = LinkedHashMap<Long, Builder>()
        ctx.contentResolver.query(ContactsContract.Data.CONTENT_URI, projection, selection, mimes, null)?.use { c ->
            while (c.moveToNext()) {
                val id = c.getLong(0)
                val name = c.getString(2)?.trim().orEmpty()
                val b = byId.getOrPut(id) {
                    Builder(id, c.getString(1), name, c.getInt(3) == 1, c.getString(4))
                }
                val data = c.getString(6)?.trim().orEmpty()
                if (data.isEmpty()) continue
                val type = if (c.isNull(7)) 0 else c.getInt(7)
                val custom = c.getString(8)
                when (c.getString(5)) {
                    Phone.CONTENT_ITEM_TYPE -> {
                        val digits = data.filter { it.isDigit() }
                        if (b.phones.none { it.value.filter { ch -> ch.isDigit() } == digits }) {
                            b.phones += Labeled(data, Phone.getTypeLabel(res, type, custom).toString())
                        }
                    }
                    Email.CONTENT_ITEM_TYPE ->
                        if (b.emails.none { it.value.equals(data, ignoreCase = true) }) {
                            b.emails += Labeled(data, Email.getTypeLabel(res, type, custom).toString())
                        }
                    StructuredPostal.CONTENT_ITEM_TYPE ->
                        b.addresses += Labeled(data.replace('\n', ' ').replace(Regex(" {2,}"), " "), StructuredPostal.getTypeLabel(res, type, custom).toString())
                    Organization.CONTENT_ITEM_TYPE -> if (b.organization == null) b.organization = data
                }
            }
        }
        return byId.values
            .filter { it.name.isNotEmpty() || it.phones.isNotEmpty() || it.emails.isNotEmpty() }
            .map {
                PhoneContact(
                    id = it.id,
                    lookupKey = it.lookup,
                    name = it.name.ifEmpty { it.phones.firstOrNull()?.value ?: it.emails.first().value },
                    starred = it.starred,
                    photo = it.photo,
                    organization = it.organization,
                    phones = it.phones,
                    emails = it.emails,
                    addresses = it.addresses,
                )
            }
            .sortedBy { TextNorm.norm(it.name) }
    }

    /** Filtre par nom, société, e-mail, adresse ou numéro (avec ou sans espaces, 06… ou +33 6…). */
    fun filter(all: List<PhoneContact>, query: String): List<PhoneContact> {
        val q = query.trim()
        if (q.isEmpty()) return all
        val words = TextNorm.norm(q).split(' ').filter { it.isNotBlank() }
        val qDigits = q.filter { it.isDigit() }
        val numeric = qDigits.length >= 3 && q.count { it.isLetter() } == 0
        return all.filter { c ->
            if (numeric) {
                val national = qDigits.trimStart('0')
                c.phoneDigits.any { it.contains(qDigits) || (national.length >= 3 && it.contains(national)) }
            } else {
                words.all { c.searchText.contains(it) }
            }
        }
    }
}
