package fr.jeremy.calepin.detect

import java.util.Calendar
import kotlin.math.abs

/** Un caractère d'un PDF avec sa position (points, origine en haut à gauche). */
data class Glyph(val text: String, val x: Float, val y: Float, val w: Float, val size: Float, val page: Int = 0)

/**
 * Plannings « en grille » (logiciels de sociétés de sécurité, d'intérim…) :
 *  - une rangée d'en-tête avec les numéros des jours (01 02 03 … 31), une colonne par jour ;
 *  - une ligne par site, avec dans chaque colonne un code de vacation (J01, N02…) et/ou ses horaires ;
 *  - une légende : « J01 : MATIN de 06:00 à 13:30 », regroupée sous « Site : … ».
 * Le texte seul ne suffit pas (les colonnes se collent : « 09:0009:00 ») : on lit la position de chaque caractère.
 */
object GridPlanningParser {

    private class Row(val page: Int, val y: Float, val text: String, val xs: FloatArray, val size: Float) {
        /** Centre horizontal des caractères [start, end[. */
        fun centerX(start: Int, end: Int): Float = (xs[start] + xs[end - 1]) / 2f
    }

    private data class Code(val h1: Int, val m1: Int, val h2: Int, val m2: Int, val desc: String, val site: String)

    private const val MONTHS = "janvier|février|fevrier|mars|avril|mai|juin|juillet|août|aout|septembre|octobre|novembre|décembre|decembre"
    private fun monthIndex(w: String): Int {
        val s = w.lowercase()
        return when {
            s.startsWith("janv") -> 0; s.startsWith("f") -> 1; s.startsWith("mars") -> 2; s.startsWith("avr") -> 3
            s.startsWith("mai") -> 4; s.startsWith("juin") -> 5; s.startsWith("juil") -> 6; s.startsWith("ao") -> 7
            s.startsWith("sept") -> 8; s.startsWith("oct") -> 9; s.startsWith("nov") -> 10; else -> 11
        }
    }

    private val rxLegend = Regex(
        """^\s*([A-Z#][A-Z0-9]{1,4})\s*:\s*(.*?)\s*(?:de\s+)?(\d{1,2})\s*[:hH]\s*(\d{2})\s*(?:à|a|-|–)\s*(\d{1,2})\s*[:hH]\s*(\d{2})"""
    )
    private val rxSite = Regex("""(?i)^\s*Site\s*:\s*(.+)$""")
    private val rxTime = Regex("""([01]\d|2[0-4])[:hH]([0-5]\d)""")
    private val rxDayNum = Regex("""(?<!\d)(0[1-9]|[12]\d|3[01])(?!\d)""")

    fun parse(glyphs: List<Glyph>, now: Long = System.currentTimeMillis()): List<Shift> {
        if (glyphs.isEmpty()) return emptyList()
        val out = mutableListOf<Shift>()
        for ((page, pg) in glyphs.groupBy { it.page }) out += parsePage(page, rows(pg), now)
        return out.distinctBy { Triple(it.start, it.end, it.label) }.sortedBy { it.start }
    }

    /** Regroupe les caractères en lignes (même hauteur) et insère des espaces dans les vrais blancs. */
    private fun rows(glyphs: List<Glyph>): List<Row> {
        // Certains PDF écrivent deux fois chaque lettre pour simuler le gras : on retire ces doublons
        val sorted = glyphs.filter { it.text.isNotEmpty() }.sortedWith(compareBy({ it.y }, { it.x }))
            .fold(mutableListOf<Glyph>()) { acc, g ->
                val p = acc.lastOrNull()
                if (p != null && p.text == g.text && abs(p.x - g.x) < 0.8f && abs(p.y - g.y) < 0.8f) acc else acc.apply { add(g) }
            }
        val groups = mutableListOf<MutableList<Glyph>>()
        for (g in sorted) {
            val last = groups.lastOrNull()
            if (last != null && abs(last.first().y - g.y) <= maxOf(1.5f, g.size * 0.25f)) last += g else groups += mutableListOf(g)
        }
        return groups.mapNotNull { gs ->
            val line = gs.sortedBy { it.x }
            val sb = StringBuilder()
            val xs = ArrayList<Float>()
            var prevEnd = Float.NaN
            for (g in line) {
                if (g.text.isBlank()) {
                    // Espace écrite dans le PDF
                    if (sb.isNotEmpty() && sb.last() != ' ') { sb.append(' '); xs += g.x + g.w / 2 }
                    continue
                }
                if (!prevEnd.isNaN() && g.x - prevEnd > g.size * 0.25f && sb.isNotEmpty() && sb.last() != ' ') {
                    sb.append(' '); xs += (prevEnd + g.x) / 2
                }
                for ((i, ch) in g.text.withIndex()) { sb.append(ch); xs += g.x + g.w * (i + 0.5f) / g.text.length }
                prevEnd = g.x + g.w
            }
            if (sb.isEmpty()) return@mapNotNull null
            Row(line.first().page, line.map { it.y }.average().toFloat(), sb.toString(), xs.toFloatArray(), line.map { it.size }.average().toFloat())
        }.sortedBy { it.y }
    }

    /** Mois (et année si présente) en mot entier ; gère les lettres espacées « O c t o b r e ». */
    private fun findMonth(texts: List<String>): Pair<Int, Int?>? {
        val spaced = texts.joinToString(" | ").lowercase()
        Regex("""(?<![\p{L}])($MONTHS)(?![\p{L}])\s*(20\d\d)?""").find(spaced)?.let {
            return monthIndex(it.groupValues[1]) to it.groupValues[2].toIntOrNull()
        }
        val compact = texts.joinToString("|") { it.replace(" ", "") }.lowercase()
        Regex("""($MONTHS)(20\d\d)""").find(compact)?.let { return monthIndex(it.groupValues[1]) to it.groupValues[2].toInt() }
        Regex("""(?<![\p{L}])($MONTHS)(?![\p{L}])""").find(compact)?.let { return monthIndex(it.groupValues[1]) to null }
        return null
    }

    private fun parsePage(page: Int, rows: List<Row>, now: Long): List<Shift> {
        // 1) En-tête des jours : la ligne qui contient la plus longue suite de jours consécutifs
        var header: Row? = null
        var days: List<Pair<Int, Float>> = emptyList()
        for (r in rows) {
            val nums = rxDayNum.findAll(r.text).map { it.value.toInt() to r.centerX(it.range.first, it.range.last + 1) }.toList()
            val seq = longestRun(nums)
            if (seq.size >= 5 && seq.size > days.size) { header = r; days = seq }
        }
        val h = header ?: return emptyList()

        // 2) Mois et année : écrits près de l'en-tête (lettres parfois espacées : « O c t o b r e »)
        val nowCal = Calendar.getInstance().apply { timeInMillis = now }
        var month = nowCal.get(Calendar.MONTH)
        var year = nowCal.get(Calendar.YEAR)
        // (la ligne des numéros de jours est exclue : « …192021… » ressemblerait à une année)
        val nearRows = rows.filter { it !== h && it.y in (h.y - 30f)..(h.y + 12f) }.map { it.text }
        val aboveRows = rows.filter { it.y < h.y }.map { it.text }
        val found = findMonth(nearRows) ?: findMonth(aboveRows)
        if (found != null) {
            month = found.first
            year = found.second
                ?: Regex("""(?<!\d)20\d\d(?!\d)""").find(nearRows.joinToString("|") { it.replace(" ", "") })?.value?.toInt()
                ?: year
        } else {
            // Repli : première date complète après « cycle » / « du »
            val all = rows.joinToString("\n") { it.text }
            Regex("""(?i)(?:cycle[^\n]*?|du\s+)(\d{2})/(\d{2})/(\d{4})""").find(all)?.let {
                month = it.groupValues[2].toInt() - 1; year = it.groupValues[3].toInt()
            }
        }
        // Date de chaque colonne (gestion du passage au mois suivant : … 30 31 01 02)
        val columns = mutableListOf<Pair<Long, Float>>()
        var m = month; var y = year; var prevDay = 0
        for ((d, x) in days) {
            if (d < prevDay) { m++; if (m > 11) { m = 0; y++ } }
            prevDay = d
            dayMillis(y, m, d)?.let { columns += it to x }
        }
        if (columns.isEmpty()) return emptyList()
        val spacing = if (columns.size > 1) (columns.last().second - columns.first().second) / (columns.size - 1) else 15f

        fun columnAt(x: Float): Long? {
            val best = columns.minByOrNull { abs(it.second - x) } ?: return null
            return if (abs(best.second - x) <= spacing * 0.6f) best.first else null
        }

        // 3) Légende des codes, avec le site en cours
        val legend = mutableMapOf<String, Code>()
        var site = ""
        var legendStart = Float.MAX_VALUE
        for (r in rows) {
            if (r.y <= h.y) continue
            rxSite.find(r.text)?.let { s ->
                val parts = s.groupValues[1].split(" - ").map { it.trim() }.filter { it.isNotEmpty() }
                site = (if (parts.size > 1) parts[1] else parts.firstOrNull() ?: "").take(40)
                legendStart = minOf(legendStart, r.y)
            }
            rxLegend.find(r.text)?.let { lg ->
                val g = lg.groupValues
                legend[g[1]] = Code(g[3].toInt(), g[4].toInt(), g[5].toInt(), g[6].toInt(), g[2].trim().trimEnd(':', '-').trim(), site)
                legendStart = minOf(legendStart, r.y)
            }
        }
        val grid = rows.filter { it.y > h.y + 1 && it.y < legendStart }
        val out = mutableListOf<Shift>()

        // 4a) Codes de la grille + horaires de la légende
        if (legend.isNotEmpty()) {
            val rxCode = Regex("""(?<![A-Za-z0-9#])(""" + legend.keys.sortedByDescending { it.length }.joinToString("|") { Regex.escape(it) } + """)(?![0-9])""")
            for (r in grid) {
                for (mt in rxCode.findAll(r.text)) {
                    val code = legend[mt.value] ?: continue
                    val day = columnAt(r.centerX(mt.range.first, mt.range.last + 1)) ?: continue
                    out += shift(day, code.h1, code.m1, code.h2, code.m2, listOf(code.site, code.desc).filter { it.isNotBlank() }.joinToString(" · "), r.text)
                }
            }
            if (out.isNotEmpty()) return out
        }

        // 4b) Sans légende : horaires sous chaque colonne, deux par deux (début, fin), avec l'intitulé de la ligne
        val firstX = columns.first().second - spacing * 0.6f
        data class T(val day: Long, val y: Float, val h: Int, val m: Int, val label: String)
        val times = mutableListOf<T>()
        var label = ""
        for (r in grid) {
            val left = r.text.indices.filter { r.xs[it] < firstX }.joinToString("") { r.text[it].toString() }.trim()
            if (left.length >= 3 && left.any { it.isLetter() }) label = left
            for (mt in rxTime.findAll(r.text)) {
                val day = columnAt(r.centerX(mt.range.first, mt.range.last + 1)) ?: continue
                times += T(day, r.y, mt.groupValues[1].toInt(), mt.groupValues[2].toInt(), label)
            }
        }
        for ((day, ts) in times.groupBy { it.day }) {
            ts.sortedBy { it.y }.chunked(2).filter { it.size == 2 }.forEach { (a, b) ->
                out += shift(day, a.h, a.m, b.h, b.m, a.label, "")
            }
        }
        return out
    }

    /** Plus longue suite de numéros de jours consécutifs (avec éventuel retour à 01 après la fin du mois). */
    private fun longestRun(nums: List<Pair<Int, Float>>): List<Pair<Int, Float>> {
        var best = emptyList<Pair<Int, Float>>()
        var cur = mutableListOf<Pair<Int, Float>>()
        for (n in nums) {
            val prev = cur.lastOrNull()
            val follows = prev != null && n.second > prev.second &&
                (n.first == prev.first + 1 || (n.first == 1 && prev.first >= 28))
            if (follows) cur.add(n) else { if (cur.size > best.size) best = cur; cur = mutableListOf(n) }
        }
        if (cur.size > best.size) best = cur
        return best
    }

    private fun shift(day: Long, h1: Int, m1: Int, h2: Int, m2: Int, label: String, source: String): Shift {
        val s = at(day, h1 % 24, m1, 0)
        var e = at(day, h2 % 24, m2, 0)
        if (e <= s) e = at(day, h2 % 24, m2, 1) // fini après minuit (17:00 → 00:00, poste de nuit)
        return Shift(s, e, label, source)
    }

    private fun at(day: Long, h: Int, m: Int, plusDays: Int): Long = Calendar.getInstance().apply {
        timeInMillis = day
        add(Calendar.DAY_OF_YEAR, plusDays)
        set(Calendar.HOUR_OF_DAY, h); set(Calendar.MINUTE, m); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
    }.timeInMillis

    private fun dayMillis(y: Int, m: Int, d: Int): Long? = try {
        Calendar.getInstance().apply { isLenient = false; clear(); set(y, m, d) }.timeInMillis
    } catch (e: IllegalArgumentException) {
        null
    }
}
