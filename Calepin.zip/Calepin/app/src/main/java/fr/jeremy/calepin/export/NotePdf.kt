package fr.jeremy.calepin.export

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.text.Layout
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.StaticLayout
import android.text.TextPaint
import android.text.style.BackgroundColorSpan
import android.text.style.ForegroundColorSpan
import android.text.style.StrikethroughSpan
import android.text.style.StyleSpan
import android.text.style.UnderlineSpan
import fr.jeremy.calepin.text.AutoLayout
import fr.jeremy.calepin.text.AutoLayout.Block
import fr.jeremy.calepin.text.DisplayMap
import fr.jeremy.calepin.text.MarkdownSigns
import fr.jeremy.calepin.text.NoteLayout
import fr.jeremy.calepin.text.RichText
import java.io.ByteArrayOutputStream
import java.io.File

/** Présentation du PDF mis en page. */
enum class PdfStyle(val label: String, val hint: String) {
    MODERNE("Moderne", "Bandeau de couleur, titres colorés"),
    CLASSIQUE("Classique", "Titres à empattements, filets fins"),
    SOBRE("Sobre", "Noir et gris, pour imprimer"),
}

/**
 * PDF A4 soigné d'une ou plusieurs notes mises en page par [AutoLayout] : en-tête, encadré « En bref »,
 * titres, listes, cases à cocher, tableaux, citations, photos (vignettes, pleine largeur, à gauche ou à
 * droite avec le texte à côté), pied de page numéroté. Chaque note commence sur une nouvelle page.
 */
class NotePdf(
    private val style: PdfStyle,
    /** Fichier d'une photo ou vidéo de la note (null : introuvable) et vrai si c'est une vidéo. */
    private val media: (String) -> Pair<File, Boolean>?,
    /** Image réduite d'une photo ou vidéo (largeur ou hauteur au plus [maxSide] pixels). */
    private val thumbnail: (File, Boolean, Int) -> Bitmap?,
) {
    private val w = 595f
    private val h = 842f
    private val m = 50f
    private val bottom get() = h - 54f
    private val doc = PdfDocument()
    private var page: PdfDocument.Page? = null
    private var pageNo = 0
    private var y = 0f
    private var footerTitle = ""

    // Photo à gauche ou à droite : le texte passe à côté jusqu'à son bas
    private var floatBottom = 0f
    private var floatSide: NoteLayout.Side? = null
    private var floatW = 0f

    private val accent = when (style) {
        PdfStyle.MODERNE -> Color.rgb(17, 94, 132)
        PdfStyle.CLASSIQUE -> Color.rgb(122, 46, 46)
        PdfStyle.SOBRE -> Color.rgb(30, 30, 30)
    }
    private val accent2 = when (style) {
        PdfStyle.MODERNE -> Color.rgb(224, 122, 47)
        PdfStyle.CLASSIQUE -> Color.rgb(150, 120, 70)
        PdfStyle.SOBRE -> Color.rgb(110, 110, 110)
    }
    private val ink = Color.rgb(28, 33, 38)
    private val muted = Color.rgb(110, 116, 122)
    private val tint = blend(accent, Color.WHITE, 0.92f)
    private val rule = blend(accent, Color.WHITE, 0.75f)
    private val titleFace: Typeface = if (style == PdfStyle.CLASSIQUE) Typeface.create(Typeface.SERIF, Typeface.BOLD) else Typeface.create("sans-serif-medium", Typeface.NORMAL)
    private val bodyFace: Typeface = if (style == PdfStyle.CLASSIQUE) Typeface.SERIF else Typeface.SANS_SERIF

    private fun blend(a: Int, b: Int, t: Float): Int = Color.rgb(
        (Color.red(a) * (1 - t) + Color.red(b) * t).toInt(),
        (Color.green(a) * (1 - t) + Color.green(b) * t).toInt(),
        (Color.blue(a) * (1 - t) + Color.blue(b) * t).toInt(),
    )

    private fun paint(size: Float, color: Int = ink, face: Typeface = bodyFace) = TextPaint(TextPaint.ANTI_ALIAS_FLAG).apply {
        textSize = size; this.color = color; typeface = face
    }

    private val body = paint(10.8f)
    private val small = paint(9f, muted)

    // ------------------------------------------------------------------ Pages

    private fun newPage() {
        page?.let { finishPage(it) }
        pageNo++
        page = doc.startPage(PdfDocument.PageInfo.Builder(w.toInt(), h.toInt(), pageNo).create())
        y = m
        floatBottom = 0f; floatSide = null
    }

    private fun finishPage(p: PdfDocument.Page) {
        val c = p.canvas
        val fp = paint(7.8f, muted, Typeface.SANS_SERIF)
        c.drawLine(m, h - 40f, w - m, h - 40f, Paint().apply { color = rule; strokeWidth = 0.6f })
        val left = TextUtilsLite.ellipsize(footerTitle, fp, w - 2 * m - 60f)
        c.drawText(left, m, h - 28f, fp)
        val n = "$pageNo"
        c.drawText(n, w - m - fp.measureText(n), h - 28f, fp)
        doc.finishPage(p)
    }

    private val canvas: Canvas get() = page!!.canvas

    /** Place pour [space] points, sinon nouvelle page. */
    private fun ensure(space: Float) {
        if (page == null || y + space > bottom) newPage()
    }

    /** Colonne du texte (réduite à côté d'une photo placée à gauche ou à droite). */
    private fun column(): Pair<Float, Float> {
        if (floatSide == null || y >= floatBottom) { floatSide = null; return m to (w - 2 * m) }
        val gap = 14f
        return if (floatSide == NoteLayout.Side.LEFT) (m + floatW + gap) to (w - 2 * m - floatW - gap) else m to (w - 2 * m - floatW - gap)
    }

    private fun layout(text: CharSequence, p: TextPaint, width: Float, align: Layout.Alignment = Layout.Alignment.ALIGN_NORMAL, spacing: Float = 1.18f): StaticLayout =
        StaticLayout.Builder.obtain(text, 0, text.length, p, width.toInt().coerceAtLeast(20))
            .setAlignment(align).setLineSpacing(0f, spacing).setIncludePad(false).build()

    /**
     * Dessine un texte à partir de [y], coupé sur plusieurs pages si besoin. [x0] : décalage dans la colonne.
     * [onFirstLine] : dessine quelque chose devant la première ligne (puce, case) à sa hauteur.
     */
    private fun drawText(
        text: CharSequence, p: TextPaint, x0: Float = 0f, align: Layout.Alignment = Layout.Alignment.ALIGN_NORMAL,
        onFirstLine: ((Canvas, Float, Float) -> Unit)? = null, keepFirst: Float = 0f,
    ) {
        ensure(p.textSize * 1.6f + keepFirst)
        var (cx, cw) = column()
        var l = layout(text, p, cw - x0, align)
        var line = 0
        var first = true
        while (line < l.lineCount) {
            val lh = (l.getLineBottom(line) - l.getLineTop(line)).toFloat()
            if (y + lh > bottom) {
                newPage()
                // Nouvelle page : toute la largeur, la suite du texte est remise en page
                val rest = text.subSequence(l.getLineStart(line), text.length)
                val nc = column(); cx = nc.first; cw = nc.second
                l = layout(rest, p, cw - x0, align); line = 0
                continue
            }
            var last = line
            val top = l.getLineTop(line)
            while (last + 1 < l.lineCount && y + (l.getLineBottom(last + 1) - top) <= bottom) last++
            val c = canvas
            if (first) { onFirstLine?.invoke(c, cx, y + l.getLineBaseline(line) - top); first = false }
            c.save()
            c.translate(cx + x0, y - top)
            c.clipRect(0f, top.toFloat(), cw, l.getLineBottom(last).toFloat())
            l.draw(c)
            c.restore()
            y += (l.getLineBottom(last) - top).toFloat()
            line = last + 1
        }
    }

    // ------------------------------------------------------------------ Texte enrichi

    /** Gras, italique, barré, souligné, couleurs et surlignage de la note, sans leurs repères. */
    private fun styled(raw: String): CharSequence {
        if (raw.none { it == '*' || it == '~' || it == '[' || it == '#' }) return raw
        val hidden = (if ('[' in raw) RichText.tokens(raw).map { DisplayMap.Hidden(it.start, it.end, false) } else emptyList()) + MarkdownSigns.hidden(raw)
        val map = DisplayMap(raw, hidden, emptyList())
        val sb = SpannableStringBuilder(map.visible)
        fun span(what: Any, a: Int, b: Int) {
            val va = map.toVisible(a); val vb = map.toVisible(b)
            if (vb > va) sb.setSpan(what, va, vb, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        }
        MarkdownSigns.bold.findAll(raw).forEach { mr -> mr.groups[1]?.range?.let { span(StyleSpan(Typeface.BOLD), it.first, it.last + 1) } }
        MarkdownSigns.italic.findAll(raw).forEach { mr -> mr.groups[1]?.range?.let { span(StyleSpan(Typeface.ITALIC), it.first, it.last + 1) } }
        MarkdownSigns.strike.findAll(raw).forEach { mr -> mr.groups[1]?.range?.let { span(StrikethroughSpan(), it.first, it.last + 1) } }
        if ('[' in raw) RichText.spans(raw).forEach { s ->
            val col = runCatching { Color.parseColor(s.value) }.getOrNull()
            when (s.kind) {
                "c" -> if (col != null && style != PdfStyle.SOBRE) span(ForegroundColorSpan(col), s.start, s.end)
                "bg" -> if (col != null) span(BackgroundColorSpan(blend(col, Color.WHITE, 0.55f)), s.start, s.end)
                "u" -> span(UnderlineSpan(), s.start, s.end)
            }
        }
        return sb
    }

    private fun plain(raw: String) = MarkdownSigns.plain(RichText.strip(raw))

    // ------------------------------------------------------------------ En-tête et blocs

    private fun header(d: AutoLayout.Doc) {
        newPage()
        when (style) {
            PdfStyle.MODERNE -> {
                val tp = paint(23f, Color.WHITE, titleFace)
                val tl = layout(d.title, tp, w - 2 * m)
                val bandH = 34f + tl.height + 26f
                canvas.drawRect(0f, 0f, w, bandH, Paint().apply { color = accent })
                canvas.drawRect(0f, bandH, w, bandH + 4f, Paint().apply { color = accent2 })
                canvas.save(); canvas.translate(m, 30f); tl.draw(canvas); canvas.restore()
                val mp = paint(9f, blend(Color.WHITE, accent, 0.2f), Typeface.SANS_SERIF)
                canvas.drawText(TextUtilsLite.ellipsize(d.meta, mp, w - 2 * m), m, 30f + tl.height + 16f, mp)
                y = bandH + 26f
            }
            PdfStyle.CLASSIQUE -> {
                y = m + 6f
                drawText(d.title, paint(25f, accent, titleFace), align = Layout.Alignment.ALIGN_CENTER)
                y += 6f
                drawText(d.meta, paint(9f, muted, Typeface.create(Typeface.SERIF, Typeface.ITALIC)), align = Layout.Alignment.ALIGN_CENTER)
                y += 8f
                val cx = w / 2
                canvas.drawLine(cx - 70f, y, cx + 70f, y, Paint().apply { color = accent2; strokeWidth = 0.8f })
                canvas.drawCircle(cx, y, 2.2f, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = accent2 })
                y += 22f
            }
            PdfStyle.SOBRE -> {
                drawText(d.title, paint(21f, ink, Typeface.DEFAULT_BOLD))
                y += 3f
                drawText(d.meta, small)
                y += 6f
                canvas.drawLine(m, y, w - m, y, Paint().apply { color = Color.rgb(60, 60, 60); strokeWidth = 1f })
                y += 18f
            }
        }
    }

    private fun summary(facts: List<AutoLayout.Fact>) {
        if (facts.isEmpty()) return
        val pad = 12f
        val labelW = 82f
        val inner = w - 2 * m - 2 * pad
        val lp = paint(8.6f, accent, Typeface.DEFAULT_BOLD)
        val vp = paint(9.8f)
        val rows = facts.map { f -> layout(f.label.uppercase(), lp, labelW) to layout(f.values.joinToString("\n"), vp, inner - labelW) }
        val head = paint(10f, accent, titleFace)
        val total = pad + 16f + rows.sumOf { maxOf(it.first.height, it.second.height).toDouble() + 6.0 }.toFloat() + pad - 6f
        ensure(total)
        val c = canvas
        val r = RectF(m, y, w - m, y + total)
        c.drawRoundRect(r, 8f, 8f, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = tint })
        c.drawRect(m, y + 4f, m + 3.5f, y + total - 4f, Paint().apply { color = accent2 })
        var yy = y + pad
        c.drawText("En bref", m + pad, yy + 10f, head)
        yy += 16f
        rows.forEach { (lab, v) ->
            c.save(); c.translate(m + pad, yy + 1.5f); lab.draw(c); c.restore()
            c.save(); c.translate(m + pad + labelW, yy); v.draw(c); c.restore()
            yy += maxOf(lab.height, v.height) + 6f
        }
        y += total + 18f
    }

    private fun heading(b: Block.Heading) {
        val (size, color) = when (b.level) {
            1 -> 16.5f to accent
            2 -> 13.5f to (if (style == PdfStyle.SOBRE) ink else blend(accent, ink, 0.25f))
            else -> 11.5f to ink
        }
        val p = paint(size, color, titleFace)
        y += if (b.level == 1) 12f else 8f
        drawText(styled(b.text), p, keepFirst = 46f)
        if (b.level == 1) {
            val (cx, cw) = column()
            y += 3f
            val modern = style == PdfStyle.MODERNE
            val lp = Paint().apply { this.color = if (modern) accent2 else rule; strokeWidth = if (modern) 2f else 0.7f }
            canvas.drawLine(cx, y, cx + if (modern) 36f else cw, y, lp)
            y += 8f
        } else y += 5f
    }

    private fun bulletGlyph(level: Int) = when (level) { 0 -> "•"; 1 -> "◦"; else -> "–" }

    private fun list(b: Block.ListBlock) {
        val counters = IntArray(4)
        b.items.forEach { it ->
            val indent = 16f + it.level * 16f
            val mark = if (b.numbered) {
                counters[it.level]++
                for (k in it.level + 1 until 4) counters[k] = 0
                if (it.level == 0) "${counters[0]}." else "${('a' + (counters[it.level] - 1) % 26)})"
            } else bulletGlyph(it.level)
            val mp = paint(body.textSize, if (b.numbered) accent else accent2, if (b.numbered) Typeface.DEFAULT_BOLD else bodyFace)
            drawText(styled(it.text), body, x0 = indent, onFirstLine = { c, cx, base ->
                val mw = mp.measureText(mark)
                c.drawText(mark, cx + indent - 6f - mw, base, mp)
            })
            y += 3f
        }
        y += 6f
    }

    private fun tasks(b: Block.Tasks) {
        b.items.forEach { it ->
            val indent = 20f + it.level * 16f
            val done = it.done == true
            val p = if (done) paint(body.textSize, muted) else body
            val text = SpannableStringBuilder(styled(it.text)).apply { if (done) setSpan(StrikethroughSpan(), 0, length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE) }
            drawText(text, p, x0 = indent, onFirstLine = { c, cx, base ->
                val s = 9.5f
                val l = cx + indent - 16f
                val t = base - s + 1f
                val r = RectF(l, t, l + s, t + s)
                if (done) {
                    c.drawRoundRect(r, 2f, 2f, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = accent })
                    val path = Path().apply { moveTo(l + 2f, t + s * 0.52f); lineTo(l + s * 0.42f, t + s - 2.2f); lineTo(l + s - 1.8f, t + 2f) }
                    c.drawPath(path, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; this.style = Paint.Style.STROKE; strokeWidth = 1.5f; strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND })
                } else {
                    c.drawRoundRect(r, 2f, 2f, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = accent; this.style = Paint.Style.STROKE; strokeWidth = 1f })
                }
            })
            y += 4f
        }
        y += 6f
    }

    private fun keyValues(b: Block.KeyValues) {
        val (cx, cw) = column()
        val kp = paint(9.8f, if (style == PdfStyle.SOBRE) ink else accent, Typeface.DEFAULT_BOLD)
        val kw = (b.rows.maxOf { kp.measureText(plain(it.first)) } + 18f).coerceIn(70f, cw * 0.4f)
        b.rows.forEachIndexed { i, (k, v) ->
            val kl = layout(styled(k), kp, kw - 10f)
            val vl = layout(styled(v), body, cw - kw - 8f)
            val rh = maxOf(kl.height, vl.height) + 9f
            ensure(rh)
            val c = canvas
            if (i % 2 == 0) c.drawRect(cx, y, cx + cw, y + rh, Paint().apply { color = tint })
            c.save(); c.translate(cx + 6f, y + 5f + 0.8f); kl.draw(c); c.restore()
            c.save(); c.translate(cx + kw, y + 4.5f); vl.draw(c); c.restore()
            y += rh
        }
        canvas.drawLine(cx, y, cx + cw, y, Paint().apply { color = rule; strokeWidth = 0.6f })
        y += 12f
    }

    private fun table(b: Block.Table) {
        val (cx, cw) = column()
        val cols = maxOf(b.header?.size ?: 0, b.rows.maxOfOrNull { it.size } ?: 0)
        if (cols == 0) return
        val hp = paint(9.6f, if (style == PdfStyle.MODERNE) Color.WHITE else ink, Typeface.DEFAULT_BOLD)
        val cp = paint(9.6f)
        // Largeurs selon la longueur du contenu (bornées)
        val all = listOfNotNull(b.header) + b.rows
        val lens = (0 until cols).map { c -> all.maxOf { r -> plain(r.getOrElse(c) { "" }).length.coerceIn(3, 40) }.toFloat() }
        val widths = lens.map { it / lens.sum() * cw }
        fun row(cells: List<String>, p: TextPaint, fill: Int?) {
            val ls = cells.mapIndexed { i, s ->
                val numeric = Regex("^[-+]?[\\d\\s.,]+\\s?(€|%|h|kg|km|m)?$").matches(plain(s).trim()) && plain(s).isNotBlank()
                layout(styled(s), p, widths[i] - 10f, if (numeric) Layout.Alignment.ALIGN_OPPOSITE else Layout.Alignment.ALIGN_NORMAL)
            }
            val rh = (ls.maxOfOrNull { it.height } ?: 10) + 10f
            ensure(rh)
            val c = canvas
            if (fill != null) c.drawRect(cx, y, cx + cw, y + rh, Paint().apply { color = fill })
            var x = cx
            ls.forEachIndexed { i, l ->
                c.save(); c.translate(x + 5f, y + 5f); l.draw(c); c.restore()
                x += widths[i]
            }
            y += rh
            c.drawLine(cx, y, cx + cw, y, Paint().apply { color = rule; strokeWidth = 0.5f })
        }
        b.header?.let { row(it, hp, if (style == PdfStyle.MODERNE) accent else tint) }
        b.rows.forEachIndexed { i, r -> row(r, cp, if (i % 2 == 1) blend(tint, Color.WHITE, 0.5f) else null) }
        y += 12f
    }

    private fun quote(b: Block.Quote) {
        val p = paint(11f, blend(ink, accent, 0.3f), Typeface.create(bodyFace, Typeface.ITALIC))
        val start = y
        val startPage = pageNo
        drawText(styled(b.text), p, x0 = 16f)
        val (cx, _) = column()
        val top = if (pageNo == startPage) start else m
        canvas.drawRect(cx + 2f, top - 1f, cx + 5f, y + 1f, Paint().apply { color = accent2 })
        y += 10f
    }

    private fun divider() {
        ensure(18f)
        val cx = w / 2
        val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = accent2 }
        y += 6f
        listOf(-14f, 0f, 14f).forEach { canvas.drawCircle(cx + it, y, 1.6f, p) }
        y += 14f
    }

    private fun image(file: String, maxW: Float, maxH: Float): Bitmap? {
        val (f, video) = media(file) ?: return null
        return runCatching { thumbnail(f, video, 1600) }.getOrNull()
    }

    private fun drawBitmap(bm: Bitmap, r: RectF, crop: Boolean = false) {
        val src = if (!crop) Rect(0, 0, bm.width, bm.height) else {
            val ra = r.width() / r.height()
            val ba = bm.width.toFloat() / bm.height
            if (ba > ra) { val cw = (bm.height * ra).toInt(); Rect((bm.width - cw) / 2, 0, (bm.width + cw) / 2, bm.height) }
            else { val ch = (bm.width / ra).toInt(); Rect(0, (bm.height - ch) / 2, bm.width, (bm.height + ch) / 2) }
        }
        val c = canvas
        c.save()
        val clip = Path().apply { addRoundRect(r, 6f, 6f, Path.Direction.CW) }
        c.clipPath(clip)
        c.drawBitmap(bm, src, r, Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG))
        c.restore()
    }

    private fun videoBadge(r: RectF) {
        val c = canvas
        val cx = r.centerX(); val cy = r.centerY(); val rad = minOf(r.width(), r.height()) * 0.12f
        c.drawCircle(cx, cy, rad, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(150, 0, 0, 0) })
        val path = Path().apply { moveTo(cx - rad * 0.35f, cy - rad * 0.5f); lineTo(cx + rad * 0.55f, cy); lineTo(cx - rad * 0.35f, cy + rad * 0.5f); close() }
        c.drawPath(path, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE })
    }

    private fun photo(b: Block.Photo) {
        // Une photo flottante précédente se termine avant celle-ci
        if (floatSide != null && y < floatBottom) y = floatBottom + 8f
        floatSide = null
        val full = w - 2 * m
        val bm = image(b.file, full, h * 0.55f) ?: return
        val aspect = bm.width.toFloat() / bm.height.coerceAtLeast(1)
        val side = b.side
        val floating = side == NoteLayout.Side.LEFT || side == NoteLayout.Side.RIGHT
        var pw = full * b.width.coerceIn(20, 100) / 100f
        var ph = pw / aspect
        val maxH = if (floating) h * 0.4f else h * 0.55f
        if (ph > maxH) { ph = maxH; pw = ph * aspect }
        ensure(ph + 6f)
        val x = when (side) {
            NoteLayout.Side.LEFT -> m
            NoteLayout.Side.RIGHT -> w - m - pw
            else -> m + (full - pw) / 2
        }
        val r = RectF(x, y + 2f, x + pw, y + 2f + ph)
        drawBitmap(bm, r)
        if (media(b.file)?.second == true) videoBadge(r)
        if (floating && full - pw - 14f >= 120f) {
            floatSide = side; floatW = pw; floatBottom = r.bottom + 8f
            y += 2f
        } else {
            y = r.bottom + 14f
        }
        bm.recycle()
    }

    private fun thumbs(b: Block.Thumbs) {
        if (floatSide != null && y < floatBottom) y = floatBottom + 8f
        floatSide = null
        val perRow = when { b.files.size == 1 -> 1; b.files.size == 2 || b.files.size == 4 -> 2; else -> 3 }
        val gap = 8f
        val full = w - 2 * m
        val cell = if (perRow == 1) full * 0.6f else (full - gap * (perRow - 1)) / perRow
        val ch = if (perRow == 1) cell * 0.75f else cell * 0.75f
        b.files.chunked(perRow).forEach { row ->
            ensure(ch + gap)
            var x = if (perRow == 1) m + (full - cell) / 2 else m
            row.forEach { f ->
                val bm = image(f, cell, ch)
                val r = RectF(x, y, x + cell, y + ch)
                if (bm != null) {
                    drawBitmap(bm, r, crop = true)
                    if (media(f)?.second == true) videoBadge(r)
                    bm.recycle()
                }
                x += cell + gap
            }
            y += ch + gap
        }
        y += 6f
    }

    private fun paragraph(b: Block.Paragraph) {
        val align = when (b.align) {
            RichText.CENTER -> Layout.Alignment.ALIGN_CENTER
            RichText.RIGHT -> Layout.Alignment.ALIGN_OPPOSITE
            else -> Layout.Alignment.ALIGN_NORMAL
        }
        drawText(styled(b.text), body, align = align)
        y += 9f
    }

    // ------------------------------------------------------------------ Assemblage

    fun add(d: AutoLayout.Doc) {
        footerTitle = d.title
        header(d)
        summary(d.facts)
        d.blocks.forEach { b ->
            when (b) {
                is Block.Heading -> heading(b)
                is Block.Paragraph -> paragraph(b)
                is Block.ListBlock -> list(b)
                is Block.Tasks -> tasks(b)
                is Block.KeyValues -> keyValues(b)
                is Block.Table -> table(b)
                is Block.Quote -> quote(b)
                is Block.Photo -> photo(b)
                is Block.Thumbs -> thumbs(b)
                Block.Divider -> divider()
            }
        }
        if (d.blocks.isEmpty() && d.facts.isEmpty()) drawText("(note vide)", small)
    }

    fun build(): ByteArray {
        if (page == null) newPage()
        page?.let { finishPage(it) }
        page = null
        val out = ByteArrayOutputStream()
        doc.writeTo(out)
        doc.close()
        return out.toByteArray()
    }

    companion object {
        /** Toutes les notes dans un seul PDF. */
        fun render(
            docs: List<AutoLayout.Doc>, style: PdfStyle,
            media: (String) -> Pair<File, Boolean>?, thumbnail: (File, Boolean, Int) -> Bitmap?,
        ): ByteArray {
            val p = NotePdf(style, media, thumbnail)
            docs.forEach { p.add(it) }
            return p.build()
        }
    }
}

/** Texte raccourci avec « … » pour tenir dans [max] points. */
internal object TextUtilsLite {
    fun ellipsize(s: String, p: Paint, max: Float): String {
        if (p.measureText(s) <= max) return s
        var t = s
        while (t.isNotEmpty() && p.measureText("$t…") > max) t = t.dropLast(1)
        return t.trimEnd() + "…"
    }
}
