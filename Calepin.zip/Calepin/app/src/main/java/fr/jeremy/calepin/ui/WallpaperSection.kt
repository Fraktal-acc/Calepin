package fr.jeremy.calepin.ui

import android.content.Context
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Link
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import fr.jeremy.calepin.LockGuard
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.util.UUID

/** Import d'un fond : depuis la galerie (photo, GIF, vidéo) ou depuis un lien Internet. */
object Wallpapers {
    private const val MAX_BYTES = 120L * 1024 * 1024

    private fun extFor(mime: String?, path: String?): String {
        val m = mime.orEmpty().lowercase()
        val fromPath = path?.substringAfterLast('/')?.substringBefore('?')?.substringAfterLast('.', "")?.lowercase().orEmpty()
        return when {
            m.contains("gif") -> "gif"
            m.contains("webp") -> "webp"
            m.contains("png") -> "png"
            m.contains("jpeg") || m.contains("jpg") -> "jpg"
            m.contains("heic") || m.contains("heif") -> "heic"
            m.startsWith("video/") -> if (m.contains("webm")) "webm" else if (m.contains("3gp")) "3gp" else "mp4"
            fromPath in setOf("gif", "webp", "png", "jpg", "jpeg", "mp4", "webm", "3gp", "mkv", "mov", "heic") -> if (fromPath == "jpeg") "jpg" else fromPath
            else -> "jpg"
        }
    }

    private fun replace(ctx: Context, ext: String, write: (File) -> Unit): String {
        val dir = wallpaperDir(ctx)
        val f = File(dir, "fond_" + UUID.randomUUID().toString().take(8) + "." + ext)
        write(f)
        if (f.length() == 0L) { f.delete(); error("Fichier vide.") }
        dir.listFiles()?.filter { it != f }?.forEach { it.delete() }
        return f.name
    }

    fun fromUri(ctx: Context, uri: Uri): String {
        val mime = ctx.contentResolver.getType(uri)
        return replace(ctx, extFor(mime, uri.lastPathSegment)) { f ->
            ctx.contentResolver.openInputStream(uri)?.use { input -> f.outputStream().use { input.copyTo(it) } } ?: error("Fichier illisible.")
        }
    }

    fun fromUrl(ctx: Context, link: String): String {
        var url = URL(link.trim().let { if (it.startsWith("http")) it else "https://$it" })
        var c: HttpURLConnection
        var hops = 0
        while (true) {
            c = (url.openConnection() as HttpURLConnection).apply {
                connectTimeout = 15_000; readTimeout = 30_000; instanceFollowRedirects = false
                setRequestProperty("User-Agent", "Mozilla/5.0 (Android) Calepin")
            }
            val code = c.responseCode
            if (code in 300..399 && hops < 5) { url = URL(url, c.getHeaderField("Location")); c.disconnect(); hops++; continue }
            if (code !in 200..299) error("Le site a répondu $code.")
            break
        }
        val mime = c.contentType
        if (mime != null && mime.startsWith("text/html")) error("Ce lien mène à une page web, pas à une image ou une vidéo. Ouvre l'image seule et copie son adresse.")
        if (c.contentLengthLong > MAX_BYTES) error("Fichier trop lourd (plus de 120 Mo).")
        return try {
            replace(ctx, extFor(mime, url.path)) { f ->
                c.inputStream.use { input ->
                    f.outputStream().use { out ->
                        val buf = ByteArray(64 * 1024)
                        var total = 0L
                        while (true) {
                            val n = input.read(buf)
                            if (n < 0) break
                            total += n
                            if (total > MAX_BYTES) error("Fichier trop lourd (plus de 120 Mo).")
                            out.write(buf, 0, n)
                        }
                    }
                }
            }
        } finally {
            c.disconnect()
        }
    }

    fun clear(ctx: Context) { wallpaperDir(ctx).listFiles()?.forEach { it.delete() } }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun WallpaperSection() {
    val ctx = LocalContext.current
    val a = remember { Appearance.get(ctx) }
    val wall by a.wallpaper.collectAsStateWithLifecycle()
    val dim by a.wallDim.collectAsStateWithLifecycle()
    val scope by a.wallScope.collectAsStateWithLifecycle()
    val co = rememberCoroutineScope()
    var busy by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf<String?>(null) }
    var askUrl by remember { mutableStateOf(false) }
    var url by remember { mutableStateOf("") }

    fun load(block: () -> String) {
        busy = true; message = null
        co.launch {
            val r = withContext(Dispatchers.IO) { runCatching(block) }
            busy = false
            r.onSuccess { a.setWallpaper(it); message = "Fond appliqué." }.onFailure { message = it.message ?: "Impossible de récupérer ce fichier." }
        }
    }

    val pick = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) load { Wallpapers.fromUri(ctx, uri) }
    }

    Text(
        "Une photo, une image animée (GIF) ou une courte vidéo en fond de Calepin, à la place du décor du thème. " +
            "Les vidéos tournent en boucle, sans le son.",
        style = MaterialTheme.typography.bodySmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
    )
    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        OutlinedButton(onClick = { LockGuard.external(); pick.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) }, enabled = !busy) {
            Icon(Icons.Filled.Image, null, Modifier.size(18.dp)); Text(" Photo ou GIF")
        }
        OutlinedButton(onClick = { LockGuard.external(); pick.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.VideoOnly)) }, enabled = !busy) {
            Icon(Icons.Filled.Movie, null, Modifier.size(18.dp)); Text(" Vidéo")
        }
        OutlinedButton(onClick = { askUrl = true }, enabled = !busy) {
            Icon(Icons.Filled.Link, null, Modifier.size(18.dp)); Text(" Depuis Internet")
        }
        if (wall.isNotBlank()) {
            OutlinedButton(onClick = { Wallpapers.clear(ctx); a.setWallpaper(""); message = "Fond retiré : le décor du thème revient." }, enabled = !busy) {
                Icon(Icons.Filled.Delete, null, Modifier.size(18.dp)); Text(" Retirer")
            }
        }
    }
    if (busy) Row(verticalAlignment = Alignment.CenterVertically) { CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp); Text("  Chargement…") }
    message?.let { Text(it, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary) }
    if (wall.isNotBlank()) {
        Column {
            Text("Voile pour la lisibilité : ${(dim * 100).toInt()} %", style = MaterialTheme.typography.bodyMedium)
            Slider(value = dim, onValueChange = { a.setWallDim(it) }, valueRange = 0f..0.9f)
        }
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            WallScope.entries.forEach { s -> FilterChip(selected = s == scope, onClick = { a.setWallScope(s) }, label = { Text(s.label) }) }
        }
    }

    if (askUrl) {
        AlertDialog(
            onDismissRequest = { askUrl = false },
            title = { Text("Fond depuis Internet") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Colle l'adresse d'une image, d'un GIF ou d'une vidéo (lien qui se termine souvent par .jpg, .png, .gif ou .mp4).", style = MaterialTheme.typography.bodySmall)
                    OutlinedTextField(url, { url = it }, label = { Text("https://…") }, singleLine = true)
                }
            },
            confirmButton = {
                TextButton(enabled = url.isNotBlank(), onClick = { askUrl = false; val u = url; load { Wallpapers.fromUrl(ctx, u) } }) { Text("Télécharger") }
            },
            dismissButton = { TextButton(onClick = { askUrl = false }) { Text("Annuler") } },
        )
    }
}
