package fr.jeremy.calepin.export

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.DataInputStream
import java.io.File
import java.io.FileInputStream
import java.io.FilterOutputStream
import java.io.InputStream
import java.io.OutputStream
import java.security.SecureRandom
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream
import javax.crypto.Cipher
import javax.crypto.CipherInputStream
import javax.crypto.CipherOutputStream
import javax.crypto.Mac
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.IvParameterSpec
import javax.crypto.spec.PBEKeySpec
import javax.crypto.spec.SecretKeySpec

/**
 * Sauvegarde complète de Calepin dans un seul fichier (.calepin) :
 * données (notes, agenda, dossiers…), photos, vidéos, croquis, mémos vocaux, mode pro et réglages.
 * Avec un mot de passe, le fichier est chiffré (AES-256 + contrôle d'intégrité HMAC-SHA256) :
 * sans le mot de passe, personne ne peut le lire, même stocké sur Google Drive.
 */
object FullBackup {
    private val MAGIC_PLAIN = "CALEPINBK0".toByteArray()
    private val MAGIC_ENC = "CALEPINBK1".toByteArray()
    private const val ITER = 120_000

    /** Réglages sauvegardés (les modèles d'IA, très lourds, se retéléchargent). */
    val PREFS = listOf("calepin_settings", "calepin_appearance", "calepin_games", "calepin_home", "calepin_scenarios", "calepin_guard")

    /** Dossiers de fichiers sauvegardés, relatifs au stockage interne de l'appli. */
    val DIRS = listOf("media", "recordings", "pro_photos", "documents")

    class WrongPassword : Exception("Mot de passe incorrect, ou fichier abîmé.")

    private fun keys(password: String, salt: ByteArray): Pair<ByteArray, ByteArray> {
        val f = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256")
        val k = f.generateSecret(PBEKeySpec(password.toCharArray(), salt, ITER, 512)).encoded
        return k.copyOfRange(0, 32) to k.copyOfRange(32, 64)
    }

    /** Flux qui calcule le HMAC de tout ce qui passe, sans fermer le flux final. */
    private class MacStream(out: OutputStream, val mac: Mac) : FilterOutputStream(out) {
        override fun write(b: Int) { mac.update(b.toByte()); out.write(b) }
        override fun write(b: ByteArray, off: Int, len: Int) { mac.update(b, off, len); out.write(b, off, len) }
        override fun close() { flush() }
    }

    private fun prefsJson(ctx: Context): JSONObject = JSONObject().apply {
        PREFS.forEach { name ->
            val all = ctx.getSharedPreferences(name, Context.MODE_PRIVATE).all
            val o = JSONObject()
            all.forEach { (k, v) ->
                val typed = when (v) {
                    is Boolean -> JSONObject().put("t", "b").put("v", v)
                    is Int -> JSONObject().put("t", "i").put("v", v)
                    is Long -> JSONObject().put("t", "l").put("v", v)
                    is Float -> JSONObject().put("t", "f").put("v", v.toDouble())
                    is String -> JSONObject().put("t", "s").put("v", v)
                    is Set<*> -> JSONObject().put("t", "ss").put("v", JSONArray(v.map { it.toString() }))
                    else -> null
                }
                if (typed != null) o.put(k, typed)
            }
            put(name, o)
        }
    }

    private fun applyPrefs(ctx: Context, o: JSONObject) {
        PREFS.forEach { name ->
            val p = o.optJSONObject(name) ?: return@forEach
            val e = ctx.getSharedPreferences(name, Context.MODE_PRIVATE).edit()
            p.keys().forEach { k ->
                val t = p.optJSONObject(k) ?: return@forEach
                when (t.optString("t")) {
                    "b" -> e.putBoolean(k, t.optBoolean("v"))
                    "i" -> e.putInt(k, t.optInt("v"))
                    "l" -> e.putLong(k, t.optLong("v"))
                    "f" -> e.putFloat(k, t.optDouble("v").toFloat())
                    "s" -> e.putString(k, t.optString("v"))
                    "ss" -> e.putStringSet(k, t.optJSONArray("v")?.let { a -> (0 until a.length()).map { a.optString(it) }.toSet() } ?: emptySet())
                }
            }
            e.apply()
        }
    }

    /** Écrit la sauvegarde. [data] : notes, agenda… (préparés par le ViewModel). */
    fun write(ctx: Context, target: OutputStream, data: JSONObject, password: String?, onProgress: (String) -> Unit = {}) {
        target.use { raw ->
            if (password.isNullOrEmpty()) {
                raw.write(MAGIC_PLAIN)
                zip(ctx, raw, data, onProgress)
            } else {
                val salt = ByteArray(16).also { SecureRandom().nextBytes(it) }
                val iv = ByteArray(16).also { SecureRandom().nextBytes(it) }
                val (encKey, macKey) = keys(password, salt)
                raw.write(MAGIC_ENC); raw.write(salt); raw.write(iv)
                val mac = Mac.getInstance("HmacSHA256").apply { init(SecretKeySpec(macKey, "HmacSHA256")); update(iv) }
                val cipher = Cipher.getInstance("AES/CBC/PKCS5Padding").apply { init(Cipher.ENCRYPT_MODE, SecretKeySpec(encKey, "AES"), IvParameterSpec(iv)) }
                val macOut = MacStream(raw, mac)
                CipherOutputStream(macOut, cipher).use { zip(ctx, it, data, onProgress) }
                raw.write(mac.doFinal())
            }
        }
    }

    private fun zip(ctx: Context, out: OutputStream, data: JSONObject, onProgress: (String) -> Unit) {
        val z = ZipOutputStream(out)
        fun putText(name: String, text: String) {
            z.putNextEntry(ZipEntry(name)); z.write(text.toByteArray(Charsets.UTF_8)); z.closeEntry()
        }
        putText("manifest.json", JSONObject().put("app", "Calepin").put("version", 1).put("date", System.currentTimeMillis()).toString())
        putText("data.json", data.toString())
        putText("prefs.json", prefsJson(ctx).toString())
        File(ctx.filesDir, "pro.json").takeIf { it.exists() }?.let { putText("pro.json", it.readText()) }
        File(ctx.filesDir, "billing.json").takeIf { it.exists() }?.let { putText("billing.json", it.readText()) }
        DIRS.forEach { dir ->
            val files = File(ctx.filesDir, dir).listFiles()?.filter { it.isFile } ?: return@forEach
            files.forEachIndexed { i, f ->
                onProgress("Fichiers « $dir » : ${i + 1}/${files.size}")
                z.putNextEntry(ZipEntry("$dir/${f.name}"))
                FileInputStream(f).use { it.copyTo(z) }
                z.closeEntry()
            }
        }
        z.finish()
        z.flush()
    }

    /** Résultat de la lecture : données à fusionner et nombre de fichiers ajoutés. */
    class Restored(val data: JSONObject?, val pro: JSONObject?, val files: Int)

    /** Vrai si le fichier demande un mot de passe. */
    fun isEncrypted(file: File): Boolean = FileInputStream(file).use { s ->
        val m = ByteArray(10); DataInputStream(s).readFully(m); m.contentEquals(MAGIC_ENC)
    }

    fun read(ctx: Context, file: File, password: String?): Restored {
        val total = file.length()
        FileInputStream(file).use { fis ->
            val din = DataInputStream(fis)
            val magic = ByteArray(10).also { din.readFully(it) }
            return when {
                magic.contentEquals(MAGIC_PLAIN) -> unzip(ctx, din)
                magic.contentEquals(MAGIC_ENC) -> {
                    if (password.isNullOrEmpty()) throw WrongPassword()
                    val salt = ByteArray(16).also { din.readFully(it) }
                    val iv = ByteArray(16).also { din.readFully(it) }
                    val (encKey, macKey) = keys(password, salt)
                    val bodyLen = total - 10 - 16 - 16 - 32
                    if (bodyLen <= 0) throw WrongPassword()
                    // 1) Vérifier l'intégrité et le mot de passe avant de toucher à quoi que ce soit
                    val mac = Mac.getInstance("HmacSHA256").apply { init(SecretKeySpec(macKey, "HmacSHA256")); update(iv) }
                    FileInputStream(file).use { s2 ->
                        s2.skip(42)
                        val buf = ByteArray(64 * 1024)
                        var left = bodyLen
                        while (left > 0) {
                            val n = s2.read(buf, 0, minOf(buf.size.toLong(), left).toInt())
                            if (n < 0) throw WrongPassword()
                            mac.update(buf, 0, n); left -= n
                        }
                        val expected = ByteArray(32).also { DataInputStream(s2).readFully(it) }
                        if (!java.security.MessageDigest.isEqual(mac.doFinal(), expected)) throw WrongPassword()
                    }
                    // 2) Déchiffrer
                    val cipher = Cipher.getInstance("AES/CBC/PKCS5Padding").apply { init(Cipher.DECRYPT_MODE, SecretKeySpec(encKey, "AES"), IvParameterSpec(iv)) }
                    unzip(ctx, CipherInputStream(Limited(din, bodyLen), cipher))
                }
                else -> throw IllegalArgumentException("Ce fichier n'est pas une sauvegarde Calepin.")
            }
        }
    }

    private class Limited(private val inner: InputStream, private var left: Long) : InputStream() {
        override fun read(): Int = if (left <= 0) -1 else inner.read().also { if (it >= 0) left-- }
        override fun read(b: ByteArray, off: Int, len: Int): Int {
            if (left <= 0) return -1
            val n = inner.read(b, off, minOf(len.toLong(), left).toInt())
            if (n > 0) left -= n
            return n
        }
    }

    private fun unzip(ctx: Context, input: InputStream): Restored {
        var data: JSONObject? = null
        var pro: JSONObject? = null
        var files = 0
        val z = ZipInputStream(input)
        while (true) {
            val e = z.nextEntry ?: break
            val name = e.name
            when {
                name == "data.json" -> data = JSONObject(z.readBytes().toString(Charsets.UTF_8))
                name == "pro.json" -> pro = runCatching { JSONObject(z.readBytes().toString(Charsets.UTF_8)) }.getOrNull()
                name == "prefs.json" -> runCatching { applyPrefs(ctx, JSONObject(z.readBytes().toString(Charsets.UTF_8))) }
                // Devis et factures : repris seulement si le téléphone n'en a pas encore
                name == "billing.json" -> runCatching {
                    val f = File(ctx.filesDir, "billing.json")
                    if (!f.exists()) f.writeBytes(z.readBytes())
                }
                name.contains('/') -> {
                    val dir = name.substringBefore('/')
                    val fileName = name.substringAfter('/')
                    // Seulement nos dossiers, et pas de chemin détourné (« ../ »)
                    if (dir in DIRS && fileName.isNotBlank() && !fileName.contains('/') && !fileName.contains("..")) {
                        val target = File(File(ctx.filesDir, dir).apply { mkdirs() }, fileName)
                        if (!target.exists()) {
                            target.outputStream().use { z.copyTo(it) }
                            files++
                        }
                    }
                }
            }
            z.closeEntry()
        }
        return Restored(data, pro, files)
    }
}
