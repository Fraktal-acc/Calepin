package fr.jeremy.calepin.ui.market

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import fr.jeremy.calepin.Actions
import fr.jeremy.calepin.i18n.I18n
import fr.jeremy.calepin.i18n.RawText
import fr.jeremy.calepin.i18n.Text
import fr.jeremy.calepin.market.News
import fr.jeremy.calepin.market.NewsTone
import fr.jeremy.calepin.ui.appBorder
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.util.Locale

private val POS = Color(0xFF2E9E4F)
private val NEG = Color(0xFFE0453A)

private fun ago(t: Long): String {
    if (t <= 0) return ""
    val m = ((System.currentTimeMillis() - t) / 60_000L).coerceAtLeast(0)
    val v = when {
        m < 60 -> "$m min"
        m < 48 * 60 -> "${m / 60} h"
        else -> "${m / 1440} " + I18n.tr("j")
    }
    return I18n.tr("il y a {0}").replace("{0}", v)
}

/**
 * Actualités de l'instrument trouvées sur internet (Yahoo Finance, Google Actualités en français et en anglais),
 * avec le ton de chaque titre et le ton général, pris en compte par l'analyse du robot.
 */
@Composable
fun NewsCard(symbol: String, name: String, reload: Int) {
    val ctx = LocalContext.current
    var force by remember { mutableIntStateOf(0) }
    var showAll by remember { mutableStateOf(false) }
    val tone by produceState<NewsTone?>(null, symbol, reload, force) {
        while (true) {
            value = withContext(Dispatchers.IO) { runCatching { News.forInstrument(symbol, name, force = force > 0) }.getOrNull() } ?: value
            delay(10 * 60_000L)
        }
    }
    val cs = MaterialTheme.colorScheme
    Surface(shape = MaterialTheme.shapes.large, color = cs.surfaceContainerLow, border = appBorder(), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Actualités sur internet", style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
                IconButton(onClick = { force++ }) { Icon(Icons.Filled.Refresh, I18n.tr("Actualiser")) }
            }
            val t = tone
            if (t == null) {
                Text("Recherche des actualités…", color = cs.onSurfaceVariant)
                return@Column
            }
            if (t.items.isEmpty()) {
                Text("Aucune actualité trouvée cette semaine.", color = cs.onSurfaceVariant)
                return@Column
            }
            val pct = t.score * 100
            val col = when { pct >= 15 -> POS; pct <= -15 -> NEG; else -> cs.onSurfaceVariant }
            RawText(
                I18n.tr("Ton général") + " : " + (if (pct >= 0) "+" else "") + String.format(Locale.FRANCE, "%.0f", pct) + " % · " +
                    I18n.tr(when { pct >= 15 -> "plutôt favorable"; pct <= -15 -> "plutôt défavorable"; else -> "neutre" }),
                style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold, color = col,
            )
            RawText(
                "${t.items.size} " + I18n.tr("articles") + " · ${t.positive} " + I18n.tr("positifs") + " · ${t.negative} " + I18n.tr("négatifs") + " · ${t.recent} " + I18n.tr("ces dernières 48 h"),
                style = MaterialTheme.typography.labelMedium, color = cs.onSurfaceVariant,
            )
            (if (showAll) t.items else t.items.take(8)).forEach { n ->
                Surface(
                    onClick = { if (n.link.isNotBlank()) Actions.openUrl(ctx, n.link) },
                    shape = MaterialTheme.shapes.medium,
                    color = cs.surfaceContainerHigh,
                    modifier = Modifier.fillMaxWidth(),
                ) {
                    Row(Modifier.padding(10.dp)) {
                        Box(
                            Modifier.padding(top = 5.dp).size(9.dp).background(
                                when { n.score >= 0.3 -> POS; n.score <= -0.3 -> NEG; else -> cs.outline }, CircleShape,
                            ),
                        )
                        Spacer(Modifier.width(10.dp))
                        Column(Modifier.weight(1f)) {
                            RawText(n.title, style = MaterialTheme.typography.bodyMedium, maxLines = 3, overflow = TextOverflow.Ellipsis)
                            RawText(listOf(n.source, ago(n.time)).filter { it.isNotBlank() }.joinToString(" · "), style = MaterialTheme.typography.labelSmall, color = cs.onSurfaceVariant)
                        }
                    }
                }
            }
            if (t.items.size > 8) TextButton(onClick = { showAll = !showAll }) { Text(if (showAll) "Moins d'articles" else "Tous les articles") }
            Text(
                "Le ton est estimé d'après les mots des titres (hausse, record, relève ses objectifs… ou chute, perte, avertissement…). Lis les articles importants avant de décider.",
                style = MaterialTheme.typography.labelSmall, color = cs.onSurfaceVariant,
            )
        }
    }
}
