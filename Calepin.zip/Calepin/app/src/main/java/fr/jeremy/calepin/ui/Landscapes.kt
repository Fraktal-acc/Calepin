package fr.jeremy.calepin.ui

import androidx.compose.material3.ColorScheme
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.unit.dp
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

/*
 * Paysages peints (montagnes, océan, forêt, ville, désert, aurore, plage, savane, lavande, Côte d'Azur)
 * et décors inspirés d'autres cultures (Japon, Chine, Inde, Maroc, Mexique, Grèce).
 * Tout est dessiné sur le téléphone : ciel en dégradé, reliefs en plusieurs plans avec brume (perspective
 * atmosphérique), reflets dans l'eau, lumières qui scintillent… et quelques mouvements lents.
 */

private fun hs(i: Int, k: Int): Float {
    var x = i * 374761393 + k * 668265263
    x = (x xor (x ushr 13)) * 1274126177
    return ((x xor (x ushr 16)) and 0xFFFFFF) / 16777215f
}

private fun wrapF(v: Float, m: Float) = ((v % m) + m) % m

/** Relief « naturel » entre -1 et 1 : somme d'ondulations de fréquences croissantes. */
private fun relief(x: Float, seed: Int): Float {
    var v = 0f
    var amp = 1f
    var freq = 1f
    var norm = 0f
    for (o in 0 until 5) {
        v += amp * sin(x * freq * (2.1f + hs(seed, o) * 1.7f) * PI.toFloat() + hs(seed, o + 10) * 6.28f)
        norm += amp
        amp *= 0.5f
        freq *= 2.03f
    }
    return v / norm
}

private fun DrawScope.sky(vararg stops: Pair<Float, Color>) = drawRect(Brush.verticalGradient(*stops.map { it.first to DecoTint.l(0, it.second) }.toTypedArray()))

/** Chaîne de collines ou de montagnes ([sharp] : crêtes rocheuses). */
private fun DrawScope.ridge(seed: Int, baseY: Float, amp: Float, color0: Color, detail: Float = 1f, sharp: Boolean = false, shift: Float = 0f) {
    val color = DecoTint.l(2, color0)
    val w = size.width
    val p = Path()
    p.moveTo(0f, size.height)
    val n = 110
    for (i in 0..n) {
        val fx = i / n.toFloat()
        val r = relief(fx * detail + shift, seed)
        val v = if (sharp) 1f - abs(r) * 1.6f else r
        p.lineTo(fx * w, baseY - amp * (0.5f + 0.5f * v))
    }
    p.lineTo(w, size.height)
    p.close()
    drawPath(p, color)
}

/** Bande de brume qui dérive lentement. */
private fun DrawScope.mist(y: Float, thick: Float, color0: Color, t: Float, speed: Float, seed: Int) {
    val color = DecoTint.l(0, color0)
    val w = size.width
    for (k in 0 until 4) {
        val cw = w * (0.7f + hs(seed, k) * 0.6f)
        val x = wrapF(hs(seed, k + 5) * (w + cw) + t * speed * (0.6f + hs(seed, k + 9)), w + cw) - cw / 2
        drawOval(
            Brush.radialGradient(listOf(color, Color.Transparent), center = Offset(x, y), radius = cw / 2),
            topLeft = Offset(x - cw / 2, y - thick / 2), size = Size(cw, thick),
        )
    }
}

private fun DrawScope.glowAt(c: Offset, r: Float, color: Color) =
    DecoTint.l(1, color).let { col -> drawCircle(Brush.radialGradient(listOf(col, Color.Transparent), center = c, radius = r), r, c) }

private fun DrawScope.starsField(n: Int, upTo: Float, t: Float, alpha: Float = 1f, seed: Int = 1) {
    val dp = 1.dp.toPx()
    for (i in 0 until n) {
        val tw = 0.4f + 0.6f * abs(sin(t * (0.5f + hs(i, seed + 3) * 1.5f) + i))
        drawCircle(
            Color.White.copy(alpha = alpha * (0.25f + 0.55f * hs(i, seed + 7)) * tw),
            (0.5f + hs(i, seed + 4) * 1.3f) * dp,
            Offset(hs(i, seed + 1) * size.width, hs(i, seed + 2) * size.height * upTo),
        )
    }
}

/** Étoile filante de temps en temps. */
private fun DrawScope.shootingStar(t: Float, every: Float, upTo: Float) {
    val k = (t / every).toInt()
    val local = t % every
    if (local > 1.1f) return
    val p = local / 1.1f
    val sx = size.width * (0.1f + hs(k, 1) * 0.7f)
    val sy = size.height * upTo * (0.05f + hs(k, 2) * 0.5f)
    val len = size.width * 0.35f
    val x = sx + len * p
    val y = sy + len * 0.45f * p
    val a = sin(p * PI.toFloat())
    drawLine(
        Brush.linearGradient(listOf(Color.Transparent, Color.White.copy(alpha = 0.85f * a)), Offset(x - len * 0.25f, y - len * 0.11f), Offset(x, y)),
        Offset(x - len * 0.25f, y - len * 0.11f), Offset(x, y), 1.6f * 1.dp.toPx(),
    )
}

/** Reflets qui scintillent sur l'eau. */
private fun DrawScope.shimmer(cx: Float, y0: Float, y1: Float, spread: Float, color0: Color, t: Float, n: Int) {
    val color = DecoTint.l(1, color0)
    val dp = 1.dp.toPx()
    for (i in 0 until n) {
        val fy = hs(i, 1)
        val y = y0 + (y1 - y0) * fy * fy
        val width = spread * (0.3f + fy) * (0.3f + hs(i, 2))
        val x = cx + (hs(i, 3) - 0.5f) * spread * (0.4f + fy) + sin(t * 0.8f + i) * 6 * dp
        val a = (0.15f + 0.6f * abs(sin(t * (0.7f + hs(i, 4) * 1.8f) + i))) * (1f - fy * 0.6f)
        drawLine(color.copy(alpha = color.alpha * a), Offset(x - width / 2, y), Offset(x + width / 2, y), (1f + fy * 2f) * dp)
    }
}

private fun DrawScope.pine(x: Float, base: Float, h: Float, color0: Color) {
    val color = DecoTint.l(2, color0)
    val p = Path()
    val w = h * 0.42f
    for (k in 0 until 4) {
        val top = base - h + k * h * 0.2f
        val half = w * (0.35f + k * 0.2f) / 2
        p.moveTo(x, top)
        p.lineTo(x - half, top + h * 0.34f)
        p.lineTo(x + half, top + h * 0.34f)
        p.close()
    }
    drawPath(p, color)
    drawRect(color, Offset(x - h * 0.02f, base - h * 0.12f), Size(h * 0.04f, h * 0.12f))
}

private fun DrawScope.palm(x: Float, base: Float, h: Float, lean: Float, color0: Color, t: Float) {
    val color = DecoTint.l(2, color0)
    val dp = 1.dp.toPx()
    val top = Offset(x + lean * h, base - h)
    val trunk = Path().apply {
        moveTo(x - 5 * dp, base)
        quadraticBezierTo(x + lean * h * 0.2f, base - h * 0.5f, top.x - 2 * dp, top.y)
        lineTo(top.x + 2 * dp, top.y)
        quadraticBezierTo(x + lean * h * 0.2f + 6 * dp, base - h * 0.5f, x + 5 * dp, base)
        close()
    }
    drawPath(trunk, color)
    for (k in 0 until 7) {
        val ang = (-170f + k * 28f + sin(t * 0.9f + k) * 4f) * PI.toFloat() / 180f
        val len = h * (0.42f + hs(k, 3) * 0.12f)
        val end = Offset(top.x + cos(ang) * len, top.y + sin(ang) * len * 0.55f + len * 0.35f)
        val ctrl = Offset(top.x + cos(ang) * len * 0.5f, top.y + sin(ang) * len * 0.5f - len * 0.1f)
        val leaf = Path().apply {
            moveTo(top.x, top.y)
            quadraticBezierTo(ctrl.x, ctrl.y - 6 * dp, end.x, end.y)
            quadraticBezierTo(ctrl.x, ctrl.y + 6 * dp, top.x, top.y)
            close()
        }
        drawPath(leaf, color)
    }
}

private fun DrawScope.acacia(x: Float, base: Float, h: Float, color0: Color) {
    val color = DecoTint.l(2, color0)
    val dp = 1.dp.toPx()
    drawLine(color, Offset(x, base), Offset(x - h * 0.05f, base - h * 0.6f), 5 * dp)
    drawLine(color, Offset(x - h * 0.04f, base - h * 0.45f), Offset(x + h * 0.25f, base - h * 0.78f), 3.5f * dp)
    drawLine(color, Offset(x - h * 0.05f, base - h * 0.6f), Offset(x - h * 0.3f, base - h * 0.8f), 3.5f * dp)
    drawOval(color, Offset(x - h * 0.6f, base - h * 0.95f), Size(h * 1.2f, h * 0.22f))
    drawOval(color, Offset(x - h * 0.35f, base - h * 1.02f), Size(h * 0.8f, h * 0.14f))
}

private fun DrawScope.birds(t: Float, y: Float, color0: Color, n: Int, speed: Float) {
    val color = DecoTint.l(2, color0)
    val dp = 1.dp.toPx()
    for (i in 0 until n) {
        val x = wrapF(hs(i, 1) * size.width + t * speed * dp * (0.8f + hs(i, 2) * 0.4f), size.width + 60 * dp) - 30 * dp
        val yy = y + hs(i, 3) * 40 * dp + sin(t * 0.6f + i) * 6 * dp
        val s = (4 + hs(i, 4) * 4) * dp
        val flap = sin(t * 6f + i * 1.7f) * s * 0.5f
        drawLine(color, Offset(x - s, yy - flap), Offset(x, yy), 1.3f * dp)
        drawLine(color, Offset(x, yy), Offset(x + s, yy - flap), 1.3f * dp)
    }
}

/** Assombrit légèrement l'image pour que le texte reste lisible. */
private fun DrawScope.scrim(a: Float) = drawRect(Color.Black.copy(alpha = a))

fun DrawScope.drawLandscape(deco: Deco, t: Float) {
    val w = size.width
    val h = size.height
    val dp = 1.dp.toPx()
    when (deco) {
        Deco.MOUNTAINS -> {
            sky(0f to Color(0xFF1B2A4A), 0.35f to Color(0xFF5E5486), 0.55f to Color(0xFFE79A7C), 0.66f to Color(0xFFFFD6A0))
            val sun = Offset(w * 0.68f, h * (0.6f - 0.01f * sin(t * 0.05f)))
            glowAt(sun, w * 0.9f, Color(0xFFFFE0B2).copy(alpha = 0.45f))
            drawCircle(L1(Color(0xFFFFF3D6)), w * 0.05f, sun)
            starsField(40, 0.3f, t, 0.5f)
            ridge(11, h * 0.6f, h * 0.2f, Color(0xFF8A7BA6), 1.3f, sharp = true)
            mist(h * 0.6f, h * 0.06f, Color(0xFFFFE6D0).copy(alpha = 0.25f), t, 6f, 1)
            ridge(12, h * 0.68f, h * 0.17f, Color(0xFF5A5482), 1.6f, sharp = true)
            mist(h * 0.69f, h * 0.07f, Color(0xFFD9C6E0).copy(alpha = 0.22f), t, 9f, 2)
            ridge(13, h * 0.77f, h * 0.14f, Color(0xFF363660), 2f, sharp = true)
            mist(h * 0.79f, h * 0.06f, Color(0xFFB8A9D0).copy(alpha = 0.18f), t, 12f, 3)
            ridge(14, h * 0.87f, h * 0.11f, Color(0xFF1E2140), 2.4f)
            ridge(15, h * 0.97f, h * 0.09f, Color(0xFF0D1024), 3f)
            for (i in 0 until 9) pine(w * (0.03f + i * 0.11f + hs(i, 1) * 0.05f), h * (0.98f + hs(i, 2) * 0.02f), h * (0.08f + hs(i, 3) * 0.06f), Color(0xFF070A18))
            birds(t, h * 0.3f, Color(0xFF2A2440).copy(alpha = 0.7f), 5, 14f)
            scrim(0.18f)
        }

        Deco.SEASCAPE -> {
            val horizon = h * 0.58f
            sky(0f to Color(0xFF221634), 0.25f to Color(0xFF6D2E58), 0.45f to Color(0xFFE0604A), 0.58f to Color(0xFFFFC56E))
            for (i in 0 until 6) {
                val y = h * (0.18f + i * 0.06f)
                val x = wrapF(hs(i, 1) * w + t * (4 + i) * dp, w * 1.6f) - w * 0.3f
                drawRoundRect(L0(Color(0xFFFFB199)).copy(alpha = 0.18f), Offset(x, y), Size(w * (0.3f + hs(i, 2) * 0.4f), 3 * dp + hs(i, 3) * 5 * dp), CornerRadius(4 * dp))
            }
            val sun = Offset(w * 0.5f, horizon - w * 0.03f)
            glowAt(sun, w * 0.8f, Color(0xFFFFD08A).copy(alpha = 0.5f))
            drawCircle(L1(Color(0xFFFFE7B0)), w * 0.075f, sun)
            drawRect(Brush.verticalGradient(listOf(L3(Color(0xFF4A2C4E)), L3(Color(0xFF1A1630)), L3(Color(0xFF070A18))), startY = horizon, endY = h), Offset(0f, horizon), Size(w, h - horizon))
            shimmer(w * 0.5f, horizon + 2 * dp, h * 0.95f, w * 0.35f, Color(0xFFFFD08A), t, 90)
            for (i in 0 until 14) {
                val y = horizon + (h - horizon) * (i / 14f).let { it * it } + 6 * dp
                val off = sin(t * 0.6f + i) * 20 * dp
                drawLine(L3(Color(0xFF8A6FA0)).copy(alpha = 0.10f), Offset(off - 20 * dp, y), Offset(w + off, y), dp)
            }
            birds(t, h * 0.25f, Color(0xFF1A0E20).copy(alpha = 0.7f), 4, 10f)
            scrim(0.15f)
        }

        Deco.FOREST -> {
            sky(0f to Color(0xFF15211F), 0.45f to Color(0xFF3F5A52), 0.62f to Color(0xFF7C9A8C), 1f to Color(0xFF2A3A34))
            // Rayons de lumière entre les arbres
            for (k in 0 until 5) {
                val a = 0.05f + 0.03f * sin(t * 0.4f + k)
                val x0 = w * (0.1f + k * 0.18f)
                val p = Path().apply {
                    moveTo(x0, 0f); lineTo(x0 + w * 0.06f, 0f)
                    lineTo(x0 + w * 0.45f, h); lineTo(x0 + w * 0.3f, h); close()
                }
                drawPath(p, Brush.verticalGradient(listOf(L1(Color(0xFFFFF4C9)).copy(alpha = a), Color.Transparent)))
            }
            val layers = listOf(Color(0xFF6B887C), Color(0xFF4C6A5E), Color(0xFF314B42), Color(0xFF1C2E28), Color(0xFF0A1410)).map { L2(it) }
            layers.forEachIndexed { li, col ->
                val base = h * (0.62f + li * 0.09f)
                val th = h * (0.16f + li * 0.05f)
                val n = 9 + li * 3
                for (i in 0 until n) pine(w * (i + hs(i, li + 1) * 0.8f) / (n - 1), base + hs(i, li + 5) * 10 * dp, th * (0.7f + hs(i, li + 9) * 0.5f), col)
                drawRect(col, Offset(0f, base), Size(w, h - base))
                mist(base - th * 0.2f, th * 0.5f, Color(0xFFD0DCD4).copy(alpha = 0.16f - li * 0.025f), t, 5f + li * 3, li + 20)
            }
            // Poussières dans la lumière
            for (i in 0 until 30) {
                val x = wrapF(hs(i, 1) * w + t * (3 + hs(i, 2) * 6) * dp, w)
                val y = h * (0.1f + hs(i, 3) * 0.6f) + sin(t * 0.5f + i) * 8 * dp
                drawCircle(L1(Color(0xFFFFF4C9)).copy(alpha = 0.15f + 0.2f * abs(sin(t + i))), (1 + hs(i, 4) * 1.5f) * dp, Offset(x, y))
            }
            scrim(0.12f)
        }

        Deco.CITY -> {
            val water = h * 0.8f
            sky(0f to Color(0xFF03050C), 0.55f to Color(0xFF151B36), 0.75f to Color(0xFF3E2A4E), 0.8f to Color(0xFF6A3A50))
            starsField(60, 0.45f, t, 0.6f)
            drawCircle(L1(Color(0xFFF4F1E6)).copy(alpha = 0.9f), w * 0.04f, Offset(w * 0.8f, h * 0.14f))
            glowAt(Offset(w * 0.8f, h * 0.14f), w * 0.25f, Color(0xFFF4F1E6).copy(alpha = 0.15f))
            for (layer in 0 until 2) {
                val col = L2(if (layer == 0) Color(0xFF1A2038) else Color(0xFF0A0D1A))
                var x = -10 * dp
                var i = layer * 100
                while (x < w) {
                    val bw = (24 + hs(i, 1) * 40) * dp
                    val bh = h * (if (layer == 0) 0.18f + hs(i, 2) * 0.22f else 0.08f + hs(i, 2) * 0.2f)
                    drawRect(col, Offset(x, water - bh), Size(bw - 2 * dp, bh))
                    if (hs(i, 6) > 0.7f) drawRect(col, Offset(x + bw * 0.4f, water - bh - 12 * dp), Size(2 * dp, 12 * dp))
                    // Fenêtres allumées (certaines s'allument et s'éteignent doucement)
                    val cols = ((bw - 8 * dp) / (7 * dp)).toInt()
                    val rows = ((bh - 10 * dp) / (9 * dp)).toInt()
                    for (r in 0 until rows) for (c in 0 until cols) {
                        val k = i * 1000 + r * 50 + c
                        if (hs(k, 3) > (if (layer == 0) 0.75f else 0.62f)) {
                            val on = if (hs(k, 4) > 0.9f) (0.5f + 0.5f * sin(t * 0.3f + k)) else 1f
                            val wc = L1(if (hs(k, 5) > 0.8f) Color(0xFF9FD8FF) else Color(0xFFFFD27A))
                            drawRect(wc.copy(alpha = (if (layer == 0) 0.35f else 0.75f) * on), Offset(x + 4 * dp + c * 7 * dp, water - bh + 6 * dp + r * 9 * dp), Size(3 * dp, 4 * dp))
                        }
                    }
                    x += bw
                    i++
                }
            }
            drawRect(Brush.verticalGradient(listOf(L3(Color(0xFF15182A)), L3(Color(0xFF05060C))), startY = water, endY = h), Offset(0f, water), Size(w, h - water))
            // Reflets des lumières dans l'eau
            for (i in 0 until 70) {
                val x = hs(i, 1) * w
                val y = water + (h - water) * hs(i, 2)
                val len = (6 + hs(i, 3) * 20) * dp
                val a = 0.1f + 0.35f * abs(sin(t * (1 + hs(i, 4) * 2) + i))
                drawLine(L1(if (i % 5 == 0) Color(0xFF9FD8FF) else Color(0xFFFFD27A)).copy(alpha = a), Offset(x - len / 2 + sin(t + i) * 3 * dp, y), Offset(x + len / 2, y), 1.5f * dp)
            }
            scrim(0.08f)
        }

        Deco.STARRY_DESERT -> {
            sky(0f to Color(0xFF02030A), 0.6f to Color(0xFF0C1232), 0.78f to Color(0xFF2E2140))
            // Voie lactée : bande diagonale de poussière d'étoiles
            rotate(-28f, Offset(w * 0.5f, h * 0.35f)) {
                drawOval(Brush.radialGradient(listOf(L1(Color(0xFFB9A8E0)).copy(alpha = 0.18f), Color.Transparent), center = Offset(w * 0.5f, h * 0.35f), radius = w * 0.9f),
                    Offset(-w * 0.4f, h * 0.27f), Size(w * 1.8f, h * 0.16f))
                for (i in 0 until 260) {
                    val x = -w * 0.4f + hs(i, 11) * w * 1.8f
                    val y = h * 0.35f + (hs(i, 12) - 0.5f) * h * 0.16f * (0.4f + hs(i, 13))
                    drawCircle(Color.White.copy(alpha = 0.15f + 0.4f * hs(i, 14) * abs(sin(t * 0.7f + i))), (0.4f + hs(i, 15)) * dp, Offset(x, y))
                }
            }
            starsField(160, 0.75f, t, 0.9f, 3)
            shootingStar(t, 7f, 0.6f)
            ridge(31, h * 0.8f, h * 0.08f, Color(0xFF2A1E2E), 0.8f)
            ridge(32, h * 0.88f, h * 0.07f, Color(0xFF1A121E), 1f)
            ridge(33, h * 0.96f, h * 0.06f, Color(0xFF0B070E), 1.2f)
        }

        Deco.LAKE_AURORA -> {
            val lake = h * 0.68f
            sky(0f to Color(0xFF020814), 0.68f to Color(0xFF0B1B2E))
            starsField(120, 0.6f, t, 0.8f, 5)
            // Rideaux d'aurore qui ondulent
            fun aurora(mirror: Boolean, alphaMul: Float) {
                val step = 5 * dp
                var x = 0f
                var i = 0
                while (x < w) {
                    val wave = sin(x / w * 6f + t * 0.35f) * 0.5f + sin(x / w * 13f - t * 0.5f) * 0.25f
                    val top = h * (0.12f + 0.1f * wave)
                    val bottom = h * (0.42f + 0.06f * sin(x / w * 4f + t * 0.25f))
                    val a = (0.10f + 0.12f * (0.5f + 0.5f * sin(x / w * 20f + t * 1.1f))) * alphaMul
                    val y0 = if (mirror) 2 * lake - bottom else top
                    val y1 = if (mirror) 2 * lake - top else bottom
                    drawLine(
                        Brush.verticalGradient(
                            if (mirror) listOf(L1(Color(0xFF4ADE80)).copy(alpha = a), L1(Color(0xFF8B5CF6)).copy(alpha = a * 0.6f), Color.Transparent)
                            else listOf(Color.Transparent, L1(Color(0xFF8B5CF6)).copy(alpha = a * 0.6f), L1(Color(0xFF4ADE80)).copy(alpha = a)),
                            startY = y0, endY = y1,
                        ),
                        Offset(x, y0), Offset(x, y1), step,
                    )
                    x += step
                    i++
                }
            }
            aurora(false, 1f)
            ridge(41, lake, h * 0.1f, Color(0xFF0B1424), 1.4f, sharp = true)
            drawRect(Brush.verticalGradient(listOf(L3(Color(0xFF061020)), L3(Color(0xFF02060E))), startY = lake, endY = h), Offset(0f, lake), Size(w, h - lake))
            aurora(true, 0.45f)
            for (i in 0 until 12) pine(w * (i / 11f) + hs(i, 2) * 10 * dp, lake + 2 * dp, h * (0.06f + hs(i, 3) * 0.08f), Color(0xFF02050A))
            shimmer(w * 0.5f, lake + 4 * dp, h, w, Color(0xFFA7F3D0).copy(alpha = 0.5f), t, 40)
        }

        Deco.TROPICAL -> {
            val horizon = h * 0.6f
            sky(0f to Color(0xFF2E1640), 0.35f to Color(0xFFC2456A), 0.55f to Color(0xFFFFA45C), 0.6f to Color(0xFFFFD08A))
            val sun = Offset(w * 0.4f, horizon - w * 0.04f)
            glowAt(sun, w * 0.7f, Color(0xFFFFC870).copy(alpha = 0.5f))
            drawCircle(L1(Color(0xFFFFE3A3)), w * 0.08f, sun)
            drawRect(Brush.verticalGradient(listOf(L3(Color(0xFF1E5A6A)), L3(Color(0xFF0A2A36))), startY = horizon, endY = h), Offset(0f, horizon), Size(w, h - horizon))
            shimmer(sun.x, horizon + 2 * dp, h * 0.85f, w * 0.3f, Color(0xFFFFD08A), t, 60)
            // Vagues qui viennent mourir sur la plage
            for (k in 0 until 3) {
                val p = wrapF(t * 0.12f + k / 3f, 1f)
                val y = h * (0.8f + p * 0.08f)
                drawLine(Color.White.copy(alpha = 0.25f * (1f - p)), Offset(0f, y), Offset(w, y + 10 * dp), 2 * dp)
            }
            val sand = Path().apply {
                moveTo(0f, h * 0.86f); quadraticBezierTo(w * 0.5f, h * 0.82f, w, h * 0.9f); lineTo(w, h); lineTo(0f, h); close()
            }
            drawPath(sand, L2(Color(0xFF1A1008)))
            palm(w * 0.12f, h * 0.9f, h * 0.38f, 0.25f, Color(0xFF0C0806), t)
            palm(w * 0.88f, h * 0.93f, h * 0.3f, -0.3f, Color(0xFF0C0806), t + 1f)
            birds(t, h * 0.2f, Color(0xFF2A1020).copy(alpha = 0.7f), 4, 12f)
            scrim(0.12f)
        }

        Deco.SAVANNA -> {
            val ground = h * 0.74f
            sky(0f to Color(0xFF2A1406), 0.4f to Color(0xFFB4462A), 0.6f to Color(0xFFFF9A3C), 0.74f to Color(0xFFFFD27A))
            val sun = Offset(w * 0.55f, ground - w * 0.02f)
            glowAt(sun, w, Color(0xFFFFC060).copy(alpha = 0.5f))
            drawCircle(L1(Color(0xFFFFE4A0)), w * 0.2f, sun)
            ridge(51, ground + 4 * dp, h * 0.03f, Color(0xFF6A2E14), 0.6f)
            ridge(52, ground + 14 * dp, h * 0.025f, Color(0xFF1A0C05), 0.9f)
            acacia(w * 0.22f, ground + 12 * dp, h * 0.22f, Color(0xFF1A0C05))
            acacia(w * 0.78f, ground + 16 * dp, h * 0.15f, Color(0xFF1A0C05))
            acacia(w * 0.95f, ground + 10 * dp, h * 0.08f, Color(0xFF3A1A0A))
            birds(t, h * 0.28f, Color(0xFF2A1006).copy(alpha = 0.8f), 7, 16f)
            // Chaleur qui fait trembler l'air au ras du sol
            for (i in 0 until 6) {
                val y = ground - (4 + i * 4) * dp
                drawLine(L1(Color(0xFFFFE4A0)).copy(alpha = 0.06f), Offset(0f, y + sin(t * 2f + i) * 2 * dp), Offset(w, y - sin(t * 2f + i) * 2 * dp), 2 * dp)
            }
            scrim(0.16f)
        }

        Deco.LAVENDER -> {
            val horizon = h * 0.55f
            sky(0f to Color(0xFF221E48), 0.3f to Color(0xFF7A4E92), 0.48f to Color(0xFFF0A066), 0.55f to Color(0xFFFFD6A6))
            glowAt(Offset(w * 0.3f, horizon), w * 0.7f, Color(0xFFFFD6A6).copy(alpha = 0.45f))
            ridge(61, horizon + 2 * dp, h * 0.05f, Color(0xFF6A5A92), 1.2f)
            ridge(62, horizon + 10 * dp, h * 0.03f, Color(0xFF4A3E72), 1.6f)
            drawRect(Brush.verticalGradient(listOf(L3(Color(0xFF4A3270)), L3(Color(0xFF221436))), startY = horizon + 10 * dp, endY = h), Offset(0f, horizon + 8 * dp), Size(w, h))
            // Rangs de lavande en perspective, qui ondulent au vent
            val vp = Offset(w * 0.5f, horizon)
            for (k in -14..14) {
                val bx = w * 0.5f + k * w * 0.14f
                val p = Path()
                p.moveTo(vp.x + k * w * 0.012f, vp.y + 10 * dp)
                val sway = sin(t * 0.8f + k) * 4 * dp
                p.quadraticBezierTo((vp.x + bx) / 2 + sway, (vp.y + h) / 2, bx - w * 0.03f, h)
                p.lineTo(bx + w * 0.03f, h)
                p.quadraticBezierTo((vp.x + bx) / 2 + sway + 2 * dp, (vp.y + h) / 2, vp.x + k * w * 0.012f + 1 * dp, vp.y + 10 * dp)
                p.close()
                drawPath(p, Brush.verticalGradient(listOf(L3(Color(0xFF8A6CC0)), L3(Color(0xFF6A3FA8)), L3(Color(0xFF3A1E6A))), startY = horizon, endY = h))
            }
            // Arbre isolé
            val tx = w * 0.72f
            drawLine(L2(Color(0xFF1A1020)), Offset(tx, horizon + 14 * dp), Offset(tx, horizon - 20 * dp), 4 * dp)
            drawCircle(L2(Color(0xFF1A1020)), 22 * dp, Offset(tx, horizon - 30 * dp))
            drawCircle(L2(Color(0xFF1A1020)), 16 * dp, Offset(tx - 16 * dp, horizon - 22 * dp))
            drawCircle(L2(Color(0xFF1A1020)), 16 * dp, Offset(tx + 16 * dp, horizon - 24 * dp))
            // Abeilles et pollen
            for (i in 0 until 20) {
                val x = wrapF(hs(i, 1) * w + sin(t * 0.7f + i) * 30 * dp + t * 5 * dp, w)
                val y = horizon + (h - horizon) * (0.2f + hs(i, 2) * 0.7f) + cos(t + i) * 8 * dp
                drawCircle(L1(Color(0xFFFFE0A0)).copy(alpha = 0.35f), 1.5f * dp, Offset(x, y))
            }
            scrim(0.16f)
        }

        Deco.RIVIERA -> {
            val sea = h * 0.6f
            sky(0f to Color(0xFF0C1836), 0.3f to Color(0xFF34548A), 0.5f to Color(0xFFE59A72), 0.6f to Color(0xFFFFC98E))
            starsField(25, 0.25f, t, 0.5f, 9)
            glowAt(Offset(w * 0.2f, sea), w * 0.6f, Color(0xFFFFC98E).copy(alpha = 0.35f))
            // Montagnes qui plongent dans la mer, cap boisé à droite
            ridge(71, sea + 2 * dp, h * 0.16f, Color(0xFF3B4A78), 1.2f, sharp = true)
            val cape = Path().apply {
                moveTo(w * 0.45f, sea + 2 * dp)
                quadraticBezierTo(w * 0.7f, sea - h * 0.05f, w * 0.8f, sea - h * 0.16f)
                quadraticBezierTo(w * 0.9f, sea - h * 0.24f, w, sea - h * 0.22f)
                lineTo(w, sea + 2 * dp); close()
            }
            drawPath(cape, L2(Color(0xFF1A2440)))
            // Lumières du village sur la colline
            for (i in 0 until 40) {
                val fx = 0.62f + hs(i, 1) * 0.36f
                val top = sea - h * (0.02f + (fx - 0.62f) / 0.36f * 0.18f)
                val y = top + hs(i, 2) * (sea - top)
                val a = 0.5f + 0.5f * abs(sin(t * (0.3f + hs(i, 3)) + i))
                drawCircle(L1(Color(0xFFFFD27A)).copy(alpha = 0.7f * a), (1 + hs(i, 4)) * dp, Offset(w * fx, y))
            }
            drawRect(Brush.verticalGradient(listOf(L3(Color(0xFF2A3E6A)), L3(Color(0xFF0A1A34)), L3(Color(0xFF040A18))), startY = sea, endY = h), Offset(0f, sea), Size(w, h - sea))
            shimmer(w * 0.25f, sea + 2 * dp, h * 0.9f, w * 0.4f, Color(0xFFFFC98E), t, 70)
            shimmer(w * 0.8f, sea + 2 * dp, h * 0.75f, w * 0.25f, Color(0xFFFFD27A).copy(alpha = 0.6f), t + 3f, 30)
            // Un bateau qui glisse au loin
            val bx = wrapF(t * 6 * dp, w + 40 * dp) - 20 * dp
            drawRect(L2(Color(0xFF0A0F1E)), Offset(bx, sea + 10 * dp), Size(16 * dp, 3 * dp))
            drawCircle(Color(0xFFFFE4A0), 1.5f * dp, Offset(bx + 12 * dp, sea + 9 * dp))
            scrim(0.14f)
        }

        else -> Unit
    }
}

// ------------------------------------------------------------------ Décors inspirés d'autres cultures

fun DrawScope.drawCulture(deco: Deco, cs: ColorScheme, bg: Color, t: Float) {
    val w = size.width
    val h = size.height
    val dp = 1.dp.toPx()
    val light = (bg.red + bg.green + bg.blue) / 3f > 0.5f
    when (deco) {
        // Japon : vagues seigaiha qui défilent, pétales qui tombent
        Deco.SEIGAIHA -> {
            val r = 26 * dp
            val col = cs.primary.copy(alpha = if (light) 0.10f else 0.14f)
            val col2 = cs.secondary.copy(alpha = if (light) 0.08f else 0.12f)
            val shift = wrapF(t * 4 * dp, 2 * r)
            var row = 0
            var y = h * 0.62f
            while (y < h + r) {
                val off = if (row % 2 == 0) 0f else r
                var x = -2 * r + off + shift
                while (x < w + 2 * r) {
                    for (k in 0 until 4) drawArc(if (k % 2 == 0) col else col2, 180f, 180f, false, Offset(x - r + k * r * 0.22f, y - r + k * r * 0.22f), Size(2 * r - k * r * 0.44f, 2 * r - k * r * 0.44f), style = Stroke(1.5f * dp))
                    x += 2 * r
                }
                y += r * 0.55f
                row++
            }
            drawRect(Brush.verticalGradient(listOf(bg, bg.copy(alpha = 0f)), startY = h * 0.55f, endY = h * 0.75f))
            for (i in 0 until 26) {
                val speed = (18 + hs(i, 4) * 26) * dp
                val yy = wrapF(hs(i, 2) * h + t * speed, h + 20 * dp) - 10 * dp
                val xx = wrapF(hs(i, 1) * w + sin(t * 0.8f + i) * 24 * dp + t * 8 * dp, w)
                rotate(t * 60f + i * 40f, Offset(xx, yy)) {
                    drawOval(DecoTint.exact(3, Color(0xFFF4A7B9)).copy(alpha = 0.55f), Offset(xx - 4 * dp, yy - 2.5f * dp), Size(8 * dp, 5 * dp))
                }
            }
            drawCircle(cs.primary.copy(alpha = 0.12f), w * 0.18f, Offset(w * 0.78f, h * 0.18f))
        }

        // Chine : lanternes rouges qui montent doucement
        Deco.LANTERNS -> {
            drawRect(Brush.radialGradient(listOf(DecoTint.exact(1, Color(0xFFFF6B3D)).copy(alpha = 0.10f), Color.Transparent), center = Offset(w * 0.5f, h), radius = h))
            for (i in 0 until 16) {
                val speed = (10 + hs(i, 4) * 14) * dp
                val y = h - wrapF(hs(i, 2) * h + t * speed, h + 120 * dp) + 60 * dp
                val x = hs(i, 1) * w + sin(t * 0.5f + i) * 16 * dp
                val s = (16 + hs(i, 5) * 18) * dp * (if (i % 3 == 0) 1.4f else 1f)
                val flick = 0.85f + 0.15f * sin(t * 6f + i * 2f)
                glowAt(Offset(x, y), s * 2.2f, DecoTint.exact(1, Color(0xFFFF8A3D)).copy(alpha = 0.25f * flick))
                drawOval(DecoTint.exact(0, Color(0xFFD62828)).copy(alpha = 0.85f), Offset(x - s * 0.6f, y - s * 0.5f), Size(s * 1.2f, s))
                drawOval(DecoTint.exact(1, Color(0xFFFF9A3C)).copy(alpha = 0.5f * flick), Offset(x - s * 0.35f, y - s * 0.35f), Size(s * 0.7f, s * 0.7f))
                drawRect(DecoTint.exact(3, Color(0xFFF4C430)), Offset(x - s * 0.3f, y - s * 0.6f), Size(s * 0.6f, s * 0.12f))
                drawRect(DecoTint.exact(3, Color(0xFFF4C430)), Offset(x - s * 0.3f, y + s * 0.48f), Size(s * 0.6f, s * 0.12f))
                drawLine(DecoTint.exact(3, Color(0xFFF4C430)).copy(alpha = 0.8f), Offset(x, y + s * 0.6f), Offset(x + sin(t + i) * 2 * dp, y + s), dp)
            }
        }

        // Inde : grand mandala qui tourne lentement, petites lumières dorées
        Deco.MANDALA -> {
            val c = Offset(w * 0.5f, h * 0.42f)
            val R = min(w, h) * 0.55f
            rotate(t * 4f, c) {
                for (ring in 0 until 6) {
                    val rr = R * (0.18f + ring * 0.15f)
                    val n = 8 + ring * 4
                    val col = listOf(cs.primary, cs.secondary, cs.tertiary)[ring % 3].copy(alpha = if (light) 0.10f else 0.14f)
                    for (k in 0 until n) {
                        val a = k * 360f / n + (if (ring % 2 == 0) 0f else 180f / n)
                        rotate(a, c) {
                            drawOval(col, Offset(c.x - rr * 0.12f, c.y - rr - rr * 0.18f), Size(rr * 0.24f, rr * 0.36f))
                            drawCircle(col, rr * 0.03f, Offset(c.x, c.y - rr * 1.25f))
                        }
                    }
                    drawCircle(col, rr, c, style = Stroke(dp))
                }
            }
            for (i in 0 until 30) {
                val x = hs(i, 1) * w
                val y = h - wrapF(hs(i, 2) * h + t * (8 + hs(i, 3) * 10) * dp, h)
                drawCircle(DecoTint.exact(3, Color(0xFFFFC14D)).copy(alpha = 0.25f + 0.35f * abs(sin(t * 2 + i))), (1.5f + hs(i, 4) * 2f) * dp, Offset(x, y))
            }
        }

        // Maroc : étoiles de zellige et reflet de lumière qui passe
        Deco.ZELLIGE -> {
            val cell = 54 * dp
            val cols = listOf(cs.primary, cs.secondary, cs.tertiary)
            var gy = 0f
            var row = 0
            while (gy < h + cell) {
                var gx = if (row % 2 == 0) 0f else cell / 2
                var col = 0
                while (gx < w + cell) {
                    val c = Offset(gx, gy)
                    val color = cols[(row + col) % 3].copy(alpha = if (light) 0.09f else 0.12f)
                    val s = cell * 0.3f
                    drawRect(color, Offset(c.x - s, c.y - s), Size(2 * s, 2 * s), style = Stroke(1.5f * dp))
                    rotate(45f, c) { drawRect(color, Offset(c.x - s, c.y - s), Size(2 * s, 2 * s), style = Stroke(1.5f * dp)) }
                    drawCircle(color, s * 0.3f, c)
                    gx += cell
                    col++
                }
                gy += cell * 0.86f
                row++
            }
            // Lumière qui balaie la mosaïque
            val sweep = wrapF(t * 0.08f, 1.6f) - 0.3f
            rotate(25f, center) {
                drawRect(Brush.horizontalGradient(listOf(Color.Transparent, DecoTint.exact(3, Color.White).copy(alpha = if (light) 0.14f else 0.08f), Color.Transparent), startX = w * sweep - w * 0.15f, endX = w * sweep + w * 0.15f), Offset(-w, -h), Size(w * 3, h * 3))
            }
        }

        // Mexique : guirlandes de papel picado qui se balancent, pétales de fleurs orange
        Deco.PAPEL -> {
            val allFlags: List<Color> = listOf(DecoTint.exact(0, Color(0xFFE91E63)), DecoTint.exact(1, Color(0xFFFF9800)), DecoTint.exact(2, Color(0xFF00ACC1)), Color(0xFF8BC34A), Color(0xFF9C27B0), Color(0xFFFFEB3B))
            // Couleurs choisies : les fanions n'utilisent plus qu'elles
            val flagCols: List<Color> = if (DecoTint.has(0) || DecoTint.has(1) || DecoTint.has(2)) allFlags.take(3) else allFlags
            for (line in 0 until 3) {
                val y0 = h * (0.06f + line * 0.11f)
                val n = 9
                val fw = w / n
                drawLine(Color(0xFF6D4C41).copy(alpha = 0.5f), Offset(0f, y0), Offset(w, y0 + 6 * dp), dp)
                for (k in 0 until n) {
                    val x = k * fw + fw * 0.08f
                    val sway = sin(t * 1.2f + k + line) * 3f
                    val col = flagCols[(k + line * 2) % flagCols.size].copy(alpha = if (light) 0.55f else 0.45f)
                    rotate(sway, Offset(x + fw * 0.42f, y0)) {
                        val p = Path().apply {
                            moveTo(x, y0); lineTo(x + fw * 0.84f, y0); lineTo(x + fw * 0.84f, y0 + fw * 0.7f)
                            for (z in 4 downTo 0) lineTo(x + fw * 0.84f * z / 4f, y0 + fw * (if (z % 2 == 0) 0.7f else 0.82f))
                            close()
                        }
                        drawPath(p, col)
                        drawCircle(bg.copy(alpha = 0.6f), fw * 0.1f, Offset(x + fw * 0.42f, y0 + fw * 0.32f))
                        drawRect(bg.copy(alpha = 0.6f), Offset(x + fw * 0.15f, y0 + fw * 0.5f), Size(fw * 0.1f, fw * 0.08f))
                        drawRect(bg.copy(alpha = 0.6f), Offset(x + fw * 0.6f, y0 + fw * 0.5f), Size(fw * 0.1f, fw * 0.08f))
                    }
                }
            }
            for (i in 0 until 30) {
                val y = wrapF(hs(i, 2) * h + t * (20 + hs(i, 4) * 30) * dp, h)
                val x = wrapF(hs(i, 1) * w + sin(t + i) * 20 * dp, w)
                drawCircle(DecoTint.exact(3, Color(0xFFFF9800)).copy(alpha = 0.5f), (2 + hs(i, 5) * 2) * dp, Offset(x, y))
            }
        }

        // Grèce : frises à la grecque, mer qui scintille
        Deco.MEANDER -> {
            val col = cs.primary.copy(alpha = if (light) 0.22f else 0.3f)
            fun frieze(y: Float) {
                val u = 10 * dp
                val shift = wrapF(t * 6 * dp, 4 * u)
                var x = -4 * u + shift
                val p = Path()
                p.moveTo(x, y + 3 * u)
                while (x < w + 4 * u) {
                    p.lineTo(x, y); p.lineTo(x + 3 * u, y); p.lineTo(x + 3 * u, y + 2 * u)
                    p.lineTo(x + u, y + 2 * u); p.lineTo(x + u, y + u); p.lineTo(x + 2 * u, y + u)
                    p.moveTo(x + 4 * u, y + 3 * u)
                    p.lineTo(x, y + 3 * u)
                    p.moveTo(x + 4 * u, y + 3 * u)
                    x += 4 * u
                }
                drawPath(p, col, style = Stroke(2 * dp))
            }
            frieze(14 * dp)
            frieze(h - 44 * dp)
            for (i in 0 until 50) {
                val y = h * (0.55f + hs(i, 1) * 0.35f)
                val x = hs(i, 2) * w + sin(t * 0.5f + i) * 10 * dp
                val len = (10 + hs(i, 3) * 30) * dp
                drawLine(cs.primary.copy(alpha = 0.06f + 0.1f * abs(sin(t + i))), Offset(x, y), Offset(x + len, y), 2 * dp)
            }
            glowAt(Offset(w * 0.85f, h * 0.15f), w * 0.4f, cs.secondary.copy(alpha = 0.15f))
        }

        else -> Unit
    }
}

/** Décors « paysage » (peints, avec leurs propres couleurs). */
val LANDSCAPE_DECOS = setOf(
    Deco.MOUNTAINS, Deco.SEASCAPE, Deco.FOREST, Deco.CITY, Deco.STARRY_DESERT, Deco.LAKE_AURORA,
    Deco.TROPICAL, Deco.SAVANNA, Deco.LAVENDER, Deco.RIVIERA,
)

/** Décors inspirés d'autres cultures. */
val CULTURE_DECOS = setOf(Deco.SEIGAIHA, Deco.LANTERNS, Deco.MANDALA, Deco.ZELLIGE, Deco.PAPEL, Deco.MEANDER)

private fun L0(c: Color) = DecoTint.l(0, c)
private fun L1(c: Color) = DecoTint.l(1, c)
private fun L2(c: Color) = DecoTint.l(2, c)
private fun L3(c: Color) = DecoTint.l(3, c)
