package fr.jeremy.calepin.ui

import android.Manifest
import android.content.Context
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.EditNote
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import fr.jeremy.calepin.BuildConfig

object Onboarding {
    private fun prefs(ctx: Context) = ctx.getSharedPreferences("calepin", Context.MODE_PRIVATE)

    /**
     * À appeler au tout début de l'activité, avant de charger les notes :
     * une appli déjà utilisée avant cette version ne revoit pas la présentation.
     */
    fun prepare(ctx: Context) {
        val p = prefs(ctx)
        if (!p.getBoolean("onboarded", false) && p.getBoolean("seeded", false) && !p.getBoolean("onboarding_replay", false)) markDone(ctx)
    }

    fun done(ctx: Context): Boolean = prefs(ctx).getBoolean("onboarded", false)

    fun markDone(ctx: Context) = prefs(ctx).edit().putBoolean("onboarded", true).putBoolean("onboarding_replay", false).apply()

    /** Revoir la présentation au prochain lancement. */
    fun reset(ctx: Context) = prefs(ctx).edit().putBoolean("onboarded", false).putBoolean("onboarding_replay", true).apply()
}

private class Page(val icon: ImageVector, val title: String, val text: String)

/** Présentation en trois écrans au premier lancement ; les autorisations sont demandées au bon moment. */
@Composable
fun OnboardingScreen(onFinish: () -> Unit) {
    var page by remember { mutableIntStateOf(0) }
    val notif = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { onFinish() }
    val pages = listOf(
        Page(
            Icons.Filled.EditNote, "Bienvenue dans Calepin",
            "Tes notes, listes, photos et mémos vocaux au même endroit. Adresses, numéros, dates et e-mails sont reconnus tout seuls : " +
                "un appui pour appeler, ouvrir l'itinéraire ou créer un rappel.",
        ),
        Page(
            Icons.Filled.AutoAwesome, if (BuildConfig.AI) "Une IA qui reste sur ton téléphone" else "Un assistant à la voix",
            if (BuildConfig.AI) "Résumés, comptes rendus, traductions, questions sur tes notes, commande de la télé et de la maison… " +
                "Le modèle d'IA se télécharge seulement si tu le choisis, puis fonctionne sans Internet."
            else "« Qu'est-ce que j'ai demain ? », « note que… », « rappelle-moi à 9h de… » : parle à Calepin. " +
                "Ajoute aussi les widgets sur l'écran d'accueil du téléphone.",
        ),
        Page(
            Icons.Filled.Lock, "Tes données restent chez toi",
            "Pas de compte, pas de publicité, pas de serveur : tout est enregistré sur le téléphone. " +
                "Tu peux verrouiller l'appli et faire une sauvegarde chiffrée dans Paramètres.",
        ),
    )
    Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
        Column(
            Modifier.fillMaxSize().systemBarsPadding().padding(28.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                if (page < pages.lastIndex) TextButton(onClick = onFinish) { Text("Passer") }
            }
            Spacer(Modifier.weight(1f))
            AnimatedContent(targetState = page, label = "page") { i ->
                val p = pages[i]
                Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(18.dp)) {
                    Box(Modifier.size(120.dp).clip(CircleShape).background(MaterialTheme.colorScheme.primaryContainer), contentAlignment = Alignment.Center) {
                        Icon(p.icon, null, Modifier.size(60.dp), tint = MaterialTheme.colorScheme.onPrimaryContainer)
                    }
                    Text(p.title, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.SemiBold, textAlign = TextAlign.Center)
                    Text(p.text, style = MaterialTheme.typography.bodyLarge, textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
            Spacer(Modifier.weight(1f))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(bottom = 20.dp)) {
                pages.indices.forEach { i ->
                    Box(
                        Modifier.size(if (i == page) 22.dp else 8.dp, 8.dp).clip(CircleShape)
                            .background(if (i == page) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant),
                    )
                }
            }
            Button(
                onClick = {
                    if (page < pages.lastIndex) page++
                    // Les notifications servent aux rappels : demandées à la fin, avec l'explication juste au-dessus
                    else if (Build.VERSION.SDK_INT >= 33) notif.launch(Manifest.permission.POST_NOTIFICATIONS)
                    else onFinish()
                },
                modifier = Modifier.fillMaxWidth().height(52.dp),
            ) { Text(if (page < pages.lastIndex) "Suivant" else "Commencer") }
            if (page == pages.lastIndex) {
                Spacer(Modifier.height(6.dp))
                Text(
                    "Calepin va te demander d'afficher des notifications : elles servent uniquement à tes rappels et alarmes.",
                    style = MaterialTheme.typography.bodySmall, textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            Spacer(Modifier.width(1.dp))
        }
    }
}
