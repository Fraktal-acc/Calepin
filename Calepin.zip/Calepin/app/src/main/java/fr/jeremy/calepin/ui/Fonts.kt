package fr.jeremy.calepin.ui

import android.content.Context
import androidx.compose.ui.text.font.FontFamily
import java.util.concurrent.ConcurrentHashMap

/**
 * Polices d'écriture. Les polices « système » sont toujours là ; les autres (libres, Google Fonts)
 * sont ajoutées à l'appli au moment de la compilation. Si l'une manque, la police classique la remplace.
 * [display] : police décorative, réservée aux titres pour garder le texte lisible.
 */
enum class FontChoice(val label: String, val asset: String? = null, val display: Boolean = false) {
    AUTO("Selon le thème"),
    SANS("Classique"),
    SERIF("Élégante"),
    MONO("Code"),
    CURSIVE("Manuscrite"),
    MACHINE("Machine à écrire", "specialelite.ttf"),
    FUTURISTE("Futuriste", "orbitron.ttf", display = true),
    HOLOGRAMME("Hologramme", "audiowide.ttf", display = true),
    MEDIEVALE("Médiévale", "cinzel.ttf", display = true),
    GOTHIQUE("Gothique", "unifraktur.ttf", display = true),
    HORREUR("Horreur", "creepster.ttf", display = true),
    SANGLANTE("Sanglante", "nosifer.ttf", display = true),
    CONDENSEE("Affiche", "bebasneue.ttf", display = true),
    MANGA("Manga", "bangers.ttf", display = true),
    SAMOURAI("Samouraï", "shojumaru.ttf", display = true),
    MARQUEUR("Marqueur", "permanentmarker.ttf", display = true),
    PIXEL("Pixel rétro", "pressstart2p.ttf", display = true),
    DOUCE("Douce", "pacifico.ttf", display = true),
    CRAYON("Crayon", "caveat.ttf"),
    ;

    fun family(ctx: Context): FontFamily = when (this) {
        AUTO, SANS -> FontFamily.Default
        SERIF -> FontFamily.Serif
        MONO -> FontFamily.Monospace
        CURSIVE -> FontFamily.Cursive
        else -> Fonts.load(ctx, asset!!) ?: FontFamily.Default
    }

    /** Vrai si la police est présente sur ce téléphone (les polices ajoutées peuvent manquer). */
    fun available(ctx: Context) = asset == null || Fonts.load(ctx, asset) != null
}

object Fonts {
    private val cache = ConcurrentHashMap<String, Any>()
    private val MISSING = Any()

    fun load(ctx: Context, asset: String): FontFamily? {
        val hit = cache[asset]
        if (hit === MISSING) return null
        if (hit is FontFamily) return hit
        val ff = runCatching {
            val tf = android.graphics.Typeface.createFromAsset(ctx.applicationContext.assets, "fonts/$asset")
            FontFamily(androidx.compose.ui.text.font.Typeface(tf))
        }.getOrNull()
        cache[asset] = ff ?: MISSING
        return ff
    }
}
