package fr.jeremy.calepin.radio

import android.graphics.BitmapFactory
import android.util.LruCache
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.util.Collections
import java.util.concurrent.TimeUnit

/** Logos des radios : téléchargés une fois, réduits et gardés en mémoire. */
object RadioLogos {
    private val cache = LruCache<String, ImageBitmap>(120)
    private val failed = Collections.synchronizedSet(HashSet<String>())
    private val http by lazy {
        OkHttpClient.Builder().connectTimeout(5, TimeUnit.SECONDS).readTimeout(8, TimeUnit.SECONDS).build()
    }

    fun cached(url: String): ImageBitmap? = if (url.isBlank()) null else cache.get(url)

    suspend fun load(url: String): ImageBitmap? = withContext(Dispatchers.IO) {
        if (!url.startsWith("http") || url in failed) return@withContext null
        cache.get(url)?.let { return@withContext it }
        try {
            val req = Request.Builder().url(url).header("User-Agent", "Calepin/1.0 (Android)").build()
            val bytes = http.newCall(req).execute().use { r ->
                if (!r.isSuccessful) null
                else r.body?.takeIf { (it.contentLength()) <= 2_000_000L }?.bytes()
            } ?: run { failed += url; return@withContext null }
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
            if (bounds.outWidth <= 0) { failed += url; return@withContext null }
            var sample = 1
            while (bounds.outWidth / (sample * 2) >= 128 && bounds.outHeight / (sample * 2) >= 128) sample *= 2
            val bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size, BitmapFactory.Options().apply { inSampleSize = sample })
                ?: run { failed += url; return@withContext null }
            bmp.asImageBitmap().also { cache.put(url, it) }
        } catch (e: Exception) {
            failed += url
            null
        }
    }
}
