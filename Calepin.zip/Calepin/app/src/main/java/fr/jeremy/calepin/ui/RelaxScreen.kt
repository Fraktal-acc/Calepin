package fr.jeremy.calepin.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Radio
import androidx.compose.material.icons.filled.SportsEsports
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp

/** Détente : les jeux et les webradios. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RelaxScreen(onGames: () -> Unit, onRadio: () -> Unit, onClose: () -> Unit) {
    val ctx = LocalContext.current
    BackHandler { onClose() }
    LaunchedEffect(Unit) { fr.jeremy.calepin.radio.RadioPlayer.attach(ctx) }
    Scaffold(
        topBar = {
            TopAppBar(
                title = { FitText("Détente") },
                navigationIcon = { IconButton(onClick = onClose) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Retour") } },
            )
        },
    ) { pad ->
        Column(
            Modifier
                .fillMaxSize()
                .padding(pad)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp)
                .padding(bottom = 40.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            RadioNowPlaying()
            LinkCard("Webradios", Icons.Filled.Radio, "Les radios du monde entier, classées par pays, avec recherche", onRadio)
            LinkCard("Jeux", Icons.Filled.SportsEsports, "Tetris, casse-briques, Snake", onGames)
        }
    }
}
