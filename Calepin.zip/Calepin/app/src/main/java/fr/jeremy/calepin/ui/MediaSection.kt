package fr.jeremy.calepin.ui

import android.app.Activity
import android.content.Intent
import android.graphics.Bitmap
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.rememberTransformableState
import androidx.compose.foundation.gestures.transformable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Draw
import androidx.compose.material.icons.filled.PhotoCamera
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.PlayCircle
import androidx.compose.material.icons.filled.SaveAlt
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material.icons.filled.VerticalAlignBottom
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import fr.jeremy.calepin.i18n.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import fr.jeremy.calepin.Files
import fr.jeremy.calepin.LockGuard
import fr.jeremy.calepin.NotesViewModel
import fr.jeremy.calepin.data.Attachment
import fr.jeremy.calepin.media.Media
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

/** Ajout de photos et vidéos à une note : appareil photo, caméra, galerie, croquis. */
class MediaAdder internal constructor(
    val capture: (video: Boolean) -> Unit,
    val gallery: () -> Unit,
    val sketch: () -> Unit,
    val importing: () -> Boolean,
)

/**
 * Prépare l'ajout de photos et vidéos. [onAdded] reçoit les éléments ajoutés (pour les placer dans le texte).
 * À appeler dans la composition (il garde les lanceurs Android et le dialogue de croquis).
 */
@Composable
fun rememberMediaAdder(vm: NotesViewModel, ensureNote: () -> Long, onAdded: (List<Attachment>) -> Unit): MediaAdder {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var pending by remember { mutableStateOf<File?>(null) }
    var importing by remember { mutableStateOf(false) }
    var sketching by remember { mutableStateOf(false) }
    val latestAdded = androidx.compose.runtime.rememberUpdatedState(onAdded)

    /** Ajoute puis renvoie les nouveaux éléments (comparaison avant / après). */
    fun added(id: Long, before: Set<Long>) {
        val now = vm.attachmentsOf(id).filter { it.id !in before }
        if (now.isNotEmpty()) latestAdded.value(now)
    }

    val takePhoto = rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()) { ok ->
        val f = pending
        pending = null
        if (f != null) {
            if (ok) {
                val id = ensureNote()
                val before = vm.attachmentsOf(id).map { it.id }.toSet()
                vm.addCaptured(id, f, video = false)
                added(id, before)
            } else f.delete()
        }
    }
    val takeVideo = rememberLauncherForActivityResult(ActivityResultContracts.CaptureVideo()) { ok ->
        val f = pending
        pending = null
        if (f != null) {
            if (ok) {
                val id = ensureNote()
                val before = vm.attachmentsOf(id).map { it.id }.toSet()
                vm.addCaptured(id, f, video = true)
                added(id, before)
            } else f.delete()
        }
    }
    val pick = rememberLauncherForActivityResult(ActivityResultContracts.PickMultipleVisualMedia(30)) { uris ->
        if (uris.isNotEmpty()) {
            importing = true
            scope.launch {
                val id = ensureNote()
                val before = vm.attachmentsOf(id).map { it.id }.toSet()
                val n = vm.importMedia(id, uris)
                importing = false
                added(id, before)
                if (n < uris.size) fr.jeremy.calepin.i18n.I18n.toast(ctx, "${uris.size - n} élément(s) n'ont pas pu être importés", Toast.LENGTH_SHORT).show()
            }
        }
    }

    if (sketching) {
        SketchDialog(
            onDismiss = { sketching = false },
            onSave = { bmp ->
                sketching = false
                scope.launch {
                    val f = withContext(Dispatchers.IO) {
                        File(Media.dir(ctx), "croquis_" + java.util.UUID.randomUUID().toString() + ".png").also { out ->
                            out.outputStream().use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
                        }
                    }
                    val id = ensureNote()
                    val before = vm.attachmentsOf(id).map { it.id }.toSet()
                    vm.addCaptured(id, f, video = false)
                    added(id, before)
                }
            },
        )
    }

    return remember {
        MediaAdder(
            capture = { video ->
                val f = Media.newFile(ctx, video)
                pending = f
                LockGuard.external()
                try {
                    if (video) takeVideo.launch(Files.uriFor(ctx, f)) else takePhoto.launch(Files.uriFor(ctx, f))
                } catch (e: Exception) {
                    pending = null
                    fr.jeremy.calepin.i18n.I18n.toast(ctx, "Aucun appareil photo disponible", Toast.LENGTH_SHORT).show()
                }
            },
            gallery = {
                LockGuard.external()
                pick.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageAndVideo))
            },
            sketch = { sketching = true },
            importing = { importing },
        )
    }
}

/**
 * Photos et vidéos d'une note. Les nouvelles se placent dans le texte, sous ce qui est déjà écrit ([onAdded]) ;
 * celles qui ne sont pas dans le texte restent dans la galerie en bas ([placed] : fichiers déjà dans le texte).
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun MediaSection(
    vm: NotesViewModel,
    noteId: Long,
    ensureNote: () -> Long,
    placed: Set<String> = emptySet(),
    version: Int = 0,
    onAdded: (List<Attachment>) -> Unit = {},
    onPlace: ((Attachment) -> Unit)? = null,
    onDeleted: (Attachment) -> Unit = {},
) {
    var localVersion by remember { mutableIntStateOf(0) }
    val media = remember(noteId, version, localVersion) { vm.attachmentsOf(noteId) }.filter { it.fileName !in placed }
    var viewing by remember { mutableStateOf<Attachment?>(null) }
    val adder = rememberMediaAdder(vm, ensureNote) { onAdded(it); localVersion++ }

    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        if (media.isNotEmpty()) {
            Text(if (placed.isEmpty()) "Photos et vidéos" else "Autres photos et vidéos", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(media, key = { it.id }) { a -> Thumb(vm.fileOf(a), a.isVideo, Modifier.size(104.dp)) { viewing = a } }
            }
        }
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = { adder.capture(false) }) {
                Icon(Icons.Filled.PhotoCamera, null, Modifier.size(18.dp)); Text(" Photo")
            }
            OutlinedButton(onClick = { adder.capture(true) }) {
                Icon(Icons.Filled.Videocam, null, Modifier.size(18.dp)); Text(" Vidéo")
            }
            OutlinedButton(onClick = { adder.gallery() }) {
                Icon(Icons.Filled.PhotoLibrary, null, Modifier.size(18.dp)); Text(" Galerie")
            }
            OutlinedButton(onClick = { adder.sketch() }) {
                Icon(Icons.Filled.Draw, null, Modifier.size(18.dp)); Text(" Croquis")
            }
            if (adder.importing()) CircularProgressIndicator(Modifier.padding(top = 10.dp).size(20.dp), strokeWidth = 2.dp)
        }
    }

    viewing?.let { a ->
        MediaViewer(
            vm = vm, a = a,
            onClose = { viewing = null },
            onDeleted = { viewing = null; localVersion++; onDeleted(a) },
            onPlace = onPlace?.let { place -> { place(a); viewing = null; localVersion++ } },
        )
    }
}

/** Photo ou vidéo placée dans le texte d'une note : miniature comme dans la galerie, en grand au toucher. */
@Composable
fun InlineMediaView(vm: NotesViewModel, a: Attachment, modifier: Modifier = Modifier, onDeleted: (Attachment) -> Unit = {}) {
    var viewing by remember { mutableStateOf(false) }
    Thumb(vm.fileOf(a), a.isVideo, modifier) { viewing = true }
    if (viewing) {
        MediaViewer(vm = vm, a = a, onClose = { viewing = false }, onDeleted = { viewing = false; onDeleted(a) })
    }
}

@Composable
private fun Thumb(file: File, isVideo: Boolean, modifier: Modifier, maxSide: Int = 320, crop: Boolean = true, onClick: () -> Unit) {
    val bmp by produceState<Bitmap?>(null, file) {
        value = withContext(Dispatchers.IO) { Media.thumbnail(file, isVideo, maxSide) }
    }
    Box(
        modifier
            .clip(RoundedCornerShape(10.dp))
            .background(MaterialTheme.colorScheme.surfaceContainer)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        bmp?.let { Image(it.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = if (crop) ContentScale.Crop else ContentScale.Fit) }
        if (isVideo) Icon(Icons.Filled.PlayCircle, "Vidéo", tint = Color.White, modifier = Modifier.size(36.dp))
    }
}

@Composable
private fun MediaViewer(vm: NotesViewModel, a: Attachment, onClose: () -> Unit, onDeleted: () -> Unit, onPlace: (() -> Unit)? = null) {
    val ctx = LocalContext.current
    val file = vm.fileOf(a)
    val mime = Media.mimeOf(file)
    var confirmDelete by remember { mutableStateOf(false) }
    val bmp by produceState<Bitmap?>(null, file) {
        value = withContext(Dispatchers.IO) { Media.thumbnail(file, a.isVideo, 2048) }
    }
    var scale by remember { mutableFloatStateOf(1f) }
    var offsetX by remember { mutableFloatStateOf(0f) }
    var offsetY by remember { mutableFloatStateOf(0f) }
    val zoom = rememberTransformableState { z, pan, _ ->
        scale = (scale * z).coerceIn(1f, 6f)
        offsetX += pan.x; offsetY += pan.y
        if (scale == 1f) { offsetX = 0f; offsetY = 0f }
    }
    val saver = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { res ->
        val uri = res.data?.data
        if (res.resultCode == Activity.RESULT_OK && uri != null) {
            val ok = Files.write(ctx, uri, file.readBytes())
            fr.jeremy.calepin.i18n.I18n.toast(ctx, if (ok) "Fichier enregistré" else "Impossible d'écrire le fichier", Toast.LENGTH_SHORT).show()
        }
    }

    Dialog(onDismissRequest = onClose, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Box(
            Modifier
                .fillMaxSize()
                .background(Color.Black),
        ) {
            bmp?.let {
                Image(
                    it.asImageBitmap(), null,
                    Modifier
                        .fillMaxSize()
                        .transformable(zoom)
                        .graphicsLayer(scaleX = scale, scaleY = scale, translationX = offsetX, translationY = offsetY),
                    contentScale = ContentScale.Fit,
                )
            }
            if (a.isVideo) {
                Button(
                    onClick = {
                        LockGuard.external()
                        runCatching {
                            ctx.startActivity(
                                Intent(Intent.ACTION_VIEW).setDataAndType(Files.uriFor(ctx, file), "video/*")
                                    .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                            )
                        }.onFailure { fr.jeremy.calepin.i18n.I18n.toast(ctx, "Aucun lecteur vidéo installé", Toast.LENGTH_SHORT).show() }
                    },
                    modifier = Modifier.align(Alignment.Center),
                ) {
                    Icon(Icons.Filled.PlayCircle, null); Text("  Lire la vidéo")
                }
            }
            Row(
                Modifier
                    .align(Alignment.TopEnd)
                    .systemBarsPadding()
                    .padding(8.dp),
            ) {
                IconButton(onClick = onClose) { Icon(Icons.Filled.Close, "Fermer", tint = Color.White) }
            }
            Row(
                Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
                    .systemBarsPadding()
                    .background(Color.Black.copy(alpha = 0.5f))
                    .padding(8.dp),
                horizontalArrangement = Arrangement.SpaceEvenly,
            ) {
                TextButton(onClick = { Files.shareFile(ctx, file, mime, file.name) }) {
                    Icon(Icons.Filled.Share, null, tint = Color.White); Text("  Partager", color = Color.White)
                }
                TextButton(onClick = {
                    LockGuard.external()
                    saver.launch(Files.createDocumentIntent("Calepin " + file.name, mime))
                }) {
                    Icon(Icons.Filled.SaveAlt, null, tint = Color.White); Text("  Enregistrer", color = Color.White)
                }
                if (onPlace != null) {
                    TextButton(onClick = onPlace) {
                        Icon(Icons.Filled.VerticalAlignBottom, null, tint = Color.White); Text("  Dans le texte", color = Color.White)
                    }
                }
                TextButton(onClick = { confirmDelete = true }) {
                    Icon(Icons.Filled.Delete, null, tint = Color(0xFFFF8A80)); Text("  Supprimer", color = Color(0xFFFF8A80))
                }
            }
        }
    }

    if (confirmDelete) {
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            title = { Text(if (a.isVideo) "Supprimer cette vidéo ?" else "Supprimer cette photo ?") },
            text = { Text("Elle sera retirée de la note et effacée de Calepin.") },
            confirmButton = {
                TextButton(onClick = { vm.deleteAttachment(a); confirmDelete = false; onDeleted() }) {
                    Text("Supprimer", color = MaterialTheme.colorScheme.error)
                }
            },
            dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text("Annuler") } },
        )
    }
}
