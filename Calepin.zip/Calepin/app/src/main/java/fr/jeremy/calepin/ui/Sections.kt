package fr.jeremy.calepin.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import fr.jeremy.calepin.i18n.Text

/**
 * Rubrique dépliable des écrans Apparence et Paramètres : un en-tête bien visible (icône, titre, résumé)
 * qu'on touche pour ouvrir ou refermer le contenu. L'état ouvert / fermé est gardé en tournant l'écran.
 */
@Composable
fun FoldSection(
    title: String,
    icon: ImageVector,
    summary: String? = null,
    startOpen: Boolean = false,
    content: @Composable ColumnScope.() -> Unit,
) {
    var open by rememberSaveable(title) { mutableStateOf(startOpen) }
    val cs = MaterialTheme.colorScheme
    val translucent = LocalLook.current.deco != Deco.NONE
    Surface(
        shape = MaterialTheme.shapes.large,
        color = (if (open) cs.surfaceContainer else cs.surfaceContainerLow).copy(alpha = if (translucent) 0.9f else 1f),
        border = appBorder(BorderStroke(1.dp, if (open) cs.primary.copy(alpha = 0.5f) else cs.outlineVariant)),
        modifier = Modifier.fillMaxWidth(),
    ) {
        Column {
            Row(
                Modifier
                    .fillMaxWidth()
                    .clickable { open = !open }
                    .padding(horizontal = 14.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Surface(shape = CircleShape, color = if (open) cs.primary else cs.primaryContainer) {
                    Icon(
                        icon, contentDescription = null,
                        tint = if (open) cs.onPrimary else cs.onPrimaryContainer,
                        modifier = Modifier.padding(8.dp).size(22.dp),
                    )
                }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    FitText(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold, color = cs.onSurface)
                    if (summary != null && !open) {
                        Text(summary, style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant, maxLines = 2)
                    }
                }
                Icon(
                    if (open) Icons.Filled.ExpandLess else Icons.Filled.ExpandMore,
                    contentDescription = if (open) "Replier" else "Déplier",
                    tint = cs.primary,
                )
            }
            AnimatedVisibility(visible = open) {
                Column(
                    Modifier.padding(start = 16.dp, end = 16.dp, bottom = 16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    HorizontalDivider(color = cs.outlineVariant)
                    content()
                }
            }
        }
    }
}

/** Sous-titre à l'intérieur d'une rubrique. */
@Composable
fun SubTitle(text: String) {
    Text(text, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.primary)
}

/** Rubrique qui ouvre un autre écran (Apparence, Jeux, À propos…) : même allure qu'une rubrique dépliable. */
@Composable
fun LinkCard(title: String, icon: ImageVector, summary: String? = null, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val translucent = LocalLook.current.deco != Deco.NONE
    Surface(
        shape = MaterialTheme.shapes.large,
        color = cs.surfaceContainerLow.copy(alpha = if (translucent) 0.9f else 1f),
        border = appBorder(BorderStroke(1.dp, cs.outlineVariant)),
        modifier = Modifier.fillMaxWidth(),
    ) {
        Row(
            Modifier
                .fillMaxWidth()
                .clickable(onClick = onClick)
                .padding(horizontal = 14.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Surface(shape = CircleShape, color = cs.primaryContainer) {
                Icon(icon, contentDescription = null, tint = cs.onPrimaryContainer, modifier = Modifier.padding(8.dp).size(22.dp))
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                FitText(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold, color = cs.onSurface)
                if (summary != null) {
                    Text(summary, style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant, maxLines = 2)
                }
            }
            Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, contentDescription = null, tint = cs.primary)
        }
    }
}
