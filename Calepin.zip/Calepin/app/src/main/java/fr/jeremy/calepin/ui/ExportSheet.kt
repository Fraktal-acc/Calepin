package fr.jeremy.calepin.ui

import android.app.Activity
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.SaveAlt
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import fr.jeremy.calepin.Files
import fr.jeremy.calepin.LockGuard
import fr.jeremy.calepin.NotesViewModel
import fr.jeremy.calepin.data.Note
import fr.jeremy.calepin.export.ExportFormat
import fr.jeremy.calepin.export.Exporters
import kotlinx.coroutines.launch

/** Choix du format puis « Partager » ou « Enregistrer sous… ». */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ExportSheet(vm: NotesViewModel, notes: List<Note>, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var format by rememberSaveable { mutableStateOf(ExportFormat.PDF) }
    var busy by remember { mutableStateOf(false) }
    var pending by remember { mutableStateOf<ByteArray?>(null) }

    val saver = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { res ->
        val uri = res.data?.data
        val bytes = pending
        pending = null
        if (res.resultCode == Activity.RESULT_OK && uri != null && bytes != null) {
            val ok = Files.write(ctx, uri, bytes)
            Toast.makeText(ctx, if (ok) "Fichier enregistré" else "Impossible d'écrire le fichier", Toast.LENGTH_SHORT).show()
            if (ok) onDismiss()
        }
    }

    fun run(share: Boolean) {
        scope.launch {
            busy = true
            val bytes = runCatching { vm.export(format, notes) }.getOrNull()
            busy = false
            if (bytes == null) {
                Toast.makeText(ctx, "L'export a échoué", Toast.LENGTH_SHORT).show()
                return@launch
            }
            val name = Exporters.fileName(notes, format)
            LockGuard.external()
            if (share) {
                Files.shareBytes(ctx, bytes, name, format.mime)
            } else {
                pending = bytes
                saver.launch(Files.createDocumentIntent(name, format.mime))
            }
        }
    }

    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(
            Modifier
                .padding(horizontal = 20.dp)
                .padding(bottom = 28.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(4.dp),
        ) {
            Text(
                if (notes.size == 1) "Exporter la note" else "Exporter ${notes.size} notes",
                style = MaterialTheme.typography.titleLarge,
            )
            Text(
                "Choisissez le format, puis partagez le fichier ou enregistrez-le où vous voulez.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(bottom = 8.dp),
            )
            ExportFormat.entries.forEach { f ->
                Row(
                    Modifier
                        .fillMaxWidth()
                        .clickable { format = f }
                        .padding(vertical = 2.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    RadioButton(selected = format == f, onClick = { format = f })
                    Column {
                        Text("${f.label} (.${f.ext})", style = MaterialTheme.typography.bodyLarge)
                        Text(f.hint, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(top = 12.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                OutlinedButton(onClick = { run(share = true) }, enabled = !busy, modifier = Modifier.weight(1f)) {
                    Icon(Icons.Filled.Share, contentDescription = null, modifier = Modifier.size(18.dp))
                    Text("  Partager")
                }
                Button(onClick = { run(share = false) }, enabled = !busy, modifier = Modifier.weight(1f)) {
                    if (busy) {
                        CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp)
                    } else {
                        Icon(Icons.Filled.SaveAlt, contentDescription = null, modifier = Modifier.size(18.dp))
                    }
                    Text("  Enregistrer")
                }
            }
        }
    }
}
