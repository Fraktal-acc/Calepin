package fr.jeremy.calepin.control

import android.accessibilityservice.AccessibilityService
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/**
 * Envoi automatique d'un message (ou d'un fichier) WhatsApp ou Telegram préparé et confirmé dans Calepin IA.
 *
 * Le service ne fait rien tant qu'aucun envoi n'est « armé » (25 secondes au plus, un seul envoi).
 * - Texte : il vérifie que le champ de saisie contient exactement le message confirmé, puis touche « Envoyer ».
 * - Fichier ou message vocal : il touche « Envoyer » sur l'écran d'envoi ouvert par Calepin.
 * - Telegram sans lien direct : dans la liste de partage, il choisit la conversation au nom exact, puis « Envoyer ».
 * Il ramène ensuite Calepin IA à l'écran. Il ne lit ni n'enregistre rien d'autre.
 */
class WhatsAppSender : AccessibilityService() {

    companion object {
        private enum class Mode { TEXT, MEDIA }

        @Volatile private var armedText: String? = null
        @Volatile private var armedMode = Mode.TEXT
        @Volatile private var armedApp: String = Conv.WHATSAPP
        /** Telegram (liste de partage) : nom exact de la conversation à choisir. */
        @Volatile private var armedTarget: String? = null
        @Volatile private var targetChosen = false
        @Volatile private var armedUntil = 0L

        /** Arme l'envoi d'un texte WhatsApp (compatibilité). */
        fun arm(message: String) = armText(Conv.WHATSAPP, message)

        /** Arme l'envoi d'un texte (le champ doit contenir exactement [message]). */
        fun armText(app: String, message: String, shareTarget: String? = null) {
            armedText = message.trim()
            armedMode = Mode.TEXT
            armedApp = app
            armedTarget = shareTarget?.trim()?.takeIf { it.isNotEmpty() }
            targetChosen = false
            armedUntil = System.currentTimeMillis() + 25_000
        }

        /** Arme l'envoi d'un fichier ou d'un message vocal partagé à [app]. */
        fun armMedia(app: String, shareTarget: String? = null) {
            armedText = null
            armedMode = Mode.MEDIA
            armedApp = app
            armedTarget = shareTarget?.trim()?.takeIf { it.isNotEmpty() }
            targetChosen = false
            armedUntil = System.currentTimeMillis() + 25_000
        }

        fun disarm() {
            armedText = null
            armedTarget = null
            armedUntil = 0
        }

        fun isEnabled(ctx: Context): Boolean {
            val me = ComponentName(ctx, WhatsAppSender::class.java).flattenToString()
            val list = Settings.Secure.getString(ctx.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
            return list.split(':').any { it.equals(me, ignoreCase = true) }
        }

        private fun prefs(ctx: Context) = ctx.getSharedPreferences("calepin_settings", Context.MODE_PRIVATE)

        /** Envoi automatique choisi pour cette appli (Paramètres → Maison et téléphone). */
        fun wanted(ctx: Context, app: String): Boolean = prefs(ctx).getBoolean("auto_send_$app", true)

        fun setWanted(ctx: Context, app: String, on: Boolean) { prefs(ctx).edit().putBoolean("auto_send_$app", on).apply() }

        /** Le service est actif et l'envoi automatique est voulu pour cette appli. */
        fun autoFor(ctx: Context, app: String): Boolean = isEnabled(ctx) && wanted(ctx, app)

        fun openSettings(ctx: Context) {
            runCatching { ctx.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
        }
    }

    private val main = Handler(Looper.getMainLooper())
    private var lastClick = 0L

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (System.currentTimeMillis() > armedUntil) { if (armedUntil != 0L) disarm(); return }
        val pkg = event?.packageName?.toString() ?: return
        val app = when (pkg) {
            in MessageHub.WHATSAPP_PKGS -> Conv.WHATSAPP
            in MessageHub.TELEGRAM_PKGS -> Conv.TELEGRAM
            else -> return
        }
        if (app != armedApp) return
        // Laisser l'écran se mettre en place entre deux actions
        if (System.currentTimeMillis() - lastClick < 700) return
        val root = rootInActiveWindow ?: return
        handle(root, pkg, app)
    }

    private fun sendButton(root: AccessibilityNodeInfo, pkg: String): AccessibilityNodeInfo? =
        root.findAccessibilityNodeInfosByViewId("$pkg:id/send").firstOrNull { it.isVisibleToUser }
            ?: root.findAccessibilityNodeInfosByViewId("android:id/button1").firstOrNull { it.text?.toString()?.trim()?.uppercase() in SEND_UPPER }
            ?: findByLabel(root)

    private fun handle(root: AccessibilityNodeInfo, pkg: String, app: String) {
        if (armedMode == Mode.TEXT) {
            val text = armedText ?: return
            // Sécurité : le champ de saisie doit contenir exactement le message confirmé
            val field = (if (app == Conv.WHATSAPP) root.findAccessibilityNodeInfosByViewId("$pkg:id/entry").firstOrNull() else null)
                ?: findEditable(root) { it.text?.toString()?.trim() == text }
            if (field?.text?.toString()?.trim() == text) {
                sendButton(root, pkg)?.let { if (click(it)) done() }
                return
            }
        }
        // Liste de partage : choisir la conversation au nom exact, puis Envoyer
        val target = armedTarget
        if (target != null && !targetChosen) {
            val cell = findNode(root) { n -> !n.isEditable && n.text?.toString()?.trim().equals(target, ignoreCase = true) }
            if (cell != null && click(cell)) targetChosen = true
            return
        }
        if (armedMode == Mode.MEDIA || targetChosen) sendButton(root, pkg)?.let { if (click(it)) done() }
    }

    private fun done() {
        disarm()
        main.postDelayed({
            packageManager.getLaunchIntentForPackage(packageName)?.let {
                runCatching { startActivity(it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT)) }
            }
        }, 900)
    }

    /** Bouton « Envoyer » (texte ou description), selon la langue du téléphone. */
    private fun findByLabel(root: AccessibilityNodeInfo): AccessibilityNodeInfo? =
        findNode(root) { n ->
            val d = n.contentDescription?.toString()?.trim()
            val t = n.text?.toString()?.trim()
            (d != null && d in SEND_LABELS) || (t != null && t.uppercase() in SEND_UPPER && !n.isEditable)
        }

    private fun findEditable(root: AccessibilityNodeInfo, ok: (AccessibilityNodeInfo) -> Boolean) =
        findNode(root) { it.isEditable && ok(it) }

    private fun findNode(root: AccessibilityNodeInfo, ok: (AccessibilityNodeInfo) -> Boolean): AccessibilityNodeInfo? {
        val queue = ArrayDeque<AccessibilityNodeInfo>()
        queue.add(root)
        var seen = 0
        while (queue.isNotEmpty() && seen < 1500) {
            val n = queue.removeFirst()
            seen++
            if (n.isVisibleToUser && ok(n)) return n
            for (i in 0 until n.childCount) n.getChild(i)?.let { queue.add(it) }
        }
        return null
    }

    private fun click(node: AccessibilityNodeInfo): Boolean {
        var n: AccessibilityNodeInfo? = node
        while (n != null) {
            if (n.isClickable) {
                lastClick = System.currentTimeMillis()
                return n.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            }
            n = n.parent
        }
        return false
    }

    override fun onInterrupt() {}
}

/** Bouton « Envoyer » selon la langue du téléphone (français, anglais, italien, espagnol, allemand). */
private val SEND_LABELS = listOf("Envoyer", "Send", "Invia", "Enviar", "Senden")
private val SEND_UPPER = SEND_LABELS.map { it.uppercase() }.toSet()
