package fr.jeremy.calepin.control

import android.accessibilityservice.AccessibilityService
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/**
 * Envoi automatique d'un message WhatsApp préparé et confirmé dans Calepin IA.
 *
 * Le service ne fait rien tant qu'aucun envoi n'est « armé ». Quand WhatsApp s'ouvre sur la conversation,
 * il vérifie que le champ de saisie contient exactement le message confirmé, touche « Envoyer » une seule fois,
 * puis ramène Calepin IA à l'écran. Il ne lit ni n'enregistre rien d'autre.
 */
class WhatsAppSender : AccessibilityService() {

    companion object {
        @Volatile private var armedText: String? = null
        @Volatile private var armedUntil = 0L

        /** Arme un envoi pour les 25 prochaines secondes. */
        fun arm(message: String) {
            armedText = message.trim()
            armedUntil = System.currentTimeMillis() + 25_000
        }

        fun disarm() {
            armedText = null
            armedUntil = 0
        }

        fun isEnabled(ctx: Context): Boolean {
            val me = ComponentName(ctx, WhatsAppSender::class.java).flattenToString()
            val list = Settings.Secure.getString(ctx.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
            return list.split(':').any { it.equals(me, ignoreCase = true) }
        }

        fun openSettings(ctx: Context) {
            runCatching { ctx.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
        }
    }

    private val main = Handler(Looper.getMainLooper())

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        val text = armedText ?: return
        if (System.currentTimeMillis() > armedUntil) { disarm(); return }
        val pkg = event?.packageName?.toString() ?: return
        if (pkg != "com.whatsapp" && pkg != "com.whatsapp.w4b") return
        val root = rootInActiveWindow ?: return

        // Sécurité : le champ de saisie doit contenir exactement le message confirmé
        val entry = root.findAccessibilityNodeInfosByViewId("$pkg:id/entry").firstOrNull()
        val typed = entry?.text?.toString()?.trim()
        if (typed != text) return

        val send = root.findAccessibilityNodeInfosByViewId("$pkg:id/send").firstOrNull()
            ?: SEND_LABELS.asSequence().flatMap { root.findAccessibilityNodeInfosByText(it).asSequence() }
                .firstOrNull { it.contentDescription?.toString() in SEND_LABELS }
            ?: return
        if (click(send)) {
            disarm()
            // Retour dans Calepin IA une fois le message parti
            main.postDelayed({
                packageManager.getLaunchIntentForPackage(packageName)?.let {
                    runCatching { startActivity(it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT)) }
                }
            }, 900)
        }
    }

    private fun click(node: AccessibilityNodeInfo): Boolean {
        var n: AccessibilityNodeInfo? = node
        while (n != null) {
            if (n.isClickable) return n.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            n = n.parent
        }
        return false
    }

    override fun onInterrupt() {}
}

/** Bouton « Envoyer » de WhatsApp selon la langue du téléphone (français, anglais, italien, espagnol, allemand). */
private val SEND_LABELS = listOf("Envoyer", "Send", "Invia", "Enviar", "Senden")
