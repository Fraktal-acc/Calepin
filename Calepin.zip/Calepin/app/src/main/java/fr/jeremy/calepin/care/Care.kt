package fr.jeremy.calepin.care

import android.Manifest
import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import fr.jeremy.calepin.MainActivity
import fr.jeremy.calepin.R
import fr.jeremy.calepin.data.Event
import fr.jeremy.calepin.data.NoteDb
import fr.jeremy.calepin.i18n.I18n
import fr.jeremy.calepin.reminders.Reminders
import java.io.File
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/** Tâches qui tournent seules : sauvegarde de nuit, réveil des vacations, rappels URSSAF, routines. */
object Care {
    const val ACTION_BACKUP = "fr.jeremy.calepin.care.BACKUP"
    const val ACTION_WAKE_SYNC = "fr.jeremy.calepin.care.WAKE_SYNC"
    const val ACTION_URSSAF = "fr.jeremy.calepin.care.URSSAF"
    const val ACTION_ROUTINE = "fr.jeremy.calepin.care.ROUTINE"
    const val EXTRA_ROUTINE = "routine"
    const val ACTION_PLACE = "fr.jeremy.calepin.care.PLACE"
    private const val CHANNEL = "calepin_entretien"

    fun prefs(ctx: Context) = ctx.applicationContext.getSharedPreferences("calepin_care", Context.MODE_PRIVATE)

    private fun am(ctx: Context) = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager

    fun pending(ctx: Context, action: String, code: Int, extra: String? = null): PendingIntent =
        PendingIntent.getBroadcast(
            ctx, code,
            Intent(ctx, CareReceiver::class.java).setAction(action).apply { if (extra != null) putExtra(EXTRA_ROUTINE, extra) },
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )

    /** Prochaine occurrence d'une heure de la journée (en minutes depuis minuit). */
    fun nextAt(minutes: Int, from: Long = System.currentTimeMillis()): Long = Calendar.getInstance().apply {
        timeInMillis = from
        set(Calendar.HOUR_OF_DAY, minutes / 60); set(Calendar.MINUTE, minutes % 60); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
        if (timeInMillis <= from) add(Calendar.DAY_OF_YEAR, 1)
    }.timeInMillis

    fun at(ctx: Context, time: Long, pi: PendingIntent) {
        runCatching { am(ctx).setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, time, pi) }
    }

    fun cancel(ctx: Context, pi: PendingIntent) = runCatching { am(ctx).cancel(pi) }

    /** Tout reprogrammer (démarrage du téléphone, ouverture de l'appli, réglage modifié). */
    fun scheduleAll(ctx: Context) {
        runCatching { advanceRepeats(ctx) }
        runCatching { PlaceReminders.registerAll(ctx) }
        AutoBackup.schedule(ctx)
        WakeAlarm.scheduleSync(ctx)
        Urssaf.schedule(ctx)
        Routines.schedule(ctx)
    }

    /** Rendez-vous répétés déjà passés (sans rappel pour les faire avancer) : placés à leur prochaine date. */
    fun advanceRepeats(ctx: Context) {
        val db = NoteDb(ctx)
        val now = System.currentTimeMillis()
        db.events().filter { it.repeat.isNotEmpty() && (if (it.end > it.start) it.end else it.start) < now }.forEach { e ->
            e.nextOccurrence(now)?.let { next ->
                db.upsertEvent(next)
                Reminders.schedule(ctx, next)
            }
        }
    }

    fun notify(ctx: Context, id: Int, title: String, text: String, open: String? = null) {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) return
        val nm = ctx.getSystemService(NotificationManager::class.java)
        if (nm.getNotificationChannel(CHANNEL) == null) {
            nm.createNotificationChannel(NotificationChannel(CHANNEL, I18n.tr(ctx, "Entretien et rappels de Calepin"), NotificationManager.IMPORTANCE_DEFAULT))
        }
        val pi = PendingIntent.getActivity(
            ctx, 900 + id,
            Intent(ctx, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP)
                .apply { if (open != null) putExtra(fr.jeremy.calepin.widgets.Widgets.EXTRA_OPEN, open) },
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        val n = NotificationCompat.Builder(ctx, CHANNEL)
            .setSmallIcon(R.drawable.wic_edit)
            .setContentTitle(I18n.tr(ctx, title))
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setContentIntent(pi)
            .setAutoCancel(true)
            .build()
        runCatching { nm.notify(id, n) }
    }
}

class CareReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        I18n.init(ctx)
        val pending = goAsync()
        Thread {
            try {
                when (intent.action) {
                    Care.ACTION_BACKUP -> { AutoBackup.run(ctx); AutoBackup.schedule(ctx) }
                    Care.ACTION_WAKE_SYNC -> { WakeAlarm.sync(ctx); WakeAlarm.scheduleSync(ctx) }
                    Care.ACTION_URSSAF -> { Urssaf.fire(ctx); Urssaf.schedule(ctx) }
                    Care.ACTION_ROUTINE -> {
                        intent.getStringExtra(Care.EXTRA_ROUTINE)?.let { Routines.runById(ctx, it) }
                        Routines.schedule(ctx)
                    }
                    Care.ACTION_PLACE -> PlaceReminders.onProximity(ctx, intent)
                    Intent.ACTION_POWER_CONNECTED -> Routines.onCharger(ctx, true)
                    Intent.ACTION_POWER_DISCONNECTED -> Routines.onCharger(ctx, false)
                }
            } catch (e: Throwable) {
                CrashLog.note(ctx, "tâche de fond ${intent.action}", e)
            } finally {
                pending.finish()
            }
        }.start()
    }
}

// ------------------------------------------------------------------ Sauvegarde automatique

/**
 * Sauvegarde complète chaque nuit (vers 3 h) dans « Téléchargements/Calepin », chiffrée si un mot de passe
 * est choisi. Les 7 dernières sont gardées.
 */
object AutoBackup {
    const val FOLDER = "Calepin"
    private const val PREFIX = "calepin-auto-"
    private const val KEEP = 7

    fun enabled(ctx: Context) = Care.prefs(ctx).getBoolean("backup_on", false)
    fun password(ctx: Context) = Care.prefs(ctx).getString("backup_pwd", "").orEmpty()
    fun hour(ctx: Context) = Care.prefs(ctx).getInt("backup_hour", 3)
    fun last(ctx: Context) = Care.prefs(ctx).getLong("backup_last", 0L)
    fun lastError(ctx: Context) = Care.prefs(ctx).getString("backup_error", null)

    fun set(ctx: Context, on: Boolean, pwd: String, hour: Int) {
        Care.prefs(ctx).edit().putBoolean("backup_on", on).putString("backup_pwd", pwd).putInt("backup_hour", hour).apply()
        schedule(ctx)
    }

    fun schedule(ctx: Context) {
        val pi = Care.pending(ctx, Care.ACTION_BACKUP, 7001)
        Care.cancel(ctx, pi)
        if (enabled(ctx)) Care.at(ctx, Care.nextAt(hour(ctx) * 60 + 5), pi)
    }

    /** Fait la sauvegarde maintenant. Renvoie un message (réussite ou erreur). */
    fun run(ctx: Context): String {
        val name = PREFIX + SimpleDateFormat("yyyy-MM-dd_HH'h'mm", Locale.FRANCE).format(Date()) + ".calepin"
        return try {
            val data = fr.jeremy.calepin.export.BackupData.export(NoteDb(ctx))
            val pwd = password(ctx).ifBlank { null }
            if (Build.VERSION.SDK_INT >= 29) {
                val v = ContentValues().apply {
                    put(MediaStore.Downloads.DISPLAY_NAME, name)
                    put(MediaStore.Downloads.MIME_TYPE, "application/octet-stream")
                    put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/" + FOLDER)
                }
                val uri = ctx.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v) ?: error("Dossier Téléchargements inaccessible")
                val out = ctx.contentResolver.openOutputStream(uri, "w") ?: error("Écriture impossible")
                fr.jeremy.calepin.export.FullBackup.write(ctx, out, data, pwd)
                prune29(ctx)
            } else {
                @Suppress("DEPRECATION")
                val dir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), FOLDER).apply { mkdirs() }
                fr.jeremy.calepin.export.FullBackup.write(ctx, File(dir, name).outputStream(), data, pwd)
                dir.listFiles { f -> f.name.startsWith(PREFIX) }?.sortedByDescending { it.lastModified() }?.drop(KEEP)?.forEach { it.delete() }
            }
            Care.prefs(ctx).edit().putLong("backup_last", System.currentTimeMillis()).remove("backup_error").apply()
            I18n.tr("Sauvegarde faite dans Téléchargements/Calepin.")
        } catch (e: Throwable) {
            val msg = e.message ?: e.javaClass.simpleName
            Care.prefs(ctx).edit().putString("backup_error", msg).apply()
            CrashLog.note(ctx, "sauvegarde automatique", e)
            Care.notify(ctx, 71, "Sauvegarde automatique impossible", msg, "backup")
            I18n.tr("Sauvegarde impossible :") + " " + msg
        }
    }

    /** Ne garde que les 7 sauvegardes automatiques les plus récentes (celles créées par Calepin). */
    private fun prune29(ctx: Context) {
        if (Build.VERSION.SDK_INT < 29) return
        val found = ArrayList<Pair<Long, android.net.Uri>>()
        ctx.contentResolver.query(
            MediaStore.Downloads.EXTERNAL_CONTENT_URI,
            arrayOf(MediaStore.Downloads._ID, MediaStore.Downloads.DATE_ADDED),
            "${MediaStore.Downloads.DISPLAY_NAME} LIKE ? AND ${MediaStore.Downloads.RELATIVE_PATH} LIKE ?",
            arrayOf("$PREFIX%", "%$FOLDER%"),
            null,
        )?.use { c ->
            while (c.moveToNext()) {
                found += c.getLong(1) to android.content.ContentUris.withAppendedId(MediaStore.Downloads.EXTERNAL_CONTENT_URI, c.getLong(0))
            }
        }
        found.sortedByDescending { it.first }.drop(KEEP).forEach { runCatching { ctx.contentResolver.delete(it.second, null, null) } }
    }
}

// ------------------------------------------------------------------ Réveil selon la vacation

/**
 * Réveil réglé tout seul avant chaque vacation : heure de prise de poste − (préparation + trajet).
 * Les réveils sont des alarmes de l'agenda (catégorie « réveil »), recalculées chaque soir et à chaque
 * import de planning ; rien les jours de repos.
 */
object WakeAlarm {
    const val CATEGORY = "reveil"

    fun enabled(ctx: Context) = Care.prefs(ctx).getBoolean("wake_on", false)
    fun prep(ctx: Context) = Care.prefs(ctx).getInt("wake_prep", 60)
    fun travel(ctx: Context) = Care.prefs(ctx).getInt("wake_travel", 20)
    fun ringtone(ctx: Context) = Care.prefs(ctx).getString("wake_ring", "").orEmpty()
    /** Les vacations qui commencent avant cette heure seulement (en minutes) : les postes de l'après-midi n'ont pas besoin de réveil. */
    fun before(ctx: Context) = Care.prefs(ctx).getInt("wake_before", 12 * 60)

    fun set(ctx: Context, on: Boolean, prep: Int, travel: Int, before: Int, ringtone: String) {
        Care.prefs(ctx).edit().putBoolean("wake_on", on).putInt("wake_prep", prep).putInt("wake_travel", travel)
            .putInt("wake_before", before).putString("wake_ring", ringtone).apply()
        Thread { runCatching { sync(ctx) } }.start()
        scheduleSync(ctx)
    }

    /** Recalcul chaque soir à 20 h (au cas où le planning a changé entre-temps). */
    fun scheduleSync(ctx: Context) {
        val pi = Care.pending(ctx, Care.ACTION_WAKE_SYNC, 7002)
        Care.cancel(ctx, pi)
        if (enabled(ctx)) Care.at(ctx, Care.nextAt(20 * 60), pi)
    }

    /** Crée, déplace ou retire les réveils des 8 prochains jours selon les vacations. */
    fun sync(ctx: Context) {
        val db = NoteDb(ctx)
        val now = System.currentTimeMillis()
        val events = db.events()
        val existing = events.filter { it.category == CATEGORY && it.start > now }
        if (!enabled(ctx)) {
            existing.forEach { Reminders.cancel(ctx, it.id); db.deleteEvent(it.id) }
            return
        }
        val lead = (prep(ctx) + travel(ctx)) * 60_000L
        val horizon = now + 8 * 86_400_000L
        val wanted = events.filter { it.isWork && !it.allDay && it.start - lead > now && it.start < horizon }
            .filter { e -> Calendar.getInstance().apply { timeInMillis = e.start }.let { it.get(Calendar.HOUR_OF_DAY) * 60 + it.get(Calendar.MINUTE) } < before(ctx) }
            .map { shift ->
                val t = shift.start - lead
                Event(
                    title = I18n.trf("Réveil · vacation de {0}", SimpleDateFormat(I18n.pattern("H'h'mm"), I18n.locale).format(Date(shift.start))),
                    start = t, remindMinutes = 0, alarm = true, ringtone = ringtone(ctx), category = CATEGORY,
                )
            }
        // Garder ceux qui sont déjà bons, retirer les autres, ajouter les manquants
        val keep = existing.filter { e -> wanted.any { it.start == e.start } }
        existing.filter { it !in keep }.forEach { Reminders.cancel(ctx, it.id); db.deleteEvent(it.id) }
        wanted.filter { w -> keep.none { it.start == w.start } }.forEach { w ->
            val id = db.upsertEvent(w)
            Reminders.schedule(ctx, w.copy(id = id))
        }
    }
}

// ------------------------------------------------------------------ Rappel des déclarations URSSAF

/** Rappel quelques jours avant chaque déclaration de chiffre d'affaires (mensuelle ou trimestrielle). */
object Urssaf {
    fun enabled(ctx: Context) = Care.prefs(ctx).getBoolean("urssaf_on", false)
    fun quarterly(ctx: Context) = Care.prefs(ctx).getBoolean("urssaf_quarter", true)
    fun daysBefore(ctx: Context) = Care.prefs(ctx).getInt("urssaf_days", 7)

    fun set(ctx: Context, on: Boolean, quarterly: Boolean, days: Int) {
        Care.prefs(ctx).edit().putBoolean("urssaf_on", on).putBoolean("urssaf_quarter", quarterly).putInt("urssaf_days", days).apply()
        schedule(ctx)
    }

    /** Prochaine date limite : fin du mois suivant (mensuel) ou 30 avril / 31 juillet / 31 octobre / 31 janvier. */
    fun nextDeadline(ctx: Context, from: Long = System.currentTimeMillis()): Long {
        val c = Calendar.getInstance().apply { timeInMillis = from }
        repeat(15) {
            val cand = (c.clone() as Calendar).apply {
                set(Calendar.DAY_OF_MONTH, 1); set(Calendar.HOUR_OF_DAY, 9); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
                add(Calendar.MONTH, it)
                set(Calendar.DAY_OF_MONTH, getActualMaximum(Calendar.DAY_OF_MONTH))
            }
            val m = cand.get(Calendar.MONTH)
            val ok = !quarterly(ctx) || m == Calendar.JANUARY || m == Calendar.APRIL || m == Calendar.JULY || m == Calendar.OCTOBER
            if (ok && cand.timeInMillis - daysBefore(ctx) * 86_400_000L > from) return cand.timeInMillis
        }
        return from + 30 * 86_400_000L
    }

    fun schedule(ctx: Context) {
        val pi = Care.pending(ctx, Care.ACTION_URSSAF, 7003)
        Care.cancel(ctx, pi)
        if (enabled(ctx)) Care.at(ctx, nextDeadline(ctx) - daysBefore(ctx) * 86_400_000L, pi)
    }

    fun fire(ctx: Context) {
        val deadline = nextDeadline(ctx, System.currentTimeMillis() - 1)
        val d = SimpleDateFormat(I18n.pattern("EEEE d MMMM"), I18n.locale).format(Date(deadline))
        Care.notify(ctx, 73, "Déclaration URSSAF", I18n.trf("Pense à déclarer ton chiffre d'affaires avant le {0} (autoentrepreneur.urssaf.fr). Le montant est dans Pro → Bilan.", d), "pro")
    }
}
