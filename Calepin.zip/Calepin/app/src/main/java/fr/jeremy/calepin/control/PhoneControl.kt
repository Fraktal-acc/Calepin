package fr.jeremy.calepin.control

import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.provider.Settings
import fr.jeremy.calepin.LockGuard
import fr.jeremy.calepin.search.TextNorm

/**
 * Actions sur le téléphone lui-même. Android interdit à une appli d'activer seule le Wi-Fi, le Bluetooth
 * ou l'économie d'énergie : pour ceux-là, on ouvre le bon réglage et l'utilisateur touche l'interrupteur.
 */
class PhoneControl(private val ctx: Context) {

    data class InstalledApp(val label: String, val pkg: String)

    private fun start(i: Intent): Boolean = try {
        LockGuard.external()
        ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        true
    } catch (e: Exception) {
        false
    }

    // ------------------------------------------------------------ Applications

    fun installedApps(): List<InstalledApp> {
        val pm = ctx.packageManager
        val main = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        @Suppress("DEPRECATION")
        return pm.queryIntentActivities(main, 0)
            .map { InstalledApp(it.loadLabel(pm).toString(), it.activityInfo.packageName) }
            .filter { it.pkg != ctx.packageName }
            .distinctBy { it.pkg }
    }

    /** Appli la plus proche du nom donné (« youtube », « whatsapp », « appareil photo »…). */
    fun findApp(name: String): InstalledApp? {
        val target = TextNorm.norm(name).replace(Regex("[^a-z0-9 ]"), " ").replace(Regex("\\s+"), " ").trim()
        if (target.length < 2) return null
        val apps = installedApps().map { it to TextNorm.norm(it.label).replace(Regex("[^a-z0-9 ]"), " ").replace(Regex("\\s+"), " ").trim() }
        return apps.firstOrNull { it.second == target }?.first
            ?: apps.filter { it.second.startsWith(target) || target.startsWith(it.second) && it.second.length >= 3 }
                .minByOrNull { it.second.length }?.first
            ?: apps.filter { it.second.contains(target) && target.length >= 4 }.minByOrNull { it.second.length }?.first
    }

    fun openApp(app: InstalledApp): Boolean {
        val i = ctx.packageManager.getLaunchIntentForPackage(app.pkg) ?: return false
        return start(i)
    }

    fun youtubeSearch(query: String): Boolean {
        val inApp = Intent(Intent.ACTION_SEARCH).setPackage("com.google.android.youtube").putExtra("query", query)
        return start(inApp) || start(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/results?search_query=" + Uri.encode(query))))
    }

    /** Ouvre WhatsApp sur la conversation, message prêt : il ne reste qu'à toucher Envoyer. */
    fun whatsapp(phone: String, message: String): Boolean {
        var digits = phone.filter { it.isDigit() || it == '+' }
        digits = when {
            digits.startsWith("+") -> digits.drop(1)
            digits.startsWith("00") -> digits.drop(2)
            digits.startsWith("0") && digits.length == 10 -> "33" + digits.drop(1)
            else -> digits
        }.filter { it.isDigit() }
        return start(Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/$digits?text=" + Uri.encode(message))))
    }

    // ------------------------------------------------------------ Réglages directs

    fun torch(on: Boolean): Boolean = try {
        val cm = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
        val id = cm.cameraIdList.firstOrNull { cid ->
            val c = cm.getCameraCharacteristics(cid)
            c.get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true &&
                c.get(CameraCharacteristics.LENS_FACING) == CameraCharacteristics.LENS_FACING_BACK
        } ?: cm.cameraIdList.firstOrNull { cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true }
        if (id == null) false else { cm.setTorchMode(id, on); true }
    } catch (e: Exception) {
        false
    }

    /** [steps] > 0 : plus fort ; < 0 : moins fort ; 0 : couper le son. */
    fun mediaVolume(steps: Int): Boolean = try {
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        if (steps == 0) {
            am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_MUTE, AudioManager.FLAG_SHOW_UI)
        } else {
            repeat(kotlin.math.abs(steps)) {
                am.adjustStreamVolume(
                    AudioManager.STREAM_MUSIC,
                    if (steps > 0) AudioManager.ADJUST_RAISE else AudioManager.ADJUST_LOWER,
                    if (it == 0) AudioManager.FLAG_SHOW_UI else 0,
                )
            }
        }
        true
    } catch (e: Exception) {
        false
    }

    fun battery(): String {
        val bm = ctx.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
        val level = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
        val charging = bm.isCharging
        return "Batterie à $level %" + if (charging) ", en charge." else "."
    }

    /** Luminosité et rotation : demandent l'autorisation « Modifier les paramètres système », donnée une fois. */
    fun canWriteSettings() = Settings.System.canWrite(ctx)

    fun askWriteSettings() = start(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:" + ctx.packageName)))

    /** [value] de 0 à 255, ou un écart si [relative]. */
    fun brightness(value: Int, relative: Boolean): Boolean = try {
        val cr = ctx.contentResolver
        Settings.System.putInt(cr, Settings.System.SCREEN_BRIGHTNESS_MODE, Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL)
        val cur = Settings.System.getInt(cr, Settings.System.SCREEN_BRIGHTNESS, 128)
        val v = (if (relative) cur + value else value).coerceIn(5, 255)
        Settings.System.putInt(cr, Settings.System.SCREEN_BRIGHTNESS, v)
    } catch (e: Exception) {
        false
    }

    fun autoBrightness(): Boolean = try {
        Settings.System.putInt(ctx.contentResolver, Settings.System.SCREEN_BRIGHTNESS_MODE, Settings.System.SCREEN_BRIGHTNESS_MODE_AUTOMATIC)
    } catch (e: Exception) {
        false
    }

    fun autoRotate(on: Boolean): Boolean = try {
        Settings.System.putInt(ctx.contentResolver, Settings.System.ACCELEROMETER_ROTATION, if (on) 1 else 0)
    } catch (e: Exception) {
        false
    }

    private val nm get() = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

    fun canControlDnd() = nm.isNotificationPolicyAccessGranted

    fun askDndAccess() = start(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS))

    fun doNotDisturb(on: Boolean): Boolean = try {
        nm.setInterruptionFilter(if (on) NotificationManager.INTERRUPTION_FILTER_PRIORITY else NotificationManager.INTERRUPTION_FILTER_ALL)
        true
    } catch (e: Exception) {
        false
    }

    /** « silent », « vibrate » ou « normal ». */
    fun ringer(mode: String): Boolean = try {
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        am.ringerMode = when (mode) {
            "silent" -> AudioManager.RINGER_MODE_SILENT
            "vibrate" -> AudioManager.RINGER_MODE_VIBRATE
            else -> AudioManager.RINGER_MODE_NORMAL
        }
        true
    } catch (e: Exception) {
        false
    }

    // ------------------------------------------------------------ Réglages ouverts pour l'utilisateur

    fun openWifi() = if (Build.VERSION.SDK_INT >= 29) start(Intent(Settings.Panel.ACTION_WIFI)) else start(Intent(Settings.ACTION_WIFI_SETTINGS))
    fun openMobileData() = if (Build.VERSION.SDK_INT >= 29) start(Intent(Settings.Panel.ACTION_INTERNET_CONNECTIVITY)) else start(Intent(Settings.ACTION_DATA_ROAMING_SETTINGS))
    fun openNfc() = if (Build.VERSION.SDK_INT >= 29) start(Intent(Settings.Panel.ACTION_NFC)) else start(Intent(Settings.ACTION_NFC_SETTINGS))
    fun openBluetooth() = start(Intent(Settings.ACTION_BLUETOOTH_SETTINGS))
    fun openBatterySaver() = start(Intent(Settings.ACTION_BATTERY_SAVER_SETTINGS)) || start(Intent(Intent.ACTION_POWER_USAGE_SUMMARY))
    fun openAirplane() = start(Intent(Settings.ACTION_AIRPLANE_MODE_SETTINGS))
    fun openLocation() = start(Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS))
    fun openHotspot() = start(Intent(Settings.ACTION_WIRELESS_SETTINGS))

    @Suppress("unused")
    private fun hasPackage(pkg: String) = try {
        ctx.packageManager.getPackageInfo(pkg, 0); true
    } catch (e: PackageManager.NameNotFoundException) {
        false
    }
}
