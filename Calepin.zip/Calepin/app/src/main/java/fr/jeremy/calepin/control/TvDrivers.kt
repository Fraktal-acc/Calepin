package fr.jeremy.calepin.control

import android.util.Base64
import fr.jeremy.calepin.search.TextNorm
import kotlinx.coroutines.delay
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import org.json.JSONArray
import org.json.JSONObject
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.security.SecureRandom
import java.security.cert.X509Certificate
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.TimeUnit
import javax.net.ssl.SSLContext
import javax.net.ssl.X509TrustManager

/**
 * Ce que l'assistant sait demander à une télé ou à un décodeur. Chaque méthode renvoie vrai si la commande
 * est partie ; elles sont bloquantes ou suspendues et s'appellent hors du fil principal.
 */
interface TvControl {
    suspend fun power(on: Boolean): Boolean
    /** > 0 : plus fort, < 0 : moins fort, 0 : couper / remettre le son. */
    suspend fun volume(steps: Int): Boolean
    suspend fun channel(number: Int, named: OrangeDecoder.Channel?): Boolean
    suspend fun channelStep(up: Boolean): Boolean
    suspend fun playPause(): Boolean
    /** Ouvre une appli de la télé ; renvoie son nom, ou null si impossible. */
    suspend fun openApp(name: String): String? = null
    suspend fun hdmi(port: Int): Boolean = false
}

object TvDrivers {
    fun forDevice(d: HomeDevice, store: DeviceStore): TvControl? = when (d.kind) {
        Kind.ORANGE -> OrangeTv(OrangeDecoder(d.host))
        Kind.BRAVIA -> BraviaControl(BraviaTv(d.host, d.secret, d.extraJson.optString("mac"), d.extraJson.optString("cookie"), d.extraJson.optString("clientid")) { k, v -> store.setExtra(d.id, k, v) })
        Kind.ANDROID_TV -> AndroidTvControl(AndroidTvRemote(d.host, store.androidTvIdentity()))
        Kind.FREEBOX_PLAYER -> FreeboxPlayer(d.host.ifBlank { "hd1.freebox.fr" }, d.secret)
        Kind.SAMSUNG -> SamsungTv(d.host, d.secret, d.extraJson.optString("mac"))
        Kind.LG -> LgTv(d.host, d.secret, d.extraJson.optString("mac"))
        Kind.ROKU -> RokuTv(d.host)
        Kind.INFRAROUGE -> IrTv(store.context, Infrared.brandOf(d))
        else -> null
    }

    /** Client HTTP qui accepte les certificats auto-signés des appareils du réseau local. */
    val lanClient: OkHttpClient by lazy {
        val trustAll = object : X509TrustManager {
            override fun checkClientTrusted(chain: Array<out X509Certificate>?, authType: String?) {}
            override fun checkServerTrusted(chain: Array<out X509Certificate>?, authType: String?) {}
            override fun getAcceptedIssuers(): Array<X509Certificate> = arrayOf()
        }
        val ssl = SSLContext.getInstance("TLS").apply { init(null, arrayOf(trustAll), SecureRandom()) }
        OkHttpClient.Builder()
            .sslSocketFactory(ssl.socketFactory, trustAll)
            .hostnameVerifier { _, _ -> true }
            .connectTimeout(4, TimeUnit.SECONDS)
            .readTimeout(70, TimeUnit.SECONDS)
            .build()
    }

    /** Réveil par le réseau (Wake-on-LAN) quand l'adresse matérielle est connue. */
    fun wakeOnLan(mac: String, ip: String) {
        val hex = mac.replace(":", "").replace("-", "")
        if (hex.length != 12) return
        runCatching {
            val macBytes = ByteArray(6) { hex.substring(it * 2, it * 2 + 2).toInt(16).toByte() }
            val packet = ByteArray(6) { 0xFF.toByte() } + (1..16).flatMap { macBytes.toList() }.toByteArray()
            DatagramSocket().use { s ->
                s.broadcast = true
                listOf("255.255.255.255", ip.substringBeforeLast('.') + ".255").forEach { addr ->
                    s.send(DatagramPacket(packet, packet.size, InetAddress.getByName(addr), 9))
                }
            }
        }
    }

    fun norm(s: String) = TextNorm.norm(s).replace(Regex("[^a-z0-9+ ]"), " ").replace(Regex("\\s+"), " ").trim()
}

/** WebSocket simple et bloquant : on envoie, on lit les messages un par un. */
class SimpleWs(url: String) {
    private val queue = LinkedBlockingQueue<String>()
    @Volatile var failure: String? = null
    private val ws: WebSocket = TvDrivers.lanClient.newWebSocket(Request.Builder().url(url).build(), object : WebSocketListener() {
        override fun onMessage(webSocket: WebSocket, text: String) { queue.put(text) }
        override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
            failure = t.message ?: t.javaClass.simpleName
            queue.put("__failure__")
        }
        override fun onClosed(webSocket: WebSocket, code: Int, reason: String) { queue.put("__closed__") }
    })

    fun send(text: String) = ws.send(text)

    /** Prochain message, ou null après [timeoutMs] / en cas d'erreur. */
    fun next(timeoutMs: Long): String? {
        val m = queue.poll(timeoutMs, TimeUnit.MILLISECONDS) ?: return null
        return if (m.startsWith("__")) null else m
    }

    fun close() = ws.close(1000, null)
}

// ---------------------------------------------------------------------------------------------- Orange

class OrangeTv(private val d: OrangeDecoder) : TvControl {
    override suspend fun power(on: Boolean) = if (on) d.powerOn() else d.powerOff()
    override suspend fun volume(steps: Int): Boolean {
        if (steps == 0) return d.key(OrangeDecoder.MUTE)
        var ok = true
        repeat(kotlin.math.abs(steps).coerceAtMost(20)) { ok = ok && d.key(if (steps > 0) OrangeDecoder.VOL_UP else OrangeDecoder.VOL_DOWN) }
        return ok
    }
    override suspend fun channel(number: Int, named: OrangeDecoder.Channel?): Boolean {
        if (d.isOn() == false) d.powerOn()
        return (named != null && d.channel(named)) || d.channelNumber(number)
    }
    override suspend fun channelStep(up: Boolean) = d.key(if (up) OrangeDecoder.CH_UP else OrangeDecoder.CH_DOWN)
    override suspend fun playPause() = d.key(OrangeDecoder.PLAY_PAUSE)
}

// ---------------------------------------------------------------------------------------------- Freebox Player

/** Télécommande réseau des Freebox Player « historiques » (code à 8 chiffres affiché dans les réglages du Player). */
class FreeboxPlayer(private val host: String, private val code: String) : TvControl {
    private fun key(k: String) = Http.get("http://$host/pub/remote_control?code=$code&key=$k", 4000) != null

    override suspend fun power(on: Boolean) = key("power") // bascule : la Freebox ne dit pas si elle est allumée
    override suspend fun volume(steps: Int): Boolean {
        if (steps == 0) return key("mute")
        var ok = true
        repeat(kotlin.math.abs(steps).coerceAtMost(20)) { ok = ok && key(if (steps > 0) "vol_inc" else "vol_dec") }
        return ok
    }
    override suspend fun channel(number: Int, named: OrangeDecoder.Channel?): Boolean {
        number.toString().forEach { if (!key(it.toString())) return false; delay(150) }
        return true
    }
    override suspend fun channelStep(up: Boolean) = key(if (up) "prgm_inc" else "prgm_dec")
    override suspend fun playPause() = key("play")
}

// ---------------------------------------------------------------------------------------------- Android TV

class AndroidTvControl(private val r: AndroidTvRemote) : TvControl {
    private fun keys(vararg k: Int) = runCatching { r.run(k, null, 120) }.isSuccess

    override suspend fun power(on: Boolean): Boolean = runCatching {
        val state = r.run(IntArray(0), null, 0).isOn
        if (state == null || state != on) r.run(intArrayOf(AndroidTvRemote.KEY_POWER), null, 0)
        true
    }.getOrDefault(false)

    override suspend fun volume(steps: Int): Boolean {
        if (steps == 0) return keys(AndroidTvRemote.KEY_MUTE)
        val k = if (steps > 0) AndroidTvRemote.KEY_VOLUME_UP else AndroidTvRemote.KEY_VOLUME_DOWN
        return keys(*IntArray(kotlin.math.abs(steps).coerceAtMost(20)) { k })
    }

    override suspend fun channel(number: Int, named: OrangeDecoder.Channel?) =
        keys(*number.toString().map { AndroidTvRemote.KEY_0 + it.digitToInt() }.toIntArray())

    override suspend fun channelStep(up: Boolean) = keys(if (up) AndroidTvRemote.KEY_CHANNEL_UP else AndroidTvRemote.KEY_CHANNEL_DOWN)
    override suspend fun playPause() = keys(AndroidTvRemote.KEY_PLAY_PAUSE)

    override suspend fun openApp(name: String): String? {
        val n = TvDrivers.norm(name)
        val (label, link) = APPS.entries.firstOrNull { (k, _) -> n.contains(k) || k.contains(n) }?.let { it.value } ?: return null
        return if (runCatching { r.run(IntArray(0), link, 0) }.isSuccess) label else null
    }

    override suspend fun hdmi(port: Int): Boolean = keys(AndroidTvRemote.KEY_TV_INPUT)

    companion object {
        /** Applis courantes et le lien qui les ouvre sur Android TV. */
        val APPS = linkedMapOf(
            "netflix" to ("Netflix" to "https://www.netflix.com/title"),
            "youtube" to ("YouTube" to "https://www.youtube.com"),
            "prime" to ("Prime Video" to "https://app.primevideo.com"),
            "disney" to ("Disney+" to "https://www.disneyplus.com"),
            "spotify" to ("Spotify" to "spotify://"),
            "molotov" to ("Molotov" to "market://launch?id=tv.molotov.app"),
            "canal" to ("myCANAL" to "market://launch?id=com.canal.android.canal"),
            "france tv" to ("france.tv" to "market://launch?id=fr.francetv.pluzz"),
            "arte" to ("Arte" to "market://launch?id=tv.arte.plus7"),
            "twitch" to ("Twitch" to "https://www.twitch.tv"),
            "plex" to ("Plex" to "market://launch?id=com.plexapp.android"),
            "kodi" to ("Kodi" to "market://launch?id=org.xbmc.kodi"),
        )
    }
}

// ---------------------------------------------------------------------------------------------- Sony Bravia

class BraviaControl(private val tv: BraviaTv) : TvControl {
    override suspend fun power(on: Boolean) = if (on) tv.powerOn() else tv.powerOff()
    override suspend fun volume(steps: Int) = if (steps == 0) tv.key("Mute") else tv.volume(if (steps > 0) "+$steps" else "$steps")
    override suspend fun channel(number: Int, named: OrangeDecoder.Channel?): Boolean {
        number.toString().forEach { if (!tv.key("Num$it")) return false; delay(150) }
        return true
    }
    override suspend fun channelStep(up: Boolean) = tv.key(if (up) "ChannelUp" else "ChannelDown")
    override suspend fun playPause() = tv.key("Pause") || tv.key("Play")
    override suspend fun openApp(name: String): String? {
        val n = TvDrivers.norm(name)
        val app = tv.apps().firstOrNull { TvDrivers.norm(it.title) == n }
            ?: tv.apps().firstOrNull { TvDrivers.norm(it.title).contains(n) || n.contains(TvDrivers.norm(it.title)) }
            ?: return null
        if (tv.isOn() == false) tv.powerOn()
        return if (tv.openApp(app)) app.title else null
    }
    override suspend fun hdmi(port: Int) = tv.hdmi(port)
}

// ---------------------------------------------------------------------------------------------- Samsung

/** Téléviseurs Samsung récents (Tizen, 2016 et après) : télécommande par WebSocket, autorisée une fois sur la télé. */
class SamsungTv(private val host: String, private val token: String, private val mac: String) : TvControl {
    companion object {
        private val NAME = Base64.encodeToString("Calepin IA".toByteArray(), Base64.NO_WRAP)

        fun probe(host: String): Boolean = (Http.get("http://$host:8001/api/v2/", 1500, 400) ?: "").let { "Samsung" in it || "\"device\"" in it }

        /** Demande l'autorisation (fenêtre sur la télé) et renvoie le jeton, ou une erreur. */
        fun pair(host: String): Result<String> = runCatching {
            val ws = SimpleWs("wss://$host:8002/api/v2/channels/samsung.remote.control?name=$NAME")
            try {
                val deadline = System.currentTimeMillis() + 45_000
                while (System.currentTimeMillis() < deadline) {
                    val m = ws.next(2000) ?: if (ws.failure != null) error(ws.failure!!) else continue
                    val o = JSONObject(m)
                    if (o.optString("event") == "ms.channel.connect") return@runCatching o.optJSONObject("data")?.optString("token").orEmpty()
                    if (o.optString("event") == "ms.channel.unauthorized") error("demande refusée sur la télé")
                }
                error("pas de réponse de la télé")
            } finally {
                ws.close()
            }
        }
    }

    private fun send(vararg keys: String): Boolean = runCatching {
        val url = "wss://$host:8002/api/v2/channels/samsung.remote.control?name=$NAME" + if (token.isNotBlank()) "&token=$token" else ""
        val ws = SimpleWs(url)
        try {
            val first = ws.next(6000) ?: error(ws.failure ?: "pas de réponse")
            if (!first.contains("ms.channel.connect")) error("connexion refusée")
            keys.forEach { k ->
                ws.send(
                    JSONObject().put("method", "ms.remote.control").put(
                        "params",
                        JSONObject().put("Cmd", "Click").put("DataOfCmd", k).put("Option", "false").put("TypeOfRemote", "SendRemoteKey"),
                    ).toString()
                )
                Thread.sleep(150)
            }
            Thread.sleep(300)
        } finally {
            ws.close()
        }
    }.isSuccess

    private fun isOn(): Boolean? = Http.get("http://$host:8001/api/v2/", 1500)?.let {
        runCatching { JSONObject(it).optJSONObject("device")?.optString("PowerState") }.getOrNull()?.let { s -> s == "on" } ?: true
    }

    override suspend fun power(on: Boolean): Boolean {
        val state = isOn()
        if (on) {
            if (state == true) return true
            TvDrivers.wakeOnLan(mac, host)
            delay(1500)
            return isOn() == true || send("KEY_POWER")
        }
        if (state == false) return true
        return send("KEY_POWER")
    }

    override suspend fun volume(steps: Int) =
        if (steps == 0) send("KEY_MUTE") else send(*Array(kotlin.math.abs(steps).coerceAtMost(20)) { if (steps > 0) "KEY_VOLUP" else "KEY_VOLDOWN" })

    override suspend fun channel(number: Int, named: OrangeDecoder.Channel?) =
        send(*(number.toString().map { "KEY_$it" } + "KEY_ENTER").toTypedArray())

    override suspend fun channelStep(up: Boolean) = send(if (up) "KEY_CHUP" else "KEY_CHDOWN")
    override suspend fun playPause() = send("KEY_PLAY")
    override suspend fun hdmi(port: Int) = send("KEY_HDMI$port") || send("KEY_HDMI")
}

// ---------------------------------------------------------------------------------------------- LG webOS

/** Téléviseurs LG webOS : protocole « SSAP » par WebSocket, autorisé une fois sur la télé (clé client). */
class LgTv(private val host: String, private val clientKey: String, private val mac: String) : TvControl {
    companion object {
        private val PERMISSIONS = listOf(
            "APP_TO_APP", "CLOSE", "CONTROL_AUDIO", "CONTROL_DISPLAY", "CONTROL_INPUT_JOYSTICK", "CONTROL_INPUT_MEDIA_PLAYBACK",
            "CONTROL_INPUT_MEDIA_RECORDING", "CONTROL_INPUT_TEXT", "CONTROL_INPUT_TV", "CONTROL_MOUSE_AND_KEYBOARD", "CONTROL_POWER",
            "CONTROL_TV_SCREEN", "LAUNCH", "LAUNCH_WEBAPP", "READ_APP_STATUS", "READ_COUNTRY_INFO", "READ_CURRENT_CHANNEL",
            "READ_INPUT_DEVICE_LIST", "READ_INSTALLED_APPS", "READ_LGE_SDX", "READ_LGE_TV_INPUT_EVENTS", "READ_NETWORK_STATE",
            "READ_NOTIFICATIONS", "READ_POWER_STATE", "READ_RUNNING_APPS", "READ_SETTINGS", "READ_TV_CHANNEL_LIST",
            "READ_TV_CURRENT_TIME", "READ_UPDATE_INFO", "SEARCH", "TEST_OPEN", "TEST_PROTECTED", "TEST_SECURE",
            "UPDATE_FROM_REMOTE_APP", "WRITE_NOTIFICATION_ALERT", "WRITE_NOTIFICATION_TOAST", "WRITE_SETTINGS",
        )

        private fun registration(key: String): String = JSONObject()
            .put("type", "register").put("id", "register_0")
            .put(
                "payload",
                JSONObject().put("forcePairing", false).put("pairingType", "PROMPT")
                    .apply { if (key.isNotBlank()) put("client-key", key) }
                    .put("manifest", JSONObject().put("appVersion", "1.1").put("manifestVersion", 1).put("permissions", JSONArray(PERMISSIONS))),
            ).toString()

        /**
         * Connexion (et autorisation sur la télé si besoin) ; renvoie la clé client.
         * Essaie d'abord sans chiffrement (port 3000), puis chiffré (port 3001) comme l'exigent les télés récentes.
         */
        fun connect(host: String, key: String, timeoutMs: Long): Pair<SimpleWs, String> {
            var lastError = "pas de réponse de la télé"
            for (url in listOf("ws://$host:3000", "wss://$host:3001")) {
                val ws = SimpleWs(url)
                ws.send(registration(key))
                val deadline = System.currentTimeMillis() + timeoutMs
                var failed = false
                while (!failed && System.currentTimeMillis() < deadline) {
                    val m = ws.next(1500)
                    if (m == null) {
                        if (ws.failure != null) { lastError = ws.failure!!; failed = true }
                        continue
                    }
                    val o = runCatching { JSONObject(m) }.getOrNull() ?: continue
                    when (o.optString("type")) {
                        "registered" -> return ws to o.optJSONObject("payload")?.optString("client-key").orEmpty().ifBlank { key }
                        "error" -> { ws.close(); error(o.optString("error", "refusé par la télé")) }
                    }
                }
                ws.close()
                if (!failed) break // la télé a répondu mais pas autorisé à temps
            }
            error(lastError)
        }

        fun pair(host: String): Result<String> = runCatching {
            val (ws, key) = connect(host, "", 60_000)
            ws.close()
            key
        }
    }

    private fun request(vararg calls: Pair<String, JSONObject?>): List<JSONObject?> {
        val (ws, _) = connect(host, clientKey, 8000)
        try {
            return calls.mapIndexed { i, (uri, payload) ->
                val id = "c$i"
                ws.send(JSONObject().put("type", "request").put("id", id).put("uri", "ssap://$uri").put("payload", payload ?: JSONObject()).toString())
                var res: JSONObject? = null
                val deadline = System.currentTimeMillis() + 5000
                while (res == null && System.currentTimeMillis() < deadline) {
                    val m = ws.next(1000) ?: continue
                    val o = runCatching { JSONObject(m) }.getOrNull() ?: continue
                    if (o.optString("id") == id) res = o
                }
                res
            }
        } finally {
            ws.close()
        }
    }

    private fun ok(uri: String, payload: JSONObject? = null) = runCatching {
        request(uri to payload).firstOrNull()?.optString("type") == "response"
    }.getOrDefault(false)

    override suspend fun power(on: Boolean): Boolean {
        if (on) {
            TvDrivers.wakeOnLan(mac, host)
            delay(2000)
            return runCatching { connect(host, clientKey, 4000).first.close(); true }.getOrDefault(false)
        }
        return ok("system/turnOff")
    }

    override suspend fun volume(steps: Int): Boolean {
        if (steps == 0) {
            val muted = runCatching { request("audio/getStatus" to null).firstOrNull()?.optJSONObject("payload")?.optBoolean("mute") }.getOrNull() ?: false
            return ok("audio/setMute", JSONObject().put("mute", !muted))
        }
        val uri = if (steps > 0) "audio/volumeUp" else "audio/volumeDown"
        return runCatching { request(*Array(kotlin.math.abs(steps).coerceAtMost(20)) { uri to null }) }.isSuccess
    }

    override suspend fun channel(number: Int, named: OrangeDecoder.Channel?) = ok("tv/openChannel", JSONObject().put("channelNumber", number.toString()))
    override suspend fun channelStep(up: Boolean) = ok(if (up) "tv/channelUp" else "tv/channelDown")
    override suspend fun playPause() = ok("media.controls/play")

    override suspend fun openApp(name: String): String? = runCatching {
        val list = request("com.webos.applicationManager/listLaunchPoints" to null).firstOrNull()
            ?.optJSONObject("payload")?.optJSONArray("launchPoints") ?: return null
        val n = TvDrivers.norm(name)
        val apps = (0 until list.length()).mapNotNull { list.optJSONObject(it) }
        val app = apps.firstOrNull { TvDrivers.norm(it.optString("title")) == n }
            ?: apps.firstOrNull { TvDrivers.norm(it.optString("title")).let { t -> t.contains(n) || n.contains(t) } } ?: return null
        if (ok("system.launcher/launch", JSONObject().put("id", app.optString("id")))) app.optString("title") else null
    }.getOrNull()

    override suspend fun hdmi(port: Int) = ok("tv/switchInput", JSONObject().put("inputId", "HDMI_$port"))
}

// ---------------------------------------------------------------------------------------------- Roku

class RokuTv(private val host: String) : TvControl {
    companion object {
        fun probe(host: String) = (Http.get("http://$host:8060/query/device-info", 1500, 400) ?: "").contains("<device-info")
    }

    private fun key(k: String) = Http.post("http://$host:8060/keypress/$k", "", emptyMap(), 4000) != null

    override suspend fun power(on: Boolean) = key(if (on) "PowerOn" else "PowerOff")
    override suspend fun volume(steps: Int): Boolean {
        if (steps == 0) return key("VolumeMute")
        var ok = true
        repeat(kotlin.math.abs(steps).coerceAtMost(20)) { ok = ok && key(if (steps > 0) "VolumeUp" else "VolumeDown") }
        return ok
    }
    override suspend fun channel(number: Int, named: OrangeDecoder.Channel?) = false
    override suspend fun channelStep(up: Boolean) = key(if (up) "ChannelUp" else "ChannelDown")
    override suspend fun playPause() = key("Play")
    override suspend fun openApp(name: String): String? {
        val xml = Http.get("http://$host:8060/query/apps", 4000) ?: return null
        val n = TvDrivers.norm(name)
        val m = Regex("<app id=\"(\\d+)\"[^>]*>([^<]+)</app>").findAll(xml)
            .firstOrNull { TvDrivers.norm(it.groupValues[2]).let { t -> t == n || t.contains(n) || n.contains(t) } } ?: return null
        return if (Http.post("http://$host:8060/launch/${m.groupValues[1]}", "", emptyMap(), 4000) != null) m.groupValues[2] else null
    }
}
