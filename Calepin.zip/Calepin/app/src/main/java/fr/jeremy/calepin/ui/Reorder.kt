package fr.jeremy.calepin.ui

import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectDragGesturesAfterLongPress
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DragIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.boundsInRoot
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.unit.dp
import androidx.compose.ui.zIndex
import kotlinx.coroutines.delay

/**
 * Glisser-déposer pour toutes les listes de Calepin (colonnes, grilles, listes défilantes).
 *
 * Chaque élément déplaçable porte [reorderItem] ; on le saisit par un appui long (ou par sa poignée,
 * [DragHandle]) et on le lâche sur un autre élément : [onMove] reçoit les deux clés. D'autres endroits
 * peuvent recevoir un élément sans être déplaçables eux-mêmes ([dropTarget], ex. un dossier) : [onDrop].
 * Près du bord de la liste, elle défile toute seule ([ReorderAutoScroll]).
 */
class ReorderState(
    private val onMoveState: androidx.compose.runtime.State<(Any, Any) -> Unit>,
    private val onDropState: androidx.compose.runtime.State<(Any, Any) -> Unit>,
) {
    internal val bounds = mutableStateMapOf<Any, Rect>()
    internal val targets = mutableStateMapOf<Any, Rect>()
    /** Élément en cours de déplacement. */
    var dragging by mutableStateOf<Any?>(null); private set
    /** Élément ou endroit sous le doigt. */
    var hover by mutableStateOf<Any?>(null); private set
    internal var pointer by mutableStateOf(Offset.Zero)
    private var grab = Offset.Zero
    private var size = Offset.Zero
    /** Zone visible de la liste (pour le défilement automatique). */
    internal var viewport by mutableStateOf<Rect?>(null)

    val isDragging: Boolean get() = dragging != null

    internal fun start(key: Any, local: Offset) {
        val b = bounds[key] ?: return
        dragging = key
        grab = local
        size = Offset(b.width, b.height)
        pointer = b.topLeft + local
        hover = null
    }

    internal fun drag(delta: Offset) {
        pointer += delta
        retarget()
    }

    /** Ce qu'il y a sous le centre de l'élément déplacé (les endroits de dépôt d'abord). */
    internal fun retarget() {
        val d = dragging ?: return
        val c = pointer - grab + size / 2f
        hover = targets.entries.firstOrNull { it.value.contains(c) }?.key
            ?: bounds.entries.firstOrNull { it.key != d && it.value.contains(c) }?.key
    }

    internal fun end() {
        val from = dragging
        val to = hover
        dragging = null
        hover = null
        if (from == null || to == null || from == to) return
        if (to in targets) onDropState.value(from, to) else onMoveState.value(from, to)
    }

    internal fun cancel() { dragging = null; hover = null }

    /** Décalage à appliquer à l'élément déplacé : il suit le doigt, même si la liste défile. */
    internal fun translation(key: Any): Offset {
        if (dragging != key) return Offset.Zero
        val b = bounds[key] ?: return Offset.Zero
        return pointer - grab - b.topLeft
    }
}

@Composable
fun rememberReorderState(onDrop: (from: Any, target: Any) -> Unit = { _, _ -> }, onMove: (from: Any, to: Any) -> Unit): ReorderState {
    val m = rememberUpdatedState(onMove)
    val d = rememberUpdatedState(onDrop)
    return remember { ReorderState(m, d) }
}

/** Liste qui défile : sa zone visible, pour le défilement automatique pendant un déplacement. */
fun Modifier.reorderContainer(state: ReorderState): Modifier =
    onGloballyPositioned { state.viewport = it.boundsInRoot() }

/**
 * Élément déplaçable. [handleOnly] : seule la poignée ([DragHandle]) le saisit (quand l'appui long sert déjà
 * à autre chose) ; sinon un appui long sur l'élément le saisit.
 */
fun Modifier.reorderItem(state: ReorderState, key: Any, enabled: Boolean = true, handleOnly: Boolean = false): Modifier = composed {
    val haptic = LocalHapticFeedback.current
    // Élément qui quitte l'écran (liste qui défile) : il ne compte plus comme cible
    androidx.compose.runtime.DisposableEffect(key) { onDispose { state.bounds.remove(key) } }
    val dragging = state.dragging == key
    val hovered = state.hover == key && state.dragging != null
    val cs = MaterialTheme.colorScheme
    this
        .onGloballyPositioned { c -> state.bounds[key] = Rect(c.positionInRoot(), androidx.compose.ui.geometry.Size(c.size.width.toFloat(), c.size.height.toFloat())) }
        .zIndex(if (dragging) 10f else 0f)
        .graphicsLayer {
            val t = state.translation(key)
            translationX = t.x
            translationY = t.y
            if (dragging) { shadowElevation = 16f; alpha = 0.92f }
        }
        .then(if (hovered) Modifier.border(2.dp, cs.primary, MaterialTheme.shapes.medium) else Modifier)
        .then(
            if (!enabled || handleOnly) Modifier
            else Modifier.pointerInput(key) {
                detectDragGesturesAfterLongPress(
                    onDragStart = { haptic.performHapticFeedback(HapticFeedbackType.LongPress); state.start(key, it) },
                    onDrag = { ch, d -> ch.consume(); state.drag(d) },
                    onDragEnd = { state.end() },
                    onDragCancel = { state.cancel() },
                )
            }
        )
}

/** Endroit qui reçoit un élément sans être déplaçable (dossier, corbeille…). */
fun Modifier.dropTarget(state: ReorderState, key: Any): Modifier = composed {
    androidx.compose.runtime.DisposableEffect(key) { onDispose { state.targets.remove(key) } }
    val hovered = state.hover == key && state.dragging != null
    val cs = MaterialTheme.colorScheme
    this
        .onGloballyPositioned { c -> state.targets[key] = Rect(c.positionInRoot(), androidx.compose.ui.geometry.Size(c.size.width.toFloat(), c.size.height.toFloat())) }
        .then(if (hovered) Modifier.border(3.dp, cs.primary, MaterialTheme.shapes.medium) else Modifier)
}

/**
 * Poignée de l'élément [key] : on la fait glisser directement (sans appui long). Sa position dans l'élément
 * est mesurée pour que l'élément suive exactement le doigt.
 */
@Composable
fun DragHandle(state: ReorderState, key: Any, modifier: Modifier = Modifier) {
    val haptic = LocalHapticFeedback.current
    var origin by remember { mutableStateOf(Offset.Zero) }
    Box(
        modifier
            .clip(MaterialTheme.shapes.small)
            .onGloballyPositioned { origin = it.positionInRoot() }
            .pointerInput(key) {
                detectDragGestures(
                    onDragStart = { p ->
                        haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                        val item = state.bounds[key]
                        state.start(key, if (item != null) origin + p - item.topLeft else p)
                    },
                    onDrag = { ch, d -> ch.consume(); state.drag(d) },
                    onDragEnd = { state.end() },
                    onDragCancel = { state.cancel() },
                )
            }
            .padding(8.dp),
    ) {
        Icon(Icons.Filled.DragIndicator, "Déplacer", Modifier.size(20.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

/** Défilement automatique quand on approche le bord de la liste avec un élément. */
@Composable
fun ReorderAutoScroll(state: ReorderState, scrollBy: suspend (Float) -> Float) {
    val edge = with(LocalDensity.current) { 64.dp.toPx() }
    val scroll by rememberUpdatedState(scrollBy)
    LaunchedEffect(state.dragging) {
        if (state.dragging == null) return@LaunchedEffect
        while (state.dragging != null) {
            val v = state.viewport
            if (v != null) {
                val y = state.pointer.y
                val speed = when {
                    y < v.top + edge -> -(v.top + edge - y).coerceAtMost(edge) / 3f
                    y > v.bottom - edge -> (y - (v.bottom - edge)).coerceAtMost(edge) / 3f
                    else -> 0f
                }
                if (speed != 0f) {
                    runCatching { scroll(speed) }
                    state.retarget()
                }
            }
            delay(16)
        }
    }
}

/** Liste avec l'élément [from] déplacé à la place de [to]. */
fun <T> List<T>.moved(from: Int, to: Int): List<T> {
    if (from !in indices || to !in indices || from == to) return this
    val m = toMutableList()
    val x = m.removeAt(from)
    m.add(to, x)
    return m
}

/** Même chose avec les clés des éléments. */
fun <T> List<T>.movedByKey(key: (T) -> Any, from: Any, to: Any): List<T> =
    moved(indexOfFirst { key(it) == from }, indexOfFirst { key(it) == to })
