package fr.jeremy.calepin.ui

import android.app.Activity
import android.os.Build
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import fr.jeremy.calepin.AudioFormat
import fr.jeremy.calepin.audio.Transcriber
import androidx.compose.material3.LinearProgressIndicator
import fr.jeremy.calepin.reminders.Reminders
import android.media.RingtoneManager
import android.net.Uri
import androidx.core.content.IntentCompat
import fr.jeremy.calepin.BuildConfig
import fr.jeremy.calepin.DisplayMode
import fr.jeremy.calepin.LockGuard
import fr.jeremy.calepin.NotesViewModel
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun SettingsScreen(vm: NotesViewModel, onClose: () -> Unit) {
    val s = vm.settings
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val display by s.display.collectAsStateWithLifecycle()
    val audioFormat by s.audioFormat.collectAsStateWithLifecycle()
    val bitrate by s.audioBitrate.collectAsStateWithLifecycle()
    val pinOn by s.pinEnabled.collectAsStateWithLifecycle()
    val bioOn by s.bioEnabled.collectAsStateWithLifecycle()
    val delay by s.lockDelay.collectAsStateWithLifecycle()
    val hide by s.hideInRecents.collectAsStateWithLifecycle()
    var pinDialog by remember { mutableStateOf(false) }
    var exportAll by remember { mutableStateOf(false) }
    val bioAvailable = remember { Bio.available(ctx) }
    val ringtone by s.ringtone.collectAsStateWithLifecycle()
    var modelInstalled by remember { mutableStateOf(Transcriber.isInstalled(ctx)) }
    var downloading by remember { mutableStateOf<Float?>(null) }
    val voiceOn by s.assistantVoice.collectAsStateWithLifecycle()
    val offlineOn by s.assistantOffline.collectAsStateWithLifecycle()
    val rate by s.speechRate.collectAsStateWithLifecycle()
    val briefingOn by s.briefingEnabled.collectAsStateWithLifecycle()
    val briefingTime by s.briefingTime.collectAsStateWithLifecycle()
    val notifPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    val ringPicker = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { res ->
        if (res.resultCode == Activity.RESULT_OK) {
            val uri = res.data?.let { IntentCompat.getParcelableExtra(it, RingtoneManager.EXTRA_RINGTONE_PICKED_URI, Uri::class.java) }
            s.setRingtone(uri?.toString() ?: "")
        }
    }

    BackHandler { onClose() }

    val restore = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { res ->
        val uri = res.data?.data
        if (res.resultCode == Activity.RESULT_OK && uri != null) {
            scope.launch {
                val msg = try {
                    val text = ctx.contentResolver.openInputStream(uri)?.use { it.readBytes().toString(Charsets.UTF_8) } ?: ""
                    val n = vm.restore(text)
                    if (n == 0) "Aucune nouvelle note : tout était déjà présent" else "$n note${if (n > 1) "s" else ""} restaurée${if (n > 1) "s" else ""}"
                } catch (e: Exception) {
                    "Fichier illisible : choisissez une sauvegarde .json créée par Calepin"
                }
                Toast.makeText(ctx, msg, Toast.LENGTH_LONG).show()
            }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Paramètres") },
                navigationIcon = {
                    IconButton(onClick = onClose) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Retour") }
                },
            )
        },
    ) { pad ->
        Column(
            Modifier
                .fillMaxSize()
                .padding(pad)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp)
                .padding(bottom = 40.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            Section("Affichage des notes")
            DisplayMode.entries.forEach { m ->
                RadioRow(m.label, display == m) { s.setDisplay(m) }
            }

            HorizontalDivider()
            Section("Mémos vocaux")
            Text("Format des nouveaux enregistrements", style = MaterialTheme.typography.bodyMedium)
            AudioFormat.entries.forEach { f -> RadioRow(f.label, audioFormat == f) { s.setAudioFormat(f) } }
            Text("Qualité", style = MaterialTheme.typography.bodyMedium)
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(64 to "Voix · 64 kb/s", 128 to "Standard · 128 kb/s", 192 to "Haute · 192 kb/s").forEach { (k, label) ->
                    FilterChip(selected = bitrate == k, onClick = { s.setAudioBitrate(k) }, label = { Text(label) })
                }
            }
            Hint("Le M4A est le format natif d'Android : léger et lisible partout. Le MP3 est le plus universel pour les vieux lecteurs.")

            Text("Module vocal français (transcription et assistant hors ligne)", style = MaterialTheme.typography.bodyMedium)
            if (modelInstalled) {
                Hint("Installé : transcription des mémos et écoute de l'assistant fonctionnent sans connexion.")
                TextButton(onClick = { Transcriber.remove(ctx); modelInstalled = false }) {
                    Text("Supprimer le module (libère ~50 Mo)")
                }
            } else if (downloading != null) {
                LinearProgressIndicator(progress = { downloading ?: 0f }, modifier = Modifier.fillMaxWidth())
                Hint("Téléchargement… ${((downloading ?: 0f) * 100).toInt()} %")
            } else {
                TextButton(onClick = {
                    downloading = 0f
                    scope.launch {
                        try {
                            Transcriber.download(ctx) { p -> downloading = p }
                            modelInstalled = true
                        } catch (e: Exception) {
                            Toast.makeText(ctx, "Téléchargement impossible. Vérifiez la connexion.", Toast.LENGTH_LONG).show()
                        }
                        downloading = null
                    }
                }) { Text("Installer le module (${Transcriber.MODEL_SIZE_MB} Mo, une seule fois, en Wi-Fi de préférence)") }
            }

            HorizontalDivider()
            Section("Assistant")
            SwitchRow("Réponses à voix haute", "L'assistant lit ses réponses (voix française du téléphone)", voiceOn) {
                s.setAssistantVoice(it)
            }
            SwitchRow(
                "Écoute hors ligne",
                if (modelInstalled) "Avec le module vocal français, sans Internet" else "Nécessite le module vocal ci-dessus",
                offlineOn,
            ) { s.setAssistantOffline(it) }
            Text("Vitesse de la voix", style = MaterialTheme.typography.bodyMedium)
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(0.85f to "Lente", 1.0f to "Normale", 1.2f to "Rapide").forEach { (r, label) ->
                    FilterChip(selected = kotlin.math.abs(rate - r) < 0.01f, onClick = { s.setSpeechRate(r) }, label = { Text(label) })
                }
            }
            SwitchRow(
                "Briefing du matin",
                "Chaque jour, une notification résume ta journée : rendez-vous, prochaine vacation",
                briefingOn,
            ) { on ->
                s.setBriefingEnabled(on)
                if (on && Build.VERSION.SDK_INT >= 33) {
                    LockGuard.external()
                    notifPermission.launch(android.Manifest.permission.POST_NOTIFICATIONS)
                }
                fr.jeremy.calepin.assistant.Briefing.schedule(ctx)
            }
            if (briefingOn) {
                TextButton(onClick = {
                    android.app.TimePickerDialog(ctx, { _, h, m ->
                        s.setBriefingTime(h * 60 + m)
                        fr.jeremy.calepin.assistant.Briefing.schedule(ctx)
                    }, briefingTime / 60, briefingTime % 60, true).show()
                }) { Text("Heure du briefing : %d h %02d".format(briefingTime / 60, briefingTime % 60)) }
            }

            HorizontalDivider()
            Section("Rappels et alarmes")
            Text("Sonnerie par défaut des nouveaux rappels", style = MaterialTheme.typography.bodyMedium)
            TextButton(onClick = {
                LockGuard.external()
                ringPicker.launch(
                    android.content.Intent(RingtoneManager.ACTION_RINGTONE_PICKER).apply {
                        putExtra(RingtoneManager.EXTRA_RINGTONE_TYPE, RingtoneManager.TYPE_ALARM or RingtoneManager.TYPE_RINGTONE or RingtoneManager.TYPE_NOTIFICATION)
                        putExtra(RingtoneManager.EXTRA_RINGTONE_TITLE, "Sonnerie par défaut")
                        putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_DEFAULT, true)
                        putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_SILENT, false)
                        if (ringtone.isNotBlank()) putExtra(RingtoneManager.EXTRA_RINGTONE_EXISTING_URI, Uri.parse(ringtone))
                    }
                )
            }) { Text(Reminders.ringtoneName(ctx, ringtone)) }
            if (!Reminders.canExact(ctx) && Build.VERSION.SDK_INT >= 31) {
                TextButton(onClick = {
                    LockGuard.external()
                    ctx.startActivity(
                        android.content.Intent(android.provider.Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:" + ctx.packageName))
                    )
                }) { Text("Autoriser les rappels à l'heure exacte") }
            }
            Hint(
                "Chaque rendez-vous peut avoir sa propre sonnerie. « Alarme » sonne en boucle, même téléphone verrouillé, " +
                    "jusqu'à « Arrêter » ou « Répéter dans 5 minutes ». « Notification » émet un seul son."
            )

            HorizontalDivider()
            Section("Sécurité à l'ouverture")
            SwitchRow(
                "Code PIN",
                if (pinOn) "Activé · 4 à 8 chiffres" else "Désactivé",
                pinOn,
            ) { on -> if (on) pinDialog = true else { s.clearPin(); if (!canBioAlone(ctx)) s.setBio(false) } }
            if (pinOn) {
                TextButton(onClick = { pinDialog = true }) { Text("Changer le code PIN") }
            }
            SwitchRow(
                "Empreinte digitale ou visage",
                when {
                    !bioAvailable -> "Aucune empreinte ni visage enregistré dans les paramètres du téléphone"
                    !pinOn && !canBioAlone(ctx) -> "Définissez d'abord un code PIN (solution de secours)"
                    else -> "Selon ce que votre téléphone propose"
                },
                bioOn,
                enabled = bioAvailable && (pinOn || canBioAlone(ctx)),
            ) { on -> s.setBio(on) }
            if (pinOn || bioOn) {
                Text("Reverrouiller après être sorti de l'appli", style = MaterialTheme.typography.bodyMedium)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(0 to "Immédiatement", 60 to "1 minute", 300 to "5 minutes", 1800 to "30 minutes").forEach { (sec, label) ->
                        FilterChip(selected = delay == sec, onClick = { s.setLockDelay(sec) }, label = { Text(label) })
                    }
                }
            }
            SwitchRow(
                "Masquer le contenu dans les applis récentes",
                "Empêche aussi les captures d'écran de Calepin",
                hide,
            ) { s.setHideInRecents(it) }
            Hint(
                "Android ne propose pas de déverrouillage par la voix sécurisé : une voix enregistrée pourrait être rejouée. " +
                    "Vous pouvez activer le code PIN, la biométrie, ou les deux (l'un ou l'autre suffit alors pour ouvrir)."
            )

            HorizontalDivider()
            Section("Sauvegarde et export")
            TextButton(onClick = { exportAll = true }) { Text("Exporter toutes les notes (PDF, Word, Excel…)") }
            TextButton(onClick = {
                LockGuard.external()
                restore.launch(
                    android.content.Intent(android.content.Intent.ACTION_OPEN_DOCUMENT).apply {
                        addCategory(android.content.Intent.CATEGORY_OPENABLE)
                        type = "*/*"
                    }
                )
            }) { Text("Restaurer une sauvegarde (.json)") }
            Hint(
                "Pour une sauvegarde complète, exportez au format « Sauvegarde (.json) » et gardez le fichier sur Drive ou par mail. " +
                    "Les mémos vocaux se sauvegardent un par un (« Enregistrer sous… »)."
            )

            HorizontalDivider()
            Text(
                "Calepin · version ${BuildConfig.VERSION_NAME}",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }

    if (pinDialog) {
        PinSetupDialog(
            onDismiss = { pinDialog = false },
            onSave = { pin ->
                s.setPin(pin)
                pinDialog = false
                Toast.makeText(ctx, "Code PIN enregistré", Toast.LENGTH_SHORT).show()
            },
        )
    }
    if (exportAll) {
        ExportSheet(vm, vm.allNotes(), onDismiss = { exportAll = false })
    }
}

/** Sans PIN, la biométrie seule n'est permise que si le code du téléphone peut servir de secours. */
private fun canBioAlone(ctx: android.content.Context) = Build.VERSION.SDK_INT >= 30 && Bio.deviceCredentialFallback(ctx)

@Composable
private fun PinSetupDialog(onDismiss: () -> Unit, onSave: (String) -> Unit) {
    var first by remember { mutableStateOf("") }
    var second by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Choisir un code PIN") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = first,
                    onValueChange = { v -> if (v.length <= 8 && v.all { it.isDigit() }) first = v; error = null },
                    label = { Text("Nouveau code (4 à 8 chiffres)") },
                    singleLine = true,
                    visualTransformation = PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                )
                OutlinedTextField(
                    value = second,
                    onValueChange = { v -> if (v.length <= 8 && v.all { it.isDigit() }) second = v; error = null },
                    label = { Text("Confirmer le code") },
                    singleLine = true,
                    visualTransformation = PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                )
                error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                error = when {
                    first.length < 4 -> "Le code doit avoir au moins 4 chiffres"
                    first != second -> "Les deux codes ne sont pas identiques"
                    else -> null
                }
                if (error == null) onSave(first)
            }) { Text("Enregistrer") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Annuler") } },
    )
}

@Composable
private fun Section(title: String) {
    Text(title, style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary)
}

@Composable
private fun Hint(text: String) {
    Text(text, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
}

@Composable
private fun RadioRow(label: String, selected: Boolean, onClick: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        RadioButton(selected = selected, onClick = onClick)
        Text(label, style = MaterialTheme.typography.bodyLarge)
    }
}

@Composable
private fun SwitchRow(
    title: String,
    subtitle: String?,
    checked: Boolean,
    enabled: Boolean = true,
    onChange: (Boolean) -> Unit,
) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.bodyLarge)
            if (subtitle != null) {
                Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        Switch(checked = checked, onCheckedChange = onChange, enabled = enabled)
    }
}
