package fr.jeremy.calepin.ai

/**
 * Moteur d'IA générative hors ligne. Seule la variante « Calepin IA » en fournit un
 * (voir AiEngineFactory dans src/ia) ; la variante standard renvoie null.
 */
interface AiEngine {
    /**
     * Génère une réponse. [onText] reçoit le texte au fur et à mesure.
     * Le premier appel charge le modèle en mémoire (quelques secondes).
     */
    suspend fun generate(modelPath: String, system: String, prompt: String, onText: (String) -> Unit): String

    /** Interrompt la réponse en cours. */
    fun stop()

    /** Libère la mémoire occupée par le modèle. */
    fun release()
}
