package fr.jeremy.calepin.ai

/**
 * Moteur d'IA générative hors ligne. Seule la variante « Calepin IA » en fournit un
 * (voir AiEngineFactory dans src/ia) ; la variante standard renvoie null.
 */
interface AiEngine {
    /**
     * Génère une réponse. [onText] reçoit le texte au fur et à mesure.
     * Le premier appel charge le modèle en mémoire (quelques secondes).
     */
    suspend fun generate(modelPath: String, system: String, prompt: String, onText: (String) -> Unit): String

    /**
     * Réponse à une question sur une photo ([imagePath] : fichier JPEG). Seuls les modèles qui voient les images
     * (Gemma 4) le savent ; sinon [UnsupportedOperationException].
     */
    suspend fun generateWithImage(modelPath: String, system: String, prompt: String, imagePath: String, onText: (String) -> Unit): String =
        throw UnsupportedOperationException("Ce modèle ne sait pas regarder les photos.")

    /** Interrompt la réponse en cours. */
    fun stop()

    /** Libère la mémoire occupée par le modèle. */
    fun release()
}
