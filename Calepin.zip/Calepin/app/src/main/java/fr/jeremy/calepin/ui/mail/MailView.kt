package fr.jeremy.calepin.ui.mail

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.view.ViewGroup
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.OpenInNew
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import fr.jeremy.calepin.Files
import fr.jeremy.calepin.LockGuard
import fr.jeremy.calepin.i18n.I18n
import fr.jeremy.calepin.i18n.RawText
import fr.jeremy.calepin.i18n.Text
import fr.jeremy.calepin.mail.CID_HOST
import fr.jeremy.calepin.mail.MailAttachment
import fr.jeremy.calepin.mail.MailBody
import fr.jeremy.calepin.mail.Mailto
import fr.jeremy.calepin.mail.cidFromUrl
import fr.jeremy.calepin.mail.mailPage
import fr.jeremy.calepin.mail.parseMailto
import fr.jeremy.calepin.mail.rewriteCids
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

private const val BASE_URL = "https://mail.calepin.invalid/"

/** Pièce jointe affichable comme photo dans le mail. */
internal fun MailAttachment.isPhoto(): Boolean =
    mime.startsWith("image/") || name.substringAfterLast('.', "").lowercase() in setOf("jpg", "jpeg", "png", "gif", "webp", "bmp", "heic", "heif")

/** Ce que l'affichage du mail doit faire d'un lien. */
private class MailLinks(var inline: Map<String, Pair<File, String>>, var onLink: (String) -> Unit, var onLongLink: (String) -> Unit)

/** Ouvre un lien hors de Calepin (navigateur, téléphone, carte…). */
internal fun openExternal(ctx: Context, url: String) {
    LockGuard.external()
    val uri = Uri.parse(url)
    val i = if (uri.scheme.equals("tel", true)) Intent(Intent.ACTION_DIAL, uri) else Intent(Intent.ACTION_VIEW, uri)
    runCatching { ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
        .onFailure { I18n.toast(ctx, I18n.tr("Aucune application pour ouvrir ce lien"), Toast.LENGTH_LONG).show() }
}

private fun hex(c: Color) = "#%06X".format(0xFFFFFF and c.toArgb())

/**
 * Corps du mail comme dans une boîte mail classique : mise en page HTML, photos (intégrées ou sur Internet),
 * liens cliquables (navigateur, « mailto: » vers l'écriture dans Calepin, numéros vers le téléphone).
 * Appui long sur un lien : ouvrir, copier ou partager.
 */
@Composable
fun MailBodyView(b: MailBody, onMailto: (Mailto) -> Unit, modifier: Modifier = Modifier) {
    val ctx = LocalContext.current
    val cs = MaterialTheme.colorScheme
    var longLink by remember { mutableStateOf<String?>(null) }
    val fg = hex(cs.onSurface)
    val bg = hex(cs.surface)
    val link = hex(cs.primary)
    val page = remember(b, fg, bg, link) {
        mailPage(b.html?.let { rewriteCids(it, b.inline.keys) }, b.text.ifBlank { I18n.tr("(mail vide)") }, fg, bg, link)
    }
    val handler = { url: String ->
        when {
            url.startsWith("mailto:", true) -> onMailto(parseMailto(url))
            url.startsWith("javascript:", true) || url.startsWith("about:", true) -> Unit
            else -> openExternal(ctx, url)
        }
    }
    val links = remember { MailLinks(b.inline, handler, { longLink = it }) }
    links.inline = b.inline
    links.onLink = handler
    links.onLongLink = { longLink = it }
    val isHtml = b.html != null

    Surface(
        shape = RoundedCornerShape(12.dp),
        color = if (isHtml) Color.White else Color.Transparent,
        modifier = modifier.fillMaxWidth(),
    ) {
        AndroidView(
            factory = { c ->
                WebView(c).apply {
                    layoutParams = ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
                    // Pas de JavaScript ni d'accès aux fichiers : un mail ne peut rien exécuter dans Calepin
                    settings.javaScriptEnabled = false
                    settings.allowFileAccess = false
                    settings.allowContentAccess = false
                    settings.loadsImagesAutomatically = true
                    settings.blockNetworkImage = false
                    settings.mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
                    settings.setSupportZoom(false)
                    settings.builtInZoomControls = false
                    isVerticalScrollBarEnabled = false
                    setBackgroundColor(android.graphics.Color.TRANSPARENT)
                    webViewClient = object : WebViewClient() {
                        override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                            val url = request.url.toString()
                            // Lien vers un endroit du même mail (sommaire) : la page défile toute seule
                            if (url.startsWith(BASE_URL) && request.url.fragment != null) return false
                            if (request.url.host == CID_HOST) return true
                            links.onLink(url)
                            return true
                        }

                        override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? {
                            if (request.url.host != CID_HOST) return null
                            val img = links.inline[cidFromUrl(request.url.encodedPath)]
                            return runCatching { WebResourceResponse(img!!.second, null, img.first.inputStream()) }
                                .getOrElse { WebResourceResponse("text/plain", "utf-8", 404, "Not found", null, java.io.ByteArrayInputStream(ByteArray(0))) }
                        }

                        override fun onPageFinished(view: WebView, url: String?) {
                            // Hauteur réelle une fois les images chargées
                            view.postDelayed({ view.requestLayout() }, 300)
                        }
                    }
                    setOnLongClickListener { v ->
                        val r = (v as WebView).hitTestResult
                        val target = r.extra
                        if (r.type == WebView.HitTestResult.SRC_ANCHOR_TYPE && !target.isNullOrBlank()) {
                            links.onLongLink(target); true
                        } else false
                    }
                }
            },
            update = { w ->
                if (w.tag != page) {
                    w.tag = page
                    w.loadDataWithBaseURL(BASE_URL, page, "text/html", "utf-8", null)
                }
            },
            onRelease = { w -> runCatching { w.stopLoading(); w.destroy() } },
            modifier = Modifier.fillMaxWidth(),
        )
    }

    longLink?.let { url ->
        val shown = if (url.startsWith("mailto:", true)) parseMailto(url).to else url
        AlertDialog(
            onDismissRequest = { longLink = null },
            title = { Text("Lien") },
            text = { RawText(shown, maxLines = 6, overflow = TextOverflow.Ellipsis) },
            confirmButton = { TextButton(onClick = { longLink = null; handler(url) }) { Text("Ouvrir") } },
            dismissButton = {
                Row {
                    TextButton(onClick = {
                        longLink = null
                        val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                        cm.setPrimaryClip(ClipData.newPlainText("lien", shown))
                        I18n.toast(ctx, I18n.tr("Lien copié"), Toast.LENGTH_SHORT).show()
                    }) { Text("Copier") }
                    TextButton(onClick = {
                        longLink = null
                        LockGuard.external()
                        val i = Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, shown)
                        runCatching { ctx.startActivity(Intent.createChooser(i, null).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
                    }) { Text("Partager") }
                }
            },
        )
    }
}

/** Image réduite pour l'affichage (sans charger la photo entière en mémoire). */
internal suspend fun loadPhoto(f: File, max: Int): Bitmap? = withContext(Dispatchers.IO) {
    runCatching {
        val o = android.graphics.BitmapFactory.Options().apply { inJustDecodeBounds = true }
        android.graphics.BitmapFactory.decodeFile(f.path, o)
        var sample = 1
        while (maxOf(o.outWidth, o.outHeight) / (sample * 2) >= max) sample *= 2
        android.graphics.BitmapFactory.decodeFile(f.path, android.graphics.BitmapFactory.Options().apply { inSampleSize = sample })
    }.getOrNull()
}

/** Photos jointes au mail : vignettes (téléchargées à l'ouverture), touchées pour les voir en grand. */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun MailPhotos(photos: List<MailAttachment>, files: Map<Int, File>, onOpen: (MailAttachment, File) -> Unit) {
    if (photos.isEmpty()) return
    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        photos.forEach { at ->
            val f = files[at.index]
            Surface(
                onClick = { if (f != null) onOpen(at, f) },
                shape = RoundedCornerShape(10.dp),
                color = MaterialTheme.colorScheme.surfaceContainerHigh,
                modifier = Modifier.size(104.dp),
            ) {
                Box(contentAlignment = Alignment.Center) {
                    if (f == null) CircularProgressIndicator(Modifier.size(24.dp), strokeWidth = 2.dp)
                    else {
                        val bmp by produceState<Bitmap?>(null, f.path) { value = loadPhoto(f, 320) }
                        val img = bmp
                        if (img != null) Image(img.asImageBitmap(), at.name, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize().clip(RoundedCornerShape(10.dp)))
                        else Icon(Icons.Filled.Image, at.name)
                    }
                }
            }
        }
    }
}

/** Photo en plein écran : pincer pour zoomer, double appui pour agrandir ; ouvrir avec une autre appli ou partager. */
@Composable
fun MailPhotoViewer(f: File, name: String, mime: String, onOpenWith: () -> Unit, onClose: () -> Unit) {
    val ctx = LocalContext.current
    Dialog(onDismissRequest = onClose, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        val bmp by produceState<Bitmap?>(null, f.path) { value = loadPhoto(f, 2400) }
        var scale by remember { mutableStateOf(1f) }
        var offset by remember { mutableStateOf(Offset.Zero) }
        Box(Modifier.fillMaxSize().background(Color.Black)) {
            val img = bmp
            if (img == null) CircularProgressIndicator(Modifier.align(Alignment.Center))
            else Image(
                img.asImageBitmap(), name,
                modifier = Modifier.fillMaxSize()
                    .pointerInput(Unit) {
                        detectTransformGestures { _, pan, zoom, _ ->
                            scale = (scale * zoom).coerceIn(1f, 6f)
                            offset = if (scale == 1f) Offset.Zero else offset + pan
                        }
                    }
                    .pointerInput(Unit) {
                        detectTapGestures(onDoubleTap = { if (scale > 1f) { scale = 1f; offset = Offset.Zero } else scale = 2.5f })
                    }
                    .graphicsLayer(scaleX = scale, scaleY = scale, translationX = offset.x, translationY = offset.y),
            )
            Column(Modifier.fillMaxWidth().background(Color.Black.copy(alpha = 0.45f)).statusBarsPadding()) {
                Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = onClose) { Icon(Icons.Filled.Close, "Fermer", tint = Color.White) }
                    RawText(name, color = Color.White, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
                    IconButton(onClick = {
                        LockGuard.external()
                        val i = Intent(Intent.ACTION_SEND).setType(mime.ifBlank { "image/*" }).putExtra(Intent.EXTRA_STREAM, Files.uriFor(ctx, f))
                            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                        runCatching { ctx.startActivity(Intent.createChooser(i, name).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
                    }) { Icon(Icons.Filled.Share, "Partager", tint = Color.White) }
                    IconButton(onClick = onOpenWith) { Icon(Icons.AutoMirrored.Filled.OpenInNew, "Ouvrir avec…", tint = Color.White) }
                }
            }
        }
    }
}
