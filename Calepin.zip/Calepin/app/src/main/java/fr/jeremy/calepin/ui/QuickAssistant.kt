package fr.jeremy.calepin.ui

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.speech.RecognizerIntent
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.OpenInFull
import androidx.compose.material3.AssistChip
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.SmallFloatingActionButton
import androidx.compose.material3.Surface
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import fr.jeremy.calepin.Actions
import fr.jeremy.calepin.LockGuard
import fr.jeremy.calepin.NotesViewModel
import fr.jeremy.calepin.ScreenContext
import fr.jeremy.calepin.assistant.AssistantAction
import fr.jeremy.calepin.assistant.OfflineListener
import fr.jeremy.calepin.assistant.Speaker
import fr.jeremy.calepin.i18n.I18n
import fr.jeremy.calepin.i18n.RawText
import fr.jeremy.calepin.i18n.Text
import kotlinx.coroutines.launch

/** Exemples proposés selon le menu ouvert. */
private fun examplesFor(screen: String): List<String> = when (screen) {
    "pdf" -> listOf("Ajoute les dates de ce PDF à l'agenda", "Mon planning cette semaine")
    "office" -> listOf("Importe le PDF planning dans l'agenda", "Ouvre le PDF contrat")
    "conversation" -> listOf("Réponds-lui que j'arrive dans 10 minutes", "Dis-lui merci, à ce soir")
    "messages" -> listOf("Envoie un WhatsApp à Marc : j'arrive", "Lis mes mails", "Lis les messages de Famille")
    "agenda" -> listOf("Qu'est-ce que j'ai demain ?", "Rendez-vous dentiste jeudi 14h", "Importe le PDF planning dans l'agenda")
    "notes" -> listOf("Note que le plombier passe lundi", "Cherche facture", "Ajoute les dates de la note chantier à l'agenda")
    "note" -> listOf("Ajoute les dates de cette note à l'agenda", "Rappelle-moi demain à 9h de relire cette note")
    "contacts" -> listOf("Appelle Marc", "SMS à Julie", "Emmène-moi chez Marc")
    "pro" -> listOf("Combien d'heures ce mois-ci ?", "Mon planning cette semaine")
    "phone" -> listOf("Ouvre les fichiers", "Ouvre le nettoyeur", "Ouvre l'optimiseur")
    else -> listOf("Résumé de ma journée", "Rappelle-moi dans 20 minutes d'appeler le plombier")
}

/**
 * Bouton de l'assistant présent dans les menus : on parle ou on écrit sans quitter l'écran. L'assistant
 * sait où l'on est (PDF ouvert, note, conversation…) : « ajoute les dates de ce PDF à l'agenda »,
 * « réponds-lui que j'arrive ».
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun QuickAssistant(vm: NotesViewModel, onOpenFull: () -> Unit, modifier: Modifier = Modifier) {
    var open by remember { mutableStateOf(false) }
    val cs = MaterialTheme.colorScheme
    SmallFloatingActionButton(
        onClick = { open = true },
        containerColor = cs.primaryContainer,
        modifier = modifier,
    ) { AssistantIcon(tint = cs.onPrimaryContainer, background = cs.primaryContainer, size = 22.dp) }
    if (open) {
        val sheet = rememberModalBottomSheetState(skipPartiallyExpanded = true)
        ModalBottomSheet(onDismissRequest = { open = false }, sheetState = sheet) {
            QuickAssistantPanel(vm, onOpenFull = { open = false; onOpenFull() })
        }
    }
}

@Composable
private fun QuickAssistantPanel(vm: NotesViewModel, onOpenFull: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val voiceOn by vm.settings.assistantVoice.collectAsStateWithLifecycle()
    val offlinePref by vm.settings.assistantOffline.collectAsStateWithLifecycle()
    val rate by vm.settings.speechRate.collectAsStateWithLifecycle()
    val working by vm.aiWorking.collectAsStateWithLifecycle()
    var input by remember { mutableStateOf("") }
    var reply by remember { mutableStateOf<String?>(null) }
    var actions by remember { mutableStateOf<List<AssistantAction>>(emptyList()) }
    var busy by remember { mutableStateOf(false) }
    var listening by remember { mutableStateOf(false) }
    var partial by remember { mutableStateOf("") }
    val speaker = remember { Speaker(ctx) }
    val offline = remember { OfflineListener(ctx) }
    DisposableEffect(Unit) { onDispose { speaker.shutdown(); offline.stop() } }
    speaker.rate = rate
    val screen = if (ScreenContext.conv != null) "conversation" else ScreenContext.screen

    fun send(text: String) {
        val t = text.trim()
        if (t.isEmpty()) return
        input = ""
        busy = true
        scope.launch {
            val r = runCatching { vm.ask(t) }.getOrNull()
            busy = false
            reply = r?.text ?: I18n.tr("Je n'ai pas pu répondre.")
            actions = r?.actions.orEmpty()
            if (voiceOn) r?.text?.let { speaker.speak(it) }
            // Actions simples faites tout de suite (comme dans l'écran de l'assistant)
            r?.actions?.forEach { a ->
                when (a) {
                    is AssistantAction.Dial -> Actions.dial(ctx, a.number)
                    is AssistantAction.Sms -> Actions.sms(ctx, a.number)
                    is AssistantAction.Directions -> Actions.directions(ctx, a.address)
                    is AssistantAction.PhoneCalendar -> if (a.auto) Actions.addEvent(ctx, a.title, "", a.start, !a.allDay, null, a.end.takeIf { it > a.start })
                    else -> Unit
                }
            }
        }
    }

    val googleSpeech = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { res ->
        listening = false
        val text = res.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
        if (res.resultCode == Activity.RESULT_OK && !text.isNullOrBlank()) send(text)
    }
    fun listenOffline() {
        speaker.stop()
        listening = true
        partial = ""
        scope.launch {
            runCatching {
                offline.start(
                    onPartial = { partial = it },
                    onResult = { listening = false; partial = ""; send(it) },
                    onError = { listening = false; partial = ""; I18n.toast(ctx, it, Toast.LENGTH_SHORT).show() },
                )
            }.onFailure { listening = false }
        }
    }
    val micPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok -> if (ok) listenOffline() }
    fun listen() {
        speaker.stop()
        if (offlinePref && offline.available) {
            if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) listenOffline()
            else { LockGuard.external(); micPermission.launch(Manifest.permission.RECORD_AUDIO) }
        } else {
            LockGuard.external()
            runCatching {
                listening = true
                googleSpeech.launch(
                    Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                        putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                        putExtra(RecognizerIntent.EXTRA_LANGUAGE, I18n.language.value.speechTag)
                        putExtra(RecognizerIntent.EXTRA_PROMPT, I18n.tr("Je t'écoute"))
                    },
                )
            }.onFailure { listening = false; I18n.toast(ctx, "Aucune reconnaissance vocale sur ce téléphone", Toast.LENGTH_LONG).show() }
        }
    }

    Column(
        Modifier.fillMaxWidth().imePadding().navigationBarsPadding().padding(horizontal = 16.dp).padding(bottom = 12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            AssistantIcon(tint = MaterialTheme.colorScheme.primary, background = MaterialTheme.colorScheme.surface)
            Spacer(Modifier.width(8.dp))
            Text("Assistant", style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
            IconButton(onClick = onOpenFull) { Icon(Icons.Filled.OpenInFull, "Ouvrir l'assistant en grand") }
        }
        if (busy || working) LinearProgressIndicator(Modifier.fillMaxWidth())
        val shown = reply
        if (shown != null) Surface(shape = RoundedCornerShape(16.dp), color = MaterialTheme.colorScheme.surfaceContainerHigh, modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.heightIn(max = 260.dp).verticalScroll(rememberScrollState()).padding(12.dp)) {
                RawText(shown, style = MaterialTheme.typography.bodyLarge)
                actions.firstNotNullOfOrNull { it as? AssistantAction.OpenNote }?.let { a ->
                    TextButton(onClick = { vm.navigation.value = "note:" + a.id }) { Text("Ouvrir la note") }
                }
                if (actions.any { it is AssistantAction.OpenCalendar }) TextButton(onClick = { vm.navigation.value = "agenda" }) { Text("Ouvrir l'agenda") }
            }
        } else {
            // Idées selon le menu ouvert
            examplesFor(screen).forEach { ex -> AssistChip(onClick = { send(I18n.tr(ex)) }, label = { Text(ex) }) }
        }
        if (listening) RawText(partial.ifBlank { I18n.tr("Je t'écoute…") }, color = MaterialTheme.colorScheme.primary)
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                input, { input = it }, modifier = Modifier.weight(1f),
                placeholder = { Text("Demande ou commande…") }, maxLines = 4, shape = RoundedCornerShape(24.dp),
                keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Sentences, imeAction = ImeAction.Send),
                keyboardActions = KeyboardActions(onSend = { send(input) }),
            )
            if (input.isBlank()) IconButton(onClick = { listen() }) { Icon(Icons.Filled.Mic, "Parler", tint = MaterialTheme.colorScheme.primary) }
            else IconButton(onClick = { send(input) }) { Icon(Icons.AutoMirrored.Filled.Send, "Envoyer", tint = MaterialTheme.colorScheme.primary) }
        }
    }
}
