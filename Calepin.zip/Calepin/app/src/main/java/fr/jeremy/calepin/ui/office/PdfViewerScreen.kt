package fr.jeremy.calepin.ui.office

import android.app.Activity
import android.graphics.Bitmap
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.foundation.gestures.calculatePan
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.ime
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.RotateLeft
import androidx.compose.material.icons.automirrored.filled.RotateRight
import androidx.compose.material.icons.automirrored.filled.Undo
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.ChevronLeft
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCut
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Draw
import androidx.compose.material.icons.filled.EditNote
import androidx.compose.material.icons.filled.GridView
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.NoteAdd
import androidx.compose.material.icons.filled.OpenWith
import androidx.compose.material.icons.filled.SaveAlt
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.StopCircle
import androidx.compose.material.icons.filled.ZoomIn
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.ZoomOut
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Checkbox
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.SmallFloatingActionButton
import androidx.compose.material3.Surface
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.ColorMatrix
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import fr.jeremy.calepin.Files
import fr.jeremy.calepin.LockGuard
import fr.jeremy.calepin.i18n.I18n
import fr.jeremy.calepin.i18n.RawText
import fr.jeremy.calepin.i18n.Text
import fr.jeremy.calepin.office.PdfLibrary
import fr.jeremy.calepin.office.PdfLibrary.Mark
import fr.jeremy.calepin.office.PdfLibrary.P
import fr.jeremy.calepin.ui.FitText
import fr.jeremy.calepin.ui.NoteFind
import kotlinx.coroutines.launch
import org.json.JSONArray
import kotlin.math.max
import kotlin.math.min

/** Couleurs « négatif » pour lire la nuit (fond noir, texte clair). */
private val NIGHT = ColorFilter.colorMatrix(
    ColorMatrix(floatArrayOf(-1f, 0f, 0f, 0f, 255f, 0f, -1f, 0f, 0f, 255f, 0f, 0f, -1f, 0f, 255f, 0f, 0f, 0f, 1f, 0f)),
)

/** Lecteur de PDF : défilement, zoom (pincer ou toucher deux fois), recherche, lecture à voix haute, pages, annotations. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PdfViewerScreen(id: String, onClose: () -> Unit, onOpen: (String) -> Unit) {
    val ctx = LocalContext.current
    val lib = remember { PdfLibrary.get(ctx) }
    val items by lib.items.collectAsStateWithLifecycle()
    val entry = items.firstOrNull { it.id == id }
    val scope = rememberCoroutineScope()
    var version by remember { mutableIntStateOf(0) }
    val ratios by produceState(emptyList<Float>(), id, version) { value = lib.ratios(id) }
    val listState = rememberLazyListState(initialFirstVisibleItemIndex = entry?.page ?: 0)
    var zoom by rememberSaveable { mutableFloatStateOf(1f) }
    var night by rememberSaveable { mutableStateOf(false) }
    var menu by remember { mutableStateOf(false) }
    var searchOpen by remember { mutableStateOf(false) }
    var query by remember { mutableStateOf("") }
    var pagesOpen by remember { mutableStateOf(false) }
    var annotate by remember { mutableStateOf<Int?>(null) }
    var formOpen by remember { mutableStateOf(false) }
    var protectOpen by remember { mutableStateOf(false) }
    var copyOpen by remember { mutableStateOf(false) }
    var mailFile by remember { mutableStateOf<java.io.File?>(null) }
    var mailDraft by remember { mutableStateOf<fr.jeremy.calepin.ui.mail.MailDraft?>(null) }
    var busy by remember { mutableStateOf<String?>(null) }
    var speaking by remember { mutableStateOf(false) }
    val speaker = remember { fr.jeremy.calepin.assistant.Speaker(ctx) { speaking = false } }
    val current = listState.firstVisibleItemIndex
    DisposableEffect(Unit) { onDispose { speaker.shutdown(); lib.touch(id, listState.firstVisibleItemIndex) } }
    BackHandler { if (searchOpen) searchOpen = false else onClose() }

    fun toast(t: String) = I18n.toast(ctx, t, Toast.LENGTH_LONG).show()
    fun run(label: String, block: suspend () -> Unit) {
        busy = I18n.tr(label)
        scope.launch {
            runCatching { block() }.onFailure { toast(I18n.tr("Échec :") + " " + (it.message ?: it.javaClass.simpleName)) }
            busy = null
            version++
        }
    }

    // Texte des pages : chargé seulement quand on cherche ou qu'on lit à voix haute
    var texts by remember { mutableStateOf<List<String>?>(null) }
    LaunchedEffect(version) { texts = null }
    suspend fun loadTexts(): List<String> = texts ?: lib.pageTexts(id).also { texts = it }

    val saver = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { res ->
        val uri = res.data?.data
        if (res.resultCode == Activity.RESULT_OK && uri != null) {
            toast(if (Files.write(ctx, uri, lib.file(id).readBytes())) "Fichier enregistré" else "Impossible d'écrire le fichier")
        }
    }

    if (entry == null) {
        LaunchedEffect(Unit) { onClose() }
        return
    }

    Scaffold(
        containerColor = if (night) Color(0xFF111111) else MaterialTheme.colorScheme.surfaceContainerHighest,
        topBar = {
            TopAppBar(
                title = { FitText(entry.name, translate = false) },
                navigationIcon = { IconButton(onClick = onClose) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Retour") } },
                actions = {
                    IconButton(onClick = { searchOpen = !searchOpen }) { Icon(Icons.Filled.Search, "Chercher dans le PDF") }
                    IconButton(onClick = { annotate = current }) { Icon(Icons.Filled.Draw, "Annoter ou signer cette page") }
                    IconButton(onClick = { pagesOpen = true }) { Icon(Icons.Filled.GridView, "Pages") }
                    Box {
                        IconButton(onClick = { menu = true }) { Icon(Icons.Filled.MoreVert, "Plus d'actions") }
                        DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                            DropdownMenuItem(
                                text = { Text(if (speaking) "Arrêter la lecture" else "Lire la page à voix haute") },
                                leadingIcon = { Icon(if (speaking) Icons.Filled.StopCircle else Icons.AutoMirrored.Filled.VolumeUp, null) },
                                onClick = {
                                    menu = false
                                    if (speaking) { speaker.stop(); speaking = false } else scope.launch {
                                        val t = loadTexts().drop(current).take(3).joinToString(" ").trim()
                                        if (t.isBlank()) toast("Cette page ne contient pas de texte lisible (document scanné ?).")
                                        else { speaking = true; speaker.speak(t) }
                                    }
                                },
                            )
                            DropdownMenuItem(text = { Text(if (night) "Mode jour" else "Mode nuit") }, leadingIcon = { Icon(Icons.Filled.DarkMode, null) }, onClick = { menu = false; night = !night })
                            DropdownMenuItem(text = { Text("Remplir le formulaire") }, leadingIcon = { Icon(Icons.Filled.EditNote, null) }, onClick = { menu = false; formOpen = true })
                            DropdownMenuItem(text = { Text("Copie protégée par mot de passe") }, leadingIcon = { Icon(Icons.Filled.Lock, null) }, onClick = { menu = false; protectOpen = true })
                            if (lib.canUndo(id)) {
                                DropdownMenuItem(text = { Text("Annuler la dernière modification") }, leadingIcon = { Icon(Icons.AutoMirrored.Filled.Undo, null) }, onClick = { menu = false; run("Annulation…") { lib.undo(id) } })
                            }
                            DropdownMenuItem(text = { Text("Envoyer par mail") }, leadingIcon = { Icon(Icons.Filled.Email, null) }, onClick = {
                                menu = false
                                scope.launch { mailFile = lib.exportCopy(id) }
                            })
                            DropdownMenuItem(text = { Text("Faire une copie") }, leadingIcon = { Icon(Icons.Filled.ContentCopy, null) }, onClick = { menu = false; copyOpen = true })
                            DropdownMenuItem(text = { Text("Partager") }, leadingIcon = { Icon(Icons.Filled.Share, null) }, onClick = {
                                menu = false
                                scope.launch { Files.shareFile(ctx, lib.exportCopy(id), "application/pdf", entry.name + ".pdf") }
                            })
                            DropdownMenuItem(text = { Text("Enregistrer sous…") }, leadingIcon = { Icon(Icons.Filled.SaveAlt, null) }, onClick = {
                                menu = false; LockGuard.external(); saver.launch(Files.createDocumentIntent(entry.name + ".pdf", "application/pdf"))
                            })
                        }
                    }
                },
            )
        },
    ) { pad ->
        val density = LocalDensity.current
        val screenW = LocalConfiguration.current.screenWidthDp.dp - 16.dp
        // Rendu par paliers de zoom (pas un nouveau rendu à chaque mouvement des doigts)
        val renderZoom = (Math.round(zoom * 2) / 2f).coerceAtLeast(1f)
        val renderPx = with(density) { (screenW * renderZoom).toPx() }.toInt().coerceAtMost(2600)
        Box(Modifier.fillMaxSize().padding(pad)) {
            Box(
                Modifier
                    .fillMaxSize()
                    .pointerInput(Unit) {
                        // Pincer pour zoomer (deux doigts) ; un doigt fait défiler normalement
                        awaitEachGesture {
                            awaitFirstDown(requireUnconsumed = false)
                            do {
                                val ev = awaitPointerEvent(PointerEventPass.Initial)
                                if (ev.changes.count { it.pressed } >= 2) {
                                    val z = ev.calculateZoom()
                                    if (z != 1f) {
                                        zoom = (zoom * z).coerceIn(1f, 5f)
                                        ev.changes.forEach { it.consume() }
                                    }
                                }
                            } while (ev.changes.any { it.pressed })
                        }
                    }
                    .horizontalScroll(rememberScrollState()),
            ) {
                LazyColumn(
                    state = listState,
                    modifier = Modifier.width(screenW * zoom + 16.dp).fillMaxHeight(),
                    contentPadding = PaddingValues(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    itemsIndexed(ratios) { i, r ->
                        PdfPageImage(lib, id, i, r, screenW * zoom, renderPx, version, night) {
                            zoom = if (zoom > 1.2f) 1f else 2.5f
                        }
                    }
                }
            }
            if (ratios.isNotEmpty()) {
                Surface(shape = CircleShape, color = Color.Black.copy(alpha = 0.55f), modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 14.dp)) {
                    RawText("${current + 1} / ${ratios.size}", color = Color.White, style = MaterialTheme.typography.labelLarge, modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp))
                }
            }
            Column(Modifier.align(Alignment.BottomEnd).padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                SmallFloatingActionButton(onClick = { zoom = (zoom * 1.4f).coerceAtMost(5f) }) { Icon(Icons.Filled.ZoomIn, "Agrandir") }
                SmallFloatingActionButton(onClick = { zoom = (zoom / 1.4f).coerceAtLeast(1f) }) { Icon(Icons.Filled.ZoomOut, "Réduire") }
            }
            busy?.let {
                Surface(color = MaterialTheme.colorScheme.secondaryContainer, modifier = Modifier.fillMaxWidth().align(Alignment.TopCenter)) {
                    Column(Modifier.padding(10.dp)) { RawText(it); LinearProgressIndicator(Modifier.fillMaxWidth()) }
                }
            }
            if (searchOpen) {
                SearchPanel(
                    query = query, onQuery = { query = it },
                    loadTexts = { loadTexts() },
                    onGo = { p -> scope.launch { listState.animateScrollToItem(p) } },
                    onClose = { searchOpen = false },
                    modifier = Modifier.align(Alignment.BottomCenter),
                )
            }
        }
    }

    if (pagesOpen) {
        PageManager(
            lib = lib, id = id, version = version, count = ratios.size,
            onClose = { pagesOpen = false },
            onGo = { p -> pagesOpen = false; scope.launch { listState.scrollToItem(p) } },
            run = { label, block -> run(label, block) },
            onOpen = { pagesOpen = false; onOpen(it) },
        )
    }
    annotate?.let { page ->
        val r = ratios.getOrNull(page)
        if (r != null) AnnotateDialog(lib, id, page, r, version, onDismiss = { annotate = null }, onSave = { layer ->
            annotate = null
            run("Enregistrement des annotations…") { lib.saveLayer(id, page, layer) }
        })
    }
    if (formOpen) FormDialog(lib, id, onDismiss = { formOpen = false }) { values, flatten ->
        formOpen = false
        run("Remplissage du formulaire…") { lib.fillForm(id, values, flatten) }
    }
    mailFile?.let { f ->
        fr.jeremy.calepin.ui.mail.SendByMailDialog(f, f.name, "application/pdf", onDismiss = { mailFile = null }, onCalepin = { mailDraft = it })
    }
    mailDraft?.let { d -> fr.jeremy.calepin.ui.mail.MailComposeDialog(d) { mailDraft = null } }
    if (copyOpen) {
        var copyName by remember { mutableStateOf(entry.name + " " + I18n.tr("(copie)")) }
        AlertDialog(
            onDismissRequest = { copyOpen = false },
            title = { Text("Faire une copie") },
            text = { OutlinedTextField(copyName, { copyName = it }, label = { Text("Nom de la copie") }, singleLine = true) },
            confirmButton = {
                TextButton(enabled = copyName.isNotBlank(), onClick = {
                    copyOpen = false
                    busy = I18n.tr("Copie…")
                    scope.launch {
                        runCatching { lib.duplicate(id, copyName.trim()) }
                            .onSuccess { e -> busy = null; toast(I18n.tr("Copie créée.")); onOpen(e.id) }
                            .onFailure { busy = null; toast(I18n.tr("Échec :") + " " + (it.message ?: "")) }
                    }
                }) { Text("Créer la copie") }
            },
            dismissButton = { TextButton(onClick = { copyOpen = false }) { Text("Annuler") } },
        )
    }
    if (protectOpen) {
        var pwd by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { protectOpen = false },
            title = { Text("Copie protégée") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Crée une copie du PDF qui demande ce mot de passe pour l'ouvrir, puis la partage. Ton PDF ici n'est pas modifié.", style = MaterialTheme.typography.bodySmall)
                    OutlinedTextField(pwd, { pwd = it }, label = { Text("Mot de passe") }, singleLine = true, visualTransformation = PasswordVisualTransformation())
                }
            },
            confirmButton = {
                TextButton(enabled = pwd.length >= 4, onClick = {
                    protectOpen = false
                    busy = I18n.tr("Protection…")
                    scope.launch {
                        runCatching { lib.protect(id, pwd, entry.name + " (protégé)") }
                            .onSuccess { f -> busy = null; Files.shareFile(ctx, f, "application/pdf", f.name) }
                            .onFailure { busy = null; toast(I18n.tr("Échec :") + " " + (it.message ?: "")) }
                    }
                }) { Text("Créer et partager") }
            },
            dismissButton = { TextButton(onClick = { protectOpen = false }) { Text("Annuler") } },
        )
    }
}

/** Une page, rendue à la bonne taille ; toucher deux fois zoome. */
@Composable
private fun PdfPageImage(lib: PdfLibrary, id: String, index: Int, ratio: Float, width: androidx.compose.ui.unit.Dp, renderPx: Int, version: Int, night: Boolean, onDoubleTap: () -> Unit) {
    val bmp by produceState<Bitmap?>(null, index, renderPx, version) { value = lib.render(id, index, renderPx) }
    Box(
        Modifier
            .width(width)
            .aspectRatio(1f / ratio)
            .background(if (night) Color.Black else Color.White)
            .pointerInput(Unit) { detectTapGestures(onDoubleTap = { onDoubleTap() }) },
    ) {
        bmp?.let { Image(it.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = ContentScale.FillBounds, colorFilter = if (night) NIGHT else null) }
    }
}

/** Recherche dans le texte du PDF : liste des pages trouvées, avec un extrait. */
@Composable
private fun SearchPanel(query: String, onQuery: (String) -> Unit, loadTexts: suspend () -> List<String>, onGo: (Int) -> Unit, onClose: () -> Unit, modifier: Modifier) {
    var texts by remember { mutableStateOf<List<String>?>(null) }
    LaunchedEffect(Unit) { texts = loadTexts() }
    val results = remember(texts, query) {
        val t = texts ?: return@remember emptyList()
        if (query.trim().length < 2) emptyList() else t.flatMapIndexed { p, txt ->
            NoteFind.find(txt, query).take(5).map { r ->
                val a = (r.first - 40).coerceAtLeast(0)
                val b = (r.last + 60).coerceAtMost(txt.length)
                p to txt.substring(a, b).replace('\n', ' ').trim()
            }
        }
    }
    Surface(shape = RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp), color = MaterialTheme.colorScheme.surfaceContainerHigh, tonalElevation = 6.dp, modifier = modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp).navigationBarsPadding()) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(query, onQuery, label = { Text("Chercher dans le PDF") }, singleLine = true, modifier = Modifier.weight(1f))
                IconButton(onClick = onClose) { Icon(Icons.Filled.Close, "Fermer") }
            }
            when {
                texts == null -> LinearProgressIndicator(Modifier.fillMaxWidth().padding(top = 8.dp))
                texts!!.all { it.isBlank() } -> Text("Ce PDF ne contient pas de texte (document scanné) : la recherche n'est pas possible.", style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(top = 8.dp))
                query.trim().length >= 2 -> RawText(I18n.trf("{0} résultat(s)", results.size), style = MaterialTheme.typography.labelLarge, modifier = Modifier.padding(top = 6.dp))
            }
            LazyColumn(Modifier.heightIn(max = 240.dp)) {
                itemsIndexed(results) { _, (p, snippet) ->
                    Column(Modifier.fillMaxWidth().clickable { onGo(p) }.padding(vertical = 8.dp)) {
                        RawText(I18n.trf("Page {0}", p + 1), style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
                        RawText("…$snippet…", style = MaterialTheme.typography.bodySmall, maxLines = 2)
                    }
                }
            }
        }
    }
}

// ------------------------------------------------------------------ Gestion des pages

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
private fun PageManager(
    lib: PdfLibrary,
    id: String,
    version: Int,
    count: Int,
    onClose: () -> Unit,
    onGo: (Int) -> Unit,
    run: (String, suspend () -> Unit) -> Unit,
    onOpen: (String) -> Unit,
) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var sel by remember { mutableStateOf(setOf<Int>()) }
    var addFrom by remember { mutableStateOf(false) }
    val items by lib.items.collectAsStateWithLifecycle()
    val pickImages = rememberLauncherForActivityResult(ActivityResultContracts.PickMultipleVisualMedia(60)) { uris ->
        if (uris.isNotEmpty()) run("Ajout des photos…") {
            val tmp = lib.fromImages(uris, "tmp")
            lib.appendFrom(id, listOf(tmp.id))
            lib.delete(tmp.id)
        }
    }
    Dialog(onDismissRequest = onClose, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Scaffold(
            containerColor = MaterialTheme.colorScheme.surface,
            topBar = {
                TopAppBar(
                    title = { Text(if (sel.isEmpty()) "Pages" else I18n.trf("{0} page(s) choisie(s)", sel.size)) },
                    navigationIcon = { IconButton(onClick = onClose) { Icon(Icons.Filled.Close, "Fermer") } },
                    actions = {
                        if (sel.size < count) TextButton(onClick = { sel = (0 until count).toSet() }) { Text("Tout") }
                        else TextButton(onClick = { sel = emptySet() }) { Text("Aucune") }
                    },
                )
            },
            bottomBar = {
                Surface(tonalElevation = 3.dp) {
                    FlowRow(Modifier.fillMaxWidth().padding(8.dp).navigationBarsPadding(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        val any = sel.isNotEmpty()
                        IconButton(enabled = any, onClick = { run("Rotation…") { lib.rotate(id, sel, -90) } }) { Icon(Icons.AutoMirrored.Filled.RotateLeft, "Tourner à gauche") }
                        IconButton(enabled = any, onClick = { run("Rotation…") { lib.rotate(id, sel, 90) } }) { Icon(Icons.AutoMirrored.Filled.RotateRight, "Tourner à droite") }
                        IconButton(enabled = sel.size == 1 && sel.first() > 0, onClick = {
                            val p = sel.first()
                            val order = (0 until count).toMutableList().apply { removeAt(p); add(p - 1, p) }
                            sel = setOf(p - 1)
                            run("Déplacement…") { lib.reorder(id, order) }
                        }) { Icon(Icons.Filled.ChevronLeft, "Avancer la page") }
                        IconButton(enabled = sel.size == 1 && sel.first() < count - 1, onClick = {
                            val p = sel.first()
                            val order = (0 until count).toMutableList().apply { removeAt(p); add(p + 1, p) }
                            sel = setOf(p + 1)
                            run("Déplacement…") { lib.reorder(id, order) }
                        }) { Icon(Icons.Filled.ChevronRight, "Reculer la page") }
                        IconButton(enabled = any && sel.size < count, onClick = {
                            val s = sel; sel = emptySet()
                            run("Suppression…") { lib.deletePages(id, s) }
                        }) { Icon(Icons.Filled.Delete, "Supprimer les pages") }
                        IconButton(enabled = any, onClick = {
                            val s = sel.toList()
                            scope.launch {
                                runCatching { lib.extract(id, s, (lib.get(id)?.name ?: "PDF") + " (extrait)") }
                                    .onSuccess { onOpen(it.id) }
                                    .onFailure { I18n.toast(ctx, "Extraction impossible", Toast.LENGTH_SHORT).show() }
                            }
                        }) { Icon(Icons.Filled.ContentCut, "Extraire dans un nouveau PDF") }
                        IconButton(onClick = { addFrom = true }) { Icon(Icons.Filled.NoteAdd, "Ajouter un autre PDF à la fin") }
                        IconButton(onClick = { LockGuard.external(); pickImages.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) }) {
                            Icon(Icons.Filled.AddPhotoAlternate, "Ajouter des photos à la fin")
                        }
                    }
                }
            },
        ) { pad ->
            LazyVerticalGrid(GridCells.Adaptive(110.dp), Modifier.fillMaxSize().padding(pad), contentPadding = PaddingValues(10.dp), horizontalArrangement = Arrangement.spacedBy(10.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                itemsIndexed(List(count) { it }) { _, i ->
                    val bmp by produceState<Bitmap?>(null, i, version) { value = lib.render(id, i, 240) }
                    val on = i in sel
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Box(
                            Modifier
                                .fillMaxWidth()
                                .aspectRatio(0.72f)
                                .clip(RoundedCornerShape(8.dp))
                                .background(Color.White)
                                .border(if (on) 3.dp else 1.dp, if (on) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(8.dp))
                                .pointerInput(i) { detectTapGestures(onTap = { sel = if (on) sel - i else sel + i }, onDoubleTap = { onGo(i) }) },
                        ) {
                            bmp?.let { Image(it.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = ContentScale.Fit) }
                            if (on) Checkbox(checked = true, onCheckedChange = null, modifier = Modifier.align(Alignment.TopEnd))
                        }
                        RawText("${i + 1}", style = MaterialTheme.typography.labelMedium)
                    }
                }
            }
        }
    }
    if (addFrom) {
        AlertDialog(
            onDismissRequest = { addFrom = false },
            title = { Text("Ajouter à la fin") },
            text = {
                Column {
                    val others = items.filter { it.id != id }
                    if (others.isEmpty()) Text("Ouvre d'abord un autre PDF dans Calepin.")
                    others.forEach { e ->
                        RawText(e.name, modifier = Modifier.fillMaxWidth().clickable { addFrom = false; run("Ajout des pages…") { lib.appendFrom(id, listOf(e.id)) } }.padding(vertical = 10.dp))
                    }
                }
            },
            confirmButton = { TextButton(onClick = { addFrom = false }) { Text("Fermer") } },
        )
    }
}

// ------------------------------------------------------------------ Annotations et signature

private enum class Tool(val label: String) { WRITE("Écrire"), PEN("Stylo"), HIGHLIGHT("Surligneur"), SIGN("Signature"), HIDE("Masquer"), ERASE("Gomme") }

/** Zone de texte tapée directement sur la page (outil « Écrire »). [at] : coin haut gauche. */
private class WriteBox(val key: Int, at0: P, val color: Int, size0: Float) {
    /** Position et taille modifiables : on déplace la zone avec la poignée, la taille suit le curseur. */
    var at by mutableStateOf(at0)
    var size by mutableFloatStateOf(size0)
}

/**
 * Lignes horizontales du document (soulignés de formulaire, cadres) repérées dans l'image de la page :
 * positions de 0 à 1 depuis le haut. Sert à poser le texte juste au-dessus, comme sur une ligne.
 */
private fun detectLines(b: Bitmap): List<Float> {
    val w = b.width
    val h = b.height
    val row = IntArray(w)
    val minRun = (w * 0.12f).toInt().coerceAtLeast(8)
    val found = ArrayList<Float>()
    var lastY = -10
    for (y in 0 until h) {
        b.getPixels(row, 0, w, 0, y, w, 1)
        var run = 0
        var best = 0
        for (x in 0 until w) {
            val c = row[x]
            val lum = (((c shr 16) and 0xFF) * 3 + ((c shr 8) and 0xFF) * 6 + (c and 0xFF)) / 10
            if (lum < 120) { run++; if (run > best) best = run } else run = 0
        }
        if (best >= minRun) {
            if (y - lastY > 3) found += y.toFloat() / h
            lastY = y
        }
    }
    return found
}

private val INK_COLORS = listOf(0xFF111111.toInt(), 0xFF1565C0.toInt(), 0xFFC62828.toInt(), 0xFF2E7D32.toInt(), 0xFFFFEB3B.toInt(), 0xFFFFFFFF.toInt())

/** Annoter une page : stylo, surligneur, texte, signature, cache blanc. Enregistré dans le PDF. */
@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
private fun AnnotateDialog(lib: PdfLibrary, id: String, page: Int, ratio: Float, version: Int, onDismiss: () -> Unit, onSave: (PdfLibrary.PageLayer) -> Unit) {
    val ctx = LocalContext.current
    val marks = remember { mutableStateListOf<Mark>() }
    val stroke = remember { mutableStateListOf<P>() }
    var tool by remember { mutableStateOf(Tool.WRITE) }
    var color by remember { mutableIntStateOf(INK_COLORS[0]) }
    var thick by remember { mutableFloatStateOf(3f) }
    var textSize by remember { mutableFloatStateOf(0.02f) }
    var sigSize by remember { mutableFloatStateOf(0.3f) }
    var signing by remember { mutableStateOf(false) }
    var signature by remember { mutableStateOf(Signature.load(ctx)) }
    var boxStart by remember { mutableStateOf<P?>(null) }
    var boxEnd by remember { mutableStateOf<P?>(null) }
    // Outil « Écrire » : zones de texte posées sur des lignes invisibles (ou sur celles du document)
    val writes = remember { mutableStateListOf<WriteBox>() }
    val texts = remember { androidx.compose.runtime.mutableStateMapOf<Int, androidx.compose.ui.text.input.TextFieldValue>() }
    val layouts = remember { mutableMapOf<Int, androidx.compose.ui.text.TextLayoutResult>() }
    val requesters = remember { mutableMapOf<Int, androidx.compose.ui.focus.FocusRequester>() }
    var nextKey by remember { mutableIntStateOf(1) }
    var focusKey by remember { mutableIntStateOf(-1) }
    var docLines by remember { mutableStateOf<List<Float>>(emptyList()) }
    var snap by remember { mutableStateOf(false) }
    var pageWpx by remember { mutableFloatStateOf(1f) }
    var pageHpx by remember { mutableFloatStateOf(1f) }
    val writeScroll = rememberScrollState()
    val hScroll = rememberScrollState()
    var zoom by remember { mutableFloatStateOf(1f) }
    // Annotations déjà enregistrées sur cette page : on les reprend pour les modifier
    var loaded by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        val l = runCatching { lib.layer(id, page) }.getOrDefault(PdfLibrary.PageLayer())
        marks.addAll(l.marks)
        l.writes.forEach { wd ->
            val k = nextKey++
            writes.add(WriteBox(k, wd.at, wd.color, wd.size))
            texts[k] = androidx.compose.ui.text.input.TextFieldValue(wd.text)
        }
        loaded = true
    }

    /** Gomme : retire l'annotation touchée (la plus récente d'abord). */
    fun eraseAt(n: P) {
        val tol = 0.03f
        fun near(p: P) = kotlin.math.hypot((p.x - n.x).toDouble(), ((p.y - n.y) * ratio).toDouble()) < tol
        val i = marks.indexOfLast { m ->
            when (m) {
                is Mark.Ink -> m.points.any { near(it) }
                is Mark.Box -> n.x in min(m.a.x, m.b.x)..max(m.a.x, m.b.x) && n.y in min(m.a.y, m.b.y)..max(m.a.y, m.b.y)
                is Mark.Text -> near(m.at)
            }
        }
        if (i >= 0) marks.removeAt(i)
    }

    /** Texte tapé → annotations (une par ligne affichée, au même endroit que sur l'écran). */
    fun writtenMarks(): List<Mark> = writes.flatMap { b ->
        val t = texts[b.key]?.text.orEmpty()
        val l = layouts[b.key]
        if (t.isBlank() || l == null) return@flatMap emptyList<Mark>()
        (0 until l.lineCount).mapNotNull { i ->
            val line = t.substring(l.getLineStart(i), l.getLineEnd(i, visibleEnd = true)).trimEnd('\n', ' ')
            if (line.isEmpty()) return@mapNotNull null
            val baseline = b.at.y * pageHpx + l.getLineBaseline(i)
            val top = (baseline - 0.85f * b.size * pageWpx) / pageHpx
            Mark.Text(P(b.at.x, top), line, b.color, b.size)
        }
    }

    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false, dismissOnClickOutside = false, decorFitsSystemWindows = false)) {
        val imeOpen = WindowInsets.ime.getBottom(LocalDensity.current) > 0
        Scaffold(
            containerColor = MaterialTheme.colorScheme.surfaceContainerHighest,
            topBar = {
                TopAppBar(
                    title = { RawText(I18n.trf("Page {0}", page + 1)) },
                    navigationIcon = { IconButton(onClick = onDismiss) { Icon(Icons.Filled.Close, "Annuler") } },
                    actions = {
                        IconButton(enabled = marks.isNotEmpty(), onClick = { marks.removeAt(marks.lastIndex) }) { Icon(Icons.AutoMirrored.Filled.Undo, "Annuler le dernier ajout") }
                        FilledTonalButton(enabled = loaded, onClick = {
                            onSave(
                                PdfLibrary.PageLayer(
                                    marks = marks.toList(),
                                    writes = writes.map { b -> PdfLibrary.WriteData(b.at, b.color, b.size, texts[b.key]?.text.orEmpty()) },
                                    flat = writtenMarks(),
                                ),
                            )
                        }) { Text("Enregistrer") }
                    },
                )
            },
            bottomBar = {
                // Clavier ouvert : la page prend toute la place (les outils reviennent en fermant le clavier)
                if (!imeOpen) Surface(tonalElevation = 3.dp) {
                    Column(Modifier.fillMaxWidth().padding(10.dp).navigationBarsPadding(), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            Tool.entries.forEach { t ->
                                FilterChip(selected = tool == t, onClick = {
                                    tool = t
                                    if (t == Tool.SIGN && signature == null) signing = true
                                    if (t == Tool.HIGHLIGHT && color != INK_COLORS[4]) color = INK_COLORS[4]
                                    if (t == Tool.HIDE) color = INK_COLORS[5]
                                }, label = { Text(t.label) })
                            }
                        }
                        if (tool != Tool.SIGN && tool != Tool.ERASE) {
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                                INK_COLORS.forEach { c ->
                                    Box(
                                        Modifier.size(30.dp).clip(CircleShape).background(Color(c))
                                            .border(if (c == color) 3.dp else 1.dp, if (c == color) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline, CircleShape)
                                            .clickable { color = c },
                                    )
                                }
                            }
                        }
                        when (tool) {
                            Tool.PEN, Tool.HIGHLIGHT -> Row(verticalAlignment = Alignment.CenterVertically) {
                                Text("Épaisseur", style = MaterialTheme.typography.labelMedium); Slider(thick, { thick = it }, valueRange = 1f..14f, modifier = Modifier.weight(1f))
                            }
                            Tool.WRITE -> Column {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text("Taille", style = MaterialTheme.typography.labelMedium)
                                    Slider(textSize, { v -> textSize = v; writes.firstOrNull { it.key == focusKey }?.size = v }, valueRange = 0.012f..0.08f, modifier = Modifier.weight(1f))
                                }
                                FilterChip(selected = snap, onClick = { snap = !snap }, label = { Text("Aligner sur les lignes du document") })
                            }
                            Tool.SIGN -> Row(verticalAlignment = Alignment.CenterVertically) {
                                Text("Taille", style = MaterialTheme.typography.labelMedium); Slider(sigSize, { sigSize = it }, valueRange = 0.12f..0.7f, modifier = Modifier.weight(1f))
                                TextButton(onClick = { signing = true }) { Text("Refaire") }
                            }
                            Tool.HIDE -> Text("Glisse pour couvrir une zone (par exemple pour écrire par-dessus avec l'outil Écrire).", style = MaterialTheme.typography.bodySmall)
                            Tool.ERASE -> Text("Touche un trait, une signature, un cache ou un texte pour l'effacer. Pour corriger un texte, choisis « Écrire » et touche-le.", style = MaterialTheme.typography.bodySmall)
                        }
                        if (tool == Tool.WRITE) Text(
                            "Touche l'endroit voulu et écris : le texte se place là où tu touches. Fais glisser la poignée ✥ pour le déplacer au millimètre. Entrée = ligne suivante.",
                            style = MaterialTheme.typography.bodySmall,
                        )
                        if (tool == Tool.SIGN && signature != null) Text("Touche l'endroit où signer.", style = MaterialTheme.typography.bodySmall)
                    }
                }
            },
        ) { pad ->
            BoxWithConstraints(Modifier.fillMaxSize().padding(pad).imePadding().padding(8.dp), contentAlignment = Alignment.TopCenter) {
                // Écrire : page à la largeur de l'écran, qui défile (le clavier prend la place du bas).
                // Autres outils : page entière à l'écran, pour dessiner sans défilement.
                val writing = tool == Tool.WRITE
                val boxW = maxWidth
                val boxH = maxHeight
                val w0 = if (writing) maxWidth.value else min(maxWidth.value, maxHeight.value / ratio)
                val w = w0 * zoom
                val wDp = w.dp
                val hDp = (w * ratio).dp
                val density = LocalDensity.current
                val px = with(density) { wDp.toPx() }
                // Rendu plus fin quand on zoome (par paliers)
                val rz = kotlin.math.round(zoom).coerceIn(1f, 3f)
                val bmp by produceState<Bitmap?>(null, version, rz) { value = lib.renderEditable(id, page, (with(density) { maxWidth.toPx() } * 1.5f * rz).toInt()) }
                LaunchedEffect(bmp) {
                    val b = bmp ?: return@LaunchedEffect
                    docLines = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.Default) { runCatching { detectLines(b) }.getOrDefault(emptyList()) }
                }
                // Le texte en cours d'écriture reste visible au-dessus du clavier
                LaunchedEffect(focusKey, writing) {
                    val b = writes.firstOrNull { it.key == focusKey } ?: return@LaunchedEffect
                    if (writing) writeScroll.animateScrollTo((b.at.y * pageHpx - with(density) { 80.dp.toPx() }).toInt().coerceAtLeast(0))
                    if (writing && zoom > 1.05f) hScroll.animateScrollTo((b.at.x * pageWpx - with(density) { 40.dp.toPx() }).toInt().coerceAtLeast(0))
                }
                Box(
                    Modifier
                        .fillMaxSize()
                        .pointerInput(Unit) {
                            // Deux doigts : pincer pour zoomer, glisser pour se déplacer (un doigt écrit ou dessine)
                            awaitEachGesture {
                                awaitFirstDown(requireUnconsumed = false)
                                do {
                                    val ev = awaitPointerEvent(PointerEventPass.Initial)
                                    if (ev.changes.count { it.pressed } >= 2) {
                                        val z = ev.calculateZoom()
                                        val pan = ev.calculatePan()
                                        if (z != 1f) zoom = (zoom * z).coerceIn(1f, 4f)
                                        hScroll.dispatchRawDelta(-pan.x)
                                        writeScroll.dispatchRawDelta(-pan.y)
                                        ev.changes.forEach { it.consume() }
                                    }
                                } while (ev.changes.any { it.pressed })
                            }
                        }
                        .horizontalScroll(hScroll, enabled = writing)
                        .verticalScroll(writeScroll, enabled = writing),
                ) {
                Column(
                    Modifier.widthIn(min = boxW).heightIn(min = boxH),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = if (writing) Arrangement.Top else Arrangement.Center,
                ) {
                Box(
                    Modifier
                        .width(wDp)
                        .height(hDp)
                        .background(Color.White)
                        .onSizeChanged { pageWpx = it.width.toFloat(); pageHpx = it.height.toFloat() },
                ) {
                    bmp?.let { Image(it.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = ContentScale.FillBounds) }
                    Canvas(
                        Modifier
                            .fillMaxSize()
                            .pointerInput(tool, color, thick, textSize, sigSize, signature, docLines, snap) {
                                fun norm(o: Offset) = P((o.x / size.width).coerceIn(0f, 1f), (o.y / size.height).coerceIn(0f, 1f))
                                when (tool) {
                                    Tool.PEN, Tool.HIGHLIGHT -> detectDragGestures(
                                        onDragStart = { stroke.clear(); stroke.add(norm(it)) },
                                        onDrag = { ch, _ -> stroke.add(norm(ch.position)) },
                                        onDragCancel = { stroke.clear() },
                                        onDragEnd = {
                                            val wPx = if (tool == Tool.HIGHLIGHT) thick * 3f else thick
                                            marks.add(Mark.Ink(stroke.toList(), color, wPx * density.density / size.width, highlight = tool == Tool.HIGHLIGHT))
                                            stroke.clear()
                                        },
                                    )
                                    Tool.HIDE -> detectDragGestures(
                                        onDragStart = { boxStart = norm(it); boxEnd = norm(it) },
                                        onDrag = { ch, _ -> boxEnd = norm(ch.position) },
                                        onDragCancel = { boxStart = null; boxEnd = null },
                                        onDragEnd = {
                                            val a = boxStart; val b = boxEnd
                                            if (a != null && b != null) marks.add(Mark.Box(a, b, color))
                                            boxStart = null; boxEnd = null
                                        },
                                    )
                                    Tool.WRITE -> detectTapGestures { o ->
                                        val n = norm(o)
                                        // Hauteur d'une ligne (en fraction de la hauteur de la page)
                                        val lineH = textSize * 1.25f / ratio
                                        // Par défaut : la première ligne est centrée là où on touche.
                                        // Option « Aligner » : posée sur la ligne du document la plus proche, sinon sur une grille invisible.
                                        val docLine = if (snap) docLines.firstOrNull { it >= n.y - lineH * 0.4f && it - n.y <= lineH * 1.3f } else null
                                        val top = when {
                                            docLine != null -> docLine - 1.1f * textSize / ratio
                                            snap -> kotlin.math.floor(n.y / lineH) * lineH
                                            else -> n.y - lineH * 0.5f
                                        }
                                        val k = nextKey++
                                        writes.add(WriteBox(k, P(n.x.coerceAtMost(0.9f), top.coerceIn(0f, 0.98f)), color, textSize))
                                        texts[k] = androidx.compose.ui.text.input.TextFieldValue("")
                                        focusKey = k
                                    }
                                    Tool.ERASE -> detectTapGestures { o -> eraseAt(norm(o)) }
                                    Tool.SIGN -> detectTapGestures { o ->
                                        val sig = signature ?: run { signing = true; return@detectTapGestures }
                                        val c = norm(o)
                                        sig.strokes.forEach { s ->
                                            marks.add(
                                                Mark.Ink(
                                                    s.map { p -> P(c.x + (p.x - 0.5f) * sigSize, c.y + (p.y - 0.5f) * sigSize / ratio / sig.aspect) },
                                                    color = 0xFF0D1B4C.toInt(), width = 0.0045f * (sigSize / 0.3f),
                                                ),
                                            )
                                        }
                                    }
                                }
                            },
                    ) {
                        val all = marks.toList() + (if (stroke.size > 1) listOf(Mark.Ink(stroke.toList(), color, (if (tool == Tool.HIGHLIGHT) thick * 3f else thick) * density.density / size.width, tool == Tool.HIGHLIGHT)) else emptyList())
                        all.forEach { m -> drawMark(m, size) }
                        val a = boxStart; val b = boxEnd
                        if (a != null && b != null) {
                            drawRect(Color(color).copy(alpha = 0.7f), Offset(min(a.x, b.x) * size.width, min(a.y, b.y) * size.height), Size(kotlin.math.abs(b.x - a.x) * size.width, kotlin.math.abs(b.y - a.y) * size.height))
                        }
                    }
                    // Zones de texte tapées sur la page
                    writes.toList().forEach { b ->
                        val fr = requesters.getOrPut(b.key) { androidx.compose.ui.focus.FocusRequester() }
                        val fontPx = b.size * px
                        val style = androidx.compose.ui.text.TextStyle(
                            color = Color(b.color),
                            fontSize = with(density) { fontPx.toSp() },
                            lineHeight = with(density) { (fontPx * 1.25f).toSp() },
                            fontFamily = androidx.compose.ui.text.font.FontFamily.SansSerif,
                        )
                        androidx.compose.foundation.text.BasicTextField(
                            value = texts[b.key] ?: androidx.compose.ui.text.input.TextFieldValue(""),
                            onValueChange = { texts[b.key] = it },
                            textStyle = style,
                            readOnly = !writing,
                            cursorBrush = androidx.compose.ui.graphics.SolidColor(Color(b.color)),
                            onTextLayout = { layouts[b.key] = it },
                            keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(capitalization = androidx.compose.ui.text.input.KeyboardCapitalization.Sentences),
                            modifier = Modifier
                                .offset(x = (b.at.x * w).dp, y = (b.at.y * w * ratio).dp)
                                .width(((1f - b.at.x - 0.02f).coerceAtLeast(0.08f) * w).dp)
                                .then(if (b.key == focusKey && writing) Modifier.background(Color(0x143A7BD5)) else Modifier)
                                .then(
                                    if (tool == Tool.ERASE) Modifier.pointerInput(b.key) {
                                        detectTapGestures { writes.removeAll { it.key == b.key }; texts.remove(b.key) }
                                    } else Modifier,
                                )
                                .focusRequester(fr)
                                .onFocusChanged { f ->
                                    if (f.isFocused) focusKey = b.key
                                    else if (texts[b.key]?.text.isNullOrBlank() && focusKey != b.key) {
                                        writes.removeAll { it.key == b.key }; texts.remove(b.key)
                                    }
                                },
                        )
                        if (b.key == focusKey && writing) LaunchedEffect(b.key) { runCatching { fr.requestFocus() } }
                        // Poignée pour déplacer la zone librement (à gauche de la première ligne)
                        if (writing) {
                            val handle = 26.dp
                            val lineDp = with(density) { (fontPx * 1.25f).toDp() }
                            Box(
                                Modifier
                                    .offset(
                                        // Pas la place à gauche (bord de la page) : la poignée passe au-dessus
                                        x = if ((b.at.x * w).dp < handle + 2.dp) (b.at.x * w).dp else (b.at.x * w).dp - handle - 2.dp,
                                        y = if ((b.at.x * w).dp < handle + 2.dp) (b.at.y * w * ratio).dp - handle else (b.at.y * w * ratio).dp + lineDp / 2 - handle / 2,
                                    )
                                    .size(handle)
                                    .clip(CircleShape)
                                    .background(MaterialTheme.colorScheme.primary.copy(alpha = if (b.key == focusKey) 0.9f else 0.45f))
                                    .pointerInput(b.key) {
                                        detectDragGestures(onDragStart = { focusKey = b.key }) { ch, d ->
                                            ch.consume()
                                            b.at = P((b.at.x + d.x / pageWpx).coerceIn(0f, 0.95f), (b.at.y + d.y / pageHpx).coerceIn(0f, 0.98f))
                                        }
                                    },
                                contentAlignment = Alignment.Center,
                            ) { Icon(Icons.Filled.OpenWith, "Déplacer le texte", tint = MaterialTheme.colorScheme.onPrimary, modifier = Modifier.size(16.dp)) }
                        }
                    }
                }
                }
                }
                // Zoom de la page (aussi en pinçant avec deux doigts)
                Column(Modifier.align(Alignment.BottomEnd).padding(4.dp), verticalArrangement = Arrangement.spacedBy(6.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    if (zoom > 1.05f) Surface(shape = CircleShape, color = Color.Black.copy(alpha = 0.55f)) {
                        RawText("${(zoom * 100).toInt()} %", color = Color.White, style = MaterialTheme.typography.labelSmall, modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp))
                    }
                    SmallFloatingActionButton(onClick = { zoom = (zoom * 1.4f).coerceAtMost(4f) }) { Icon(Icons.Filled.ZoomIn, "Agrandir") }
                    SmallFloatingActionButton(onClick = { zoom = (zoom / 1.4f).coerceAtLeast(1f) }) { Icon(Icons.Filled.ZoomOut, "Réduire") }
                }
            }
        }
    }

    if (signing) SignatureDialog(onDismiss = { signing = false }) { s ->
        Signature.save(ctx, s); signature = s; signing = false; tool = Tool.SIGN
    }
}

/** Dessin d'une annotation à l'écran (même rendu que dans le PDF). */
private fun androidx.compose.ui.graphics.drawscope.DrawScope.drawMark(m: Mark, sz: Size) {
    when (m) {
        is Mark.Ink -> {
            val path = Path()
            m.points.forEachIndexed { i, p -> if (i == 0) path.moveTo(p.x * sz.width, p.y * sz.height) else path.lineTo(p.x * sz.width, p.y * sz.height) }
            if (m.points.size == 1) path.lineTo(m.points[0].x * sz.width + 0.5f, m.points[0].y * sz.height)
            drawPath(path, Color(m.color).copy(alpha = if (m.highlight) 0.35f else 1f), style = Stroke(max(1f, m.width * sz.width), cap = StrokeCap.Round, join = StrokeJoin.Round))
        }
        is Mark.Text -> {
            val paint = android.graphics.Paint().apply {
                isAntiAlias = true; color = m.color; textSize = m.size * sz.width; typeface = android.graphics.Typeface.SANS_SERIF
            }
            m.text.lines().forEachIndexed { i, line ->
                drawContext.canvas.nativeCanvas.drawText(line, m.at.x * sz.width, m.at.y * sz.height + paint.textSize * (0.85f + i * 1.25f), paint)
            }
        }
        is Mark.Box -> drawRect(
            Color(m.color),
            Offset(min(m.a.x, m.b.x) * sz.width, min(m.a.y, m.b.y) * sz.height),
            Size(kotlin.math.abs(m.b.x - m.a.x) * sz.width, kotlin.math.abs(m.b.y - m.a.y) * sz.height),
        )
    }
}

/** Signature dessinée une fois, gardée pour les prochaines fois ([aspect] : largeur / hauteur du cadre). */
private class Signature(val strokes: List<List<P>>, val aspect: Float) {
    companion object {
        private fun p(ctx: android.content.Context) = ctx.getSharedPreferences("calepin_pdf", android.content.Context.MODE_PRIVATE)

        fun load(ctx: android.content.Context): Signature? = runCatching {
            val o = org.json.JSONObject(p(ctx).getString("signature", null) ?: return null)
            val a = o.getJSONArray("s")
            Signature((0 until a.length()).map { i ->
                val s = a.getJSONArray(i)
                (0 until s.length() / 2).map { k -> P(s.getDouble(2 * k).toFloat(), s.getDouble(2 * k + 1).toFloat()) }
            }, o.optDouble("aspect", 2.5).toFloat())
        }.getOrNull()

        fun save(ctx: android.content.Context, s: Signature) {
            val a = JSONArray()
            s.strokes.forEach { st -> a.put(JSONArray().apply { st.forEach { put(it.x.toDouble()); put(it.y.toDouble()) } }) }
            p(ctx).edit().putString("signature", org.json.JSONObject().put("s", a).put("aspect", s.aspect.toDouble()).toString()).apply()
        }
    }
}

@Composable
private fun SignatureDialog(onDismiss: () -> Unit, onSave: (Signature) -> Unit) {
    val strokes = remember { mutableStateListOf<List<P>>() }
    val cur = remember { mutableStateListOf<P>() }
    val aspect = 2.5f
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Ta signature") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Signe avec le doigt dans le cadre. Elle sera gardée pour les prochaines fois.", style = MaterialTheme.typography.bodySmall)
                Canvas(
                    Modifier
                        .fillMaxWidth()
                        .aspectRatio(aspect)
                        .clip(RoundedCornerShape(10.dp))
                        .background(Color.White)
                        .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(10.dp))
                        .pointerInput(Unit) {
                            fun n(o: Offset) = P((o.x / size.width).coerceIn(0f, 1f), (o.y / size.height).coerceIn(0f, 1f))
                            detectDragGestures(
                                onDragStart = { cur.clear(); cur.add(n(it)) },
                                onDrag = { ch, _ -> cur.add(n(ch.position)) },
                                onDragEnd = { strokes.add(cur.toList()); cur.clear() },
                            )
                        },
                ) {
                    drawLine(Color(0xFFBDBDBD), Offset(size.width * 0.08f, size.height * 0.78f), Offset(size.width * 0.92f, size.height * 0.78f), 1.dp.toPx())
                    (strokes + listOf(cur.toList())).forEach { s ->
                        if (s.size > 1) {
                            val path = Path()
                            s.forEachIndexed { i, p -> if (i == 0) path.moveTo(p.x * size.width, p.y * size.height) else path.lineTo(p.x * size.width, p.y * size.height) }
                            drawPath(path, Color(0xFF0D1B4C), style = Stroke(2.5.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round))
                        }
                    }
                }
                TextButton(onClick = { strokes.clear() }) { Text("Effacer") }
            }
        },
        confirmButton = { TextButton(enabled = strokes.isNotEmpty(), onClick = { onSave(Signature(strokes.toList(), aspect)) }) { Text("Garder cette signature") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Annuler") } },
    )
}

// ------------------------------------------------------------------ Formulaires

@Composable
private fun FormDialog(lib: PdfLibrary, id: String, onDismiss: () -> Unit, onSave: (Map<String, String>, Boolean) -> Unit) {
    val ctx = LocalContext.current
    val fields by produceState<List<PdfLibrary.FormField>?>(null, id) { value = lib.formFields(id) }
    val values = remember { androidx.compose.runtime.mutableStateMapOf<String, String>() }
    var flatten by remember { mutableStateOf(false) }
    LaunchedEffect(fields) { fields?.forEach { f -> if (f.name !in values) values[f.name] = f.value } }
    val f = fields
    if (f != null && f.isEmpty()) {
        LaunchedEffect(Unit) { I18n.toast(ctx, "Ce PDF n'a pas de champs à remplir. Utilise « Annoter » et l'outil Texte pour écrire dessus.", Toast.LENGTH_LONG).show(); onDismiss() }
        return
    }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Remplir le formulaire") },
        text = {
            if (f == null) LinearProgressIndicator(Modifier.fillMaxWidth())
            else LazyColumn(Modifier.heightIn(max = 420.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                itemsIndexed(f) { _, field ->
                    if (field.checkbox) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Checkbox(checked = values[field.name].orEmpty().isNotEmpty(), onCheckedChange = { values[field.name] = if (it) "1" else "" })
                            RawText(field.label)
                        }
                    } else {
                        OutlinedTextField(values[field.name].orEmpty(), { values[field.name] = it }, label = { RawText(field.label) }, modifier = Modifier.fillMaxWidth())
                    }
                }
                item {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(checked = flatten, onCheckedChange = { flatten = it })
                        Text("Figer les réponses (le formulaire ne sera plus modifiable)")
                    }
                }
            }
        },
        confirmButton = { TextButton(enabled = f != null, onClick = { onSave(values.toMap(), flatten) }) { Text("Enregistrer") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Annuler") } },
    )
}

