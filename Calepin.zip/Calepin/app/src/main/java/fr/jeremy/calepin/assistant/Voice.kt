package fr.jeremy.calepin.assistant

import android.content.Context
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import fr.jeremy.calepin.audio.Transcriber
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import org.vosk.Recognizer
import org.vosk.android.RecognitionListener
import org.vosk.android.SpeechService
import java.util.Locale

/** Voix de l'assistant : synthèse vocale du téléphone (fonctionne hors ligne avec la voix française installée). */
class Speaker(context: Context, private val finished: () -> Unit = {}) {
    private var ready = false
    private var queued: String? = null
    var rate: Float = 1.0f

    private val tts: TextToSpeech = TextToSpeech(context.applicationContext) { status ->
        if (status == TextToSpeech.SUCCESS) {
            ready = true
            tts.setLanguage(Locale.FRANCE)
            tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(id: String?) = Unit
                override fun onDone(id: String?) = finished()
                @Deprecated("Deprecated in Java")
                override fun onError(id: String?) = finished()
            })
            queued?.let { speak(it) }
            queued = null
        }
    }

    fun speak(text: String) {
        if (!ready) { queued = text; return }
        tts.setSpeechRate(rate)
        // Lecture plus naturelle : puces et symboles retirés
        val clean = text.replace("•", ",").replace("«", "").replace("»", "").replace(" · ", ", ")
        tts.speak(clean, TextToSpeech.QUEUE_FLUSH, null, "calepin-" + System.nanoTime())
    }

    fun stop() { if (ready) tts.stop() }
    fun shutdown() { tts.stop(); tts.shutdown() }
}

/**
 * Écoute hors ligne avec Vosk (module français déjà utilisé pour la transcription).
 * S'arrête tout seul à la fin de la phrase.
 */
class OfflineListener(private val context: Context) {
    private var service: SpeechService? = null

    val available: Boolean get() = Transcriber.isInstalled(context)

    suspend fun start(onPartial: (String) -> Unit, onResult: (String) -> Unit, onError: (String) -> Unit) {
        // Noms distincts : dans l'objet ci-dessous, « onResult(…) » appellerait sa propre méthode
        val partialCb = onPartial
        val resultCb = onResult
        val errorCb = onError
        stop()
        val model = withContext(Dispatchers.IO) { Transcriber.model(context) }
        val rec = Recognizer(model, 16000f)
        val svc = SpeechService(rec, 16000f)
        service = svc
        svc.startListening(object : RecognitionListener {
            override fun onPartialResult(hypothesis: String?) {
                text(hypothesis, "partial")?.let(partialCb)
            }
            override fun onResult(hypothesis: String?) {
                val t = text(hypothesis, "text")
                if (!t.isNullOrBlank()) { stop(); resultCb(t) }
            }
            override fun onFinalResult(hypothesis: String?) {
                val t = text(hypothesis, "text")
                stop()
                if (!t.isNullOrBlank()) resultCb(t) else errorCb("Je n'ai rien entendu.")
            }
            override fun onError(exception: Exception?) { stop(); errorCb(exception?.message ?: "Micro indisponible") }
            override fun onTimeout() { stop(); errorCb("Je n'ai rien entendu.") }
        }, 10_000)
    }

    fun stop() {
        service?.let { runCatching { it.stop() }; runCatching { it.shutdown() } }
        service = null
    }

    private fun text(json: String?, key: String): String? =
        runCatching { JSONObject(json ?: return null).optString(key) }.getOrNull()?.trim()?.takeIf { it.isNotEmpty() }
}
