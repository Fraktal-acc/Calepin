package fr.jeremy.calepin.search

import fr.jeremy.calepin.data.Note
import fr.jeremy.calepin.detect.Entity
import fr.jeremy.calepin.detect.EntityType
import fr.jeremy.calepin.detect.PhoneCountries
import java.text.Normalizer
import java.util.Calendar
import java.util.concurrent.ConcurrentHashMap

// ------------------------------------------------------------------ Options

enum class Scope(val label: String) { ALL("Partout"), TITLE("Titre"), CONTENT("Contenu"), TAG("Étiquettes") }

enum class Period(val label: String, val days: Int) {
    ANY("Toutes", 0), WEEK("7 derniers jours", 7), MONTH("30 derniers jours", 30), YEAR("12 derniers mois", 365)
}

enum class Sort(val label: String) {
    RELEVANCE("Pertinence"), UPDATED("Modifiées récemment"), CREATED("Créées récemment"), TITLE("Titre A → Z")
}

data class SearchOptions(
    val scope: Scope = Scope.ALL,
    val types: Set<EntityType> = emptySet(),
    val tags: Set<String> = emptySet(),
    val period: Period = Period.ANY,
    val sort: Sort = Sort.RELEVANCE,
    val fuzzy: Boolean = true,
    val pinnedOnly: Boolean = false,
) {
    val activeCount: Int
        get() = listOf(
            scope != Scope.ALL, types.isNotEmpty(), tags.isNotEmpty(), period != Period.ANY,
            sort != Sort.RELEVANCE, !fuzzy, pinnedOnly,
        ).count { it }
}

data class Snippet(val text: String, val highlights: List<IntRange>)

data class SearchResult(
    val note: Note,
    val entities: List<Entity>,
    val score: Double,
    val titleHighlights: List<IntRange>,
    val snippet: Snippet,
    val approximate: Boolean,
)

// --------------------------------------------------------- Normalisation

object TextNorm {
    private val cache = ConcurrentHashMap<Char, String>()

    fun normChar(c: Char): String = cache.getOrPut(c) {
        when (c) {
            'œ', 'Œ' -> "oe"
            'æ', 'Æ' -> "ae"
            'ß' -> "ss"
            '’', '‘', '`', 'ʼ' -> "'"
            ' ', ' ' -> " "
            else -> Normalizer.normalize(c.toString(), Normalizer.Form.NFD)
                .filter { Character.getType(it) != Character.NON_SPACING_MARK.toInt() }
                .lowercase()
        }
    }

    fun norm(s: String): String = buildString { s.forEach { append(normChar(it)) } }
}

/** Texte normalisé (minuscules, sans accents) + table de correspondance vers le texte d'origine. */
class Indexed(val original: String) {
    val norm: String
    private val map: IntArray
    val digits: String
    private val dmap: IntArray

    init {
        val sb = StringBuilder()
        val m = ArrayList<Int>(original.length)
        val db = StringBuilder()
        val dm = ArrayList<Int>()
        original.forEachIndexed { i, ch ->
            val n = TextNorm.normChar(ch)
            for (c in n) { sb.append(c); m.add(i) }
            if (ch.isDigit()) { db.append(ch); dm.add(i) }
        }
        norm = sb.toString(); map = m.toIntArray()
        digits = db.toString(); dmap = dm.toIntArray()
    }

    fun toOriginal(start: Int, endExclusive: Int, digitSpace: Boolean = false): IntRange {
        val mp = if (digitSpace) dmap else map
        return mp[start]..mp[endExclusive - 1]
    }
}

// ------------------------------------------------------------- Requête

enum class Field { ANY, TITLE, CONTENT, TAG }

data class Term(
    val text: String,
    val phrase: Boolean,
    val field: Field,
    val digitsOnly: Boolean,
    /** Pour une recherche de numéro : partie nationale, pour trouver +33 6…, 0033 6… et 06… indifféremment. */
    val phoneNsn: String? = null,
)
data class Clause(val alternatives: List<Term>, val negated: Boolean)
data class DateSpec(val day: Int?, val month: Int?, val year: Int?)

data class ParsedQuery(
    val clauses: List<Clause> = emptyList(),
    val types: Set<EntityType> = emptySet(),
    val tags: Set<String> = emptySet(),
    val before: Long? = null,
    val after: Long? = null,
    val onDate: DateSpec? = null,
    val pinnedOnly: Boolean = false,
    val countries: Set<String> = emptySet(),
) {
    val hasText get() = clauses.any { !it.negated }
}

object QueryParser {
    private data class Tok(val raw: String, val quoted: Boolean, val neg: Boolean, val prefix: String?)

    private val rxPrefix = Regex("""^([\p{L}]+):""")

    private val TYPE_WORDS = mapOf(
        "tel" to EntityType.PHONE, "telephone" to EntityType.PHONE, "phone" to EntityType.PHONE,
        "numero" to EntityType.PHONE, "portable" to EntityType.PHONE,
        "adresse" to EntityType.ADDRESS, "adresses" to EntityType.ADDRESS, "lieu" to EntityType.ADDRESS,
        "date" to EntityType.DATE, "dates" to EntityType.DATE, "rdv" to EntityType.DATE,
        "email" to EntityType.EMAIL, "mail" to EntityType.EMAIL, "courriel" to EntityType.EMAIL,
        "lien" to EntityType.URL, "liens" to EntityType.URL, "url" to EntityType.URL, "site" to EntityType.URL,
    )

    private fun tokenize(q: String): List<Tok> {
        val out = mutableListOf<Tok>()
        var i = 0
        while (i < q.length) {
            if (q[i].isWhitespace()) { i++; continue }
            var neg = false
            if (q[i] == '-' && i + 1 < q.length && !q[i + 1].isWhitespace()) { neg = true; i++ }
            var prefix: String? = null
            rxPrefix.find(q.substring(i))?.let { m ->
                prefix = TextNorm.norm(m.groupValues[1]); i += m.value.length
            }
            if (i < q.length && (q[i] == '"' || q[i] == '«' || q[i] == '“')) {
                val close = when (q[i]) { '«' -> '»'; '“' -> '”'; else -> '"' }
                val end = q.indexOf(close, i + 1).let { if (it < 0) q.length else it }
                out += Tok(q.substring(i + 1, end).trim(), true, neg, prefix)
                i = end + 1
            } else {
                var j = i
                while (j < q.length && !q[j].isWhitespace()) j++
                out += Tok(q.substring(i, j), false, neg, prefix)
                i = j
            }
        }
        return out
    }

    private val rxWholePhone = Regex("""^[+(]?\d[\d .\-()]{4,}$""")

    fun parse(query: String): ParsedQuery {
        // Une requête qui n'est qu'un numéro (« 06 12 34 », « +377 93 ») est cherchée d'un bloc, espaces ignorés.
        val trimmed = query.trim()
        if (rxWholePhone.matches(trimmed) && trimmed.count { it.isDigit() } >= 3) {
            val term = Term(trimmed.filter { it.isDigit() }, false, Field.ANY, true, PhoneCountries.nationalPart(trimmed))
            return ParsedQuery(clauses = listOf(Clause(listOf(term), false)))
        }
        val clauses = mutableListOf<Clause>()
        val types = mutableSetOf<EntityType>()
        val tags = mutableSetOf<String>()
        var before: Long? = null
        var after: Long? = null
        var onDate: DateSpec? = null
        var pinned = false
        var joinNext = false
        val countries = mutableSetOf<String>()

        for (t in tokenize(query)) {
            val raw = t.raw
            if (!t.quoted && t.prefix == null && (raw == "OU" || raw == "OR" || raw == "|")) {
                joinNext = clauses.isNotEmpty(); continue
            }
            if (raw.isEmpty()) continue
            val value = TextNorm.norm(raw)
            var field = Field.ANY
            when (t.prefix) {
                "type", "contient" -> { TYPE_WORDS[value]?.let { types += it }; continue }
                "tag", "etiquette" -> { tags += value; continue }
                "avant" -> { before = parseDateSpec(value)?.let { startOf(it) }; continue }
                "apres", "depuis" -> { after = parseDateSpec(value)?.let { startOf(it) }; continue }
                "date", "le" -> { onDate = parseDateSpec(value); continue }
                "pays", "country", "indicatif" -> { countries += value; continue }
                "est", "is" -> { if (value.startsWith("epingl") || value == "pinned") pinned = true; continue }
                "titre", "title" -> field = Field.TITLE
                "contenu", "texte" -> field = Field.CONTENT
                null -> Unit
                else -> Unit // préfixe inconnu (ex. « http: ») : on cherche le texte tel quel
            }
            if (!t.quoted && t.prefix == null && raw.startsWith("#") && raw.length > 1) {
                tags += TextNorm.norm(raw.substring(1)); continue
            }
            val fullText = if (t.prefix != null && field == Field.ANY) TextNorm.norm(t.prefix + ":" + raw) else value
            val digitCount = raw.count { it.isDigit() }
            val digitsOnly = !t.quoted && digitCount >= 3 && raw.all { it.isDigit() || it in " .-+()" }
            val term = Term(
                text = if (digitsOnly) raw.filter { it.isDigit() } else fullText,
                phrase = t.quoted,
                field = field,
                digitsOnly = digitsOnly,
                phoneNsn = if (digitsOnly) PhoneCountries.nationalPart(raw) else null,
            )
            if (joinNext && clauses.isNotEmpty() && !t.neg) {
                val last = clauses.removeAt(clauses.lastIndex)
                clauses += last.copy(alternatives = last.alternatives + term)
            } else {
                clauses += Clause(listOf(term), t.neg)
            }
            joinNext = false
        }
        return ParsedQuery(clauses, types, tags, before, after, onDate, pinned, countries)
    }

    /** « 12/10/2026 », « 12/10 », « 10/2026 », « 2026 ». */
    fun parseDateSpec(s: String): DateSpec? {
        val parts = s.split('/', '-', '.').filter { it.isNotEmpty() }
        val n = parts.map { it.toIntOrNull() ?: return null }
        return when (n.size) {
            3 -> DateSpec(n[0], n[1], if (n[2] < 100) 2000 + n[2] else n[2])
            2 -> if (parts[1].length == 4 || n[1] > 12) DateSpec(null, n[0], n[1]) else DateSpec(n[0], n[1], null)
            1 -> if (parts[0].length == 4) DateSpec(null, null, n[0]) else null
            else -> null
        }
    }

    fun startOf(d: DateSpec): Long {
        val year = d.year ?: Calendar.getInstance().get(Calendar.YEAR)
        return Calendar.getInstance().apply {
            clear()
            set(year, (d.month ?: 1) - 1, d.day ?: 1)
        }.timeInMillis
    }
}

// --------------------------------------------------------------- Moteur

object SearchEngine {

    private class NoteIndex(val note: Note, val entities: List<Entity>) {
        val title = Indexed(note.title)
        val content = Indexed(note.content)
        val tag = Indexed(note.tag)
        val tagSet: Set<String> = note.tags.map { TextNorm.norm(it) }.toSet()
        val types: Set<EntityType> = entities.map { it.type }.toSet()
    }

    private val cache = ConcurrentHashMap<Long, NoteIndex>()

    private data class Hit(val range: IntRange, val quality: Int) // 0 approx, 1 dans un mot, 2 début de mot, 3 mot entier

    private val rxWord = Regex("""[\p{L}\d']+""")

    fun search(
        notes: List<Note>,
        query: String,
        options: SearchOptions,
        entitiesOf: (Note) -> List<Entity>,
        now: Long = System.currentTimeMillis(),
    ): List<SearchResult> {
        val q = QueryParser.parse(query)
        val alive = notes.map { it.id }.toSet()
        cache.keys.retainAll(alive)

        val results = ArrayList<SearchResult>()
        for (note in notes) {
            val ix = cache[note.id]?.takeIf { it.note == note }
                ?: NoteIndex(note, entitiesOf(note)).also { cache[note.id] = it }

            // Filtres
            if ((options.pinnedOnly || q.pinnedOnly) && !note.pinned) continue
            val needTypes = options.types + q.types
            if (!ix.types.containsAll(needTypes)) continue
            val needTags = options.tags.map { TextNorm.norm(it) }.toSet() + q.tags
            if (needTags.isNotEmpty() && needTags.none { wanted -> ix.tagSet.any { it == wanted || it.startsWith(wanted) } }) continue
            if (options.period != Period.ANY && note.updatedAt < now - options.period.days * 86_400_000L) continue
            val before = q.before
            if (before != null && note.updatedAt >= before) continue
            val after = q.after
            if (after != null && note.updatedAt < after) continue
            val spec = q.onDate
            if (spec != null && ix.entities.none { e -> e.timeMillis != null && matchesDate(e.timeMillis, spec) }) continue

            if (q.countries.isNotEmpty() && q.countries.none { wanted -> ix.entities.any { e -> countryMatches(e, wanted) } }) continue

            // Texte
            var score = 0.0
            var ok = true
            var approx = false
            val titleHl = mutableListOf<IntRange>()
            val contentHl = mutableListOf<IntRange>()

            for (clause in q.clauses) {
                if (clause.negated) {
                    val found = clause.alternatives.any { term ->
                        fieldsFor(term, options.scope).any { f ->
                            findHits(pick(ix, f), term, fuzzy = false).isNotEmpty() || phoneHits(ix, term, f).isNotEmpty()
                        }
                    }
                    if (found) { ok = false; break }
                    continue
                }
                var best = 0.0
                for (term in clause.alternatives) {
                    var s = 0.0
                    for (f in fieldsFor(term, options.scope)) {
                        val hits = findHits(pick(ix, f), term, options.fuzzy) + phoneHits(ix, term, f)
                        if (hits.isEmpty()) continue
                        val weight = when (f) { Field.TITLE -> 3.0; Field.TAG -> 2.0; else -> 1.0 }
                        val q0 = hits.maxOf { it.quality }
                        if (q0 == 0) approx = true
                        s += weight * (2.0 + q0 * 2 + minOf(hits.size, 5) * 0.5 + if (term.phrase) 3 else 0)
                        when (f) {
                            Field.TITLE -> titleHl += hits.map { it.range }
                            Field.CONTENT -> contentHl += hits.map { it.range }
                            else -> Unit
                        }
                    }
                    best = maxOf(best, s)
                }
                if (best == 0.0) { ok = false; break }
                score += best
            }
            if (!ok) continue
            if (note.pinned) score += 1.0

            results += SearchResult(
                note = note,
                entities = ix.entities,
                score = score,
                titleHighlights = merge(titleHl),
                snippet = snippet(note.content, merge(contentHl)),
                approximate = approx,
            )
        }

        val byUpdated = compareByDescending<SearchResult> { it.note.updatedAt }
        val sorted = when {
            options.sort == Sort.RELEVANCE && !q.hasText ->
                results.sortedWith(compareByDescending<SearchResult> { it.note.pinned }.then(byUpdated))
            options.sort == Sort.RELEVANCE -> results.sortedWith(compareByDescending<SearchResult> { it.score }.then(byUpdated))
            options.sort == Sort.UPDATED -> results.sortedWith(byUpdated)
            options.sort == Sort.CREATED -> results.sortedByDescending { it.note.createdAt }
            else -> results.sortedBy { TextNorm.norm(it.note.title.ifBlank { it.note.content }) }
        }
        return sorted
    }

    private fun fieldsFor(term: Term, scope: Scope): List<Field> = when {
        term.field != Field.ANY -> listOf(term.field)
        scope == Scope.TITLE -> listOf(Field.TITLE)
        scope == Scope.CONTENT -> listOf(Field.CONTENT)
        scope == Scope.TAG -> listOf(Field.TAG)
        else -> listOf(Field.TITLE, Field.CONTENT, Field.TAG)
    }

    private fun pick(ix: NoteIndex, f: Field): Indexed = when (f) {
        Field.TITLE -> ix.title
        Field.TAG -> ix.tag
        else -> ix.content
    }

    /** Un numéro cherché retrouve les numéros de la note quel que soit leur format (+33, 0033, 0…, espaces). */
    private fun phoneHits(ix: NoteIndex, term: Term, f: Field): List<Hit> {
        val nsn = term.phoneNsn ?: return emptyList()
        if (f != Field.CONTENT || nsn.length < 3) return emptyList()
        return ix.entities
            .filter { it.type == EntityType.PHONE && PhoneCountries.nationalPart(it.value).contains(nsn) }
            .map { Hit(it.start until it.end, 3) }
    }

    private fun countryMatches(e: Entity, wanted: String): Boolean {
        if (e.type != EntityType.PHONE) return false
        val c = TextNorm.norm(e.country ?: return false)
        val code = wanted.trimStart('+')
        return if (code.isNotEmpty() && code.all { it.isDigit() }) c.contains("(+$code)") else c.contains(wanted)
    }

    private fun findHits(ix: Indexed, term: Term, fuzzy: Boolean): List<Hit> {
        val needle = term.text
        if (needle.isEmpty()) return emptyList()
        val hay = if (term.digitsOnly) ix.digits else ix.norm
        val hits = mutableListOf<Hit>()
        var from = 0
        while (true) {
            val at = hay.indexOf(needle, from)
            if (at < 0) break
            val end = at + needle.length
            val quality = if (term.digitsOnly) 3 else {
                val startOk = at == 0 || !hay[at - 1].isLetterOrDigit()
                val endOk = end == hay.length || !hay[end].isLetterOrDigit()
                when { startOk && endOk -> 3; startOk -> 2; else -> 1 }
            }
            hits += Hit(ix.toOriginal(at, end, term.digitsOnly), quality)
            from = end
        }
        if (hits.isNotEmpty() || !fuzzy || term.phrase || term.digitsOnly || needle.length < 4 || needle.contains(' ')) {
            return hits
        }
        // Recherche approximative : tolère 1 faute (2 au-delà de 7 lettres), y compris sur un début de mot.
        val allowed = if (needle.length >= 8) 2 else 1
        for (m in rxWord.findAll(hay)) {
            val w = m.value
            if (w.length + allowed < needle.length) continue
            val d = minOf(
                if (kotlin.math.abs(w.length - needle.length) <= allowed) levenshtein(w, needle, allowed) else allowed + 1,
                if (w.length > needle.length) levenshtein(w.substring(0, needle.length), needle, allowed) else allowed + 1,
            )
            if (d <= allowed) hits += Hit(ix.toOriginal(m.range.first, m.range.last + 1), 0)
        }
        return hits
    }

    /** Distance d'édition avec arrêt anticipé au-delà de [max]. */
    fun levenshtein(a: String, b: String, max: Int): Int {
        if (a == b) return 0
        var prev = IntArray(b.length + 1) { it }
        var cur = IntArray(b.length + 1)
        for (i in 1..a.length) {
            cur[0] = i
            var rowMin = cur[0]
            for (j in 1..b.length) {
                val cost = if (a[i - 1] == b[j - 1]) 0 else 1
                cur[j] = minOf(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + cost)
                if (i > 1 && j > 1 && a[i - 1] == b[j - 2] && a[i - 2] == b[j - 1]) {
                    cur[j] = minOf(cur[j], prev[j - 1]) // inversion de deux lettres = 1 faute
                }
                rowMin = minOf(rowMin, cur[j])
            }
            if (rowMin > max) return max + 1
            val t = prev; prev = cur; cur = t
        }
        return prev[b.length]
    }

    private fun matchesDate(t: Long, spec: DateSpec): Boolean {
        val c = Calendar.getInstance().apply { timeInMillis = t }
        return (spec.year == null || c.get(Calendar.YEAR) == spec.year) &&
            (spec.month == null || c.get(Calendar.MONTH) + 1 == spec.month) &&
            (spec.day == null || c.get(Calendar.DAY_OF_MONTH) == spec.day)
    }

    private fun merge(ranges: List<IntRange>): List<IntRange> {
        if (ranges.isEmpty()) return ranges
        val sorted = ranges.sortedBy { it.first }
        val out = mutableListOf(sorted[0])
        for (r in sorted.drop(1)) {
            val last = out.last()
            if (r.first <= last.last + 1) out[out.lastIndex] = last.first..maxOf(last.last, r.last) else out += r
        }
        return out
    }

    fun snippet(content: String, hits: List<IntRange>, max: Int = 170): Snippet {
        val flat = content.replace('\n', ' ').replace('\t', ' ')
        if (hits.isEmpty()) {
            val t = if (flat.length > max) flat.take(max).trimEnd() + "…" else flat
            return Snippet(t, emptyList())
        }
        var start = maxOf(0, hits.first().first - 50)
        if (start > 0) {
            val sp = flat.lastIndexOf(' ', start)
            start = if (sp in 0 until hits.first().first) sp + 1 else start
        }
        val end = minOf(flat.length, start + max)
        val prefix = if (start > 0) "…" else ""
        val suffix = if (end < flat.length) "…" else ""
        val shift = prefix.length - start
        val hl = hits.filter { it.first >= start && it.first < end }
            .map { (it.first + shift)..(minOf(it.last, end - 1) + shift) }
        return Snippet(prefix + flat.substring(start, end) + suffix, hl)
    }
}
