package fr.jeremy.calepin.ai

/** Transformations d'une note par l'IA hors ligne (Calepin IA). */
enum class AiTool(val label: String, val instruction: String) {
    RESUME("Résumer", "Résume ce texte en quelques phrases claires. Garde les informations importantes : noms, dates, heures, chiffres, adresses."),
    REFORMULER("Reformuler", "Reformule ce texte pour qu'il soit clair et agréable à lire, sans rien ajouter ni retirer d'important."),
    CORRIGER("Corriger les fautes", "Corrige l'orthographe, la grammaire et la ponctuation de ce texte. Ne change ni le sens ni le style. Garde les retours à la ligne et les lignes qui commencent par ☐ ou ☑."),
    COMPTE_RENDU(
        "Compte rendu",
        "Transforme ces notes ou cette dictée en compte rendu structuré : sur la première ligne un titre court ; " +
            "puis une ligne « Points clés : » suivie de puces « - » ; puis une ligne « À faire : » suivie d'une ligne par tâche commençant par « ☐ » " +
            "(avec qui et quand si c'est mentionné). N'invente rien.",
    ),
    TACHES("Extraire les tâches", "Liste les choses à faire présentes dans ce texte, une par ligne, chaque ligne commençant par « ☐ ». Rien d'autre."),
    ANGLAIS("Traduire en anglais", "Traduis ce texte en anglais. Garde la mise en forme."),
    ITALIEN("Traduire en italien", "Traduis ce texte en italien. Garde la mise en forme."),
    ESPAGNOL("Traduire en espagnol", "Traduis ce texte en espagnol. Garde la mise en forme."),
    ALLEMAND("Traduire en allemand", "Traduis ce texte en allemand. Garde la mise en forme."),
    FRANCAIS("Traduire en français", "Traduis ce texte en français. Garde la mise en forme."),
    ;

    companion object {
        const val SYSTEM = "Tu es l'assistant d'écriture de Calepin. Tu réponds uniquement par le texte demandé, " +
            "sans phrase d'introduction, sans commentaire et sans guillemets autour. Sauf demande de traduction, tu écris dans la même langue que le texte fourni."
    }
}
