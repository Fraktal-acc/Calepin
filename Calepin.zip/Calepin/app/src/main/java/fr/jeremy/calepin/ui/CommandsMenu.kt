package fr.jeremy.calepin.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.Brush
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.EditNote
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.Radio
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Insights
import androidx.compose.material.icons.filled.Work
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.AssistChip
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import fr.jeremy.calepin.BuildConfig
import fr.jeremy.calepin.NotesViewModel
import fr.jeremy.calepin.assistant.AssistantAction
import fr.jeremy.calepin.i18n.I18n
import fr.jeremy.calepin.i18n.RawText
import fr.jeremy.calepin.i18n.Text
import kotlinx.coroutines.launch

/** Rubrique de commandes : titre, icône et commandes (« … » : à compléter). */
private data class CommandGroup(val title: String, val icon: ImageVector, val commands: List<String>)

/** Toutes les commandes de l'assistant, rangées par fonctionnalité de Calepin. */
private fun commandGroups(custom: List<String>): List<CommandGroup> = buildList {
    add(CommandGroup("Notes", Icons.Filled.EditNote, listOf(
        "Note : acheter du pain", "Nouvelle note", "Ajoute du lait à la liste de courses", "Cherche plombier",
        "Lis la note courses", "Ouvre les notes",
    )))
    add(CommandGroup("Agenda et rappels", Icons.Filled.CalendarMonth, listOf(
        "Rendez-vous chez le dentiste jeudi à 14h30", "Ajoute au calendrier réunion lundi de 9h à 11h",
        "Rappelle-moi d'appeler le plombier dans 20 minutes", "Réveille-moi demain à 6h",
        "Qu'est-ce que j'ai demain ?", "Je suis en congés du 10 au 16 octobre",
        "Ajoute les dates de la note chantier à l'agenda", "Mets dans l'agenda du téléphone le rendez-vous de demain",
        "Supprime les rendez-vous de demain", "Annule le rendez-vous chez le dentiste", "Résumé de ma journée",
    )))
    add(CommandGroup("Planning de travail", Icons.Filled.Work, listOf(
        "Importe mon planning", "Importe le planning d'octobre dans l'agenda", "Analyse mon planning",
        "Mon planning cette semaine", "Quand est-ce que je travaille ?", "Combien d'heures ce mois-ci ?",
        "Ouvre les heures de travail", "Mode nuit au travail", "Quitte le mode nuit",
    )))
    add(CommandGroup("Appels et itinéraires", Icons.Filled.Call, listOf(
        "Appelle le 06 12 34 56 78", "Appelle le plombier", "SMS au 06 12 34 56 78",
        "Emmène-moi au Consulat d'Italie",
    )))
    add(CommandGroup("PDF et bureau", Icons.Filled.PictureAsPdf, listOf(
        "Mets en page la note chantier en PDF", "Fais un PDF de cette note",
        "Ouvre les PDF", "Ouvre le PDF contrat", "Importe le PDF facture",
        "Importe le dernier PDF téléchargé dans l'agenda", "Ouvre le bureau", "Ouvre les fichiers",
    )))
    add(CommandGroup("Radio et détente", Icons.Filled.Radio, listOf(
        "Ouvre les webradios", "Remets la radio", "Coupe la radio", "Ouvre les jeux", "Ouvre le programme télé", "Ouvre la détente",
    )))
    add(CommandGroup("Apparence", Icons.Filled.Brush, listOf(
        "Fond étoiles", "Fond d'écran neige", "Fond au hasard", "Thème aléatoire", "Nouveau tirage",
        "Garde ce thème sous le nom Plage", "Thème d'origine", "Mode sombre", "Mode clair", "Mode noir",
        "Texte plus grand", "Texte plus petit", "Icônes néon", "Désactive les animations", "Ouvre l'apparence",
    )))
    if (BuildConfig.AI) add(CommandGroup("Maison et téléphone", Icons.Filled.Home, fr.jeremy.calepin.control.DeviceCommands.EXAMPLES.map { it.replaceFirstChar { c -> c.uppercase() } } + listOf("Ouvre la télécommande", "Ouvre les appareils de la maison")))
    add(CommandGroup("Appli", Icons.Filled.Apps, listOf(
        "Ouvre les paramètres", "Quoi de neuf ?", "Ouvre la corbeille", "Ouvre la sauvegarde", "Ouvre les statistiques",
        "Ouvre les rappels par lieu", "Ouvre le nettoyeur", "Ouvre l'optimiseur", "Ouvre le mode pro",
        "Quelle heure est-il ?", "Quel jour sommes-nous ?", "Aide",
    )))
    add(CommandGroup("Mes commandes", Icons.Filled.Star, custom.ifEmpty { listOf("Mes commandes", "Quand je dis boulot, mets le mode silencieux et ouvre mon planning") }))
}

/**
 * Menu de toutes les commandes, par rubrique. Toucher une commande la propose (modifiable) puis la lance
 * comme si on l'avait dite à l'assistant.
 */
@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun CommandsMenu(vm: NotesViewModel, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    remember { fr.jeremy.calepin.control.CustomCommands.init(ctx) }
    val custom by fr.jeremy.calepin.control.CustomCommands.list.collectAsStateWithLifecycle()
    val groups = remember(custom) { commandGroups(custom.filter { it.enabled }.mapNotNull { it.triggers.firstOrNull() }) }
    var open by remember { mutableStateOf<String?>(null) }
    var chosen by remember { mutableStateOf<String?>(null) }
    var filter by remember { mutableStateOf("") }
    ModalBottomSheet(onDismissRequest = onDismiss, sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)) {
        Column(Modifier.padding(horizontal = 16.dp).navigationBarsPadding()) {
            Text("Toutes les commandes", style = MaterialTheme.typography.titleLarge)
            Text(
                "À dire ou à écrire à l'assistant. Touche une commande pour la lancer (tu peux la modifier avant).",
                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            OutlinedTextField(
                filter, { filter = it }, singleLine = true,
                placeholder = { Text("Chercher une commande") },
                leadingIcon = { Icon(Icons.Filled.Search, null) },
                modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
            )
            val q = fr.jeremy.calepin.search.TextNorm.norm(filter).lowercase().trim()
            LazyColumn(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                items(groups, key = { it.title }) { g ->
                    // Les commandes sont montrées dans la langue de l'appli (et comprises dans toutes)
                    val shown = g.commands.map { it to I18n.tr(it) }.filter { (src, tr) ->
                        q.isEmpty() || fr.jeremy.calepin.search.TextNorm.norm(src + " " + tr).lowercase().contains(q)
                    }
                    if (shown.isEmpty()) return@items
                    val expanded = q.isNotEmpty() || open == g.title
                    Surface(
                        onClick = { open = if (open == g.title) null else g.title },
                        shape = MaterialTheme.shapes.large,
                        color = MaterialTheme.colorScheme.surfaceContainerHigh,
                        modifier = Modifier.fillMaxWidth(),
                    ) {
                        Column(Modifier.padding(12.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(g.icon, null, tint = MaterialTheme.colorScheme.primary)
                                Spacer(Modifier.width(10.dp))
                                Text(g.title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                                RawText("${shown.size}", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Icon(if (expanded) Icons.Filled.ExpandLess else Icons.Filled.ExpandMore, null)
                            }
                            if (expanded) FlowRow(
                                Modifier.padding(top = 8.dp),
                                horizontalArrangement = Arrangement.spacedBy(6.dp),
                            ) {
                                shown.forEach { (_, tr) ->
                                    AssistChip(onClick = { chosen = tr }, label = { RawText("« $tr »", maxLines = 2) })
                                }
                            }
                        }
                    }
                }
                item { Spacer(Modifier.size(24.dp)) }
            }
        }
    }
    chosen?.let { c -> RunCommandDialog(vm, c, onDismiss = { chosen = null }, onDone = { chosen = null; onDismiss() }) }
}

/** Commande proposée (modifiable), lancée comme si on l'avait dite à l'assistant ; la réponse s'affiche. */
@Composable
private fun RunCommandDialog(vm: NotesViewModel, initial: String, onDismiss: () -> Unit, onDone: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var text by remember { mutableStateOf(initial) }
    var busy by remember { mutableStateOf(false) }
    var reply by remember { mutableStateOf<String?>(null) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Lancer la commande") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(text, { text = it; reply = null }, modifier = Modifier.fillMaxWidth())
                Text("Remplace les exemples (noms, dates, heures) par les tiens si besoin.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                if (busy) LinearProgressIndicator(Modifier.fillMaxWidth())
                reply?.let { RawText(it, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.primary) }
            }
        },
        confirmButton = {
            TextButton(enabled = !busy && text.isNotBlank(), onClick = {
                busy = true
                scope.launch {
                    val r = runCatching { vm.ask(text.trim()) }.getOrNull()
                    busy = false
                    reply = r?.text ?: I18n.tr("Je n'ai pas pu répondre.")
                    // Actions simples faites tout de suite (comme avec l'assistant)
                    r?.actions?.forEach { a ->
                        when (a) {
                            is AssistantAction.Dial -> fr.jeremy.calepin.Actions.dial(ctx, a.number)
                            is AssistantAction.Sms -> fr.jeremy.calepin.Actions.sms(ctx, a.number)
                            is AssistantAction.Directions -> fr.jeremy.calepin.Actions.directions(ctx, a.address)
                            is AssistantAction.PhoneCalendar -> if (a.auto) fr.jeremy.calepin.Actions.addEvent(ctx, a.title, "", a.start, !a.allDay, null, a.end.takeIf { it > a.start })
                            else -> Unit
                        }
                    }
                }
            }) { Text("Lancer") }
        },
        dismissButton = {
            if (reply != null) TextButton(onClick = onDone) { Text("Fermer le menu") }
            else TextButton(onClick = onDismiss) { Text("Annuler") }
        },
    )
}
