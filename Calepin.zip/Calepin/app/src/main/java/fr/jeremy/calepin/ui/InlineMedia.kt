package fr.jeremy.calepin.ui

import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.input.TextFieldValue
import fr.jeremy.calepin.data.Attachment
import java.text.Normalizer

/**
 * Photos et vidéos placées dans le texte d'une note : une ligne « {{photo:fichier.jpg}} » (ou video)
 * marque l'endroit ; en lecture, la photo s'affiche à cette place, sur toute la largeur.
 */
object InlineMedia {
    /** Repère (groupe 2 : le fichier ; « |right|40 » éventuel : photo placée, voir [NoteLayout]). */
    val marker = fr.jeremy.calepin.text.NoteLayout.marker
    private val markerLine = Regex("(?m)^[ \\t]*\\{\\{(?:photo|video):[^}\\n]+\\}\\}[ \\t]*(?:\\n|$)")

    /** Découpe le texte en lecture : texte, rangées de vignettes, photos placées avec le texte qui les entoure. */
    fun segments(text: String): List<fr.jeremy.calepin.text.NoteLayout.Segment> = fr.jeremy.calepin.text.NoteLayout.segments(text)

    fun markerFor(a: Attachment) = "{{" + (if (a.isVideo) "video" else "photo") + ":" + a.fileName + "}}"

    /** Fichiers déjà placés dans le texte. */
    fun placed(text: String): Set<String> = marker.findAll(text).map { it.groupValues[2] }.toSet()

    /** Texte sans les repères (photos, couleurs, alignement) : partage, lecture à voix haute, export, aperçus. */
    fun strip(text: String): String = fr.jeremy.calepin.text.RichText.strip(text.replace(markerLine, "").replace(marker, "")).trimEnd()

    /** Texte lisible, sans aucun repère : ni photos, ni couleurs, ni signes de gras, barré, titres ou liens. */
    fun plain(text: String): String = fr.jeremy.calepin.text.MarkdownSigns.plain(strip(text))

    /** Retire le repère d'un fichier (photo supprimée). */
    fun remove(text: String, fileName: String): String {
        val m = "\\{\\{(?:photo|video):" + Regex.escape(fileName) + "(?:\\|[^}\\n]*)?\\}\\}"
        val one = Regex("(?m)^[ \\t]*$m[ \\t]*(?:\\n|$)")
        return text.replace(one, "").replace(Regex(m), "")
    }

    /** Ajoute les photos sous tout le texte (lecture). */
    fun appendAtEnd(text: String, items: List<Attachment>): String {
        val base = text.trimEnd('\n', ' ')
        return (if (base.isEmpty()) "" else base + "\n") + items.joinToString("\n") { markerFor(it) } + "\n"
    }

    /** Insère les photos sur leur propre ligne, à l'endroit du curseur (écriture). */
    fun insertAt(f: TextFieldValue, items: List<Attachment>): TextFieldValue {
        val t = f.text
        val pos = f.selection.max.coerceIn(0, t.length)
        // Fin de la ligne en cours : la photo se place sous la ligne, sans la couper
        val lineEnd = t.indexOf('\n', pos).let { if (it < 0) t.length else it }
        val before = t.substring(0, lineEnd)
        val after = t.substring(lineEnd)
        val block = (if (before.isEmpty() || before.endsWith("\n")) "" else "\n") + items.joinToString("\n") { markerFor(it) } + "\n"
        val rest = after.removePrefix("\n")
        val nt = before + block + rest
        return TextFieldValue(nt, TextRange(before.length + block.length))
    }
}

/** Recherche dans le texte d'une note : sans tenir compte des majuscules ni des accents. */
object NoteFind {
    private fun fold(c: Char): Char {
        val d = Normalizer.normalize(c.toString(), Normalizer.Form.NFD)
        return (d.firstOrNull() ?: c).lowercaseChar()
    }

    private fun fold(s: String): String = buildString(s.length) { s.forEach { append(fold(it)) } }

    /** Positions de [query] dans [text] (même longueur que l'original : les positions restent justes). */
    fun find(text: String, query: String): List<IntRange> {
        val q = fold(query.trim())
        if (q.isEmpty()) return emptyList()
        val t = fold(text)
        val out = ArrayList<IntRange>()
        var i = t.indexOf(q)
        while (i >= 0 && out.size < 2000) {
            out += i until i + q.length
            i = t.indexOf(q, i + q.length)
        }
        return out
    }
}
