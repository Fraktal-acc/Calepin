package fr.jeremy.calepin.media

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.text.PDFTextStripper
import com.tom_roush.pdfbox.text.TextPosition
import fr.jeremy.calepin.detect.Glyph
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

/**
 * Texte d'un PDF, ligne par ligne dans l'ordre de lecture.
 * 1) PDF « numérique » : lecture directe du texte (PdfBox).
 * 2) PDF scanné ou photo : chaque page est rendue en image puis lue par reconnaissance de caractères (ML Kit, sur le téléphone).
 */
object PdfText {

    /** [keywords] : mots-clés des propriétés du PDF (certains logiciels de planning y écrivent le nombre de vacations). */
    data class Result(val text: String, val usedOcr: Boolean, val glyphs: List<Glyph> = emptyList(), val keywords: String? = null)

    /** Récupère chaque caractère avec sa position (pour les plannings en grille). */
    private class GlyphStripper : PDFTextStripper() {
        val glyphs = mutableListOf<Glyph>()
        override fun processTextPosition(text: TextPosition) {
            val u = text.unicode
            if (!u.isNullOrEmpty()) {
                val size = text.fontSizeInPt.takeIf { it > 0f } ?: text.heightDir
                glyphs += Glyph(u, text.xDirAdj, text.yDirAdj, text.widthDirAdj, size, currentPageNo)
            }
            super.processTextPosition(text)
        }
    }

    suspend fun extract(ctx: Context, uri: Uri, onProgress: (String) -> Unit = {}): Result = withContext(Dispatchers.IO) {
        onProgress("Lecture du PDF…")
        var glyphs: List<Glyph> = emptyList()
        var keywords: String? = null
        val direct = runCatching {
            PDFBoxResourceLoader.init(ctx.applicationContext)
            ctx.contentResolver.openInputStream(uri)!!.use { input ->
                PDDocument.load(input).use { doc ->
                    keywords = runCatching { doc.documentInformation?.keywords }.getOrNull()
                    val text = PDFTextStripper().apply { setSortByPosition(true) }.getText(doc)
                    glyphs = runCatching { GlyphStripper().also { it.getText(doc) }.glyphs.toList() }.getOrDefault(emptyList())
                    text
                }
            }
        }.getOrDefault("")
        if (direct.count { it.isLetterOrDigit() } > 20) return@withContext Result(direct, usedOcr = false, glyphs = glyphs, keywords = keywords)
        val ocrGlyphs = mutableListOf<Glyph>()
        val text = ocr(ctx, uri, onProgress, ocrGlyphs)
        Result(text, usedOcr = true, glyphs = ocrGlyphs)
    }

    /** Image (photo d'un planning) : reconnaissance de caractères directe. */
    suspend fun extractImage(ctx: Context, uri: Uri): Result = withContext(Dispatchers.IO) {
        val image = InputImage.fromFilePath(ctx, uri)
        val glyphs = mutableListOf<Glyph>()
        val text = recognize(image, 0, glyphs)
        Result(text, usedOcr = true, glyphs = glyphs)
    }

    private suspend fun ocr(ctx: Context, uri: Uri, onProgress: (String) -> Unit, glyphs: MutableList<Glyph>): String {
        val pfd = ctx.contentResolver.openFileDescriptor(uri, "r") ?: return ""
        val sb = StringBuilder()
        pfd.use {
            PdfRenderer(it).use { renderer ->
                for (i in 0 until minOf(renderer.pageCount, 20)) {
                    onProgress("Lecture de la page ${i + 1} sur ${renderer.pageCount}…")
                    renderer.openPage(i).use { page ->
                        val scale = 2.5f // ~180 ppp : bon compromis lisibilité / mémoire
                        val bmp = Bitmap.createBitmap((page.width * scale).toInt(), (page.height * scale).toInt(), Bitmap.Config.ARGB_8888)
                        bmp.eraseColor(Color.WHITE)
                        page.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                        sb.append(recognize(InputImage.fromBitmap(bmp, 0), i, glyphs)).append('\n')
                        bmp.recycle()
                    }
                }
            }
        }
        return sb.toString()
    }

    /** Regroupe les lignes reconnues par rangée (même hauteur) pour garder la structure des tableaux. */
    private suspend fun recognize(image: InputImage, page: Int, glyphs: MutableList<Glyph>): String {
        val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
        val result = suspendCancellableCoroutine { cont ->
            recognizer.process(image)
                .addOnSuccessListener { cont.resume(it) }
                .addOnFailureListener { cont.resumeWithException(it) }
        }
        recognizer.close()
        // Chaque mot reconnu devient des « caractères » répartis sur sa largeur, comme pour un PDF numérique
        result.textBlocks.forEach { b ->
            b.lines.forEach { l ->
                l.elements.forEach { el ->
                    val box = el.boundingBox ?: return@forEach
                    val n = el.text.length.coerceAtLeast(1)
                    val cw = box.width().toFloat() / n
                    el.text.forEachIndexed { k, ch ->
                        glyphs += Glyph(ch.toString(), box.left + cw * k, box.bottom.toFloat(), cw, box.height().toFloat(), page)
                    }
                }
            }
        }
        data class L(val top: Int, val bottom: Int, val left: Int, val text: String)
        val lines = result.textBlocks.flatMap { b ->
            b.lines.mapNotNull { l -> l.boundingBox?.let { L(it.top, it.bottom, it.left, l.text) } }
        }.sortedBy { it.top }
        val rows = mutableListOf<MutableList<L>>()
        for (l in lines) {
            val row = rows.lastOrNull()
            val center = (l.top + l.bottom) / 2
            if (row != null && row.any { center in it.top..it.bottom }) row += l else rows += mutableListOf(l)
        }
        return rows.joinToString("\n") { r -> r.sortedBy { it.left }.joinToString("   ") { it.text } }
    }
}
