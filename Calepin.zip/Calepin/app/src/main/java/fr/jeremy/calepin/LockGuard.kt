package fr.jeremy.calepin

/**
 * Quand Calepin ouvre une autre appli (partage, Maps, choix d'un dossier…), le retour
 * ne doit pas reverrouiller l'appli. On mémorise ce moment pour ignorer ce retour-là.
 */
object LockGuard {
    @Volatile private var at = 0L

    fun external() { at = System.currentTimeMillis() }

    /** Vrai si l'appli a été quittée vers une autre appli lancée par Calepin il y a moins de 3 minutes. */
    fun consume(): Boolean {
        val ok = at != 0L && System.currentTimeMillis() - at < 180_000
        at = 0L
        return ok
    }
}
