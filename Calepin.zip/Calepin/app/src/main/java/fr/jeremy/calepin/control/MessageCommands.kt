package fr.jeremy.calepin.control

import android.content.Context
import fr.jeremy.calepin.contacts.PhoneContacts
import fr.jeremy.calepin.i18n.I18n
import fr.jeremy.calepin.search.TextNorm
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Messages WhatsApp et Telegram par l'assistant (à la voix ou à l'écrit, et via l'IA avec « ACTION: ») :
 * « envoie un WhatsApp à Marc : j'arrive », « Telegram à Julie : on se voit ce soir ? »,
 * « réponds à Famille : d'accord », « lis les messages de Marc », « lis mes mails », « ouvre les messages ».
 * Chaque envoi est confirmé (« oui » / « non ») avant de partir.
 */
class MessageCommands(context: Context) {
    private val ctx = context.applicationContext

    data class Result(val text: String, val navigate: String? = null)

    private data class Pending(val conv: Conv, val label: String, val message: String, val at: Long)

    @Volatile private var pending: Pending? = null

    private fun res(t: String, nav: String? = null) = Result(I18n.tr(t), nav)
    private fun resf(t: String, vararg a: String) = Result(I18n.trf(t, *a))

    /** Vrai pendant qu'un message attend « oui » ou « non ». */
    val awaitingConfirmation: Boolean get() = pending?.let { System.currentTimeMillis() - it.at <= 3 * 60_000 } == true

    suspend fun handle(raw: String): Result? = withContext(Dispatchers.IO) {
        MessageHub.init(ctx)
        val text = raw.trim().trimEnd('.', '!', ' ')
        val n = TextNorm.norm(text).lowercase().replace(Regex("\\s+"), " ").trimEnd('?', ' ')
        if (n.isBlank()) return@withContext null
        confirm(n) ?: open(n) ?: locked(n) ?: readMails(n) ?: read(n) ?: send(text, n)
    }

    // ------------------------------------------------------------ Navigation

    private fun open(n: String): Result? {
        if (Regex("^(ouvre|affiche|montre|va dans|va sur|aller dans)( moi)? (les |mes )?(messages|messageries|messagerie|conversations|discussions)$").matches(n))
            return res("J'ouvre les messages.", "messages")
        if (Regex("^(ouvre|affiche|montre)( moi)? (les |mes )?(mails|e-mails|emails|courriels) (suivis|reportes|importants)$").matches(n))
            return res("J'ouvre les messages.", "messages")
        return null
    }

    // ------------------------------------------------------------ Lecture

    /** Messages protégés par code et pas encore ouverts : pas de lecture par l'assistant. */
    private fun locked(n: String): Result? {
        if (!fr.jeremy.calepin.SectionLock.needs(fr.jeremy.calepin.SectionLock.MESSAGES)) return null
        if (!Regex("^(?:lis|lire|relis|montre|affiche|quels sont|qu'est-ce que dit|que dit|que disent)\\b").containsMatchIn(n)) return null
        if (!Regex("\\b(messages?|mails?|e-mails|emails|courriels)\\b").containsMatchIn(n)) return null
        return res("Les messages sont protégés par code : ouvre d'abord le menu Messages.", "messages")
    }

    private fun appIn(n: String): String? = when {
        Regex("\\bwhats ?app\\b|\\bwatsap\\b|\\bwhatsap\\b").containsMatchIn(n) -> Conv.WHATSAPP
        Regex("\\btelegram(me)?\\b").containsMatchIn(n) -> Conv.TELEGRAM
        else -> null
    }

    private fun appName(app: String) = if (app == Conv.TELEGRAM) "Telegram" else "WhatsApp"

    private fun read(n: String): Result? {
        val m = Regex("^(?:lis|lire|relis|montre|affiche|quels sont|qu'est-ce que dit|que dit|que disent)(?: moi)?(?: les| mes)?(?: (?:derniers|nouveaux))? (?:messages|message)(?: (?:whats ?app|telegram))? (?:de|du|des|d'|dans|avec) ?(.+?)(?: (?:sur|dans|par) (?:whats ?app|telegram))?$").find(n)
            ?: return null
        val who = m.groupValues[1].trim().removePrefix("la conversation ").removePrefix("le groupe ").trim()
        if (who.isBlank()) return null
        val app = appIn(n)
        val conv = MessageHub.convs.value.filter { app == null || it.app == app }.let { list ->
            list.firstOrNull { TextNorm.norm(it.name) == who } ?: list.firstOrNull { TextNorm.norm(it.name).contains(who) }
        } ?: return resf("« {0} » n'est pas dans tes conversations suivies. Ajoute-la dans Messages pour que je puisse lire ses messages.", who)
        val msgs = MessageHub.messages.value[conv.key].orEmpty().filter { !it.mine }.takeLast(5)
        if (msgs.isEmpty()) return resf("Aucun message reçu de {0} pour le moment.", conv.name)
        val body = msgs.joinToString("\n") { msg ->
            val from = msg.from.takeIf { it.isNotBlank() && !it.equals(conv.name, true) }?.let { "$it : " } ?: ""
            "• $from${msg.text}"
        }
        return Result(I18n.trf("Derniers messages de {0} :", conv.name) + "\n" + body)
    }

    private fun readMails(n: String): Result? {
        if (!Regex("^(?:lis|lire|montre|affiche|quels sont)(?: moi)?(?: les| mes)?(?: (?:derniers|nouveaux))? (?:mails|mail|e-mails|emails|courriels)(?: (?:suivis|recus|importants))?$").matches(n)) return null
        if (MessageHub.mailRules.value.isEmpty()) return res("Aucune adresse suivie. Ajoute les adresses dont tu veux recevoir les mails dans Messages → Mails.")
        val mails = MessageHub.mails.value.take(5)
        if (mails.isEmpty()) return res("Aucun mail reçu des adresses suivies pour le moment.")
        return Result(I18n.tr("Derniers mails suivis :") + "\n" + mails.joinToString("\n") { "• ${it.from} : ${it.subject}" })
    }

    // ------------------------------------------------------------ Envoi

    private val verb = "(?:envoie|envoies|envoyer|ecris|ecrire|dis|reponds|repondre|message|fais passer|transmets)"
    private val appWord = "(?:whats ?app|telegram|telegramme)"

    private fun send(text: String, n: String): Result? {
        // Séparateur du message : « : », ou à la voix « … pour lui dire que … », « … en disant … », « … message … »
        val sep = Regex(":|\\s(?:pour (?:lui |leur )?dire(?: que| qu'|qu’)?|en (?:lui |leur )?disant(?: que| qu'|qu’)?|qui dit|disant|avec le message|le message)\\s*", RegexOption.IGNORE_CASE)
            .findAll(text).firstOrNull { it.value.contains(':') || Regex("\\s(a|à|au|aux)\\s", RegexOption.IGNORE_CASE).containsMatchIn(text.substring(0, it.range.first)) }
        if (sep == null) {
            // « envoie un WhatsApp à Marc » sans message
            val m = Regex("^$verb(?: un| une)?(?: message)?(?: (?:sur |par )?$appWord) a (.+)$").find(n) ?: return null
            val app = appIn(n) ?: return null
            return resf("Quel message dois-je envoyer à {0} ? Dis par exemple « envoie un {1} à {0} pour lui dire que j'arrive ».", m.groupValues[1].trim(), appName(app))
        }
        val head = TextNorm.norm(text.substring(0, sep.range.first)).lowercase().replace(Regex("\\s+"), " ").trim()
        val message = text.substring(sep.range.last + 1).trim().let { if (sep.value.contains(':')) it else it.replaceFirstChar { c -> c.uppercase() } }
        val m = Regex("^$verb(?: un| une)?(?: (?:petit |nouveau )?message)?(?: (?:sur |par |en )?$appWord)?(?: (?:a|au|aux|pour|dans) )(.+?)(?: (?:sur|par|via|dans|en) $appWord)?$").find(head)
            ?: Regex("^$appWord (?:a|au|pour|dans) (.+)$").find(head)
            ?: return null
        val who = m.groupValues[1].trim().removePrefix("la conversation ").removePrefix("le groupe ").trim()
        if (who.isBlank()) return null
        val app = appIn(head)
        // Sans « WhatsApp » ni « Telegram », on ne prend que les conversations connues (sinon c'est un SMS)
        val known: Conv? = if (app != null) MessageHub.findByName(ctx, app, who)
        else listOf(Conv.WHATSAPP, Conv.TELEGRAM).firstNotNullOfOrNull { a ->
            MessageHub.convs.value.firstOrNull { it.app == a && TextNorm.norm(it.name) == who }
        } ?: MessageHub.convs.value.firstOrNull { TextNorm.norm(it.name).contains(who) }
        if (app == null && known == null) {
            return if (head.startsWith("repond")) resf("Je ne connais pas la conversation « {0} ». Ajoute-la dans Messages.", who) else null
        }
        if (message.isBlank()) return resf("Quel message dois-je envoyer à {0} ?", who)
        val a = app ?: known!!.app

        val conv: Conv = when {
            known != null && (known.phone.isNotBlank() || MessageHub.canReplyDirectly(known.key) || a == Conv.TELEGRAM) -> known
            else -> {
                // Numéro du contact (WhatsApp sans conversation suivie, ou suivie sans numéro)
                val c = contact(who)
                when {
                    c is Pair<*, *> -> Conv(a, known?.name ?: (c.first as String), c.second as String)
                    known != null -> known
                    a == Conv.TELEGRAM -> Conv(a, who.replaceFirstChar { it.uppercase() })
                    c is String -> return Result(c)
                    else -> return resf("Je ne trouve pas « {0} ».", who)
                }
            }
        }
        pending = Pending(conv, conv.name, fr.jeremy.calepin.text.Sentences.fix(message), System.currentTimeMillis())
        return Result(I18n.trf("J'envoie « {0} » à {1} sur {2} ? Dis « oui » pour confirmer ou « non » pour annuler.", fr.jeremy.calepin.text.Sentences.fix(message), conv.name, appName(conv.app)))
    }

    /** Contact du téléphone : (nom, numéro), ou un message d'erreur. */
    private fun contact(who: String): Any? {
        if (!PhoneContacts.hasPermission(ctx)) return I18n.trf("Autorise l'accès aux contacts (écran Contacts) pour que je trouve « {0} ».", who)
        val found = PhoneContacts.filter(PhoneContacts.load(ctx), who).filter { it.phones.isNotEmpty() }
        if (found.size > 1 && found.none { TextNorm.norm(it.name).lowercase() == who }) {
            return I18n.trf("Plusieurs contacts correspondent à « {0} » : {1}. Précise le nom.", who, found.take(4).joinToString(", ") { it.name })
        }
        val c = found.firstOrNull { TextNorm.norm(it.name).lowercase() == who } ?: found.firstOrNull()
            ?: return I18n.trf("Je ne trouve pas « {0} » dans tes contacts.", who)
        val number = (c.phones.firstOrNull { it.label.contains("mobile", true) || it.value.filter(Char::isDigit).let { d -> d.startsWith("06") || d.startsWith("07") || d.startsWith("336") || d.startsWith("337") } } ?: c.phones.first()).value
        return c.name to number
    }

    private fun confirm(n: String): Result? {
        val p = pending ?: return null
        if (System.currentTimeMillis() - p.at > 3 * 60_000) { pending = null; return null }
        val yes = Regex("^(oui|ouais|yes|yeah|yep|sure|confirme|confirmer|confirm|envoie|envoie le|envoie-le|send it|send|vas y|vas-y|ok|okay|d'accord|c'est bon|go|si|certo|va bene|invia|claro|vale|envia|ja|jawohl|klar|genau|senden|schick)\\b").containsMatchIn(n)
        val no = Regex("^(non|no|nope|annule|annuler|cancel|laisse tomber|stop|pas maintenant|not now|annulla|cancela|nein|abbrechen|nicht)\\b").containsMatchIn(n)
        // Une nouvelle demande (« envoie un WhatsApp à … ») n'est pas une confirmation
        if ((!yes && !no) || n.split(' ').size > 4) return null
        pending = null
        if (no) return res("Message annulé.")
        val conv = p.conv
        return when (MessageHub.deliver(ctx, conv, p.message)) {
            MessageHub.Delivery.SENT -> resf("Message envoyé à {0} sur {1}.", conv.name, appName(conv.app))
            MessageHub.Delivery.AUTO -> resf("J'envoie le message à {0}…", conv.name)
            MessageHub.Delivery.READY -> resf("Message prêt pour {0} dans {1} : touche Envoyer.", conv.name, appName(conv.app))
            MessageHub.Delivery.FAILED -> resf("{0} n'a pas pu s'ouvrir.", appName(conv.app))
        }
    }
}
