package fr.jeremy.calepin.control

import android.content.Context
import fr.jeremy.calepin.i18n.I18n
import fr.jeremy.calepin.search.TextNorm
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Mails suivis par l'assistant (à la voix ou à l'écrit, et via l'IA avec « ACTION: ») :
 * « lis mes mails », « ouvre les messages ».
 */
class MessageCommands(context: Context) {
    private val ctx = context.applicationContext

    data class Result(val text: String, val navigate: String? = null)

    private fun res(t: String, nav: String? = null) = Result(I18n.tr(t), nav)

    suspend fun handle(raw: String): Result? = withContext(Dispatchers.IO) {
        MessageHub.init(ctx)
        val text = raw.trim().trimEnd('.', '!', ' ')
        val n = TextNorm.norm(text).lowercase().replace(Regex("\\s+"), " ").trimEnd('?', ' ')
        if (n.isBlank()) return@withContext null
        open(n) ?: locked(n) ?: readMails(n)
    }

    // ------------------------------------------------------------ Navigation

    private fun open(n: String): Result? {
        if (Regex("^(ouvre|affiche|montre|va dans|va sur|aller dans)( moi)? (les |mes )?(messages|messageries|messagerie)$").matches(n))
            return res("J'ouvre les messages.", "messages")
        if (Regex("^(ouvre|affiche|montre)( moi)? (les |mes )?(mails|e-mails|emails|courriels) (suivis|reportes|importants)$").matches(n))
            return res("J'ouvre les messages.", "messages")
        return null
    }

    // ------------------------------------------------------------ Lecture

    /** Messages protégés par code et pas encore ouverts : pas de lecture par l'assistant. */
    private fun locked(n: String): Result? {
        if (!fr.jeremy.calepin.SectionLock.needs(fr.jeremy.calepin.SectionLock.MESSAGES)) return null
        if (!Regex("^(?:lis|lire|relis|montre|affiche|quels sont|qu'est-ce que dit|que dit|que disent)\\b").containsMatchIn(n)) return null
        if (!Regex("\\b(messages?|mails?|e-mails|emails|courriels)\\b").containsMatchIn(n)) return null
        return res("Les messages sont protégés par code : ouvre d'abord le menu Messages.", "messages")
    }

    private fun readMails(n: String): Result? {
        if (!Regex("^(?:lis|lire|montre|affiche|quels sont)(?: moi)?(?: les| mes)?(?: (?:derniers|nouveaux))? (?:mails|mail|e-mails|emails|courriels)(?: (?:suivis|recus|importants))?$").matches(n)) return null
        if (MessageHub.mailRules.value.isEmpty()) return res("Aucune adresse suivie. Ajoute les adresses dont tu veux recevoir les mails dans Messages → Mails.")
        val mails = MessageHub.mails.value.take(5)
        if (mails.isEmpty()) return res("Aucun mail reçu des adresses suivies pour le moment.")
        return Result(I18n.tr("Derniers mails suivis :") + "\n" + mails.joinToString("\n") { "• ${it.from} : ${it.subject}" })
    }
}
