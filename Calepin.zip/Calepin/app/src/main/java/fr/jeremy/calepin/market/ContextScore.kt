package fr.jeremy.calepin.market

import java.util.Locale
import kotlin.math.abs

/** Genre d'instrument, pour savoir quelles informations de contexte s'appliquent. */
enum class AssetKind { STOCK, INDEX, CRYPTO, CURRENCY, COMMODITY, OTHER }

/**
 * Contexte de marché (sources en plus des cours de l'instrument) : peur des marchés (VIX), force relative
 * face à l'indice de référence, humeur du marché des cryptos (Fear & Greed), tendance du dollar pour les
 * matières premières. Calculs purs, sans réseau.
 */
object ContextScore {
    private fun f(x: Double, d: Int = 1) = String.format(Locale.FRANCE, "%.${d}f", x)

    fun kindOf(symbol: String, type: String = ""): AssetKind {
        val t = type.lowercase()
        return when {
            t.contains("crypto") || Regex("-(USD|EUR|USDT|GBP)$").containsMatchIn(symbol) -> AssetKind.CRYPTO
            t.contains("devise") || symbol.endsWith("=X") -> AssetKind.CURRENCY
            t.contains("indice") || symbol.startsWith("^") -> AssetKind.INDEX
            t.contains("terme") || symbol.endsWith("=F") -> AssetKind.COMMODITY
            t.contains("action") || t.contains("etf") || Regex("^[A-Z0-9.\\-]{1,12}$").matches(symbol) -> AssetKind.STOCK
            else -> AssetKind.OTHER
        }
    }

    /** Indice de référence d'une action, d'après sa place de cotation (suffixe Yahoo). */
    fun benchmarkFor(symbol: String, kind: AssetKind): String? {
        if (kind != AssetKind.STOCK) return null
        val suffix = symbol.substringAfterLast('.', "").uppercase()
        return when (suffix) {
            "" -> "^GSPC"
            "PA" -> "^FCHI"
            "DE", "F" -> "^GDAXI"
            "L" -> "^FTSE"
            "MI" -> "FTSEMIB.MI"
            "AS" -> "^AEX"
            "MC" -> "^IBEX"
            "SW" -> "^SSMI"
            "BR" -> "^BFX"
            "T" -> "^N225"
            "HK" -> "^HSI"
            "TO" -> "^GSPTSE"
            else -> null
        }
    }

    /** Peur des marchés d'actions (VIX) : calme = favorable, panique = défavorable (sauf excès, souvent proche d'un creux). */
    fun vixFactor(vix: Double, vixBefore: Double): Factor? {
        if (vix.isNaN() || vix <= 0) return null
        var v = when {
            vix < 15 -> 0.4
            vix < 20 -> 0.1
            vix < 25 -> -0.2
            vix < 35 -> -0.6
            else -> 0.3
        }
        val trend = if (!vixBefore.isNaN() && vixBefore > 0) vix / vixBefore else 1.0
        if (trend < 0.9) v += 0.2
        if (trend > 1.1) v -= 0.2
        val txt = "VIX " + f(vix) + when {
            vix < 15 -> " : marchés calmes"
            vix < 20 -> " : nervosité normale"
            vix < 25 -> " : nervosité en hausse"
            vix < 35 -> " : marchés inquiets"
            else -> " : panique (souvent proche d'un creux)"
        } + when {
            trend < 0.9 -> ", la peur recule"
            trend > 1.1 -> ", la peur monte"
            else -> ""
        }
        return Factor("Climat des marchés", v.coerceIn(-1.0, 1.0), 8.0, txt)
    }

    /** Variation en % sur les [n] dernières bougies. */
    fun change(closes: List<Double>, n: Int): Double {
        if (closes.size <= n) return Double.NaN
        val a = closes[closes.size - 1 - n]
        return if (a > 0) (closes.last() - a) / a * 100 else Double.NaN
    }

    /** Force relative : l'instrument fait-il mieux que son indice sur ~3 mois (63 séances) ? */
    fun relativeStrength(closes: List<Double>, bench: List<Double>, benchName: String, n: Int = 63): Factor? {
        val a = change(closes, n)
        val b = change(bench, n)
        if (a.isNaN() || b.isNaN()) return null
        val diff = a - b
        val v = (diff / 15).coerceIn(-1.0, 1.0)
        val txt = (if (diff >= 0) "Fait mieux que " else "Fait moins bien que ") + benchName +
            " sur 3 mois (" + (if (a >= 0) "+" else "") + f(a) + " % contre " + (if (b >= 0) "+" else "") + f(b) + " %)"
        return Factor("Force relative", v, 8.0, txt)
    }

    /** Humeur du marché des cryptos (indice Fear & Greed, 0 à 100), lue à contre-courant. */
    fun fearGreedFactor(value: Int, label: String = ""): Factor? {
        if (value !in 0..100) return null
        val v = when {
            value < 25 -> 0.6
            value < 45 -> 0.2
            value <= 55 -> 0.0
            value <= 75 -> -0.2
            else -> -0.6
        }
        val txt = "Fear & Greed $value/100" + when {
            value < 25 -> " : peur extrême (souvent une occasion d'achat)"
            value < 45 -> " : peur"
            value <= 55 -> " : neutre"
            value <= 75 -> " : avidité"
            else -> " : avidité extrême (risque de correction)"
        } + (if (label.isNotBlank()) "" else "")
        return Factor("Humeur des cryptos", v, 8.0, txt)
    }

    /** Matières premières cotées en dollars : un dollar qui baisse les soutient, un dollar qui monte les freine. */
    fun dollarFactor(dxy: List<Double>, n: Int = 20): Factor? {
        val ch = change(dxy, n)
        if (ch.isNaN()) return null
        val v = (-ch / 3).coerceIn(-1.0, 1.0)
        val txt = "Dollar " + (if (ch >= 0) "en hausse" else "en baisse") + " de " + f(abs(ch)) + " % sur un mois" +
            if (ch >= 0) " : défavorable aux matières premières" else " : favorable aux matières premières"
        return Factor("Dollar", v, 6.0, txt)
    }

    /** Symbole Stooq (source de secours des cours) pour un symbole Yahoo, ou null si inconnu. */
    fun stooqSymbol(symbol: String): String? {
        val s = symbol.uppercase()
        val indices = mapOf("^GSPC" to "^spx", "^DJI" to "^dji", "^IXIC" to "^ndq", "^NDX" to "^ndx", "^FCHI" to "^cac",
            "^GDAXI" to "^dax", "^FTSE" to "^ukx", "^N225" to "^nkx", "^HSI" to "^hsi", "^STOXX50E" to "^stx")
        indices[s]?.let { return it }
        val futures = mapOf("GC=F" to "gc.f", "SI=F" to "si.f", "CL=F" to "cl.f", "BZ=F" to "cb.f", "NG=F" to "ng.f", "HG=F" to "hg.f", "PL=F" to "pl.f")
        futures[s]?.let { return it }
        Regex("^([A-Z]{6})=X$").find(s)?.let { return it.groupValues[1].lowercase() }
        Regex("^([A-Z]{2,5})-(USD|EUR)$").find(s)?.let { return (it.groupValues[1] + it.groupValues[2]).lowercase() }
        Regex("^([A-Z0-9]{1,6})\\.(DE|L|JP)$").find(s)?.let {
            val m = mapOf("DE" to "de", "L" to "uk", "JP" to "jp")
            return it.groupValues[1].lowercase() + "." + m.getValue(it.groupValues[2])
        }
        if (Regex("^[A-Z]{1,5}$").matches(s)) return s.lowercase() + ".us"
        return null
    }

    /** Cours au format CSV de Stooq (Date,Open,High,Low,Close,Volume), du plus ancien au plus récent. */
    fun parseStooqCsv(csv: String): List<Candle> {
        val out = ArrayList<Candle>()
        val df = java.text.SimpleDateFormat("yyyy-MM-dd", Locale.ROOT).apply { timeZone = java.util.TimeZone.getTimeZone("UTC") }
        csv.lineSequence().drop(1).forEach { line ->
            val p = line.trim().split(',')
            if (p.size < 5) return@forEach
            val t = runCatching { df.parse(p[0])!!.time / 1000 }.getOrNull() ?: return@forEach
            val o = p[1].toDoubleOrNull(); val h = p[2].toDoubleOrNull(); val l = p[3].toDoubleOrNull(); val c = p[4].toDoubleOrNull()
            if (o == null || h == null || l == null || c == null) return@forEach
            out += Candle(t, o, h, l, c, p.getOrNull(5)?.toDoubleOrNull() ?: 0.0)
        }
        return out.sortedBy { it.t }
    }
}
