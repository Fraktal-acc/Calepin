package fr.jeremy.calepin.control

import org.json.JSONObject

/** Touches de la télécommande à l'écran. */
enum class RemoteKey {
    POWER, UP, DOWN, LEFT, RIGHT, OK, BACK, HOME, MENU, GUIDE, INFO, INPUT,
    VOL_UP, VOL_DOWN, MUTE, CH_UP, CH_DOWN, PLAY_PAUSE, REWIND, FORWARD,
    D0, D1, D2, D3, D4, D5, D6, D7, D8, D9;

    val digit: Int? get() = if (name.length == 2 && name[0] == 'D') name[1].digitToInt() else null

    companion object {
        fun digit(d: Int) = valueOf("D$d")
    }
}

/**
 * Télécommande d'un appareil précis. Les marques qui le permettent gardent la connexion ouverte
 * pour que chaque touche parte tout de suite. À utiliser hors du fil principal.
 */
interface RemoteSession {
    /** Touches que cet appareil comprend (les autres sont grisées). */
    val keys: Set<RemoteKey>
    val hasApps: Boolean get() = false
    val hasHdmi: Boolean get() = false
    suspend fun press(k: RemoteKey): Boolean
    suspend fun openApp(name: String): String? = null
    suspend fun hdmi(port: Int): Boolean = false
    /** Explication du dernier échec, si l'appareil en donne une. */
    val lastError: String? get() = null
    fun close() {}
}

object RemoteDrivers {
    fun open(d: HomeDevice, store: DeviceStore): RemoteSession? = when (d.kind) {
        Kind.ORANGE -> OrangeRemote(OrangeDecoder(d.host))
        Kind.FREEBOX_PLAYER -> FreeboxRemote(d.host.ifBlank { "hd1.freebox.fr" }, d.secret)
        Kind.ANDROID_TV -> AndroidTvSession(AndroidTvRemote(d.host, store.androidTvIdentity()))
        Kind.BRAVIA -> BraviaRemote(BraviaTv(d.host, d.secret, d.extraJson.optString("mac")))
        Kind.SAMSUNG -> SamsungRemote(d.host, d.secret, d.extraJson.optString("mac"))
        Kind.LG -> LgRemote(d.host, d.secret, d.extraJson.optString("mac"))
        Kind.ROKU -> RokuRemote(d.host)
        else -> null
    }

    val ALL: Set<RemoteKey> = RemoteKey.entries.toSet()
}

// ---------------------------------------------------------------------------------------------- Orange

private class OrangeRemote(private val d: OrangeDecoder) : RemoteSession {
    private val map = mapOf(
        RemoteKey.UP to 103, RemoteKey.DOWN to 108, RemoteKey.LEFT to 105, RemoteKey.RIGHT to 106, RemoteKey.OK to 352,
        RemoteKey.BACK to 158, RemoteKey.HOME to 139, RemoteKey.MENU to 139, RemoteKey.GUIDE to 365,
        RemoteKey.VOL_UP to 115, RemoteKey.VOL_DOWN to 114, RemoteKey.MUTE to 113, RemoteKey.CH_UP to 402, RemoteKey.CH_DOWN to 403,
        RemoteKey.PLAY_PAUSE to 164, RemoteKey.REWIND to 168, RemoteKey.FORWARD to 159,
    ) + (0..9).associate { RemoteKey.digit(it) to 512 + it }

    override val keys = map.keys + RemoteKey.POWER

    override suspend fun press(k: RemoteKey): Boolean {
        if (k == RemoteKey.POWER) return if (d.isOn() == true) d.powerOff() else d.powerOn()
        return d.key(map[k] ?: return false)
    }
}

// ---------------------------------------------------------------------------------------------- Freebox Player

private class FreeboxRemote(private val host: String, private val code: String) : RemoteSession {
    private val map = mapOf(
        RemoteKey.POWER to "power", RemoteKey.UP to "up", RemoteKey.DOWN to "down", RemoteKey.LEFT to "left", RemoteKey.RIGHT to "right",
        RemoteKey.OK to "ok", RemoteKey.BACK to "back", RemoteKey.HOME to "home", RemoteKey.MENU to "options", RemoteKey.GUIDE to "epg",
        RemoteKey.INFO to "info", RemoteKey.VOL_UP to "vol_inc", RemoteKey.VOL_DOWN to "vol_dec", RemoteKey.MUTE to "mute",
        RemoteKey.CH_UP to "prgm_inc", RemoteKey.CH_DOWN to "prgm_dec", RemoteKey.PLAY_PAUSE to "play",
        RemoteKey.REWIND to "bwd", RemoteKey.FORWARD to "fwd", RemoteKey.INPUT to "tv",
    ) + (0..9).associate { RemoteKey.digit(it) to it.toString() }

    override val keys = map.keys

    override suspend fun press(k: RemoteKey): Boolean =
        Http.get("http://$host/pub/remote_control?code=$code&key=${map[k] ?: return false}", 4000) != null
}

// ---------------------------------------------------------------------------------------------- Android TV

private class AndroidTvSession(private val remote: AndroidTvRemote) : RemoteSession {
    private var live: AndroidTvRemote.Live? = null
    private val control = AndroidTvControl(remote)

    private val map = mapOf(
        RemoteKey.POWER to AndroidTvRemote.KEY_POWER, RemoteKey.UP to AndroidTvRemote.KEY_UP, RemoteKey.DOWN to AndroidTvRemote.KEY_DOWN,
        RemoteKey.LEFT to AndroidTvRemote.KEY_LEFT, RemoteKey.RIGHT to AndroidTvRemote.KEY_RIGHT, RemoteKey.OK to AndroidTvRemote.KEY_CENTER,
        RemoteKey.BACK to AndroidTvRemote.KEY_BACK, RemoteKey.HOME to AndroidTvRemote.KEY_HOME, RemoteKey.MENU to 82,
        RemoteKey.GUIDE to AndroidTvRemote.KEY_GUIDE, RemoteKey.INFO to 165, RemoteKey.INPUT to AndroidTvRemote.KEY_TV_INPUT,
        RemoteKey.VOL_UP to AndroidTvRemote.KEY_VOLUME_UP, RemoteKey.VOL_DOWN to AndroidTvRemote.KEY_VOLUME_DOWN, RemoteKey.MUTE to AndroidTvRemote.KEY_MUTE,
        RemoteKey.CH_UP to AndroidTvRemote.KEY_CHANNEL_UP, RemoteKey.CH_DOWN to AndroidTvRemote.KEY_CHANNEL_DOWN,
        RemoteKey.PLAY_PAUSE to AndroidTvRemote.KEY_PLAY_PAUSE, RemoteKey.REWIND to 89, RemoteKey.FORWARD to 90,
    ) + (0..9).associate { RemoteKey.digit(it) to AndroidTvRemote.KEY_0 + it }

    override val keys = map.keys
    override val hasApps = true

    @Synchronized
    private fun session(): AndroidTvRemote.Live {
        live?.takeIf { it.isReady }?.let { return it }
        live?.close()
        return remote.Live().open().also { live = it }
    }

    override suspend fun press(k: RemoteKey): Boolean {
        val code = map[k] ?: return false
        return runCatching { session().key(code) }.recoverCatching {
            live?.close(); live = null
            session().key(code) // nouvelle tentative après une coupure
        }.isSuccess
    }

    override suspend fun openApp(name: String): String? {
        val n = TvDrivers.norm(name)
        val (label, link) = AndroidTvControl.APPS.entries.firstOrNull { (k, _) -> n.contains(k) || k.contains(n) }?.value ?: return null
        return if (runCatching { session().appLink(link) }.isSuccess) label else control.openApp(name)
    }

    override fun close() {
        live?.close()
        live = null
    }
}

// ---------------------------------------------------------------------------------------------- Sony Bravia

private class BraviaRemote(private val tv: BraviaTv) : RemoteSession {
    private val control = BraviaControl(tv)
    private val map = mapOf(
        RemoteKey.UP to "Up", RemoteKey.DOWN to "Down", RemoteKey.LEFT to "Left", RemoteKey.RIGHT to "Right", RemoteKey.OK to "Confirm",
        RemoteKey.BACK to "Return", RemoteKey.HOME to "Home", RemoteKey.MENU to "ActionMenu", RemoteKey.GUIDE to "GGuide",
        RemoteKey.INFO to "Display", RemoteKey.INPUT to "Input", RemoteKey.VOL_UP to "VolumeUp", RemoteKey.VOL_DOWN to "VolumeDown",
        RemoteKey.MUTE to "Mute", RemoteKey.CH_UP to "ChannelUp", RemoteKey.CH_DOWN to "ChannelDown", RemoteKey.PLAY_PAUSE to "Play",
        RemoteKey.REWIND to "Rewind", RemoteKey.FORWARD to "Forward",
    ) + (0..9).associate { RemoteKey.digit(it) to "Num$it" }

    override val keys = map.keys + RemoteKey.POWER
    override val hasApps = true
    override val hasHdmi = true

    override suspend fun press(k: RemoteKey): Boolean {
        if (k == RemoteKey.POWER) return if (tv.isOn() == true) tv.powerOff() else tv.powerOn()
        val name = map[k] ?: return false
        if (tv.key(name)) return true
        return when (k) {
            RemoteKey.OK -> tv.key("DpadCenter")
            RemoteKey.MENU -> tv.key("Options")
            RemoteKey.GUIDE -> tv.key("EPG")
            RemoteKey.VOL_UP -> tv.volume("+1")
            RemoteKey.VOL_DOWN -> tv.volume("-1")
            else -> false
        }
    }

    override val lastError: String? get() = tv.lastKeyError

    override suspend fun openApp(name: String) = control.openApp(name)
    override suspend fun hdmi(port: Int) = tv.hdmi(port)
}

// ---------------------------------------------------------------------------------------------- Samsung

private class SamsungRemote(private val host: String, private val token: String, private val mac: String) : RemoteSession {
    private var ws: SimpleWs? = null
    private val control = SamsungTv(host, token, mac)
    private val map = mapOf(
        RemoteKey.POWER to "KEY_POWER", RemoteKey.UP to "KEY_UP", RemoteKey.DOWN to "KEY_DOWN", RemoteKey.LEFT to "KEY_LEFT",
        RemoteKey.RIGHT to "KEY_RIGHT", RemoteKey.OK to "KEY_ENTER", RemoteKey.BACK to "KEY_RETURN", RemoteKey.HOME to "KEY_HOME",
        RemoteKey.MENU to "KEY_MENU", RemoteKey.GUIDE to "KEY_GUIDE", RemoteKey.INFO to "KEY_INFO", RemoteKey.INPUT to "KEY_SOURCE",
        RemoteKey.VOL_UP to "KEY_VOLUP", RemoteKey.VOL_DOWN to "KEY_VOLDOWN", RemoteKey.MUTE to "KEY_MUTE",
        RemoteKey.CH_UP to "KEY_CHUP", RemoteKey.CH_DOWN to "KEY_CHDOWN", RemoteKey.PLAY_PAUSE to "KEY_PLAY",
        RemoteKey.REWIND to "KEY_REWIND", RemoteKey.FORWARD to "KEY_FF",
    ) + (0..9).associate { RemoteKey.digit(it) to "KEY_$it" }

    override val keys = map.keys
    override val hasHdmi = true

    @Synchronized
    private fun socket(): SimpleWs {
        ws?.takeIf { it.failure == null }?.let { return it }
        ws?.close()
        val name = android.util.Base64.encodeToString("Calepin IA".toByteArray(), android.util.Base64.NO_WRAP)
        val s = SimpleWs("wss://$host:8002/api/v2/channels/samsung.remote.control?name=$name" + if (token.isNotBlank()) "&token=$token" else "")
        val first = s.next(6000)
        if (first == null || !first.contains("ms.channel.connect")) { s.close(); error(s.failure ?: "connexion refusée par la télé") }
        ws = s
        return s
    }

    override suspend fun press(k: RemoteKey): Boolean {
        val code = map[k] ?: return false
        val msg = JSONObject().put("method", "ms.remote.control").put(
            "params", JSONObject().put("Cmd", "Click").put("DataOfCmd", code).put("Option", "false").put("TypeOfRemote", "SendRemoteKey"),
        ).toString()
        val sent = runCatching { socket().send(msg) }.getOrDefault(false) ||
            runCatching { ws?.close(); ws = null; socket().send(msg) }.getOrDefault(false)
        // Télé éteinte : la connexion échoue, on tente le réveil par le réseau
        return sent || (k == RemoteKey.POWER && control.power(true))
    }

    override suspend fun hdmi(port: Int) = control.hdmi(port)

    override fun close() {
        ws?.close()
        ws = null
    }
}

// ---------------------------------------------------------------------------------------------- LG webOS

private class LgRemote(private val host: String, private val key: String, private val mac: String) : RemoteSession {
    private var main: SimpleWs? = null
    private var pointer: SimpleWs? = null
    private var counter = 0
    private val control = LgTv(host, key, mac)

    /** Touches envoyées par la « prise pointeur » de webOS. */
    private val buttons = mapOf(
        RemoteKey.UP to "UP", RemoteKey.DOWN to "DOWN", RemoteKey.LEFT to "LEFT", RemoteKey.RIGHT to "RIGHT", RemoteKey.OK to "ENTER",
        RemoteKey.BACK to "BACK", RemoteKey.HOME to "HOME", RemoteKey.MENU to "MENU", RemoteKey.GUIDE to "GUIDE", RemoteKey.INFO to "INFO",
        RemoteKey.VOL_UP to "VOLUMEUP", RemoteKey.VOL_DOWN to "VOLUMEDOWN", RemoteKey.MUTE to "MUTE",
        RemoteKey.CH_UP to "CHANNELUP", RemoteKey.CH_DOWN to "CHANNELDOWN", RemoteKey.PLAY_PAUSE to "PLAY",
        RemoteKey.REWIND to "REWIND", RemoteKey.FORWARD to "FASTFORWARD",
    ) + (0..9).associate { RemoteKey.digit(it) to it.toString() }

    override val keys = buttons.keys + RemoteKey.POWER
    override val hasApps = true
    override val hasHdmi = true

    @Synchronized
    private fun pointerSocket(): SimpleWs {
        pointer?.takeIf { it.failure == null }?.let { return it }
        pointer?.close()
        val m = main?.takeIf { it.failure == null } ?: LgTv.connect(host, key, 8000).first.also { main = it }
        val id = "p${counter++}"
        m.send(JSONObject().put("type", "request").put("id", id).put("uri", "ssap://com.webos.service.networkinput/getPointerInputSocket").toString())
        var path: String? = null
        val deadline = System.currentTimeMillis() + 5000
        while (path == null && System.currentTimeMillis() < deadline) {
            val r = m.next(1000) ?: continue
            val o = runCatching { JSONObject(r) }.getOrNull() ?: continue
            if (o.optString("id") == id) path = o.optJSONObject("payload")?.optString("socketPath")
        }
        val p = SimpleWs(path?.takeIf { it.isNotBlank() } ?: error("la télé n'a pas ouvert la télécommande"))
        pointer = p
        return p
    }

    override suspend fun press(k: RemoteKey): Boolean {
        when (k) {
            RemoteKey.POWER -> return control.power(false) || control.power(true)
            else -> Unit
        }
        val b = buttons[k] ?: return false
        val msg = "type:button\nname:$b\n\n"
        return runCatching { pointerSocket().send(msg) }.getOrDefault(false) ||
            runCatching { pointer?.close(); pointer = null; pointerSocket().send(msg) }.getOrDefault(false)
    }

    override suspend fun openApp(name: String) = control.openApp(name)
    override suspend fun hdmi(port: Int) = control.hdmi(port)

    override fun close() {
        pointer?.close(); pointer = null
        main?.close(); main = null
    }
}

// ---------------------------------------------------------------------------------------------- Roku

private class RokuRemote(private val host: String) : RemoteSession {
    private val control = RokuTv(host)
    private val map = mapOf(
        RemoteKey.POWER to "Power", RemoteKey.UP to "Up", RemoteKey.DOWN to "Down", RemoteKey.LEFT to "Left", RemoteKey.RIGHT to "Right",
        RemoteKey.OK to "Select", RemoteKey.BACK to "Back", RemoteKey.HOME to "Home", RemoteKey.INFO to "Info",
        RemoteKey.VOL_UP to "VolumeUp", RemoteKey.VOL_DOWN to "VolumeDown", RemoteKey.MUTE to "VolumeMute",
        RemoteKey.CH_UP to "ChannelUp", RemoteKey.CH_DOWN to "ChannelDown", RemoteKey.PLAY_PAUSE to "Play",
        RemoteKey.REWIND to "Rev", RemoteKey.FORWARD to "Fwd", RemoteKey.INPUT to "InputHDMI1",
    )

    override val keys = map.keys
    override val hasApps = true
    override val hasHdmi = true

    override suspend fun press(k: RemoteKey): Boolean = Http.post("http://$host:8060/keypress/${map[k] ?: return false}", "", emptyMap(), 4000) != null
    override suspend fun openApp(name: String) = control.openApp(name)
    override suspend fun hdmi(port: Int) = Http.post("http://$host:8060/keypress/InputHDMI$port", "", emptyMap(), 4000) != null
}
