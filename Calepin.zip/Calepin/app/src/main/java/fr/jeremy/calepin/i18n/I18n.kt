package fr.jeremy.calepin.i18n

import android.content.Context
import android.widget.Toast
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import java.util.Locale

/** Langues de l'appli. Le français est la langue d'origine : les textes du code sont écrits en français. */
enum class AppLanguage(val code: String, val label: String, val speechTag: String, val englishName: String) {
    FR("fr", "Français", "fr-FR", "French"),
    EN("en", "English", "en-US", "English"),
    IT("it", "Italiano", "it-IT", "Italian"),
    ES("es", "Español", "es-ES", "Spanish"),
    DE("de", "Deutsch", "de-DE", "German");

    val locale: Locale get() = if (this == FR) Locale.FRANCE else Locale.forLanguageTag(code)
}

/**
 * Traductions de l'interface.
 *
 * Les textes restent écrits en français dans le code ; chaque langue a un fichier
 * `assets/i18n/<code>.tsv` (une ligne par texte : français, tabulation, traduction).
 * Un texte absent du fichier reste simplement en français.
 *
 * Les textes qui contiennent des valeurs ({0}, {1}…) sont reconnus quelle que soit la valeur :
 * « {0} notes » traduit aussi bien « 3 notes » que « 12 notes ». Pour les pluriels collés au mot
 * (« {0} note{1} »), la traduction peut écrire {1|singulier|pluriel}.
 */
object I18n {
    private const val PREFS = "calepin_settings"
    private const val KEY = "language"
    private const val MAX_LEN = 4000

    @Volatile private var app: Context? = null
    private val _language = MutableStateFlow(AppLanguage.FR)
    val language: StateFlow<AppLanguage> = _language

    private val dicts = HashMap<AppLanguage, Dict>()

    /** À appeler au démarrage (et dans les récepteurs de rappels, widgets…) : lit la langue choisie. */
    fun init(ctx: Context) {
        if (app != null) return
        synchronized(this) {
            if (app != null) return
            val c = ctx.applicationContext ?: ctx
            val saved = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY, null)
            _language.value = AppLanguage.entries.firstOrNull { it.name == saved } ?: defaultLanguage()
            app = c
        }
    }

    /** Premier lancement : la langue du téléphone si elle est proposée, sinon le français. */
    private fun defaultLanguage(): AppLanguage {
        val sys = Locale.getDefault().language
        return AppLanguage.entries.firstOrNull { it.code == sys } ?: AppLanguage.FR
    }

    fun set(ctx: Context, lang: AppLanguage) {
        init(ctx)
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY, lang.name).apply()
        _language.value = lang
    }

    /** Langue des dates (jours, mois). */
    val locale: Locale get() = _language.value.locale

    /** Format de date adapté à la langue : « 14h30 » en français, « 14:30 » ailleurs, sans le « à » français. */
    fun pattern(p: String): String {
        val lang = _language.value
        if (lang == AppLanguage.FR) return p
        val base = p.replace(" 'à' ", " ").replace("'à' ", "").replace("HH'h'mm", "HH:mm").replace("H'h'mm", "H:mm").replace("'h'", ":")
        return when (lang) {
            // « Donnerstag, 8. Oktober »
            AppLanguage.DE -> base.replace(Regex("\\b(EEEE|EEE) d\\b"), "$1, d").replace(Regex("\\bd MMM"), "d. MMM")
            // « jueves 8 de octubre »
            AppLanguage.ES -> base.replace(Regex("\\bd MMMM"), "d 'de' MMMM").replace("MMMM yyyy", "MMMM 'de' yyyy")
            else -> base
        }
    }

    /** Traduit un texte d'interface (rendu tel quel s'il n'a pas de traduction). */
    fun tr(text: String): String {
        val lang = _language.value
        if (lang == AppLanguage.FR || text.isEmpty() || text.length > MAX_LEN) return text
        val d = dict(lang) ?: return text
        return d.translate(text)
    }

    /** Variante pour le code hors écran (rappels, widgets) : s'assure que la langue a été lue. */
    fun tr(ctx: Context, text: String): String { init(ctx); return tr(text) }

    /** Texte à trous écrit avec {0}, {1}… : traduit puis rempli. */
    fun trf(key: String, vararg args: Any?): String {
        // Pluriels écrits {1|singulier|pluriel} dans les traductions : choisis selon la valeur ({1} = "" ou "s")
        var s = PLURAL_FORM.replace(tr(key)) { m ->
            val v = args.getOrNull(m.groupValues[1].toInt())?.toString().orEmpty()
            if (v.isEmpty() || v == "1") m.groupValues[2] else m.groupValues[3]
        }
        args.forEachIndexed { i, a -> s = s.replace("{$i}", a?.toString().orEmpty()) }
        return s
    }

    private val PLURAL_FORM = Regex("""\{(\d+)\|([^|}]*)\|([^}]*)\}""")

    /** Toast traduit (même usage que Toast.makeText). */
    fun toast(ctx: Context, text: CharSequence, duration: Int): Toast {
        init(ctx)
        return Toast.makeText(ctx, tr(text.toString()), duration)
    }

    private fun dict(lang: AppLanguage): Dict? = synchronized(dicts) {
        dicts[lang] ?: run {
            val c = app ?: return null
            val d = runCatching { Dict.load(c, lang.code) }.getOrNull() ?: Dict(HashMap(), emptyList())
            dicts[lang] = d
            d
        }
    }
}

private class Template(val regex: Regex, val anchor: String, val out: String)

private class Dict(val exact: HashMap<String, String>, val templates: List<Template>) {
    private val cache = object : LinkedHashMap<String, String>(512, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, String>?) = size > 3000
    }

    fun translate(text: String): String = synchronized(cache) {
        cache[text] ?: lookup(text, 0).also { cache[text] = it }
    }

    private fun lookup(text: String, depth: Int): String {
        exact[text]?.let { return it }
        // Espaces autour du texte : on traduit le cœur et on les garde
        val trimmed = text.trim()
        if (trimmed.isEmpty()) return text
        if (trimmed.length != text.length) {
            val inner = lookup(trimmed, depth)
            if (inner == trimmed) return text
            val lead = text.length - text.trimStart().length
            return text.substring(0, lead) + inner + text.substring(lead + trimmed.length)
        }
        if (depth > 2) return text
        // Textes avec des valeurs
        for (t in templates) {
            if (t.anchor.isNotEmpty() && !text.contains(t.anchor)) continue
            val m = t.regex.matchEntire(text) ?: continue
            return fill(t.out, m.groupValues.drop(1), depth)
        }
        // Morceaux assemblés : « 3 notes · version 1.2 », plusieurs lignes…
        for (sep in SEPARATORS) {
            if (!text.contains(sep)) continue
            val parts = text.split(sep)
            val done = parts.map { lookup(it, depth + 1) }
            if (done != parts) return done.joinToString(sep)
        }
        return text
    }

    private fun fill(out: String, values: List<String>, depth: Int): String {
        var s = PLURAL.replace(out) { m ->
            val v = values.getOrNull(m.groupValues[1].toInt()).orEmpty()
            if (v.isEmpty() || v == "1") m.groupValues[2] else m.groupValues[3]
        }
        values.forEachIndexed { i, v ->
            // Une valeur peut elle-même être un texte connu (« Sans dossier »…)
            val tv = if (v.any { it.isLetter() }) exact[v] ?: lookup(v, depth + 1) else v
            s = s.replace("{$i}", tv)
        }
        return s
    }

    companion object {
        private val SEPARATORS = listOf("\n", " · ", " — ", " • ")
        private val PLACEHOLDER = Regex("""\{(\d+)\}""")
        private val PLURAL = Regex("""\{(\d+)\|([^|}]*)\|([^}]*)\}""")

        fun load(ctx: Context, code: String): Dict {
            val exact = HashMap<String, String>(4096)
            val templates = ArrayList<Template>()
            ctx.assets.open("i18n/$code.tsv").bufferedReader(Charsets.UTF_8).useLines { lines ->
                lines.forEach { line ->
                    if (line.isBlank() || line.startsWith("#")) return@forEach
                    val tab = line.indexOf('\t')
                    if (tab <= 0) return@forEach
                    val key = unescape(line.substring(0, tab))
                    val value = unescape(line.substring(tab + 1))
                    if (value.isEmpty()) return@forEach
                    exact[key] = value
                    if (PLACEHOLDER.containsMatchIn(key)) template(key, value)?.let { templates += it }
                }
            }
            // Les modèles les plus précis (le plus de texte fixe) d'abord
            templates.sortByDescending { it.anchor.length * 1000 + it.regex.pattern.length }
            return Dict(exact, templates)
        }

        private fun template(key: String, out: String): Template? {
            val literals = PLACEHOLDER.split(key)
            val fixed = literals.joinToString("")
            // Trop peu de texte fixe : le modèle reconnaîtrait n'importe quoi
            if (fixed.count { it.isLetter() } < 3) return null
            val count = PLACEHOLDER.findAll(key).count()
            val sb = StringBuilder("^")
            literals.forEachIndexed { i, lit ->
                sb.append(Regex.escape(lit))
                // Une valeur ne déborde jamais sur un autre morceau (« · », autre ligne)
                if (i < count) sb.append(if (i == count - 1 && literals.last().isEmpty()) "([^\\n·]*)" else "([^\\n·]*?)")
            }
            sb.append("$")
            // Les valeurs sont numérotées dans l'ordre de la clé : {0} est le premier trou, {1} le second…
            val order = PLACEHOLDER.findAll(key).map { it.groupValues[1].toInt() }.toList()
            val normalized = if (order == order.indices.toList()) out else {
                // Clé écrite avec des numéros dans le désordre : on les remet dans l'ordre des trous
                var o = out
                order.forEachIndexed { pos, num -> o = o.replace("{$num}", "{#$pos}").replace("{$num|", "{#$pos|") }
                o.replace("{#", "{")
            }
            val anchor = literals.maxByOrNull { it.length }.orEmpty()
            return runCatching { Template(Regex(sb.toString(), RegexOption.DOT_MATCHES_ALL), anchor, normalized) }.getOrNull()
        }

        private fun unescape(s: String): String {
            if (!s.contains('\\')) return s
            val b = StringBuilder(s.length)
            var i = 0
            while (i < s.length) {
                val c = s[i]
                if (c == '\\' && i + 1 < s.length) {
                    when (s[i + 1]) {
                        'n' -> b.append('\n')
                        't' -> b.append('\t')
                        '\\' -> b.append('\\')
                        else -> { b.append(c); b.append(s[i + 1]) }
                    }
                    i += 2
                } else {
                    b.append(c); i++
                }
            }
            return b.toString()
        }
    }
}
