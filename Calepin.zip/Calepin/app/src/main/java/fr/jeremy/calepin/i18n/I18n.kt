package fr.jeremy.calepin.i18n

import android.content.Context
import android.widget.Toast
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import java.util.Locale

/** Langue de l'appli : Calepin est en français seulement. */
enum class AppLanguage(val code: String, val label: String, val speechTag: String, val englishName: String) {
    FR("fr", "Français", "fr-FR", "French");

    val locale: Locale get() = Locale.FRANCE
}

/**
 * Textes de l'interface. Calepin est en français : les textes du code s'affichent tels quels.
 * [trf] remplit les textes à trous écrits avec {0}, {1}…
 */
object I18n {
    private val _language = MutableStateFlow(AppLanguage.FR)
    val language: StateFlow<AppLanguage> = _language

    /** Gardé pour les appels existants (rappels, widgets…) : rien à lire. */
    @Suppress("UNUSED_PARAMETER")
    fun init(ctx: Context) {}

    /** Langue des dates (jours, mois). */
    val locale: Locale get() = Locale.FRANCE

    /** Format de date (inchangé : français). */
    fun pattern(p: String): String = p

    fun tr(text: String): String = text

    @Suppress("UNUSED_PARAMETER")
    fun tr(ctx: Context, text: String): String = text

    /** Texte à trous écrit avec {0}, {1}… : rempli avec les valeurs. */
    fun trf(key: String, vararg args: Any?): String {
        var s = PLURAL_FORM.replace(key) { m ->
            val v = args.getOrNull(m.groupValues[1].toInt())?.toString().orEmpty()
            if (v.isEmpty() || v == "1") m.groupValues[2] else m.groupValues[3]
        }
        args.forEachIndexed { i, a -> s = s.replace("{$i}", a?.toString().orEmpty()) }
        return s
    }

    private val PLURAL_FORM = Regex("""\{(\d+)\|([^|}]*)\|([^}]*)\}""")

    /** Même usage que Toast.makeText. */
    fun toast(ctx: Context, text: CharSequence, duration: Int): Toast = Toast.makeText(ctx, text, duration)
}
