package fr.jeremy.calepin.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Backspace
import androidx.compose.material.icons.filled.Fingerprint
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import fr.jeremy.calepin.SectionLock
import fr.jeremy.calepin.i18n.I18n
import fr.jeremy.calepin.i18n.RawText
import fr.jeremy.calepin.i18n.Text
import kotlinx.coroutines.delay

/** Nom affiché d'une rubrique protégée. */
private fun sectionName(section: String) = SectionLock.SECTIONS.firstOrNull { it.first == section }?.second ?: section

/**
 * Affiche [content] si la rubrique n'est pas protégée par le code PIN (ou déjà déverrouillée),
 * sinon le clavier du code. [onCancel] : retour sans déverrouiller.
 */
@Composable
fun SectionGate(section: String, onCancel: () -> Unit, content: @Composable () -> Unit) {
    val ctx = LocalContext.current
    remember { SectionLock.init(ctx) }
    val hasPin by SectionLock.hasPin.collectAsStateWithLifecycle()
    val guarded by SectionLock.guarded.collectAsStateWithLifecycle()
    val unlocked by SectionLock.unlocked.collectAsStateWithLifecycle()
    if (hasPin && section in guarded && section !in unlocked) {
        SectionPinPad(I18n.trf("« {0} » est protégé", I18n.tr(sectionName(section))), onOk = { SectionLock.unlock(section) }, onCancel = onCancel)
    } else content()
}

/** Note sensible (ou toutes les notes protégées) : le code avant de l'afficher. */
@Composable
fun NoteGate(noteId: Long?, onCancel: () -> Unit, content: @Composable () -> Unit) {
    val ctx = LocalContext.current
    remember { SectionLock.init(ctx) }
    val hasPin by SectionLock.hasPin.collectAsStateWithLifecycle()
    val guarded by SectionLock.guarded.collectAsStateWithLifecycle()
    val unlocked by SectionLock.unlocked.collectAsStateWithLifecycle()
    val privates by SectionLock.privateNotes.collectAsStateWithLifecycle()
    val needAll = hasPin && SectionLock.NOTES in guarded && SectionLock.NOTES !in unlocked
    val needPrivate = hasPin && noteId != null && noteId in privates && SectionLock.PRIVATE in guarded && SectionLock.PRIVATE !in unlocked
    when {
        needAll -> SectionPinPad(I18n.trf("« {0} » est protégé", I18n.tr("Notes")), onOk = { SectionLock.unlock(SectionLock.NOTES) }, onCancel = onCancel)
        needPrivate -> SectionPinPad(I18n.tr("Note sensible"), onOk = { SectionLock.unlock(SectionLock.PRIVATE) }, onCancel = onCancel)
        else -> content()
    }
}

@Composable
fun SectionPinPad(title: String, onOk: () -> Unit, onCancel: () -> Unit) {
    val ctx = LocalContext.current
    val activity = ctx as? FragmentActivity
    BackHandler { onCancel() }
    val bioOn by SectionLock.bio.collectAsStateWithLifecycle()
    val bioOk = remember { Bio.available(ctx) }
    var entered by remember { mutableStateOf("") }
    var message by remember { mutableStateOf<String?>(null) }
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    val waiting = SectionLock.lockedUntil > now

    LaunchedEffect(waiting) {
        while (SectionLock.lockedUntil > System.currentTimeMillis()) { now = System.currentTimeMillis(); delay(500) }
        now = System.currentTimeMillis()
    }

    fun askBio() {
        if (activity != null) Bio.prompt(activity, true, onSuccess = onOk, onFail = { message = it })
    }
    LaunchedEffect(Unit) { if (bioOn && bioOk) askBio() }

    fun tryPin(pin: String) {
        if (SectionLock.checkPin(pin)) {
            SectionLock.failedAttempts = 0
            onOk()
        } else {
            val fails = SectionLock.failedAttempts + 1
            SectionLock.failedAttempts = fails
            entered = ""
            if (fails >= 5) {
                SectionLock.lockedUntil = System.currentTimeMillis() + 30_000
                SectionLock.failedAttempts = 0
                now = System.currentTimeMillis()
                message = I18n.tr("Trop d'essais. Patientez 30 secondes.")
            } else {
                message = I18n.trf("Code incorrect ({0} essai(s) avant attente)", (5 - fails).toString())
            }
        }
    }

    Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
        Box(Modifier.fillMaxSize().systemBarsPadding()) {
            IconButton(onClick = onCancel, modifier = Modifier.padding(4.dp)) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Retour") }
            Column(
                Modifier.fillMaxSize().padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center,
            ) {
                Icon(Icons.Filled.Lock, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(40.dp))
                Spacer(Modifier.height(12.dp))
                RawText(title, style = MaterialTheme.typography.headlineSmall)
                Spacer(Modifier.height(6.dp))
                Text("Saisissez le code de protection", color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(Modifier.height(20.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                    repeat(maxOf(4, entered.length)) { i ->
                        Box(
                            Modifier.size(14.dp).then(
                                if (i < entered.length) Modifier.background(MaterialTheme.colorScheme.primary, CircleShape)
                                else Modifier.border(1.5.dp, MaterialTheme.colorScheme.outline, CircleShape)
                            ),
                        )
                    }
                }
                Spacer(Modifier.height(10.dp))
                RawText(
                    if (waiting) I18n.trf("Patientez {0} s", (((SectionLock.lockedUntil - now) / 1000) + 1).toString()) else message ?: " ",
                    color = MaterialTheme.colorScheme.error,
                    style = MaterialTheme.typography.bodyMedium,
                )
                Spacer(Modifier.height(12.dp))
                val keys = listOf("1", "2", "3", "4", "5", "6", "7", "8", "9", "bio", "0", "del")
                keys.chunked(3).forEach { row ->
                    Row(horizontalArrangement = Arrangement.spacedBy(18.dp), modifier = Modifier.padding(vertical = 6.dp)) {
                        row.forEach { k ->
                            Box(Modifier.size(72.dp), contentAlignment = Alignment.Center) {
                                when (k) {
                                    "bio" -> if (bioOn && bioOk) {
                                        IconButton(onClick = { askBio() }, modifier = Modifier.size(64.dp)) {
                                            Icon(Icons.Filled.Fingerprint, "Empreinte ou visage", modifier = Modifier.size(32.dp))
                                        }
                                    }
                                    "del" -> IconButton(onClick = { entered = entered.dropLast(1) }, modifier = Modifier.size(64.dp)) {
                                        Icon(Icons.Filled.Backspace, "Effacer")
                                    }
                                    else -> FilledTonalButton(
                                        onClick = {
                                            if (!waiting && entered.length < 8) {
                                                entered += k
                                                message = null
                                                if (entered.length >= 4 && SectionLock.checkPin(entered)) tryPin(entered)
                                            }
                                        },
                                        shape = CircleShape,
                                        modifier = Modifier.size(68.dp),
                                        enabled = !waiting,
                                    ) { RawText(k, style = MaterialTheme.typography.headlineSmall.copy(fontSize = 24.sp, fontWeight = FontWeight.Medium)) }
                                }
                            }
                        }
                    }
                }
                Spacer(Modifier.height(6.dp))
                TextButton(onClick = { if (entered.length >= 4) tryPin(entered) }, enabled = !waiting && entered.length >= 4) { Text("Valider") }
            }
        }
    }
}
