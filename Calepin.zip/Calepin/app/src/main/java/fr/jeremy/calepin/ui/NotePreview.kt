package fr.jeremy.calepin.ui

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import fr.jeremy.calepin.i18n.Text
import fr.jeremy.calepin.text.NoteLayout
import java.io.File

/** Texte d'une note mis en forme comme à l'ouverture (repères cachés, gras, couleurs, cases à cocher…). */
@Composable
fun styledNote(text: String): AnnotatedString {
    val cs = MaterialTheme.colorScheme
    return remember(text, cs.primary, cs.onSurfaceVariant, cs.tertiary) {
        val b = AnnotatedString.Builder(text)
        val box = SpanStyle(color = cs.primary, fontWeight = FontWeight.Bold)
        val done = SpanStyle(textDecoration = TextDecoration.LineThrough, color = cs.onSurfaceVariant.copy(alpha = 0.7f))
        Checklist.boxPositions(text).forEach { p -> if (p < text.length) b.addStyle(box, p, p + 1) }
        Checklist.doneRanges(text).forEach { r -> if (r.last < text.length) b.addStyle(done, r.first, r.last + 1) }
        Markdown.styleInto(b, text, Markdown.HIDDEN, cs.primary)
        Markdown.links.findAll(text).forEach { m ->
            b.addStyle(Markdown.HIDDEN, m.range.first, m.range.first + 2)
            b.addStyle(Markdown.HIDDEN, m.range.last - 1, m.range.last + 1)
            b.addStyle(SpanStyle(color = cs.tertiary, fontWeight = FontWeight.SemiBold), m.range.first + 2, m.range.last - 1)
        }
        RichStyle.spansInto(b, text, Markdown.HIDDEN)
        RichStyle.alignInto(b, text)
        // Repères de photos dans une phrase : cachés
        NoteLayout.marker.findAll(text).forEach { b.addStyle(Markdown.HIDDEN, it.range.first, it.range.last + 1) }
        b.toAnnotatedString()
    }
}

/**
 * Aperçu d'une note dans la liste, présenté comme une fois ouverte : texte mis en forme, photos à leur place
 * (le texte passe à côté des photos à gauche ou à droite). Coupé à [maxHeight].
 */
@Composable
fun NotePreview(content: String, maxHeight: Dp, style: TextStyle, color: Color, modifier: Modifier = Modifier) {
    val ctx = LocalContext.current
    val dir = remember { fr.jeremy.calepin.media.Media.dir(ctx) }
    val full = styledNote(content)
    val segments = remember(content) { NoteLayout.segments(content) }
    fun isVideo(name: String) = name.endsWith(".mp4", ignoreCase = true)
    val part: @Composable (Int, Int, Modifier) -> Unit = { s, e, mod ->
        if (e > s) Text(full.subSequence(s, e), style = style, color = color, overflow = TextOverflow.Clip, modifier = mod)
    }
    Column(modifier.fillMaxWidth().heightIn(max = maxHeight).clipToBounds(), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        segments.forEach { seg ->
            val fl = seg.float
            when {
                seg.files != null -> Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    seg.files.forEach { f -> NotePhoto(File(dir, f), isVideo(f), Modifier.size(56.dp), maxSide = 200) }
                }
                fl != null -> FloatLayout(
                    File(dir, fl.file), fl.video, fl,
                    full.subSequence(seg.start, seg.end), style,
                    photoModifier = Modifier, photoAlpha = 1f, maxSide = 400,
                ) { from, to, mod -> part(seg.start + from, seg.start + to, mod) }
                else -> part(seg.start, seg.end, Modifier.fillMaxWidth())
            }
        }
    }
}
