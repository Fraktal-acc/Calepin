package fr.jeremy.calepin.games

import android.content.Context
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.Gesture
import androidx.compose.material.icons.filled.ViewModule
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import fr.jeremy.calepin.i18n.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

enum class Game(val label: String, val desc: String, val key: String) {
    TETRIS("Tetris", "Empilez les pièces, complétez des lignes", "tetris"),
    BREAKOUT("Casse-briques", "Faites glisser la raquette, cassez tout", "breakout"),
    SNAKE("Snake", "Mangez sans vous mordre la queue", "snake"),
}

/** Meilleurs scores, gardés sur le téléphone. */
object GameScores {
    private fun prefs(ctx: Context) = ctx.getSharedPreferences("calepin_games", Context.MODE_PRIVATE)
    fun best(ctx: Context, key: String) = prefs(ctx).getInt("best_$key", 0)

    /** Enregistre si c'est un record ; renvoie vrai dans ce cas. */
    fun submit(ctx: Context, key: String, score: Int): Boolean {
        if (score <= best(ctx, key)) return false
        prefs(ctx).edit().putInt("best_$key", score).apply()
        return true
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GamesScreen(onClose: () -> Unit) {
    var game by rememberSaveable { mutableStateOf<Game?>(null) }
    BackHandler { if (game != null) game = null else onClose() }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(game?.label ?: "Jeux") },
                navigationIcon = {
                    IconButton(onClick = { if (game != null) game = null else onClose() }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Retour")
                    }
                },
            )
        },
    ) { pad ->
        Box(
            Modifier
                .fillMaxSize()
                .padding(pad)
                .padding(horizontal = 12.dp)
                .padding(bottom = 12.dp),
        ) {
            when (game) {
                null -> GameMenu { game = it }
                Game.TETRIS -> TetrisGame()
                Game.BREAKOUT -> BreakoutGame()
                Game.SNAKE -> SnakeGame()
            }
        }
    }
}

@Composable
private fun GameMenu(onPick: (Game) -> Unit) {
    val ctx = LocalContext.current
    Column(verticalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.padding(top = 8.dp)) {
        Text(
            "Un petit jeu en attendant ? Tout fonctionne hors ligne.",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Game.entries.forEach { g ->
            val icon: ImageVector = when (g) {
                Game.TETRIS -> Icons.Filled.Apps
                Game.BREAKOUT -> Icons.Filled.ViewModule
                Game.SNAKE -> Icons.Filled.Gesture
            }
            Card(
                onClick = { onPick(g) },
                border = fr.jeremy.calepin.ui.appBorder(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLow),
                modifier = Modifier.fillMaxWidth(),
            ) {
                Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Surface(shape = CircleShape, color = MaterialTheme.colorScheme.primaryContainer, modifier = Modifier.size(48.dp)) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(icon, null, tint = MaterialTheme.colorScheme.onPrimaryContainer)
                        }
                    }
                    Spacer(Modifier.width(14.dp))
                    Column(Modifier.weight(1f)) {
                        Text(g.label, style = MaterialTheme.typography.titleMedium)
                        Text(g.desc, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    val best = remember { GameScores.best(ctx, g.key) }
                    if (best > 0) {
                        Column(horizontalAlignment = Alignment.End) {
                            Text("Record", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text("$best", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary)
                        }
                    }
                }
            }
        }
    }
}

// ------------------------------------------------------------------ Outils communs

/** Appelle [onFrame] à chaque image (durée écoulée en ms) tant que [running] est vrai. */
@Composable
internal fun GameLoop(running: Boolean, onFrame: (Float) -> Unit) {
    val latest by rememberUpdatedState(onFrame)
    LaunchedEffect(running) {
        if (!running) return@LaunchedEffect
        var last = 0L
        while (true) {
            withFrameNanos { t ->
                if (last != 0L) latest(((t - last) / 1_000_000f).coerceAtMost(50f))
                last = t
            }
        }
    }
}

/** Ligne du haut : score, record et autre information. */
@Composable
internal fun ScoreBar(score: Int, best: Int, extra: String? = null) {
    Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text("Score", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text("$score", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        }
        if (extra != null) {
            Text(extra, style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.secondary, modifier = Modifier.padding(end = 16.dp))
        }
        Column(horizontalAlignment = Alignment.End) {
            Text("Record", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text("${maxOf(score, best)}", style = MaterialTheme.typography.titleLarge, color = MaterialTheme.colorScheme.primary)
        }
    }
}

/** Voile affiché en pause ou en fin de partie. */
@Composable
internal fun BoxScope.Overlay(title: String, subtitle: String) {
    Column(
        Modifier
            .align(Alignment.Center)
            .clip(RoundedCornerShape(16.dp))
            .background(Color.Black.copy(alpha = 0.72f))
            .padding(horizontal = 24.dp, vertical = 18.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text(title, color = Color.White, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
        Spacer(Modifier.size(6.dp))
        Text(subtitle, color = Color.White.copy(alpha = 0.85f), style = MaterialTheme.typography.bodyMedium, textAlign = TextAlign.Center)
    }
}

/** Bouton de commande ; [repeat] : l'action se répète tant qu'on garde le doigt dessus. */
@Composable
internal fun PadButton(
    icon: ImageVector,
    description: String,
    modifier: Modifier = Modifier,
    repeat: Boolean = false,
    onPress: () -> Unit,
) {
    val scope = rememberCoroutineScope()
    val action by rememberUpdatedState(onPress)
    Surface(
        shape = RoundedCornerShape(16.dp),
        color = MaterialTheme.colorScheme.secondaryContainer,
        modifier = modifier
            .size(64.dp)
            .clip(RoundedCornerShape(16.dp))
            .pointerInput(repeat) {
                detectTapGestures(onPress = {
                    action()
                    val job = if (repeat) scope.launch {
                        delay(220)
                        while (true) { action(); delay(55) }
                    } else null
                    tryAwaitRelease()
                    job?.cancel()
                })
            },
    ) {
        Box(contentAlignment = Alignment.Center) {
            Icon(icon, contentDescription = description, tint = MaterialTheme.colorScheme.onSecondaryContainer, modifier = Modifier.size(32.dp))
        }
    }
}

/** Couleurs vives des pièces et briques. */
internal val GamePalette = listOf(
    Color(0xFF26C6DA), Color(0xFFFFCA28), Color(0xFFAB47BC), Color(0xFF66BB6A),
    Color(0xFFEF5350), Color(0xFF42A5F5), Color(0xFFFF7043),
)

internal val BoardBackground = Color(0xFF14181F)
internal val GridLine = Color(0xFF232A35)
