package fr.jeremy.calepin.ui

import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.OpenInNew
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import fr.jeremy.calepin.control.Mail
import fr.jeremy.calepin.control.MessageHub
import fr.jeremy.calepin.i18n.I18n
import fr.jeremy.calepin.i18n.RawText
import fr.jeremy.calepin.i18n.Text
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

private fun whenText(t: Long): String {
    if (t <= 0) return ""
    val c = Calendar.getInstance().apply { timeInMillis = t }
    val now = Calendar.getInstance()
    val sameDay = c.get(Calendar.YEAR) == now.get(Calendar.YEAR) && c.get(Calendar.DAY_OF_YEAR) == now.get(Calendar.DAY_OF_YEAR)
    return SimpleDateFormat(if (sameDay) "HH:mm" else "dd/MM HH:mm", Locale.getDefault()).format(Date(t))
}

/** Ce qu'il faut ouvrir en arrivant dans Messages (depuis la recherche de l'accueil). */
object MessagesTarget {
    @Volatile var mail: fr.jeremy.calepin.mail.MailHeader? = null
}

/**
 * Messages : les mails. Mes adresses (boîte de réception, lecture, écriture), mes contacts mail,
 * et les mails reçus des adresses suivies, repérés dans les notifications des applis de mail.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MessagesScreen(onClose: () -> Unit, onOpenPdf: ((String) -> Unit)? = null) {
    val ctx = LocalContext.current
    remember { MessageHub.init(ctx) }
    var access by remember { mutableStateOf(MessageHub.hasAccess(ctx)) }
    LaunchedEffect(Unit) {
        while (true) { access = MessageHub.hasAccess(ctx); delay(1500) }
    }
    // Mails avec les adresses de l'utilisateur : boîte de réception, lecture, écriture
    remember { fr.jeremy.calepin.mail.MailAccounts.init(ctx) }
    val mailAccounts by fr.jeremy.calepin.mail.MailAccounts.accounts.collectAsStateWithLifecycle()
    var inboxId by rememberSaveable { mutableStateOf<String?>(null) }
    var readUid by rememberSaveable { mutableStateOf<Long?>(null) }
    var readFolder by rememberSaveable { mutableStateOf("INBOX") }
    var fromSearch by rememberSaveable { mutableStateOf(false) }
    // Arrivée depuis la recherche de l'accueil : mail à ouvrir tout de suite
    remember {
        MessagesTarget.mail?.let { h -> fromSearch = true; readFolder = h.folder; inboxId = h.accountId; readUid = h.uid; MessagesTarget.mail = null }
        true
    }
    var draft by remember { mutableStateOf<fr.jeremy.calepin.ui.mail.MailDraft?>(null) }
    val inboxAccount = mailAccounts.firstOrNull { it.id == inboxId }
    draft?.let { d ->
        fr.jeremy.calepin.ui.mail.MailComposeScreen(d, onClose = { draft = null })
        return
    }
    if (inboxAccount != null) {
        val uid = readUid
        if (uid != null) fr.jeremy.calepin.ui.mail.MailReadScreen(
            inboxAccount, uid,
            onBack = { readUid = null; readFolder = "INBOX"; if (fromSearch) { fromSearch = false; inboxId = null } },
            onCompose = { draft = it },
            folder = readFolder,
            onOpenPdf = onOpenPdf,
        )
        else fr.jeremy.calepin.ui.mail.MailInboxScreen(
            inboxAccount, onBack = { inboxId = null },
            onOpen = { readFolder = "INBOX"; readUid = it },
            onCompose = { draft = fr.jeremy.calepin.ui.mail.MailDraft(inboxAccount.id) },
        )
        return
    }

    BackHandler { onClose() }
    Scaffold(
        topBar = {
            TopAppBar(
                title = { FitText("Messages") },
                navigationIcon = { IconButton(onClick = onClose) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Retour") } },
            )
        },
    ) { pad ->
        LazyColumn(
            Modifier.fillMaxSize().padding(pad),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 40.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            mailsTab(
                this,
                onInbox = { inboxId = it.id },
                onCompose = { draft = fr.jeremy.calepin.ui.mail.MailDraft(mailAccounts.firstOrNull()?.id) },
                onFound = { h -> fromSearch = true; readFolder = h.folder; inboxId = h.accountId; readUid = h.uid },
                onWrite = { email ->
                    if (mailAccounts.isEmpty()) Toast.makeText(ctx, I18n.tr("Ajoute d'abord ton adresse mail (Mes adresses mail)."), Toast.LENGTH_LONG).show()
                    else draft = fr.jeremy.calepin.ui.mail.MailDraft(mailAccounts.first().id, to = "$email, ")
                },
                access = access,
                onAccess = { MessageHub.openAccessSettings(ctx) },
            )
        }
    }
}

// ------------------------------------------------------------------ Mails

private fun mailsTab(
    scope: androidx.compose.foundation.lazy.LazyListScope,
    onInbox: (fr.jeremy.calepin.mail.MailAccount) -> Unit,
    onCompose: () -> Unit,
    onFound: (fr.jeremy.calepin.mail.MailHeader) -> Unit,
    onWrite: (String) -> Unit,
    access: Boolean,
    onAccess: () -> Unit,
) {
    scope.item { fr.jeremy.calepin.ui.mail.MailAccountsCard(onInbox, onCompose) }
    scope.item { fr.jeremy.calepin.ui.mail.MailContactsCard(onWrite) }
    scope.item { fr.jeremy.calepin.ui.mail.MailSearchCard(onFound) }
    if (!access) scope.item { AccessCard(onAccess) }
    scope.item { MailRulesCard() }
    scope.item { MailListHeader() }
    scope.item { MailList() }
}

/** Lecture des notifications des applis de mail : à autoriser une fois dans les réglages d'Android. */
@Composable
private fun AccessCard(onAccess: () -> Unit) {
    MsgCard {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Filled.NotificationsActive, null, tint = MaterialTheme.colorScheme.primary)
            Spacer(Modifier.width(10.dp))
            Text("Accès aux notifications", style = MaterialTheme.typography.titleMedium)
        }
        Text(
            "Pour repérer ici les mails des adresses suivies reçus dans Gmail, Outlook, Samsung Email…, Calepin lit leurs notifications. " +
                "Seules les adresses que tu ajoutes sont gardées, et rien ne quitte le téléphone.",
            style = MaterialTheme.typography.bodyMedium,
        )
        Button(onClick = onAccess) { Text("Autoriser l'accès") }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun MailRulesCard() {
    val ctx = LocalContext.current
    val rules by MessageHub.mailRules.collectAsStateWithLifecycle()
    val recent by MessageHub.recent.collectAsStateWithLifecycle()
    var input by remember { mutableStateOf("") }
    val suggestions = recent.filter { rules.none { r -> r.equals(it, true) } }.take(10)
    MsgCard {
        Text("Mails repérés dans les notifications", style = MaterialTheme.typography.titleMedium)
        Text(
            "Les mails reçus de ces adresses (ou de ces noms) dans Gmail, Outlook, Samsung Email… s'affichent ici. " +
                "Les applis de mail montrent souvent le nom de l'expéditeur plutôt que son adresse : ajoute aussi son nom si besoin.",
            style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        if (rules.isNotEmpty()) FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            rules.forEach { r ->
                Surface(shape = RoundedCornerShape(50), color = MaterialTheme.colorScheme.secondaryContainer) {
                    Row(Modifier.padding(start = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                        RawText(r, style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSecondaryContainer)
                        IconButton(onClick = { MessageHub.removeMailRule(ctx, r) }, modifier = Modifier.size(36.dp)) { Icon(Icons.Filled.Close, "Retirer", Modifier.size(16.dp)) }
                    }
                }
            }
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                input, { input = it }, label = { Text("Adresse mail ou nom") }, singleLine = true, modifier = Modifier.weight(1f),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
            )
            IconButton(enabled = input.isNotBlank(), onClick = { MessageHub.addMailRule(ctx, input); input = "" }) { Icon(Icons.Filled.Add, "Ajouter") }
        }
        if (suggestions.isNotEmpty()) {
            Text("Expéditeurs vus récemment :", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                suggestions.forEach { s -> FilterChip(selected = false, onClick = { MessageHub.addMailRule(ctx, s) }, label = { RawText(s, maxLines = 1) }, leadingIcon = { Icon(Icons.Filled.Add, null, Modifier.size(16.dp)) }) }
            }
        }
    }
}

@Composable
private fun MailListHeader() {
    val mails by MessageHub.mails.collectAsStateWithLifecycle()
    Text(if (mails.isEmpty()) "Aucun mail reçu des adresses suivies pour le moment." else "Mails reçus", style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
}

@Composable
private fun MailList() {
    val ctx = LocalContext.current
    val mails by MessageHub.mails.collectAsStateWithLifecycle()
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        mails.forEach { m -> MailRow(m, onOpen = { MessageHub.openMail(ctx, m) }, onDelete = { MessageHub.deleteMail(ctx, m.id) }) }
    }
}

@Composable
private fun MailRow(m: Mail, onOpen: () -> Unit, onDelete: () -> Unit) {
    var expanded by remember { mutableStateOf(false) }
    Surface(onClick = { expanded = !expanded }, shape = MaterialTheme.shapes.large, color = MaterialTheme.colorScheme.surfaceContainerLow, border = appBorder(), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.Email, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(20.dp))
                Spacer(Modifier.width(8.dp))
                RawText(m.from, style = MaterialTheme.typography.titleSmall, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
                RawText(whenText(m.time), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            if (m.subject.isNotBlank()) RawText(m.subject, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold, maxLines = if (expanded) Int.MAX_VALUE else 2, overflow = TextOverflow.Ellipsis)
            val body = m.body.removePrefix(m.subject).trim()
            if (body.isNotBlank()) RawText(body, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = if (expanded) Int.MAX_VALUE else 3, overflow = TextOverflow.Ellipsis)
            if (m.account.isNotBlank()) RawText(m.account, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            if (expanded) Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                TextButton(onClick = onOpen) { Icon(Icons.AutoMirrored.Filled.OpenInNew, null, Modifier.size(18.dp)); Text("  Ouvrir") }
                TextButton(onClick = onDelete) { Icon(Icons.Filled.Delete, null, Modifier.size(18.dp)); Text("  Retirer") }
            }
        }
    }
}

@Composable
private fun MsgCard(content: @Composable () -> Unit) {
    Surface(shape = MaterialTheme.shapes.large, color = MaterialTheme.colorScheme.surfaceContainerLow, border = appBorder(), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) { content() }
    }
}
