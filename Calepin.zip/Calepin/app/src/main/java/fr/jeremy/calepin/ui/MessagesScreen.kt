package fr.jeremy.calepin.ui

import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.OpenInNew
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Forum
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import fr.jeremy.calepin.control.Conv
import fr.jeremy.calepin.control.Mail
import fr.jeremy.calepin.control.MessageHub
import fr.jeremy.calepin.control.Msg
import fr.jeremy.calepin.control.WhatsAppSender
import fr.jeremy.calepin.i18n.I18n
import fr.jeremy.calepin.i18n.RawText
import fr.jeremy.calepin.i18n.Text
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

private val WA_GREEN = Color(0xFF25D366)
private val TG_BLUE = Color(0xFF2AABEE)

private fun appColor(app: String) = if (app == Conv.TELEGRAM) TG_BLUE else WA_GREEN
private fun appLabel(app: String) = if (app == Conv.TELEGRAM) "Telegram" else "WhatsApp"

private fun whenText(t: Long): String {
    if (t <= 0) return ""
    val c = Calendar.getInstance().apply { timeInMillis = t }
    val now = Calendar.getInstance()
    val sameDay = c.get(Calendar.YEAR) == now.get(Calendar.YEAR) && c.get(Calendar.DAY_OF_YEAR) == now.get(Calendar.DAY_OF_YEAR)
    return SimpleDateFormat(if (sameDay) "HH:mm" else "dd/MM HH:mm", Locale.getDefault()).format(Date(t))
}

/**
 * Messages : conversations WhatsApp et Telegram choisies (lues depuis les notifications, réponse directe),
 * et mails reçus des adresses suivies.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MessagesScreen(onClose: () -> Unit) {
    val ctx = LocalContext.current
    remember { MessageHub.init(ctx) }
    var tab by rememberSaveable { mutableIntStateOf(0) }
    var openKey by rememberSaveable { mutableStateOf<String?>(null) }
    var access by remember { mutableStateOf(MessageHub.hasAccess(ctx)) }
    LaunchedEffect(Unit) {
        while (true) { access = MessageHub.hasAccess(ctx); delay(1500) }
    }
    val convs by MessageHub.convs.collectAsStateWithLifecycle()
    val opened = convs.firstOrNull { it.key == openKey }
    if (opened != null) {
        ConversationView(opened, onBack = { openKey = null })
        return
    }

    BackHandler { onClose() }
    Scaffold(
        topBar = {
            TopAppBar(
                title = { FitText("Messages") },
                navigationIcon = { IconButton(onClick = onClose) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Retour") } },
            )
        },
    ) { pad ->
        LazyColumn(
            Modifier.fillMaxSize().padding(pad),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 40.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(selected = tab == 0, onClick = { tab = 0 }, label = { Text("Conversations") }, leadingIcon = { Icon(Icons.Filled.Forum, null, Modifier.size(18.dp)) })
                    FilterChip(selected = tab == 1, onClick = { tab = 1 }, label = { Text("Mails") }, leadingIcon = { Icon(Icons.Filled.Email, null, Modifier.size(18.dp)) })
                }
            }
            if (!access) item {
                MsgCard {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Filled.NotificationsActive, null, tint = MaterialTheme.colorScheme.primary)
                        Spacer(Modifier.width(10.dp))
                        Text("Accès aux notifications", style = MaterialTheme.typography.titleMedium)
                    }
                    Text(
                        "Pour afficher ici les messages WhatsApp et Telegram et les mails choisis, Calepin lit leurs notifications. " +
                            "Seules les conversations et adresses que tu ajoutes sont gardées, et rien ne quitte le téléphone.",
                        style = MaterialTheme.typography.bodyMedium,
                    )
                    Button(onClick = { MessageHub.openAccessSettings(ctx) }) { Text("Autoriser l'accès") }
                }
            }
            if (tab == 0) conversationsTab(this, convs) { openKey = it.key }
            else mailsTab(this)
        }
    }
}

// ------------------------------------------------------------------ Conversations

private fun conversationsTab(scope: androidx.compose.foundation.lazy.LazyListScope, convs: List<Conv>, onOpen: (Conv) -> Unit) {
    scope.item { AddConvButton() }
    if (convs.isEmpty()) scope.item {
        Text(
            "Ajoute les conversations WhatsApp ou Telegram à suivre (une personne ou un groupe). Leurs nouveaux messages apparaîtront ici, " +
                "et tu pourras répondre sans ouvrir l'appli. À l'assistant, dis aussi « envoie un WhatsApp à Marc : j'arrive » ou « Telegram à Julie : à ce soir ».",
            style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
    scope.items(convs, key = { it.key }) { c -> ConvRow(c, onOpen) }
}

@Composable
private fun AddConvButton() {
    var show by remember { mutableStateOf(false) }
    Button(onClick = { show = true }, modifier = Modifier.fillMaxWidth()) {
        Icon(Icons.Filled.Add, null); Spacer(Modifier.width(6.dp)); Text("Ajouter une conversation")
    }
    if (show) AddConvDialog { show = false }
}

@Composable
private fun AppBadge(app: String, size: Int = 40) {
    Box(Modifier.size(size.dp).clip(CircleShape).background(appColor(app)), contentAlignment = Alignment.Center) {
        RawText(if (app == Conv.TELEGRAM) "TG" else "WA", color = Color.White, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelLarge)
    }
}

@Composable
private fun ConvRow(c: Conv, onOpen: (Conv) -> Unit) {
    val all by MessageHub.messages.collectAsStateWithLifecycle()
    val last = all[c.key]?.lastOrNull()
    Surface(onClick = { onOpen(c) }, shape = MaterialTheme.shapes.large, color = MaterialTheme.colorScheme.surfaceContainerLow, border = appBorder(), modifier = Modifier.fillMaxWidth()) {
        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            AppBadge(c.app)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    RawText(c.name, style = MaterialTheme.typography.titleMedium, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
                    if (last != null) RawText(whenText(last.time), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                if (last != null) RawText(
                    (if (last.mine) I18n.tr("Moi") + " : " else "") + last.text,
                    style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 2, overflow = TextOverflow.Ellipsis,
                ) else RawText(appLabel(c.app) + " · " + I18n.tr("pas encore de message"), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun AddConvDialog(onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    var app by remember { mutableStateOf(Conv.WHATSAPP) }
    var name by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    val recent by MessageHub.recent.collectAsStateWithLifecycle()
    val convs by MessageHub.convs.collectAsStateWithLifecycle()
    val suggestions = recent.filter { (a, n) -> a == app && convs.none { it.app == a && it.name == n } }.map { it.second }.take(12)
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Nouvelle conversation") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(Conv.WHATSAPP, Conv.TELEGRAM).forEach { a ->
                        FilterChip(selected = app == a, onClick = { app = a }, label = { RawText(appLabel(a)) })
                    }
                }
                if (suggestions.isNotEmpty()) {
                    Text("Vues récemment dans les notifications :", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        suggestions.forEach { s -> FilterChip(selected = name == s, onClick = { name = s }, label = { RawText(s, maxLines = 1) }) }
                    }
                }
                OutlinedTextField(name, { name = it }, label = { Text("Nom de la personne ou du groupe") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(
                    phone, { phone = it }, label = { Text("Numéro (facultatif)") }, singleLine = true, modifier = Modifier.fillMaxWidth(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                )
                Text(
                    "Le nom doit être celui affiché dans les notifications. Le numéro permet d'ouvrir directement la conversation quand la réponse rapide n'est pas disponible.",
                    style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        },
        confirmButton = {
            TextButton(enabled = name.isNotBlank(), onClick = {
                MessageHub.addConv(ctx, Conv(app, name.trim(), phone.trim()))
                onDismiss()
            }) { Text("Ajouter") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Annuler") } },
    )
}

// ------------------------------------------------------------------ Discussion

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ConversationView(conv: Conv, onBack: () -> Unit) {
    val ctx = LocalContext.current
    BackHandler { onBack() }
    val all by MessageHub.messages.collectAsStateWithLifecycle()
    val msgs = all[conv.key].orEmpty()
    var input by rememberSaveable(conv.key) { mutableStateOf("") }
    var confirmRemove by remember { mutableStateOf(false) }
    var confirmClear by remember { mutableStateOf(false) }
    val list = rememberLazyListState()
    LaunchedEffect(msgs.size) { if (msgs.isNotEmpty()) list.scrollToItem(0) }
    val direct = remember(msgs.size) { MessageHub.canReplyDirectly(conv.key) }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.surface,
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        AppBadge(conv.app, 32)
                        Spacer(Modifier.width(10.dp))
                        Column {
                            RawText(conv.name, maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.titleMedium)
                            RawText(appLabel(conv.app), style = MaterialTheme.typography.labelSmall, color = appColor(conv.app))
                        }
                    }
                },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Retour") } },
                actions = {
                    IconButton(onClick = { MessageHub.openApp(ctx, conv) }) { Icon(Icons.AutoMirrored.Filled.OpenInNew, "Ouvrir dans l'appli") }
                    IconButton(onClick = { confirmClear = true }) { Icon(Icons.Filled.DeleteSweep, "Effacer l'historique") }
                    IconButton(onClick = { confirmRemove = true }) { Icon(Icons.Filled.Delete, "Retirer la conversation") }
                },
            )
        },
        bottomBar = {
            Surface(color = MaterialTheme.colorScheme.surfaceContainer, modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.navigationBarsPadding().imePadding().padding(horizontal = 12.dp, vertical = 8.dp)) {
                    RawText(
                        if (direct) I18n.tr("Réponse directe : le message part tout de suite.")
                        else I18n.trf("Le message s'ouvrira dans {0}. La réponse directe revient dès qu'un nouveau message arrive.", appLabel(conv.app)),
                        style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        OutlinedTextField(input, { input = it }, placeholder = { Text("Message") }, modifier = Modifier.weight(1f), maxLines = 5, shape = RoundedCornerShape(24.dp))
                        IconButton(enabled = input.isNotBlank(), onClick = {
                            val t = input.trim()
                            val viaApp = !MessageHub.canReplyDirectly(conv.key)
                            if (viaApp && conv.app == Conv.WHATSAPP && conv.phone.isNotBlank() && WhatsAppSender.isEnabled(ctx)) WhatsAppSender.arm(t)
                            val sent = MessageHub.send(ctx, conv, t)
                            input = ""
                            Toast.makeText(ctx, I18n.tr(if (sent) "Message envoyé." else "Message prêt dans l'appli."), Toast.LENGTH_SHORT).show()
                        }) { Icon(Icons.AutoMirrored.Filled.Send, "Envoyer", tint = appColor(conv.app)) }
                    }
                }
            }
        },
    ) { pad ->
        if (msgs.isEmpty()) {
            Box(Modifier.fillMaxSize().padding(pad).padding(24.dp), contentAlignment = Alignment.Center) {
                Text(
                    "Aucun message pour l'instant. Les prochains messages reçus dans cette conversation s'afficheront ici.",
                    style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        } else LazyColumn(
            Modifier.fillMaxSize().padding(pad),
            state = list,
            reverseLayout = true,
            contentPadding = PaddingValues(12.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp),
        ) {
            items(msgs.asReversed()) { m -> Bubble(m, conv) }
        }
    }

    if (confirmClear) AlertDialog(
        onDismissRequest = { confirmClear = false },
        title = { Text("Effacer l'historique ?") },
        text = { Text("Les messages gardés dans Calepin sont effacés. Rien n'est supprimé dans l'appli de messagerie.") },
        confirmButton = { TextButton(onClick = { MessageHub.clearConv(ctx, conv); confirmClear = false }) { Text("Effacer") } },
        dismissButton = { TextButton(onClick = { confirmClear = false }) { Text("Annuler") } },
    )
    if (confirmRemove) AlertDialog(
        onDismissRequest = { confirmRemove = false },
        title = { Text("Retirer la conversation ?") },
        text = { Text("Calepin ne suivra plus cette conversation. Rien n'est supprimé dans l'appli de messagerie.") },
        confirmButton = { TextButton(onClick = { MessageHub.removeConv(ctx, conv); confirmRemove = false; onBack() }) { Text("Retirer") } },
        dismissButton = { TextButton(onClick = { confirmRemove = false }) { Text("Annuler") } },
    )
}

@Composable
private fun Bubble(m: Msg, conv: Conv) {
    val cs = MaterialTheme.colorScheme
    Row(Modifier.fillMaxWidth(), horizontalArrangement = if (m.mine) Arrangement.End else Arrangement.Start) {
        Surface(
            shape = RoundedCornerShape(topStart = 18.dp, topEnd = 18.dp, bottomStart = if (m.mine) 18.dp else 4.dp, bottomEnd = if (m.mine) 4.dp else 18.dp),
            color = if (m.mine) cs.primaryContainer else cs.surfaceContainerHigh,
            modifier = Modifier.widthIn(max = 300.dp),
        ) {
            Column(Modifier.padding(horizontal = 12.dp, vertical = 8.dp)) {
                // Dans un groupe : nom de l'auteur
                if (!m.mine && m.from.isNotBlank() && !m.from.equals(conv.name, true)) {
                    RawText(m.from, style = MaterialTheme.typography.labelMedium, color = appColor(conv.app), fontWeight = FontWeight.Bold)
                }
                RawText(m.text, style = MaterialTheme.typography.bodyLarge, color = if (m.mine) cs.onPrimaryContainer else cs.onSurface)
                RawText(whenText(m.time), style = MaterialTheme.typography.labelSmall, color = cs.onSurfaceVariant, modifier = Modifier.align(Alignment.End))
            }
        }
    }
}

// ------------------------------------------------------------------ Mails

private fun mailsTab(scope: androidx.compose.foundation.lazy.LazyListScope) {
    scope.item { MailRulesCard() }
    scope.item { MailListHeader() }
    scope.item { MailList() }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun MailRulesCard() {
    val ctx = LocalContext.current
    val rules by MessageHub.mailRules.collectAsStateWithLifecycle()
    val recent by MessageHub.recent.collectAsStateWithLifecycle()
    var input by remember { mutableStateOf("") }
    val suggestions = recent.filter { it.first == "mail" && rules.none { r -> r.equals(it.second, true) } }.map { it.second }.take(10)
    MsgCard {
        Text("Adresses suivies", style = MaterialTheme.typography.titleMedium)
        Text(
            "Les mails reçus de ces adresses (ou de ces noms) dans Gmail, Outlook, Samsung Email… s'affichent ici. " +
                "Les applis de mail montrent souvent le nom de l'expéditeur plutôt que son adresse : ajoute aussi son nom si besoin.",
            style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        if (rules.isNotEmpty()) FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            rules.forEach { r ->
                Surface(shape = RoundedCornerShape(50), color = MaterialTheme.colorScheme.secondaryContainer) {
                    Row(Modifier.padding(start = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                        RawText(r, style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSecondaryContainer)
                        IconButton(onClick = { MessageHub.removeMailRule(ctx, r) }, modifier = Modifier.size(36.dp)) { Icon(Icons.Filled.Close, "Retirer", Modifier.size(16.dp)) }
                    }
                }
            }
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                input, { input = it }, label = { Text("Adresse mail ou nom") }, singleLine = true, modifier = Modifier.weight(1f),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
            )
            IconButton(enabled = input.isNotBlank(), onClick = { MessageHub.addMailRule(ctx, input); input = "" }) { Icon(Icons.Filled.Add, "Ajouter") }
        }
        if (suggestions.isNotEmpty()) {
            Text("Expéditeurs vus récemment :", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                suggestions.forEach { s -> FilterChip(selected = false, onClick = { MessageHub.addMailRule(ctx, s) }, label = { RawText(s, maxLines = 1) }, leadingIcon = { Icon(Icons.Filled.Add, null, Modifier.size(16.dp)) }) }
            }
        }
    }
}

@Composable
private fun MailListHeader() {
    val mails by MessageHub.mails.collectAsStateWithLifecycle()
    Text(if (mails.isEmpty()) "Aucun mail reçu des adresses suivies pour le moment." else "Mails reçus", style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
}

@Composable
private fun MailList() {
    val ctx = LocalContext.current
    val mails by MessageHub.mails.collectAsStateWithLifecycle()
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        mails.forEach { m -> MailRow(m, onOpen = { MessageHub.openMail(ctx, m) }, onDelete = { MessageHub.deleteMail(ctx, m.id) }) }
    }
}

@Composable
private fun MailRow(m: Mail, onOpen: () -> Unit, onDelete: () -> Unit) {
    var expanded by remember { mutableStateOf(false) }
    Surface(onClick = { expanded = !expanded }, shape = MaterialTheme.shapes.large, color = MaterialTheme.colorScheme.surfaceContainerLow, border = appBorder(), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.Email, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(20.dp))
                Spacer(Modifier.width(8.dp))
                RawText(m.from, style = MaterialTheme.typography.titleSmall, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
                RawText(whenText(m.time), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            if (m.subject.isNotBlank()) RawText(m.subject, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold, maxLines = if (expanded) Int.MAX_VALUE else 2, overflow = TextOverflow.Ellipsis)
            val body = m.body.removePrefix(m.subject).trim()
            if (body.isNotBlank()) RawText(body, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = if (expanded) Int.MAX_VALUE else 3, overflow = TextOverflow.Ellipsis)
            if (m.account.isNotBlank()) RawText(m.account, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            if (expanded) Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                TextButton(onClick = onOpen) { Icon(Icons.AutoMirrored.Filled.OpenInNew, null, Modifier.size(18.dp)); Text("  Ouvrir") }
                TextButton(onClick = onDelete) { Icon(Icons.Filled.Delete, null, Modifier.size(18.dp)); Text("  Retirer") }
            }
        }
    }
}

@Composable
private fun MsgCard(content: @Composable () -> Unit) {
    Surface(shape = MaterialTheme.shapes.large, color = MaterialTheme.colorScheme.surfaceContainerLow, border = appBorder(), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) { content() }
    }
}
