package fr.jeremy.calepin.tiles

import android.app.PendingIntent
import android.content.Intent
import android.os.Build
import android.service.quicksettings.TileService
import fr.jeremy.calepin.MainActivity
import fr.jeremy.calepin.widgets.Widgets

/** Boutons du volet rapide (en glissant du haut de l'écran). */
abstract class OpenTile(private val what: String, private val code: Int) : TileService() {
    override fun onClick() {
        super.onClick()
        val i = Intent(this, MainActivity::class.java)
            .setAction("fr.jeremy.calepin.TILE.$what")
            .putExtra(Widgets.EXTRA_OPEN, what)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
        if (Build.VERSION.SDK_INT >= 34) {
            startActivityAndCollapse(PendingIntent.getActivity(this, code, i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT))
        } else {
            @Suppress("DEPRECATION")
            startActivityAndCollapse(i)
        }
    }
}

class NoteTile : OpenTile("new_note", 501)
class AssistantTile : OpenTile("assistant", 502)
