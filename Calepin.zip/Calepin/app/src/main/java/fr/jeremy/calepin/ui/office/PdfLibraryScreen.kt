package fr.jeremy.calepin.ui.office

import android.app.Activity
import android.graphics.Bitmap
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DriveFileMove
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.CreateNewFolder
import androidx.compose.material.icons.filled.FolderDelete
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.CallMerge
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.DriveFileRenameOutline
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.SaveAlt
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Email
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import fr.jeremy.calepin.Files
import fr.jeremy.calepin.LockGuard
import fr.jeremy.calepin.i18n.I18n
import fr.jeremy.calepin.i18n.RawText
import fr.jeremy.calepin.i18n.Text
import fr.jeremy.calepin.office.PdfEntry
import fr.jeremy.calepin.office.PdfLibrary
import fr.jeremy.calepin.office.PdfLocked
import fr.jeremy.calepin.ui.LinkCard
import fr.jeremy.calepin.ui.SubTitle
import fr.jeremy.calepin.ui.appBorder
import fr.jeremy.calepin.ui.tools.ToolHint
import fr.jeremy.calepin.ui.tools.ToolScaffold
import kotlinx.coroutines.launch
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.foundation.verticalScroll
import java.text.SimpleDateFormat
import java.util.Date

/** Bureau : les outils de documents (PDF pour commencer ; traitement de texte, tableur et présentations à venir). */
@Composable
fun OfficeScreen(onPdf: () -> Unit, onClose: () -> Unit) {
    ToolScaffold("Bureau", onClose) {
        LinkCard("PDF", Icons.Filled.PictureAsPdf, "Lire, chercher, annoter, signer, remplir, fusionner, photos en PDF", onPdf)
        ToolHint("Les documents restent dans Calepin (et dans la sauvegarde complète). Tu peux aussi ouvrir un PDF depuis une autre appli avec « Ouvrir avec Calepin ».")
    }
}

/** Bibliothèque de PDF : ouvrir, créer à partir de photos, fusionner, renommer, partager. */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun PdfLibraryScreen(onOpen: (String) -> Unit, onClose: () -> Unit) {
    val ctx = LocalContext.current
    val lib = remember { PdfLibrary.get(ctx) }
    val allItems by lib.items.collectAsStateWithLifecycle()
    val folders by lib.folders.collectAsStateWithLifecycle()
    var folder by androidx.compose.runtime.saveable.rememberSaveable { mutableStateOf("") }
    androidx.compose.runtime.SideEffect { lib.currentFolder = folder }
    val items = allItems.filter { it.folder == folder }
    var newFolder by remember { mutableStateOf(false) }
    var renamingFolder by remember { mutableStateOf<String?>(null) }
    var deletingFolder by remember { mutableStateOf<String?>(null) }
    var moving by remember { mutableStateOf<PdfEntry?>(null) }
    androidx.activity.compose.BackHandler(enabled = folder.isNotEmpty()) { folder = "" }
    val scope = rememberCoroutineScope()
    var busy by remember { mutableStateOf<String?>(null) }
    var locked by remember { mutableStateOf<Uri?>(null) }
    var pwd by remember { mutableStateOf("") }
    var merging by remember { mutableStateOf(false) }
    var selected by remember { mutableStateOf(setOf<String>()) }
    var renaming by remember { mutableStateOf<PdfEntry?>(null) }
    var deleting by remember { mutableStateOf<PdfEntry?>(null) }
    var saving by remember { mutableStateOf<PdfEntry?>(null) }
    var mailFile by remember { mutableStateOf<java.io.File?>(null) }
    var mailDraft by remember { mutableStateOf<fr.jeremy.calepin.ui.mail.MailDraft?>(null) }

    fun toast(t: String) = I18n.toast(ctx, t, Toast.LENGTH_LONG).show()

    fun importUri(u: Uri, password: String? = null) {
        busy = I18n.tr("Ouverture du PDF…")
        scope.launch {
            runCatching { lib.import(u, password) }
                .onSuccess { busy = null; locked = null; pwd = ""; onOpen(it.id) }
                .onFailure { e ->
                    busy = null
                    if (e is PdfLocked) { locked = u; if (password != null) toast("Mot de passe incorrect.") }
                    else toast(I18n.tr("Impossible d'ouvrir ce PDF :") + " " + (e.message ?: ""))
                }
        }
    }

    val openPdf = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u -> if (u != null) importUri(u) }
    val pickImages = rememberLauncherForActivityResult(ActivityResultContracts.PickMultipleVisualMedia(60)) { uris ->
        if (uris.isNotEmpty()) {
            busy = I18n.tr("Création du PDF…")
            scope.launch {
                val name = "Photos " + SimpleDateFormat(I18n.pattern("d MMM yyyy HH'h'mm"), I18n.locale).format(Date())
                runCatching { lib.fromImages(uris, name) }
                    .onSuccess { busy = null; onOpen(it.id) }
                    .onFailure { busy = null; toast(I18n.tr("Création impossible :") + " " + (it.message ?: "")) }
            }
        }
    }
    val saver = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { res ->
        val uri = res.data?.data
        val e = saving
        saving = null
        if (res.resultCode == Activity.RESULT_OK && uri != null && e != null) {
            val ok = Files.write(ctx, uri, lib.file(e.id).readBytes())
            toast(if (ok) "Fichier enregistré" else "Impossible d'écrire le fichier")
        }
    }

    ToolScaffold(if (folder.isEmpty()) "PDF" else "PDF · $folder", { if (folder.isNotEmpty()) folder = "" else onClose() }, actions = {
        if (folder.isNotEmpty()) {
            IconButton(onClick = { renamingFolder = folder }) { Icon(Icons.Filled.DriveFileRenameOutline, "Renommer le dossier") }
            IconButton(onClick = { deletingFolder = folder }) { Icon(Icons.Filled.FolderDelete, "Supprimer le dossier") }
        }
    }) {
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = { LockGuard.external(); openPdf.launch(arrayOf("application/pdf")) }) {
                Icon(Icons.Filled.FolderOpen, null, Modifier.size(18.dp)); Text("  Ouvrir un PDF")
            }
            OutlinedButton(onClick = {
                LockGuard.external()
                pickImages.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
            }) { Icon(Icons.Filled.AddPhotoAlternate, null, Modifier.size(18.dp)); Text("  Photos → PDF") }
            if (items.size >= 2) {
                OutlinedButton(onClick = { merging = !merging; selected = emptySet() }) {
                    Icon(Icons.Filled.CallMerge, null, Modifier.size(18.dp)); Text(if (merging) "  Annuler" else "  Fusionner")
                }
            }
        }
        // PDF téléchargés (navigateur, mails, applis) : ajoutés tout seuls dans « Téléchargements »
        if (folder.isEmpty()) {
            var auto by remember { mutableStateOf(fr.jeremy.calepin.office.PdfDownloads.enabled(ctx)) }
            var access by remember { mutableStateOf(fr.jeremy.calepin.tools.StorageAccess.granted(ctx)) }
            var showDownloads by remember { mutableStateOf(false) }
            LaunchedEffect(Unit) {
                // Accès donné pendant que l'écran est ouvert : la surveillance démarre aussitôt
                fr.jeremy.calepin.office.PdfDownloads.refresh(ctx)
                while (true) {
                    val now = fr.jeremy.calepin.tools.StorageAccess.granted(ctx)
                    if (now && !access) fr.jeremy.calepin.office.PdfDownloads.refresh(ctx)
                    access = now
                    kotlinx.coroutines.delay(3000)
                }
            }
            Surface(shape = MaterialTheme.shapes.large, color = MaterialTheme.colorScheme.surfaceContainerLow, border = appBorder(), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("Ajouter automatiquement les PDF téléchargés", style = MaterialTheme.typography.bodyLarge)
                            Text("Depuis internet, les mails ou une appli : rangés dans le dossier « Téléchargements »", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        androidx.compose.material3.Switch(auto, { auto = it; fr.jeremy.calepin.office.PdfDownloads.setEnabled(ctx, it) })
                    }
                    if (!access) TextButton(onClick = {
                        LockGuard.external()
                        runCatching { ctx.startActivity(fr.jeremy.calepin.tools.StorageAccess.settingsIntent(ctx).addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)) }
                    }) { Text("Autoriser l'accès aux fichiers (dossier Téléchargements)") }
                    else TextButton(onClick = { showDownloads = true }) { Icon(Icons.Filled.FolderOpen, null, Modifier.size(18.dp)); Text("  Choisir dans Téléchargements") }
                }
            }
            if (showDownloads) {
                val files = remember { fr.jeremy.calepin.office.PdfDownloads.list().take(40) }
                AlertDialog(
                    onDismissRequest = { showDownloads = false },
                    title = { Text("PDF du dossier Téléchargements") },
                    text = {
                        Column(Modifier.verticalScroll(androidx.compose.foundation.rememberScrollState()), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            if (files.isEmpty()) Text("Aucun PDF dans Téléchargements.")
                            files.forEach { f ->
                                Surface(onClick = {
                                    showDownloads = false
                                    busy = I18n.tr("Import…")
                                    scope.launch {
                                        runCatching { fr.jeremy.calepin.office.PdfDownloads.import(ctx, f) }
                                            .onSuccess { busy = null; onOpen(it.id) }
                                            .onFailure { busy = null; toast(I18n.tr("Échec :") + " " + (it.message ?: "")) }
                                    }
                                }, shape = MaterialTheme.shapes.medium, color = MaterialTheme.colorScheme.surfaceContainerHigh, modifier = Modifier.fillMaxWidth()) {
                                    Column(Modifier.padding(10.dp)) {
                                        RawText(f.name, style = MaterialTheme.typography.bodyMedium, maxLines = 2)
                                        RawText(SimpleDateFormat(I18n.pattern("d MMM yyyy HH'h'mm"), I18n.locale).format(Date(f.lastModified())), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }
                                }
                            }
                        }
                    },
                    confirmButton = {},
                    dismissButton = { TextButton(onClick = { showDownloads = false }) { Text("Fermer") } },
                )
            }
        }
        busy?.let { Column { RawText(it, style = MaterialTheme.typography.bodySmall); LinearProgressIndicator(Modifier.fillMaxWidth()) } }
        if (merging) {
            ToolHint("Coche les PDF à fusionner, dans l'ordre voulu : le premier coché sera au début.")
            Button(
                enabled = selected.size >= 2 && busy == null,
                onClick = {
                    busy = I18n.tr("Fusion…")
                    val order = selectionOrder.filter { it in selected }
                    scope.launch {
                        runCatching { lib.merge(order, I18n.tr("Fusion") + " " + SimpleDateFormat(I18n.pattern("d MMM HH'h'mm"), I18n.locale).format(Date())) }
                            .onSuccess { busy = null; merging = false; selected = emptySet(); onOpen(it.id) }
                            .onFailure { busy = null; toast(I18n.tr("Fusion impossible :") + " " + (it.message ?: "")) }
                    }
                },
            ) { Text(I18n.trf("Fusionner {0} PDF", selected.size)) }
        }
        // Dossiers (à l'accueil du bureau PDF)
        if (folder.isEmpty()) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                SubTitle("Dossiers")
                Spacer(Modifier.weight(1f))
                TextButton(onClick = { newFolder = true }) { Icon(Icons.Filled.CreateNewFolder, null, Modifier.size(18.dp)); Text("  Nouveau dossier") }
            }
            if (folders.isEmpty()) ToolHint("Crée des dossiers pour ranger tes PDF (factures, contrats, impôts…).")
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                folders.forEach { f ->
                    val n = allItems.count { it.folder == f }
                    Surface(
                        shape = MaterialTheme.shapes.medium, color = MaterialTheme.colorScheme.surfaceContainerHigh, border = appBorder(),
                        modifier = Modifier.clickable { folder = f; merging = false; selected = emptySet() },
                    ) {
                        Row(Modifier.padding(horizontal = 12.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Filled.Folder, null, tint = MaterialTheme.colorScheme.primary)
                            Spacer(Modifier.width(8.dp))
                            Column {
                                RawText(f, style = MaterialTheme.typography.titleSmall, maxLines = 1)
                                RawText(I18n.trf("{0} PDF", n), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }
                }
            }
        }
        if (items.isEmpty()) {
            Surface(shape = MaterialTheme.shapes.large, color = MaterialTheme.colorScheme.surfaceContainerLow, border = appBorder(), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("Aucun PDF pour l'instant.", style = MaterialTheme.typography.titleSmall)
                    ToolHint("Ouvre un PDF du téléphone (Téléchargements, Drive, pièce jointe…) ou transforme des photos en PDF : il est copié ici, avec tes annotations et signatures.")
                }
            }
        } else SubTitle(if (folder.isEmpty()) "Mes PDF" else "Dans ce dossier")
        items.forEach { e ->
            PdfRow(
                lib, e,
                selecting = merging,
                checked = e.id in selected,
                onClick = {
                    if (merging) {
                        selected = if (e.id in selected) selected - e.id else selected + e.id
                        if (e.id in selected) selectionOrder.add(e.id) else selectionOrder.remove(e.id)
                    } else onOpen(e.id)
                },
                onRename = { renaming = e },
                onShare = { scope.launch { Files.shareFile(ctx, lib.exportCopy(e.id), "application/pdf", e.name + ".pdf") } },
                onMail = { scope.launch { mailFile = lib.exportCopy(e.id) } },
                onCopy = {
                    scope.launch {
                        runCatching { lib.duplicate(e.id, e.name + " " + I18n.tr("(copie)")) }
                            .onSuccess { toast(I18n.tr("Copie créée.")) }
                            .onFailure { toast(I18n.tr("Échec :") + " " + (it.message ?: "")) }
                    }
                },
                onSave = { saving = e; LockGuard.external(); saver.launch(Files.createDocumentIntent(e.name + ".pdf", "application/pdf")) },
                onDelete = { deleting = e },
                onMove = { moving = e },
            )
        }
    }

    mailFile?.let { f ->
        fr.jeremy.calepin.ui.mail.SendByMailDialog(f, f.name, "application/pdf", onDismiss = { mailFile = null }, onCalepin = { mailDraft = it })
    }
    mailDraft?.let { d -> fr.jeremy.calepin.ui.mail.MailComposeDialog(d) { mailDraft = null } }
    locked?.let { u ->
        AlertDialog(
            onDismissRequest = { locked = null; pwd = "" },
            title = { Text("PDF protégé") },
            text = {
                OutlinedTextField(pwd, { pwd = it }, label = { Text("Mot de passe") }, singleLine = true, visualTransformation = PasswordVisualTransformation())
            },
            confirmButton = { TextButton(enabled = pwd.isNotEmpty(), onClick = { importUri(u, pwd) }) { Text("Ouvrir") } },
            dismissButton = { TextButton(onClick = { locked = null; pwd = "" }) { Text("Annuler") } },
        )
    }
    renaming?.let { e ->
        var name by remember(e.id) { mutableStateOf(e.name) }
        AlertDialog(
            onDismissRequest = { renaming = null },
            title = { Text("Renommer") },
            text = { OutlinedTextField(name, { name = it }, singleLine = true) },
            confirmButton = { TextButton(onClick = { lib.rename(e.id, name); renaming = null }) { Text("Enregistrer") } },
            dismissButton = { TextButton(onClick = { renaming = null }) { Text("Annuler") } },
        )
    }
    if (newFolder) {
        var name by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { newFolder = false },
            title = { Text("Nouveau dossier") },
            text = { OutlinedTextField(name, { name = it }, label = { Text("Nom du dossier") }, singleLine = true) },
            confirmButton = { TextButton(enabled = name.isNotBlank(), onClick = { lib.addFolder(name); newFolder = false }) { Text("Créer") } },
            dismissButton = { TextButton(onClick = { newFolder = false }) { Text("Annuler") } },
        )
    }
    renamingFolder?.let { f ->
        var name by remember(f) { mutableStateOf(f) }
        AlertDialog(
            onDismissRequest = { renamingFolder = null },
            title = { Text("Renommer le dossier") },
            text = { OutlinedTextField(name, { name = it }, singleLine = true) },
            confirmButton = { TextButton(enabled = name.isNotBlank(), onClick = { lib.renameFolder(f, name); folder = name.trim().replace("/", "-"); renamingFolder = null }) { Text("Enregistrer") } },
            dismissButton = { TextButton(onClick = { renamingFolder = null }) { Text("Annuler") } },
        )
    }
    deletingFolder?.let { f ->
        AlertDialog(
            onDismissRequest = { deletingFolder = null },
            title = { Text("Supprimer le dossier ?") },
            text = { Text("Les PDF qu'il contient ne sont pas effacés : ils reviennent à l'accueil du bureau PDF.") },
            confirmButton = { TextButton(onClick = { lib.deleteFolder(f); folder = ""; deletingFolder = null }) { Text("Supprimer le dossier") } },
            dismissButton = { TextButton(onClick = { deletingFolder = null }) { Text("Annuler") } },
        )
    }
    moving?.let { e ->
        var creating by remember(e.id) { mutableStateOf(false) }
        var name by remember(e.id) { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { moving = null },
            title = { Text("Ranger dans…") },
            text = {
                Column {
                    (listOf("") + folders).forEach { f ->
                        Row(
                            Modifier.fillMaxWidth().clickable { lib.move(e.id, f); moving = null }.padding(vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Icon(if (f.isEmpty()) Icons.Filled.Home else Icons.Filled.Folder, null, tint = MaterialTheme.colorScheme.primary)
                            Spacer(Modifier.width(10.dp))
                            if (f.isEmpty()) Text("Aucun dossier (accueil)") else RawText(f)
                            if (f == e.folder) RawText("  ✓", color = MaterialTheme.colorScheme.primary)
                        }
                    }
                    if (creating) {
                        OutlinedTextField(name, { name = it }, label = { Text("Nom du dossier") }, singleLine = true)
                    } else TextButton(onClick = { creating = true }) { Icon(Icons.Filled.CreateNewFolder, null, Modifier.size(18.dp)); Text("  Nouveau dossier") }
                }
            },
            confirmButton = {
                if (creating) TextButton(enabled = name.isNotBlank(), onClick = {
                    lib.addFolder(name); lib.move(e.id, name.trim().replace("/", "-")); moving = null
                }) { Text("Créer et ranger") } else TextButton(onClick = { moving = null }) { Text("Fermer") }
            },
        )
    }
    deleting?.let { e ->
        AlertDialog(
            onDismissRequest = { deleting = null },
            title = { Text("Supprimer ce PDF ?") },
            text = { RawText(e.name) },
            confirmButton = { TextButton(onClick = { lib.delete(e.id); deleting = null }) { Text("Supprimer", color = MaterialTheme.colorScheme.error) } },
            dismissButton = { TextButton(onClick = { deleting = null }) { Text("Annuler") } },
        )
    }
}

/** Ordre dans lequel les PDF ont été cochés pour la fusion. */
private val selectionOrder = mutableListOf<String>()

@Composable
private fun PdfRow(
    lib: PdfLibrary,
    e: PdfEntry,
    selecting: Boolean,
    checked: Boolean,
    onClick: () -> Unit,
    onRename: () -> Unit,
    onShare: () -> Unit,
    onSave: () -> Unit,
    onDelete: () -> Unit,
    onMove: () -> Unit = {},
    onMail: () -> Unit = {},
    onCopy: () -> Unit = {},
) {
    var menu by remember { mutableStateOf(false) }
    val thumb by produceState<Bitmap?>(null, e.id, e.opened) { value = lib.render(e.id, 0, 160) }
    Surface(shape = MaterialTheme.shapes.large, color = MaterialTheme.colorScheme.surfaceContainerLow, border = appBorder(), modifier = Modifier.fillMaxWidth()) {
        Row(Modifier.clickable(onClick = onClick).padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
            if (selecting) Checkbox(checked = checked, onCheckedChange = { onClick() })
            Box(Modifier.width(52.dp).height(68.dp).clip(RoundedCornerShape(6.dp)).background(Color.White), contentAlignment = Alignment.Center) {
                thumb?.let { Image(it.asImageBitmap(), null, contentScale = ContentScale.Crop) }
                    ?: Icon(Icons.Filled.PictureAsPdf, null, tint = MaterialTheme.colorScheme.primary)
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                RawText(e.name, style = MaterialTheme.typography.titleSmall, maxLines = 2)
                RawText(
                    I18n.trf("{0} page(s)", e.pages) + " · " + SimpleDateFormat(I18n.pattern("d MMM yyyy"), I18n.locale).format(Date(e.opened)),
                    style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            if (!selecting) Box {
                IconButton(onClick = { menu = true }) { Icon(Icons.Filled.MoreVert, "Plus d'actions") }
                DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                    DropdownMenuItem(text = { Text("Renommer") }, leadingIcon = { Icon(Icons.Filled.DriveFileRenameOutline, null) }, onClick = { menu = false; onRename() })
                    DropdownMenuItem(text = { Text("Envoyer par mail") }, leadingIcon = { Icon(Icons.Filled.Email, null) }, onClick = { menu = false; onMail() })
                    DropdownMenuItem(text = { Text("Faire une copie") }, leadingIcon = { Icon(Icons.Filled.ContentCopy, null) }, onClick = { menu = false; onCopy() })
                    DropdownMenuItem(text = { Text("Partager") }, leadingIcon = { Icon(Icons.Filled.Share, null) }, onClick = { menu = false; onShare() })
                    DropdownMenuItem(text = { Text("Enregistrer sous…") }, leadingIcon = { Icon(Icons.Filled.SaveAlt, null) }, onClick = { menu = false; onSave() })
                    DropdownMenuItem(text = { Text("Ranger dans un dossier") }, leadingIcon = { Icon(Icons.Filled.DriveFileMove, null) }, onClick = { menu = false; onMove() })
                    DropdownMenuItem(text = { Text("Supprimer", color = MaterialTheme.colorScheme.error) }, leadingIcon = { Icon(Icons.Filled.Delete, null, tint = MaterialTheme.colorScheme.error) }, onClick = { menu = false; onDelete() })
                }
            }
        }
    }
}

/** Ouvre un PDF reçu d'une autre appli (« Ouvrir avec Calepin ») : copie dans la bibliothèque. */
suspend fun importExternalPdf(ctx: android.content.Context, uri: Uri): String? =
    runCatching { PdfLibrary.get(ctx).import(uri).id }.getOrNull()

