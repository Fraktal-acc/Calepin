package fr.jeremy.calepin.ui.office

import android.graphics.Bitmap
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.consumeWindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.FormatAlignLeft
import androidx.compose.material.icons.automirrored.filled.FormatAlignRight
import androidx.compose.material.icons.automirrored.filled.FormatIndentDecrease
import androidx.compose.material.icons.automirrored.filled.FormatIndentIncrease
import androidx.compose.material.icons.automirrored.filled.FormatListBulleted
import androidx.compose.material.icons.automirrored.filled.Redo
import androidx.compose.material.icons.automirrored.filled.Undo
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.CheckBox
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.FindReplace
import androidx.compose.material.icons.filled.FormatAlignCenter
import androidx.compose.material.icons.filled.FormatBold
import androidx.compose.material.icons.filled.FormatClear
import androidx.compose.material.icons.filled.FormatColorFill
import androidx.compose.material.icons.filled.FormatColorText
import androidx.compose.material.icons.filled.FormatItalic
import androidx.compose.material.icons.filled.FormatListNumbered
import androidx.compose.material.icons.filled.FormatStrikethrough
import androidx.compose.material.icons.filled.FormatUnderlined
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.InsertPageBreak
import androidx.compose.material.icons.filled.Link
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.PhotoCamera
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.Print
import androidx.compose.material.icons.filled.QueryStats
import androidx.compose.material.icons.filled.SaveAlt
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.TableChart
import androidx.compose.material.icons.filled.Today
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.ZoomIn
import androidx.compose.material.icons.filled.ZoomOut
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.ParagraphStyle
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.OffsetMapping
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.input.TransformedText
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextIndent
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.em
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import fr.jeremy.calepin.Files
import fr.jeremy.calepin.LockGuard
import fr.jeremy.calepin.i18n.I18n
import fr.jeremy.calepin.i18n.RawText
import fr.jeremy.calepin.i18n.Text
import fr.jeremy.calepin.media.Media
import fr.jeremy.calepin.office.word.DocBlock
import fr.jeremy.calepin.office.word.PageSetup
import fr.jeremy.calepin.office.word.Paper
import fr.jeremy.calepin.office.word.WordDoc
import fr.jeremy.calepin.office.word.WordLibrary
import fr.jeremy.calepin.office.word.WordMarkup
import fr.jeremy.calepin.text.DisplayMap
import fr.jeremy.calepin.text.RichText
import fr.jeremy.calepin.ui.ColorSwatches
import fr.jeremy.calepin.ui.EditLayoutPlanner
import fr.jeremy.calepin.ui.FitText
import fr.jeremy.calepin.ui.HIGHLIGHT_COLORS
import fr.jeremy.calepin.ui.Markdown
import fr.jeremy.calepin.ui.RichStyle
import fr.jeremy.calepin.ui.TEXT_COLORS
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Couleurs de la page (le document reste blanc, comme sur papier, quel que soit le thème). */
private val PAPER = Color.White
private val INK = Color(0xFF1F1F1F)
private val HEADING = Color(0xFF2F5496)
private val WORD_BLUE = Color(0xFF2B579A)

/**
 * État de l'éditeur : le document (blocs) et le texte de chaque zone d'écriture (bloc de texte ou cellule
 * de tableau, clé « id » ou « id|ligne|colonne »), avec l'historique pour annuler et rétablir.
 */
private class DocState(initial: WordDoc) {
    var doc by mutableStateOf(initial.normalized())
    val fields = mutableStateMapOf<String, TextFieldValue>()
    var focused by mutableStateOf<String?>(null)
    /** Dernière cellule touchée de chaque tableau (pour ajouter une ligne ou une colonne au bon endroit). */
    val lastCell = HashMap<String, Pair<Int, Int>>()
    var version by mutableIntStateOf(0)
    /** Rechercher : mots cherchés (surlignés) et résultat en cours (zone, début). */
    var findQuery by mutableStateOf("")
    var findCurrent by mutableStateOf<Pair<String, Int>?>(null)
    private val history = ArrayList<WordDoc>()
    private var hIdx = -1
    var canUndo by mutableStateOf(false); private set
    var canRedo by mutableStateOf(false); private set
    private val requesters = HashMap<String, FocusRequester>()

    init { syncFields(); history += doc; hIdx = 0 }

    fun requester(key: String) = requesters.getOrPut(key) { FocusRequester() }

    fun cellKey(tid: String, r: Int, c: Int) = "$tid|$r|$c"

    /** Zones d'écriture remises en accord avec le document (valeurs gardées quand le texte n'a pas changé). */
    fun syncFields() {
        val keys = HashSet<String>()
        doc.blocks.forEach { b ->
            when (b) {
                is DocBlock.Text -> { keys += b.id; put(b.id, b.text) }
                is DocBlock.Table -> b.rows.forEachIndexed { r, row -> row.forEachIndexed { c, t -> val k = cellKey(b.id, r, c); keys += k; put(k, t) } }
                else -> {}
            }
        }
        fields.keys.filter { it !in keys }.forEach { fields.remove(it) }
    }

    private fun put(k: String, t: String) {
        val cur = fields[k]
        if (cur == null || cur.text != t) {
            val sel = cur?.selection?.let { TextRange(it.start.coerceIn(0, t.length), it.end.coerceIn(0, t.length)) } ?: TextRange(t.length)
            fields[k] = TextFieldValue(t, sel)
        }
    }

    /** Frappe dans une zone : le document suit. */
    fun setField(key: String, v: TextFieldValue) {
        val old = fields[key]
        fields[key] = v
        if (old?.text == v.text) return
        val parts = key.split('|')
        doc = if (parts.size == 3) {
            val (tid, r, c) = Triple(parts[0], parts[1].toInt(), parts[2].toInt())
            doc.copy(blocks = doc.blocks.map { b ->
                if (b is DocBlock.Table && b.id == tid) b.copy(rows = b.rows.mapIndexed { ri, row -> if (ri == r) row.mapIndexed { ci, cell -> if (ci == c) v.text else cell } else row }) else b
            })
        } else doc.copy(blocks = doc.blocks.map { b -> if (b is DocBlock.Text && b.id == key) b.copy(text = v.text) else b })
        version++
    }

    /** Changement de structure (tableau, image, saut de page, mise en page) : enregistré tout de suite dans l'historique. */
    fun applyDoc(d: WordDoc) {
        doc = d.normalized()
        syncFields()
        version++
        snapshot()
    }

    fun snapshot() {
        if (hIdx >= 0 && history[hIdx] == doc) return
        while (history.size > hIdx + 1) history.removeAt(history.lastIndex)
        history += doc
        if (history.size > 80) history.removeAt(0)
        hIdx = history.lastIndex
        canUndo = hIdx > 0; canRedo = false
    }

    fun undo() {
        // Frappe pas encore enregistrée dans l'historique : elle l'est d'abord (pour pouvoir la rétablir)
        snapshot()
        if (hIdx > 0) { hIdx--; restore() }
    }
    fun redo() { if (hIdx < history.lastIndex) { hIdx++; restore() } }
    private fun restore() {
        doc = history[hIdx]
        syncFields()
        version++
        canUndo = hIdx > 0; canRedo = hIdx < history.lastIndex
    }

    /** Coupe le bloc de texte [key] au curseur et place [block] entre les deux morceaux. */
    fun insert(block: DocBlock) {
        val key = focused
        val blocks = doc.blocks.toMutableList()
        val i = blocks.indexOfFirst { it is DocBlock.Text && it.id == key }
        if (i >= 0) {
            val t = blocks[i] as DocBlock.Text
            val f = fields[t.id] ?: TextFieldValue(t.text)
            val at = f.selection.min.coerceIn(0, t.text.length)
            var before = t.text.substring(0, at)
            var after = t.text.substring(at)
            if (before.endsWith("\n")) before = before.dropLast(1)
            if (after.startsWith("\n")) after = after.drop(1)
            blocks[i] = t.copy(text = before)
            blocks.add(i + 1, block)
            blocks.add(i + 2, DocBlock.Text(text = after))
        } else {
            // Curseur dans un tableau ou nulle part : après le tableau en cours, sinon à la fin
            val ti = key?.substringBefore('|')?.let { tid -> blocks.indexOfFirst { it.id == tid } } ?: -1
            if (ti >= 0) blocks.add(ti + 1, block) else blocks.add(block)
        }
        applyDoc(doc.copy(blocks = blocks))
    }

    fun remove(id: String) = applyDoc(doc.copy(blocks = doc.blocks.filterNot { it.id == id }))

    fun replace(b: DocBlock) = applyDoc(doc.copy(blocks = doc.blocks.map { if (it.id == b.id) b else it }))

    /** Déplace un objet (image, tableau) avant ou après le bloc de texte voisin. */
    fun move(id: String, delta: Int) {
        val l = doc.blocks.toMutableList()
        val i = l.indexOfFirst { it.id == id }
        val j = i + delta
        if (i < 0 || j !in l.indices) return
        val x = l.removeAt(i); l.add(j, x)
        applyDoc(doc.copy(blocks = l))
    }
}

/** Écran d'un document Word : chargement puis éditeur. */
@Composable
fun WordEditorScreen(id: String, onClose: () -> Unit) {
    val ctx = LocalContext.current
    val lib = remember { WordLibrary.get(ctx) }
    var doc by remember(id) { mutableStateOf<WordDoc?>(null) }
    var error by remember(id) { mutableStateOf<String?>(null) }
    LaunchedEffect(id) {
        runCatching { lib.open(id) }.onSuccess { doc = it }.onFailure { error = it.message ?: "Document illisible" }
    }
    val d = doc
    if (d == null) {
        BackHandler { onClose() }
        Box(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.surface), contentAlignment = Alignment.Center) {
            if (error != null) Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.padding(24.dp)) {
                Text("Impossible d'ouvrir ce document.", style = MaterialTheme.typography.titleMedium)
                RawText(error.orEmpty(), style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                TextButton(onClick = onClose) { Text("Retour") }
            } else CircularProgressIndicator()
        }
        return
    }
    WordEditor(id, d, onClose)
}

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
private fun WordEditor(id: String, initial: WordDoc, onClose: () -> Unit) {
    val ctx = LocalContext.current
    val lib = remember { WordLibrary.get(ctx) }
    val scope = rememberCoroutineScope()
    val st = remember(id) { DocState(initial) }
    val entry = lib.items.value.firstOrNull { it.id == id }
    var name by remember { mutableStateOf(entry?.name ?: "Document") }
    var readOnly by remember { mutableStateOf(false) }
    var zoom by remember { mutableStateOf(1f) }
    var menu by remember { mutableStateOf(false) }
    var renaming by remember { mutableStateOf(false) }
    var pageSetup by remember { mutableStateOf(false) }
    var stats by remember { mutableStateOf(false) }
    var finding by remember { mutableStateOf(false) }
    var warnings by remember { mutableStateOf(entry?.warnings.orEmpty()) }
    var busy by remember { mutableStateOf<String?>(null) }
    var selectedObj by remember { mutableStateOf<String?>(null) }
    var savedVersion by remember { mutableIntStateOf(0) }

    fun toast(t: String) = I18n.toast(ctx, t, Toast.LENGTH_SHORT).show()

    // Enregistrement automatique (le fichier .docx est réécrit)
    fun save(then: (() -> Unit)? = null) {
        val v = st.version
        val d = st.doc
        scope.launch(NonCancellable) {
            if (v != savedVersion) runCatching { lib.save(id, d) }.onSuccess { savedVersion = v }.onFailure { toast("Enregistrement impossible : " + (it.message ?: "erreur")) }
            then?.invoke()
        }
    }
    LaunchedEffect(st.version) {
        delay(700)
        st.snapshot()
        delay(1800)
        if (st.version != savedVersion) save()
    }
    val owner = LocalLifecycleOwner.current
    DisposableEffect(owner) {
        val obs = LifecycleEventObserver { _, e -> if (e == Lifecycle.Event.ON_STOP) save() }
        owner.lifecycle.addObserver(obs)
        onDispose { owner.lifecycle.removeObserver(obs) }
    }
    fun close() { save { scope.launch { onClose() } } }
    BackHandler { if (finding) finding = false else close() }

    // Images : galerie ou appareil photo
    var pendingPhoto by remember { mutableStateOf<File?>(null) }
    val gallery = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri: Uri? ->
        uri ?: return@rememberLauncherForActivityResult
        scope.launch { lib.addImage(id, uri)?.let { st.insert(DocBlock.Image(file = it, widthPct = 100)) } ?: toast("Image illisible") }
    }
    val camera = rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()) { ok ->
        val f = pendingPhoto; pendingPhoto = null
        if (f != null && ok && f.exists() && f.length() > 0) scope.launch {
            withContext(Dispatchers.IO) { lib.shrink(f) }
            st.insert(DocBlock.Image(file = f.name, widthPct = 100))
        } else f?.delete()
    }
    val saver = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { res ->
        val uri = res.data?.data
        if (res.resultCode == android.app.Activity.RESULT_OK && uri != null) scope.launch {
            lib.save(id, st.doc)
            val ok = withContext(Dispatchers.IO) { Files.write(ctx, uri, lib.file(id).readBytes()) }
            toast(if (ok) "Document enregistré" else "Impossible d'écrire le fichier")
        }
    }

    fun withPdf(label: String, action: (ByteArray) -> Unit) {
        busy = label
        scope.launch {
            runCatching { WordTools.pdf(ctx, id, st.doc, name) }
                .onSuccess { busy = null; action(it) }
                .onFailure { busy = null; toast("PDF impossible : " + (it.message ?: "erreur")) }
        }
    }

    // ------------------------------------------------------------------ Mise en forme de la zone en cours

    fun edit(f: (TextFieldValue) -> TextFieldValue) {
        val k = st.focused ?: run { toast("Touche d'abord le texte à mettre en forme."); return }
        val cur = st.fields[k] ?: return
        st.setField(k, f(cur))
        st.snapshot()
    }
    fun rich(kind: String, value: String?) = edit { f ->
        val a = f.selection.min.coerceIn(0, f.text.length); val b = f.selection.max.coerceIn(0, f.text.length)
        val e = when (kind) {
            "u" -> RichText.toggleUnderline(f.text, a, b)
            "align" -> RichText.setAlign(f.text, a, b, value)
            else -> RichText.apply(f.text, a, b, kind, value)
        }
        TextFieldValue(e.text, if (a == b) TextRange(e.start) else TextRange(e.start, e.end))
    }
    fun lines(op: (String, Int, Int) -> WordMarkup.Edit) = edit { f ->
        val a = f.selection.min.coerceIn(0, f.text.length); val b = f.selection.max.coerceIn(0, f.text.length)
        val e = op(f.text, a, b)
        // Curseur gardé au même endroit du texte (décalé de ce qui a été ajouté devant)
        val delta = e.text.length - f.text.length
        if (a == b) TextFieldValue(e.text, TextRange((a + delta).coerceIn(e.start, e.end)))
        else TextFieldValue(e.text, TextRange(e.start, e.end))
    }

    var palette by remember { mutableStateOf<String?>(null) }
    var linking by remember { mutableStateOf(false) }
    var tableDialog by remember { mutableStateOf(false) }

    val cs = MaterialTheme.colorScheme
    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column(Modifier.clickable { renaming = true }) {
                        FitText(name, translate = false)
                        Text(if (st.version == savedVersion) "Enregistré" else "Modifié…", style = MaterialTheme.typography.labelSmall, color = cs.onSurfaceVariant)
                    }
                },
                navigationIcon = { IconButton(onClick = { close() }) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Retour") } },
                actions = {
                    if (!readOnly) {
                        IconButton(onClick = { st.undo() }, enabled = st.canUndo) { Icon(Icons.AutoMirrored.Filled.Undo, "Annuler") }
                        IconButton(onClick = { st.redo() }, enabled = st.canRedo) { Icon(Icons.AutoMirrored.Filled.Redo, "Rétablir") }
                    }
                    Box {
                        IconButton(onClick = { menu = true }) { Icon(Icons.Filled.MoreVert, "Plus d'options") }
                        DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                            DropdownMenuItem(text = { Text(if (readOnly) "Modifier" else "Lecture seule") }, leadingIcon = { Icon(if (readOnly) Icons.Filled.Edit else Icons.Filled.Visibility, null) }, onClick = { menu = false; readOnly = !readOnly })
                            DropdownMenuItem(text = { Text("Rechercher et remplacer") }, leadingIcon = { Icon(Icons.Filled.FindReplace, null) }, onClick = { menu = false; finding = true })
                            DropdownMenuItem(text = { Text("Mise en page") }, leadingIcon = { Icon(Icons.Filled.Settings, null) }, onClick = { menu = false; pageSetup = true })
                            HorizontalDivider()
                            DropdownMenuItem(text = { Text("Partager (Word)") }, leadingIcon = { Icon(Icons.Filled.Share, null) }, onClick = {
                                menu = false
                                scope.launch { lib.save(id, st.doc); savedVersion = st.version; LockGuard.external(); Files.shareBytes(ctx, lib.file(id).readBytes(), WordTools.fileName(name, "docx"), DOCX_MIME) }
                            })
                            DropdownMenuItem(text = { Text("Partager en PDF") }, leadingIcon = { Icon(Icons.Filled.PictureAsPdf, null) }, onClick = {
                                menu = false
                                withPdf("Création du PDF…") { b -> LockGuard.external(); Files.shareBytes(ctx, b, WordTools.fileName(name, "pdf"), "application/pdf") }
                            })
                            DropdownMenuItem(text = { Text("Imprimer") }, leadingIcon = { Icon(Icons.Filled.Print, null) }, onClick = {
                                menu = false
                                withPdf("Préparation de l'impression…") { b -> LockGuard.external(); WordTools.print(ctx, name, b) }
                            })
                            DropdownMenuItem(text = { Text("Enregistrer sur le téléphone") }, leadingIcon = { Icon(Icons.Filled.SaveAlt, null) }, onClick = {
                                menu = false; LockGuard.external(); saver.launch(Files.createDocumentIntent(WordTools.fileName(name, "docx"), DOCX_MIME))
                            })
                            HorizontalDivider()
                            DropdownMenuItem(text = { Text("Statistiques") }, leadingIcon = { Icon(Icons.Filled.QueryStats, null) }, onClick = { menu = false; stats = true })
                            DropdownMenuItem(text = { Text("Agrandir l'affichage") }, leadingIcon = { Icon(Icons.Filled.ZoomIn, null) }, onClick = { zoom = (zoom + 0.15f).coerceAtMost(2f) })
                            DropdownMenuItem(text = { Text("Réduire l'affichage") }, leadingIcon = { Icon(Icons.Filled.ZoomOut, null) }, onClick = { zoom = (zoom - 0.15f).coerceAtLeast(0.7f) })
                        }
                    }
                },
            )
        },
    ) { pad ->
        Column(Modifier.fillMaxSize().padding(pad).consumeWindowInsets(pad).imePadding().background(cs.surfaceContainerHighest.copy(alpha = 0.6f))) {
            busy?.let {
                Row(Modifier.fillMaxWidth().background(cs.secondaryContainer).padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    CircularProgressIndicator(Modifier.size(16.dp), strokeWidth = 2.dp); Text("  $it", style = MaterialTheme.typography.bodySmall)
                }
            }
            if (finding) FindBar(st, onClose = { finding = false })
            // La page
            val page = st.doc.page
            val font = when { PageSetup.isMono(page.font) -> FontFamily.Monospace; PageSetup.isSerif(page.font) -> FontFamily.Serif; else -> FontFamily.SansSerif }
            val base = TextStyle(color = INK, fontSize = (page.sizePt * 1.32f * zoom).sp, fontFamily = font, lineHeight = 1.42.em)
            val query = st.findQuery to st.findCurrent
            Column(Modifier.weight(1f).fillMaxWidth().verticalScroll(rememberScrollState()).padding(horizontal = 8.dp, vertical = 10.dp)) {
                Surface(color = PAPER, shadowElevation = 3.dp, shape = RoundedCornerShape(3.dp), modifier = Modifier.fillMaxWidth().widthIn(max = 900.dp)) {
                    val margin = (page.marginMm * 0.9f).coerceIn(10f, 30f).dp
                    Column(Modifier.padding(horizontal = margin, vertical = margin + 4.dp)) {
                        if (page.header.isNotBlank()) {
                            RawText(page.header, style = MaterialTheme.typography.labelSmall, color = Color.Gray, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center)
                            Spacer(Modifier.height(10.dp))
                        }
                        st.doc.blocks.forEachIndexed { bi, b ->
                            when (b) {
                                is DocBlock.Text -> DocField(st, b.id, base, readOnly, query, bi == st.doc.blocks.lastIndex)
                                is DocBlock.Table -> TableView(st, b, base, readOnly, query, selected = selectedObj == b.id, onSelect = { selectedObj = if (selectedObj == b.id) null else b.id })
                                is DocBlock.Image -> ImageView(lib, id, st, b, readOnly, selected = selectedObj == b.id, onSelect = { selectedObj = if (selectedObj == b.id) null else b.id })
                                is DocBlock.PageBreak -> BreakView(readOnly) { st.remove(b.id) }
                            }
                        }
                        val footer = listOfNotNull(page.footer.takeIf { it.isNotBlank() }, if (page.pageNumbers) "n° de page" else null).joinToString(" · ")
                        if (footer.isNotEmpty()) {
                            Spacer(Modifier.height(16.dp))
                            RawText(footer, style = MaterialTheme.typography.labelSmall, color = Color.Gray, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center)
                        }
                    }
                }
                Spacer(Modifier.height(80.dp))
            }

            // Barre de mise en forme, juste au-dessus du clavier
            if (!readOnly) Surface(color = cs.surfaceContainer, tonalElevation = 3.dp) {
                val pal = palette
                Row(Modifier.fillMaxWidth().height(52.dp).horizontalScroll(rememberScrollState()).padding(horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                    if (pal != null) {
                        IconButton(onClick = { palette = null }) { Icon(Icons.Filled.Close, "Fermer les couleurs") }
                        val f = st.focused?.let { st.fields[it] }
                        val cur = f?.let { RichText.valueOver(it.text, it.selection.min.coerceIn(0, it.text.length), it.selection.max.coerceIn(0, it.text.length), pal) }
                        ColorSwatches(if (pal == "bg") HIGHLIGHT_COLORS else TEXT_COLORS, cur) { hex -> rich(pal, hex) }
                    } else {
                        StyleMenu { k -> lines { t, a, b -> WordMarkup.setStyle(t, a, b, k) } }
                        Tool(Icons.Filled.FormatBold, "Gras") { edit { Markdown.wrap(it, "**") } }
                        Tool(Icons.Filled.FormatItalic, "Italique") { edit { Markdown.wrap(it, "*") } }
                        Tool(Icons.Filled.FormatUnderlined, "Souligné") { rich("u", null) }
                        Tool(Icons.Filled.FormatStrikethrough, "Barré") { edit { Markdown.wrap(it, "~~") } }
                        Tool(Icons.Filled.FormatColorText, "Couleur du texte") { palette = "c" }
                        Tool(Icons.Filled.FormatColorFill, "Surlignage") { palette = "bg" }
                        AlignMenu { a -> rich("align", a) }
                        Tool(Icons.AutoMirrored.Filled.FormatListBulleted, "Liste à puces") { lines { t, a, b -> WordMarkup.toggleList(t, a, b, WordMarkup.Kind.BULLET) } }
                        Tool(Icons.Filled.FormatListNumbered, "Liste numérotée") { lines { t, a, b -> WordMarkup.toggleList(t, a, b, WordMarkup.Kind.NUMBER) } }
                        Tool(Icons.Filled.CheckBox, "Cases à cocher (toucher deux fois : cocher)") {
                            val f = st.focused?.let { st.fields[it] }
                            val line = f?.let { v -> WordMarkup.lineRange(v.text, v.selection.start, v.selection.start).let { (a, b) -> v.text.substring(a, b) } }
                            if (line != null && WordMarkup.parse(line).kind == WordMarkup.Kind.CHECK) lines { t, a, _ -> WordMarkup.toggleCheck(t, a) }
                            else lines { t, a, b -> WordMarkup.toggleList(t, a, b, WordMarkup.Kind.CHECK) }
                        }
                        Tool(Icons.AutoMirrored.Filled.FormatIndentDecrease, "Diminuer le retrait") { lines { t, a, b -> WordMarkup.indent(t, a, b, -1) } }
                        Tool(Icons.AutoMirrored.Filled.FormatIndentIncrease, "Augmenter le retrait") { lines { t, a, b -> WordMarkup.indent(t, a, b, 1) } }
                        InsertMenu(
                            onTable = { tableDialog = true },
                            onImage = { LockGuard.external(); gallery.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) },
                            onPhoto = {
                                val f = lib.newPhotoFile(id); pendingPhoto = f; LockGuard.external()
                                runCatching { camera.launch(Files.uriFor(ctx, f)) }.onFailure { pendingPhoto = null; toast("Aucun appareil photo disponible") }
                            },
                            onBreak = { st.insert(DocBlock.PageBreak()) },
                            onLink = { linking = true },
                            onDate = {
                                val d = SimpleDateFormat("EEEE d MMMM yyyy", Locale.FRANCE).format(Date())
                                edit { f ->
                                    val a = f.selection.min.coerceIn(0, f.text.length); val b = f.selection.max.coerceIn(0, f.text.length)
                                    TextFieldValue(f.text.substring(0, a) + d + f.text.substring(b), TextRange(a + d.length))
                                }
                            },
                        )
                        Tool(Icons.Filled.FormatClear, "Effacer la mise en forme") { lines { t, a, b -> WordMarkup.clearFormatting(t, a, b) } }
                    }
                }
            }
        }
    }

    if (renaming) RenameDialog(name, onDismiss = { renaming = false }) { n -> lib.rename(id, n); name = n; renaming = false; st.version++ }
    if (pageSetup) PageSetupDialog(st.doc.page, onDismiss = { pageSetup = false }) { p -> st.applyDoc(st.doc.copy(page = p)); pageSetup = false }
    if (stats) {
        val s = remember(st.doc) { st.doc.stats() }
        AlertDialog(
            onDismissRequest = { stats = false },
            title = { Text("Statistiques") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    StatLine("Mots", s.words)
                    StatLine("Caractères (espaces compris)", s.chars)
                    StatLine("Caractères (sans espaces)", s.charsNoSpaces)
                    StatLine("Paragraphes", s.paragraphs)
                    if (s.tables > 0) StatLine("Tableaux", s.tables)
                    if (s.images > 0) StatLine("Images", s.images)
                    Text(I18n.trf("Environ {0} page(s) et {1} min de lecture", ((s.words + 399) / 400).coerceAtLeast(1) + st.doc.blocks.count { it is DocBlock.PageBreak }, ((s.words + 229) / 230).coerceAtLeast(1)),
                        style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
                }
            },
            confirmButton = { TextButton(onClick = { stats = false }) { Text("Fermer") } },
        )
    }
    if (linking) LinkDialog(
        initialLabel = st.focused?.let { st.fields[it] }?.let { f -> f.text.substring(f.selection.min.coerceIn(0, f.text.length), f.selection.max.coerceIn(0, f.text.length)) }.orEmpty(),
        onDismiss = { linking = false },
    ) { label, url ->
        linking = false
        val u = Markdown.normalizeUrl(url) ?: run { toast("Adresse invalide"); return@LinkDialog }
        edit { Markdown.insertWebLink(it, label, u) }
    }
    if (tableDialog) TableSizeDialog(onDismiss = { tableDialog = false }) { r, c ->
        tableDialog = false
        st.insert(DocBlock.Table(rows = List(r) { List(c) { "" } }, header = true))
    }
    if (warnings.isNotEmpty()) AlertDialog(
        onDismissRequest = { warnings = emptyList(); lib.clearWarnings(id) },
        title = { Text("Document ouvert") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("Tout le texte est là. Quelques éléments de Word sont adaptés au téléphone :", style = MaterialTheme.typography.bodyMedium)
                warnings.forEach { RawText("• " + I18n.tr(it), style = MaterialTheme.typography.bodySmall) }
                Text("L'original n'est modifié que si tu changes quelque chose. Astuce : « Dupliquer » le document avant pour garder l'original intact.", style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
            }
        },
        confirmButton = { TextButton(onClick = { warnings = emptyList(); lib.clearWarnings(id) }) { Text("OK") } },
    )
}

@Composable
private fun StatLine(label: String, n: Int) {
    Row { Text(label, modifier = Modifier.weight(1f)); RawText("%,d".format(Locale.FRANCE, n), fontWeight = FontWeight.SemiBold) }
}

@Composable
private fun Tool(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, onClick: () -> Unit) {
    IconButton(onClick = onClick) { Icon(icon, label) }
}

@Composable
private fun StyleMenu(onPick: (WordMarkup.Kind) -> Unit) {
    var open by remember { mutableStateOf(false) }
    Box {
        TextButton(onClick = { open = true }) { Text("Style ▾", fontWeight = FontWeight.SemiBold) }
        DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
            listOf(
                WordMarkup.Kind.NORMAL to "Normal", WordMarkup.Kind.H1 to "Titre 1", WordMarkup.Kind.H2 to "Titre 2",
                WordMarkup.Kind.H3 to "Titre 3", WordMarkup.Kind.QUOTE to "Citation",
            ).forEach { (k, label) ->
                DropdownMenuItem(
                    text = {
                        Text(label, style = when (k) {
                            WordMarkup.Kind.H1 -> TextStyle(fontSize = 20.sp, fontWeight = FontWeight.Bold, color = HEADING)
                            WordMarkup.Kind.H2 -> TextStyle(fontSize = 17.sp, fontWeight = FontWeight.Bold, color = HEADING)
                            WordMarkup.Kind.H3 -> TextStyle(fontSize = 15.sp, fontWeight = FontWeight.Bold, color = HEADING)
                            WordMarkup.Kind.QUOTE -> TextStyle(fontStyle = FontStyle.Italic, color = Color.Gray)
                            else -> MaterialTheme.typography.bodyLarge
                        })
                    },
                    onClick = { open = false; onPick(k) },
                )
            }
        }
    }
}

@Composable
private fun AlignMenu(onPick: (String?) -> Unit) {
    var open by remember { mutableStateOf(false) }
    Box {
        IconButton(onClick = { open = true }) { Icon(Icons.AutoMirrored.Filled.FormatAlignLeft, "Alignement") }
        DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
            DropdownMenuItem(text = { Text("Aligner à gauche") }, leadingIcon = { Icon(Icons.AutoMirrored.Filled.FormatAlignLeft, null) }, onClick = { open = false; onPick(null) })
            DropdownMenuItem(text = { Text("Centrer") }, leadingIcon = { Icon(Icons.Filled.FormatAlignCenter, null) }, onClick = { open = false; onPick(RichText.CENTER) })
            DropdownMenuItem(text = { Text("Aligner à droite") }, leadingIcon = { Icon(Icons.AutoMirrored.Filled.FormatAlignRight, null) }, onClick = { open = false; onPick(RichText.RIGHT) })
        }
    }
}

@Composable
private fun InsertMenu(onTable: () -> Unit, onImage: () -> Unit, onPhoto: () -> Unit, onBreak: () -> Unit, onLink: () -> Unit, onDate: () -> Unit) {
    var open by remember { mutableStateOf(false) }
    Box {
        IconButton(onClick = { open = true }) { Icon(Icons.Filled.Add, "Insérer") }
        DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
            DropdownMenuItem(text = { Text("Tableau") }, leadingIcon = { Icon(Icons.Filled.TableChart, null) }, onClick = { open = false; onTable() })
            DropdownMenuItem(text = { Text("Image de la galerie") }, leadingIcon = { Icon(Icons.Filled.Image, null) }, onClick = { open = false; onImage() })
            DropdownMenuItem(text = { Text("Photo") }, leadingIcon = { Icon(Icons.Filled.PhotoCamera, null) }, onClick = { open = false; onPhoto() })
            DropdownMenuItem(text = { Text("Lien") }, leadingIcon = { Icon(Icons.Filled.Link, null) }, onClick = { open = false; onLink() })
            DropdownMenuItem(text = { Text("Date du jour") }, leadingIcon = { Icon(Icons.Filled.Today, null) }, onClick = { open = false; onDate() })
            DropdownMenuItem(text = { Text("Saut de page") }, leadingIcon = { Icon(Icons.Filled.InsertPageBreak, null) }, onClick = { open = false; onBreak() })
        }
    }
}

// ------------------------------------------------------------------ Zones d'écriture

@Composable
private fun DocField(st: DocState, key: String, base: TextStyle, readOnly: Boolean, query: Pair<String, Pair<String, Int>?>, last: Boolean, cell: Boolean = false, bold: Boolean = false) {
    val v = st.fields[key] ?: return
    val q = query.first
    val ranges = remember(v.text, q) { if (q.isBlank()) emptyList() else WordMarkup.find(v.text, q) }
    val cur = query.second?.takeIf { it.first == key }?.second ?: -1
    val transform = remember(ranges, cur) { DocVisual(ranges, ranges.indexOfFirst { it.first == cur }) }
    BasicTextField(
        value = v,
        onValueChange = { nv ->
            val old = v.text
            // Entrée dans une liste : élément suivant ; sinon l'alignement de la ligne continue
            val fix = if (nv.selection.collapsed) WordMarkup.afterEnter(old, nv.text, nv.selection.end) ?: RichText.afterEdit(old, nv.text, nv.selection.end) else null
            st.setField(key, if (fix != null) TextFieldValue(fix.first, TextRange(fix.second)) else nv)
        },
        readOnly = readOnly,
        textStyle = if (bold) base.copy(fontWeight = FontWeight.Bold) else base,
        cursorBrush = SolidColor(WORD_BLUE),
        visualTransformation = transform,
        modifier = Modifier
            .fillMaxWidth()
            .focusRequester(st.requester(key))
            .onFocusChanged { if (it.isFocused) { st.focused = key; key.split('|').takeIf { p -> p.size == 3 }?.let { p -> st.lastCell[p[0]] = p[1].toInt() to p[2].toInt() } } }
            .then(if (last && !cell) Modifier.heightIn(min = 160.dp) else Modifier),
        decorationBox = { inner ->
            Box {
                if (v.text.isEmpty() && last && !cell && !readOnly) Text("Écris ici…", style = base.copy(color = Color.LightGray))
                inner()
            }
        },
    )
}

/**
 * Affichage « comme dans Word » : signes de mise en forme cachés, titres, gras, couleurs, citations en
 * retrait, listes avec retrait suspendu, alignement, mots cherchés surlignés.
 */
private class DocVisual(private val search: List<IntRange>, private val current: Int) : VisualTransformation {
    override fun filter(text: AnnotatedString): TransformedText {
        val s = text.text
        val b = AnnotatedString.Builder(text)
        Markdown.styleInto(b, s, SpanStyle(color = Color.Gray), HEADING)
        RichStyle.spansInto(b, s, null)
        // Cases cochées : barrées et grisées ; numéros et cases en bleu
        var pos = 0
        val lines = s.split('\n')
        val quotes = ArrayList<DisplayMap.Hidden>()
        lines.forEach { l ->
            val p = WordMarkup.parse(l)
            when (p.kind) {
                WordMarkup.Kind.NUMBER, WordMarkup.Kind.CHECK -> b.addStyle(SpanStyle(color = WORD_BLUE, fontWeight = FontWeight.Bold), pos + l.length - l.trimStart().length, pos + p.prefix)
                WordMarkup.Kind.QUOTE -> {
                    quotes += DisplayMap.Hidden(pos, pos + p.prefix, true)
                    b.addStyle(SpanStyle(fontStyle = FontStyle.Italic, color = Color(0xFF555555)), pos + p.prefix, pos + l.length)
                }
                else -> {}
            }
            if (p.kind == WordMarkup.Kind.CHECK && p.done && l.length > p.prefix) b.addStyle(SpanStyle(textDecoration = TextDecoration.LineThrough, color = Color.Gray), pos + p.prefix, pos + l.length)
            pos += l.length + 1
        }
        search.forEachIndexed { i, r -> if (r.last < s.length) b.addStyle(SpanStyle(background = if (i == current) Color(0xFFFFB74D) else Color(0xFFFFF59D)), r.first, r.last + 1) }
        val styled = b.toAnnotatedString()
        val hidden = EditLayoutPlanner.hiddenSigns(s) + quotes
        val map = DisplayMap(s, hidden, emptyList())
        val out = AnnotatedString.Builder()
        if (map.isIdentity) out.append(styled) else map.pieces.forEach { pc ->
            when (pc) {
                is DisplayMap.Piece.Orig -> if (pc.end > pc.start) out.append(styled.subSequence(pc.start, pc.end))
                is DisplayMap.Piece.Added -> out.append(pc.text)
            }
        }
        // Paragraphes : alignement, retrait des citations, retrait suspendu des listes
        pos = 0
        lines.forEach { l ->
            val p = WordMarkup.parse(l)
            val align = WordMarkup.alignOf(l)
            val vs = map.toVisible(pos)
            val ve = map.toVisible(pos + l.length)
            val indent = when {
                p.kind == WordMarkup.Kind.QUOTE -> TextIndent(1.2.em, 1.2.em)
                WordMarkup.isList(p.kind) -> TextIndent(0.em, (p.prefix * 0.55f + 0.2f).em)
                else -> null
            }
            if (ve > vs && (align != null || indent != null)) {
                out.addStyle(ParagraphStyle(textAlign = when (align) { "center" -> TextAlign.Center; "right" -> TextAlign.End; else -> TextAlign.Unspecified }, textIndent = indent), vs, ve)
            }
            pos += l.length + 1
        }
        return TransformedText(out.toAnnotatedString(), if (map.isIdentity) OffsetMapping.Identity else object : OffsetMapping {
            override fun originalToTransformed(offset: Int) = map.toVisible(offset)
            override fun transformedToOriginal(offset: Int) = map.toOriginal(offset)
        })
    }

    override fun equals(other: Any?) = other is DocVisual && other.search == search && other.current == current
    override fun hashCode() = search.hashCode() * 31 + current
}

// ------------------------------------------------------------------ Tableaux, images, sauts de page

@Composable
private fun TableView(st: DocState, t: DocBlock.Table, base: TextStyle, readOnly: Boolean, query: Pair<String, Pair<String, Int>?>, selected: Boolean, onSelect: () -> Unit) {
    val cols = t.cols.coerceAtLeast(1)
    val line = Color(0xFFA6A6A6)
    val small = base.copy(fontSize = base.fontSize * 0.92f)
    val wide = cols > 3
    Column(Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
        if (!readOnly) Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
            Text("Tableau", style = MaterialTheme.typography.labelSmall, color = Color.Gray, modifier = Modifier.weight(1f).clickable { onSelect() })
            var open by remember { mutableStateOf(false) }
            Box {
                IconButton(onClick = { open = true }, modifier = Modifier.size(32.dp)) { Icon(Icons.Filled.MoreVert, "Options du tableau", tint = Color.Gray) }
                DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
                    val (r0, c0) = st.lastCell[t.id] ?: (t.rows.lastIndex to (cols - 1))
                    fun upd(rows: List<List<String>>, header: Boolean = t.header) { open = false; st.replace(t.copy(rows = rows, header = header)) }
                    DropdownMenuItem(text = { Text("Ajouter une ligne dessous") }, onClick = { upd(t.rows.toMutableList().apply { add((r0 + 1).coerceAtMost(size), List(cols) { "" }) }) })
                    DropdownMenuItem(text = { Text("Ajouter une ligne dessus") }, onClick = { upd(t.rows.toMutableList().apply { add(r0.coerceIn(0, size), List(cols) { "" }) }) })
                    DropdownMenuItem(text = { Text("Ajouter une colonne à droite") }, onClick = { upd(t.rows.map { r -> r.toMutableList().apply { add((c0 + 1).coerceAtMost(size), "") } }) })
                    DropdownMenuItem(text = { Text("Ajouter une colonne à gauche") }, onClick = { upd(t.rows.map { r -> r.toMutableList().apply { add(c0.coerceIn(0, size), "") } }) })
                    if (t.rows.size > 1) DropdownMenuItem(text = { Text("Supprimer la ligne") }, onClick = { upd(t.rows.filterIndexed { i, _ -> i != r0 }) })
                    if (cols > 1) DropdownMenuItem(text = { Text("Supprimer la colonne") }, onClick = { upd(t.rows.map { r -> r.filterIndexed { i, _ -> i != c0 } }) })
                    DropdownMenuItem(text = { Text(if (t.header) "Première ligne normale" else "Première ligne en en-tête") }, onClick = { upd(t.rows, !t.header) })
                    DropdownMenuItem(text = { Text("Monter") }, leadingIcon = { Icon(Icons.Filled.ArrowUpward, null) }, onClick = { open = false; st.move(t.id, -1) })
                    DropdownMenuItem(text = { Text("Descendre") }, leadingIcon = { Icon(Icons.Filled.ArrowDownward, null) }, onClick = { open = false; st.move(t.id, 1) })
                    DropdownMenuItem(text = { Text("Supprimer le tableau", color = MaterialTheme.colorScheme.error) }, leadingIcon = { Icon(Icons.Filled.Delete, null, tint = MaterialTheme.colorScheme.error) }, onClick = { open = false; st.remove(t.id) })
                }
            }
        }
        val scroll = rememberScrollState()
        Column(Modifier.then(if (wide) Modifier.horizontalScroll(scroll) else Modifier.fillMaxWidth()).border(BorderStroke(1.dp, line))) {
            t.rows.forEachIndexed { r, row ->
                val head = t.header && r == 0
                Row(Modifier.then(if (wide) Modifier else Modifier.fillMaxWidth()).height(IntrinsicSize.Min).background(if (head) Color(0xFFDEEAF6) else Color.Transparent)) {
                    for (c in 0 until cols) {
                        Box(
                            Modifier
                                .then(if (wide) Modifier.width(130.dp) else Modifier.weight(1f))
                                .fillMaxHeight()
                                .drawBehind {
                                    if (c > 0) drawLine(line, androidx.compose.ui.geometry.Offset(0f, 0f), androidx.compose.ui.geometry.Offset(0f, size.height), 1.dp.toPx())
                                    if (r > 0) drawLine(line, androidx.compose.ui.geometry.Offset(0f, 0f), androidx.compose.ui.geometry.Offset(size.width, 0f), 1.dp.toPx())
                                }
                                .padding(horizontal = 6.dp, vertical = 4.dp),
                        ) {
                            DocField(st, st.cellKey(t.id, r, c), small, readOnly, query, last = false, cell = true, bold = head)
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun ImageView(lib: WordLibrary, docId: String, st: DocState, b: DocBlock.Image, readOnly: Boolean, selected: Boolean, onSelect: () -> Unit) {
    val f = remember(b.file) { File(lib.mediaDir(docId), b.file) }
    val bmp by produceState<Bitmap?>(null, b.file) { value = withContext(Dispatchers.IO) { Media.thumbnail(f, false, 1400) } }
    Column(Modifier.fillMaxWidth().padding(vertical = 6.dp), horizontalAlignment = when (b.align) { "left" -> Alignment.Start; "right" -> Alignment.End; else -> Alignment.CenterHorizontally }) {
        Box(
            Modifier
                .fillMaxWidth(b.widthPct.coerceIn(10, 100) / 100f)
                .then(if (selected) Modifier.border(2.dp, WORD_BLUE) else Modifier)
                .clickable(enabled = !readOnly) { onSelect() },
        ) {
            val img = bmp
            if (img != null) Image(img.asImageBitmap(), "Image", Modifier.fillMaxWidth(), contentScale = ContentScale.FillWidth)
            else Box(Modifier.fillMaxWidth().height(120.dp).background(Color(0xFFEEEEEE)))
        }
        if (selected && !readOnly) {
            FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.padding(top = 4.dp)) {
                listOf(25, 50, 75, 100).forEach { p -> FilterChip(selected = b.widthPct == p, onClick = { st.replace(b.copy(widthPct = p)) }, label = { RawText("$p %") }) }
                FilterChip(selected = b.align == "left", onClick = { st.replace(b.copy(align = "left")) }, label = { Text("Gauche") })
                FilterChip(selected = b.align == "center", onClick = { st.replace(b.copy(align = "center")) }, label = { Text("Centre") })
                FilterChip(selected = b.align == "right", onClick = { st.replace(b.copy(align = "right")) }, label = { Text("Droite") })
                IconButton(onClick = { st.move(b.id, -1) }) { Icon(Icons.Filled.ArrowUpward, "Monter") }
                IconButton(onClick = { st.move(b.id, 1) }) { Icon(Icons.Filled.ArrowDownward, "Descendre") }
                IconButton(onClick = { st.remove(b.id) }) { Icon(Icons.Filled.Delete, "Supprimer l'image", tint = MaterialTheme.colorScheme.error) }
            }
        }
    }
}

@Composable
private fun BreakView(readOnly: Boolean, onDelete: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        val dash = PathEffect.dashPathEffect(floatArrayOf(10f, 8f))
        Box(Modifier.weight(1f).height(1.dp).drawBehind { drawLine(Color.Gray, androidx.compose.ui.geometry.Offset(0f, 0f), androidx.compose.ui.geometry.Offset(size.width, 0f), 2f, pathEffect = dash) })
        Text("  Saut de page  ", style = MaterialTheme.typography.labelSmall, color = Color.Gray)
        Box(Modifier.weight(1f).height(1.dp).drawBehind { drawLine(Color.Gray, androidx.compose.ui.geometry.Offset(0f, 0f), androidx.compose.ui.geometry.Offset(size.width, 0f), 2f, pathEffect = dash) })
        if (!readOnly) IconButton(onClick = onDelete, modifier = Modifier.size(28.dp)) { Icon(Icons.Filled.Close, "Supprimer le saut de page", tint = Color.Gray, modifier = Modifier.size(16.dp)) }
    }
}

// ------------------------------------------------------------------ Rechercher et remplacer

@Composable
private fun FindBar(st: DocState, onClose: () -> Unit) {
    var q by remember { mutableStateOf(st.findQuery) }
    var rep by remember { mutableStateOf("") }
    var idx by remember { mutableIntStateOf(0) }
    var tick by remember { mutableIntStateOf(0) }
    // Tous les résultats, dans l'ordre du document : (zone, début)
    val hits = remember(q, st.doc, tick) {
        val out = ArrayList<Pair<String, IntRange>>()
        if (q.isNotBlank()) st.doc.blocks.forEach { b ->
            when (b) {
                is DocBlock.Text -> WordMarkup.find(b.text, q).forEach { out += b.id to it }
                is DocBlock.Table -> b.rows.forEachIndexed { r, row -> row.forEachIndexed { c, cell -> WordMarkup.find(cell, q).forEach { out += st.cellKey(b.id, r, c) to it } } }
                else -> {}
            }
        }
        out
    }
    fun go(i: Int) {
        if (hits.isEmpty()) return
        idx = ((i % hits.size) + hits.size) % hits.size
        val (k, r) = hits[idx]
        st.findCurrent = k to r.first
        st.fields[k]?.let { st.fields[k] = it.copy(selection = TextRange(r.first, r.last + 1)) }
        runCatching { st.requester(k).requestFocus() }
    }
    LaunchedEffect(q) { st.findQuery = q; st.findCurrent = null; idx = 0 }
    DisposableEffect(Unit) { onDispose { st.findQuery = ""; st.findCurrent = null } }
    Surface(color = MaterialTheme.colorScheme.surfaceContainerHigh, tonalElevation = 2.dp) {
        Column(Modifier.fillMaxWidth().padding(8.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(q, { q = it }, placeholder = { Text("Rechercher") }, singleLine = true, modifier = Modifier.weight(1f))
                RawText(if (q.isBlank()) "" else if (hits.isEmpty()) "  0" else "  ${idx + 1}/${hits.size}", style = MaterialTheme.typography.labelMedium)
                IconButton(onClick = { go(idx - 1) }, enabled = hits.isNotEmpty()) { Icon(Icons.Filled.ArrowUpward, "Précédent") }
                IconButton(onClick = { go(idx + 1) }, enabled = hits.isNotEmpty()) { Icon(Icons.Filled.ArrowDownward, "Suivant") }
                IconButton(onClick = onClose) { Icon(Icons.Filled.Close, "Fermer") }
            }
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                OutlinedTextField(rep, { rep = it }, placeholder = { Text("Remplacer par") }, singleLine = true, modifier = Modifier.weight(1f))
                TextButton(enabled = hits.isNotEmpty(), onClick = {
                    val (k, r) = hits.getOrNull(idx) ?: return@TextButton
                    val f = st.fields[k] ?: return@TextButton
                    st.setField(k, TextFieldValue(f.text.replaceRange(r.first, r.last + 1, rep), TextRange(r.first + rep.length)))
                    st.snapshot(); tick++
                }) { Text("Remplacer") }
                TextButton(enabled = hits.isNotEmpty(), onClick = {
                    // Du dernier au premier : les positions des autres restent justes
                    var n = 0
                    hits.groupBy { it.first }.forEach { (k, l) ->
                        var t = st.fields[k]?.text ?: return@forEach
                        l.map { it.second }.sortedByDescending { it.first }.forEach { r -> t = t.replaceRange(r.first, r.last + 1, rep); n++ }
                        st.setField(k, TextFieldValue(t, TextRange(t.length)))
                    }
                    st.snapshot(); tick++
                    st.findCurrent = null
                }) { Text("Tout") }
            }
        }
    }
}

// ------------------------------------------------------------------ Dialogues

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun PageSetupDialog(initial: PageSetup, onDismiss: () -> Unit, onDone: (PageSetup) -> Unit) {
    var p by remember { mutableStateOf(initial) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Mise en page") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Format", style = MaterialTheme.typography.titleSmall)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Paper.entries.forEach { x -> FilterChip(selected = p.paper == x, onClick = { p = p.copy(paper = x) }, label = { Text(x.label) }) }
                    FilterChip(selected = !p.landscape, onClick = { p = p.copy(landscape = false) }, label = { Text("Portrait") })
                    FilterChip(selected = p.landscape, onClick = { p = p.copy(landscape = true) }, label = { Text("Paysage") })
                }
                Text("Marges", style = MaterialTheme.typography.titleSmall)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf(13 to "Étroites", 25 to "Normales", 35 to "Larges").forEach { (mm, l) -> FilterChip(selected = p.marginMm == mm, onClick = { p = p.copy(marginMm = mm) }, label = { Text(l) }) }
                }
                Text("Police du texte", style = MaterialTheme.typography.titleSmall)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    PageSetup.FONTS.forEach { f ->
                        FilterChip(selected = p.font == f, onClick = { p = p.copy(font = f) }, label = {
                            RawText(f, style = TextStyle(fontFamily = when { PageSetup.isMono(f) -> FontFamily.Monospace; PageSetup.isSerif(f) -> FontFamily.Serif; else -> FontFamily.SansSerif }))
                        })
                    }
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Taille", style = MaterialTheme.typography.titleSmall, modifier = Modifier.weight(1f))
                    IconButton(onClick = { p = p.copy(sizePt = (p.sizePt - 1).coerceAtLeast(8)) }) { Icon(Icons.Filled.ZoomOut, "Plus petit") }
                    RawText("${p.sizePt} pt", fontWeight = FontWeight.SemiBold)
                    IconButton(onClick = { p = p.copy(sizePt = (p.sizePt + 1).coerceAtMost(24)) }) { Icon(Icons.Filled.ZoomIn, "Plus grand") }
                }
                OutlinedTextField(p.header, { p = p.copy(header = it) }, label = { Text("En-tête (en haut de chaque page)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(p.footer, { p = p.copy(footer = it) }, label = { Text("Pied de page") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Numéros de page", modifier = Modifier.weight(1f))
                    Switch(checked = p.pageNumbers, onCheckedChange = { p = p.copy(pageNumbers = it) })
                }
            }
        },
        confirmButton = { TextButton(onClick = { onDone(p) }) { Text("OK") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Annuler") } },
    )
}

@Composable
private fun LinkDialog(initialLabel: String, onDismiss: () -> Unit, onDone: (String, String) -> Unit) {
    var label by remember { mutableStateOf(RichText.strip(initialLabel)) }
    var url by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Lien") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(label, { label = it }, label = { Text("Texte affiché") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(url, { url = it }, label = { Text("Adresse (site, e-mail ou téléphone)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            }
        },
        confirmButton = { TextButton(enabled = url.isNotBlank(), onClick = { onDone(label, url) }) { Text("Insérer") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Annuler") } },
    )
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun TableSizeDialog(onDismiss: () -> Unit, onDone: (Int, Int) -> Unit) {
    var rows by remember { mutableIntStateOf(3) }
    var cols by remember { mutableIntStateOf(3) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Insérer un tableau") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Lignes", modifier = Modifier.weight(1f))
                    IconButton(onClick = { rows = (rows - 1).coerceAtLeast(1) }) { Text("−") }
                    RawText("$rows", fontWeight = FontWeight.SemiBold)
                    IconButton(onClick = { rows = (rows + 1).coerceAtMost(40) }) { Text("+") }
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Colonnes", modifier = Modifier.weight(1f))
                    IconButton(onClick = { cols = (cols - 1).coerceAtLeast(1) }) { Text("−") }
                    RawText("$cols", fontWeight = FontWeight.SemiBold)
                    IconButton(onClick = { cols = (cols + 1).coerceAtMost(8) }) { Text("+") }
                }
                // Aperçu
                Column(Modifier.border(1.dp, Color.Gray)) {
                    repeat(rows.coerceAtMost(6)) { r ->
                        Row { repeat(cols) { Box(Modifier.size(width = 26.dp, height = 14.dp).border(0.5.dp, Color.Gray).background(if (r == 0) Color(0xFFDEEAF6) else Color.Transparent)) } }
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = { onDone(rows, cols) }) { Text("Insérer") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Annuler") } },
    )
}
