package fr.jeremy.calepin.market

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import org.json.JSONArray
import org.json.JSONObject
import java.util.Calendar
import java.util.Locale
import java.util.concurrent.atomic.AtomicInteger

/**
 * Détecteur d'opportunités du robot de bourse : passe des listes d'instruments au crible (cours sur deux ans,
 * analyse complète avec contrôle sur l'historique, tendance hebdomadaire), puis approfondit les meilleurs
 * (actualités du web, climat des marchés, force relative…) et les classe par potentiel d'achat.
 * Avec le robot en marche, la recherche peut se faire toute seule une fois par jour et prévenir des meilleures.
 */
object OpportunityScanner {
    private const val PREFS = "market_scan"
    const val SIGNAL_NAME = "Opportunité d'achat"

    data class Progress(val done: Int, val total: Int, val step: String)

    private val _results = MutableStateFlow<List<Opportunity>>(emptyList())
    val results: StateFlow<List<Opportunity>> = _results
    private val _progress = MutableStateFlow<Progress?>(null)
    val progress: StateFlow<Progress?> = _progress
    private val _lastScan = MutableStateFlow(0L)
    val lastScan: StateFlow<Long> = _lastScan
    private val _lists = MutableStateFlow(setOf(Opportunities.WATCH, "cac40", "us"))
    val lists: StateFlow<Set<String>> = _lists
    private val _auto = MutableStateFlow(false)
    val auto: StateFlow<Boolean> = _auto
    /** Note à partir de laquelle le robot prévient (recherche automatique). */
    private val _threshold = MutableStateFlow(65)
    val threshold: StateFlow<Int> = _threshold
    private val _failed = MutableStateFlow(0)
    /** Instruments qui n'ont pas pu être lus lors de la dernière recherche. */
    val failed: StateFlow<Int> = _failed

    private val lock = Mutex()
    @Volatile private var loaded = false

    private fun p(ctx: Context): SharedPreferences = ctx.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun init(ctx: Context) {
        if (loaded) return
        synchronized(this) {
            if (loaded) return
            val p = p(ctx)
            p.getString("lists", null)?.split(',')?.filter { it.isNotBlank() }?.toSet()?.takeIf { it.isNotEmpty() }?.let { _lists.value = it }
            _auto.value = p.getBoolean("auto", false)
            _threshold.value = p.getInt("threshold", 65)
            _lastScan.value = p.getLong("last", 0L)
            _results.value = runCatching { parse(JSONArray(p.getString("results", "[]"))) }.getOrDefault(emptyList())
            loaded = true
        }
    }

    fun setLists(ctx: Context, ids: Set<String>) {
        _lists.value = ids
        p(ctx).edit().putString("lists", ids.joinToString(",")).apply()
    }

    fun setAuto(ctx: Context, on: Boolean) {
        _auto.value = on
        p(ctx).edit().putBoolean("auto", on).apply()
        Market.schedule(ctx)
    }

    fun setThreshold(ctx: Context, v: Int) {
        _threshold.value = v.coerceIn(40, 90)
        p(ctx).edit().putInt("threshold", _threshold.value).apply()
    }

    /** Recherche automatique voulue (pour garder le robot programmé même sans règle). */
    fun autoOn(ctx: Context): Boolean { init(ctx); return _auto.value }

    /**
     * Passe au crible les listes [ids]. [deep] : les meilleurs sont revus avec les actualités et le contexte
     * de marché (plus précis, un peu plus long). Renvoie le classement (aussi gardé dans [results]).
     */
    suspend fun scan(ctx: Context, ids: Set<String> = _lists.value, deep: Boolean = true): List<Opportunity> {
        init(ctx)
        Market.init(ctx)
        if (!lock.tryLock()) return _results.value
        try {
            _progress.value = Progress(0, 0, "Préparation de la liste…")
            val trending = if (Opportunities.TRENDING in ids) coroutineScope {
                listOf("day_gainers" to 15, "most_actives" to 15, "undervalued_growth_stocks" to 10, "growth_technology_stocks" to 10)
                    .map { (id, n) -> async(Dispatchers.IO) { runCatching { MarketData.screener(id, n) }.getOrDefault(emptyList()) } }
                    .awaitAll().flatten()
            } else emptyList()
            val insts = Opportunities.instruments(ids, Market.watch.value, trending)
            val now = System.currentTimeMillis()
            // Signaux d'achat des règles du robot (3 derniers jours) : un bonus pour ces instruments
            val robot = Market.signals.value
                .filter { it.action == Action.BUY && now - it.t < 3 * 86_400_000L }
                .associate { it.symbol to it.ruleName }
            val done = AtomicInteger(0)
            val failed = AtomicInteger(0)
            val total = insts.size
            _progress.value = Progress(0, total, "Analyse des cours…")
            val sem = Semaphore(6)
            // 1. Analyse technique de chaque instrument (cours quotidiens sur deux ans)
            val first = coroutineScope {
                insts.map { inst ->
                    async(Dispatchers.IO) {
                        sem.withPermit {
                            val r = runCatching {
                                val s = MarketData.series(inst.symbol, Timeframe.D1)
                                val c = s.candles
                                if (c.size < 60) null else {
                                    val weekly = Indicators.aggregate(c, 7 * 86_400L)
                                    val named = if (inst.name.isBlank() || inst.name == inst.symbol) inst.copy(name = s.name) else inst
                                    Analyzer(c).analyze(weekly, withBacktest = true)?.let { an ->
                                        Opportunities.from(named, s.price, s.currency, an, now, robot[inst.symbol])?.let { o -> Triple(o, s, named) }
                                    }
                                }
                            }.onFailure { failed.incrementAndGet() }.getOrNull()
                            val n = done.incrementAndGet()
                            _progress.value = Progress(n, total, inst.name.ifBlank { inst.symbol })
                            r
                        }
                    }
                }.awaitAll().filterNotNull()
            }
            // 2. Les plus prometteurs revus avec les actualités du web et le contexte de marché
            val best = first.sortedByDescending { it.first.potential }
            val deepCount = if (deep) minOf(12, best.size) else 0
            val refined = if (deepCount == 0) best.map { it.first } else {
                _progress.value = Progress(0, deepCount, "Actualités et contexte des meilleurs…")
                val d2 = AtomicInteger(0)
                val top = coroutineScope {
                    best.take(deepCount).map { (o, s, inst) ->
                        async(Dispatchers.IO) {
                            sem.withPermit {
                                val extra = ArrayList<Factor>()
                                runCatching { News.forInstrument(inst.symbol, inst.name) }.getOrNull()?.let { News.factor(it)?.let { f -> extra += f } }
                                extra += runCatching { MarketContext.factors(inst.symbol, inst.type, s.candles) }.getOrDefault(emptyList())
                                val weekly = Indicators.aggregate(s.candles, 7 * 86_400L)
                                val again = if (extra.isEmpty()) o else runCatching {
                                    Analyzer(s.candles).analyze(weekly, withBacktest = true, extra = extra)?.let { an ->
                                        Opportunities.from(inst, s.price, s.currency, an, now, robot[inst.symbol])
                                    }
                                }.getOrElse { o }
                                _progress.value = Progress(d2.incrementAndGet(), deepCount, inst.name)
                                // Une mauvaise nouvelle peut faire sortir l'instrument du classement
                                again
                            }
                        }
                    }.awaitAll().filterNotNull()
                }
                top + best.drop(deepCount).map { it.first }
            }
            val ranked = Opportunities.rank(refined).take(40)
            _results.value = ranked
            _lastScan.value = now
            _failed.value = failed.get()
            p(ctx).edit().putLong("last", now).putString("results", toJson(ranked).toString()).apply()
            return ranked
        } finally {
            _progress.value = null
            lock.unlock()
        }
    }

    /**
     * Appelée par le robot à chaque vérification : une recherche par jour au plus (en journée), puis une
     * notification pour les nouvelles opportunités au-dessus du seuil (pas deux fois la même en 3 jours).
     */
    fun autoIfDue(ctx: Context) {
        init(ctx)
        if (!_auto.value) return
        val now = System.currentTimeMillis()
        if (now - _lastScan.value < 20 * 3_600_000L) return
        val hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        if (hour !in 8..21) return
        // La recherche peut durer plus d'une minute : faite dans une tâche Android à part
        val js = ctx.getSystemService(android.app.job.JobScheduler::class.java) ?: return
        if (js.allPendingJobs.any { it.id == JOB_ID }) return
        runCatching {
            js.schedule(
                android.app.job.JobInfo.Builder(JOB_ID, android.content.ComponentName(ctx, OpportunityJob::class.java))
                    .setRequiredNetworkType(android.app.job.JobInfo.NETWORK_TYPE_ANY)
                    .setOverrideDeadline(30 * 60_000L)
                    .build()
            )
        }
    }

    const val JOB_ID = 7310

    /** Recherche quotidienne puis notification des meilleures opportunités (dans [OpportunityJob]). */
    fun runDaily(ctx: Context) {
        init(ctx)
        val now = System.currentTimeMillis()
        if (now - _lastScan.value < 20 * 3_600_000L) return
        val found = runBlocking { scan(ctx) }
        val p = p(ctx)
        val fresh = found.filter { it.potential >= _threshold.value }.filter { o ->
            val last = p.getLong("sent_${o.symbol}", 0L)
            now - last > 3 * 86_400_000L
        }.take(3)
        fresh.forEach { o ->
            p.edit().putLong("sent_${o.symbol}", now).apply()
            Market.publish(ctx, Signal(now, SIGNAL_NAME, o.symbol, o.name, Action.ALERT, o.price, o.currency, summary(o)))
        }
    }

    private fun f(x: Double, d: Int = 1) = String.format(Locale.FRANCE, "%.${d}f", x)

    /** Résumé d'une ligne (journal des signaux, notification). */
    fun summary(o: Opportunity): String = buildString {
        append("Potentiel ").append(o.potential.toInt()).append("/100")
        if (!o.upside.isNaN()) append(" · objectif +").append(f(o.upside)).append(" %")
        if (!o.downside.isNaN()) append(", stop -").append(f(o.downside)).append(" %")
        if (!o.winRate.isNaN()) append(" · réussite passée ").append(o.winRate.toInt()).append(" %")
        o.reasons.firstOrNull()?.let { append(" · ").append(it.take(90)) }
    }

    private fun toJson(l: List<Opportunity>) = JSONArray().apply {
        l.forEach { o ->
            put(JSONObject()
                .put("s", o.symbol).put("n", o.name).put("ty", o.type).put("p", o.price).put("c", o.currency)
                .put("sc", o.score).put("cf", o.confidence).put("po", o.potential)
                .put("up", if (o.upside.isNaN()) JSONObject.NULL else o.upside)
                .put("dn", if (o.downside.isNaN()) JSONObject.NULL else o.downside)
                .put("rr", o.rr).put("wr", if (o.winRate.isNaN()) JSONObject.NULL else o.winRate)
                .put("v", o.verdict).put("st", o.stop).put("tg", o.target)
                .put("re", JSONArray(o.reasons)).put("ri", JSONArray(o.risks)).put("t", o.time))
        }
    }

    private fun parse(a: JSONArray): List<Opportunity> = (0 until a.length()).mapNotNull { k ->
        val o = a.optJSONObject(k) ?: return@mapNotNull null
        fun list(n: String) = o.optJSONArray(n)?.let { arr -> (0 until arr.length()).map { arr.optString(it) } }.orEmpty()
        fun num(n: String) = if (o.isNull(n)) Double.NaN else o.optDouble(n, Double.NaN)
        Opportunity(
            symbol = o.optString("s"), name = o.optString("n"), type = o.optString("ty"), price = o.optDouble("p"), currency = o.optString("c"),
            score = o.optDouble("sc"), confidence = o.optDouble("cf"), potential = o.optDouble("po"),
            upside = num("up"), downside = num("dn"), rr = o.optDouble("rr"), winRate = num("wr"),
            verdict = o.optString("v"), stop = o.optDouble("st"), target = o.optDouble("tg"),
            reasons = list("re"), risks = list("ri"), time = o.optLong("t"),
        ).takeIf { it.symbol.isNotBlank() }
    }
}

/** Tâche Android de la recherche quotidienne d'opportunités. */
class OpportunityJob : android.app.job.JobService() {
    override fun onStartJob(params: android.app.job.JobParameters): Boolean {
        Thread {
            runCatching { OpportunityScanner.runDaily(applicationContext) }
            jobFinished(params, false)
        }.start()
        return true
    }

    override fun onStopJob(params: android.app.job.JobParameters): Boolean = false
}
