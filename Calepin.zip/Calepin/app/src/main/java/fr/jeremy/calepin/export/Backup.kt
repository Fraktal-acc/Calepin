package fr.jeremy.calepin.export

import fr.jeremy.calepin.data.Note
import org.json.JSONObject

/** Lecture d'une sauvegarde JSON créée par Calepin. */
object Backup {
    fun parse(text: String): List<Note> {
        val root = JSONObject(text)
        val arr = root.optJSONArray("notes") ?: throw IllegalArgumentException("Ce fichier n'est pas une sauvegarde Calepin")
        return (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            val now = System.currentTimeMillis()
            Note(
                title = o.optString("title"),
                content = o.optString("content"),
                tag = o.optString("tag"),
                pinned = o.optBoolean("pinned"),
                folder = o.optString("folder"),
                createdAt = o.optLong("createdAt", now),
                updatedAt = o.optLong("updatedAt", now),
            )
        }
    }
}
