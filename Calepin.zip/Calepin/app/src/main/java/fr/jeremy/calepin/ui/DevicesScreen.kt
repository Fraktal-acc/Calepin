package fr.jeremy.calepin.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.StarBorder
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import fr.jeremy.calepin.control.AndroidTvRemote
import fr.jeremy.calepin.control.DeviceStore
import fr.jeremy.calepin.control.Discovery
import fr.jeremy.calepin.control.FoundDevice
import fr.jeremy.calepin.control.HomeDevice
import fr.jeremy.calepin.control.Kind
import fr.jeremy.calepin.control.LgTv
import fr.jeremy.calepin.control.Role
import fr.jeremy.calepin.control.SamsungTv
import fr.jeremy.calepin.control.SmartHome
import fr.jeremy.calepin.control.Target
import fr.jeremy.calepin.control.TvDrivers
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject

/** Appareils de la maison : recherche sur le Wi-Fi, ajout, essai, appareil par défaut. */
@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun DevicesScreen(onClose: () -> Unit) {
    val ctx = LocalContext.current
    val store = remember { DeviceStore(ctx) }
    val scope = rememberCoroutineScope()
    var version by remember { mutableIntStateOf(0) }
    val devices = remember(version) { store.all() }
    var progress by remember { mutableStateOf<Int?>(null) }
    var progressText by remember { mutableStateOf("") }
    var found by remember { mutableStateOf<List<FoundDevice>?>(null) }
    var adding by remember { mutableStateOf<FoundDevice?>(null) }
    var choosingKind by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf<String?>(null) }
    var confirmDelete by remember { mutableStateOf<HomeDevice?>(null) }

    BackHandler { onClose() }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Appareils de la maison") },
                navigationIcon = { IconButton(onClick = onClose) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Retour") } },
                actions = { IconButton(onClick = { choosingKind = true }) { Icon(Icons.Filled.Add, "Ajouter à la main") } },
            )
        },
    ) { pad ->
        Column(
            Modifier
                .fillMaxSize()
                .padding(pad)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp)
                .padding(bottom = 40.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Text(
                "Télés, décodeurs, lumières, prises et centrales domotiques du Wi-Fi de la maison. Une fois ajoutés, " +
                    "commande-les à la voix depuis l'assistant : « allume la télé », « éteins la lampe du salon »…",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )

            if (progress != null) {
                LinearProgressIndicator(progress = { (progress ?: 0) / 100f }, modifier = Modifier.fillMaxWidth())
                Text(progressText, style = MaterialTheme.typography.bodySmall)
            } else {
                Button(onClick = {
                    progress = 0
                    status = null
                    scope.launch {
                        found = runCatching { Discovery.scan(ctx) { p, t -> progress = p; progressText = t } }.getOrDefault(emptyList())
                        if (fr.jeremy.calepin.control.LanScanner.localIp() == null) status = "Le téléphone n'est pas connecté à un Wi-Fi."
                        progress = null
                    }
                }, modifier = Modifier.fillMaxWidth()) { Text("Rechercher les appareils sur le Wi-Fi") }
            }
            status?.let { Text(it, color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.bodyMedium) }

            found?.let { list ->
                Text("Trouvés sur le réseau (${list.size})", style = MaterialTheme.typography.titleSmall)
                if (list.isEmpty()) {
                    Text(
                        "Rien trouvé. Vérifie que les appareils sont allumés et sur le même Wi-Fi, ou ajoute-les à la main avec « + ».",
                        style = MaterialTheme.typography.bodySmall,
                    )
                }
                list.forEach { f ->
                    val already = devices.any { it.host == f.host && it.kind == f.kind }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(f.label, style = MaterialTheme.typography.bodyLarge)
                            Text(
                                listOfNotNull(f.kind?.label ?: "Non pilotable par Calepin IA", f.host, f.details.takeIf { it.isNotBlank() && it != f.label })
                                    .joinToString(" · "),
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                        when {
                            already -> Text("Ajouté", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
                            f.kind != null -> TextButton(onClick = { adding = f }) { Text("Ajouter") }
                        }
                    }
                }
                HorizontalDivider()
            }

            Text("Mes appareils (${devices.size})", style = MaterialTheme.typography.titleSmall)
            if (devices.isEmpty()) {
                Text("Aucun pour l'instant : lance une recherche ou touche « + ».", style = MaterialTheme.typography.bodySmall)
            }
            devices.forEach { d ->
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLow), modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(d.name, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                                Text("${d.kind.label} · ${d.role.label} · ${d.host}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            if (d.role == Role.TV || d.role == Role.DECODER) {
                                val isDefault = store.defaultFor(d.role)?.id == d.id
                                IconButton(onClick = { store.setDefault(d); version++ }) {
                                    Icon(if (isDefault) Icons.Filled.Star else Icons.Filled.StarBorder, if (isDefault) "Appareil par défaut" else "Choisir par défaut")
                                }
                            }
                        }
                        val subs = d.extraJson.optJSONArray("targets")
                        if (subs != null) {
                            Text(
                                "${subs.length()} élément(s) : " + (0 until minOf(subs.length(), 8)).joinToString(", ") { subs.optJSONObject(it)?.optString("name").orEmpty() } +
                                    if (subs.length() > 8) "…" else "",
                                style = MaterialTheme.typography.bodySmall,
                            )
                        }
                        FlowRow(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            if (d.kind != Kind.HUE && d.kind != Kind.HOME_ASSISTANT) {
                                TextButton(onClick = { scope.launch { status = test(d, store, true) } }) { Text("Allumer") }
                                TextButton(onClick = { scope.launch { status = test(d, store, false) } }) { Text("Éteindre") }
                            } else {
                                TextButton(onClick = {
                                    scope.launch {
                                        status = withContext(Dispatchers.IO) { refreshTargets(d, store) }
                                        version++
                                    }
                                }) { Text("Actualiser la liste") }
                            }
                            TextButton(onClick = { confirmDelete = d }) { Text("Supprimer", color = MaterialTheme.colorScheme.error) }
                        }
                    }
                }
            }
        }
    }

    adding?.let { f ->
        AddDeviceDialog(
            store = store,
            kind = f.kind ?: Kind.WEBHOOK,
            initialHost = f.host,
            initialName = f.label,
            onDismiss = { adding = null },
            onSaved = { msg -> adding = null; status = msg; version++ },
        )
    }
    if (choosingKind) {
        AlertDialog(
            onDismissRequest = { choosingKind = false },
            title = { Text("Type d'appareil") },
            text = {
                Column(Modifier.heightIn(max = 460.dp).verticalScroll(rememberScrollState())) {
                    Kind.entries.filter { it != Kind.INFRAROUGE || fr.jeremy.calepin.control.Infrared.available(store.context) }.forEach { k ->
                        Text(
                            k.label,
                            style = MaterialTheme.typography.bodyLarge,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { choosingKind = false; adding = FoundDevice("", k, k.label) }
                                .padding(vertical = 10.dp),
                        )
                    }
                }
            },
            confirmButton = { TextButton(onClick = { choosingKind = false }) { Text("Fermer") } },
        )
    }
    confirmDelete?.let { d ->
        AlertDialog(
            onDismissRequest = { confirmDelete = null },
            title = { Text("Supprimer « ${d.name} » ?") },
            text = { Text("Il ne sera plus commandé par l'assistant. L'appareil lui-même n'est pas modifié.") },
            confirmButton = { TextButton(onClick = { store.delete(d.id); confirmDelete = null; version++ }) { Text("Supprimer", color = MaterialTheme.colorScheme.error) } },
            dismissButton = { TextButton(onClick = { confirmDelete = null }) { Text("Annuler") } },
        )
    }
}

private suspend fun test(d: HomeDevice, store: DeviceStore, on: Boolean): String = withContext(Dispatchers.IO) {
    val tv = TvDrivers.forDevice(d, store)
    val ok = if (tv != null) tv.power(on) else SmartHome.power(Target(d, null, d.name, d.role.name.lowercase()), on)
    if (ok) "${d.name} : commande envoyée." else "${d.name} ne répond pas. Vérifie l'adresse et que l'appareil est sur le même Wi-Fi."
}

private fun refreshTargets(d: HomeDevice, store: DeviceStore): String {
    val list = when (d.kind) {
        Kind.HUE -> SmartHome.hueTargets(d.host, d.secret)
        Kind.HOME_ASSISTANT -> SmartHome.haTargets(d.host, d.secret).getOrElse { return "Home Assistant : ${it.message}" }
        else -> return ""
    }
    store.upsert(d.copy(extra = d.extraJson.put("targets", list).toString()))
    return "${d.name} : ${list.length()} élément(s)."
}

/** Ajout d'un appareil, avec l'étape propre à sa famille (code, clé, jeton, accord sur la télé…). */
@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun AddDeviceDialog(
    store: DeviceStore,
    kind: Kind,
    initialHost: String,
    initialName: String,
    onDismiss: () -> Unit,
    onSaved: (String) -> Unit,
) {
    val scope = rememberCoroutineScope()
    var name by remember { mutableStateOf(initialName.ifBlank { kind.label }) }
    var host by remember {
        mutableStateOf(
            when {
                kind == Kind.FREEBOX_PLAYER && initialHost.isBlank() -> "hd1.freebox.fr"
                kind == Kind.HOME_ASSISTANT && initialHost.isNotBlank() && !initialHost.startsWith("http") -> "http://$initialHost:8123"
                else -> initialHost
            }
        )
    }
    var role by remember { mutableStateOf(kind.role) }
    var secret by remember { mutableStateOf("") }
    var offUrl by remember { mutableStateOf("") }
    var irBrand by remember { mutableStateOf(fr.jeremy.calepin.control.Infrared.Brand.SAMSUNG) }
    var busy by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf<String?>(null) }
    var pairing by remember { mutableStateOf<AndroidTvRemote?>(null) }
    DisposableEffect(Unit) { onDispose { pairing?.closePairing() } }

    fun save(secretValue: String = secret, extra: JSONObject = JSONObject()) {
        val d = HomeDevice(name = name.trim().ifBlank { kind.label }, kind = kind, host = host.trim(), role = role, secret = secretValue.trim(), extra = extra.toString())
        store.upsert(d)
        if (store.all().count { it.role == role } == 1 && (role == Role.TV || role == Role.DECODER)) store.setDefault(d)
        onSaved("« ${d.name} » ajouté. Essaie : « allume ${d.name.lowercase()} ».")
    }

    fun launchStep(block: suspend () -> Unit) {
        busy = true
        message = null
        scope.launch {
            try {
                block()
            } catch (e: Exception) {
                message = e.message ?: e.javaClass.simpleName
            }
            busy = false
        }
    }

    AlertDialog(
        onDismissRequest = { if (!busy) onDismiss() },
        title = { Text(kind.label) },
        text = {
            Column(Modifier.heightIn(max = 520.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(kind.help, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Nom à dire (ex. télé du salon)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                if (kind == Kind.INFRAROUGE) {
                    Text("Marque de la télé", style = MaterialTheme.typography.labelLarge)
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        fr.jeremy.calepin.control.Infrared.Brand.entries.forEach { b ->
                            androidx.compose.material3.FilterChip(selected = b == irBrand, onClick = { irBrand = b }, label = { Text(b.label) })
                        }
                    }
                    TextButton(onClick = {
                        val ok = fr.jeremy.calepin.control.Infrared.send(store.context, irBrand, fr.jeremy.calepin.control.RemoteKey.POWER)
                        message = if (ok) "Signal envoyé : la télé a-t-elle réagi ?" else "Ce téléphone n'a pas d'émetteur infrarouge."
                    }) { Text("Tester (marche / arrêt)") }
                } else OutlinedTextField(
                    value = host, onValueChange = { host = it }, singleLine = true, modifier = Modifier.fillMaxWidth(),
                    label = {
                        Text(
                            when (kind) {
                                Kind.HOME_ASSISTANT -> "Adresse (http://…:8123)"
                                Kind.WEBHOOK -> "Adresse pour allumer / lancer"
                                else -> "Adresse sur le Wi-Fi"
                            }
                        )
                    },
                )
                if (kind == Kind.ANDROID_TV || kind == Kind.SHELLY || kind == Kind.TASMOTA || kind == Kind.WEBHOOK) {
                    val choices = when (kind) {
                        Kind.ANDROID_TV -> listOf(Role.TV, Role.DECODER)
                        Kind.WEBHOOK -> listOf(Role.LIGHT, Role.PLUG, Role.OTHER)
                        else -> listOf(Role.PLUG, Role.LIGHT)
                    }
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        choices.forEach { r -> FilterChip(selected = role == r, onClick = { role = r }, label = { Text(r.label) }) }
                    }
                }
                when (kind) {
                    Kind.BRAVIA -> OutlinedTextField(value = secret, onValueChange = { secret = it }, label = { Text("Clé pré-partagée") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    Kind.FREEBOX_PLAYER -> OutlinedTextField(value = secret, onValueChange = { secret = it }, label = { Text("Code télécommande réseau") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    Kind.HOME_ASSISTANT -> OutlinedTextField(value = secret, onValueChange = { secret = it }, label = { Text("Jeton d'accès longue durée") }, modifier = Modifier.fillMaxWidth())
                    Kind.WEBHOOK -> OutlinedTextField(value = offUrl, onValueChange = { offUrl = it }, label = { Text("Adresse pour éteindre (facultatif)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    Kind.ANDROID_TV -> if (pairing != null) {
                        OutlinedTextField(value = secret, onValueChange = { secret = it.take(6) }, label = { Text("Code affiché sur la télé") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    }
                    else -> Unit
                }
                if (busy) LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                message?.let { Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall) }
            }
        },
        confirmButton = {
            val ready = (host.isNotBlank() || kind == Kind.INFRAROUGE) && !busy
            when (kind) {
                Kind.ANDROID_TV -> if (pairing == null) {
                    Button(enabled = ready, onClick = {
                        launchStep {
                            val r = AndroidTvRemote(host.trim(), withContext(Dispatchers.IO) { store.androidTvIdentity() })
                            withContext(Dispatchers.IO) { r.startPairing("Calepin IA") }
                            pairing = r
                        }
                    }) { Text("Afficher le code") }
                } else {
                    Button(enabled = !busy && secret.length == 6, onClick = {
                        launchStep {
                            withContext(Dispatchers.IO) { pairing!!.finishPairing(secret) }
                            pairing = null
                            save(secretValue = "")
                        }
                    }) { Text("Valider le code") }
                }
                Kind.SAMSUNG -> Button(enabled = ready, onClick = {
                    launchStep {
                        message = "Accepte la demande sur la télé…"
                        val token = withContext(Dispatchers.IO) { SamsungTv.pair(host.trim()) }.getOrThrow()
                        save(secretValue = token)
                    }
                }) { Text("Connecter") }
                Kind.LG -> Button(enabled = ready, onClick = {
                    launchStep {
                        message = "Accepte la demande sur la télé…"
                        val key = withContext(Dispatchers.IO) { LgTv.pair(host.trim()) }.getOrThrow()
                        save(secretValue = key)
                    }
                }) { Text("Connecter") }
                Kind.HUE -> Button(enabled = ready, onClick = {
                    launchStep {
                        val user = withContext(Dispatchers.IO) { SmartHome.hueLink(host.trim()) }.getOrThrow()
                        val targets = withContext(Dispatchers.IO) { SmartHome.hueTargets(host.trim(), user) }
                        save(secretValue = user, extra = JSONObject().put("targets", targets))
                    }
                }) { Text("Connecter") }
                Kind.HOME_ASSISTANT -> Button(enabled = ready && secret.isNotBlank(), onClick = {
                    launchStep {
                        val targets = withContext(Dispatchers.IO) { SmartHome.haTargets(host.trim(), secret.trim()) }.getOrThrow()
                        save(extra = JSONObject().put("targets", targets))
                    }
                }) { Text("Connecter") }
                Kind.INFRAROUGE -> Button(enabled = !busy, onClick = {
                    host = "infrarouge"
                    save(extra = JSONObject().put("brand", irBrand.name))
                }) { Text("Enregistrer") }
                Kind.WEBHOOK -> Button(enabled = ready, onClick = {
                    save(extra = JSONObject().put("on_url", host.trim()).put("off_url", offUrl.trim()))
                }) { Text("Enregistrer") }
                Kind.BRAVIA -> Button(enabled = ready, onClick = {
                    launchStep {
                        val tv = fr.jeremy.calepin.control.BraviaTv(host.trim(), secret.trim())
                        val problem = withContext(Dispatchers.IO) { tv.lastProblem() }
                        if (problem != null) error(problem)
                        val mac = withContext(Dispatchers.IO) { tv.macAddress() }.orEmpty()
                        save(extra = JSONObject().put("mac", mac))
                    }
                }) { Text("Enregistrer") }
                else -> Button(enabled = ready, onClick = { save() }) { Text("Enregistrer") }
            }
        },
        dismissButton = { TextButton(onClick = { pairing?.closePairing(); onDismiss() }, enabled = !busy) { Text("Annuler") } },
    )
}
