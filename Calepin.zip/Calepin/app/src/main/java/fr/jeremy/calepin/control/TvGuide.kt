package fr.jeremy.calepin.control

import android.content.Context
import android.util.Xml
import fr.jeremy.calepin.search.TextNorm
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import org.xmlpull.v1.XmlPullParser
import java.io.File
import java.io.InputStream
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale
import java.util.zip.GZIPInputStream
import java.util.zip.ZipInputStream

/** Une émission du programme télé. */
data class TvProgram(
    val channelId: String,
    val channel: String,
    /** Numéro TNT de la chaîne (null si inconnu). */
    val number: Int?,
    val start: Long,
    val end: Long,
    val title: String,
    val subtitle: String,
    val category: String,
    val desc: String,
) {
    /** Film de cinéma (pas un téléfilm). */
    val isFilm: Boolean
        get() = category.lowercase(Locale.FRANCE).split(",").map { it.trim() }.any { it == "film" || it.startsWith("film ") || it == "cinéma" || it == "movie" }
    val isTvFilm: Boolean get() = "téléfilm" in category.lowercase(Locale.FRANCE)

    fun toJson(): JSONObject = JSONObject().put("ci", channelId).put("c", channel).put("n", number ?: -1).put("s", start).put("e", end)
        .put("t", title).put("st", subtitle).put("cat", category).put("d", desc)

    companion object {
        fun fromJson(o: JSONObject) = TvProgram(
            o.optString("ci"), o.optString("c"), o.optInt("n", -1).takeIf { it >= 0 }, o.optLong("s"), o.optLong("e"),
            o.optString("t"), o.optString("st"), o.optString("cat"), o.optString("d"),
        )
    }
}

/**
 * Programme télé des chaînes de la TNT (fichiers XMLTV libres de xmltvfr.fr, mis à jour chaque nuit).
 * Gardé en cache une demi-journée ; seules les émissions d'aujourd'hui et de demain matin sont conservées.
 */
object TvGuide {
    private val SOURCES = listOf(
        "https://xmltvfr.fr/xmltv/xmltv_tnt.xml.gz",
        "https://xmltvfr.fr/xmltv/xmltv_tnt.zip",
    )
    private const val MAX_AGE = 12 * 3_600_000L

    @Volatile private var memory: Pair<Long, List<TvProgram>>? = null

    private fun cache(ctx: Context) = File(ctx.filesDir, "tvguide.json")

    private fun dayKey(t: Long) = Calendar.getInstance().apply { timeInMillis = t }.let { it.get(Calendar.YEAR) * 1000 + it.get(Calendar.DAY_OF_YEAR) }

    /** Programme (depuis le cache s'il est récent, sinon téléchargé). */
    suspend fun load(ctx: Context, force: Boolean = false): Result<List<TvProgram>> = withContext(Dispatchers.IO) {
        val now = System.currentTimeMillis()
        fun fresh(at: Long) = now - at < MAX_AGE && dayKey(at) == dayKey(now)
        if (!force) {
            memory?.let { (at, l) -> if (fresh(at)) return@withContext Result.success(l) }
            runCatching {
                val o = JSONObject(cache(ctx).readText())
                val at = o.getLong("at")
                if (fresh(at)) {
                    val a = o.getJSONArray("p")
                    val l = (0 until a.length()).map { TvProgram.fromJson(a.getJSONObject(it)) }
                    memory = at to l
                    return@withContext Result.success(l)
                }
            }
        }
        var last: Throwable? = null
        for (src in SOURCES) {
            try {
                val list = download(src)
                if (list.isNotEmpty()) {
                    memory = now to list
                    runCatching {
                        cache(ctx).writeText(JSONObject().put("at", now).put("p", JSONArray().apply { list.forEach { put(it.toJson()) } }).toString())
                    }
                    return@withContext Result.success(list)
                }
            } catch (e: Throwable) {
                last = e
            }
        }
        // Rien de neuf : l'ancien cache vaut mieux que rien
        runCatching {
            val a = JSONObject(cache(ctx).readText()).getJSONArray("p")
            val l = (0 until a.length()).map { TvProgram.fromJson(a.getJSONObject(it)) }
            if (l.isNotEmpty()) return@withContext Result.success(l)
        }
        Result.failure(last ?: IllegalStateException("Programme indisponible"))
    }

    private fun download(src: String): List<TvProgram> {
        val c = URL(src).openConnection() as HttpURLConnection
        c.connectTimeout = 10_000
        c.readTimeout = 30_000
        c.setRequestProperty("User-Agent", "Calepin (appli Android personnelle)")
        try {
            if (c.responseCode !in 200..299) error("HTTP ${c.responseCode}")
            c.inputStream.buffered().use { raw ->
                return if (src.endsWith(".zip")) {
                    val z = ZipInputStream(raw)
                    var e = z.nextEntry
                    while (e != null && !e.name.endsWith(".xml")) e = z.nextEntry
                    if (e == null) error("Archive vide")
                    parse(z)
                } else {
                    parse(GZIPInputStream(raw))
                }
            }
        } finally {
            c.disconnect()
        }
    }

    /** Lecture du XMLTV en flux (le fichier fait plusieurs Mo une fois décompressé). */
    fun parse(input: InputStream): List<TvProgram> {
        val now = System.currentTimeMillis()
        val dayStart = Calendar.getInstance().apply { set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0) }.timeInMillis
        val keepFrom = minOf(dayStart, now - 6 * 3_600_000L)
        val keepTo = dayStart + 30 * 3_600_000L
        val fmt = SimpleDateFormat("yyyyMMddHHmmss Z", Locale.US)
        fun time(s: String?): Long = s?.let { runCatching { fmt.parse(it.trim())?.time }.getOrNull() } ?: 0L

        val names = HashMap<String, String>()
        val out = ArrayList<TvProgram>()
        val p = Xml.newPullParser()
        p.setFeature(XmlPullParser.FEATURE_PROCESS_NAMESPACES, false)
        p.setInput(input, "UTF-8")
        var chId: String? = null
        var prog: MutableMap<String, String>? = null
        var cats = ArrayList<String>()
        var ev = p.eventType
        while (ev != XmlPullParser.END_DOCUMENT) {
            if (ev == XmlPullParser.START_TAG) {
                when (p.name) {
                    "channel" -> chId = p.getAttributeValue(null, "id")
                    "display-name" -> if (chId != null && prog == null) {
                        val n = p.nextText().trim()
                        if (n.isNotEmpty()) names.putIfAbsent(chId!!, n)
                    }
                    "programme" -> {
                        val s = time(p.getAttributeValue(null, "start"))
                        val e = time(p.getAttributeValue(null, "stop"))
                        prog = if (e > keepFrom && s < keepTo) mutableMapOf(
                            "ch" to (p.getAttributeValue(null, "channel") ?: ""), "s" to s.toString(), "e" to e.toString(),
                        ) else null
                        cats = ArrayList()
                        if (prog == null) {
                            // Émission hors période : on saute tout son contenu
                            var depth = 1
                            while (depth > 0) {
                                when (p.next()) {
                                    XmlPullParser.START_TAG -> depth++
                                    XmlPullParser.END_TAG -> depth--
                                    XmlPullParser.END_DOCUMENT -> depth = 0
                                }
                            }
                        }
                    }
                    "title", "sub-title", "desc" -> prog?.let { m ->
                        val k = p.name
                        val v = p.nextText().trim()
                        if (m[k].isNullOrEmpty()) m[k] = v
                    }
                    "category" -> if (prog != null) cats += p.nextText().trim()
                }
            } else if (ev == XmlPullParser.END_TAG) {
                when (p.name) {
                    "channel" -> chId = null
                    "programme" -> prog?.let { m ->
                        val id = m["ch"].orEmpty()
                        val name = names[id] ?: id.substringBefore(".")
                        out += TvProgram(
                            id, name, numberOf(name), m["s"]!!.toLong(), m["e"]!!.toLong(),
                            m["title"].orEmpty(), m["sub-title"].orEmpty(), cats.distinct().joinToString(", "), m["desc"].orEmpty().take(400),
                        )
                        prog = null
                    }
                }
            }
            ev = p.next()
        }
        return out.sortedWith(compareBy({ it.number ?: 999 }, { it.start }))
    }

    /** Numéro TNT d'après le nom de la chaîne. */
    fun numberOf(name: String): Int? {
        val n = TextNorm.norm(name).replace(Regex("\\s+"), " ").trim()
        return OrangeDecoder.findChannel(n)?.number
    }

    /** Émission de première partie de soirée (vers 21 h) sur chaque chaîne. */
    fun tonight(all: List<TvProgram>, day: Long = System.currentTimeMillis()): List<TvProgram> {
        val c = Calendar.getInstance().apply { timeInMillis = day; set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0) }
        fun at(h: Int, m: Int) = (c.clone() as Calendar).apply { set(Calendar.HOUR_OF_DAY, h); set(Calendar.MINUTE, m) }.timeInMillis
        val from = at(20, 40)
        val to = at(21, 40)
        val prime = at(21, 10)
        return all.groupBy { it.channelId }.mapNotNull { (_, l) ->
            l.filter { it.start in from..to && it.end - it.start >= 25 * 60_000L }.minByOrNull { it.start }
                ?: l.firstOrNull { it.start <= prime && it.end > prime }
        }.sortedWith(compareBy({ it.number ?: 999 }, { it.channel }))
    }

    /** Émission en cours sur chaque chaîne. */
    fun now(all: List<TvProgram>, t: Long = System.currentTimeMillis()): List<TvProgram> =
        all.filter { it.start <= t && it.end > t }.distinctBy { it.channelId }.sortedWith(compareBy({ it.number ?: 999 }, { it.channel }))

    /** « Le film de ce soir » : le film de cinéma de la soirée sur la chaîne au plus petit numéro (sinon un téléfilm). */
    fun tonightFilm(all: List<TvProgram>): TvProgram? {
        val t = tonight(all)
        return t.firstOrNull { it.isFilm && it.number != null } ?: t.firstOrNull { it.isFilm } ?: t.firstOrNull { it.isTvFilm && it.number != null }
    }
}
