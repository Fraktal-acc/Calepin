package fr.jeremy.calepin.vehicle

import java.util.Calendar

/** Type de véhicule. */
enum class VehicleKind(val label: String) {
    VOITURE("Voiture"), UTILITAIRE("Utilitaire"), MOTO("Moto / scooter"), VELO("Vélo"), AUTRE("Autre"),
}

/** État constaté d'une pièce, du meilleur au pire. */
enum class Verdict(val label: String, val advice: String) {
    BON("Bon état", "Rien à faire pour l'instant. Recontrôle dans quelques mois."),
    SURVEILLER("À surveiller", "Usure visible : recontrôle bientôt et prévois le remplacement."),
    REMPLACER("À remplacer", "À faire vérifier et remplacer rapidement par un professionnel."),
    INCONNU("À vérifier", "Impossible de conclure : refais une photo plus nette ou fais vérifier."),
    ;

    /** Gravité pour garder la pire : inconnu passe après bon. */
    val rank: Int get() = when (this) { BON -> 0; INCONNU -> 1; SURVEILLER -> 2; REMPLACER -> 3 }

    companion object {
        fun worst(l: Iterable<Verdict>): Verdict = l.maxByOrNull { it.rank } ?: INCONNU
    }
}

/** Question d'un contrôle guidé : « oui » donne [ifYes]. */
data class Question(val id: String, val text: String, val ifYes: Verdict)

/** Pièce contrôlable, avec les conseils de photo et les questions du contrôle guidé. */
enum class Part(
    val label: String,
    /** Comment prendre la photo. */
    val photoTip: String,
    /** Ce que l'IA doit regarder. */
    val aiFocus: String,
    val questions: List<Question>,
    /** Positions possibles (pneus : avant gauche…). */
    val positions: List<String> = emptyList(),
    /** Véhicules concernés (vide : tous). */
    val kinds: Set<VehicleKind> = emptySet(),
) {
    PNEU(
        "Pneus",
        "Photo de face de la bande de roulement, de près, bien éclairée (lampe du téléphone). Une 2e photo du flanc aide à voir les craquelures et la date (code DOT).",
        "la profondeur des sculptures, les témoins d'usure (petits plots au fond des rainures) au même niveau que la gomme, " +
            "une usure plus forte d'un côté (parallélisme) ou au centre (surgonflage), les craquelures, hernies (bosses), coupures, " +
            "clous ou objets plantés, la toile visible",
        listOf(
            Question("twi", "Les témoins d'usure (petits plots au fond des rainures) sont au niveau de la gomme", Verdict.REMPLACER),
            Question("toile", "On voit la toile ou des fils métalliques", Verdict.REMPLACER),
            Question("hernie", "Il y a une bosse (hernie) ou une coupure sur le flanc", Verdict.REMPLACER),
            Question("craquelures", "Le flanc est craquelé (petites fissures)", Verdict.SURVEILLER),
            Question("inegale", "L'usure est plus forte sur un bord ou au centre", Verdict.SURVEILLER),
            Question("clou", "Un clou, une vis ou un caillou est planté dans la gomme", Verdict.SURVEILLER),
            Question("pression", "Le pneu paraît sous-gonflé (écrasé en bas)", Verdict.SURVEILLER),
        ),
        positions = listOf("Avant gauche", "Avant droit", "Arrière gauche", "Arrière droit", "Roue de secours"),
        kinds = setOf(VehicleKind.VOITURE, VehicleKind.UTILITAIRE, VehicleKind.AUTRE),
    ),
    PNEU_2R(
        "Pneus (deux-roues)",
        "Photo de la bande de roulement au centre et sur les côtés (là où ça frotte en virage), bien éclairée.",
        "la profondeur des sculptures au centre et sur les bords, les témoins d'usure, une usure en méplat au centre, " +
            "les craquelures, coupures, objets plantés",
        listOf(
            Question("twi", "Les témoins d'usure sont au niveau de la gomme", Verdict.REMPLACER),
            Question("meplat", "Le centre est aplati (méplat)", Verdict.SURVEILLER),
            Question("craquelures", "La gomme est craquelée", Verdict.SURVEILLER),
            Question("coupure", "Il y a une coupure ou une bosse", Verdict.REMPLACER),
        ),
        positions = listOf("Avant", "Arrière"),
        kinds = setOf(VehicleKind.MOTO, VehicleKind.VELO),
    ),
    FREINS(
        "Freins",
        "Photo du disque à travers la jante (roue braquée pour l'avant), avec l'étrier et la plaquette si on la voit.",
        "l'épaisseur de garniture des plaquettes, un rebord (lèvre) sur le bord extérieur du disque, des rayures profondes, " +
            "de la rouille épaisse, des fissures ou des traces bleues de surchauffe",
        listOf(
            Question("plaquette", "La garniture des plaquettes paraît très fine (moins de 3 mm)", Verdict.REMPLACER),
            Question("bruit", "Les freins grincent ou font un bruit de métal", Verdict.REMPLACER),
            Question("levre", "Le disque a un rebord marqué sur son bord extérieur", Verdict.SURVEILLER),
            Question("rayures", "Le disque est rayé profondément ou bleui", Verdict.SURVEILLER),
            Question("voyant", "Le voyant de freins ou d'usure est allumé", Verdict.REMPLACER),
            Question("vibre", "La pédale ou le volant vibre au freinage", Verdict.SURVEILLER),
        ),
    ),
    PARE_BRISE(
        "Pare-brise",
        "Photo de l'impact ou de la fissure de près, avec une pièce ou un doigt à côté pour l'échelle.",
        "les impacts (taille et position), les fissures et leur longueur, la zone de vision du conducteur",
        listOf(
            Question("fissure", "Il y a une fissure (une ligne qui s'étend)", Verdict.REMPLACER),
            Question("gros", "Un impact est plus grand qu'une pièce de 2 €", Verdict.REMPLACER),
            Question("vision", "Un impact est dans le champ de vision du conducteur", Verdict.SURVEILLER),
            Question("impact", "Il y a un petit impact (réparable)", Verdict.SURVEILLER),
        ),
        kinds = setOf(VehicleKind.VOITURE, VehicleKind.UTILITAIRE, VehicleKind.AUTRE),
    ),
    ESSUIE_GLACES(
        "Essuie-glaces",
        "Photo de la lame en caoutchouc, de près, et si possible du pare-brise mouillé après un passage.",
        "le caoutchouc fendu, durci, arraché ou déformé, les traînées laissées sur la vitre",
        listOf(
            Question("traces", "Ils laissent des traînées ou des zones non essuyées", Verdict.REMPLACER),
            Question("fendu", "Le caoutchouc est fendu, arraché ou durci", Verdict.REMPLACER),
            Question("bruit", "Ils grincent ou sautent sur la vitre", Verdict.SURVEILLER),
        ),
        kinds = setOf(VehicleKind.VOITURE, VehicleKind.UTILITAIRE, VehicleKind.AUTRE),
    ),
    ECLAIRAGE(
        "Éclairage",
        "Photo des phares allumés (de jour à l'ombre ou le soir), et des optiques de près.",
        "une ampoule éteinte, une optique jaunie ou opaque, une fissure, de la condensation à l'intérieur",
        listOf(
            Question("eteint", "Une ampoule ne s'allume pas (phare, feu stop, clignotant)", Verdict.REMPLACER),
            Question("jauni", "L'optique est jaunie ou opaque", Verdict.SURVEILLER),
            Question("buee", "Il y a de la buée ou de l'eau dans le phare", Verdict.SURVEILLER),
            Question("casse", "L'optique est fissurée ou cassée", Verdict.REMPLACER),
        ),
    ),
    CHAINE(
        "Chaîne et transmission",
        "Photo de la chaîne et de la couronne arrière, de près.",
        "la rouille, les dents de la couronne pointues ou crochues, la chaîne sèche, distendue ou avec des maillons raides",
        listOf(
            Question("dents", "Les dents de la couronne sont pointues ou en crochet", Verdict.REMPLACER),
            Question("rouille", "La chaîne est rouillée ou sèche", Verdict.SURVEILLER),
            Question("tension", "La chaîne pend beaucoup ou saute", Verdict.SURVEILLER),
        ),
        kinds = setOf(VehicleKind.MOTO, VehicleKind.VELO),
    ),
    CARROSSERIE(
        "Carrosserie et dessous",
        "Photo de la zone abîmée ou rouillée, avec un peu de recul puis de près.",
        "la rouille (surface ou perforante), les bosses, les rayures jusqu'à la tôle, une fuite (taches sous le véhicule), " +
            "un pot d'échappement percé ou qui pend",
        listOf(
            Question("perforee", "La rouille a percé la tôle", Verdict.REMPLACER),
            Question("fuite", "Il y a une tache de liquide sous le véhicule", Verdict.SURVEILLER),
            Question("echappement", "L'échappement pend, est percé ou fait plus de bruit", Verdict.SURVEILLER),
            Question("rouille", "Il y a de la rouille en surface", Verdict.SURVEILLER),
            Question("rayure", "Une rayure va jusqu'à la tôle", Verdict.SURVEILLER),
        ),
    ),
    AUTRE(
        "Autre pièce",
        "Photo de la pièce de près, bien éclairée, avec un objet connu à côté pour l'échelle.",
        "tout signe d'usure, de casse, de fuite, de rouille ou de mauvais état",
        emptyList(),
    ),
    ;

    fun forKind(k: VehicleKind) = kinds.isEmpty() || k in kinds

    companion object {
        fun forVehicle(k: VehicleKind) = entries.filter { it.forKind(k) }
    }
}

/** Analyse de l'IA, lue dans sa réponse. */
data class AiFinding(val verdict: Verdict, val findings: List<String>, val advice: String, val confident: Boolean, val treadMm: Float? = null)

/** Règles de sécurité utilisées par l'assistant (sans IA, ou en plus de l'IA). */
object WearRules {
    /** Profondeur minimale légale des pneus de voiture en France (mm). */
    const val LEGAL_MM = 1.6f
    /** En dessous : freinage sur sol mouillé nettement moins bon. */
    const val ADVISED_MM = 3f

    /** Profondeur mesurée (jauge ou pièce) → verdict. */
    fun tread(mm: Float, twoWheels: Boolean = false): Pair<Verdict, String> = when {
        mm < (if (twoWheels) 1f else LEGAL_MM) -> Verdict.REMPLACER to
            "Profondeur de ${fmt(mm)} mm : sous le minimum légal (${if (twoWheels) "1 mm pour un deux-roues" else "1,6 mm"}). Pneu à remplacer avant de rouler."
        mm < 2f -> Verdict.REMPLACER to "Profondeur de ${fmt(mm)} mm : presque au minimum légal, à remplacer très bientôt."
        mm < ADVISED_MM -> Verdict.SURVEILLER to "Profondeur de ${fmt(mm)} mm : encore légal, mais l'adhérence sur route mouillée baisse. Prévois le remplacement."
        else -> Verdict.BON to "Profondeur de ${fmt(mm)} mm : correcte."
    }

    private fun fmt(f: Float) = if (f % 1f == 0f) f.toInt().toString() else "%.1f".format(java.util.Locale.FRANCE, f)

    /** Test de la pièce de 1 € : la bordure dorée fait environ 3 mm. */
    const val COIN_TIP = "Test de la pièce de 1 € : glisse-la dans une rainure. Si la bordure dorée reste visible, il reste moins de 3 mm environ. " +
        "Les témoins d'usure (petits plots dans les rainures) marquent le minimum légal de 1,6 mm."

    /** Semaine et année de fabrication lues dans le code DOT du flanc (« DOT … 2319 » = semaine 23 de 2019). */
    fun dot(text: String, now: Int = Calendar.getInstance().get(Calendar.YEAR)): Pair<Int, Int>? {
        val t = text.uppercase().replace('O', '0').replace(Regex("[^A-Z0-9 ]"), " ")
        val afterDot = Regex("D\\s*0\\s*T\\b(.{0,40})").find(t)?.groupValues?.get(1)
        val zone = afterDot ?: t
        val candidates = Regex("(?<![0-9])([0-5][0-9])([0-9]{2})(?![0-9])").findAll(zone).map { it.groupValues[1].toInt() to it.groupValues[2].toInt() }
            .filter { (w, y) -> w in 1..53 && 2000 + y in 2000..now }.toList()
        // Le code de date est le dernier groupe de 4 chiffres du DOT
        val (w, y) = candidates.lastOrNull() ?: return null
        return w to 2000 + y
    }

    /** Âge du pneu → verdict. */
    fun age(week: Int, year: Int, nowMillis: Long = System.currentTimeMillis()): Pair<Verdict, String> {
        val c = Calendar.getInstance().apply { timeInMillis = nowMillis }
        val months = (c.get(Calendar.YEAR) - year) * 12 + (c.get(Calendar.WEEK_OF_YEAR) - week) / 4
        val years = months / 12
        val made = "fabriqué la semaine $week de $year"
        return when {
            years >= 10 -> Verdict.REMPLACER to "Pneu $made : plus de 10 ans, la gomme durcit même sans usure. À remplacer."
            years >= 6 -> Verdict.SURVEILLER to "Pneu $made : $years ans. Fais-le contrôler chaque année (craquelures, gomme dure)."
            else -> Verdict.BON to "Pneu $made : ${if (years < 1) "moins d'un an" else "$years an" + (if (years > 1) "s" else "")}."
        }
    }

    /** Réponses « oui » du contrôle guidé → verdict et constats. */
    fun guided(part: Part, yes: Set<String>): Pair<Verdict, List<String>> {
        val hits = part.questions.filter { it.id in yes }
        if (hits.isEmpty()) return (if (part.questions.isEmpty()) Verdict.INCONNU else Verdict.BON) to emptyList()
        return Verdict.worst(hits.map { it.ifYes }) to hits.map { it.text }
    }

    // ------------------------------------------------------------------ IA

    /** Consigne pour l'IA qui regarde la photo. */
    fun aiPrompt(part: Part, position: String?, vehicle: String): String =
        "Tu es un mécanicien expérimenté. Regarde attentivement cette photo d'un élément de véhicule : " +
            "${part.label.lowercase()}${position?.let { " ($it)" } ?: ""} de « $vehicle ». " +
            "Examine ${part.aiFocus}. " +
            "Réponds en français, exactement avec ces lignes :\n" +
            "ÉTAT : BON, SURVEILLER, REMPLACER ou INCERTAIN\n" +
            "CONFIANCE : HAUTE ou BASSE\n" +
            (if (part == Part.PNEU || part == Part.PNEU_2R) "PROFONDEUR : estimation en mm, ou INCONNUE\n" else "") +
            "CONSTATS :\n- un constat par ligne, seulement ce qui se voit vraiment sur la photo\n" +
            "CONSEIL : une phrase\n" +
            "Si la photo est floue, trop sombre, ou ne montre pas cette pièce, réponds ÉTAT : INCERTAIN et dis quelle photo prendre. " +
            "N'invente rien. En cas de doute sur la sécurité (pneus, freins), choisis l'état le plus prudent."

    /** Lecture de la réponse de l'IA (tolérante : majuscules, accents, mots en plus). */
    fun parseAi(text: String): AiFinding {
        val lines = text.lines().map { it.trim() }
        fun value(key: String) = lines.firstOrNull { Regex("(?i)^\\**\\s*$key\\s*\\**\\s*:").containsMatchIn(it) }
            ?.substringAfter(':')?.trim()?.trim('*', ' ')
        val etat = (value("[ÉE]TAT") ?: "").uppercase()
        val verdict = when {
            "REMPLACER" in etat || "CHANGER" in etat || "MAUVAIS" in etat -> Verdict.REMPLACER
            "SURVEILLER" in etat || "MOYEN" in etat || "USÉ" in etat || "USE" in etat -> Verdict.SURVEILLER
            "INCERTAIN" in etat || "INCONNU" in etat || etat.isBlank() -> Verdict.INCONNU
            "BON" in etat || "CORRECT" in etat -> Verdict.BON
            else -> Verdict.INCONNU
        }
        val confident = !(value("CONFIANCE") ?: "BASSE").uppercase().contains("BASSE")
        val mm = value("PROFONDEUR")?.let { Regex("(\\d+(?:[.,]\\d+)?)").find(it)?.groupValues?.get(1)?.replace(',', '.')?.toFloatOrNull() }
            ?.takeIf { it in 0f..15f }
        val start = lines.indexOfFirst { Regex("(?i)^\\**\\s*CONSTATS?\\s*\\**\\s*:").containsMatchIn(it) }
        val findings = if (start < 0) emptyList() else {
            val first = lines[start].substringAfter(':').trim().trim('*', ' ')
            (listOf(first) + lines.drop(start + 1).takeWhile { !Regex("(?i)^\\**\\s*(CONSEIL|[ÉE]TAT|CONFIANCE|PROFONDEUR)\\b").containsMatchIn(it) })
                .map { it.removePrefix("-").removePrefix("•").removePrefix("*").trim() }
                .filter { it.isNotBlank() && it.length > 2 }
        }
        val advice = value("CONSEIL").orEmpty()
        return AiFinding(verdict, findings.take(8), advice, confident, mm)
    }

    /**
     * Verdict final : le pire de ce qui a été constaté (photo analysée, questions, profondeur, âge).
     * Une analyse de l'IA peu sûre ne peut pas, seule, rassurer : elle compte alors comme « à vérifier ».
     */
    fun combine(ai: AiFinding?, others: List<Verdict>): Verdict {
        val aiV = ai?.let { if (!it.confident && it.verdict == Verdict.BON) Verdict.INCONNU else it.verdict }
        val all = listOfNotNull(aiV) + others
        if (all.isEmpty()) return Verdict.INCONNU
        // Mesures et questions disent « bon » : l'incertitude de la photo ne l'emporte pas
        if (aiV == Verdict.INCONNU && others.isNotEmpty()) return Verdict.worst(others)
        return Verdict.worst(all)
    }
}
