package fr.jeremy.calepin.ui

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Switch
import fr.jeremy.calepin.i18n.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.DialogProperties
import fr.jeremy.calepin.LockGuard
import fr.jeremy.calepin.NotesViewModel
import fr.jeremy.calepin.imports.NoteImporter
import fr.jeremy.calepin.imports.NoteSource
import kotlinx.coroutines.launch

/** Import des notes d'une autre appli : choix de l'appli, mode d'emploi, puis fichiers ou dossier. */
@Composable
fun ImportDialog(vm: NotesViewModel, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var source by remember { mutableStateOf<NoteSource?>(null) }
    var addTag by remember { mutableStateOf(true) }
    var busy by remember { mutableStateOf<String?>(null) }
    var result by remember { mutableStateOf<String?>(null) }

    fun startImport(block: suspend (NoteSource, (String) -> Unit) -> NoteImporter.Report) {
        val src = source ?: return
        busy = "Préparation…"
        scope.launch {
            result = try {
                val report = block(src) { msg -> busy = msg }
                busy = "Enregistrement des notes…"
                val added = vm.importNotes(report.notes)
                summary(report, added)
            } catch (e: Exception) {
                "Import impossible : ${e.message ?: "fichier illisible"}"
            }
            busy = null
        }
    }

    val pickFiles = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris: List<Uri> ->
        if (uris.isNotEmpty()) startImport { src, progress -> NoteImporter.fromFiles(ctx, uris, src, addTag, progress) }
    }
    val pickFolder = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { tree: Uri? ->
        if (tree != null) startImport { src, progress -> NoteImporter.fromFolder(ctx, tree, src, addTag, progress) }
    }

    val working = busy != null
    AlertDialog(
        onDismissRequest = { if (!working) onDismiss() },
        properties = DialogProperties(dismissOnBackPress = !working, dismissOnClickOutside = !working),
        title = {
            Text(
                when {
                    result != null -> "Import terminé"
                    source != null -> source!!.label
                    else -> "Importer depuis…"
                }
            )
        },
        text = {
            Column(
                Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                val src = source
                when {
                    working -> {
                        LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                        Text(busy.orEmpty(), style = MaterialTheme.typography.bodyMedium)
                        Text(
                            "Les PDF et images manuscrits sont lus page par page : cela peut prendre un moment.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                    result != null -> Text(result!!, style = MaterialTheme.typography.bodyMedium)
                    src == null -> {
                        Text(
                            "Android ne laisse pas une appli lire les notes d'une autre. On importe donc les fichiers que " +
                                "l'appli d'origine sait exporter. Choisissez-la pour voir comment faire :",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                        NoteSource.entries.forEach { s ->
                            Row(
                                Modifier
                                    .fillMaxWidth()
                                    .clickable { source = s }
                                    .padding(vertical = 10.dp),
                                verticalAlignment = Alignment.CenterVertically,
                            ) {
                                Text(s.label, style = MaterialTheme.typography.bodyLarge, modifier = Modifier.weight(1f))
                                Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, null)
                            }
                        }
                    }
                    else -> {
                        Text(src.howTo, style = MaterialTheme.typography.bodyMedium)
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text("Ajouter l'étiquette « ${src.tag} »", style = MaterialTheme.typography.bodyLarge)
                                Text(
                                    "Pour retrouver facilement les notes importées",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                )
                            }
                            Switch(checked = addTag, onCheckedChange = { addTag = it })
                        }
                        Button(
                            onClick = { LockGuard.external(); pickFiles.launch(arrayOf("*/*")) },
                            modifier = Modifier.fillMaxWidth(),
                        ) { Text("Choisir des fichiers (.zip, .enex, .pdf…)") }
                        OutlinedButton(
                            onClick = { LockGuard.external(); pickFolder.launch(null) },
                            modifier = Modifier.fillMaxWidth(),
                        ) { Text("Choisir un dossier entier") }
                        Text(
                            "Formats reconnus : texte (.txt), Markdown (.md), Word (.docx), PDF, HTML, Evernote (.enex), " +
                                "Google Keep et Simplenote (.json), archives .zip, images (lues par reconnaissance d'écriture). " +
                                "Les notes déjà présentes dans Calepin ne sont pas dupliquées.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }
            }
        },
        confirmButton = {
            if (!working) {
                TextButton(onClick = onDismiss) { Text(if (result != null) "OK" else "Fermer") }
            }
        },
        dismissButton = {
            if (!working && (source != null || result != null)) {
                TextButton(onClick = { source = null; result = null }) { Text(if (result != null) "Importer autre chose" else "Retour") }
            }
        },
    )
}

private fun summary(r: NoteImporter.Report, added: Int): String = buildString {
    val found = r.notes.size
    when {
        found == 0 -> append("Aucune note trouvée dans ces fichiers.")
        added == 0 -> append("Aucune nouvelle note : les $found notes trouvées étaient déjà dans Calepin.")
        else -> {
            append("$added note${if (added > 1) "s" else ""} importée${if (added > 1) "s" else ""}.")
            val dup = found - added
            if (dup > 0) append("\n$dup déjà présente${if (dup > 1) "s" else ""}, non dupliquée${if (dup > 1) "s" else ""}.")
        }
    }
    if (r.unsupported.isNotEmpty()) {
        val exts = r.unsupported.map { it.substringAfterLast('.', "sans extension").lowercase() }.distinct().take(6)
        append("\n${r.unsupported.size} fichier${if (r.unsupported.size > 1) "s" else ""} ignoré${if (r.unsupported.size > 1) "s" else ""} ")
        append("(format non pris en charge : ${exts.joinToString(", ") { ".$it" }}).")
    }
    if (r.unreadable.isNotEmpty()) {
        append("\nIllisible${if (r.unreadable.size > 1) "s" else ""} : ${r.unreadable.take(5).joinToString(", ")}")
        if (r.unreadable.size > 5) append("…")
    }
}
