package fr.jeremy.calepin.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowLeft
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.automirrored.filled.VolumeOff
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Dialpad
import androidx.compose.material.icons.filled.FastForward
import androidx.compose.material.icons.filled.FastRewind
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Input
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.PowerSettingsNew
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.Tv
import androidx.compose.material.icons.automirrored.filled.Undo
import androidx.compose.material3.AssistChip
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import fr.jeremy.calepin.control.DeviceStore
import fr.jeremy.calepin.control.Kind
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedTextField
import androidx.compose.ui.text.input.KeyboardType
import fr.jeremy.calepin.control.RemoteDrivers
import fr.jeremy.calepin.control.RemoteKey
import fr.jeremy.calepin.control.RemoteSession
import fr.jeremy.calepin.control.Role
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** Télécommande à l'écran pour les télés et décodeurs enregistrés (toutes marques gérées). */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RemoteScreen(onClose: () -> Unit, onDevices: () -> Unit) {
    val ctx = LocalContext.current
    val store = remember { DeviceStore(ctx) }
    val devices = remember { store.all().filter { it.role == Role.TV || it.role == Role.DECODER } }
    var current by remember {
        mutableStateOf(devices.firstOrNull { it.isDefault && it.role == Role.DECODER } ?: devices.firstOrNull { it.isDefault } ?: devices.firstOrNull())
    }
    val session = remember(current?.id) { current?.let { RemoteDrivers.open(it, store) } }
    DisposableEffect(session) { onDispose { session?.let { s -> Thread { s.close() }.start() } } }
    val scope = rememberCoroutineScope()
    val haptic = LocalHapticFeedback.current
    var status by remember { mutableStateOf<String?>(null) }
    var digits by remember { mutableStateOf(false) }
    var pinDialog by remember { mutableStateOf(false) }
    BackHandler { onClose() }

    fun press(k: RemoteKey) {
        val s = session ?: return
        haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
        scope.launch {
            val ok = withContext(Dispatchers.IO) { runCatching { s.press(k) }.getOrDefault(false) }
            if (!ok && s.needsPin) pinDialog = true
            status = if (ok) null else s.lastError?.let { "${current?.name ?: "L'appareil"} : $it." }
                ?: "${current?.name ?: "L'appareil"} ne répond pas. Il doit être allumé (ou en veille réseau) et sur le même Wi-Fi."
        }
    }

    fun app(name: String) {
        val s = session ?: return
        scope.launch {
            val r = withContext(Dispatchers.IO) { runCatching { s.openApp(name) }.getOrNull() }
            status = if (r != null) "$r ouvert." else "Impossible d'ouvrir $name sur cet appareil."
        }
    }

    if (pinDialog && session != null) {
        PinDialog(session, onDone = { ok ->
            pinDialog = false
            status = if (ok) "Téléphone autorisé : les touches devraient maintenant répondre." else null
        })
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Télécommande") },
                navigationIcon = { IconButton(onClick = onClose) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Retour") } },
                actions = { IconButton(onClick = onDevices) { Icon(Icons.Filled.Add, "Ajouter un appareil") } },
            )
        },
    ) { pad ->
        if (devices.isEmpty()) {
            Column(Modifier.fillMaxSize().padding(pad).padding(32.dp), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(Icons.Filled.Tv, null, Modifier.size(56.dp), tint = MaterialTheme.colorScheme.primary)
                Spacer(Modifier.height(12.dp))
                Text("Aucune télé ni décodeur enregistré", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(6.dp))
                Text("Recherche-les sur le Wi-Fi pour les piloter d'ici.", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                TextButton(onClick = onDevices) { Text("Rechercher les appareils") }
            }
            return@Scaffold
        }
        val keys = session?.keys ?: emptySet()
        Column(
            Modifier
                .fillMaxSize()
                .padding(pad)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp)
                .padding(bottom = 24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            // Choix de l'appareil
            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                devices.forEach { d -> FilterChip(selected = d.id == current?.id, onClick = { current = d; status = null }, label = { Text(d.name) }) }
            }
            current?.let { Text(it.kind.label, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant) }
            if (current?.kind == Kind.BRAVIA) {
                TextButton(onClick = { pinDialog = true }) { Text("Autoriser ce téléphone (code PIN)") }
            }

            // Marche / arrêt, entrée, menu
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                RoundKey(Icons.Filled.Input, "Source", RemoteKey.INPUT in keys) { press(RemoteKey.INPUT) }
                RoundKey(
                    Icons.Filled.PowerSettingsNew, "Marche / arrêt", RemoteKey.POWER in keys, size = 64.dp,
                    container = MaterialTheme.colorScheme.errorContainer, content = MaterialTheme.colorScheme.onErrorContainer,
                ) { press(RemoteKey.POWER) }
                RoundKey(Icons.Filled.Dialpad, "Pavé numérique", keys.any { it.digit != null }) { digits = !digits }
            }

            if (digits) {
                Surface(shape = MaterialTheme.shapes.large, color = MaterialTheme.colorScheme.surfaceContainerLow) {
                    Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf(listOf(1, 2, 3), listOf(4, 5, 6), listOf(7, 8, 9), listOf(-1, 0, -2)).forEach { row ->
                            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                row.forEach { n ->
                                    when (n) {
                                        -1 -> RoundKey(Icons.Filled.Info, "Infos", RemoteKey.INFO in keys) { press(RemoteKey.INFO) }
                                        -2 -> RoundKey(Icons.AutoMirrored.Filled.Undo, "Retour", RemoteKey.BACK in keys) { press(RemoteKey.BACK) }
                                        else -> TextKey(n.toString()) { press(RemoteKey.digit(n)) }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Volume, croix de navigation, chaînes
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Rocker("VOL", Icons.Filled.Add, Icons.Filled.Remove, { press(RemoteKey.VOL_UP) }, { press(RemoteKey.VOL_DOWN) })
                DPad(::press)
                Rocker("CH", Icons.Filled.KeyboardArrowUp, Icons.Filled.KeyboardArrowDown, { press(RemoteKey.CH_UP) }, { press(RemoteKey.CH_DOWN) })
            }

            // Retour, accueil, menu, guide, silence
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                RoundKey(Icons.AutoMirrored.Filled.Undo, "Retour", RemoteKey.BACK in keys) { press(RemoteKey.BACK) }
                RoundKey(Icons.Filled.Home, "Accueil", RemoteKey.HOME in keys) { press(RemoteKey.HOME) }
                RoundKey(Icons.Filled.Menu, "Menu", RemoteKey.MENU in keys) { press(RemoteKey.MENU) }
                RoundKey(Icons.Filled.Tv, "Guide TV", RemoteKey.GUIDE in keys) { press(RemoteKey.GUIDE) }
                RoundKey(Icons.AutoMirrored.Filled.VolumeOff, "Couper le son", RemoteKey.MUTE in keys) { press(RemoteKey.MUTE) }
            }

            // Lecture
            Row(horizontalArrangement = Arrangement.spacedBy(20.dp)) {
                RoundKey(Icons.Filled.FastRewind, "Retour rapide", RemoteKey.REWIND in keys) { press(RemoteKey.REWIND) }
                RoundKey(Icons.Filled.PlayArrow, "Lecture / pause", RemoteKey.PLAY_PAUSE in keys, size = 60.dp) { press(RemoteKey.PLAY_PAUSE) }
                RoundKey(Icons.Filled.FastForward, "Avance rapide", RemoteKey.FORWARD in keys) { press(RemoteKey.FORWARD) }
            }

            // Applis et entrées HDMI
            if (session?.hasApps == true) {
                Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("Netflix", "YouTube", "Prime Video", "Disney+", "myCANAL", "Spotify").forEach { n ->
                        AssistChip(onClick = { app(n) }, label = { Text(n) })
                    }
                }
            }
            if (session?.hasHdmi == true) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    (1..4).forEach { p ->
                        AssistChip(onClick = { scope.launch { status = if (withContext(Dispatchers.IO) { session.hdmi(p) }) "HDMI $p" else "Entrée HDMI $p indisponible" } }, label = { Text("HDMI $p") })
                    }
                }
            }

            status?.let { Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall) }
            Text(
                "Astuce : à la voix aussi — « mets France 2 », « monte le son de la télé », « mets Netflix sur la télé ».",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}

@Composable
private fun RoundKey(
    icon: ImageVector,
    description: String,
    enabled: Boolean,
    size: Dp = 52.dp,
    container: androidx.compose.ui.graphics.Color = MaterialTheme.colorScheme.secondaryContainer,
    content: androidx.compose.ui.graphics.Color = MaterialTheme.colorScheme.onSecondaryContainer,
    onClick: () -> Unit,
) {
    Surface(
        onClick = onClick,
        enabled = enabled,
        shape = CircleShape,
        color = if (enabled) container else MaterialTheme.colorScheme.surfaceContainerHigh,
        modifier = Modifier.size(size),
    ) {
        Box(contentAlignment = Alignment.Center) {
            Icon(icon, description, tint = if (enabled) content else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.4f))
        }
    }
}

@Composable
private fun TextKey(label: String, onClick: () -> Unit) {
    Surface(onClick = onClick, shape = CircleShape, color = MaterialTheme.colorScheme.secondaryContainer, modifier = Modifier.size(60.dp)) {
        Box(contentAlignment = Alignment.Center) {
            Text(label, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.onSecondaryContainer)
        }
    }
}

/** Bascule haut / bas (volume ou chaînes). */
@Composable
private fun Rocker(label: String, up: ImageVector, down: ImageVector, onUp: () -> Unit, onDown: () -> Unit) {
    Surface(shape = MaterialTheme.shapes.extraLarge, color = MaterialTheme.colorScheme.surfaceContainerHigh, modifier = Modifier.width(64.dp)) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            IconButton(onClick = onUp, modifier = Modifier.size(64.dp)) { Icon(up, "$label plus") }
            Text(label, style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)
            IconButton(onClick = onDown, modifier = Modifier.size(64.dp)) { Icon(down, "$label moins") }
        }
    }
}

/** Croix de navigation avec OK au centre. */
@Composable
private fun DPad(press: (RemoteKey) -> Unit) {
    Surface(shape = CircleShape, color = MaterialTheme.colorScheme.surfaceContainerHigh, modifier = Modifier.size(196.dp)) {
        Box {
            IconButton(onClick = { press(RemoteKey.UP) }, modifier = Modifier.align(Alignment.TopCenter).size(64.dp)) { Icon(Icons.Filled.KeyboardArrowUp, "Haut", Modifier.size(36.dp)) }
            IconButton(onClick = { press(RemoteKey.DOWN) }, modifier = Modifier.align(Alignment.BottomCenter).size(64.dp)) { Icon(Icons.Filled.KeyboardArrowDown, "Bas", Modifier.size(36.dp)) }
            IconButton(onClick = { press(RemoteKey.LEFT) }, modifier = Modifier.align(Alignment.CenterStart).size(64.dp)) { Icon(Icons.AutoMirrored.Filled.KeyboardArrowLeft, "Gauche", Modifier.size(36.dp)) }
            IconButton(onClick = { press(RemoteKey.RIGHT) }, modifier = Modifier.align(Alignment.CenterEnd).size(64.dp)) { Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, "Droite", Modifier.size(36.dp)) }
            Surface(
                onClick = { press(RemoteKey.OK) },
                shape = CircleShape,
                color = MaterialTheme.colorScheme.primary,
                modifier = Modifier.align(Alignment.Center).size(72.dp).clip(CircleShape),
            ) {
                Box(contentAlignment = Alignment.Center) { Text("OK", color = MaterialTheme.colorScheme.onPrimary, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold) }
            }
        }
    }
}

/** Autorisation par code PIN affiché sur la télé (Sony Bravia 2013-2014). */
@Composable
private fun PinDialog(session: RemoteSession, onDone: (Boolean) -> Unit) {
    val scope = rememberCoroutineScope()
    var pin by remember { mutableStateOf("") }
    var asked by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }
    var msg by remember { mutableStateOf<String?>(null) }
    AlertDialog(
        onDismissRequest = { if (!busy) onDone(false) },
        title = { Text("Autoriser ce téléphone") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    "Ce téléviseur demande une autorisation pour recevoir les touches (flèches, OK…). " +
                        "Touche « Afficher le code » : un code à 4 chiffres apparaît sur la télé, saisis-le ici.",
                    style = MaterialTheme.typography.bodyMedium,
                )
                Button(enabled = !busy, onClick = {
                    busy = true
                    scope.launch {
                        val ok = withContext(Dispatchers.IO) { runCatching { session.requestPin() }.getOrDefault(false) }
                        busy = false
                        asked = ok
                        msg = if (ok) "Regarde l'écran de la télé." else "La télé ne répond pas. Vérifie qu'elle est allumée et que « Réseau → Paramètres de l'appareil distant → Commande à distance » est activé."
                    }
                }) { Text(if (asked) "Afficher un nouveau code" else "Afficher le code") }
                OutlinedTextField(
                    value = pin,
                    onValueChange = { v -> pin = v.filter { it.isDigit() }.take(8) },
                    label = { Text("Code affiché sur la télé") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                )
                msg?.let { Text(it, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary) }
            }
        },
        confirmButton = {
            TextButton(enabled = !busy && pin.length >= 4, onClick = {
                busy = true
                scope.launch {
                    val ok = withContext(Dispatchers.IO) { runCatching { session.confirmPin(pin) }.getOrDefault(false) }
                    busy = false
                    if (ok) onDone(true) else msg = "Code refusé. Demande un nouveau code et recommence."
                }
            }) { Text("Valider") }
        },
        dismissButton = { TextButton(enabled = !busy, onClick = { onDone(false) }) { Text("Annuler") } },
    )
}
