package fr.jeremy.calepin.control

import kotlinx.coroutines.delay
import org.json.JSONObject

/**
 * Décodeur TV d'Orange, piloté sur le Wi-Fi comme sa télécommande
 * (http://<adresse>:8080/remoteControl/cmd). Les appels réseau se font hors du fil principal.
 */
class OrangeDecoder(
    ip: String,
    /** Appelé quand le décodeur a changé d'adresse sur le Wi-Fi (retrouvé par une recherche), pour la garder. */
    private val onNewHost: ((String) -> Unit)? = null,
) {
    @Volatile private var ip: String = ip

    /** Raison du dernier échec, pour l'expliquer à l'utilisateur. */
    @Volatile var problem: String = ""
        private set

    data class Channel(val number: Int, val epgId: String, val names: List<String>)

    companion object {
        const val POWER = 116
        const val OK = 352
        const val BACK = 158
        const val MENU = 139
        const val CH_UP = 402
        const val CH_DOWN = 403
        const val VOL_UP = 115
        const val VOL_DOWN = 114
        const val MUTE = 113
        const val PLAY_PAUSE = 164
        const val GUIDE = 365
        private val DIGITS = (0..9).associateWith { 512 + it }

        /** Chaînes de la TV d'Orange (numéro, identifiant du guide, façons de les nommer). */
        val CHANNELS = listOf(
            Channel(1, "192", listOf("tf1")),
            Channel(2, "4", listOf("france 2", "france2")),
            Channel(3, "80", listOf("france 3", "france3")),
            Channel(4, "78", listOf("france 4", "france4")),
            Channel(5, "47", listOf("france 5", "france5")),
            Channel(6, "118", listOf("m6")),
            Channel(7, "111", listOf("arte")),
            Channel(8, "234", listOf("lcp", "public senat")),
            Channel(9, "119", listOf("w9")),
            Channel(10, "195", listOf("tmc")),
            Channel(11, "446", listOf("tfx")),
            Channel(12, "482", listOf("gulli")),
            Channel(13, "481", listOf("bfm tv", "bfmtv", "bfm")),
            Channel(14, "226", listOf("cnews", "c news")),
            Channel(15, "112", listOf("lci")),
            Channel(16, "2111", listOf("franceinfo", "france info")),
            Channel(17, "458", listOf("cstar", "c star")),
            Channel(18, "4139", listOf("t18")),
            Channel(19, "4138", listOf("novo19", "novo 19")),
            Channel(20, "1404", listOf("tf1 series films", "tf1 series")),
            Channel(21, "1401", listOf("l'equipe", "la chaine l'equipe", "equipe")),
            Channel(22, "1403", listOf("6ter")),
            Channel(23, "1402", listOf("rmc story")),
            Channel(24, "1400", listOf("rmc decouverte")),
            Channel(25, "1399", listOf("rmc life")),
            Channel(33, "205", listOf("tv5monde", "tv5 monde", "tv5")),
            Channel(35, "191", listOf("teva")),
            Channel(36, "145", listOf("paris premiere")),
            Channel(37, "225", listOf("tv breizh")),
            Channel(40, "34", listOf("canal+", "canal plus", "canal")),
        )

        /** Chaîne citée dans un texte déjà normalisé (minuscules, sans accents) ; le nom le plus long l'emporte. */
        fun findChannel(norm: String): Channel? =
            CHANNELS.flatMap { c -> c.names.map { it to c } }
                .sortedByDescending { it.first.length }
                .firstOrNull { (name, _) -> Regex("(^|[^a-z0-9])" + Regex.escape(name) + "($|[^a-z0-9+])").containsMatchIn(norm) }
                ?.second

        /** Vrai si un décodeur Orange répond à cette adresse. */
        fun probe(host: String): Boolean {
            val r = Http.get("http://$host:8080/remoteControl/cmd?operation=10", timeoutMs = 1200, connectMs = 400) ?: return false
            return "activeStandbyState" in r || "osdContext" in r || "friendlyName" in r
        }
    }

    private fun cmd(query: String, timeoutMs: Int = 4000, connectMs: Int = timeoutMs) =
        Http.get("http://$ip:8080/remoteControl/cmd?$query", timeoutMs = timeoutMs, connectMs = connectMs)

    /** État lu une seule fois : vrai = allumé, faux = en veille, null = pas de réponse. */
    private fun statusOnce(connectMs: Int, readMs: Int): Boolean? {
        val r = cmd("operation=10", readMs, connectMs) ?: return null
        val data = runCatching { JSONObject(r).optJSONObject("result")?.optJSONObject("data") }.getOrNull() ?: return null
        // Adresse matérielle gardée : elle sert à réveiller le décodeur s'il ne répond plus
        data.optString("macAddress").takeIf { it.isNotBlank() }?.let { LanNet.rememberMac(ip, it) }
        return data.optString("activeStandbyState", "1") == "0"
    }

    /**
     * État : vrai = allumé, faux = en veille, null = injoignable. Plusieurs essais avec des délais croissants :
     * un décodeur en veille ou un téléphone dont le Wi-Fi sort d'économie d'énergie répond parfois lentement.
     */
    fun isOn(): Boolean? {
        for ((c, r) in listOf(1500 to 2500, 2500 to 4000, 4000 to 6000)) {
            statusOnce(c, r)?.let { problem = ""; return it }
        }
        return null
    }

    /** Touche de la télécommande, avec un second essai si le premier n'aboutit pas. */
    fun key(code: Int): Boolean =
        cmd("operation=01&key=$code&mode=0") != null || cmd("operation=01&key=$code&mode=0", 6000, 3000) != null

    /** Paquet « magique » envoyé sur le Wi-Fi : réveille le décodeur si sa veille le permet. */
    private fun wake() {
        val mac = LanNet.macFor(ip) ?: return
        TvDrivers.wakeOnLan(mac, ip)
    }

    /** Décodeur qui ne répond plus à son adresse : on le cherche sur le Wi-Fi (son adresse a pu changer). */
    private suspend fun rediscover(): Boolean {
        val found = runCatching { LanScanner.scan().decoders }.getOrDefault(emptyList())
        val other = found.firstOrNull { it != ip } ?: return false
        ip = other
        onNewHost?.invoke(other)
        return true
    }

    /** Joint le décodeur coûte que coûte : essais, réveil à distance, puis recherche sur le Wi-Fi. */
    private suspend fun reach(): Boolean? {
        isOn()?.let { return it }
        // Pas de réponse : réveil à distance puis nouvelle attente (jusqu'à ~25 s)
        wake()
        repeat(8) {
            delay(2500)
            statusOnce(2000, 3000)?.let { problem = ""; return it }
            if (it == 3) wake()
        }
        if (rediscover()) isOn()?.let { return it }
        problem = "Le décodeur ne répond pas sur le Wi-Fi. S'il est en « Économie d'énergie » (veille profonde : Réglages > Décodeur > Économie d'énergie), " +
            "il coupe son réseau et met jusqu'à 2 minutes à se réveiller : désactive ce mode pour pouvoir l'allumer depuis le téléphone."
        return null
    }

    suspend fun powerOn(): Boolean {
        val on = reach() ?: return false
        if (!on) {
            key(POWER)
            // On vérifie qu'il s'allume vraiment (sinon un second appui)
            // On attend qu'il annonce être allumé (sans rappuyer : un second appui le remettrait en veille)
            var ok = false
            for (i in 0 until 8) {
                delay(1500)
                if (statusOnce(1500, 3000) == true) { ok = true; break }
            }
            delay(800)
            key(OK) // valide l'écran de démarrage éventuel
            if (!ok) return statusOnce(2000, 4000) != false
        }
        return true
    }

    suspend fun powerOff(): Boolean {
        val on = reach() ?: return false
        if (on) {
            key(POWER)
            delay(1500)
            if (statusOnce(1500, 3000) == true) key(POWER)
        }
        return true
    }

    suspend fun channelNumber(n: Int): Boolean {
        n.toString().forEach { ch ->
            if (!key(DIGITS.getValue(ch.digitToInt()))) return false
            delay(180)
        }
        return true
    }

    fun channel(c: Channel): Boolean =
        cmd("operation=09&epg_id=${c.epgId.padStart(10, '*')}&uui=1") != null
}
