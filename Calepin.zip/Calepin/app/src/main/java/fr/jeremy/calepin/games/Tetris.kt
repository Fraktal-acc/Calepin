package fr.jeremy.calepin.games

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowLeft
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.VerticalAlignBottom
import androidx.compose.material3.MaterialTheme
import fr.jeremy.calepin.i18n.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp

/** Les 7 pièces, dans une boîte de 4 (I) ou 3 cases. */
private val SHAPES: List<Pair<Int, List<Pair<Int, Int>>>> = listOf(
    4 to listOf(0 to 1, 1 to 1, 2 to 1, 3 to 1), // I
    2 to listOf(0 to 0, 1 to 0, 0 to 1, 1 to 1), // O
    3 to listOf(1 to 0, 0 to 1, 1 to 1, 2 to 1), // T
    3 to listOf(1 to 0, 2 to 0, 0 to 1, 1 to 1), // S
    3 to listOf(0 to 0, 1 to 0, 1 to 1, 2 to 1), // Z
    3 to listOf(0 to 0, 0 to 1, 1 to 1, 2 to 1), // J
    3 to listOf(2 to 0, 0 to 1, 1 to 1, 2 to 1), // L
)

/** Rotations précalculées : ROT[type][rot] = cases. Rotation horaire (x, y) → (s-1-y, x). */
private val ROT: List<List<List<Pair<Int, Int>>>> = SHAPES.map { (s, cells) ->
    generateSequence(cells) { cur -> cur.map { (x, y) -> (s - 1 - y) to x } }.take(4).toList()
}

private class TetrisState {
    val w = 10
    val h = 20
    val board = Array(h) { IntArray(w) } // 0 = vide, sinon type + 1
    var type = 0
    var rot = 0
    var px = 0
    var py = 0
    var next = 0
    private val bag = ArrayDeque<Int>()
    var score by mutableIntStateOf(0)
    var lines by mutableIntStateOf(0)
    var level by mutableIntStateOf(0)
    var over by mutableStateOf(false)
    var frame by mutableIntStateOf(0)
    private var acc = 0f

    private fun draw(): Int {
        if (bag.isEmpty()) bag.addAll((0 until 7).shuffled())
        return bag.removeFirst()
    }

    fun reset() {
        board.forEach { it.fill(0) }
        bag.clear()
        score = 0; lines = 0; level = 0; acc = 0f; over = false
        next = draw()
        spawn()
    }

    fun cells(t: Int = type, r: Int = rot, x: Int = px, y: Int = py) = ROT[t][r].map { (cx, cy) -> (x + cx) to (y + cy) }

    private fun fits(t: Int, r: Int, x: Int, y: Int) = cells(t, r, x, y).all { (cx, cy) ->
        cx in 0 until w && cy < h && (cy < 0 || board[cy][cx] == 0)
    }

    private fun spawn() {
        type = next
        next = draw()
        rot = 0
        px = (w - SHAPES[type].first) / 2
        py = if (type == 0) -1 else 0
        if (!fits(type, rot, px, py)) over = true
        frame++
    }

    private fun interval() = (800 - level * 70).coerceAtLeast(90).toFloat()

    /** Partie en cours, pour la reprendre plus tard. */
    fun save(): String = org.json.JSONObject()
        .put("board", org.json.JSONArray(board.flatMap { it.toList() }))
        .put("type", type).put("rot", rot).put("px", px).put("py", py).put("next", next)
        .put("bag", org.json.JSONArray(bag.toList()))
        .put("score", score).put("lines", lines).put("level", level)
        .toString()

    fun restore(text: String?): Boolean = runCatching {
        val o = org.json.JSONObject(text ?: return false)
        val b = o.getJSONArray("board")
        if (b.length() != w * h) return false
        for (i in 0 until w * h) board[i / w][i % w] = b.getInt(i)
        type = o.getInt("type"); rot = o.getInt("rot"); px = o.getInt("px"); py = o.getInt("py"); next = o.getInt("next")
        bag.clear()
        val bg = o.getJSONArray("bag")
        for (i in 0 until bg.length()) bag.addLast(bg.getInt(i))
        score = o.getInt("score"); lines = o.getInt("lines"); level = o.getInt("level")
        acc = 0f; over = false; frame++
        true
    }.getOrDefault(false)

    fun update(dtMs: Float) {
        if (over) return
        acc += dtMs
        while (acc >= interval() && !over) {
            acc -= interval()
            if (fits(type, rot, px, py + 1)) py++ else lock()
            frame++
        }
    }

    fun move(dx: Int) {
        if (!over && fits(type, rot, px + dx, py)) { px += dx; frame++ }
    }

    fun rotate() {
        if (over || type == 1) return
        val r = (rot + 1) % 4
        for (kick in listOf(0, -1, 1, -2, 2)) {
            if (fits(type, r, px + kick, py)) { rot = r; px += kick; frame++; return }
        }
        if (fits(type, r, px, py - 1)) { rot = r; py--; frame++ }
    }

    fun softDrop() {
        if (over) return
        if (fits(type, rot, px, py + 1)) { py++; score += 1; acc = 0f } else lock()
        frame++
    }

    fun hardDrop() {
        if (over) return
        var d = 0
        while (fits(type, rot, px, py + 1)) { py++; d++ }
        score += d * 2
        lock()
        frame++
    }

    fun ghostY(): Int {
        var y = py
        while (fits(type, rot, px, y + 1)) y++
        return y
    }

    private fun lock() {
        for ((cx, cy) in cells()) {
            if (cy < 0) { over = true; return }
            board[cy][cx] = type + 1
        }
        val full = (0 until h).filter { y -> board[y].all { it != 0 } }
        if (full.isNotEmpty()) {
            val kept = (0 until h).filter { it !in full }.map { board[it].copyOf() }
            val empty = List(full.size) { IntArray(w) }
            (empty + kept).forEachIndexed { y, row -> board[y] = row }
            score += listOf(0, 40, 100, 300, 1200)[full.size] * (level + 1)
            lines += full.size
            level = lines / 10
        }
        acc = 0f
        spawn()
    }
}

@Composable
internal fun TetrisGame() {
    val ctx = LocalContext.current
    // Une partie laissée en cours reprend là où elle s'était arrêtée (en pause)
    val g = remember { TetrisState().apply { if (!restore(GameSaves.load(ctx, "tetris"))) reset() } }
    var paused by remember { mutableStateOf(true) }
    SaveOnLeave("tetris", onPause = { paused = true }) { if (g.over) null else g.save() }
    var best by remember { mutableIntStateOf(GameScores.best(ctx, "tetris")) }
    var record by remember { mutableStateOf(false) }

    GameLoop(running = !paused && !g.over) { g.update(it) }
    LaunchedEffect(g.over) {
        if (g.over) {
            record = GameScores.submit(ctx, "tetris", g.score)
            if (record) best = g.score
        }
    }

    fun act(block: () -> Unit) {
        if (g.over) return
        if (paused) { paused = false; return }
        block()
    }

    Column(Modifier.fillMaxSize()) {
        ScoreBar(g.score, best, extra = "Niveau ${g.level + 1} · ${g.lines} lignes")
        Row(
            Modifier
                .weight(1f)
                .fillMaxWidth(),
            horizontalArrangement = Arrangement.Center,
        ) {
            Box(
                Modifier
                    .fillMaxHeight()
                    .aspectRatio(0.5f, matchHeightConstraintsFirst = true)
                    .pointerInput(Unit) {
                        detectTapGestures {
                            when {
                                g.over -> { g.reset(); record = false; paused = false }
                                paused -> paused = false
                                else -> g.rotate()
                            }
                        }
                    }
                    .pointerInput(Unit) {
                        // Glisser à gauche/droite : déplacer ; vers le bas : descendre
                        var ax = 0f
                        var ay = 0f
                        detectDragGestures(onDragStart = { ax = 0f; ay = 0f }) { change, amount ->
                            change.consume()
                            if (paused || g.over) return@detectDragGestures
                            val cell = size.width / 10f
                            ax += amount.x
                            ay += amount.y
                            while (ax > cell) { g.move(1); ax -= cell }
                            while (ax < -cell) { g.move(-1); ax += cell }
                            while (ay > cell) { g.softDrop(); ay -= cell }
                        }
                    },
            ) {
                Canvas(Modifier.fillMaxSize()) {
                    g.frame
                    val c = size.width / g.w
                    drawRoundRect(BoardBackground, cornerRadius = CornerRadius(8f))
                    for (x in 1 until g.w) drawLine(GridLine, Offset(x * c, 0f), Offset(x * c, size.height))
                    for (y in 1 until g.h) drawLine(GridLine, Offset(0f, y * c), Offset(size.width, y * c))
                    for (y in 0 until g.h) for (x in 0 until g.w) {
                        val v = g.board[y][x]
                        if (v != 0) block(GamePalette[v - 1], x, y, c)
                    }
                    if (!g.over) {
                        val gy = g.ghostY()
                        g.cells(y = gy).forEach { (x, y) -> if (y >= 0) block(GamePalette[g.type].copy(alpha = 0.22f), x, y, c) }
                        g.cells().forEach { (x, y) -> if (y >= 0) block(GamePalette[g.type], x, y, c) }
                    }
                }
                when {
                    g.over -> Overlay(if (record) "Nouveau record : ${g.score} !" else "Partie terminée", "Touchez pour rejouer")
                    paused -> Overlay(
                        if (g.score == 0) "Tetris" else "Pause",
                        "Touchez la grille : tourner\nGlissez : déplacer ou descendre\nTouchez pour jouer",
                    )
                }
            }
            Spacer(Modifier.width(10.dp))
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("Suivante", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Canvas(Modifier.size(56.dp).padding(top = 4.dp)) {
                    g.frame
                    val c = size.width / 4
                    val (s, cells) = SHAPES[g.next]
                    val off = (4 - s) / 2f
                    cells.forEach { (x, y) -> block(GamePalette[g.next], x, y, c, off, if (s == 4) 0.5f else 1f) }
                }
                Spacer(Modifier.size(12.dp))
                PadButton(if (paused) Icons.Filled.PlayArrow else Icons.Filled.Pause, if (paused) "Jouer" else "Pause", modifier = Modifier.size(48.dp)) {
                    if (!g.over) paused = !paused
                }
            }
        }
        Spacer(Modifier.size(10.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
            PadButton(Icons.AutoMirrored.Filled.KeyboardArrowLeft, "Gauche", repeat = true) { act { g.move(-1) } }
            PadButton(Icons.Filled.Refresh, "Tourner") { act { g.rotate() } }
            PadButton(Icons.AutoMirrored.Filled.KeyboardArrowRight, "Droite", repeat = true) { act { g.move(1) } }
            PadButton(Icons.Filled.KeyboardArrowDown, "Descendre", repeat = true) { act { g.softDrop() } }
            PadButton(Icons.Filled.VerticalAlignBottom, "Lâcher") { act { g.hardDrop() } }
        }
    }
}

private fun DrawScope.block(color: Color, x: Int, y: Int, c: Float, offX: Float = 0f, offY: Float = 0f) {
    val inset = c * 0.06f
    drawRoundRect(
        color,
        Offset((x + offX) * c + inset, (y + offY) * c + inset),
        Size(c - 2 * inset, c - 2 * inset),
        CornerRadius(c * 0.18f),
    )
    // Petit reflet pour le relief
    drawRect(Color.White.copy(alpha = 0.18f * color.alpha), Offset((x + offX) * c + inset, (y + offY) * c + inset), Size(c - 2 * inset, c * 0.18f))
}
