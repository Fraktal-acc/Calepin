package fr.jeremy.calepin.radio

import android.content.ComponentName
import android.content.Context
import android.net.Uri
import android.os.Handler
import android.os.Looper
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.google.common.util.concurrent.ListenableFuture
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

/** Pilote la radio jouée par [RadioService] ; l'état est observé par les écrans. */
object RadioPlayer {
    private val _current = MutableStateFlow<Station?>(null)
    val current: StateFlow<Station?> = _current
    private val _playing = MutableStateFlow(false)
    val playing: StateFlow<Boolean> = _playing
    private val _buffering = MutableStateFlow(false)
    val buffering: StateFlow<Boolean> = _buffering
    /** Titre du morceau en cours, quand la radio le diffuse. */
    private val _track = MutableStateFlow<String?>(null)
    val track: StateFlow<String?> = _track
    private val _error = MutableStateFlow<String?>(null)
    val error: StateFlow<String?> = _error

    private val main = Handler(Looper.getMainLooper())
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var controller: MediaController? = null
    private var future: ListenableFuture<MediaController>? = null

    private val listener = object : Player.Listener {
        override fun onIsPlayingChanged(isPlaying: Boolean) {
            _playing.value = isPlaying
            if (isPlaying) _error.value = null
        }

        override fun onPlaybackStateChanged(state: Int) {
            _buffering.value = state == Player.STATE_BUFFERING
            if (state == Player.STATE_IDLE || state == Player.STATE_ENDED) _playing.value = false
        }

        override fun onPlayerError(error: PlaybackException) {
            _playing.value = false
            _buffering.value = false
            _error.value = "Cette radio ne répond pas pour le moment. Essaie une autre radio."
        }

        override fun onMediaMetadataChanged(m: MediaMetadata) {
            val t = listOfNotNull(m.artist?.toString(), m.title?.toString())
                .filter { it.isNotBlank() && it != _current.value?.name && it != _current.value?.country }
                .joinToString(" – ")
            _track.value = t.ifBlank { null }
        }
    }

    private fun onMain(block: () -> Unit) {
        if (Looper.myLooper() == Looper.getMainLooper()) block() else main.post(block)
    }

    private fun connect(ctx: Context, then: (MediaController) -> Unit) {
        val c = controller
        if (c != null && c.isConnected) { then(c); return }
        val app = ctx.applicationContext
        val f = future ?: MediaController.Builder(app, SessionToken(app, ComponentName(app, RadioService::class.java)))
            .buildAsync().also { future = it }
        f.addListener({
            try {
                val got = f.get()
                if (controller !== got) {
                    controller = got
                    got.addListener(listener)
                }
                then(got)
            } catch (e: Exception) {
                future = null
                controller = null
                _error.value = "Lecture impossible pour le moment."
            }
        }, ContextCompat.getMainExecutor(app))
    }

    /** À l'ouverture d'un écran : retrouve la radio qui joue peut-être déjà (appli relancée). */
    fun attach(ctx: Context) = onMain {
        connect(ctx) { c ->
            _playing.value = c.isPlaying
            _buffering.value = c.playbackState == Player.STATE_BUFFERING
            if (c.mediaItemCount > 0 && _current.value == null) _current.value = RadioPrefs.last(ctx)
        }
    }

    fun play(ctx: Context, s: Station) = onMain {
        _current.value = s
        _error.value = null
        _track.value = null
        _buffering.value = true
        RadioPrefs.setLast(ctx.applicationContext, s)
        connect(ctx) { c ->
            c.setMediaItem(item(s))
            c.prepare()
            c.play()
        }
        if (s.uuid.isNotEmpty()) scope.launch { RadioApi.click(s.uuid) }
    }

    fun toggle(ctx: Context) = onMain {
        connect(ctx) { c ->
            if (c.isPlaying) {
                c.pause()
            } else {
                val s = _current.value ?: RadioPrefs.last(ctx) ?: return@connect
                // Une radio en direct : on relance le flux plutôt que de reprendre en retard
                _current.value = s
                c.setMediaItem(item(s))
                c.prepare()
                c.play()
            }
        }
    }

    /** « Remets la radio » : relance la dernière radio écoutée. Faux s'il n'y en a pas encore. */
    fun resumeLast(ctx: Context): Boolean {
        val s = _current.value ?: RadioPrefs.last(ctx) ?: return false
        play(ctx, s)
        return true
    }

    fun stop(ctx: Context) = onMain {
        controller?.let { c ->
            c.stop()
            c.clearMediaItems()
        }
        _current.value = null
        _playing.value = false
        _buffering.value = false
        _track.value = null
    }

    private fun item(s: Station): MediaItem {
        val uri = Uri.parse(s.url)
        val meta = MediaMetadata.Builder()
            .setTitle(s.name)
            .setArtist(s.country.ifBlank { null })
            .apply { if (s.favicon.startsWith("http")) setArtworkUri(Uri.parse(s.favicon)) }
            .build()
        return MediaItem.Builder()
            .setMediaId(s.uuid.ifEmpty { s.url })
            .setUri(uri)
            .setRequestMetadata(MediaItem.RequestMetadata.Builder().setMediaUri(uri).build())
            .setMediaMetadata(meta)
            .build()
    }
}
