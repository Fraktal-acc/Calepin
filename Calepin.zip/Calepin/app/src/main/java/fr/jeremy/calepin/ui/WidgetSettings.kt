package fr.jeremy.calepin.ui

import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.widget.Toast
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Cloud
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.SettingsRemote
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.TouchApp
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import fr.jeremy.calepin.i18n.I18n
import fr.jeremy.calepin.i18n.RawText
import fr.jeremy.calepin.i18n.Text
import kotlinx.coroutines.delay

/** Un widget de Calepin pour l'écran d'accueil. */
private class WidgetKind(val cls: Class<*>, val name: String, val desc: String, val icon: ImageVector)

private fun widgetKinds(): List<WidgetKind> = buildList {
    add(WidgetKind(fr.jeremy.calepin.widgets.QuickWidget::class.java, "Raccourcis", "Nouvelle note, mémo vocal, assistant en un geste", Icons.Filled.TouchApp))
    add(WidgetKind(fr.jeremy.calepin.widgets.NotesWidget::class.java, "Notes", "Les dernières notes, à ouvrir d'un toucher", Icons.Filled.Description))
    add(WidgetKind(fr.jeremy.calepin.widgets.AgendaWidget::class.java, "Agenda", "Les prochains rendez-vous", Icons.Filled.CalendarMonth))
    add(WidgetKind(fr.jeremy.calepin.widgets.WeatherWidget::class.java, "Météo", "Le temps qu'il fait et la suite de la journée", Icons.Filled.Cloud))
    add(WidgetKind(fr.jeremy.calepin.widgets.ShiftWidget::class.java, "Prochaine vacation", "Le prochain poste du planning de travail", Icons.Filled.Schedule))
    if (fr.jeremy.calepin.BuildConfig.AI) add(WidgetKind(fr.jeremy.calepin.widgets.RemoteWidget::class.java, "Télécommande", "Télé, lumières et scénarios de la maison", Icons.Filled.SettingsRemote))
}

private object WidgetInstall {
    fun component(ctx: Context, cls: Class<*>) = ComponentName(ctx, cls)

    fun installed(ctx: Context, cls: Class<*>): Boolean = try {
        ctx.packageManager.getComponentEnabledSetting(component(ctx, cls)) != PackageManager.COMPONENT_ENABLED_STATE_DISABLED
    } catch (_: Exception) { true }

    fun setInstalled(ctx: Context, cls: Class<*>, on: Boolean) {
        try {
            ctx.packageManager.setComponentEnabledSetting(
                component(ctx, cls),
                if (on) PackageManager.COMPONENT_ENABLED_STATE_DEFAULT else PackageManager.COMPONENT_ENABLED_STATE_DISABLED,
                PackageManager.DONT_KILL_APP,
            )
        } catch (_: Exception) { }
        if (on) fr.jeremy.calepin.widgets.Widgets.refreshAll(ctx)
    }

    /** Nombre de ces widgets posés sur l'écran d'accueil. */
    fun placed(ctx: Context, cls: Class<*>): Int = try {
        AppWidgetManager.getInstance(ctx).getAppWidgetIds(component(ctx, cls)).size
    } catch (_: Exception) { 0 }

    /** Demande au lanceur de poser le widget sur l'écran d'accueil ; false si le lanceur ne sait pas le faire. */
    fun pin(ctx: Context, cls: Class<*>): Boolean {
        if (Build.VERSION.SDK_INT < 26) return false
        return try {
            val mgr = AppWidgetManager.getInstance(ctx)
            mgr.isRequestPinAppWidgetSupported && mgr.requestPinAppWidget(component(ctx, cls), null, null)
        } catch (_: Exception) { false }
    }
}

/**
 * Paramètres → Widgets : installer (proposer dans la liste des widgets du téléphone) ou désinstaller chaque widget,
 * et le poser directement sur l'écran d'accueil.
 */
@Composable
fun WidgetSettings() {
    val ctx = LocalContext.current
    var version by remember { mutableIntStateOf(0) }
    // Les widgets posés depuis le lanceur apparaissent quelques secondes plus tard
    LaunchedEffect(Unit) { while (true) { delay(2000); version++ } }
    var confirmRemove by remember { mutableStateOf<WidgetKind?>(null) }
    Text(
        "Un widget installé apparaît dans la liste des widgets du téléphone (appui long sur l'écran d'accueil → Widgets). " +
            "Désinstallé, il disparaît de cette liste et de l'écran d'accueil.",
        style = MaterialTheme.typography.bodySmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
    )
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        widgetKinds().forEach { w ->
            val installed = remember(version) { WidgetInstall.installed(ctx, w.cls) }
            val placed = remember(version) { WidgetInstall.placed(ctx, w.cls) }
            Surface(shape = MaterialTheme.shapes.medium, color = MaterialTheme.colorScheme.surfaceContainerLow, modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(w.icon, null, tint = if (installed) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant)
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(w.name, style = MaterialTheme.typography.titleSmall)
                            Text(w.desc, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            RawText(
                                when {
                                    !installed -> I18n.tr("Désinstallé")
                                    placed == 0 -> I18n.tr("Installé · pas sur l'écran d'accueil")
                                    placed == 1 -> I18n.tr("Installé · 1 sur l'écran d'accueil")
                                    else -> I18n.tr("Installé · {0} sur l'écran d'accueil").replace("{0}", placed.toString())
                                },
                                style = MaterialTheme.typography.labelSmall,
                                color = if (installed) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                        Switch(
                            checked = installed,
                            onCheckedChange = { on ->
                                if (!on && placed > 0) confirmRemove = w
                                else { WidgetInstall.setInstalled(ctx, w.cls, on); version++ }
                            },
                        )
                    }
                    OutlinedButton(
                        onClick = {
                            if (!installed) WidgetInstall.setInstalled(ctx, w.cls, true)
                            if (!WidgetInstall.pin(ctx, w.cls)) {
                                I18n.toast(ctx, "Ton écran d'accueil ne permet pas de l'ajouter d'ici : appui long sur l'écran d'accueil → Widgets → Calepin.", Toast.LENGTH_LONG).show()
                            }
                            version++
                        },
                        modifier = Modifier.fillMaxWidth(),
                    ) {
                        Icon(Icons.Filled.Add, null, Modifier.size(18.dp))
                        Spacer(Modifier.width(8.dp))
                        Text("Ajouter à l'écran d'accueil")
                    }
                }
            }
        }
    }
    confirmRemove?.let { w ->
        AlertDialog(
            onDismissRequest = { confirmRemove = null },
            title = { Text("Désinstaller ce widget ?") },
            text = { Text("Il sera retiré de l'écran d'accueil et de la liste des widgets. Tu pourras le réinstaller ici à tout moment.") },
            confirmButton = {
                TextButton(onClick = { WidgetInstall.setInstalled(ctx, w.cls, false); confirmRemove = null; version++ }) { Text("Désinstaller") }
            },
            dismissButton = { TextButton(onClick = { confirmRemove = null }) { Text("Annuler") } },
        )
    }
}
