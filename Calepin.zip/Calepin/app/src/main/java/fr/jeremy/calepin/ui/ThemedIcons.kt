package fr.jeremy.calepin.ui

import android.os.Build
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.CutCornerShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Contacts
import androidx.compose.material.icons.filled.EditNote
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.BusinessCenter
import androidx.compose.material.icons.filled.SettingsRemote
import androidx.compose.material.icons.filled.SmartToy
import androidx.compose.material.icons.filled.SportsEsports
import androidx.compose.material.icons.outlined.CalendarMonth
import androidx.compose.material.icons.outlined.Contacts
import androidx.compose.material.icons.outlined.EditNote
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Palette
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material.icons.outlined.BusinessCenter
import androidx.compose.material.icons.outlined.SettingsRemote
import androidx.compose.material.icons.outlined.SmartToy
import androidx.compose.material.icons.outlined.SportsEsports
import androidx.compose.material.icons.rounded.CalendarMonth
import androidx.compose.material.icons.rounded.Contacts
import androidx.compose.material.icons.rounded.EditNote
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.Palette
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.BusinessCenter
import androidx.compose.material.icons.rounded.SettingsRemote
import androidx.compose.material.icons.rounded.SmartToy
import androidx.compose.material.icons.rounded.SportsEsports
import androidx.compose.material.icons.sharp.CalendarMonth
import androidx.compose.material.icons.sharp.Contacts
import androidx.compose.material.icons.sharp.EditNote
import androidx.compose.material.icons.sharp.Home
import androidx.compose.material.icons.sharp.Palette
import androidx.compose.material.icons.sharp.Settings
import androidx.compose.material.icons.sharp.BusinessCenter
import androidx.compose.material.icons.sharp.SettingsRemote
import androidx.compose.material.icons.sharp.SmartToy
import androidx.compose.material.icons.sharp.SportsEsports
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Paint
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

/** Icônes de l'accueil, chacune dessinée dans les quatre familles Material (pleine, contour, arrondie, anguleuse). */
enum class AppIcon(val filled: ImageVector, val outlined: ImageVector, val rounded: ImageVector, val sharp: ImageVector) {
    NOTES(Icons.Filled.EditNote, Icons.Outlined.EditNote, Icons.Rounded.EditNote, Icons.Sharp.EditNote),
    AGENDA(Icons.Filled.CalendarMonth, Icons.Outlined.CalendarMonth, Icons.Rounded.CalendarMonth, Icons.Sharp.CalendarMonth),
    ASSISTANT(Icons.Filled.SmartToy, Icons.Outlined.SmartToy, Icons.Rounded.SmartToy, Icons.Sharp.SmartToy),
    CONTACTS(Icons.Filled.Contacts, Icons.Outlined.Contacts, Icons.Rounded.Contacts, Icons.Sharp.Contacts),
    REMOTE(Icons.Filled.SettingsRemote, Icons.Outlined.SettingsRemote, Icons.Rounded.SettingsRemote, Icons.Sharp.SettingsRemote),
    HOME(Icons.Filled.Home, Icons.Outlined.Home, Icons.Rounded.Home, Icons.Sharp.Home),
    GAMES(Icons.Filled.SportsEsports, Icons.Outlined.SportsEsports, Icons.Rounded.SportsEsports, Icons.Sharp.SportsEsports),
    APPEARANCE(Icons.Filled.Palette, Icons.Outlined.Palette, Icons.Rounded.Palette, Icons.Sharp.Palette),
    SETTINGS(Icons.Filled.Settings, Icons.Outlined.Settings, Icons.Rounded.Settings, Icons.Sharp.Settings),
    PRO(Icons.Filled.BusinessCenter, Icons.Outlined.BusinessCenter, Icons.Rounded.BusinessCenter, Icons.Sharp.BusinessCenter),
}

private val GOLD = Color(0xFFD4AF37)

@Composable
private fun accentOf(tone: Int): Color = when (tone % 3) {
    0 -> MaterialTheme.colorScheme.primary
    1 -> MaterialTheme.colorScheme.secondary
    else -> MaterialTheme.colorScheme.tertiary
}

/** Contour à coins coupés (octogone), en coordonnées de dessin. */
private fun cutPath(w: Float, h: Float, c: Float, inset: Float = 0f) = android.graphics.Path().apply {
    val l = inset; val t = inset; val r = w - inset; val b = h - inset
    moveTo(l + c, t); lineTo(r - c, t); lineTo(r, t + c); lineTo(r, b - c)
    lineTo(r - c, b); lineTo(l + c, b); lineTo(l, b - c); lineTo(l, t + c); close()
}

/** Trait lumineux (halo) façon néon. Le halo apparaît à partir d'Android 9. */
private fun DrawScope.neonStroke(path: android.graphics.Path, color: Color, width: Float, glow: Float) {
    drawIntoCanvas { canvas ->
        val paint = Paint().asFrameworkPaint().apply {
            isAntiAlias = true
            style = android.graphics.Paint.Style.STROKE
            strokeWidth = width
            this.color = color.toArgb()
            if (Build.VERSION.SDK_INT >= 28) setShadowLayer(glow, 0f, 0f, color.toArgb())
        }
        if (Build.VERSION.SDK_INT < 28) {
            // Halo simulé : traits plus larges et transparents
            val halo = android.graphics.Paint(paint).apply { strokeWidth = width * 4; this.color = color.copy(alpha = 0.18f).toArgb() }
            canvas.nativeCanvas.drawPath(path, halo)
        }
        canvas.nativeCanvas.drawPath(path, paint)
    }
}

/**
 * Icône de rubrique dans le style choisi (ou celui du thème).
 * [tone] alterne les trois couleurs du thème d'une tuile à l'autre.
 */
@Composable
fun ThemedIcon(icon: AppIcon, tone: Int, box: Dp, style: IconStyle = LocalLook.current.icons) {
    val cs = MaterialTheme.colorScheme
    val accent = accentOf(tone)
    val glyph = box * 0.54f
    when (style) {
        IconStyle.AUTO, IconStyle.PLEIN -> {
            val (bg, fg) = when (tone % 3) {
                0 -> cs.primaryContainer to cs.onPrimaryContainer
                1 -> cs.secondaryContainer to cs.onSecondaryContainer
                else -> cs.tertiaryContainer to cs.onTertiaryContainer
            }
            Box(Modifier.size(box).clip(MaterialTheme.shapes.medium).background(bg), contentAlignment = Alignment.Center) {
                Icon(icon.filled, null, tint = fg, modifier = Modifier.size(glyph))
            }
        }

        IconStyle.CONTOUR -> Box(
            Modifier.size(box).border(1.5.dp, accent, MaterialTheme.shapes.medium),
            contentAlignment = Alignment.Center,
        ) { Icon(icon.outlined, null, tint = accent, modifier = Modifier.size(glyph)) }

        IconStyle.MINIMAL -> Box(Modifier.size(box), contentAlignment = Alignment.Center) {
            Icon(icon.rounded, null, tint = accent, modifier = Modifier.size(box * 0.72f))
        }

        IconStyle.BULLE -> {
            val other = when (tone % 3) { 0 -> cs.tertiary; 1 -> cs.primary; else -> cs.secondary }
            Box(
                Modifier
                    .size(box)
                    .clip(RoundedCornerShape(percent = 34))
                    .background(Brush.linearGradient(listOf(lerp(accent, Color.White, 0.15f), lerp(accent, other, 0.65f))))
                    .drawBehind {
                        // Reflet en haut, comme une bulle de verre
                        drawCircle(Color.White.copy(alpha = 0.22f), radius = size.width * 0.42f, center = Offset(size.width * 0.3f, size.height * 0.12f))
                    },
                contentAlignment = Alignment.Center,
            ) { Icon(icon.rounded, null, tint = Color.White, modifier = Modifier.size(glyph)) }
        }

        IconStyle.NEON -> Box(
            Modifier
                .size(box)
                .drawBehind {
                    val c = size.minDimension * 0.22f
                    drawPath(androidx.compose.ui.graphics.Path().apply {
                        moveTo(c, 0f); lineTo(size.width - c, 0f); lineTo(size.width, c); lineTo(size.width, size.height - c)
                        lineTo(size.width - c, size.height); lineTo(c, size.height); lineTo(0f, size.height - c); lineTo(0f, c); close()
                    }, accent.copy(alpha = 0.10f))
                    neonStroke(cutPath(size.width, size.height, c, 1.5f), accent, 2.dp.toPx(), 9.dp.toPx())
                },
            contentAlignment = Alignment.Center,
        ) {
            if (Build.VERSION.SDK_INT >= 31) {
                Icon(icon.outlined, null, tint = accent, modifier = Modifier.size(glyph).blur(5.dp))
            }
            Icon(icon.outlined, null, tint = lerp(accent, Color.White, 0.35f), modifier = Modifier.size(glyph))
        }

        IconStyle.GRIMOIRE -> {
            val shape = CutCornerShape(percent = 30)
            Box(
                Modifier
                    .size(box)
                    .clip(shape)
                    .background(Brush.radialGradient(listOf(lerp(accent, Color.Black, 0.35f), lerp(accent, Color.Black, 0.82f))))
                    .border(1.5.dp, GOLD, shape)
                    .padding(4.dp)
                    .border(0.75.dp, GOLD.copy(alpha = 0.55f), shape)
                    .drawBehind {
                        // Petites gemmes aux quatre points cardinaux
                        val r = 1.6.dp.toPx()
                        listOf(Offset(size.width / 2, 2.5f * r), Offset(size.width / 2, size.height - 2.5f * r), Offset(2.5f * r, size.height / 2), Offset(size.width - 2.5f * r, size.height / 2))
                            .forEach { drawCircle(GOLD, r, it) }
                    },
                contentAlignment = Alignment.Center,
            ) { Icon(icon.sharp, null, tint = GOLD, modifier = Modifier.size(glyph * 0.92f)) }
        }

        IconStyle.TERMINAL -> Box(
            Modifier
                .size(box)
                .background(accent.copy(alpha = 0.07f))
                .drawBehind {
                    // Lignes de balayage et crochets d'angle
                    var y = 0f
                    val gap = 3.dp.toPx()
                    while (y < size.height) { drawLine(accent.copy(alpha = 0.10f), Offset(0f, y), Offset(size.width, y), 1f); y += gap }
                    val l = size.minDimension * 0.28f
                    val w = 2.dp.toPx()
                    val pts = listOf(Offset(0f, 0f) to Offset(1f, 1f), Offset(size.width, 0f) to Offset(-1f, 1f), Offset(0f, size.height) to Offset(1f, -1f), Offset(size.width, size.height) to Offset(-1f, -1f))
                    pts.forEach { (o, d) ->
                        drawLine(accent, o, Offset(o.x + d.x * l, o.y), w)
                        drawLine(accent, o, Offset(o.x, o.y + d.y * l), w)
                    }
                },
            contentAlignment = Alignment.Center,
        ) { Icon(icon.sharp, null, tint = accent, modifier = Modifier.size(glyph)) }

        IconStyle.HOLOGRAMME -> Box(
            Modifier
                .size(box)
                .drawBehind {
                    // Disque holographique : halo, anneaux et lignes de balayage
                    drawCircle(Brush.radialGradient(listOf(accent.copy(alpha = 0.35f), accent.copy(alpha = 0.04f))), size.minDimension / 2)
                    drawCircle(accent.copy(alpha = 0.8f), size.minDimension / 2 - 1.dp.toPx(), style = Stroke(1.dp.toPx()))
                    drawCircle(accent.copy(alpha = 0.35f), size.minDimension / 2 - 5.dp.toPx(), style = Stroke(0.7.dp.toPx()))
                    var y = 2f
                    while (y < size.height) { drawLine(accent.copy(alpha = 0.12f), Offset(0f, y), Offset(size.width, y), 1f); y += 3.dp.toPx() }
                },
            contentAlignment = Alignment.Center,
        ) {
            if (Build.VERSION.SDK_INT >= 31) Icon(icon.outlined, null, tint = accent, modifier = Modifier.size(glyph).blur(4.dp))
            Icon(icon.outlined, null, tint = lerp(accent, Color.White, 0.5f), modifier = Modifier.size(glyph * 0.9f))
        }

        IconStyle.BLASON -> {
            // Écu : haut droit, pointe en bas ; bordure métal
            val shield = androidx.compose.foundation.shape.GenericShape { sz, _ ->
                moveTo(0f, 0f); lineTo(sz.width, 0f); lineTo(sz.width, sz.height * 0.55f)
                quadraticBezierTo(sz.width, sz.height * 0.85f, sz.width / 2, sz.height)
                quadraticBezierTo(0f, sz.height * 0.85f, 0f, sz.height * 0.55f); close()
            }
            Box(
                Modifier
                    .size(box)
                    .clip(shield)
                    .background(Brush.verticalGradient(listOf(lerp(accent, Color.White, 0.25f), lerp(accent, Color.Black, 0.55f))))
                    .border(2.dp, Brush.verticalGradient(listOf(Color(0xFFE8E8E8), Color(0xFF8A8A8A))), shield),
                contentAlignment = Alignment.Center,
            ) { Icon(icon.sharp, null, tint = Color.White, modifier = Modifier.size(glyph * 0.85f).padding(bottom = 4.dp)) }
        }

        IconStyle.MANGA -> Box(
            Modifier
                .size(box)
                .drawBehind {
                    // Bulle d'explosion à pointes, trait noir épais et trame de points
                    val c = center
                    val path = androidx.compose.ui.graphics.Path()
                    val n = 12
                    for (i in 0 until n * 2) {
                        val r = if (i % 2 == 0) size.minDimension / 2 else size.minDimension * 0.36f
                        val a = (i / (n * 2f)) * 2 * Math.PI.toFloat()
                        val p = Offset(c.x + kotlin.math.cos(a) * r, c.y + kotlin.math.sin(a) * r)
                        if (i == 0) path.moveTo(p.x, p.y) else path.lineTo(p.x, p.y)
                    }
                    path.close()
                    drawPath(path, accent)
                    var x = 0f
                    while (x < size.width) {
                        var y = 0f
                        while (y < size.height) { drawCircle(Color.White.copy(alpha = 0.25f), 0.9.dp.toPx(), Offset(x, y)); y += 5.dp.toPx() }
                        x += 5.dp.toPx()
                    }
                    drawPath(path, Color.Black, style = Stroke(2.2.dp.toPx(), join = androidx.compose.ui.graphics.StrokeJoin.Miter))
                },
            contentAlignment = Alignment.Center,
        ) { Icon(icon.filled, null, tint = Color.Black, modifier = Modifier.size(glyph * 0.8f)) }

        IconStyle.GRUNGE -> Box(
            Modifier
                .size(box)
                .drawBehind {
                    // Carré abîmé : bords irréguliers et taches
                    val path = androidx.compose.ui.graphics.Path()
                    val steps = 24
                    for (i in 0..steps) {
                        val f = i / steps.toFloat()
                        val j = ((i * 7919) % 13) / 13f * 3.dp.toPx()
                        val p = when {
                            f < 0.25f -> Offset(size.width * f * 4, j)
                            f < 0.5f -> Offset(size.width - j, size.height * (f - 0.25f) * 4)
                            f < 0.75f -> Offset(size.width * (1 - (f - 0.5f) * 4), size.height - j)
                            else -> Offset(j, size.height * (1 - (f - 0.75f) * 4))
                        }
                        if (i == 0) path.moveTo(p.x, p.y) else path.lineTo(p.x, p.y)
                    }
                    path.close()
                    drawPath(path, lerp(accent, Color.Black, 0.55f))
                    drawPath(path, accent.copy(alpha = 0.7f), style = Stroke(1.5.dp.toPx()))
                    listOf(0.2f to 0.8f, 0.85f to 0.25f, 0.7f to 0.9f).forEach { (fx, fy) ->
                        drawCircle(Color(0xFF7A0E0E).copy(alpha = 0.55f), 3.dp.toPx(), Offset(size.width * fx, size.height * fy))
                    }
                },
            contentAlignment = Alignment.Center,
        ) { Icon(icon.sharp, null, tint = lerp(accent, Color.White, 0.6f), modifier = Modifier.size(glyph)) }

        IconStyle.ENCRE -> Box(
            Modifier
                .size(box)
                .drawBehind {
                    // Rond tracé au pinceau (ensō), ouvert en haut à droite
                    drawArc(
                        accent.copy(alpha = 0.9f), startAngle = -50f, sweepAngle = 310f, useCenter = false,
                        topLeft = Offset(3.dp.toPx(), 3.dp.toPx()), size = Size(size.width - 6.dp.toPx(), size.height - 6.dp.toPx()),
                        style = Stroke(4.dp.toPx(), cap = androidx.compose.ui.graphics.StrokeCap.Round),
                    )
                    drawArc(
                        accent.copy(alpha = 0.35f), startAngle = -40f, sweepAngle = 290f, useCenter = false,
                        topLeft = Offset(6.dp.toPx(), 5.dp.toPx()), size = Size(size.width - 11.dp.toPx(), size.height - 10.dp.toPx()),
                        style = Stroke(1.5.dp.toPx(), cap = androidx.compose.ui.graphics.StrokeCap.Round),
                    )
                },
            contentAlignment = Alignment.Center,
        ) { Icon(icon.rounded, null, tint = accent, modifier = Modifier.size(glyph * 0.85f)) }

        IconStyle.VITRAIL -> {
            val cs2 = MaterialTheme.colorScheme
            Box(
                Modifier
                    .size(box)
                    .clip(RoundedCornerShape(topStartPercent = 50, topEndPercent = 50, bottomStartPercent = 8, bottomEndPercent = 8))
                    .drawBehind {
                        // Verre coloré en losanges, plombs sombres
                        val cols = listOf(accent, cs2.secondary, cs2.tertiary, lerp(accent, Color.White, 0.4f))
                        val step = size.width / 3
                        var i = 0
                        var y = -step
                        while (y < size.height) {
                            var x = if ((i % 2) == 0) 0f else -step / 2
                            while (x < size.width) {
                                drawRect(cols[(i + (x / step).toInt()).mod(cols.size)].copy(alpha = 0.75f), Offset(x, y), Size(step, step))
                                x += step
                            }
                            y += step; i++
                        }
                        var k = -size.height
                        while (k < size.width + size.height) {
                            drawLine(Color(0xFF1E1E1E), Offset(k, 0f), Offset(k + size.height, size.height), 1.5.dp.toPx())
                            drawLine(Color(0xFF1E1E1E), Offset(k + size.height, 0f), Offset(k, size.height), 1.5.dp.toPx())
                            k += step
                        }
                    }
                    .border(2.dp, Color(0xFF2A2A2A), RoundedCornerShape(topStartPercent = 50, topEndPercent = 50, bottomStartPercent = 8, bottomEndPercent = 8)),
                contentAlignment = Alignment.Center,
            ) { Icon(icon.filled, null, tint = Color.White, modifier = Modifier.size(glyph * 0.8f)) }
        }
    }
}

/** Effet lumineux sur un titre (néon, grimoire…), ou null. */
@Composable
fun titleGlow(): androidx.compose.ui.graphics.Shadow? {
    val cs = MaterialTheme.colorScheme
    return when (LocalLook.current.deco) {
        Deco.NEON, Deco.SUNSET -> androidx.compose.ui.graphics.Shadow(cs.primary, Offset.Zero, 22f)
        Deco.TERMINAL -> androidx.compose.ui.graphics.Shadow(cs.primary.copy(alpha = 0.8f), Offset.Zero, 14f)
        Deco.GRIMOIRE -> androidx.compose.ui.graphics.Shadow(cs.primary, Offset(0f, 2f), 12f)
        Deco.AURORA, Deco.FIREFLIES, Deco.BUBBLES -> androidx.compose.ui.graphics.Shadow(cs.secondary.copy(alpha = 0.7f), Offset.Zero, 18f)
        Deco.STARS, Deco.STORM -> androidx.compose.ui.graphics.Shadow(cs.primary.copy(alpha = 0.9f), Offset.Zero, 20f)
        Deco.ENERGY -> androidx.compose.ui.graphics.Shadow(cs.secondary, Offset.Zero, 26f)
        Deco.SNOW -> androidx.compose.ui.graphics.Shadow(Color.White.copy(alpha = 0.6f), Offset.Zero, 16f)
        Deco.BLOOD, Deco.FOG, Deco.SHADOWS -> androidx.compose.ui.graphics.Shadow(cs.secondary.copy(alpha = 0.8f), Offset(0f, 2f), 10f)
        Deco.CIRCUIT, Deco.NEBULA, Deco.BOKEH -> androidx.compose.ui.graphics.Shadow(cs.primary.copy(alpha = 0.9f), Offset.Zero, 20f)
        Deco.FLAMES, Deco.LAVA -> androidx.compose.ui.graphics.Shadow(cs.secondary.copy(alpha = 0.9f), Offset.Zero, 22f)
        Deco.WAVES -> androidx.compose.ui.graphics.Shadow(cs.primary.copy(alpha = 0.7f), Offset.Zero, 16f)
        else -> null
    }
}
