package fr.jeremy.calepin.ui

import android.os.Build
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.CutCornerShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Contacts
import androidx.compose.material.icons.filled.EditNote
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.BusinessCenter
import androidx.compose.material.icons.filled.SettingsRemote
import androidx.compose.material.icons.filled.SmartToy
import androidx.compose.material.icons.filled.SportsEsports
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Forum
import androidx.compose.material.icons.outlined.CalendarMonth
import androidx.compose.material.icons.outlined.Contacts
import androidx.compose.material.icons.outlined.EditNote
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Palette
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material.icons.outlined.BusinessCenter
import androidx.compose.material.icons.outlined.SettingsRemote
import androidx.compose.material.icons.outlined.SmartToy
import androidx.compose.material.icons.outlined.SportsEsports
import androidx.compose.material.icons.outlined.PhoneAndroid
import androidx.compose.material.icons.outlined.Description
import androidx.compose.material.icons.outlined.Forum
import androidx.compose.material.icons.rounded.CalendarMonth
import androidx.compose.material.icons.rounded.Contacts
import androidx.compose.material.icons.rounded.EditNote
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.Palette
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.BusinessCenter
import androidx.compose.material.icons.rounded.SettingsRemote
import androidx.compose.material.icons.rounded.SmartToy
import androidx.compose.material.icons.rounded.SportsEsports
import androidx.compose.material.icons.rounded.PhoneAndroid
import androidx.compose.material.icons.rounded.Description
import androidx.compose.material.icons.rounded.Forum
import androidx.compose.material.icons.sharp.CalendarMonth
import androidx.compose.material.icons.sharp.Contacts
import androidx.compose.material.icons.sharp.EditNote
import androidx.compose.material.icons.sharp.Home
import androidx.compose.material.icons.sharp.Palette
import androidx.compose.material.icons.sharp.Settings
import androidx.compose.material.icons.sharp.BusinessCenter
import androidx.compose.material.icons.sharp.SettingsRemote
import androidx.compose.material.icons.sharp.SmartToy
import androidx.compose.material.icons.sharp.SportsEsports
import androidx.compose.material.icons.sharp.PhoneAndroid
import androidx.compose.material.icons.sharp.Description
import androidx.compose.material.icons.sharp.Forum
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Paint
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

/** Icônes de l'accueil, chacune dessinée dans les quatre familles Material (pleine, contour, arrondie, anguleuse). */
enum class AppIcon(val filled: ImageVector, val outlined: ImageVector, val rounded: ImageVector, val sharp: ImageVector) {
    NOTES(Icons.Filled.EditNote, Icons.Outlined.EditNote, Icons.Rounded.EditNote, Icons.Sharp.EditNote),
    AGENDA(Icons.Filled.CalendarMonth, Icons.Outlined.CalendarMonth, Icons.Rounded.CalendarMonth, Icons.Sharp.CalendarMonth),
    ASSISTANT(Icons.Filled.SmartToy, Icons.Outlined.SmartToy, Icons.Rounded.SmartToy, Icons.Sharp.SmartToy),
    CONTACTS(Icons.Filled.Contacts, Icons.Outlined.Contacts, Icons.Rounded.Contacts, Icons.Sharp.Contacts),
    REMOTE(Icons.Filled.SettingsRemote, Icons.Outlined.SettingsRemote, Icons.Rounded.SettingsRemote, Icons.Sharp.SettingsRemote),
    HOME(Icons.Filled.Home, Icons.Outlined.Home, Icons.Rounded.Home, Icons.Sharp.Home),
    GAMES(Icons.Filled.SportsEsports, Icons.Outlined.SportsEsports, Icons.Rounded.SportsEsports, Icons.Sharp.SportsEsports),
    APPEARANCE(Icons.Filled.Palette, Icons.Outlined.Palette, Icons.Rounded.Palette, Icons.Sharp.Palette),
    SETTINGS(Icons.Filled.Settings, Icons.Outlined.Settings, Icons.Rounded.Settings, Icons.Sharp.Settings),
    PRO(Icons.Filled.BusinessCenter, Icons.Outlined.BusinessCenter, Icons.Rounded.BusinessCenter, Icons.Sharp.BusinessCenter),
    PHONE(Icons.Filled.PhoneAndroid, Icons.Outlined.PhoneAndroid, Icons.Rounded.PhoneAndroid, Icons.Sharp.PhoneAndroid),
    OFFICE(Icons.Filled.Description, Icons.Outlined.Description, Icons.Rounded.Description, Icons.Sharp.Description),
    MESSAGES(Icons.Filled.Forum, Icons.Outlined.Forum, Icons.Rounded.Forum, Icons.Sharp.Forum),
}

private val GOLD = Color(0xFFD4AF37)

/** Parties d'une icône dont on peut choisir la couleur. */
enum class IconSlot { FILL, LINE, GLYPH, EXTRA }

/** Couleurs choisies pour une icône ([ColorPref.AUTO] = celle du style, [ColorPref.NONE] = rien). */
data class IconColors(
    val fill: Long = ColorPref.AUTO,
    val line: Long = ColorPref.AUTO,
    val glyph: Long = ColorPref.AUTO,
    val extra: Long = ColorPref.AUTO,
) {
    val isAuto get() = fill == ColorPref.AUTO && line == ColorPref.AUTO && glyph == ColorPref.AUTO && extra == ColorPref.AUTO
    fun get(s: IconSlot) = when (s) { IconSlot.FILL -> fill; IconSlot.LINE -> line; IconSlot.GLYPH -> glyph; IconSlot.EXTRA -> extra }
    fun with(s: IconSlot, v: Long) = when (s) {
        IconSlot.FILL -> copy(fill = v); IconSlot.LINE -> copy(line = v); IconSlot.GLYPH -> copy(glyph = v); IconSlot.EXTRA -> copy(extra = v)
    }

    /** Une couleur choisie pour l'icône l'emporte sur celle choisie pour toutes. */
    fun over(base: IconColors?): IconColors {
        if (base == null) return this
        fun m(a: Long, b: Long) = if (a != ColorPref.AUTO) a else b
        return IconColors(m(fill, base.fill), m(line, base.line), m(glyph, base.glyph), m(extra, base.extra))
    }

    companion object {
        fun encode(m: Map<String, IconColors>): String = org.json.JSONObject().apply {
            m.forEach { (k, c) -> put(k, org.json.JSONArray(listOf(c.fill, c.line, c.glyph, c.extra))) }
        }.toString()

        fun decode(s: String?): Map<String, IconColors> = runCatching {
            if (s.isNullOrBlank()) return emptyMap()
            val o = org.json.JSONObject(s)
            o.keys().asSequence().associateWith { k ->
                val a = o.getJSONArray(k)
                IconColors(a.optLong(0, ColorPref.AUTO), a.optLong(1, ColorPref.AUTO), a.optLong(2, ColorPref.AUTO), a.optLong(3, ColorPref.AUTO))
            }
        }.getOrDefault(emptyMap())

        /** Parties réglables de chaque style, avec leur nom. */
        fun slotsOf(style: IconStyle): List<Pair<IconSlot, String>> {
            val fill = IconSlot.FILL to "Fond"
            val line = IconSlot.LINE to "Contour"
            val glyph = IconSlot.GLYPH to "Symbole"
            return when (style) {
                IconStyle.AUTO, IconStyle.PLEIN -> listOf(fill, glyph)
                IconStyle.CONTOUR -> listOf(line, glyph)
                IconStyle.MINIMAL -> listOf(glyph)
                IconStyle.BULLE, IconStyle.COEUR, IconStyle.FLAMME, IconStyle.AQUARELLE ->
                    listOf(IconSlot.FILL to "Dégradé : 1re couleur", IconSlot.EXTRA to "Dégradé : 2e couleur", glyph)
                IconStyle.NEON -> listOf(IconSlot.LINE to "Tube néon (contour)", IconSlot.FILL to "Remplissage", glyph, IconSlot.EXTRA to "Halo")
                IconStyle.GRIMOIRE -> listOf(fill, IconSlot.LINE to "Cadre doré", glyph, IconSlot.EXTRA to "Gemmes")
                IconStyle.TERMINAL -> listOf(IconSlot.LINE to "Crochets", fill, glyph)
                IconStyle.HOLOGRAMME -> listOf(IconSlot.FILL to "Halo", IconSlot.LINE to "Anneaux", glyph)
                IconStyle.BLASON -> listOf(IconSlot.FILL to "Écu : haut", IconSlot.EXTRA to "Écu : bas", IconSlot.LINE to "Bordure", glyph)
                IconStyle.MANGA -> listOf(IconSlot.FILL to "Explosion", IconSlot.LINE to "Trait d'encre", glyph, IconSlot.EXTRA to "Trame")
                IconStyle.GRUNGE -> listOf(fill, line, glyph, IconSlot.EXTRA to "Taches")
                IconStyle.ENCRE -> listOf(IconSlot.LINE to "Coup de pinceau", glyph)
                IconStyle.VITRAIL -> listOf(IconSlot.FILL to "Verre : 1re couleur", IconSlot.EXTRA to "Verre : 2e couleur", IconSlot.LINE to "Plombs", glyph)
                IconStyle.VAGUE -> listOf(IconSlot.FILL to "Mer", IconSlot.EXTRA to "Vagues", line, glyph)
                IconStyle.GLACE -> listOf(IconSlot.FILL to "Glace", IconSlot.LINE to "Arêtes", glyph)
                IconStyle.VERRE -> listOf(IconSlot.FILL to "Verre", line, glyph)
                IconStyle.PLANETE -> listOf(IconSlot.FILL to "Planète", IconSlot.EXTRA to "Ombre", IconSlot.LINE to "Anneau", glyph)
                IconStyle.CIRCUIT -> listOf(IconSlot.FILL to "Puce", IconSlot.LINE to "Broches", IconSlot.EXTRA to "Pistes", glyph)
                IconStyle.ENGRENAGE -> listOf(IconSlot.FILL to "Métal", IconSlot.LINE to "Contour", glyph)
                IconStyle.SCEAU -> listOf(IconSlot.FILL to "Encre du sceau", IconSlot.LINE to "Cadre", glyph)
                IconStyle.LANTERNE -> listOf(IconSlot.FILL to "Papier", IconSlot.LINE to "Armature", glyph, IconSlot.EXTRA to "Lumière")
                IconStyle.ZELLIGE -> listOf(IconSlot.FILL to "Étoile", IconSlot.EXTRA to "Cœur de l'étoile", line, glyph)
                IconStyle.PAPEL -> listOf(IconSlot.FILL to "Papier", IconSlot.EXTRA to "Découpes", glyph)
                IconStyle.GRECQUE -> listOf(fill, IconSlot.LINE to "Frise", glyph)
            }
        }
    }
}

@Composable
private fun accentOf(tone: Int): Color = when (tone % 3) {
    0 -> MaterialTheme.colorScheme.primary
    1 -> MaterialTheme.colorScheme.secondary
    else -> MaterialTheme.colorScheme.tertiary
}

/** Contour à coins coupés (octogone), en coordonnées de dessin. */
private fun cutPath(w: Float, h: Float, c: Float, inset: Float = 0f) = android.graphics.Path().apply {
    val l = inset; val t = inset; val r = w - inset; val b = h - inset
    moveTo(l + c, t); lineTo(r - c, t); lineTo(r, t + c); lineTo(r, b - c)
    lineTo(r - c, b); lineTo(l + c, b); lineTo(l, b - c); lineTo(l, t + c); close()
}

/** Trait lumineux (halo) façon néon. Le halo apparaît à partir d'Android 9. */
private fun DrawScope.neonStroke(path: android.graphics.Path, color: Color, width: Float, glow: Float, haloColor: Color = color) {
    drawIntoCanvas { canvas ->
        val paint = Paint().asFrameworkPaint().apply {
            isAntiAlias = true
            style = android.graphics.Paint.Style.STROKE
            strokeWidth = width
            this.color = color.toArgb()
            if (Build.VERSION.SDK_INT >= 28) setShadowLayer(glow, 0f, 0f, haloColor.toArgb())
        }
        if (Build.VERSION.SDK_INT < 28) {
            // Halo simulé : traits plus larges et transparents
            val halo = android.graphics.Paint(paint).apply { strokeWidth = width * 4; this.color = haloColor.copy(alpha = 0.18f).toArgb() }
            canvas.nativeCanvas.drawPath(path, halo)
        }
        canvas.nativeCanvas.drawPath(path, paint)
    }
}

/** Étoile ou roue dentée : [n] pointes alternant rayon extérieur et intérieur. */
private fun starPath(c: Offset, outer: Float, inner: Float, n: Int, rot: Float = -90f) = androidx.compose.ui.graphics.Path().apply {
    for (i in 0 until n * 2) {
        val r = if (i % 2 == 0) outer else inner
        val a = Math.toRadians((rot + i * 180.0 / n)).toFloat()
        val p = Offset(c.x + kotlin.math.cos(a) * r, c.y + kotlin.math.sin(a) * r)
        if (i == 0) moveTo(p.x, p.y) else lineTo(p.x, p.y)
    }
    close()
}

/**
 * Icône de rubrique dans le style choisi (ou celui du thème).
 * [tone] alterne les trois couleurs du thème d'une tuile à l'autre.
 * Les couleurs choisies dans Apparence (pour toutes les icônes ou pour celle-ci) remplacent celles du style.
 */
@Composable
fun ThemedIcon(icon: AppIcon, tone: Int, box: Dp, style: IconStyle = LocalLook.current.icons) {
    val cs = MaterialTheme.colorScheme
    val accent = accentOf(tone)
    val other = when (tone % 3) { 0 -> cs.tertiary; 1 -> cs.primary; else -> cs.secondary }
    val glyph = box * 0.54f
    val custom: Map<String, IconColors> = LocalLook.current.iconColors
    val chosen: IconColors = (custom[icon.name] ?: IconColors()).over(custom["*"])
    fun pick(v: Long, def: Color): Color = when (v) {
        ColorPref.AUTO -> def
        ColorPref.NONE -> Color.Transparent
        else -> Color(v.toInt())
    }
    fun fillC(def: Color) = pick(chosen.fill, def)
    fun lineC(def: Color) = pick(chosen.line, def)
    fun glyphC(def: Color) = pick(chosen.glyph, def)
    fun extraC(def: Color) = pick(chosen.extra, def)

    when (style) {
        IconStyle.AUTO, IconStyle.PLEIN -> {
            val (bg, fg) = when (tone % 3) {
                0 -> cs.primaryContainer to cs.onPrimaryContainer
                1 -> cs.secondaryContainer to cs.onSecondaryContainer
                else -> cs.tertiaryContainer to cs.onTertiaryContainer
            }
            Box(Modifier.size(box).clip(MaterialTheme.shapes.medium).background(fillC(bg)), contentAlignment = Alignment.Center) {
                Icon(icon.filled, null, tint = glyphC(fg), modifier = Modifier.size(glyph))
            }
        }

        IconStyle.CONTOUR -> Box(
            Modifier.size(box).border(1.5.dp, lineC(accent), MaterialTheme.shapes.medium),
            contentAlignment = Alignment.Center,
        ) { Icon(icon.outlined, null, tint = glyphC(accent), modifier = Modifier.size(glyph)) }

        IconStyle.MINIMAL -> Box(Modifier.size(box), contentAlignment = Alignment.Center) {
            Icon(icon.rounded, null, tint = glyphC(accent), modifier = Modifier.size(box * 0.72f))
        }

        IconStyle.BULLE -> {
            val a = fillC(lerp(accent, Color.White, 0.15f))
            val b = extraC(lerp(accent, other, 0.65f))
            Box(
                Modifier
                    .size(box)
                    .clip(RoundedCornerShape(percent = 34))
                    .background(Brush.linearGradient(listOf(a, b)))
                    .drawBehind {
                        // Reflet en haut, comme une bulle de verre
                        drawCircle(Color.White.copy(alpha = 0.22f), radius = size.width * 0.42f, center = Offset(size.width * 0.3f, size.height * 0.12f))
                    },
                contentAlignment = Alignment.Center,
            ) { Icon(icon.rounded, null, tint = glyphC(Color.White), modifier = Modifier.size(glyph)) }
        }

        IconStyle.NEON -> {
            val tube = lineC(accent)
            val inside = fillC(accent.copy(alpha = 0.10f))
            val halo = extraC(tube)
            val sym = glyphC(lerp(tube, Color.White, 0.35f))
            Box(
                Modifier
                    .size(box)
                    .drawBehind {
                        val c = size.minDimension * 0.22f
                        drawPath(androidx.compose.ui.graphics.Path().apply {
                            moveTo(c, 0f); lineTo(size.width - c, 0f); lineTo(size.width, c); lineTo(size.width, size.height - c)
                            lineTo(size.width - c, size.height); lineTo(c, size.height); lineTo(0f, size.height - c); lineTo(0f, c); close()
                        }, inside)
                        neonStroke(cutPath(size.width, size.height, c, 1.5f), tube, 2.dp.toPx(), 9.dp.toPx(), halo)
                    },
                contentAlignment = Alignment.Center,
            ) {
                if (Build.VERSION.SDK_INT >= 31) {
                    Icon(icon.outlined, null, tint = halo, modifier = Modifier.size(glyph).blur(5.dp))
                }
                Icon(icon.outlined, null, tint = sym, modifier = Modifier.size(glyph))
            }
        }

        IconStyle.GRIMOIRE -> {
            val shape = CutCornerShape(percent = 30)
            val base = fillC(accent)
            val frame = lineC(GOLD)
            val gems = extraC(frame)
            Box(
                Modifier
                    .size(box)
                    .clip(shape)
                    .background(Brush.radialGradient(listOf(lerp(base, Color.Black, 0.35f), lerp(base, Color.Black, 0.82f))))
                    .border(1.5.dp, frame, shape)
                    .padding(4.dp)
                    .border(0.75.dp, frame.copy(alpha = frame.alpha * 0.55f), shape)
                    .drawBehind {
                        // Petites gemmes aux quatre points cardinaux
                        val r = 1.6.dp.toPx()
                        listOf(Offset(size.width / 2, 2.5f * r), Offset(size.width / 2, size.height - 2.5f * r), Offset(2.5f * r, size.height / 2), Offset(size.width - 2.5f * r, size.height / 2))
                            .forEach { drawCircle(gems, r, it) }
                    },
                contentAlignment = Alignment.Center,
            ) { Icon(icon.sharp, null, tint = glyphC(GOLD), modifier = Modifier.size(glyph * 0.92f)) }
        }

        IconStyle.TERMINAL -> {
            val corner = lineC(accent)
            val bg = fillC(accent)
            Box(
                Modifier
                    .size(box)
                    .background(bg.copy(alpha = bg.alpha * 0.07f))
                    .drawBehind {
                        // Lignes de balayage et crochets d'angle
                        var y = 0f
                        val gap = 3.dp.toPx()
                        while (y < size.height) { drawLine(bg.copy(alpha = bg.alpha * 0.10f), Offset(0f, y), Offset(size.width, y), 1f); y += gap }
                        val l = size.minDimension * 0.28f
                        val w = 2.dp.toPx()
                        val pts = listOf(Offset(0f, 0f) to Offset(1f, 1f), Offset(size.width, 0f) to Offset(-1f, 1f), Offset(0f, size.height) to Offset(1f, -1f), Offset(size.width, size.height) to Offset(-1f, -1f))
                        pts.forEach { (o, d) ->
                            drawLine(corner, o, Offset(o.x + d.x * l, o.y), w)
                            drawLine(corner, o, Offset(o.x, o.y + d.y * l), w)
                        }
                    },
                contentAlignment = Alignment.Center,
            ) { Icon(icon.sharp, null, tint = glyphC(accent), modifier = Modifier.size(glyph)) }
        }

        IconStyle.HOLOGRAMME -> {
            val halo = fillC(accent)
            val ring = lineC(accent)
            val sym = glyphC(lerp(accent, Color.White, 0.5f))
            Box(
                Modifier
                    .size(box)
                    .drawBehind {
                        // Disque holographique : halo, anneaux et lignes de balayage
                        drawCircle(Brush.radialGradient(listOf(halo.copy(alpha = halo.alpha * 0.35f), halo.copy(alpha = halo.alpha * 0.04f))), size.minDimension / 2)
                        drawCircle(ring.copy(alpha = ring.alpha * 0.8f), size.minDimension / 2 - 1.dp.toPx(), style = Stroke(1.dp.toPx()))
                        drawCircle(ring.copy(alpha = ring.alpha * 0.35f), size.minDimension / 2 - 5.dp.toPx(), style = Stroke(0.7.dp.toPx()))
                        var y = 2f
                        while (y < size.height) { drawLine(halo.copy(alpha = halo.alpha * 0.12f), Offset(0f, y), Offset(size.width, y), 1f); y += 3.dp.toPx() }
                    },
                contentAlignment = Alignment.Center,
            ) {
                if (Build.VERSION.SDK_INT >= 31) Icon(icon.outlined, null, tint = sym.copy(alpha = sym.alpha * 0.8f), modifier = Modifier.size(glyph).blur(4.dp))
                Icon(icon.outlined, null, tint = sym, modifier = Modifier.size(glyph * 0.9f))
            }
        }

        IconStyle.BLASON -> {
            // Écu : haut droit, pointe en bas ; bordure métal
            val shield = androidx.compose.foundation.shape.GenericShape { sz, _ ->
                moveTo(0f, 0f); lineTo(sz.width, 0f); lineTo(sz.width, sz.height * 0.55f)
                quadraticBezierTo(sz.width, sz.height * 0.85f, sz.width / 2, sz.height)
                quadraticBezierTo(0f, sz.height * 0.85f, 0f, sz.height * 0.55f); close()
            }
            val top = fillC(lerp(accent, Color.White, 0.25f))
            val bottom = extraC(lerp(accent, Color.Black, 0.55f))
            val metal = if (chosen.line == ColorPref.AUTO) Brush.verticalGradient(listOf(Color(0xFFE8E8E8), Color(0xFF8A8A8A)))
            else androidx.compose.ui.graphics.SolidColor(lineC(Color.Gray))
            Box(
                Modifier
                    .size(box)
                    .clip(shield)
                    .background(Brush.verticalGradient(listOf(top, bottom)))
                    .border(2.dp, metal, shield),
                contentAlignment = Alignment.Center,
            ) { Icon(icon.sharp, null, tint = glyphC(Color.White), modifier = Modifier.size(glyph * 0.85f).padding(bottom = 4.dp)) }
        }

        IconStyle.MANGA -> {
            val burst = fillC(accent)
            val ink = lineC(Color.Black)
            val dots = extraC(Color.White.copy(alpha = 0.25f))
            Box(
                Modifier
                    .size(box)
                    .drawBehind {
                        // Bulle d'explosion à pointes, trait noir épais et trame de points
                        val path = starPath(center, size.minDimension / 2, size.minDimension * 0.36f, 12, 0f)
                        drawPath(path, burst)
                        var x = 0f
                        while (x < size.width) {
                            var y = 0f
                            while (y < size.height) { drawCircle(dots, 0.9.dp.toPx(), Offset(x, y)); y += 5.dp.toPx() }
                            x += 5.dp.toPx()
                        }
                        drawPath(path, ink, style = Stroke(2.2.dp.toPx(), join = androidx.compose.ui.graphics.StrokeJoin.Miter))
                    },
                contentAlignment = Alignment.Center,
            ) { Icon(icon.filled, null, tint = glyphC(Color.Black), modifier = Modifier.size(glyph * 0.8f)) }
        }

        IconStyle.GRUNGE -> {
            val base = fillC(lerp(accent, Color.Black, 0.55f))
            val edge = lineC(accent.copy(alpha = 0.7f))
            val stain = extraC(Color(0xFF7A0E0E).copy(alpha = 0.55f))
            Box(
                Modifier
                    .size(box)
                    .drawBehind {
                        // Carré abîmé : bords irréguliers et taches
                        val path = androidx.compose.ui.graphics.Path()
                        val steps = 24
                        for (i in 0..steps) {
                            val f = i / steps.toFloat()
                            val j = ((i * 7919) % 13) / 13f * 3.dp.toPx()
                            val p = when {
                                f < 0.25f -> Offset(size.width * f * 4, j)
                                f < 0.5f -> Offset(size.width - j, size.height * (f - 0.25f) * 4)
                                f < 0.75f -> Offset(size.width * (1 - (f - 0.5f) * 4), size.height - j)
                                else -> Offset(j, size.height * (1 - (f - 0.75f) * 4))
                            }
                            if (i == 0) path.moveTo(p.x, p.y) else path.lineTo(p.x, p.y)
                        }
                        path.close()
                        drawPath(path, base)
                        drawPath(path, edge, style = Stroke(1.5.dp.toPx()))
                        listOf(0.2f to 0.8f, 0.85f to 0.25f, 0.7f to 0.9f).forEach { (fx, fy) ->
                            drawCircle(stain, 3.dp.toPx(), Offset(size.width * fx, size.height * fy))
                        }
                    },
                contentAlignment = Alignment.Center,
            ) { Icon(icon.sharp, null, tint = glyphC(lerp(accent, Color.White, 0.6f)), modifier = Modifier.size(glyph)) }
        }

        IconStyle.ENCRE -> {
            val brush = lineC(accent)
            Box(
                Modifier
                    .size(box)
                    .drawBehind {
                        // Rond tracé au pinceau (ensō), ouvert en haut à droite
                        drawArc(
                            brush.copy(alpha = brush.alpha * 0.9f), startAngle = -50f, sweepAngle = 310f, useCenter = false,
                            topLeft = Offset(3.dp.toPx(), 3.dp.toPx()), size = Size(size.width - 6.dp.toPx(), size.height - 6.dp.toPx()),
                            style = Stroke(4.dp.toPx(), cap = androidx.compose.ui.graphics.StrokeCap.Round),
                        )
                        drawArc(
                            brush.copy(alpha = brush.alpha * 0.35f), startAngle = -40f, sweepAngle = 290f, useCenter = false,
                            topLeft = Offset(6.dp.toPx(), 5.dp.toPx()), size = Size(size.width - 11.dp.toPx(), size.height - 10.dp.toPx()),
                            style = Stroke(1.5.dp.toPx(), cap = androidx.compose.ui.graphics.StrokeCap.Round),
                        )
                    },
                contentAlignment = Alignment.Center,
            ) { Icon(icon.rounded, null, tint = glyphC(accent), modifier = Modifier.size(glyph * 0.85f)) }
        }

        IconStyle.VITRAIL -> {
            val g1 = fillC(accent)
            val g2 = extraC(cs.secondary)
            val lead = lineC(Color(0xFF1E1E1E))
            val arch = RoundedCornerShape(topStartPercent = 50, topEndPercent = 50, bottomStartPercent = 8, bottomEndPercent = 8)
            Box(
                Modifier
                    .size(box)
                    .clip(arch)
                    .drawBehind {
                        // Verre coloré en losanges, plombs sombres
                        val cols = listOf(g1, g2, lerp(g1, g2, 0.5f), lerp(g1, Color.White, 0.4f))
                        val step = size.width / 3
                        var i = 0
                        var y = -step
                        while (y < size.height) {
                            var x = if ((i % 2) == 0) 0f else -step / 2
                            while (x < size.width) {
                                drawRect(cols[(i + (x / step).toInt()).mod(cols.size)].copy(alpha = 0.75f), Offset(x, y), Size(step, step))
                                x += step
                            }
                            y += step; i++
                        }
                        var k = -size.height
                        while (k < size.width + size.height) {
                            drawLine(lead, Offset(k, 0f), Offset(k + size.height, size.height), 1.5.dp.toPx())
                            drawLine(lead, Offset(k + size.height, 0f), Offset(k, size.height), 1.5.dp.toPx())
                            k += step
                        }
                    }
                    .border(2.dp, lead, arch),
                contentAlignment = Alignment.Center,
            ) { Icon(icon.filled, null, tint = glyphC(Color.White), modifier = Modifier.size(glyph * 0.8f)) }
        }

        // ---------------------------------------------------------------- Styles des nouveaux thèmes

        IconStyle.AQUARELLE -> {
            val a = fillC(accent)
            val b = extraC(other)
            Box(
                Modifier
                    .size(box)
                    .drawBehind {
                        // Taches d'aquarelle qui se mêlent, bords doux
                        val r = size.minDimension
                        drawCircle(Brush.radialGradient(listOf(a.copy(alpha = a.alpha * 0.75f), a.copy(alpha = 0f)), Offset(r * 0.38f, r * 0.42f), r * 0.48f), r * 0.48f, Offset(r * 0.38f, r * 0.42f))
                        drawCircle(Brush.radialGradient(listOf(b.copy(alpha = b.alpha * 0.7f), b.copy(alpha = 0f)), Offset(r * 0.64f, r * 0.6f), r * 0.42f), r * 0.42f, Offset(r * 0.64f, r * 0.6f))
                        drawCircle(Brush.radialGradient(listOf(lerp(a, b, 0.5f).copy(alpha = 0.5f), Color.Transparent), Offset(r * 0.5f, r * 0.3f), r * 0.3f), r * 0.3f, Offset(r * 0.5f, r * 0.3f))
                    },
                contentAlignment = Alignment.Center,
            ) { Icon(icon.rounded, null, tint = glyphC(lerp(a, Color.Black, 0.45f)), modifier = Modifier.size(glyph)) }
        }

        IconStyle.VAGUE -> {
            val sea = fillC(lerp(accent, Color(0xFF0277BD), 0.4f))
            val waves = extraC(Color.White.copy(alpha = 0.55f))
            val edge = lineC(Color.White.copy(alpha = 0.7f))
            Box(
                Modifier
                    .size(box)
                    .clip(CircleShape)
                    .background(Brush.verticalGradient(listOf(lerp(sea, Color.White, 0.25f), lerp(sea, Color.Black, 0.25f))))
                    .drawBehind {
                        // Trois vagues ondulées en bas du cercle
                        for (k in 0..2) {
                            val y0 = size.height * (0.58f + k * 0.13f)
                            val path = androidx.compose.ui.graphics.Path().apply {
                                moveTo(0f, y0)
                                var x = 0f
                                val w = size.width / 4
                                while (x < size.width) {
                                    quadraticBezierTo(x + w / 2, y0 - 4.dp.toPx(), x + w, y0)
                                    x += w
                                }
                            }
                            drawPath(path, waves.copy(alpha = waves.alpha * (1f - k * 0.25f)), style = Stroke(1.6.dp.toPx(), cap = androidx.compose.ui.graphics.StrokeCap.Round))
                        }
                    }
                    .border(1.5.dp, edge, CircleShape),
                contentAlignment = Alignment.Center,
            ) { Icon(icon.rounded, null, tint = glyphC(Color.White), modifier = Modifier.size(glyph * 0.85f).padding(bottom = 6.dp)) }
        }

        IconStyle.GLACE -> {
            val ice = fillC(lerp(accent, Color(0xFFB3E5FC), 0.6f))
            val edge = lineC(Color.White)
            val hex = androidx.compose.foundation.shape.GenericShape { sz, _ ->
                val c = sz.width / 2; val r = sz.minDimension / 2
                for (i in 0 until 6) {
                    val a = Math.toRadians(-90.0 + i * 60).toFloat()
                    val x = c + kotlin.math.cos(a) * r; val y = sz.height / 2 + kotlin.math.sin(a) * r
                    if (i == 0) moveTo(x, y) else lineTo(x, y)
                }
                close()
            }
            Box(
                Modifier
                    .size(box)
                    .clip(hex)
                    .background(Brush.linearGradient(listOf(lerp(ice, Color.White, 0.55f), ice, lerp(ice, Color(0xFF01579B), 0.35f))))
                    .drawBehind {
                        // Facettes du cristal
                        val c = center
                        for (i in 0 until 6) {
                            val a = Math.toRadians(-90.0 + i * 60).toFloat()
                            drawLine(edge.copy(alpha = edge.alpha * 0.35f), c, Offset(c.x + kotlin.math.cos(a) * size.minDimension / 2, c.y + kotlin.math.sin(a) * size.minDimension / 2), 1.dp.toPx())
                        }
                    }
                    .border(1.5.dp, edge, hex),
                contentAlignment = Alignment.Center,
            ) { Icon(icon.outlined, null, tint = glyphC(Color(0xFF0D47A1)), modifier = Modifier.size(glyph * 0.85f)) }
        }

        IconStyle.VERRE -> {
            val glass = fillC(Color.White.copy(alpha = 0.18f))
            val edge = lineC(Color.White.copy(alpha = 0.45f))
            val shape = RoundedCornerShape(percent = 28)
            Box(
                Modifier
                    .size(box)
                    .clip(shape)
                    .background(Brush.linearGradient(listOf(glass.copy(alpha = (glass.alpha * 1.6f).coerceAtMost(1f)), glass.copy(alpha = glass.alpha * 0.5f))))
                    .border(1.dp, edge, shape),
                contentAlignment = Alignment.Center,
            ) { Icon(icon.rounded, null, tint = glyphC(accent), modifier = Modifier.size(glyph)) }
        }

        IconStyle.FLAMME -> {
            val hot = fillC(Color(0xFFFF6D00))
            val core = extraC(Color(0xFFFFD54F))
            val flame = androidx.compose.foundation.shape.GenericShape { sz, _ ->
                val w = sz.width; val h = sz.height
                moveTo(w * 0.5f, 0f)
                cubicTo(w * 0.62f, h * 0.22f, w * 0.98f, h * 0.38f, w * 0.92f, h * 0.68f)
                cubicTo(w * 0.86f, h * 0.92f, w * 0.66f, h, w * 0.5f, h)
                cubicTo(w * 0.34f, h, w * 0.14f, h * 0.92f, w * 0.08f, h * 0.68f)
                cubicTo(w * 0.02f, h * 0.42f, w * 0.3f, h * 0.32f, w * 0.34f, h * 0.12f)
                cubicTo(w * 0.42f, h * 0.24f, w * 0.44f, h * 0.1f, w * 0.5f, 0f)
                close()
            }
            Box(
                Modifier
                    .size(box)
                    .clip(flame)
                    .background(Brush.verticalGradient(listOf(lerp(hot, Color.Red, 0.3f), hot, core))),
                contentAlignment = Alignment.Center,
            ) { Icon(icon.filled, null, tint = glyphC(Color(0xFF3E1200)), modifier = Modifier.size(glyph * 0.72f).padding(top = 6.dp)) }
        }

        IconStyle.COEUR -> {
            val a = fillC(lerp(accent, Color(0xFFE91E63), 0.5f))
            val b = extraC(lerp(a, Color(0xFF880E4F), 0.5f))
            val heart = androidx.compose.foundation.shape.GenericShape { sz, _ ->
                val w = sz.width; val h = sz.height
                moveTo(w / 2, h * 0.95f)
                cubicTo(w * 0.05f, h * 0.62f, -w * 0.02f, h * 0.2f, w * 0.28f, h * 0.1f)
                cubicTo(w * 0.42f, h * 0.06f, w * 0.48f, h * 0.16f, w / 2, h * 0.24f)
                cubicTo(w * 0.52f, h * 0.16f, w * 0.58f, h * 0.06f, w * 0.72f, h * 0.1f)
                cubicTo(w * 1.02f, h * 0.2f, w * 0.95f, h * 0.62f, w / 2, h * 0.95f)
                close()
            }
            Box(
                Modifier.size(box).clip(heart).background(Brush.linearGradient(listOf(lerp(a, Color.White, 0.2f), b))),
                contentAlignment = Alignment.Center,
            ) { Icon(icon.rounded, null, tint = glyphC(Color.White), modifier = Modifier.size(glyph * 0.72f).padding(bottom = 4.dp)) }
        }

        IconStyle.PLANETE -> {
            val planet = fillC(accent)
            val shade = extraC(lerp(accent, Color.Black, 0.6f))
            val ring = lineC(lerp(other, Color.White, 0.3f))
            Box(
                Modifier
                    .size(box)
                    .drawBehind {
                        val r = size.minDimension * 0.36f
                        drawCircle(Brush.radialGradient(listOf(lerp(planet, Color.White, 0.3f), planet, shade), Offset(center.x - r * 0.4f, center.y - r * 0.4f), r * 1.6f), r, center)
                        // Anneau incliné
                        rotate(-20f) {
                            drawOval(ring, Offset(center.x - size.width * 0.5f, center.y - size.height * 0.12f), Size(size.width, size.height * 0.24f), style = Stroke(2.dp.toPx()))
                        }
                        listOf(0.1f to 0.15f, 0.88f to 0.2f, 0.85f to 0.9f).forEach { (fx, fy) ->
                            drawCircle(ring.copy(alpha = ring.alpha * 0.8f), 1.2.dp.toPx(), Offset(size.width * fx, size.height * fy))
                        }
                    },
                contentAlignment = Alignment.Center,
            ) { Icon(icon.rounded, null, tint = glyphC(Color.White), modifier = Modifier.size(glyph * 0.62f)) }
        }

        IconStyle.CIRCUIT -> {
            val chip = fillC(Color(0xFF1B2A24))
            val pins = lineC(lerp(accent, Color(0xFFFFC107), 0.4f))
            val traces = extraC(accent)
            Box(
                Modifier
                    .size(box)
                    .drawBehind {
                        val m = size.minDimension * 0.18f
                        // Broches sur les quatre côtés
                        for (i in 1..3) {
                            val p = size.width * (0.2f + i * 0.15f)
                            drawLine(pins, Offset(p, 0f), Offset(p, m), 2.dp.toPx())
                            drawLine(pins, Offset(p, size.height - m), Offset(p, size.height), 2.dp.toPx())
                            drawLine(pins, Offset(0f, p), Offset(m, p), 2.dp.toPx())
                            drawLine(pins, Offset(size.width - m, p), Offset(size.width, p), 2.dp.toPx())
                        }
                        drawRoundRect(chip, Offset(m, m), Size(size.width - 2 * m, size.height - 2 * m), androidx.compose.ui.geometry.CornerRadius(3.dp.toPx()))
                        drawRoundRect(traces.copy(alpha = traces.alpha * 0.8f), Offset(m, m), Size(size.width - 2 * m, size.height - 2 * m), androidx.compose.ui.geometry.CornerRadius(3.dp.toPx()), style = Stroke(1.dp.toPx()))
                        drawCircle(traces, 1.5.dp.toPx(), Offset(m + 4.dp.toPx(), m + 4.dp.toPx()))
                    },
                contentAlignment = Alignment.Center,
            ) { Icon(icon.sharp, null, tint = glyphC(traces), modifier = Modifier.size(glyph * 0.72f)) }
        }

        IconStyle.ENGRENAGE -> {
            val metal = fillC(lerp(accent, Color(0xFFB0874A), 0.55f))
            val edge = lineC(lerp(metal, Color.Black, 0.5f))
            Box(
                Modifier
                    .size(box)
                    .drawBehind {
                        val outer = size.minDimension / 2
                        val gear = androidx.compose.ui.graphics.Path().apply {
                            val n = 10
                            for (i in 0 until n * 4) {
                                val r = if ((i / 2) % 2 == 0) outer else outer * 0.82f
                                val a = Math.toRadians(i * 360.0 / (n * 4)).toFloat()
                                val p = Offset(center.x + kotlin.math.cos(a) * r, center.y + kotlin.math.sin(a) * r)
                                if (i == 0) moveTo(p.x, p.y) else lineTo(p.x, p.y)
                            }
                            close()
                        }
                        drawPath(gear, Brush.radialGradient(listOf(lerp(metal, Color.White, 0.35f), metal, lerp(metal, Color.Black, 0.35f)), center, outer))
                        drawPath(gear, edge, style = Stroke(1.2.dp.toPx()))
                        drawCircle(edge, outer * 0.62f, center, style = Stroke(1.dp.toPx()))
                    },
                contentAlignment = Alignment.Center,
            ) { Icon(icon.sharp, null, tint = glyphC(lerp(metal, Color.Black, 0.7f)), modifier = Modifier.size(glyph * 0.72f)) }
        }

        IconStyle.SCEAU -> {
            val ink = fillC(Color(0xFFC62828))
            val frame = lineC(Color(0xFFFFEBEE))
            val shape = RoundedCornerShape(18)
            Box(
                Modifier
                    .size(box)
                    .clip(shape)
                    .background(ink)
                    .padding(3.dp)
                    .border(1.5.dp, frame.copy(alpha = frame.alpha * 0.85f), RoundedCornerShape(14))
                    .drawBehind {
                        // Encre irrégulière : petites zones non imprimées
                        listOf(0.15f to 0.7f, 0.8f to 0.18f, 0.6f to 0.85f).forEach { (fx, fy) ->
                            drawCircle(Color.White.copy(alpha = 0.18f), 1.4.dp.toPx(), Offset(size.width * fx, size.height * fy))
                        }
                    },
                contentAlignment = Alignment.Center,
            ) { Icon(icon.sharp, null, tint = glyphC(Color(0xFFFFF3E0)), modifier = Modifier.size(glyph * 0.85f)) }
        }

        IconStyle.LANTERNE -> {
            val paper = fillC(Color(0xFFD32F2F))
            val frame = lineC(GOLD)
            val light = extraC(Color(0xFFFFE082))
            Box(
                Modifier
                    .size(box)
                    .drawBehind {
                        val w = size.width; val h = size.height
                        val body = androidx.compose.ui.geometry.Rect(w * 0.12f, h * 0.14f, w * 0.88f, h * 0.84f)
                        drawOval(Brush.radialGradient(listOf(lerp(paper, light, 0.55f), paper, lerp(paper, Color.Black, 0.35f)), body.center, body.width * 0.6f), body.topLeft, body.size)
                        // Nervures du papier
                        for (k in 1..3) {
                            val f = k / 4f
                            drawArc(frame.copy(alpha = frame.alpha * 0.6f), 90f, 180f, false, Offset(body.left + body.width * f - body.width * 0.12f, body.top), Size(body.width * 0.24f, body.height), style = Stroke(0.8.dp.toPx()))
                        }
                        drawRect(frame, Offset(w * 0.3f, h * 0.06f), Size(w * 0.4f, h * 0.1f))
                        drawRect(frame, Offset(w * 0.3f, h * 0.82f), Size(w * 0.4f, h * 0.08f))
                        drawLine(frame, Offset(w / 2, h * 0.9f), Offset(w / 2, h), 1.5.dp.toPx())
                    },
                contentAlignment = Alignment.Center,
            ) { Icon(icon.rounded, null, tint = glyphC(light), modifier = Modifier.size(glyph * 0.62f)) }
        }

        IconStyle.ZELLIGE -> {
            val star = fillC(lerp(accent, Color(0xFF00695C), 0.4f))
            val heart = extraC(Color(0xFFFFF8E1))
            val edge = lineC(Color.White)
            Box(
                Modifier
                    .size(box)
                    .drawBehind {
                        // Étoile à huit branches (deux carrés croisés) et cœur clair
                        val r = size.minDimension / 2
                        val s8 = starPath(center, r, r * 0.76f, 8, -90f)
                        drawPath(s8, star)
                        drawPath(s8, edge, style = Stroke(1.2.dp.toPx()))
                        val s8b = starPath(center, r * 0.6f, r * 0.46f, 8, -67.5f)
                        drawPath(s8b, heart)
                        drawPath(s8b, edge.copy(alpha = edge.alpha * 0.7f), style = Stroke(0.8.dp.toPx()))
                    },
                contentAlignment = Alignment.Center,
            ) { Icon(icon.sharp, null, tint = glyphC(star), modifier = Modifier.size(glyph * 0.62f)) }
        }

        IconStyle.PAPEL -> {
            val paper = fillC(accent)
            val cut = extraC(Color.White.copy(alpha = 0.55f))
            val flag = androidx.compose.foundation.shape.GenericShape { sz, _ ->
                val w = sz.width; val h = sz.height
                moveTo(0f, 0f); lineTo(w, 0f); lineTo(w, h * 0.8f)
                val n = 5
                for (i in n downTo 1) {
                    val x1 = w * i / n; val x0 = w * (i - 1) / n
                    quadraticBezierTo((x0 + x1) / 2, h * 1.02f, x0, h * 0.8f)
                }
                close()
            }
            Box(
                Modifier
                    .size(box)
                    .clip(flag)
                    .background(paper)
                    .drawBehind {
                        // Découpes : losanges et petits ronds
                        val step = size.width / 4
                        for (i in 0..4) for (j in 0..3) {
                            val c = Offset(i * step, j * step + step / 2)
                            if ((i + j) % 2 == 0) drawCircle(cut, 1.4.dp.toPx(), c)
                        }
                        drawLine(lerp(paper, Color.Black, 0.3f), Offset(0f, 1.dp.toPx()), Offset(size.width, 1.dp.toPx()), 2.dp.toPx())
                    },
                contentAlignment = Alignment.Center,
            ) { Icon(icon.filled, null, tint = glyphC(Color.White), modifier = Modifier.size(glyph * 0.78f).padding(bottom = 4.dp)) }
        }

        IconStyle.GRECQUE -> {
            val bg = fillC(Color(0xFF0D47A1))
            val frieze = lineC(Color.White)
            Box(
                Modifier
                    .size(box)
                    .clip(RoundedCornerShape(6.dp))
                    .background(bg)
                    .drawBehind {
                        // Frise grecque (méandre) tout autour
                        val u = size.minDimension / 12
                        val sw = 1.2.dp.toPx()
                        fun meander(ox: Float, oy: Float, dx: Float, dy: Float, n: Int) {
                            for (i in 0 until n) {
                                val bx = ox + dx * i * 3 * u; val by = oy + dy * i * 3 * u
                                val px = -dy; val py = dx
                                val p = listOf(
                                    Offset(0f, 0f), Offset(0f, 2f), Offset(2f, 2f), Offset(2f, 1f), Offset(1f, 1f), Offset(1f, 0f), Offset(3f, 0f),
                                ).map { (a, b) -> Offset(bx + (dx * a + px * b) * u, by + (dy * a + py * b) * u) }
                                for (k in 0 until p.size - 1) drawLine(frieze, p[k], p[k + 1], sw)
                            }
                        }
                        meander(u * 0.5f, u * 2.6f, 1f, 0f, 3)
                        meander(size.width - u * 0.5f, size.height - u * 2.6f, -1f, 0f, 3)
                    },
                contentAlignment = Alignment.Center,
            ) { Icon(icon.sharp, null, tint = glyphC(Color.White), modifier = Modifier.size(glyph * 0.72f)) }
        }
    }
}

/** Effet lumineux sur un titre (néon, grimoire…), ou null. */
@Composable
fun titleGlow(): androidx.compose.ui.graphics.Shadow? {
    val cs = MaterialTheme.colorScheme
    return when (LocalLook.current.deco) {
        Deco.NEON, Deco.SUNSET -> androidx.compose.ui.graphics.Shadow(cs.primary, Offset.Zero, 22f)
        Deco.TERMINAL -> androidx.compose.ui.graphics.Shadow(cs.primary.copy(alpha = 0.8f), Offset.Zero, 14f)
        Deco.GRIMOIRE -> androidx.compose.ui.graphics.Shadow(cs.primary, Offset(0f, 2f), 12f)
        Deco.AURORA, Deco.FIREFLIES, Deco.BUBBLES -> androidx.compose.ui.graphics.Shadow(cs.secondary.copy(alpha = 0.7f), Offset.Zero, 18f)
        Deco.STARS, Deco.STORM -> androidx.compose.ui.graphics.Shadow(cs.primary.copy(alpha = 0.9f), Offset.Zero, 20f)
        Deco.ENERGY -> androidx.compose.ui.graphics.Shadow(cs.secondary, Offset.Zero, 26f)
        Deco.SNOW -> androidx.compose.ui.graphics.Shadow(Color.White.copy(alpha = 0.6f), Offset.Zero, 16f)
        Deco.BLOOD, Deco.FOG, Deco.SHADOWS -> androidx.compose.ui.graphics.Shadow(cs.secondary.copy(alpha = 0.8f), Offset(0f, 2f), 10f)
        Deco.CIRCUIT, Deco.NEBULA, Deco.BOKEH -> androidx.compose.ui.graphics.Shadow(cs.primary.copy(alpha = 0.9f), Offset.Zero, 20f)
        Deco.FLAMES, Deco.LAVA -> androidx.compose.ui.graphics.Shadow(cs.secondary.copy(alpha = 0.9f), Offset.Zero, 22f)
        Deco.WAVES -> androidx.compose.ui.graphics.Shadow(cs.primary.copy(alpha = 0.7f), Offset.Zero, 16f)
        else -> null
    }
}
