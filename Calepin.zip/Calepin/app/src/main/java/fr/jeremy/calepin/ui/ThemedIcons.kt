package fr.jeremy.calepin.ui

import android.os.Build
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.CutCornerShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Contacts
import androidx.compose.material.icons.filled.EditNote
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.SettingsRemote
import androidx.compose.material.icons.filled.SmartToy
import androidx.compose.material.icons.filled.SportsEsports
import androidx.compose.material.icons.outlined.CalendarMonth
import androidx.compose.material.icons.outlined.Contacts
import androidx.compose.material.icons.outlined.EditNote
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Palette
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material.icons.outlined.SettingsRemote
import androidx.compose.material.icons.outlined.SmartToy
import androidx.compose.material.icons.outlined.SportsEsports
import androidx.compose.material.icons.rounded.CalendarMonth
import androidx.compose.material.icons.rounded.Contacts
import androidx.compose.material.icons.rounded.EditNote
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.Palette
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.SettingsRemote
import androidx.compose.material.icons.rounded.SmartToy
import androidx.compose.material.icons.rounded.SportsEsports
import androidx.compose.material.icons.sharp.CalendarMonth
import androidx.compose.material.icons.sharp.Contacts
import androidx.compose.material.icons.sharp.EditNote
import androidx.compose.material.icons.sharp.Home
import androidx.compose.material.icons.sharp.Palette
import androidx.compose.material.icons.sharp.Settings
import androidx.compose.material.icons.sharp.SettingsRemote
import androidx.compose.material.icons.sharp.SmartToy
import androidx.compose.material.icons.sharp.SportsEsports
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Paint
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

/** Icônes de l'accueil, chacune dessinée dans les quatre familles Material (pleine, contour, arrondie, anguleuse). */
enum class AppIcon(val filled: ImageVector, val outlined: ImageVector, val rounded: ImageVector, val sharp: ImageVector) {
    NOTES(Icons.Filled.EditNote, Icons.Outlined.EditNote, Icons.Rounded.EditNote, Icons.Sharp.EditNote),
    AGENDA(Icons.Filled.CalendarMonth, Icons.Outlined.CalendarMonth, Icons.Rounded.CalendarMonth, Icons.Sharp.CalendarMonth),
    ASSISTANT(Icons.Filled.SmartToy, Icons.Outlined.SmartToy, Icons.Rounded.SmartToy, Icons.Sharp.SmartToy),
    CONTACTS(Icons.Filled.Contacts, Icons.Outlined.Contacts, Icons.Rounded.Contacts, Icons.Sharp.Contacts),
    REMOTE(Icons.Filled.SettingsRemote, Icons.Outlined.SettingsRemote, Icons.Rounded.SettingsRemote, Icons.Sharp.SettingsRemote),
    HOME(Icons.Filled.Home, Icons.Outlined.Home, Icons.Rounded.Home, Icons.Sharp.Home),
    GAMES(Icons.Filled.SportsEsports, Icons.Outlined.SportsEsports, Icons.Rounded.SportsEsports, Icons.Sharp.SportsEsports),
    APPEARANCE(Icons.Filled.Palette, Icons.Outlined.Palette, Icons.Rounded.Palette, Icons.Sharp.Palette),
    SETTINGS(Icons.Filled.Settings, Icons.Outlined.Settings, Icons.Rounded.Settings, Icons.Sharp.Settings),
}

private val GOLD = Color(0xFFD4AF37)

@Composable
private fun accentOf(tone: Int): Color = when (tone % 3) {
    0 -> MaterialTheme.colorScheme.primary
    1 -> MaterialTheme.colorScheme.secondary
    else -> MaterialTheme.colorScheme.tertiary
}

/** Contour à coins coupés (octogone), en coordonnées de dessin. */
private fun cutPath(w: Float, h: Float, c: Float, inset: Float = 0f) = android.graphics.Path().apply {
    val l = inset; val t = inset; val r = w - inset; val b = h - inset
    moveTo(l + c, t); lineTo(r - c, t); lineTo(r, t + c); lineTo(r, b - c)
    lineTo(r - c, b); lineTo(l + c, b); lineTo(l, b - c); lineTo(l, t + c); close()
}

/** Trait lumineux (halo) façon néon. Le halo apparaît à partir d'Android 9. */
private fun DrawScope.neonStroke(path: android.graphics.Path, color: Color, width: Float, glow: Float) {
    drawIntoCanvas { canvas ->
        val paint = Paint().asFrameworkPaint().apply {
            isAntiAlias = true
            style = android.graphics.Paint.Style.STROKE
            strokeWidth = width
            this.color = color.toArgb()
            if (Build.VERSION.SDK_INT >= 28) setShadowLayer(glow, 0f, 0f, color.toArgb())
        }
        if (Build.VERSION.SDK_INT < 28) {
            // Halo simulé : traits plus larges et transparents
            val halo = android.graphics.Paint(paint).apply { strokeWidth = width * 4; this.color = color.copy(alpha = 0.18f).toArgb() }
            canvas.nativeCanvas.drawPath(path, halo)
        }
        canvas.nativeCanvas.drawPath(path, paint)
    }
}

/**
 * Icône de rubrique dans le style choisi (ou celui du thème).
 * [tone] alterne les trois couleurs du thème d'une tuile à l'autre.
 */
@Composable
fun ThemedIcon(icon: AppIcon, tone: Int, box: Dp, style: IconStyle = LocalLook.current.icons) {
    val cs = MaterialTheme.colorScheme
    val accent = accentOf(tone)
    val glyph = box * 0.54f
    when (style) {
        IconStyle.AUTO, IconStyle.PLEIN -> {
            val (bg, fg) = when (tone % 3) {
                0 -> cs.primaryContainer to cs.onPrimaryContainer
                1 -> cs.secondaryContainer to cs.onSecondaryContainer
                else -> cs.tertiaryContainer to cs.onTertiaryContainer
            }
            Box(Modifier.size(box).clip(MaterialTheme.shapes.medium).background(bg), contentAlignment = Alignment.Center) {
                Icon(icon.filled, null, tint = fg, modifier = Modifier.size(glyph))
            }
        }

        IconStyle.CONTOUR -> Box(
            Modifier.size(box).border(1.5.dp, accent, MaterialTheme.shapes.medium),
            contentAlignment = Alignment.Center,
        ) { Icon(icon.outlined, null, tint = accent, modifier = Modifier.size(glyph)) }

        IconStyle.MINIMAL -> Box(Modifier.size(box), contentAlignment = Alignment.Center) {
            Icon(icon.rounded, null, tint = accent, modifier = Modifier.size(box * 0.72f))
        }

        IconStyle.BULLE -> {
            val other = when (tone % 3) { 0 -> cs.tertiary; 1 -> cs.primary; else -> cs.secondary }
            Box(
                Modifier
                    .size(box)
                    .clip(RoundedCornerShape(percent = 34))
                    .background(Brush.linearGradient(listOf(lerp(accent, Color.White, 0.15f), lerp(accent, other, 0.65f))))
                    .drawBehind {
                        // Reflet en haut, comme une bulle de verre
                        drawCircle(Color.White.copy(alpha = 0.22f), radius = size.width * 0.42f, center = Offset(size.width * 0.3f, size.height * 0.12f))
                    },
                contentAlignment = Alignment.Center,
            ) { Icon(icon.rounded, null, tint = Color.White, modifier = Modifier.size(glyph)) }
        }

        IconStyle.NEON -> Box(
            Modifier
                .size(box)
                .drawBehind {
                    val c = size.minDimension * 0.22f
                    drawPath(androidx.compose.ui.graphics.Path().apply {
                        moveTo(c, 0f); lineTo(size.width - c, 0f); lineTo(size.width, c); lineTo(size.width, size.height - c)
                        lineTo(size.width - c, size.height); lineTo(c, size.height); lineTo(0f, size.height - c); lineTo(0f, c); close()
                    }, accent.copy(alpha = 0.10f))
                    neonStroke(cutPath(size.width, size.height, c, 1.5f), accent, 2.dp.toPx(), 9.dp.toPx())
                },
            contentAlignment = Alignment.Center,
        ) {
            if (Build.VERSION.SDK_INT >= 31) {
                Icon(icon.outlined, null, tint = accent, modifier = Modifier.size(glyph).blur(5.dp))
            }
            Icon(icon.outlined, null, tint = lerp(accent, Color.White, 0.35f), modifier = Modifier.size(glyph))
        }

        IconStyle.GRIMOIRE -> {
            val shape = CutCornerShape(percent = 30)
            Box(
                Modifier
                    .size(box)
                    .clip(shape)
                    .background(Brush.radialGradient(listOf(lerp(accent, Color.Black, 0.35f), lerp(accent, Color.Black, 0.82f))))
                    .border(1.5.dp, GOLD, shape)
                    .padding(4.dp)
                    .border(0.75.dp, GOLD.copy(alpha = 0.55f), shape)
                    .drawBehind {
                        // Petites gemmes aux quatre points cardinaux
                        val r = 1.6.dp.toPx()
                        listOf(Offset(size.width / 2, 2.5f * r), Offset(size.width / 2, size.height - 2.5f * r), Offset(2.5f * r, size.height / 2), Offset(size.width - 2.5f * r, size.height / 2))
                            .forEach { drawCircle(GOLD, r, it) }
                    },
                contentAlignment = Alignment.Center,
            ) { Icon(icon.sharp, null, tint = GOLD, modifier = Modifier.size(glyph * 0.92f)) }
        }

        IconStyle.TERMINAL -> Box(
            Modifier
                .size(box)
                .background(accent.copy(alpha = 0.07f))
                .drawBehind {
                    // Lignes de balayage et crochets d'angle
                    var y = 0f
                    val gap = 3.dp.toPx()
                    while (y < size.height) { drawLine(accent.copy(alpha = 0.10f), Offset(0f, y), Offset(size.width, y), 1f); y += gap }
                    val l = size.minDimension * 0.28f
                    val w = 2.dp.toPx()
                    val pts = listOf(Offset(0f, 0f) to Offset(1f, 1f), Offset(size.width, 0f) to Offset(-1f, 1f), Offset(0f, size.height) to Offset(1f, -1f), Offset(size.width, size.height) to Offset(-1f, -1f))
                    pts.forEach { (o, d) ->
                        drawLine(accent, o, Offset(o.x + d.x * l, o.y), w)
                        drawLine(accent, o, Offset(o.x, o.y + d.y * l), w)
                    }
                },
            contentAlignment = Alignment.Center,
        ) { Icon(icon.sharp, null, tint = accent, modifier = Modifier.size(glyph)) }
    }
}

/** Décor de fond de l'accueil selon le thème (grille néon, soleil synthwave, grimoire, terminal…). */
fun Modifier.decoBackground(deco: Deco, cs: androidx.compose.material3.ColorScheme): Modifier = when (deco) {
    Deco.NONE -> this
    Deco.NEON -> drawBehind {
        drawRect(Brush.radialGradient(listOf(cs.secondary.copy(alpha = 0.16f), Color.Transparent), center = Offset(size.width * 0.9f, size.height * 0.05f), radius = size.width * 0.8f))
        drawRect(Brush.radialGradient(listOf(cs.primary.copy(alpha = 0.14f), Color.Transparent), center = Offset(0f, size.height * 0.55f), radius = size.width * 0.9f))
        perspectiveGrid(cs.primary.copy(alpha = 0.22f), horizon = size.height * 0.68f)
    }
    Deco.SUNSET -> drawBehind {
        val horizon = size.height * 0.62f
        drawRect(Brush.verticalGradient(listOf(Color.Transparent, cs.primary.copy(alpha = 0.18f)), startY = 0f, endY = horizon))
        val r = size.width * 0.32f
        val center = Offset(size.width * 0.5f, horizon - r * 0.35f)
        drawCircle(Brush.verticalGradient(listOf(cs.secondary.copy(alpha = 0.55f), cs.primary.copy(alpha = 0.45f)), startY = center.y - r, endY = center.y + r), r, center)
        // Bandes horizontales qui découpent le soleil
        var y = center.y + r * 0.05f
        var band = r * 0.05f
        while (y < center.y + r) { drawRect(cs.background, Offset(center.x - r, y), Size(2 * r, band)); y += band * 3.2f; band *= 1.35f }
        drawRect(cs.background, Offset(0f, horizon), Size(size.width, size.height - horizon))
        perspectiveGrid(cs.primary.copy(alpha = 0.35f), horizon = horizon)
    }
    Deco.GRIMOIRE -> drawBehind {
        drawRect(Brush.radialGradient(listOf(cs.primary.copy(alpha = 0.16f), Color.Transparent), center = Offset(size.width * 0.5f, size.height * 0.18f), radius = size.width))
        drawRect(Brush.radialGradient(listOf(Color.Transparent, Color.Black.copy(alpha = 0.55f)), center = center, radius = size.maxDimension * 0.75f))
        // Filets dorés en haut et en bas
        val gold = GOLD.copy(alpha = 0.35f)
        val m = 18.dp.toPx()
        drawLine(gold, Offset(m, m), Offset(size.width - m, m), 1.dp.toPx())
        drawLine(gold, Offset(m, m + 4.dp.toPx()), Offset(size.width - m, m + 4.dp.toPx()), 0.5.dp.toPx())
        drawCircle(gold, 3.dp.toPx(), Offset(size.width / 2, m + 2.dp.toPx()))
    }
    Deco.TERMINAL -> drawBehind {
        drawRect(Brush.radialGradient(listOf(cs.primary.copy(alpha = 0.08f), Color.Transparent), center = center, radius = size.maxDimension * 0.7f))
        var y = 0f
        val gap = 4.dp.toPx()
        while (y < size.height) { drawLine(cs.primary.copy(alpha = 0.045f), Offset(0f, y), Offset(size.width, y), 1.dp.toPx()); y += gap }
    }
    Deco.AURORA -> drawBehind {
        drawRect(Brush.radialGradient(listOf(cs.primary.copy(alpha = 0.22f), Color.Transparent), center = Offset(size.width * 0.15f, size.height * 0.08f), radius = size.width * 0.9f))
        drawRect(Brush.radialGradient(listOf(cs.secondary.copy(alpha = 0.2f), Color.Transparent), center = Offset(size.width * 0.85f, size.height * 0.2f), radius = size.width * 0.85f))
        drawRect(Brush.radialGradient(listOf(cs.tertiary.copy(alpha = 0.14f), Color.Transparent), center = Offset(size.width * 0.5f, size.height * 0.4f), radius = size.width))
    }
    Deco.PAPER -> drawBehind {
        // Lignes de cahier et marge rouge
        val gap = 30.dp.toPx()
        var y = 120.dp.toPx()
        while (y < size.height) { drawLine(cs.primary.copy(alpha = 0.07f), Offset(0f, y), Offset(size.width, y), 1.dp.toPx()); y += gap }
        drawLine(Color(0xFFB03030).copy(alpha = 0.18f), Offset(10.dp.toPx(), 0f), Offset(10.dp.toPx(), size.height), 1.dp.toPx())
    }
}

private fun DrawScope.perspectiveGrid(color: Color, horizon: Float) {
    val w = size.width
    val h = size.height
    val vx = w / 2
    val stroke = 1.dp.toPx()
    // Lignes de fuite
    for (i in -10..10) drawLine(color, Offset(vx + i * w * 0.02f, horizon), Offset(vx + i * w * 0.22f, h), stroke)
    // Lignes horizontales de plus en plus espacées
    var y = horizon
    var step = 4.dp.toPx()
    while (y < h) { drawLine(color, Offset(0f, y), Offset(w, y), stroke); step *= 1.28f; y += step }
    drawLine(color.copy(alpha = (color.alpha * 2).coerceAtMost(1f)), Offset(0f, horizon), Offset(w, horizon), stroke * 1.5f)
}

/** Effet lumineux sur un titre (néon, grimoire…), ou null. */
@Composable
fun titleGlow(): androidx.compose.ui.graphics.Shadow? {
    val cs = MaterialTheme.colorScheme
    return when (LocalLook.current.deco) {
        Deco.NEON, Deco.SUNSET -> androidx.compose.ui.graphics.Shadow(cs.primary, Offset.Zero, 22f)
        Deco.TERMINAL -> androidx.compose.ui.graphics.Shadow(cs.primary.copy(alpha = 0.8f), Offset.Zero, 14f)
        Deco.GRIMOIRE -> androidx.compose.ui.graphics.Shadow(cs.primary, Offset(0f, 2f), 12f)
        Deco.AURORA -> androidx.compose.ui.graphics.Shadow(cs.secondary.copy(alpha = 0.7f), Offset.Zero, 18f)
        else -> null
    }
}
