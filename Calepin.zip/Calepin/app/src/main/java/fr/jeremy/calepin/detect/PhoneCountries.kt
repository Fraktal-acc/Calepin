package fr.jeremy.calepin.detect

/** Indicatifs téléphoniques internationaux (UIT) → pays, drapeau et longueur du numéro national. */
object PhoneCountries {

    data class Country(val code: String, val iso: String, val name: String, val minLen: Int, val maxLen: Int) {
        val flag: String
            get() = if (iso.length == 2 && iso.all { it in 'A'..'Z' }) {
                iso.map { String(Character.toChars(0x1F1E6 + (it - 'A'))) }.joinToString("")
            } else {
                "🌐"
            }
        val label: String get() = "$flag $name (+$code)"
    }

    /** Longueurs du numéro national (sans indicatif ni 0 initial) pour les pays les plus courants. */
    private val LENGTHS: Map<String, IntRange> = mapOf(
        "33" to 9..9, "377" to 8..9, "39" to 6..11, "34" to 9..9, "41" to 9..9, "32" to 8..9,
        "352" to 4..11, "44" to 9..10, "49" to 6..13, "31" to 9..9, "351" to 9..9, "1" to 10..10,
        "212" to 9..9, "213" to 8..9, "216" to 8..8, "43" to 7..13, "45" to 8..8, "46" to 7..10,
        "47" to 8..8, "358" to 6..11, "353" to 7..9, "30" to 10..10, "48" to 9..9, "420" to 9..9,
        "40" to 9..9, "36" to 8..9, "7" to 10..10, "90" to 10..10, "972" to 8..9, "971" to 8..9,
        "61" to 9..9, "64" to 8..10, "81" to 9..10, "86" to 10..11, "91" to 10..10, "55" to 10..11,
        "52" to 10..10, "54" to 10..11, "27" to 9..9, "221" to 9..9, "225" to 10..10, "237" to 9..9,
        "590" to 9..9, "594" to 9..9, "596" to 9..9, "262" to 9..9, "687" to 6..6, "689" to 6..8,
    )

    // indicatif:ISO:nom
    private const val RAW =
        "1:US:États-Unis / Canada|7:RU:Russie / Kazakhstan|20:EG:Égypte|27:ZA:Afrique du Sud|30:GR:Grèce|" +
            "31:NL:Pays-Bas|32:BE:Belgique|33:FR:France|34:ES:Espagne|36:HU:Hongrie|39:IT:Italie|40:RO:Roumanie|" +
            "41:CH:Suisse|43:AT:Autriche|44:GB:Royaume-Uni|45:DK:Danemark|46:SE:Suède|47:NO:Norvège|48:PL:Pologne|" +
            "49:DE:Allemagne|51:PE:Pérou|52:MX:Mexique|53:CU:Cuba|54:AR:Argentine|55:BR:Brésil|56:CL:Chili|" +
            "57:CO:Colombie|58:VE:Venezuela|60:MY:Malaisie|61:AU:Australie|62:ID:Indonésie|63:PH:Philippines|" +
            "64:NZ:Nouvelle-Zélande|65:SG:Singapour|66:TH:Thaïlande|81:JP:Japon|82:KR:Corée du Sud|84:VN:Viêt Nam|" +
            "86:CN:Chine|90:TR:Turquie|91:IN:Inde|92:PK:Pakistan|93:AF:Afghanistan|94:LK:Sri Lanka|95:MM:Birmanie|" +
            "98:IR:Iran|211:SS:Soudan du Sud|212:MA:Maroc|213:DZ:Algérie|216:TN:Tunisie|218:LY:Libye|220:GM:Gambie|" +
            "221:SN:Sénégal|222:MR:Mauritanie|223:ML:Mali|224:GN:Guinée|225:CI:Côte d'Ivoire|226:BF:Burkina Faso|" +
            "227:NE:Niger|228:TG:Togo|229:BJ:Bénin|230:MU:Maurice|231:LR:Liberia|232:SL:Sierra Leone|233:GH:Ghana|" +
            "234:NG:Nigeria|235:TD:Tchad|236:CF:Centrafrique|237:CM:Cameroun|238:CV:Cap-Vert|239:ST:Sao Tomé-et-Principe|" +
            "240:GQ:Guinée équatoriale|241:GA:Gabon|242:CG:Congo|243:CD:RD Congo|244:AO:Angola|245:GW:Guinée-Bissau|" +
            "248:SC:Seychelles|249:SD:Soudan|250:RW:Rwanda|251:ET:Éthiopie|252:SO:Somalie|253:DJ:Djibouti|254:KE:Kenya|" +
            "255:TZ:Tanzanie|256:UG:Ouganda|257:BI:Burundi|258:MZ:Mozambique|260:ZM:Zambie|261:MG:Madagascar|" +
            "262:RE:La Réunion / Mayotte|263:ZW:Zimbabwe|264:NA:Namibie|265:MW:Malawi|266:LS:Lesotho|267:BW:Botswana|" +
            "268:SZ:Eswatini|269:KM:Comores|290:SH:Sainte-Hélène|291:ER:Érythrée|297:AW:Aruba|298:FO:Îles Féroé|" +
            "299:GL:Groenland|350:GI:Gibraltar|351:PT:Portugal|352:LU:Luxembourg|353:IE:Irlande|354:IS:Islande|" +
            "355:AL:Albanie|356:MT:Malte|357:CY:Chypre|358:FI:Finlande|359:BG:Bulgarie|370:LT:Lituanie|371:LV:Lettonie|" +
            "372:EE:Estonie|373:MD:Moldavie|374:AM:Arménie|375:BY:Biélorussie|376:AD:Andorre|377:MC:Monaco|" +
            "378:SM:Saint-Marin|379:VA:Vatican|380:UA:Ukraine|381:RS:Serbie|382:ME:Monténégro|383:XK:Kosovo|" +
            "385:HR:Croatie|386:SI:Slovénie|387:BA:Bosnie-Herzégovine|389:MK:Macédoine du Nord|420:CZ:Tchéquie|" +
            "421:SK:Slovaquie|423:LI:Liechtenstein|500:FK:Îles Malouines|501:BZ:Belize|502:GT:Guatemala|503:SV:Salvador|" +
            "504:HN:Honduras|505:NI:Nicaragua|506:CR:Costa Rica|507:PA:Panama|508:PM:Saint-Pierre-et-Miquelon|" +
            "509:HT:Haïti|590:GP:Guadeloupe / Saint-Martin|591:BO:Bolivie|592:GY:Guyana|593:EC:Équateur|" +
            "594:GF:Guyane|595:PY:Paraguay|596:MQ:Martinique|597:SR:Suriname|598:UY:Uruguay|599:CW:Curaçao|" +
            "670:TL:Timor oriental|672:NF:Norfolk|673:BN:Brunei|674:NR:Nauru|675:PG:Papouasie-Nouvelle-Guinée|" +
            "676:TO:Tonga|677:SB:Îles Salomon|678:VU:Vanuatu|679:FJ:Fidji|680:PW:Palaos|681:WF:Wallis-et-Futuna|" +
            "682:CK:Îles Cook|683:NU:Niue|685:WS:Samoa|686:KI:Kiribati|687:NC:Nouvelle-Calédonie|" +
            "689:PF:Polynésie française|690:TK:Tokelau|691:FM:Micronésie|692:MH:Îles Marshall|850:KP:Corée du Nord|" +
            "852:HK:Hong Kong|853:MO:Macao|855:KH:Cambodge|856:LA:Laos|880:BD:Bangladesh|886:TW:Taïwan|" +
            "960:MV:Maldives|961:LB:Liban|962:JO:Jordanie|963:SY:Syrie|964:IQ:Irak|965:KW:Koweït|966:SA:Arabie saoudite|" +
            "967:YE:Yémen|968:OM:Oman|970:PS:Palestine|971:AE:Émirats arabes unis|972:IL:Israël|973:BH:Bahreïn|" +
            "974:QA:Qatar|975:BT:Bhoutan|976:MN:Mongolie|977:NP:Népal|992:TJ:Tadjikistan|993:TM:Turkménistan|" +
            "994:AZ:Azerbaïdjan|995:GE:Géorgie|996:KG:Kirghizistan|998:UZ:Ouzbékistan"

    val all: List<Country> = RAW.split('|').map { part ->
        val (code, iso, name) = part.split(':', limit = 3)
        val r = LENGTHS[code] ?: 4..12
        Country(code, iso, name, r.first, r.last)
    }

    private val byCode: Map<String, Country> = all.associateBy { it.code }

    val france: Country get() = byCode.getValue("33")

    /** Pays d'un numéro international donné en chiffres (sans + ni 00), indicatif le plus long d'abord. */
    fun find(intlDigits: String): Country? {
        for (len in 3 downTo 1) {
            if (intlDigits.length > len) byCode[intlDigits.substring(0, len)]?.let { return it }
        }
        return null
    }

    /**
     * Numéro « national significatif » (sans indicatif ni 0 initial) : sert à comparer
     * +33 6 12 34 56 78, 0033612345678 et 06 12 34 56 78 comme un seul et même numéro.
     */
    fun nationalPart(number: String): String {
        val raw = number.replace("(0)", "")
        val d = raw.filter { it.isDigit() }
        val t = raw.trimStart()
        return when {
            t.startsWith("+") -> find(d)?.let { d.substring(it.code.length) } ?: d
            d.startsWith("00") -> d.substring(2).let { x -> find(x)?.let { x.substring(it.code.length) } ?: x }
            d.startsWith("0") -> d.substring(1)
            else -> d
        }.trimStart('0').ifEmpty { d }
    }
}
