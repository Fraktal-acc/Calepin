package fr.jeremy.calepin.ui

import android.content.Context
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Undo
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import fr.jeremy.calepin.i18n.RawText
import fr.jeremy.calepin.i18n.Text
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import java.io.File

/**
 * « Annuler » après une suppression : une barre apparaît quelques secondes en bas de l'écran.
 * [Pending.undo] remet ce qui a été supprimé ; [Pending.commit] finit la suppression (fichiers effacés
 * pour de bon) quand la barre disparaît, quand une autre suppression arrive ou quand on quitte l'appli.
 */
object Undo {
    class Pending(val id: Long, val label: String, val undo: () -> Unit, val commit: () -> Unit)

    private val _pending = MutableStateFlow<Pending?>(null)
    val pending: StateFlow<Pending?> = _pending

    /** Durée d'affichage de la barre. */
    const val SHOW_MS = 7_000L

    /** Propose d'annuler la suppression décrite par [label] (« Note supprimée »…). */
    fun offer(label: String, commit: () -> Unit = {}, undo: () -> Unit) {
        val next = Pending(System.nanoTime(), label, undo, commit)
        val prev = synchronized(this) { _pending.value.also { _pending.value = next } }
        prev?.let { runCatching { it.commit() } }
    }

    fun undo(p: Pending) {
        val mine = synchronized(this) { (_pending.value?.id == p.id).also { if (it) _pending.value = null } }
        if (mine) runCatching { p.undo() }
    }

    /** La suppression devient définitive. */
    fun expire(p: Pending) {
        val mine = synchronized(this) { (_pending.value?.id == p.id).also { if (it) _pending.value = null } }
        if (mine) runCatching { p.commit() }
    }

    fun expireAll() { _pending.value?.let { expire(it) } }

    private fun undoDir(ctx: Context) = File(ctx.applicationContext.cacheDir, "undo").apply { mkdirs() }

    /**
     * Met un fichier de côté au lieu de l'effacer (null s'il n'existe pas). [restore] le remet à sa place,
     * [drop] l'efface pour de bon.
     */
    fun stash(ctx: Context, f: File): File? {
        if (!f.exists()) return null
        val dest = File(undoDir(ctx), "${System.nanoTime()}_${f.name}")
        if (f.renameTo(dest)) return dest
        return runCatching { if (f.isDirectory) f.copyRecursively(dest, true) else f.copyTo(dest, true); f.deleteRecursively(); dest }.getOrNull()
    }

    fun restore(stashed: File?, original: File) {
        if (stashed == null || !stashed.exists()) return
        original.parentFile?.mkdirs()
        if (!stashed.renameTo(original)) {
            runCatching { if (stashed.isDirectory) stashed.copyRecursively(original, true) else stashed.copyTo(original, true); stashed.deleteRecursively() }
        }
    }

    fun drop(stashed: File?) { runCatching { stashed?.deleteRecursively() } }

    /** Ménage au démarrage : ce qui a été mis de côté lors d'une session précédente est effacé. */
    fun cleanup(ctx: Context) { runCatching { undoDir(ctx).listFiles()?.forEach { it.deleteRecursively() } } }
}

/** Barre « Annuler » (posée une fois, par-dessus tous les écrans). */
@Composable
fun UndoBarHost() {
    Box(Modifier.fillMaxSize()) { UndoBar() }
}

@Composable
private fun BoxScope.UndoBar() {
    val p by Undo.pending.collectAsStateWithLifecycle()
    val owner = LocalLifecycleOwner.current
    // On quitte l'appli : la suppression devient définitive
    DisposableEffect(owner) {
        val obs = LifecycleEventObserver { _, e -> if (e == Lifecycle.Event.ON_STOP) Undo.expireAll() }
        owner.lifecycle.addObserver(obs)
        onDispose { owner.lifecycle.removeObserver(obs) }
    }
    val cur = p
    if (cur != null) LaunchedEffect(cur.id) {
        delay(Undo.SHOW_MS)
        Undo.expire(cur)
    }
    // Gardé pendant l'animation de sortie
    val last = remember { arrayOfNulls<Undo.Pending>(1) }
    if (cur != null) last[0] = cur
    AnimatedVisibility(
        visible = cur != null,
        enter = slideInVertically { it } + fadeIn(),
        exit = slideOutVertically { it } + fadeOut(),
        modifier = Modifier.align(Alignment.BottomCenter).navigationBarsPadding().imePadding().padding(12.dp),
    ) {
        val shown = cur ?: last[0] ?: return@AnimatedVisibility
        val cs = MaterialTheme.colorScheme
        Surface(
            shape = MaterialTheme.shapes.large,
            color = cs.inverseSurface,
            contentColor = cs.inverseOnSurface,
            shadowElevation = 6.dp,
            modifier = Modifier.widthIn(max = 560.dp).fillMaxWidth(),
        ) {
            Row(Modifier.padding(start = 16.dp, end = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.weight(1f).padding(vertical = 14.dp)) {
                    RawText(shown.label, style = MaterialTheme.typography.bodyMedium, maxLines = 2, overflow = TextOverflow.Ellipsis)
                }
                TextButton(onClick = { Undo.undo(shown) }) {
                    Icon(Icons.AutoMirrored.Filled.Undo, null, tint = cs.inversePrimary)
                    Text("  Annuler", color = cs.inversePrimary)
                }
                IconButton(onClick = { Undo.expire(shown) }) { Icon(Icons.Filled.Close, "Fermer", tint = cs.inverseOnSurface) }
            }
        }
    }
}
