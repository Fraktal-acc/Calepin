package fr.jeremy.calepin.control

import kotlinx.coroutines.delay
import org.json.JSONArray
import org.json.JSONObject
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress

/**
 * Téléviseur Sony Bravia piloté sur le Wi-Fi (API « contrôle IP » de Sony, avec une clé pré-partagée
 * choisie dans les réglages du téléviseur). Les appels réseau se font hors du fil principal.
 */
class BraviaTv(private val ip: String, private val psk: String, private val mac: String = "") {

    data class App(val title: String, val uri: String)

    companion object {
        private const val POWER_ON_IRCC = "AAAAAQAAAAEAAAAuAw=="

        /** Codes IRCC standard des télécommandes Sony, si le téléviseur ne donne pas sa liste. */
        private val DEFAULT_IRCC = mapOf(
            "up" to "AAAAAQAAAAEAAAB0Aw==", "down" to "AAAAAQAAAAEAAAB1Aw==", "left" to "AAAAAQAAAAEAAAA0Aw==",
            "right" to "AAAAAQAAAAEAAAAzAw==", "confirm" to "AAAAAQAAAAEAAABlAw==", "dpadcenter" to "AAAAAgAAAJcAAABKAw==",
            "home" to "AAAAAQAAAAEAAABgAw==", "return" to "AAAAAgAAAJcAAAAjAw==", "volumeup" to "AAAAAQAAAAEAAAASAw==",
            "volumedown" to "AAAAAQAAAAEAAAATAw==", "mute" to "AAAAAQAAAAEAAAAUAw==", "channelup" to "AAAAAQAAAAEAAAAQAw==",
            "channeldown" to "AAAAAQAAAAEAAAARAw==", "input" to "AAAAAQAAAAEAAAAlAw==", "actionmenu" to "AAAAAgAAAMQAAABLAw==",
            "options" to "AAAAAgAAAJcAAAA2Aw==", "gguide" to "AAAAAQAAAAEAAAAOAw==", "epg" to "AAAAAgAAAKQAAABbAw==",
            "display" to "AAAAAQAAAAEAAAA6Aw==", "play" to "AAAAAgAAAJcAAAAaAw==", "pause" to "AAAAAgAAAJcAAAAZAw==",
            "rewind" to "AAAAAgAAAJcAAAAbAw==", "forward" to "AAAAAgAAAJcAAAAcAw==",
            "num1" to "AAAAAQAAAAEAAAAAAw==", "num2" to "AAAAAQAAAAEAAAABAw==", "num3" to "AAAAAQAAAAEAAAACAw==",
            "num4" to "AAAAAQAAAAEAAAADAw==", "num5" to "AAAAAQAAAAEAAAAEAw==", "num6" to "AAAAAQAAAAEAAAAFAw==",
            "num7" to "AAAAAQAAAAEAAAAGAw==", "num8" to "AAAAAQAAAAEAAAAHAw==", "num9" to "AAAAAQAAAAEAAAAIAw==",
            "num0" to "AAAAAQAAAAEAAAAJAw==",
        )

        /** Vrai si un téléviseur Sony répond à cette adresse (cette question ne demande pas la clé). */
        fun probe(host: String): Boolean {
            val body = """{"method":"getInterfaceInformation","params":[],"id":1,"version":"1.0"}"""
            val r = Http.post("http://$host/sony/system", body, mapOf("Content-Type" to "application/json"), timeoutMs = 1500, connectMs = 400)
                ?: return false
            return "productCategory" in r || "modelName" in r
        }
    }

    private var irccCodes: Map<String, String>? = null

    private fun rpc(service: String, method: String, params: Any? = null, version: String = "1.0"): JSONObject? {
        val p = when (params) {
            null -> JSONArray()
            is JSONArray -> params
            else -> JSONArray().put(params)
        }
        val body = JSONObject().put("method", method).put("params", p).put("id", 1).put("version", version).toString()
        val headers = buildMap {
            put("Content-Type", "application/json")
            if (psk.isNotBlank()) put("X-Auth-PSK", psk)
        }
        val r = Http.post("http://$ip/sony/$service", body, headers, timeoutMs = 5000) ?: return null
        return runCatching { JSONObject(r) }.getOrNull()
    }

    private fun ok(r: JSONObject?) = r != null && !r.has("error")

    /** Explication lisible d'une erreur de l'API Sony (clé refusée, contrôle IP désactivé…). */
    fun lastProblem(): String? {
        val r = rpc("system", "getPowerStatus") ?: return "le téléviseur ne répond pas sur le Wi-Fi"
        val err = r.optJSONArray("error") ?: return null
        return when (err.optInt(0)) {
            403 -> "la clé pré-partagée est refusée (vérifie-la dans Paramètres → Maison)"
            else -> "erreur ${err.optInt(0)} ${err.optString(1)}"
        }
    }

    /** Vrai = allumé, faux = en veille, null = injoignable. */
    fun isOn(): Boolean? {
        val r = rpc("system", "getPowerStatus") ?: return null
        return r.firstResult()?.optString("status")?.let { it == "active" }
    }

    /** Adresse matérielle, utile pour réveiller le téléviseur par le réseau. */
    fun macAddress(): String? = rpc("system", "getSystemInformation")?.firstResult()?.optString("macAddr")?.takeIf { it.isNotBlank() }

    fun model(): String? = rpc("system", "getInterfaceInformation")?.firstResult()?.optString("modelName")?.takeIf { it.isNotBlank() }

    suspend fun powerOn(): Boolean {
        wakeOnLan()
        if (isOn() == true) return true
        val a = ok(rpc("system", "setPowerStatus", JSONObject().put("status", true)))
        if (!a) ircc(POWER_ON_IRCC)
        delay(500)
        return a || isOn() == true
    }

    fun powerOff(): Boolean = ok(rpc("system", "setPowerStatus", JSONObject().put("status", false)))

    /** [level] : « +2 », « -3 » ou « 15 ». */
    fun volume(level: String): Boolean {
        for (target in listOf("speaker", "")) {
            if (ok(rpc("audio", "setAudioVolume", JSONObject().put("target", target).put("volume", level)))) return true
        }
        return false
    }

    fun mute(on: Boolean): Boolean = ok(rpc("audio", "setAudioMute", JSONObject().put("status", on)))

    fun hdmi(port: Int): Boolean = ok(rpc("avContent", "setPlayContent", JSONObject().put("uri", "extInput:hdmi?port=$port")))

    fun apps(): List<App> {
        val arr = rpc("appControl", "getApplicationList")?.optJSONArray("result")?.optJSONArray(0) ?: return emptyList()
        return (0 until arr.length()).mapNotNull { i ->
            arr.optJSONObject(i)?.let { App(it.optString("title"), it.optString("uri")) }?.takeIf { it.uri.isNotBlank() }
        }
    }

    fun openApp(app: App): Boolean = ok(rpc("appControl", "setActiveApp", JSONObject().put("uri", app.uri)))

    /** Raison du dernier échec d'une touche (affichée sous la télécommande). */
    @Volatile var lastKeyError: String? = null
        private set

    /** Touche de télécommande par son nom Sony (« Mute », « Home », « ChannelUp »…). */
    fun key(name: String): Boolean {
        val codes = irccCodes ?: run {
            val arr = rpc("system", "getRemoteControllerInfo")?.optJSONArray("result")?.optJSONArray(1)
            val map = mutableMapOf<String, String>()
            if (arr != null) for (i in 0 until arr.length()) {
                val o = arr.optJSONObject(i) ?: continue
                val v = o.optString("value")
                if (v.isNotBlank()) map[o.optString("name").lowercase()] = v
            }
            map.also { if (it.isNotEmpty()) irccCodes = it }
        }
        val code = codes[name.lowercase()] ?: DEFAULT_IRCC[name.lowercase()]
        if (code == null) { lastKeyError = "touche « $name » inconnue de ce téléviseur"; return false }
        if (ircc(code)) return true
        // Le code annoncé par la télé a échoué : on essaie le code Sony standard s'il diffère
        val std = DEFAULT_IRCC[name.lowercase()]
        return std != null && std != code && ircc(std)
    }

    private fun ircc(code: String): Boolean {
        val body = "<?xml version=\"1.0\"?><s:Envelope xmlns:s=\"http://schemas.xmlsoap.org/soap/envelope/\" s:encodingStyle=\"http://schemas.xmlsoap.org/soap/encoding/\">" +
            "<s:Body><u:X_SendIRCC xmlns:u=\"urn:schemas-sony-com:service:IRCC:1\"><IRCCCode>$code</IRCCCode></u:X_SendIRCC></s:Body></s:Envelope>"
        return try {
            val c = (java.net.URL("http://$ip/sony/IRCC").openConnection() as java.net.HttpURLConnection).apply {
                connectTimeout = 3000
                readTimeout = 5000
                useCaches = false
                requestMethod = "POST"
                doOutput = true
                setRequestProperty("Content-Type", "text/xml; charset=UTF-8")
                setRequestProperty("SOAPACTION", "\"urn:schemas-sony-com:service:IRCC:1#X_SendIRCC\"")
                if (psk.isNotBlank()) setRequestProperty("X-Auth-PSK", psk)
            }
            try {
                c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
                val codeHttp = c.responseCode
                runCatching { (if (codeHttp in 200..299) c.inputStream else c.errorStream)?.use { it.readBytes() } }
                if (codeHttp in 200..299) { lastKeyError = null; true } else {
                    lastKeyError = when (codeHttp) {
                        403 -> "le téléviseur refuse les touches (clé pré-partagée, ou « Contrôle à distance » désactivé dans Réseau → Configuration du contrôle IP)"
                        else -> "le téléviseur a refusé la touche (erreur $codeHttp)"
                    }
                    false
                }
            } finally { c.disconnect() }
        } catch (e: Exception) {
            lastKeyError = "le téléviseur ne répond pas sur le Wi-Fi"
            false
        }
    }

    /** Paquet « magique » qui réveille le téléviseur s'il le permet (Démarrage à distance activé). */
    private fun wakeOnLan() {
        val hex = mac.replace(":", "").replace("-", "")
        if (hex.length != 12) return
        runCatching {
            val macBytes = ByteArray(6) { hex.substring(it * 2, it * 2 + 2).toInt(16).toByte() }
            val packet = ByteArray(6) { 0xFF.toByte() } + (1..16).flatMap { macBytes.toList() }.toByteArray()
            DatagramSocket().use { s ->
                s.broadcast = true
                listOf("255.255.255.255", ip.substringBeforeLast('.') + ".255").forEach { addr ->
                    s.send(DatagramPacket(packet, packet.size, InetAddress.getByName(addr), 9))
                }
            }
        }
    }
}
