package fr.jeremy.calepin.control

import kotlinx.coroutines.delay
import org.json.JSONArray
import org.json.JSONObject
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress

/**
 * Téléviseur Sony Bravia piloté sur le Wi-Fi (API « contrôle IP » de Sony, avec une clé pré-partagée
 * choisie dans les réglages du téléviseur). Les appels réseau se font hors du fil principal.
 */
class BraviaTv(
    private val ip: String,
    private val psk: String,
    private val mac: String = "",
    cookie: String = "",
    clientId: String = "",
    private val onSave: ((String, String) -> Unit)? = null,
) {
    /** Identifiant de ce téléphone auprès du téléviseur (un nouveau à chaque demande de code PIN). */
    @Volatile private var clientId: String = clientId.ifBlank { CLIENT_ID }
    @Volatile private var pendingClientId: String? = null
    /** Jeton « auth=… » obtenu par code PIN (téléviseurs 2013-2014, sans clé pré-partagée). */
    @Volatile private var cookie: String = cookie

    /** Vrai quand le téléviseur demande d'autoriser ce téléphone par un code PIN. */
    @Volatile var needsPin: Boolean = false
        private set

    data class App(val title: String, val uri: String)

    companion object {
        private const val POWER_ON_IRCC = "AAAAAQAAAAEAAAAuAw=="
        private const val CLIENT_ID = "CalepinIA:7f3c2a91-5e4d-4b8a-9c1f-2d6e8a0b4c73"

        /** Codes IRCC standard des télécommandes Sony, si le téléviseur ne donne pas sa liste. */
        private val DEFAULT_IRCC = mapOf(
            "up" to "AAAAAQAAAAEAAAB0Aw==", "down" to "AAAAAQAAAAEAAAB1Aw==", "left" to "AAAAAQAAAAEAAAA0Aw==",
            "right" to "AAAAAQAAAAEAAAAzAw==", "confirm" to "AAAAAQAAAAEAAABlAw==", "dpadcenter" to "AAAAAgAAAJcAAABKAw==",
            "home" to "AAAAAQAAAAEAAABgAw==", "return" to "AAAAAgAAAJcAAAAjAw==", "volumeup" to "AAAAAQAAAAEAAAASAw==",
            "volumedown" to "AAAAAQAAAAEAAAATAw==", "mute" to "AAAAAQAAAAEAAAAUAw==", "channelup" to "AAAAAQAAAAEAAAAQAw==",
            "channeldown" to "AAAAAQAAAAEAAAARAw==", "input" to "AAAAAQAAAAEAAAAlAw==", "actionmenu" to "AAAAAgAAAMQAAABLAw==",
            "options" to "AAAAAgAAAJcAAAA2Aw==", "gguide" to "AAAAAQAAAAEAAAAOAw==", "epg" to "AAAAAgAAAKQAAABbAw==",
            "display" to "AAAAAQAAAAEAAAA6Aw==", "play" to "AAAAAgAAAJcAAAAaAw==", "pause" to "AAAAAgAAAJcAAAAZAw==",
            "rewind" to "AAAAAgAAAJcAAAAbAw==", "forward" to "AAAAAgAAAJcAAAAcAw==",
            "num1" to "AAAAAQAAAAEAAAAAAw==", "num2" to "AAAAAQAAAAEAAAABAw==", "num3" to "AAAAAQAAAAEAAAACAw==",
            "num4" to "AAAAAQAAAAEAAAADAw==", "num5" to "AAAAAQAAAAEAAAAEAw==", "num6" to "AAAAAQAAAAEAAAAFAw==",
            "num7" to "AAAAAQAAAAEAAAAGAw==", "num8" to "AAAAAQAAAAEAAAAHAw==", "num9" to "AAAAAQAAAAEAAAAIAw==",
            "num0" to "AAAAAQAAAAEAAAAJAw==",
        )

        /** Vrai si un téléviseur Sony répond à cette adresse (cette question ne demande pas la clé). */
        fun probe(host: String): Boolean {
            val body = """{"method":"getInterfaceInformation","params":[],"id":1,"version":"1.0"}"""
            val r = Http.post("http://$host/sony/system", body, mapOf("Content-Type" to "application/json"), timeoutMs = 1500, connectMs = 400)
                ?: return false
            return "productCategory" in r || "modelName" in r
        }
    }

    private var irccCodes: Map<String, String>? = null

    private fun rpc(service: String, method: String, params: Any? = null, version: String = "1.0"): JSONObject? {
        val p = when (params) {
            null -> JSONArray()
            is JSONArray -> params
            else -> JSONArray().put(params)
        }
        val body = JSONObject().put("method", method).put("params", p).put("id", 1).put("version", version).toString()
        val headers = buildMap {
            put("Content-Type", "application/json")
            if (psk.isNotBlank()) put("X-Auth-PSK", psk)
            if (cookie.isNotBlank()) put("Cookie", cookie)
        }
        val r = Http.post("http://$ip/sony/$service", body, headers, timeoutMs = 5000) ?: return null
        return runCatching { JSONObject(r) }.getOrNull()
    }

    private fun ok(r: JSONObject?) = r != null && !r.has("error")

    /** Explication lisible d'une erreur de l'API Sony (clé refusée, contrôle IP désactivé…). */
    fun lastProblem(): String? {
        val r = rpc("system", "getPowerStatus") ?: return "le téléviseur ne répond pas sur le Wi-Fi"
        val err = r.optJSONArray("error") ?: return null
        return when (err.optInt(0)) {
            403 -> "la clé pré-partagée est refusée (vérifie-la dans Paramètres → Maison)"
            else -> "erreur ${err.optInt(0)} ${err.optString(1)}"
        }
    }

    /** Vrai = allumé, faux = en veille, null = injoignable. */
    fun isOn(): Boolean? {
        val r = rpc("system", "getPowerStatus") ?: return null
        return r.firstResult()?.optString("status")?.let { it == "active" }
    }

    /** Adresse matérielle, utile pour réveiller le téléviseur par le réseau. */
    fun macAddress(): String? = rpc("system", "getSystemInformation")?.firstResult()?.optString("macAddr")?.takeIf { it.isNotBlank() }

    fun model(): String? = rpc("system", "getInterfaceInformation")?.firstResult()?.optString("modelName")?.takeIf { it.isNotBlank() }

    suspend fun powerOn(): Boolean {
        wakeOnLan()
        if (isOn() == true) return true
        val a = ok(rpc("system", "setPowerStatus", JSONObject().put("status", true)))
        if (!a) ircc(POWER_ON_IRCC)
        delay(500)
        return a || isOn() == true
    }

    fun powerOff(): Boolean = ok(rpc("system", "setPowerStatus", JSONObject().put("status", false)))

    /** [level] : « +2 », « -3 » ou « 15 ». */
    fun volume(level: String): Boolean {
        for (target in listOf("speaker", "")) {
            if (ok(rpc("audio", "setAudioVolume", JSONObject().put("target", target).put("volume", level)))) return true
        }
        return false
    }

    fun mute(on: Boolean): Boolean = ok(rpc("audio", "setAudioMute", JSONObject().put("status", on)))

    fun hdmi(port: Int): Boolean = ok(rpc("avContent", "setPlayContent", JSONObject().put("uri", "extInput:hdmi?port=$port")))

    fun apps(): List<App> {
        val arr = rpc("appControl", "getApplicationList")?.optJSONArray("result")?.optJSONArray(0) ?: return emptyList()
        return (0 until arr.length()).mapNotNull { i ->
            arr.optJSONObject(i)?.let { App(it.optString("title"), it.optString("uri")) }?.takeIf { it.uri.isNotBlank() }
        }
    }

    fun openApp(app: App): Boolean = ok(rpc("appControl", "setActiveApp", JSONObject().put("uri", app.uri)))

    /** Raison du dernier échec d'une touche (affichée sous la télécommande). */
    @Volatile var lastKeyError: String? = null
        private set

    /** Touche de télécommande par son nom Sony (« Mute », « Home », « ChannelUp »…). */
    fun key(name: String): Boolean {
        val codes = irccCodes ?: run {
            val arr = rpc("system", "getRemoteControllerInfo")?.optJSONArray("result")?.optJSONArray(1)
            val map = mutableMapOf<String, String>()
            if (arr != null) for (i in 0 until arr.length()) {
                val o = arr.optJSONObject(i) ?: continue
                val v = o.optString("value")
                if (v.isNotBlank()) map[o.optString("name").lowercase()] = v
            }
            map.also { if (it.isNotEmpty()) irccCodes = it }
        }
        val code = codes[name.lowercase()] ?: DEFAULT_IRCC[name.lowercase()]
        if (code == null) { lastKeyError = "touche « $name » inconnue de ce téléviseur"; return false }
        authFailed = false
        if (ircc(code)) return true
        if (authFailed) {
            // Jeton expiré : on le renouvelle sans code ; sinon il faudra autoriser le téléphone par PIN
            if (cookie.isNotBlank() && renew() && ircc(code)) return true
            needsPin = true
            lastKeyError = "ce téléviseur doit d'abord autoriser ce téléphone avec un code PIN"
            return false
        }
        // Le code annoncé par la télé a échoué : on essaie le code Sony standard s'il diffère
        val std = DEFAULT_IRCC[name.lowercase()]
        return std != null && std != code && ircc(std)
    }

    @Volatile private var authFailed = false

    /** Fait afficher un code PIN à 4 chiffres sur l'écran du téléviseur (nouvel enregistrement). */
    fun requestPin(): Boolean {
        val id = "CalepinIA:" + java.util.UUID.randomUUID().toString()
        pendingClientId = id
        val r = register(id, null, null)
        return r.code == 401 || r.code in 200..299
    }

    /** Valide le code PIN affiché par le téléviseur ; vrai si le téléphone est autorisé. */
    fun confirmPin(pin: String): Boolean {
        val id = pendingClientId ?: clientId
        val r = register(id, pin.trim(), null)
        if (r.code !in 200..299 || r.body.contains("\"error\"")) return false
        clientId = id
        pendingClientId = null
        onSave?.invoke("clientid", id)
        r.cookie?.let { cookie = it; onSave?.invoke("cookie", it) }
        needsPin = false
        irccCodes = null
        workingIrcc = null
        return true
    }

    /** Renouvelle le jeton sans code (le téléphone est déjà enregistré). */
    private fun renew(): Boolean {
        val r = register(clientId, null, cookie.takeIf { it.isNotBlank() })
        val c = r.cookie ?: return false
        if (r.code !in 200..299) return false
        cookie = c
        onSave?.invoke("cookie", c)
        return true
    }

    private class Resp(val code: Int, val body: String, val cookie: String?, val error: String? = null)

    private fun raw(url: String, body: String, headers: Map<String, String>, timeoutMs: Int = 5000): Resp = try {
        val c = (java.net.URL(url).openConnection() as java.net.HttpURLConnection).apply {
            connectTimeout = 3000
            readTimeout = timeoutMs
            useCaches = false
            instanceFollowRedirects = false
            requestMethod = "POST"
            doOutput = true
            headers.forEach { (k, v) -> setRequestProperty(k, v) }
        }
        try {
            c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            val code = c.responseCode
            val text = runCatching { (if (code in 200..299) c.inputStream else c.errorStream)?.use { it.readBytes().toString(Charsets.UTF_8) } }.getOrNull().orEmpty()
            val auth = c.headerFields.entries
                .filter { it.key?.equals("Set-Cookie", ignoreCase = true) == true }
                .flatMap { it.value }
                .firstNotNullOfOrNull { Regex("auth=[^;]+").find(it)?.value }
            Resp(code, text, auth)
        } finally { c.disconnect() }
    } catch (e: Exception) {
        Resp(0, "", null, e.javaClass.simpleName + (e.message?.let { ": $it" } ?: ""))
    }

    /** Enregistrement auprès du téléviseur (API « accessControl » des Bravia 2013-2014). */
    private fun register(id: String, pin: String?, withCookie: String?): Resp {
        val body = JSONObject()
            .put("method", "actRegister")
            .put("params", JSONArray()
                .put(JSONObject().put("clientid", id).put("nickname", "Calepin IA (Android)").put("level", "private"))
                .put(JSONArray().put(JSONObject().put("value", "yes").put("function", "WOL"))))
            .put("id", 8).put("version", "1.0").toString()
        val h = buildMap {
            put("Content-Type", "application/json")
            if (pin != null) put("Authorization", "Basic " + java.util.Base64.getEncoder().encodeToString(":$pin".toByteArray(Charsets.UTF_8)))
            if (withCookie != null) put("Cookie", withCookie)
        }
        return raw("http://$ip/sony/accessControl", body, h, 8000)
    }

    /** Variante d'envoi qui a marché (adresse, en-tête XML, authentification). */
    private data class IrccWay(val url: String, val prolog: Boolean, val psk: Boolean)
    @Volatile private var workingIrcc: IrccWay? = null
    @Volatile private var irccUrls: List<String>? = null

    /** Adresses possibles du service de touches : celle annoncée par la télé, puis les habituelles. */
    private fun irccCandidates(): List<String> = irccUrls ?: run {
        val found = mutableListOf<String>()
        for (desc in listOf("http://$ip:52323/dmr.xml", "http://$ip/sony/ircc/IRCCSDesc.xml")) {
            val xml = Http.get(desc, 2500) ?: continue
            Regex("<serviceType>[^<]*IRCC[^<]*</serviceType>[\\s\\S]*?<controlURL>([^<]+)</controlURL>").findAll(xml).forEach { m ->
                val u = m.groupValues[1].trim()
                found += if (u.startsWith("http")) u else "http://$ip" + (if (u.startsWith("/")) u else "/$u")
            }
        }
        (found + "http://$ip/sony/IRCC" + "http://$ip/sony/ircc").distinct().also { irccUrls = it }
    }

    private fun irccBody(code: String, prolog: Boolean) =
        (if (prolog) "<?xml version=\"1.0\"?>" else "") +
            "<s:Envelope xmlns:s=\"http://schemas.xmlsoap.org/soap/envelope/\" s:encodingStyle=\"http://schemas.xmlsoap.org/soap/encoding/\">" +
            "<s:Body><u:X_SendIRCC xmlns:u=\"urn:schemas-sony-com:service:IRCC:1\"><IRCCCode>$code</IRCCCode></u:X_SendIRCC></s:Body></s:Envelope>"

    private fun irccHeaders(withPsk: Boolean) = buildMap {
        put("Content-Type", "text/xml; charset=UTF-8")
        put("SOAPACTION", "\"urn:schemas-sony-com:service:IRCC:1#X_SendIRCC\"")
        if (withPsk && psk.isNotBlank()) put("X-Auth-PSK", psk)
        if (cookie.isNotBlank()) put("Cookie", cookie)
    }

    private fun send(way: IrccWay, code: String): Resp = raw(way.url, irccBody(code, way.prolog), irccHeaders(way.psk))

    private fun ircc(code: String): Boolean {
        workingIrcc?.let { w ->
            val r = send(w, code)
            if (r.code in 200..299) { lastKeyError = null; needsPin = false; return true }
            if (r.code == 0) { lastKeyError = "le téléviseur ne répond pas sur le Wi-Fi"; return false }
        }
        var last: Resp? = null
        loop@ for (url in irccCandidates()) for (prolog in listOf(false, true)) for (withPsk in listOf(true, false)) {
            if (!withPsk && psk.isBlank()) continue
            val w = IrccWay(url, prolog, withPsk)
            val r = send(w, code)
            if (r.code in 200..299) { workingIrcc = w; lastKeyError = null; needsPin = false; return true }
            last = r
            if (r.code == 404) continue@loop
        }
        val r = last
        if (r != null && (r.code == 401 || r.code == 403)) authFailed = true
        lastKeyError = when {
            r == null || r.code == 0 -> "le téléviseur ne répond pas sur le Wi-Fi"
            r.code == 401 || r.code == 403 -> "le téléviseur refuse les touches (autorisation par code PIN nécessaire)"
            else -> "le téléviseur a refusé la touche (erreur ${r.code})"
        }
        return false
    }

    /** Rapport détaillé pour comprendre pourquoi les touches ne passent pas. */
    fun diagnose(): String = buildString {
        appendLine("Adresse : $ip")
        appendLine("Clé pré-partagée : " + if (psk.isBlank()) "aucune" else "oui")
        appendLine("Jeton PIN : " + if (cookie.isBlank()) "aucun" else "oui")
        val power = raw("http://$ip/sony/system", """{"method":"getPowerStatus","params":[],"id":1,"version":"1.0"}""", mapOf("Content-Type" to "application/json"))
        appendLine("État : ${power.code} ${power.error ?: power.body.take(80)}")
        val info = rpc("system", "getRemoteControllerInfo")
        val n = info?.optJSONArray("result")?.optJSONArray(1)?.length() ?: 0
        appendLine("Liste des touches : " + if (info == null) "pas de réponse" else if (n > 0) "$n touches" else info.toString().take(100))
        appendLine("Adresses touches : " + irccCandidates().joinToString())
        val up = DEFAULT_IRCC.getValue("up")
        for (url in irccCandidates()) for (prolog in listOf(false, true)) {
            val r = raw(url, irccBody(up, prolog), irccHeaders(true))
            appendLine("Haut ${url.substringAfter(ip)}${if (prolog) " +xml" else ""} : ${r.code} ${r.error ?: r.body.replace(Regex("\\s+"), " ").take(120)}")
        }
        if (cookie.isNotBlank()) {
            val r = register(clientId, null, cookie)
            appendLine("Renouvellement : ${r.code} cookie=${r.cookie != null} ${r.error ?: r.body.take(80)}")
        }
    }

    /** Paquet « magique » qui réveille le téléviseur s'il le permet (Démarrage à distance activé). */
    private fun wakeOnLan() {
        val hex = mac.replace(":", "").replace("-", "")
        if (hex.length != 12) return
        runCatching {
            val macBytes = ByteArray(6) { hex.substring(it * 2, it * 2 + 2).toInt(16).toByte() }
            val packet = ByteArray(6) { 0xFF.toByte() } + (1..16).flatMap { macBytes.toList() }.toByteArray()
            DatagramSocket().use { s ->
                s.broadcast = true
                listOf("255.255.255.255", ip.substringBeforeLast('.') + ".255").forEach { addr ->
                    s.send(DatagramPacket(packet, packet.size, InetAddress.getByName(addr), 9))
                }
            }
        }
    }
}
