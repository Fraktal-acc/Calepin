package fr.jeremy.calepin.control

import kotlinx.coroutines.delay
import org.json.JSONArray
import org.json.JSONObject
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress

/**
 * Téléviseur Sony Bravia piloté sur le Wi-Fi (API « contrôle IP » de Sony, avec une clé pré-partagée
 * choisie dans les réglages du téléviseur). Les appels réseau se font hors du fil principal.
 */
class BraviaTv(private val ip: String, private val psk: String, private val mac: String = "") {

    data class App(val title: String, val uri: String)

    companion object {
        private const val POWER_ON_IRCC = "AAAAAQAAAAEAAAAuAw=="

        /** Vrai si un téléviseur Sony répond à cette adresse (cette question ne demande pas la clé). */
        fun probe(host: String): Boolean {
            val body = """{"method":"getInterfaceInformation","params":[],"id":1,"version":"1.0"}"""
            val r = Http.post("http://$host/sony/system", body, mapOf("Content-Type" to "application/json"), timeoutMs = 1500, connectMs = 400)
                ?: return false
            return "productCategory" in r || "modelName" in r
        }
    }

    private var irccCodes: Map<String, String>? = null

    private fun rpc(service: String, method: String, params: Any? = null, version: String = "1.0"): JSONObject? {
        val p = when (params) {
            null -> JSONArray()
            is JSONArray -> params
            else -> JSONArray().put(params)
        }
        val body = JSONObject().put("method", method).put("params", p).put("id", 1).put("version", version).toString()
        val headers = buildMap {
            put("Content-Type", "application/json")
            if (psk.isNotBlank()) put("X-Auth-PSK", psk)
        }
        val r = Http.post("http://$ip/sony/$service", body, headers, timeoutMs = 5000) ?: return null
        return runCatching { JSONObject(r) }.getOrNull()
    }

    private fun ok(r: JSONObject?) = r != null && !r.has("error")

    /** Explication lisible d'une erreur de l'API Sony (clé refusée, contrôle IP désactivé…). */
    fun lastProblem(): String? {
        val r = rpc("system", "getPowerStatus") ?: return "le téléviseur ne répond pas sur le Wi-Fi"
        val err = r.optJSONArray("error") ?: return null
        return when (err.optInt(0)) {
            403 -> "la clé pré-partagée est refusée (vérifie-la dans Paramètres → Maison)"
            else -> "erreur ${err.optInt(0)} ${err.optString(1)}"
        }
    }

    /** Vrai = allumé, faux = en veille, null = injoignable. */
    fun isOn(): Boolean? {
        val r = rpc("system", "getPowerStatus") ?: return null
        return r.firstResult()?.optString("status")?.let { it == "active" }
    }

    /** Adresse matérielle, utile pour réveiller le téléviseur par le réseau. */
    fun macAddress(): String? = rpc("system", "getSystemInformation")?.firstResult()?.optString("macAddr")?.takeIf { it.isNotBlank() }

    fun model(): String? = rpc("system", "getInterfaceInformation")?.firstResult()?.optString("modelName")?.takeIf { it.isNotBlank() }

    suspend fun powerOn(): Boolean {
        wakeOnLan()
        if (isOn() == true) return true
        val a = ok(rpc("system", "setPowerStatus", JSONObject().put("status", true)))
        if (!a) ircc(POWER_ON_IRCC)
        delay(500)
        return a || isOn() == true
    }

    fun powerOff(): Boolean = ok(rpc("system", "setPowerStatus", JSONObject().put("status", false)))

    /** [level] : « +2 », « -3 » ou « 15 ». */
    fun volume(level: String): Boolean {
        for (target in listOf("speaker", "")) {
            if (ok(rpc("audio", "setAudioVolume", JSONObject().put("target", target).put("volume", level)))) return true
        }
        return false
    }

    fun mute(on: Boolean): Boolean = ok(rpc("audio", "setAudioMute", JSONObject().put("status", on)))

    fun hdmi(port: Int): Boolean = ok(rpc("avContent", "setPlayContent", JSONObject().put("uri", "extInput:hdmi?port=$port")))

    fun apps(): List<App> {
        val arr = rpc("appControl", "getApplicationList")?.optJSONArray("result")?.optJSONArray(0) ?: return emptyList()
        return (0 until arr.length()).mapNotNull { i ->
            arr.optJSONObject(i)?.let { App(it.optString("title"), it.optString("uri")) }?.takeIf { it.uri.isNotBlank() }
        }
    }

    fun openApp(app: App): Boolean = ok(rpc("appControl", "setActiveApp", JSONObject().put("uri", app.uri)))

    /** Touche de télécommande par son nom Sony (« Mute », « Home », « ChannelUp »…). */
    fun key(name: String): Boolean {
        val codes = irccCodes ?: run {
            val arr = rpc("system", "getRemoteControllerInfo")?.optJSONArray("result")?.optJSONArray(1)
            val map = mutableMapOf<String, String>()
            if (arr != null) for (i in 0 until arr.length()) {
                val o = arr.optJSONObject(i) ?: continue
                map[o.optString("name").lowercase()] = o.optString("value")
            }
            map.also { if (it.isNotEmpty()) irccCodes = it }
        }
        val code = codes[name.lowercase()] ?: return false
        return ircc(code)
    }

    private fun ircc(code: String): Boolean {
        val body = "<s:Envelope xmlns:s=\"http://schemas.xmlsoap.org/soap/envelope/\" s:encodingStyle=\"http://schemas.xmlsoap.org/soap/encoding/\">" +
            "<s:Body><u:X_SendIRCC xmlns:u=\"urn:schemas-sony-com:service:IRCC:1\"><IRCCCode>$code</IRCCCode></u:X_SendIRCC></s:Body></s:Envelope>"
        val headers = buildMap {
            put("Content-Type", "text/xml; charset=UTF-8")
            put("SOAPACTION", "\"urn:schemas-sony-com:service:IRCC:1#X_SendIRCC\"")
            if (psk.isNotBlank()) put("X-Auth-PSK", psk)
        }
        return Http.post("http://$ip/sony/IRCC", body, headers) != null
    }

    /** Paquet « magique » qui réveille le téléviseur s'il le permet (Démarrage à distance activé). */
    private fun wakeOnLan() {
        val hex = mac.replace(":", "").replace("-", "")
        if (hex.length != 12) return
        runCatching {
            val macBytes = ByteArray(6) { hex.substring(it * 2, it * 2 + 2).toInt(16).toByte() }
            val packet = ByteArray(6) { 0xFF.toByte() } + (1..16).flatMap { macBytes.toList() }.toByteArray()
            DatagramSocket().use { s ->
                s.broadcast = true
                listOf("255.255.255.255", ip.substringBeforeLast('.') + ".255").forEach { addr ->
                    s.send(DatagramPacket(packet, packet.size, InetAddress.getByName(addr), 9))
                }
            }
        }
    }
}
