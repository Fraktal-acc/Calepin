package fr.jeremy.calepin.export

import android.graphics.Color
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import fr.jeremy.calepin.data.Note
import java.io.ByteArrayOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** PDF A4 avec le moteur intégré d'Android, une note après l'autre, pages numérotées. */
object PdfExport {
    private const val W = 595 // A4 en points
    private const val H = 842
    private const val M = 50

    fun build(notes: List<Note>): ByteArray {
        val doc = PdfDocument()
        val titlePaint = TextPaint(TextPaint.ANTI_ALIAS_FLAG).apply {
            textSize = 18f; color = Color.rgb(31, 95, 122); typeface = Typeface.DEFAULT_BOLD
        }
        val metaPaint = TextPaint(TextPaint.ANTI_ALIAS_FLAG).apply {
            textSize = 9.5f; color = Color.rgb(138, 90, 51); typeface = Typeface.create(Typeface.DEFAULT, Typeface.ITALIC)
        }
        val bodyPaint = TextPaint(TextPaint.ANTI_ALIAS_FLAG).apply { textSize = 11f; color = Color.rgb(27, 35, 40) }
        val footPaint = TextPaint(TextPaint.ANTI_ALIAS_FLAG).apply { textSize = 8f; color = Color.GRAY }
        val fmt = SimpleDateFormat("d MMMM yyyy 'à' HH:mm", Locale.FRANCE)
        val width = W - 2 * M

        var pageNo = 0
        var page: PdfDocument.Page? = null
        var y = 0f

        fun newPage() {
            page?.let { finish(doc, it, pageNo, footPaint) }
            pageNo++
            page = doc.startPage(PdfDocument.PageInfo.Builder(W, H, pageNo).create())
            y = M.toFloat()
        }

        fun layout(text: String, paint: TextPaint): StaticLayout =
            StaticLayout.Builder.obtain(text, 0, text.length, paint, width)
                .setAlignment(Layout.Alignment.ALIGN_NORMAL).setLineSpacing(2f, 1f).build()

        /** Dessine un bloc de texte, en le coupant ligne par ligne sur plusieurs pages si besoin. */
        fun draw(text: String, paint: TextPaint, after: Float) {
            val l = layout(text, paint)
            var line = 0
            while (line < l.lineCount) {
                if (page == null || y + (l.getLineBottom(line) - l.getLineTop(line)) > H - M - 20) newPage()
                var last = line
                val top = l.getLineTop(line)
                while (last + 1 < l.lineCount && y + (l.getLineBottom(last + 1) - top) <= H - M - 20) last++
                val c = page!!.canvas
                c.save()
                c.translate(M.toFloat(), y - top)
                c.clipRect(0f, top.toFloat(), width.toFloat(), l.getLineBottom(last).toFloat())
                l.draw(c)
                c.restore()
                y += (l.getLineBottom(last) - top).toFloat()
                line = last + 1
            }
            y += after
        }

        notes.forEachIndexed { i, n ->
            if (i > 0) {
                if (y > H - M - 120) newPage() else y += 18f
            }
            draw(n.title.ifBlank { "Sans titre" }, titlePaint, 4f)
            val meta = (if (n.tags.isNotEmpty()) n.tags.joinToString(", ") + " · " else "") +
                "modifiée le " + fmt.format(Date(n.updatedAt))
            draw(meta, metaPaint, 10f)
            draw(n.content.ifEmpty { " " }, bodyPaint, 6f)
        }
        if (page == null) newPage()
        finish(doc, page!!, pageNo, footPaint)

        val out = ByteArrayOutputStream()
        doc.writeTo(out)
        doc.close()
        return out.toByteArray()
    }

    private fun finish(doc: PdfDocument, page: PdfDocument.Page, n: Int, paint: TextPaint) {
        page.canvas.drawText("Calepin · page $n", M.toFloat(), (H - 25).toFloat(), paint)
        doc.finishPage(page)
    }
}
