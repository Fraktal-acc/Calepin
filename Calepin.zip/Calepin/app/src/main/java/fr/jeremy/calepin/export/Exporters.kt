package fr.jeremy.calepin.export

import fr.jeremy.calepin.data.Note
import fr.jeremy.calepin.detect.Entity
import fr.jeremy.calepin.detect.EntityType
import java.io.ByteArrayOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

enum class ExportFormat(val label: String, val ext: String, val mime: String, val hint: String) {
    PDF("PDF", "pdf", "application/pdf", "à lire ou imprimer"),
    DOCX("Word", "docx", "application/vnd.openxmlformats-officedocument.wordprocessingml.document", "modifiable dans Word"),
    XLSX("Excel", "xlsx", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "une ligne par note, numéros et adresses en colonnes"),
    CSV("CSV", "csv", "text/csv", "tableur, séparateur « ; »"),
    TXT("Texte", "txt", "text/plain", "texte brut"),
    MD("Markdown", "md", "text/markdown", "texte avec mise en forme"),
    HTML("Page web", "html", "text/html", "s'ouvre dans un navigateur"),
    JSON("Sauvegarde", "json", "application/json", "à restaurer dans Calepin"),
}

/** Génère les fichiers d'export (hors PDF, qui utilise Android). */
object Exporters {

    private val dateFmt get() = SimpleDateFormat("d MMMM yyyy 'à' HH:mm", Locale.FRANCE)
    private val shortFmt get() = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.FRANCE)

    fun fileName(notes: List<Note>, format: ExportFormat): String {
        val base = if (notes.size == 1) notes[0].title.ifBlank { "Note" } else "Calepin ${notes.size} notes"
        val safe = base.replace(Regex("""[\\/:*?"<>|\n\r\t]"""), " ").trim().take(60).ifBlank { "Calepin" }
        val stamp = SimpleDateFormat("yyyy-MM-dd", Locale.FRANCE).format(Date())
        return "$safe $stamp.${format.ext}"
    }

    fun build(format: ExportFormat, notes: List<Note>, entitiesOf: (Note) -> List<Entity>): ByteArray = when (format) {
        ExportFormat.TXT -> text(notes).toByteArray()
        ExportFormat.MD -> markdown(notes).toByteArray()
        ExportFormat.HTML -> html(notes).toByteArray()
        ExportFormat.CSV -> csv(notes, entitiesOf)
        ExportFormat.DOCX -> docx(notes)
        ExportFormat.XLSX -> xlsx(notes, entitiesOf)
        ExportFormat.JSON -> json(notes).toByteArray()
        ExportFormat.PDF -> error("Le PDF est généré par PdfExport")
    }

    private fun meta(n: Note): String = buildString {
        if (n.tags.isNotEmpty()) append(n.tags.joinToString(", ")).append(" · ")
        append("modifiée le ").append(dateFmt.format(Date(n.updatedAt)))
    }

    fun text(notes: List<Note>): String = notes.joinToString("\n\n" + "─".repeat(32) + "\n\n") { n ->
        "${n.title.ifBlank { "Sans titre" }}\n${meta(n)}\n\n${fr.jeremy.calepin.ui.InlineMedia.strip(n.content)}"
    }

    fun markdown(notes: List<Note>): String = notes.joinToString("\n\n---\n\n") { n ->
        "# ${n.title.ifBlank { "Sans titre" }}\n\n*${meta(n)}*\n\n${fr.jeremy.calepin.ui.InlineMedia.strip(n.content)}"
    }

    fun html(notes: List<Note>): String = buildString {
        append("<!doctype html><html lang=\"fr\"><head><meta charset=\"utf-8\">")
        append("<meta name=\"viewport\" content=\"width=device-width, initial-scale=1\"><title>Calepin</title>")
        append("<style>body{font-family:system-ui,sans-serif;max-width:46rem;margin:2rem auto;padding:0 1rem;color:#1b2328;line-height:1.55}")
        append("article{border-bottom:1px solid #ddd;padding:1.2rem 0}h1{color:#1f5f7a;font-size:1.4rem;margin:0}")
        append(".m{color:#8a5a33;font-size:.85rem;margin:.2rem 0 .8rem}p{white-space:pre-wrap;margin:0}</style></head><body>")
        notes.forEach { n ->
            append("<article><h1>").append(esc(n.title.ifBlank { "Sans titre" })).append("</h1>")
            append("<div class=\"m\">").append(esc(meta(n))).append("</div>")
            append("<p>").append(esc(fr.jeremy.calepin.ui.InlineMedia.strip(n.content))).append("</p></article>")
        }
        append("</body></html>")
    }

    private fun entityCols(n: Note, entitiesOf: (Note) -> List<Entity>): List<String> {
        val e = entitiesOf(n)
        fun of(t: EntityType, v: (Entity) -> String) = e.filter { it.type == t }.joinToString(" | ", transform = v)
        return listOf(
            of(EntityType.PHONE) { x -> x.text + (x.country?.let { " (${it.substringAfter(' ')})" } ?: "") },
            of(EntityType.ADDRESS) { it.value },
            of(EntityType.DATE) { it.value },
            of(EntityType.EMAIL) { it.value },
            of(EntityType.URL) { it.value },
        )
    }

    private val HEADERS = listOf(
        "Titre", "Étiquettes", "Contenu", "Téléphones", "Adresses", "Dates", "E-mails", "Liens", "Épinglée", "Créée", "Modifiée",
    )

    private fun rows(notes: List<Note>, entitiesOf: (Note) -> List<Entity>): List<List<String>> = notes.map { n ->
        listOf(n.title, n.tags.joinToString(", "), fr.jeremy.calepin.ui.InlineMedia.strip(n.content)) + entityCols(n, entitiesOf) +
            listOf(if (n.pinned) "oui" else "non", shortFmt.format(Date(n.createdAt)), shortFmt.format(Date(n.updatedAt)))
    }

    /** CSV au format Excel français : UTF-8 avec BOM, séparateur « ; ». */
    fun csv(notes: List<Note>, entitiesOf: (Note) -> List<Entity>): ByteArray {
        fun cell(s: String) = "\"" + s.replace("\"", "\"\"") + "\""
        val body = (listOf(HEADERS) + rows(notes, entitiesOf)).joinToString("\r\n") { r -> r.joinToString(";") { cell(it) } }
        return byteArrayOf(0xEF.toByte(), 0xBB.toByte(), 0xBF.toByte()) + body.toByteArray()
    }

    fun json(notes: List<Note>): String = buildString {
        append("{\"app\":\"Calepin\",\"version\":1,\"exportedAt\":").append(System.currentTimeMillis()).append(",\"notes\":[")
        notes.forEachIndexed { i, n ->
            if (i > 0) append(',')
            append("{\"title\":").append(jstr(n.title))
            append(",\"content\":").append(jstr(n.content))
            append(",\"tag\":").append(jstr(n.tag))
            append(",\"pinned\":").append(n.pinned)
            if (n.folder.isNotEmpty()) append(",\"folder\":").append(jstr(n.folder))
            append(",\"createdAt\":").append(n.createdAt)
            append(",\"updatedAt\":").append(n.updatedAt).append('}')
        }
        append("]}")
    }

    // ------------------------------------------------------------- Word

    fun docx(notes: List<Note>): ByteArray {
        val body = StringBuilder()
        notes.forEachIndexed { i, n ->
            if (i > 0) body.append("<w:p><w:r><w:br w:type=\"page\"/></w:r></w:p>")
            body.append(para(n.title.ifBlank { "Sans titre" }, bold = true, size = 36, color = "1F5F7A"))
            body.append(para(meta(n), italic = true, size = 20, color = "8A5A33"))
            fr.jeremy.calepin.ui.InlineMedia.strip(n.content).split("\n").forEach { line -> body.append(para(line, size = 24)) }
        }
        val document = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>""" +
            """<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"><w:body>""" +
            body + """<w:sectPr><w:pgSz w:w="11906" w:h="16838"/>""" +
            """<w:pgMar w:top="1134" w:right="1134" w:bottom="1134" w:left="1134" w:header="567" w:footer="567" w:gutter="0"/>""" +
            """</w:sectPr></w:body></w:document>"""
        return zip(
            "[Content_Types].xml" to """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>""" +
                """<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">""" +
                """<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>""" +
                """<Default Extension="xml" ContentType="application/xml"/>""" +
                """<Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/>""" +
                """</Types>""",
            "_rels/.rels" to rels("officeDocument", "word/document.xml"),
            "word/document.xml" to document,
        )
    }

    private fun para(text: String, bold: Boolean = false, italic: Boolean = false, size: Int, color: String? = null): String {
        val rpr = buildString {
            append("<w:rPr><w:rFonts w:ascii=\"Calibri\" w:hAnsi=\"Calibri\" w:cs=\"Calibri\"/>")
            if (bold) append("<w:b/>")
            if (italic) append("<w:i/>")
            if (color != null) append("<w:color w:val=\"$color\"/>")
            append("<w:sz w:val=\"$size\"/></w:rPr>")
        }
        return "<w:p><w:pPr><w:spacing w:after=\"80\"/></w:pPr><w:r>$rpr<w:t xml:space=\"preserve\">${esc(text)}</w:t></w:r></w:p>"
    }

    // ------------------------------------------------------------ Excel

    fun xlsx(notes: List<Note>, entitiesOf: (Note) -> List<Entity>): ByteArray {
        val all = listOf(HEADERS) + rows(notes, entitiesOf)
        val sheet = StringBuilder()
        sheet.append("""<?xml version="1.0" encoding="UTF-8" standalone="yes"?>""")
        sheet.append("""<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">""")
        sheet.append("""<sheetViews><sheetView workbookViewId="0"><pane ySplit="1" topLeftCell="A2" activePane="bottomLeft" state="frozen"/></sheetView></sheetViews>""")
        val widths = listOf(28, 18, 60, 30, 40, 30, 28, 30, 10, 17, 17)
        sheet.append("<cols>")
        widths.forEachIndexed { i, w -> sheet.append("""<col min="${i + 1}" max="${i + 1}" width="$w" customWidth="1"/>""") }
        sheet.append("</cols><sheetData>")
        all.forEachIndexed { r, row ->
            sheet.append("""<row r="${r + 1}">""")
            row.forEachIndexed { c, v ->
                val style = if (r == 0) " s=\"1\"" else " s=\"2\""
                sheet.append("""<c r="${col(c)}${r + 1}" t="inlineStr"$style><is><t xml:space="preserve">${esc(v.take(32_000))}</t></is></c>""")
            }
            sheet.append("</row>")
        }
        sheet.append("</sheetData>")
        sheet.append("""<autoFilter ref="A1:${col(HEADERS.size - 1)}${all.size}"/>""")
        sheet.append("</worksheet>")

        val styles = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>""" +
            """<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">""" +
            """<fonts count="2"><font><sz val="11"/><name val="Calibri"/></font><font><b/><sz val="11"/><color rgb="FFFFFFFF"/><name val="Calibri"/></font></fonts>""" +
            """<fills count="3"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill>""" +
            """<fill><patternFill patternType="solid"><fgColor rgb="FF1F5F7A"/><bgColor indexed="64"/></patternFill></fill></fills>""" +
            """<borders count="1"><border><left/><right/><top/><bottom/><diagonal/></border></borders>""" +
            """<cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>""" +
            """<cellXfs count="3"><xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/>""" +
            """<xf numFmtId="0" fontId="1" fillId="2" borderId="0" xfId="0" applyFont="1" applyFill="1"/>""" +
            """<xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0" applyAlignment="1"><alignment vertical="top" wrapText="1"/></xf></cellXfs>""" +
            """<cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles></styleSheet>"""

        return zip(
            "[Content_Types].xml" to """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>""" +
                """<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">""" +
                """<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>""" +
                """<Default Extension="xml" ContentType="application/xml"/>""" +
                """<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>""" +
                """<Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>""" +
                """<Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>""" +
                """</Types>""",
            "_rels/.rels" to rels("officeDocument", "xl/workbook.xml"),
            "xl/workbook.xml" to """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>""" +
                """<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">""" +
                """<sheets><sheet name="Notes" sheetId="1" r:id="rId1"/></sheets>""" +
                """<definedNames><definedName name="_xlnm._FilterDatabase" localSheetId="0" hidden="1">Notes!${'$'}A${'$'}1:${'$'}${col(HEADERS.size - 1)}${'$'}${all.size}</definedName></definedNames>""" +
                """</workbook>""",
            "xl/_rels/workbook.xml.rels" to """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>""" +
                """<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">""" +
                """<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/>""" +
                """<Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>""" +
                """</Relationships>""",
            "xl/worksheets/sheet1.xml" to sheet.toString(),
            "xl/styles.xml" to styles,
        )
    }

    private fun col(i: Int): String {
        var n = i + 1
        val sb = StringBuilder()
        while (n > 0) { val r = (n - 1) % 26; sb.insert(0, ('A' + r)); n = (n - 1) / 26 }
        return sb.toString()
    }

    // ---------------------------------------------------------- Outils

    private fun rels(type: String, target: String) =
        """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>""" +
            """<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">""" +
            """<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/$type" Target="$target"/>""" +
            """</Relationships>"""

    private fun zip(vararg files: Pair<String, String>): ByteArray {
        val bos = ByteArrayOutputStream()
        ZipOutputStream(bos).use { z ->
            files.forEach { (name, content) ->
                z.putNextEntry(ZipEntry(name))
                z.write(content.toByteArray(Charsets.UTF_8))
                z.closeEntry()
            }
        }
        return bos.toByteArray()
    }

    /** Échappement XML/HTML, en retirant les caractères de contrôle interdits en XML. */
    fun esc(s: String): String = buildString(s.length) {
        for (ch in s) {
            when {
                ch == '&' -> append("&amp;")
                ch == '<' -> append("&lt;")
                ch == '>' -> append("&gt;")
                ch == '"' -> append("&quot;")
                ch < ' ' && ch != '\n' && ch != '\t' && ch != '\r' -> Unit
                else -> append(ch)
            }
        }
    }

    private fun jstr(s: String): String = buildString(s.length + 2) {
        append('"')
        for (ch in s) {
            when (ch) {
                '"' -> append("\\\"")
                '\\' -> append("\\\\")
                '\n' -> append("\\n")
                '\r' -> append("\\r")
                '\t' -> append("\\t")
                else -> if (ch < ' ') append("\\u%04x".format(ch.code)) else append(ch)
            }
        }
        append('"')
    }
}
