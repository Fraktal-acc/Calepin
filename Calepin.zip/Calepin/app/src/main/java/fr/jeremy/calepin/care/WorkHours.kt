package fr.jeremy.calepin.care

import android.content.Context
import fr.jeremy.calepin.data.Event
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/** Une vacation (créneau de travail) avec le détail de ses heures. */
data class ShiftHours(
    val start: Long,
    val end: Long,
    val title: String,
    val minutes: Int,
    val night: Int,
    val sunday: Int,
    val holiday: Int,
)

/** Heures d'une semaine (lundi → dimanche) et heures au-delà du contrat. */
data class WeekHours(val monday: Long, val minutes: Int, val over: Int)

data class MonthHours(
    val shifts: List<ShiftHours>,
    val weeks: List<WeekHours>,
) {
    val total get() = shifts.sumOf { it.minutes }
    val night get() = shifts.sumOf { it.night }
    val day get() = total - night
    val sunday get() = shifts.sumOf { it.sunday }
    val holiday get() = shifts.sumOf { it.holiday }
    val over get() = weeks.sumOf { it.over }
}

/**
 * Calcul des heures de travail à partir des vacations de l'agenda : total, heures de nuit,
 * dimanches, jours fériés (France) et heures au-delà de la durée hebdomadaire du contrat.
 */
object WorkHours {
    private fun p(ctx: Context) = ctx.applicationContext.getSharedPreferences("calepin_care", Context.MODE_PRIVATE)
    fun weeklyMinutes(ctx: Context) = p(ctx).getInt("contract_week", 35 * 60)
    fun nightStart(ctx: Context) = p(ctx).getInt("night_start", 21 * 60)
    fun nightEnd(ctx: Context) = p(ctx).getInt("night_end", 6 * 60)
    fun setRules(ctx: Context, weekly: Int, nightStart: Int, nightEnd: Int) {
        p(ctx).edit().putInt("contract_week", weekly).putInt("night_start", nightStart).putInt("night_end", nightEnd).apply()
    }

    /** Jours fériés en France pour l'année (clés « année-jourDeL'année »). */
    fun holidays(year: Int): Set<Int> {
        // Pâques (calcul grégorien)
        val a = year % 19; val b = year / 100; val c = year % 100
        val d = b / 4; val e = b % 4; val f = (b + 8) / 25; val g = (b - f + 1) / 3
        val h = (19 * a + b - d - g + 15) % 30; val i = c / 4; val k = c % 4
        val l = (32 + 2 * e + 2 * i - h - k) % 7; val m = (a + 11 * h + 22 * l) / 451
        val month = (h + l - 7 * m + 114) / 31
        val day = ((h + l - 7 * m + 114) % 31) + 1
        val easter = Calendar.getInstance().apply { clear(); set(year, month - 1, day) }
        fun doy(mo: Int, dd: Int) = Calendar.getInstance().apply { clear(); set(year, mo, dd) }.get(Calendar.DAY_OF_YEAR)
        fun plus(n: Int) = (easter.clone() as Calendar).apply { add(Calendar.DAY_OF_YEAR, n) }.get(Calendar.DAY_OF_YEAR)
        return setOf(
            doy(0, 1), plus(1), doy(4, 1), doy(4, 8), plus(39), plus(50),
            doy(6, 14), doy(7, 15), doy(10, 1), doy(10, 11), doy(11, 25),
        )
    }

    private fun isNight(minuteOfDay: Int, start: Int, end: Int) =
        if (start > end) minuteOfDay >= start || minuteOfDay < end else minuteOfDay in start until end

    fun shift(e: Event, nightStart: Int, nightEnd: Int): ShiftHours? {
        if (e.allDay || e.end <= e.start || e.end - e.start > 24 * 3_600_000L) return null
        val c = Calendar.getInstance()
        var night = 0; var sunday = 0; var holiday = 0; var total = 0
        var t = e.start
        var year = -1
        var hol: Set<Int> = emptySet()
        while (t < e.end) {
            c.timeInMillis = t
            if (c.get(Calendar.YEAR) != year) { year = c.get(Calendar.YEAR); hol = holidays(year) }
            val mod = c.get(Calendar.HOUR_OF_DAY) * 60 + c.get(Calendar.MINUTE)
            total++
            if (isNight(mod, nightStart, nightEnd)) night++
            if (c.get(Calendar.DAY_OF_WEEK) == Calendar.SUNDAY) sunday++
            if (c.get(Calendar.DAY_OF_YEAR) in hol) holiday++
            t += 60_000L
        }
        return ShiftHours(e.start, e.end, e.title, total, night, sunday, holiday)
    }

    /** Heures du mois ([year], [month] de 0 à 11). */
    fun month(events: List<Event>, year: Int, month: Int, weekly: Int, nightStart: Int, nightEnd: Int): MonthHours {
        val from = Calendar.getInstance().apply { clear(); set(year, month, 1) }
        val to = (from.clone() as Calendar).apply { add(Calendar.MONTH, 1) }
        val work = events.filter { it.isWork }
        val shifts = work.filter { it.start >= from.timeInMillis && it.start < to.timeInMillis }
            .mapNotNull { shift(it, nightStart, nightEnd) }.sortedBy { it.start }
        // Semaines (lundi → dimanche) qui touchent le mois, comptées en entier
        val monday = (from.clone() as Calendar).apply {
            val dow = (get(Calendar.DAY_OF_WEEK) + 5) % 7
            add(Calendar.DAY_OF_YEAR, -dow)
        }
        val weeks = ArrayList<WeekHours>()
        while (monday.timeInMillis < to.timeInMillis) {
            val ws = monday.timeInMillis
            val we = (monday.clone() as Calendar).apply { add(Calendar.DAY_OF_YEAR, 7) }.timeInMillis
            val minutes = work.filter { it.start in ws until we }.mapNotNull { shift(it, nightStart, nightEnd) }.sumOf { it.minutes }
            weeks += WeekHours(ws, minutes, (minutes - weekly).coerceAtLeast(0))
            monday.add(Calendar.DAY_OF_YEAR, 7)
        }
        return MonthHours(shifts, weeks)
    }

    fun hm(min: Int): String = if (min % 60 == 0) "${min / 60} h" else "%d h %02d".format(min / 60, min % 60)

    /** Relevé au format tableur (CSV, séparateur « ; », lisible par Excel). */
    fun csv(m: MonthHours): String = buildString {
        append("Date;Début;Fin;Durée (h);Nuit (h);Dimanche (h);Férié (h);Intitulé\n")
        val d = SimpleDateFormat("dd/MM/yyyy", Locale.FRANCE)
        val h = SimpleDateFormat("HH:mm", Locale.FRANCE)
        fun dec(v: Int) = "%.2f".format(Locale.FRANCE, v / 60.0)
        m.shifts.forEach { s ->
            append(d.format(Date(s.start))).append(';').append(h.format(Date(s.start))).append(';').append(h.format(Date(s.end))).append(';')
            append(dec(s.minutes)).append(';').append(dec(s.night)).append(';').append(dec(s.sunday)).append(';').append(dec(s.holiday)).append(';')
            append(s.title.replace(";", ",")).append('\n')
        }
        append("Total;;;").append(dec(m.total)).append(';').append(dec(m.night)).append(';').append(dec(m.sunday)).append(';').append(dec(m.holiday)).append(";\n")
        append("Heures au-delà du contrat;;;").append(dec(m.over)).append(";;;;\n")
    }
}

/** Historique des imports de planning : ce qui a été ajouté, modifié ou retiré, et quand. */
object PlanningLog {
    private fun p(ctx: Context) = ctx.applicationContext.getSharedPreferences("calepin_care", Context.MODE_PRIVATE)

    data class Entry(val time: Long, val added: Int, val changed: Int, val removed: Int, val details: List<String>)

    fun record(ctx: Context, add: List<Event>, replace: List<Pair<Event, Event>>, delete: List<Event>) {
        val f = SimpleDateFormat("EEE d MMM HH:mm", Locale.FRANCE)
        val g = SimpleDateFormat("HH:mm", Locale.FRANCE)
        fun span(e: Event) = f.format(Date(e.start)) + (if (e.end > e.start) "–" + g.format(Date(e.end)) else "")
        val details = replace.map { (o, n) -> "Modifié : ${span(o)} → ${span(n)}" } +
            delete.map { "Retiré : ${span(it)}" } + add.take(10).map { "Ajouté : ${span(it)}" }
        val a = all(ctx).toMutableList()
        a.add(0, Entry(System.currentTimeMillis(), add.size, replace.size, delete.size, details))
        val arr = JSONArray()
        a.take(30).forEach { e ->
            arr.put(JSONObject().put("t", e.time).put("a", e.added).put("c", e.changed).put("r", e.removed).put("d", JSONArray(e.details)))
        }
        p(ctx).edit().putString("planning_log", arr.toString()).apply()
        // Une vacation à venir a changé : notification, pour ne pas la manquer
        val now = System.currentTimeMillis()
        val upcoming = replace.count { it.first.start > now || it.second.start > now } + delete.count { it.start > now }
        if (upcoming > 0) {
            Care.notify(ctx, 74, "Planning modifié", details.filter { !it.startsWith("Ajouté") }.take(6).joinToString("\n"), "workhours")
        }
    }

    fun all(ctx: Context): List<Entry> = runCatching {
        val a = JSONArray(p(ctx).getString("planning_log", "[]"))
        (0 until a.length()).map { i ->
            val o = a.getJSONObject(i)
            val d = o.optJSONArray("d") ?: JSONArray()
            Entry(o.optLong("t"), o.optInt("a"), o.optInt("c"), o.optInt("r"), (0 until d.length()).map { d.optString(it) })
        }
    }.getOrDefault(emptyList())
}
