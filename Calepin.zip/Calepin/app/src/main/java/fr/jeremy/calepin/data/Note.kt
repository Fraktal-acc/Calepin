package fr.jeremy.calepin.data

data class Note(
    val id: Long = 0,
    val title: String = "",
    val content: String = "",
    /** Étiquettes séparées par des virgules, ex. « Clients, Urgent ». */
    val tag: String = "",
    val pinned: Boolean = false,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
) {
    val tags: List<String>
        get() = tag.split(',').map { it.trim() }.filter { it.isNotEmpty() }
}
