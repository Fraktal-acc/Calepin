package fr.jeremy.calepin.control

import android.content.Context
import fr.jeremy.calepin.search.TextNorm
import kotlinx.coroutines.delay
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

/** Un scénario : plusieurs commandes à la suite (« allume la télé », « mets HDMI 1 », « pause 3 »…). */
data class Scenario(val id: String = UUID.randomUUID().toString(), val name: String, val steps: List<String>) {
    fun toJson(): JSONObject = JSONObject().put("id", id).put("name", name).put("steps", JSONArray(steps))

    companion object {
        fun fromJson(o: JSONObject) = Scenario(
            id = o.optString("id").ifBlank { UUID.randomUUID().toString() },
            name = o.optString("name"),
            steps = o.optJSONArray("steps")?.let { a -> (0 until a.length()).map { a.optString(it) } }.orEmpty().filter { it.isNotBlank() },
        )
    }
}

object Scenarios {
    private fun prefs(ctx: Context) = ctx.applicationContext.getSharedPreferences("calepin_scenarios", Context.MODE_PRIVATE)

    val EXAMPLES = listOf(
        Scenario(name = "Soirée film", steps = listOf("allume la télé", "pause 6", "mets la télé sur HDMI 1", "baisse la lumière du salon à 20 %")),
        Scenario(name = "Bonne nuit", steps = listOf("éteins la télé", "éteins le décodeur", "éteins toutes les lumières", "active ne pas déranger")),
        Scenario(name = "Journal de 20h", steps = listOf("allume le décodeur", "pause 5", "mets TF1")),
    )

    fun all(ctx: Context): List<Scenario> {
        val raw = prefs(ctx).getString("list", null) ?: return EXAMPLES
        return runCatching { JSONArray(raw).let { a -> (0 until a.length()).map { Scenario.fromJson(a.getJSONObject(it)) } } }.getOrDefault(EXAMPLES)
    }

    fun save(ctx: Context, list: List<Scenario>) {
        prefs(ctx).edit().putString("list", JSONArray().apply { list.forEach { put(it.toJson()) } }.toString()).apply()
    }

    fun upsert(ctx: Context, s: Scenario) {
        val l = all(ctx).toMutableList()
        val i = l.indexOfFirst { it.id == s.id }
        if (i >= 0) l[i] = s else l += s
        save(ctx, l)
    }

    fun delete(ctx: Context, id: String) = save(ctx, all(ctx).filter { it.id != id })

    /** Le scénario nommé dans la phrase (« lance soirée film », « mode bonne nuit », « soirée film »), ou null. */
    fun find(ctx: Context, normText: String): Scenario? {
        val t = normText.replace(Regex("^(lance|lancer|active|activer|demarre|mets|passe en|mode|scenario)\\s+(le |la |l')?(scenario |mode )?"), "").trim()
        return all(ctx).firstOrNull { TextNorm.norm(it.name).trim() == t }
    }

    /** Exécute chaque étape ; renvoie le compte rendu (une ligne par étape). */
    @Volatile var running = false
        private set

    suspend fun run(ctx: Context, s: Scenario, onStep: (String) -> Unit = {}): String {
        if (running) return "Un scénario est déjà en cours."
        running = true
        try { return runSteps(ctx, s, onStep) } finally { running = false }
    }

    private suspend fun runSteps(ctx: Context, s: Scenario, onStep: (String) -> Unit): String {
        val cmds = DeviceCommands(ctx)
        val report = mutableListOf<String>()
        for (step in s.steps) {
            val n = TextNorm.norm(step).trim()
            val pause = Regex("^(pause|attends?|attendre)\\s+(\\d{1,3})").find(n)?.groupValues?.get(2)?.toIntOrNull()
            if (pause != null) {
                onStep("Pause de $pause s…")
                delay(pause * 1000L)
                continue
            }
            onStep(step)
            val r = runCatching { cmds.handle(step) }.getOrNull()
            report += "• $step : " + (r?.text ?: "pas compris")
        }
        return "Scénario « ${s.name} » terminé.\n" + report.joinToString("\n")
    }
}
