package fr.jeremy.calepin.control

import android.content.Context
import fr.jeremy.calepin.search.TextNorm
import kotlinx.coroutines.delay
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

/** Un scénario : plusieurs commandes à la suite (« allume la télé », « mets HDMI 1 », « pause 3 »…). */
data class Scenario(val id: String = UUID.randomUUID().toString(), val name: String, val steps: List<String>) {
    fun toJson(): JSONObject = JSONObject().put("id", id).put("name", name).put("steps", JSONArray(steps))

    companion object {
        fun fromJson(o: JSONObject) = Scenario(
            id = o.optString("id").ifBlank { UUID.randomUUID().toString() },
            name = o.optString("name"),
            steps = o.optJSONArray("steps")?.let { a -> (0 until a.length()).map { a.optString(it) } }.orEmpty().filter { it.isNotBlank() },
        )
    }
}

object Scenarios {
    private fun prefs(ctx: Context) = ctx.applicationContext.getSharedPreferences("calepin_scenarios", Context.MODE_PRIVATE)

    /** Exemples proposés au départ : noms dans la langue de l'appli, étapes en français (comprises directement). */
    val EXAMPLES: List<Scenario> get() = listOf(
        Scenario(id = "exemple-film", name = fr.jeremy.calepin.i18n.I18n.tr("Soirée film"), steps = listOf("allume la télé", "pause 6", "mets la télé sur HDMI 1", "baisse la lumière du salon à 20 %")),
        Scenario(id = "exemple-nuit", name = fr.jeremy.calepin.i18n.I18n.tr("Bonne nuit"), steps = listOf("éteins la télé", "éteins le décodeur", "éteins toutes les lumières", "active ne pas déranger")),
        Scenario(id = "exemple-journal", name = fr.jeremy.calepin.i18n.I18n.tr("Journal de 20h"), steps = listOf("allume le décodeur", "pause 5", "mets TF1")),
    )

    fun all(ctx: Context): List<Scenario> {
        val raw = prefs(ctx).getString("list", null) ?: return EXAMPLES
        return runCatching { JSONArray(raw).let { a -> (0 until a.length()).map { Scenario.fromJson(a.getJSONObject(it)) } } }.getOrDefault(EXAMPLES)
    }

    fun save(ctx: Context, list: List<Scenario>) {
        prefs(ctx).edit().putString("list", JSONArray().apply { list.forEach { put(it.toJson()) } }.toString()).apply()
    }

    fun upsert(ctx: Context, s: Scenario) {
        val l = all(ctx).toMutableList()
        val i = l.indexOfFirst { it.id == s.id }
        if (i >= 0) l[i] = s else l += s
        save(ctx, l)
    }

    fun delete(ctx: Context, id: String) = save(ctx, all(ctx).filter { it.id != id })

    /** Le scénario nommé dans la phrase (« lance soirée film », « mode bonne nuit », « soirée film »), ou null. */
    fun find(ctx: Context, normText: String): Scenario? {
        val t = normText.replace(Regex("^(lance|lancer|active|activer|demarre|mets|passe en|mode|scenario)\\s+(le |la |l')?(scenario |mode )?"), "").trim()
        return all(ctx).firstOrNull { TextNorm.norm(it.name).trim() == t }
    }

    /** Exécute chaque étape ; renvoie le compte rendu (une ligne par étape). */
    @Volatile var running = false
        private set

    suspend fun run(ctx: Context, s: Scenario, onStep: (String) -> Unit = {}): String {
        if (running) return fr.jeremy.calepin.i18n.I18n.tr("Un scénario est déjà en cours.")
        running = true
        try { return runSteps(ctx, s, onStep) } finally { running = false }
    }

    private suspend fun runSteps(ctx: Context, s: Scenario, onStep: (String) -> Unit): String {
        val cmds = DeviceCommands(ctx)
        val report = mutableListOf<String>()
        fun pauseOf(t: String) =
            Regex("^(pause|attends?|attendre)\\s+(\\d{1,3})").find(TextNorm.norm(t).trim())?.groupValues?.get(2)?.toIntOrNull()
        for (step in s.steps) {
            val pause = pauseOf(step)
            if (pause != null) {
                onStep(fr.jeremy.calepin.i18n.I18n.trf("Pause de {0} s…", pause))
                delay(pause * 1000L)
                continue
            }
            onStep(step)
            var r = runCatching { cmds.handle(step) }.getOrNull()
            // Étape écrite dans une autre langue : Calepin IA la réécrit en commande française
            if (r == null) {
                val frCmd = fr.jeremy.calepin.ai.AiLanguage.frenchCommand(ctx, step)
                if (frCmd != null) {
                    val p = pauseOf(frCmd)
                    if (p != null) { onStep(fr.jeremy.calepin.i18n.I18n.trf("Pause de {0} s…", p)); delay(p * 1000L); continue }
                    r = runCatching { cmds.handle(frCmd) }.getOrNull()
                }
            }
            report += "• $step : " + (r?.text ?: fr.jeremy.calepin.i18n.I18n.tr("pas compris"))
        }
        return fr.jeremy.calepin.i18n.I18n.trf("Scénario « {0} » terminé.", s.name) + "\n" + report.joinToString("\n")
    }
}
