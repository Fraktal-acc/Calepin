package fr.jeremy.calepin

import android.app.Application

/** Démarrage de l'appli : le journal des plantages est installé avant tout le reste. */
class CalepinApp : Application() {
    override fun onCreate() {
        super.onCreate()
        fr.jeremy.calepin.care.CrashLog.install(this)
        fr.jeremy.calepin.i18n.I18n.init(this)
        // Appareils de la maison toujours joints par le Wi-Fi (même si le téléphone bascule sur les données mobiles)
        runCatching { fr.jeremy.calepin.control.LanNet.init(this) }
        // Tâches automatiques (sauvegarde, réveils, URSSAF, routines) reprogrammées à chaque démarrage
        Thread { runCatching { fr.jeremy.calepin.care.Care.scheduleAll(this) } }.start()
        // Robot de bourse : vérification en arrière-plan (si activé)
        Thread { runCatching { fr.jeremy.calepin.market.Market.schedule(this) } }.start()
        Thread { runCatching { fr.jeremy.calepin.care.LegacyCleanup.run(this) }; fr.jeremy.calepin.ui.Undo.cleanup(this) }.start()
        // PDF téléchargés : ajoutés tout seuls au Bureau
        runCatching { fr.jeremy.calepin.office.PdfDownloads.start(this) }
        // Chargeur branché pendant que l'appli tourne : réaction immédiate (sinon, la tâche Android prend le relais)
        runCatching {
            androidx.core.content.ContextCompat.registerReceiver(
                this, fr.jeremy.calepin.care.CareReceiver(),
                android.content.IntentFilter(android.content.Intent.ACTION_POWER_CONNECTED),
                androidx.core.content.ContextCompat.RECEIVER_NOT_EXPORTED,
            )
        }
    }
}
