package fr.jeremy.calepin

import android.app.Application

/** Démarrage de l'appli : le journal des plantages est installé avant tout le reste. */
class CalepinApp : Application() {
    override fun onCreate() {
        super.onCreate()
        fr.jeremy.calepin.care.CrashLog.install(this)
        fr.jeremy.calepin.i18n.I18n.init(this)
        // Tâches automatiques (sauvegarde, réveils, URSSAF, routines) reprogrammées à chaque démarrage
        Thread { runCatching { fr.jeremy.calepin.care.Care.scheduleAll(this) } }.start()
        // PDF téléchargés : ajoutés tout seuls au Bureau
        runCatching { fr.jeremy.calepin.office.PdfDownloads.start(this) }
        // Chargeur branché pendant que l'appli tourne : réaction immédiate (sinon, la tâche Android prend le relais)
        runCatching {
            androidx.core.content.ContextCompat.registerReceiver(
                this, fr.jeremy.calepin.care.CareReceiver(),
                android.content.IntentFilter(android.content.Intent.ACTION_POWER_CONNECTED),
                androidx.core.content.ContextCompat.RECEIVER_NOT_EXPORTED,
            )
        }
    }
}
