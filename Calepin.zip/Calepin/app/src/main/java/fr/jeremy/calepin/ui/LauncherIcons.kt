package fr.jeremy.calepin.ui

import android.content.ComponentName
import android.content.Context
import android.content.pm.PackageManager
import fr.jeremy.calepin.R

/** Icône de l'appli sur l'écran du téléphone : une « entrée » par style, une seule active. */
enum class LauncherIcon(val label: String, val alias: String, val fg: Int, val bg: Int?, val bgColor: Long) {
    CLASSIQUE("Classique", "IconClassic", R.drawable.ic_launcher_foreground, null, 0xFF1F5F7A),
    NEON("Néon", "IconNeon", R.drawable.ic_launcher_neon_fg, R.drawable.ic_launcher_neon_bg, 0xFF0A0614),
    GRIMOIRE("Grimoire", "IconGrimoire", R.drawable.ic_launcher_grimoire_fg, R.drawable.ic_launcher_grimoire_bg, 0xFF140A0E),
    TERMINAL("Terminal", "IconTerminal", R.drawable.ic_launcher_terminal_fg, R.drawable.ic_launcher_terminal_bg, 0xFF030803),
    SYNTHWAVE("Synthwave", "IconSynthwave", R.drawable.ic_launcher_synthwave_fg, R.drawable.ic_launcher_synthwave_bg, 0xFF2B0F4C),
    GALAXIE("Galaxie", "IconGalaxie", R.drawable.ic_launcher_galaxie_fg, R.drawable.ic_launcher_galaxie_bg, 0xFF05070F),
    MANGA("Manga", "IconManga", R.drawable.ic_launcher_manga_fg, R.drawable.ic_launcher_manga_bg, 0xFFFFC400),
    GOTHIQUE("Gothique", "IconGothique", R.drawable.ic_launcher_gothique_fg, R.drawable.ic_launcher_gothique_bg, 0xFF080808);

    private fun component(ctx: Context) = ComponentName(ctx.packageName, "fr.jeremy.calepin.$alias")

    companion object {
        fun current(ctx: Context): LauncherIcon {
            val pm = ctx.packageManager
            return entries.firstOrNull { icon ->
                when (pm.getComponentEnabledSetting(icon.component(ctx))) {
                    PackageManager.COMPONENT_ENABLED_STATE_ENABLED -> true
                    PackageManager.COMPONENT_ENABLED_STATE_DEFAULT -> icon == CLASSIQUE
                    else -> false
                }
            } ?: CLASSIQUE
        }

        /** Active l'icône choisie (le lanceur du téléphone peut mettre quelques secondes à la montrer). */
        fun apply(ctx: Context, chosen: LauncherIcon) {
            val pm = ctx.packageManager
            // D'abord activer la nouvelle, puis éteindre les autres : il y a toujours une icône
            pm.setComponentEnabledSetting(chosen.component(ctx), PackageManager.COMPONENT_ENABLED_STATE_ENABLED, PackageManager.DONT_KILL_APP)
            entries.filter { it != chosen }.forEach {
                pm.setComponentEnabledSetting(it.component(ctx), PackageManager.COMPONENT_ENABLED_STATE_DISABLED, PackageManager.DONT_KILL_APP)
            }
        }
    }
}
