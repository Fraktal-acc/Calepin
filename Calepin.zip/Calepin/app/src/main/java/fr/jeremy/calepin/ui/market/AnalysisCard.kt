package fr.jeremy.calepin.ui.market

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import fr.jeremy.calepin.i18n.I18n
import fr.jeremy.calepin.i18n.RawText
import fr.jeremy.calepin.i18n.Text
import fr.jeremy.calepin.market.AnalysisResult
import fr.jeremy.calepin.market.Analyzer
import fr.jeremy.calepin.market.MarketData
import fr.jeremy.calepin.market.Series
import fr.jeremy.calepin.market.Timeframe
import fr.jeremy.calepin.ui.appBorder
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.util.Locale
import kotlin.math.abs

private val GREEN = Color(0xFF2E9E4F)
private val RED = Color(0xFFE0453A)

private fun n2(x: Double, d: Int) = if (x.isNaN()) "–" else String.format(Locale.FRANCE, "%,.${d}f", x).replace(' ', ' ')
private fun dec(p: Double) = when { abs(p) < 2 -> 4; abs(p) < 20 -> 3; else -> 2 }

/**
 * Analyse du robot sur l'instrument : score combiné de tous les indicateurs (tendance, RSI, MACD, Bollinger,
 * stochastique, Fibonacci, supports et résistances, volume, bougies, tendance de fond), verdict, confiance,
 * plan (entrée, stop, objectifs) et fiabilité de ces signaux dans le passé de l'instrument.
 */
@Composable
fun AnalysisCard(symbol: String, reload: Int) {
    var tf by rememberSaveable { mutableStateOf(Timeframe.D1) }
    var details by rememberSaveable { mutableStateOf(false) }
    val result by produceState<Pair<AnalysisResult?, Series?>?>(null, symbol, tf, reload) {
        value = null
        var base: Series? = ChartCache.get("$symbol|${tf.name}")
        while (true) {
            val r = withContext(Dispatchers.IO) {
                runCatching {
                    val s = base?.let { b -> MarketData.merge(b, MarketData.latest(symbol, tf), tf) } ?: MarketData.series(symbol, tf)
                    val h = Analyzer.higher(tf)?.let { ht ->
                        ChartCache.get("$symbol|${ht.name}") ?: runCatching { MarketData.series(symbol, ht).also { ChartCache.put("$symbol|${ht.name}", it) } }.getOrNull()
                    }
                    ChartCache.put("$symbol|${tf.name}", s)
                    s to h
                }.getOrNull()
            }
            if (r != null) {
                base = r.first
                // Actualités du web sur l'instrument : un élément de plus dans le score
                val news = withContext(Dispatchers.IO) {
                    runCatching { fr.jeremy.calepin.market.News.forInstrument(symbol, fr.jeremy.calepin.market.Market.watch.value.firstOrNull { it.symbol == symbol }?.name ?: r.first.name) }.getOrNull()
                }
                // Contexte de marché : peur des marchés (VIX), indice de référence, humeur des cryptos, dollar
                val type = fr.jeremy.calepin.market.Market.watch.value.firstOrNull { it.symbol == symbol }?.type.orEmpty()
                val ctxF = withContext(Dispatchers.IO) { runCatching { fr.jeremy.calepin.market.MarketContext.factors(symbol, type, r.first.candles) }.getOrDefault(emptyList()) }
                val extra = listOfNotNull(news?.let { fr.jeremy.calepin.market.NewsText.factor(it) }) + ctxF
                val an = withContext(Dispatchers.Default) { Analyzer(r.first.candles).analyze(htf = r.second?.candles, extra = extra) }
                value = an to r.first
            } else if (value == null) value = null to null
            delay(60_000L)
        }
    }
    val cs = MaterialTheme.colorScheme
    Surface(shape = MaterialTheme.shapes.large, color = cs.surfaceContainerLow, border = appBorder(), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("Analyse du robot", style = MaterialTheme.typography.titleMedium)
            TimeframePicker(tf) { tf = it }
            val pair = result
            val an = pair?.first
            val s = pair?.second
            if (pair == null) {
                Text("Analyse en cours…", color = cs.onSurfaceVariant)
                return@Column
            }
            if (an == null || s == null) {
                Text("Analyse impossible : pas de connexion ou pas assez d'historique pour cette durée de bougies.", color = cs.onSurfaceVariant)
                return@Column
            }
            val col = when { an.score >= 35 -> GREEN; an.score <= -35 -> RED; else -> cs.onSurfaceVariant }
            // Jauge de -100 (vente) à +100 (achat)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(an.verdict, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = col)
                    RawText(
                        I18n.tr("Score") + " " + (if (an.score > 0) "+" else "") + n2(an.score, 0) + " / 100 · " + I18n.tr("confiance") + " " + n2(an.confidence, 0) + " %",
                        style = MaterialTheme.typography.bodyMedium,
                    )
                }
            }
            ScoreGauge(an.score)
            // Plan
            val plan = an.plan
            if (plan != null) {
                val d = dec(plan.entry)
                Surface(shape = MaterialTheme.shapes.medium, color = (if (plan.buy) GREEN else RED).copy(alpha = 0.12f), modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text(if (plan.buy) "Plan d'achat proposé" else "Plan de vente proposé", style = MaterialTheme.typography.titleSmall, color = if (plan.buy) GREEN else RED)
                        fun pctOf(p: Double) = (if (p >= plan.entry) "+" else "") + n2((p - plan.entry) / plan.entry * 100, 2) + " %"
                        PlanLine("Entrée", n2(plan.entry, d), "")
                        PlanLine("Stop de perte", n2(plan.stop, d), pctOf(plan.stop))
                        PlanLine("Objectif 1", n2(plan.target1, d), pctOf(plan.target1))
                        PlanLine("Objectif 2", n2(plan.target2, d), pctOf(plan.target2))
                        RawText(I18n.tr("Gain possible") + " : " + n2(plan.rr, 1) + " × " + I18n.tr("le risque"), style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.SemiBold)
                    }
                }
            } else {
                Text(
                    if (abs(an.score) >= 35) "Signal présent, mais le gain possible jusqu'au prochain obstacle ne couvre pas assez le risque : mieux vaut attendre."
                    else "Les indicateurs ne sont pas assez d'accord pour acheter ou vendre : mieux vaut attendre un signal plus net.",
                    style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant,
                )
            }
            // Fiabilité passée
            an.backtest?.let { bt ->
                if (bt.trades > 0) RawText(
                    I18n.tr("Dans le passé de cet instrument") + " : " + bt.trades + " " + I18n.tr("signaux") + ", " + n2(bt.winRate, 0) + " % " + I18n.tr("gagnants") +
                        " (" + I18n.tr("objectif 1,5 × le risque") + ")" + " · " + I18n.tr("résultat moyen") + " " + (if (bt.avgR >= 0) "+" else "") + n2(bt.avgR, 2) + " R",
                    style = MaterialTheme.typography.labelMedium,
                    color = if (bt.avgR > 0) GREEN else if (bt.avgR < 0) RED else cs.onSurfaceVariant,
                )
                else Text("Pas encore assez de signaux passés pour mesurer la fiabilité.", style = MaterialTheme.typography.labelSmall, color = cs.onSurfaceVariant)
            }
            HorizontalDivider()
            // Détail de chaque indicateur
            an.factors.forEach { fct ->
                Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(fct.name, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                        RawText(
                            when { fct.value >= 0.3 -> I18n.tr("achat"); fct.value <= -0.3 -> I18n.tr("vente"); else -> I18n.tr("neutre") },
                            style = MaterialTheme.typography.labelMedium,
                            color = when { fct.value >= 0.3 -> GREEN; fct.value <= -0.3 -> RED; else -> cs.onSurfaceVariant },
                        )
                    }
                    FactorBar(fct.value)
                    if (details || abs(fct.value) >= 0.3) RawText(fct.detail, style = MaterialTheme.typography.labelSmall, color = cs.onSurfaceVariant)
                }
            }
            TextButton(onClick = { details = !details }) { Text(if (details) "Moins de détails" else "Tous les détails") }
            if (details) {
                HorizontalDivider()
                val d = dec(s.price)
                if (an.fib.isNotEmpty()) {
                    Text("Niveaux de Fibonacci", style = MaterialTheme.typography.titleSmall)
                    an.fib.forEach { l -> PlanLine(l.label, n2(l.price, d), "") }
                }
                if (an.resistances.isNotEmpty()) {
                    Text("Résistances au-dessus", style = MaterialTheme.typography.titleSmall)
                    an.resistances.forEach { l -> PlanLine(I18n.tr("Résistance"), n2(l.price, d), "") }
                }
                if (an.supports.isNotEmpty()) {
                    Text("Supports en dessous", style = MaterialTheme.typography.titleSmall)
                    an.supports.forEach { l -> PlanLine(I18n.tr("Support"), n2(l.price, d), "") }
                }
                RawText("ATR 14 : " + n2(an.atr, d) + " · ADX 14 : " + n2(an.adx, 0), style = MaterialTheme.typography.labelSmall, color = cs.onSurfaceVariant)
            }
            Text(
                "Le score combine tous les indicateurs, pondérés selon le type de marché (en tendance ou sans direction). C'est une aide à la décision, pas une certitude : aucun calcul ne prédit le marché à coup sûr.",
                style = MaterialTheme.typography.labelSmall, color = cs.onSurfaceVariant,
            )
        }
    }
}

@Composable
private fun PlanLine(label: String, value: String, extra: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(label, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
        RawText(value, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
        if (extra.isNotEmpty()) {
            Spacer(Modifier.width(8.dp))
            RawText(extra, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

/** Jauge du score : rouge (vente) à gauche, vert (achat) à droite, repère sur la valeur. */
@Composable
private fun ScoreGauge(score: Double) {
    val ink = MaterialTheme.colorScheme.onSurface
    Column {
        Canvas(Modifier.fillMaxWidth().height(16.dp)) {
            val h = size.height * 0.5f
            val top = (size.height - h) / 2
            drawRoundRect(
                Brush.horizontalGradient(listOf(RED, Color(0xFFE0A030), Color(0xFF9E9E9E), Color(0xFF8BC34A), GREEN)),
                Offset(0f, top), Size(size.width, h), CornerRadius(h / 2, h / 2),
            )
            val x = (size.width * ((score + 100) / 200)).toFloat().coerceIn(0f, size.width)
            drawCircle(ink, size.height / 2, Offset(x, size.height / 2))
            drawCircle(Color.White, size.height / 2 - 3f, Offset(x, size.height / 2))
        }
        Row {
            Text("Vente", style = MaterialTheme.typography.labelSmall, color = RED, modifier = Modifier.weight(1f))
            Text("Neutre", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Box(Modifier.weight(1f), contentAlignment = Alignment.CenterEnd) {
                Text("Achat", style = MaterialTheme.typography.labelSmall, color = GREEN)
            }
        }
    }
}

/** Petite barre centrée : vers la droite (vert) = achat, vers la gauche (rouge) = vente. */
@Composable
private fun FactorBar(value: Double) {
    val track = MaterialTheme.colorScheme.surfaceVariant
    Canvas(Modifier.fillMaxWidth().height(6.dp)) {
        drawRoundRect(track, Offset.Zero, size, CornerRadius(3f, 3f))
        val mid = size.width / 2
        val w = (abs(value) * mid).toFloat()
        if (value > 0) drawRoundRect(GREEN, Offset(mid, 0f), Size(w, size.height), CornerRadius(3f, 3f))
        else if (value < 0) drawRoundRect(RED, Offset(mid - w, 0f), Size(w, size.height), CornerRadius(3f, 3f))
        drawLine(Color.Gray, Offset(mid, 0f), Offset(mid, size.height), 1.5f)
    }
}
