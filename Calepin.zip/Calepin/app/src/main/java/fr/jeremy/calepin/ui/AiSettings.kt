package fr.jeremy.calepin.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.RadioButton
import fr.jeremy.calepin.i18n.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import fr.jeremy.calepin.NotesViewModel
import fr.jeremy.calepin.ai.AiModel
import fr.jeremy.calepin.ai.AiModels

/** Réglages de l'IA hors ligne (affichés seulement dans Calepin IA). */
@Composable
fun AiSettings(vm: NotesViewModel) {
    val ctx = LocalContext.current
    val download by vm.aiDownload.collectAsStateWithLifecycle()
    val version by vm.aiModelsVersion.collectAsStateWithLifecycle()
    val ram = remember { AiModels.totalRamGb(ctx) }
    val active = remember(version, download) { AiModels.active(ctx) }
    var confirmDelete by remember { mutableStateOf<AiModel?>(null) }

    // Écran allumé pendant le téléchargement (plusieurs minutes)
    val view = LocalView.current
    val downloading = download != null && download?.error == null
    DisposableEffect(downloading) {
        view.keepScreenOn = downloading
        onDispose { view.keepScreenOn = false }
    }

    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text(
            "Quand l'assistant ne reconnaît pas une commande, un modèle d'IA installé sur le téléphone répond, " +
                "en s'appuyant sur tes notes et ton agenda. Rien ne quitte le téléphone.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Text(
            "Mémoire du téléphone : %.0f Go".format(ram),
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        AiModels.all.forEach { m ->
            val installed = remember(version, download) { AiModels.isInstalled(ctx, m) }
            val partial = remember(version, download) { AiModels.partialBytes(ctx, m) }
            val dl = download?.takeIf { it.modelId == m.id }
            Card(
                border = fr.jeremy.calepin.ui.appBorder(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLow),
                modifier = Modifier.fillMaxWidth(),
            ) {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        if (installed) {
                            RadioButton(selected = active?.id == m.id, onClick = { vm.selectAiModel(m) })
                        }
                        Column(Modifier.weight(1f)) {
                            Text(m.label, style = MaterialTheme.typography.titleSmall)
                            Text(
                                "${m.sizeLabel} · conseillé à partir de ${m.minRamGb} Go de mémoire",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                    }
                    Text(m.description, style = MaterialTheme.typography.bodySmall)
                    if (ram + 0.5 < m.minRamGb) {
                        Text(
                            "Ce téléphone a peu de mémoire pour ce modèle : il risque d'être lent ou de se fermer.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.error,
                        )
                    }
                    when {
                        installed -> Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                if (active?.id == m.id) "Installé · utilisé par l'assistant" else "Installé",
                                style = MaterialTheme.typography.labelLarge,
                                color = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.weight(1f),
                            )
                            TextButton(onClick = { confirmDelete = m }) { Text("Supprimer") }
                        }
                        dl != null && dl.error == null -> {
                            val p = if (dl.total > 0) (dl.done.toFloat() / dl.total).coerceIn(0f, 1f) else 0f
                            LinearProgressIndicator(progress = { p }, modifier = Modifier.fillMaxWidth())
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    "%d %% · %.2f / %.2f Go".format((p * 100).toInt(), dl.done / 1e9, dl.total / 1e9),
                                    style = MaterialTheme.typography.labelMedium,
                                    modifier = Modifier.weight(1f),
                                )
                                TextButton(onClick = { vm.pauseAiDownload() }) { Text("Pause") }
                            }
                        }
                        else -> {
                            dl?.error?.let {
                                Text(it, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error)
                            }
                            val busyOther = download != null && download?.error == null
                            OutlinedButton(
                                onClick = { vm.startAiDownload(m) },
                                enabled = !busyOther,
                                modifier = Modifier.fillMaxWidth(),
                            ) {
                                Text(
                                    if (partial > 0) "Reprendre le téléchargement (%.1f Go déjà reçus)".format(partial / 1e9)
                                    else "Télécharger (${m.sizeLabel}, en Wi-Fi de préférence)"
                                )
                            }
                        }
                    }
                }
            }
        }
        Text(
            "Le téléchargement se fait une seule fois. S'il est interrompu, il reprend là où il s'était arrêté. " +
                "Garde Calepin IA ouvert pendant ce temps (l'écran reste allumé). La première réponse prend quelques " +
                "secondes, le temps de charger le modèle en mémoire.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }

    confirmDelete?.let { m ->
        AlertDialog(
            onDismissRequest = { confirmDelete = null },
            title = { Text("Supprimer ${m.label} ?") },
            text = { Text("Cela libère ${m.sizeLabel}. Il faudra le retélécharger pour réutiliser l'IA.") },
            confirmButton = {
                TextButton(onClick = { vm.deleteAiModel(m); confirmDelete = null }) {
                    Text("Supprimer", color = MaterialTheme.colorScheme.error)
                }
            },
            dismissButton = { TextButton(onClick = { confirmDelete = null }) { Text("Annuler") } },
        )
    }
}
