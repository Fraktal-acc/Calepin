package fr.jeremy.calepin.reminders

import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import fr.jeremy.calepin.R
import fr.jeremy.calepin.data.NoteDb

/** Fait sonner l'alarme en boucle (sonnerie choisie) jusqu'à « Arrêter » ou « Répéter ». */
class AlarmService : Service() {
    private var player: MediaPlayer? = null
    private var vibrator: Vibrator? = null
    private val handler = Handler(Looper.getMainLooper())
    private var eventId = -1L

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> { stopAll(); return START_NOT_STICKY }
            ACTION_SNOOZE -> {
                val id = intent.getLongExtra(Reminders.EXTRA_EVENT, eventId)
                NoteDb(this).event(id)?.let { Reminders.schedule(this, it, System.currentTimeMillis() + SNOOZE_MS) }
                stopAll(); return START_NOT_STICKY
            }
        }
        val id = intent?.getLongExtra(Reminders.EXTRA_EVENT, -1) ?: -1
        val e = NoteDb(this).event(id)
        if (e == null) { stopSelf(); return START_NOT_STICKY }
        eventId = id

        val full = PendingIntent.getActivity(
            this, 200_000 + id.toInt(),
            Intent(this, AlarmActivity::class.java).putExtra(Reminders.EXTRA_EVENT, id)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_NO_USER_ACTION),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )
        val notif = NotificationCompat.Builder(this, Reminders.alarmChannel(this))
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle(e.title)
            .setContentText(ReminderReceiver.whenText(e.start, e.allDay))
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setFullScreenIntent(full, true)
            .setContentIntent(full)
            .setOngoing(true)
            .addAction(0, "Arrêter", action(ACTION_STOP, id))
            .addAction(0, "Répéter dans 5 min", action(ACTION_SNOOZE, id))
            .build()
        ServiceCompat.startForeground(
            this, NOTIF_ID, notif,
            if (Build.VERSION.SDK_INT >= 29) ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK else 0,
        )
        startSound(Reminders.resolve(this, e.ringtone, alarm = true))
        handler.postDelayed({ stopAll() }, AUTO_STOP_MS)
        return START_NOT_STICKY
    }

    private fun action(act: String, id: Long): PendingIntent = PendingIntent.getService(
        this, act.hashCode() + id.toInt(),
        Intent(this, AlarmService::class.java).setAction(act).putExtra(Reminders.EXTRA_EVENT, id),
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
    )

    private fun startSound(uri: android.net.Uri) {
        player?.release()
        player = runCatching {
            MediaPlayer().apply {
                setAudioAttributes(
                    AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build()
                )
                setDataSource(this@AlarmService, uri)
                isLooping = true
                prepare()
                start()
            }
        }.getOrNull() ?: runCatching {
            MediaPlayer().apply {
                setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM).build())
                setDataSource(this@AlarmService, Reminders.defaultAlarmUri())
                isLooping = true
                prepare()
                start()
            }
        }.getOrNull()
        @Suppress("DEPRECATION")
        vibrator = (getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator)?.also {
            it.vibrate(VibrationEffect.createWaveform(longArrayOf(0, 800, 600), 0))
        }
    }

    private fun stopAll() {
        handler.removeCallbacksAndMessages(null)
        player?.runCatching { stop(); release() }
        player = null
        vibrator?.cancel()
        ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
        (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).cancel(NOTIF_ID)
        sendBroadcast(Intent(ACTION_FINISHED).setPackage(packageName))
        stopSelf()
    }

    override fun onDestroy() {
        player?.runCatching { release() }
        vibrator?.cancel()
        super.onDestroy()
    }

    companion object {
        const val ACTION_STOP = "fr.jeremy.calepin.ALARM_STOP"
        const val ACTION_SNOOZE = "fr.jeremy.calepin.ALARM_SNOOZE"
        const val ACTION_FINISHED = "fr.jeremy.calepin.ALARM_FINISHED"
        private const val NOTIF_ID = 4242
        const val SNOOZE_MS = 5 * 60_000L
        private const val AUTO_STOP_MS = 10 * 60_000L

        fun send(ctx: Context, action: String, id: Long) {
            ctx.startService(Intent(ctx, AlarmService::class.java).setAction(action).putExtra(Reminders.EXTRA_EVENT, id))
        }
    }
}
