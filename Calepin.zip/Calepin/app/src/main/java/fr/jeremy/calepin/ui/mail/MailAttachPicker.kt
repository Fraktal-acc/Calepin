package fr.jeremy.calepin.ui.mail

import android.content.Context
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Notes
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Forum
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import fr.jeremy.calepin.SectionLock
import fr.jeremy.calepin.data.NoteDb
import fr.jeremy.calepin.i18n.I18n
import fr.jeremy.calepin.i18n.RawText
import fr.jeremy.calepin.i18n.Text
import fr.jeremy.calepin.mail.Outgoing
import fr.jeremy.calepin.search.TextNorm
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Endroits de Calepin d'où l'on peut joindre un fichier à un mail. */
private enum class Source(val label: String, val icon: ImageVector) {
    NOTES("Notes", Icons.AutoMirrored.Filled.Notes),
    PDF("PDF du Bureau", Icons.Filled.PictureAsPdf),
    PHOTOS("Photos et vidéos", Icons.Filled.PhotoLibrary),
    MEMOS("Mémos vocaux", Icons.Filled.Mic),
    MESSAGES("Reçus dans Messages", Icons.Filled.Forum),
}

/** Format d'envoi d'une note. */
private enum class NoteFormat(val label: String, val ext: String, val mime: String) {
    PDF("PDF", "pdf", "application/pdf"),
    TXT("Texte", "txt", "text/plain"),
    DOCX("Word", "docx", "application/vnd.openxmlformats-officedocument.wordprocessingml.document"),
}

/** Un élément proposé : [key] unique, [make] prépare le fichier à joindre (copie dans le cache des mails). */
private class Item(val key: String, val title: String, val detail: String, val time: Long, val make: suspend (NoteFormat) -> Outgoing?)

private fun safeName(s: String) = s.replace(Regex("[\\\\/:*?\"<>|\\n\\r]"), "_").trim().take(80).ifBlank { "Fichier" }

private fun outDir(ctx: Context) = File(ctx.cacheDir, "mail/out").apply { mkdirs() }

/** Copie un fichier de Calepin sous un nom lisible (c'est ce nom que verra le destinataire). */
private fun copyOut(ctx: Context, src: File, name: String, mime: String): Outgoing? {
    if (!src.exists()) return null
    val f = File(outDir(ctx), System.currentTimeMillis().toString() + "_" + safeName(name))
    src.copyTo(f, overwrite = true)
    return Outgoing(f, safeName(name), mime)
}

private fun dateText(t: Long) = SimpleDateFormat(I18n.pattern("d MMM yyyy 'à' HH'h'mm"), I18n.locale).format(Date(t))

private fun loadItems(ctx: Context, source: Source): Pair<List<Item>, Int> {
    var hidden = 0
    val items: List<Item> = when (source) {
        Source.NOTES -> {
            if (SectionLock.needs(SectionLock.NOTES)) return emptyList<Item>() to -1
            val db = NoteDb(ctx)
            val notes = runCatching { db.all() }.getOrDefault(emptyList()).also { runCatching { db.close() } }
            notes.filter { n -> SectionLock.noteLocked(n.id).also { if (it) hidden++ }.not() }.sortedByDescending { it.updatedAt }.map { n ->
                val title = n.title.ifBlank { fr.jeremy.calepin.ui.InlineMedia.strip(n.content).lineSequence().firstOrNull { it.isNotBlank() }?.take(50) ?: I18n.tr("Sans titre") }
                Item("note:${n.id}", title, (if (n.folder.isNotEmpty()) n.folder.replace("/", " › ") + " · " else "") + dateText(n.updatedAt), n.updatedAt) { fmt ->
                    val bytes = when (fmt) {
                        NoteFormat.PDF -> fr.jeremy.calepin.export.PdfExport.build(listOf(n))
                        NoteFormat.TXT -> fr.jeremy.calepin.export.Exporters.text(listOf(n)).toByteArray()
                        NoteFormat.DOCX -> fr.jeremy.calepin.export.Exporters.docx(listOf(n))
                    }
                    val name = safeName(title) + "." + fmt.ext
                    val f = File(outDir(ctx), System.currentTimeMillis().toString() + "_" + name)
                    f.writeBytes(bytes)
                    Outgoing(f, name, fmt.mime)
                }
            }
        }
        Source.PDF -> {
            val lib = fr.jeremy.calepin.office.PdfLibrary.get(ctx)
            lib.items.value.sortedByDescending { maxOf(it.added, it.opened) }.map { e ->
                Item("pdf:${e.id}", e.name, (if (e.folder.isNotEmpty()) e.folder + " · " else "") + I18n.trf("{0} page(s)", e.pages), maxOf(e.added, e.opened)) { _ ->
                    val f = lib.exportCopy(e.id)
                    Outgoing(f, f.name, "application/pdf")
                }
            }
        }
        Source.PHOTOS, Source.MEMOS -> {
            if (SectionLock.needs(SectionLock.NOTES)) return emptyList<Item>() to -1
            val db = NoteDb(ctx)
            val notes = runCatching { db.all() }.getOrDefault(emptyList()).associateBy { it.id }
            fun titleOf(id: Long) = notes[id]?.title?.ifBlank { null } ?: I18n.tr("Sans titre")
            fun visible(id: Long) = !SectionLock.noteLocked(id).also { if (it) hidden++ } && notes.containsKey(id)
            val list = if (source == Source.PHOTOS) runCatching { db.attachments() }.getOrDefault(emptyList()).filter { visible(it.noteId) }.map { a ->
                val ext = a.fileName.substringAfterLast('.', if (a.isVideo) "mp4" else "jpg")
                val name = safeName(titleOf(a.noteId)) + " " + SimpleDateFormat("yyyy-MM-dd HH'h'mm", Locale.FRANCE).format(Date(a.createdAt)) + "." + ext
                Item("att:${a.id}", (if (a.isVideo) "🎥 " else "📷 ") + titleOf(a.noteId), dateText(a.createdAt), a.createdAt) { _ ->
                    copyOut(ctx, File(fr.jeremy.calepin.media.Media.dir(ctx), a.fileName), name, a.mime)
                }
            } else runCatching { db.recordings() }.getOrDefault(emptyList()).filter { visible(it.noteId) }.map { r ->
                val dur = "%d:%02d".format(r.durationMs / 60000, (r.durationMs / 1000) % 60)
                val name = safeName(I18n.tr("Mémo vocal") + " " + titleOf(r.noteId)) + " " + SimpleDateFormat("yyyy-MM-dd HH'h'mm", Locale.FRANCE).format(Date(r.createdAt)) + "." + r.extension
                Item("rec:${r.id}", "🎤 " + titleOf(r.noteId), dateText(r.createdAt) + " · " + dur + (if (r.transcript.isNotBlank()) " · " + r.transcript.take(60) else ""), r.createdAt) { _ ->
                    copyOut(ctx, File(fr.jeremy.calepin.audio.VoiceRecorder.dir(ctx), r.fileName), name, r.mime)
                }
            }
            runCatching { db.close() }
            list.sortedByDescending { it.time }
        }
        Source.MESSAGES -> {
            if (SectionLock.needs(SectionLock.MESSAGES)) return emptyList<Item>() to -1
            fr.jeremy.calepin.control.MessageHub.init(ctx)
            val convs = fr.jeremy.calepin.control.MessageHub.convs.value.associateBy { it.key }
            fr.jeremy.calepin.control.MessageHub.messages.value.flatMap { (key, msgs) ->
                msgs.filter { it.media.isNotEmpty() && File(it.media).exists() }.map { m ->
                    val f = File(m.media)
                    val who = convs[key]?.name ?: key.substringAfter('|')
                    Item("msg:${m.media}", f.name, who + " · " + dateText(m.time), m.time) { _ ->
                        copyOut(ctx, f, f.name, m.mime.ifBlank { "application/octet-stream" })
                    }
                }
            }.distinctBy { it.key }.sortedByDescending { it.time }
        }
    }
    return items to hidden
}

/**
 * Choix de pièces jointes dans Calepin : notes (en PDF, texte ou Word), PDF du Bureau, photos et vidéos
 * des notes, mémos vocaux, fichiers reçus dans Messages. Les rubriques protégées par code restent cachées.
 */
@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun MailAttachPicker(onDismiss: () -> Unit, onPicked: (List<Outgoing>) -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var source by remember { mutableStateOf(Source.NOTES) }
    var format by remember { mutableStateOf(NoteFormat.PDF) }
    var query by remember { mutableStateOf("") }
    val chosen = remember { mutableStateOf<Map<String, Item>>(emptyMap()) }
    var busy by remember { mutableStateOf(false) }
    val loaded by produceState<Pair<List<Item>, Int>?>(null, source) {
        value = null
        value = withContext(Dispatchers.IO) { runCatching { loadItems(ctx, source) }.getOrDefault(emptyList<Item>() to 0) }
    }
    androidx.compose.ui.window.Dialog(
        onDismissRequest = { if (!busy) onDismiss() },
        properties = androidx.compose.ui.window.DialogProperties(usePlatformDefaultWidth = false),
    ) {
        Scaffold(
            containerColor = MaterialTheme.colorScheme.surface,
            topBar = {
                TopAppBar(
                    title = { fr.jeremy.calepin.ui.FitText("Joindre depuis Calepin") },
                    navigationIcon = { IconButton(onClick = { if (!busy) onDismiss() }) { Icon(Icons.Filled.Close, "Fermer") } },
                )
            },
            bottomBar = {
                Surface(tonalElevation = 3.dp) {
                    Column(Modifier.navigationBarsPadding().padding(16.dp)) {
                        if (busy) LinearProgressIndicator(Modifier.fillMaxWidth().padding(bottom = 8.dp))
                        Button(
                            enabled = chosen.value.isNotEmpty() && !busy,
                            modifier = Modifier.fillMaxWidth(),
                            onClick = {
                                busy = true
                                val picked = chosen.value.values.toList()
                                scope.launch {
                                    val out = withContext(Dispatchers.IO) { picked.mapNotNull { runCatching { it.make(format) }.getOrNull() } }
                                    busy = false
                                    if (out.size < picked.size) I18n.toast(ctx, I18n.tr("Certains fichiers n'ont pas pu être joints."), android.widget.Toast.LENGTH_LONG).show()
                                    onPicked(out)
                                }
                            },
                        ) { RawText(I18n.trf("Joindre ({0})", chosen.value.size)) }
                    }
                }
            },
        ) { pad ->
            Column(Modifier.fillMaxSize().padding(pad).padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Source.entries.forEach { s ->
                        FilterChip(selected = source == s, onClick = { source = s; query = "" }, label = { Text(s.label) }, leadingIcon = { Icon(s.icon, null) })
                    }
                }
                if (source == Source.NOTES) Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("Envoyer les notes en :", style = MaterialTheme.typography.labelLarge)
                    NoteFormat.entries.forEach { f -> FilterChip(selected = format == f, onClick = { format = f }, label = { Text(f.label) }) }
                }
                OutlinedTextField(
                    query, { query = it }, singleLine = true, modifier = Modifier.fillMaxWidth(),
                    placeholder = { Text("Rechercher") }, leadingIcon = { Icon(Icons.Filled.Search, null) },
                    trailingIcon = { if (query.isNotEmpty()) IconButton(onClick = { query = "" }) { Icon(Icons.Filled.Close, "Effacer") } },
                )
                val data = loaded
                when {
                    data == null -> LinearProgressIndicator(Modifier.fillMaxWidth())
                    data.second == -1 -> Text(
                        "Cette rubrique est protégée par ton code. Ouvre-la une fois (et tape le code) pour pouvoir en joindre des fichiers.",
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    else -> {
                        val words = TextNorm.norm(query).lowercase().split(Regex("\\s+")).filter { it.isNotEmpty() }
                        val shown = data.first.filter { x -> val t = TextNorm.norm(x.title + " " + x.detail).lowercase(); words.all { w -> w in t } }
                        if (data.second > 0) RawText(
                            I18n.trf("{0} élément(s) de notes protégées masqué(s).", data.second),
                            style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                        if (shown.isEmpty()) Text("Rien à joindre ici.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                        LazyColumn(contentPadding = PaddingValues(bottom = 16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            items(shown, key = { x -> x.key }) { item ->
                                val on = item.key in chosen.value
                                Surface(
                                    onClick = { chosen.value = if (on) chosen.value - item.key else chosen.value + (item.key to item) },
                                    shape = MaterialTheme.shapes.medium,
                                    color = if (on) MaterialTheme.colorScheme.secondaryContainer else MaterialTheme.colorScheme.surfaceContainerLow,
                                    modifier = Modifier.fillMaxWidth(),
                                ) {
                                    Row(Modifier.padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                                        Checkbox(checked = on, onCheckedChange = { c -> chosen.value = if (c) chosen.value + (item.key to item) else chosen.value - item.key })
                                        Spacer(Modifier.width(4.dp))
                                        Column(Modifier.weight(1f)) {
                                            RawText(item.title, style = MaterialTheme.typography.titleSmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                            RawText(item.detail, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 2, overflow = TextOverflow.Ellipsis)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
