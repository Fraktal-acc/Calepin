package fr.jeremy.calepin.market

/**
 * Sources en plus pour l'analyse : peur des marchés (VIX), indice de référence (force relative),
 * humeur des cryptos (alternative.me), indice du dollar. Chaque donnée est gardée 15 minutes.
 */
object MarketContext {
    private val cache = HashMap<String, Pair<Any, Long>>()

    @Suppress("UNCHECKED_CAST")
    private fun <T : Any> cached(key: String, load: () -> T?): T? {
        synchronized(cache) { cache[key]?.let { (v, at) -> if (System.currentTimeMillis() - at < 900_000L) return v as T } }
        val v = runCatching { load() }.getOrNull() ?: return null
        synchronized(cache) { cache[key] = v to System.currentTimeMillis() }
        return v
    }

    private fun closes(symbol: String, range: String = "6mo"): List<Double>? =
        cached("c|$symbol|$range") { MarketData.series(symbol, "1d", range).candles.map { it.c }.takeIf { it.size > 5 } }

    private fun fearGreed(): Int? = cached("fng") {
        val o = MarketData.fetchJson("https://api.alternative.me/fng/?limit=1")
        o.optJSONArray("data")?.optJSONObject(0)?.optString("value")?.toIntOrNull()
    }

    /** Éléments de contexte pour un instrument (ceux qui s'appliquent à son genre). */
    fun factors(symbol: String, type: String, candles: List<Candle>): List<Factor> {
        val kind = ContextScore.kindOf(symbol, type)
        val out = ArrayList<Factor>()
        if (kind == AssetKind.STOCK || kind == AssetKind.INDEX) {
            closes("^VIX", "1mo")?.let { v -> ContextScore.vixFactor(v.last(), v.getOrElse(v.size - 6) { Double.NaN })?.let { out += it } }
        }
        ContextScore.benchmarkFor(symbol, kind)?.let { b ->
            closes(b)?.let { bench ->
                ContextScore.relativeStrength(candles.map { it.c }, bench, benchName(b))?.let { out += it }
            }
        }
        if (kind == AssetKind.CRYPTO) fearGreed()?.let { ContextScore.fearGreedFactor(it)?.let { f -> out += f } }
        if (kind == AssetKind.COMMODITY) closes("DX-Y.NYB", "3mo")?.let { ContextScore.dollarFactor(it)?.let { f -> out += f } }
        return out
    }

    private fun benchName(b: String) = when (b) {
        "^GSPC" -> "le S&P 500"
        "^FCHI" -> "le CAC 40"
        "^GDAXI" -> "le DAX"
        "^FTSE" -> "le FTSE 100"
        "FTSEMIB.MI" -> "le FTSE MIB"
        "^AEX" -> "l'AEX"
        "^IBEX" -> "l'IBEX 35"
        "^SSMI" -> "le SMI"
        "^BFX" -> "le BEL 20"
        "^N225" -> "le Nikkei"
        "^HSI" -> "le Hang Seng"
        "^GSPTSE" -> "le TSX"
        else -> b
    }
}
