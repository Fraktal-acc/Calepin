package fr.jeremy.calepin.ui

import android.Manifest
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.MyLocation
import androidx.compose.material.icons.filled.Place
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import fr.jeremy.calepin.i18n.I18n
import fr.jeremy.calepin.i18n.RawText
import fr.jeremy.calepin.i18n.Text
import fr.jeremy.calepin.weather.Forecast
import fr.jeremy.calepin.weather.WeatherCodes
import fr.jeremy.calepin.weather.WeatherPlace
import fr.jeremy.calepin.weather.WeatherRepo
import kotlinx.coroutines.launch
import java.time.format.DateTimeFormatter
import java.time.format.TextStyle
import kotlin.math.roundToInt

private fun deg(v: Double) = "${v.roundToInt()}°"

/** Carte météo de l'accueil : temps actuel, minimum / maximum et les prochaines heures. */
@Composable
fun WeatherCard(onOpen: () -> Unit) {
    val ctx = LocalContext.current
    val f by WeatherRepo.forecast.collectAsStateWithLifecycle()
    val loading by WeatherRepo.loading.collectAsStateWithLifecycle()
    LaunchedEffect(Unit) { WeatherRepo.refresh(ctx) }
    val cs = MaterialTheme.colorScheme
    val translucent = LocalLook.current.deco != Deco.NONE
    Card(
        onClick = onOpen,
        colors = CardDefaults.cardColors(containerColor = cs.tertiaryContainer.copy(alpha = if (translucent) 0.88f else 1f), contentColor = cs.onTertiaryContainer),
        border = appBorder(),
        modifier = Modifier.fillMaxWidth(),
    ) {
        val fc = f
        if (fc == null) {
            Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                androidx.compose.material3.Text("🌤️", fontSize = 34.sp)
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    FitText("Météo", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                    Text(
                        if (loading) "Chargement…" else "Touche ici pour choisir ta ville, ton code postal ou utiliser ta position",
                        style = MaterialTheme.typography.bodySmall,
                    )
                }
            }
            return@Card
        }
        Column(Modifier.padding(horizontal = 16.dp, vertical = 12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                androidx.compose.material3.Text(WeatherCodes.emoji(fc.code, fc.isDay), fontSize = 40.sp)
                Spacer(Modifier.width(10.dp))
                RawText(deg(fc.temp), style = MaterialTheme.typography.displaySmall, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    FitText(WeatherCodes.label(fc.code), style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold, maxLines = 2)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Filled.Place, null, Modifier.size(14.dp))
                        RawText(" " + fc.place.name, style = MaterialTheme.typography.bodySmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                    fc.days.firstOrNull()?.let { d ->
                        RawText(
                            "↓ ${deg(d.min)}  ↑ ${deg(d.max)}  💧 ${d.rain} %",
                            style = MaterialTheme.typography.bodySmall,
                        )
                    }
                }
                if (loading) CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp)
            }
            // Les prochaines heures
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                fc.hours.drop(1).take(5).forEach { h ->
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        RawText(h.time.format(DateTimeFormatter.ofPattern(if (I18n.language.value.code == "fr") "H'h'" else "H:00")), style = MaterialTheme.typography.labelSmall)
                        androidx.compose.material3.Text(WeatherCodes.emoji(h.code, h.isDay), fontSize = 18.sp)
                        RawText(deg(h.temp), style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.SemiBold)
                    }
                }
            }
        }
    }
}

/** Écran météo : lieu (position, ville ou code postal), prévisions heure par heure et sur 7 jours. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WeatherScreen(onClose: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val f by WeatherRepo.forecast.collectAsStateWithLifecycle()
    val loading by WeatherRepo.loading.collectAsStateWithLifecycle()
    val error by WeatherRepo.error.collectAsStateWithLifecycle()
    var query by remember { mutableStateOf("") }
    var results by remember { mutableStateOf<List<WeatherPlace>?>(null) }
    var searching by remember { mutableStateOf(false) }
    var recent by remember { mutableStateOf(WeatherRepo.recent(ctx)) }
    var auto by remember { mutableStateOf(WeatherRepo.isAuto(ctx)) }
    var locError by remember { mutableStateOf<String?>(null) }
    BackHandler { onClose() }
    LaunchedEffect(Unit) { WeatherRepo.refresh(ctx) }

    fun locateNow() {
        scope.launch {
            locError = null
            if (WeatherRepo.useLocation(ctx)) { auto = true; recent = WeatherRepo.recent(ctx) }
            else locError = "Position introuvable. Active la localisation du téléphone ou cherche ta ville."
        }
    }
    val permission = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { granted ->
        if (granted.values.any { it }) locateNow() else locError = "Sans l'autorisation de localisation, cherche ta ville ou ton code postal."
    }
    fun search() {
        val q = query.trim()
        if (q.length < 2) return
        scope.launch {
            searching = true
            results = runCatching { WeatherRepo.search(ctx, q) }.getOrDefault(emptyList())
            searching = false
        }
    }
    fun pick(p: WeatherPlace) {
        scope.launch {
            WeatherRepo.choose(ctx, p)
            auto = false
            results = null
            query = ""
            recent = WeatherRepo.recent(ctx)
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { FitText("Météo") },
                navigationIcon = { IconButton(onClick = onClose) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Retour") } },
                actions = {
                    IconButton(onClick = { scope.launch { WeatherRepo.refresh(ctx, force = true) } }) { Icon(Icons.Filled.Refresh, "Actualiser") }
                },
            )
        },
    ) { pad ->
        Column(
            Modifier
                .fillMaxSize()
                .padding(pad)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp)
                .padding(bottom = 40.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            // Choix du lieu
            OutlinedTextField(
                value = query,
                onValueChange = { query = it; if (it.isBlank()) results = null },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                placeholder = { Text("Ville ou code postal") },
                leadingIcon = { Icon(Icons.Filled.Search, null) },
                trailingIcon = {
                    if (query.isNotEmpty()) IconButton(onClick = { query = ""; results = null }) { Icon(Icons.Filled.Close, "Effacer") }
                },
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                keyboardActions = KeyboardActions(onSearch = { search() }),
                shape = MaterialTheme.shapes.large,
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilledTonalButton(onClick = { search() }, enabled = query.trim().length >= 2) {
                    Icon(Icons.Filled.Search, null, Modifier.size(18.dp)); Text(" Chercher")
                }
                FilledTonalButton(onClick = {
                    if (WeatherRepo.hasLocationPermission(ctx)) locateNow()
                    else {
                        fr.jeremy.calepin.LockGuard.external()
                        permission.launch(arrayOf(Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.ACCESS_FINE_LOCATION))
                    }
                }) {
                    Icon(Icons.Filled.MyLocation, null, Modifier.size(18.dp)); Text(" Ma position")
                }
            }
            if (searching) CircularProgressIndicator(Modifier.size(24.dp))
            results?.let { list ->
                if (list.isEmpty()) Hint2("Aucun lieu trouvé. Essaie le nom de la ville ou le code postal.")
                list.forEach { p -> PlaceRow(p, Icons.Filled.Place) { pick(p) } }
            }
            (locError ?: error)?.let { Text(it, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error) }

            val fc = f
            if (fc == null) {
                if (loading) Box(Modifier.fillMaxWidth().padding(24.dp), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
                else Hint2("Choisis un lieu : ta position (le lieu suit alors tes déplacements), une ville ou un code postal.")
            } else {
                CurrentWeather(fc, auto, loading)
                SubTitle("Heure par heure")
                Row(
                    Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    fc.hours.forEach { h ->
                        Surface(shape = MaterialTheme.shapes.medium, color = MaterialTheme.colorScheme.surfaceContainerLow, border = appBorder()) {
                            Column(Modifier.padding(horizontal = 10.dp, vertical = 8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                RawText(h.time.format(DateTimeFormatter.ofPattern(if (I18n.language.value.code == "fr") "H'h'" else "H:00")), style = MaterialTheme.typography.labelMedium)
                                androidx.compose.material3.Text(WeatherCodes.emoji(h.code, h.isDay), fontSize = 22.sp)
                                RawText(deg(h.temp), style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                                RawText("💧${h.rain}%", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }
                }
                SubTitle("7 prochains jours")
                val lo = fc.days.minOfOrNull { it.min } ?: 0.0
                val hi = fc.days.maxOfOrNull { it.max } ?: 1.0
                Surface(shape = MaterialTheme.shapes.large, color = MaterialTheme.colorScheme.surfaceContainerLow, border = appBorder(), modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(vertical = 6.dp)) {
                        fc.days.forEachIndexed { i, d -> DayRow(d, i, lo, hi) }
                    }
                }
            }

            if (recent.isNotEmpty()) {
                SubTitle("Lieux récents")
                recent.forEach { p -> PlaceRow(p, Icons.Filled.History) { pick(p) } }
            }
            Hint2("Prévisions Open-Meteo (Météo-France et services météo nationaux), mises à jour toutes les 30 minutes.")
        }
    }
}

@Composable
private fun CurrentWeather(f: Forecast, auto: Boolean, loading: Boolean) {
    val cs = MaterialTheme.colorScheme
    Surface(shape = MaterialTheme.shapes.large, color = cs.tertiaryContainer, border = appBorder(BorderStroke(1.dp, cs.tertiary.copy(alpha = 0.4f))), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(if (auto) Icons.Filled.MyLocation else Icons.Filled.Place, null, Modifier.size(16.dp), tint = cs.onTertiaryContainer)
                RawText(" " + f.place.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold, color = cs.onTertiaryContainer, modifier = Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                if (loading) CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp)
            }
            if (f.place.detail.isNotBlank()) RawText(f.place.detail, style = MaterialTheme.typography.bodySmall, color = cs.onTertiaryContainer.copy(alpha = 0.8f))
            Row(verticalAlignment = Alignment.CenterVertically) {
                androidx.compose.material3.Text(WeatherCodes.emoji(f.code, f.isDay), fontSize = 56.sp)
                Spacer(Modifier.width(12.dp))
                Column {
                    RawText(deg(f.temp), style = MaterialTheme.typography.displayMedium, fontWeight = FontWeight.SemiBold, color = cs.onTertiaryContainer)
                    Text(WeatherCodes.label(f.code), style = MaterialTheme.typography.titleSmall, color = cs.onTertiaryContainer)
                }
            }
            val today = f.days.firstOrNull()
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Detail("Ressenti", deg(f.feels))
                Detail("Humidité", "${f.humidity} %")
                Detail("Vent", "${f.wind.roundToInt()} km/h")
                today?.let { Detail("UV", "%.0f".format(it.uv)) }
            }
            today?.let {
                RawText("🌅 ${it.sunrise}   🌇 ${it.sunset}", style = MaterialTheme.typography.bodySmall, color = cs.onTertiaryContainer)
            }
            val ago = ((System.currentTimeMillis() - f.fetchedAt) / 60_000L).toInt()
            Text(
                if (ago < 1) "Mis à jour à l'instant" else I18n.trf("Mis à jour il y a {0} min", ago),
                style = MaterialTheme.typography.labelSmall, color = cs.onTertiaryContainer.copy(alpha = 0.7f),
            )
        }
    }
}

@Composable
private fun Detail(label: String, value: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onTertiaryContainer.copy(alpha = 0.75f))
        RawText(value, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.onTertiaryContainer)
    }
}

@Composable
private fun DayRow(d: fr.jeremy.calepin.weather.DayWeather, index: Int, lo: Double, hi: Double) {
    val cs = MaterialTheme.colorScheme
    val name = when (index) {
        0 -> I18n.tr("Aujourd'hui")
        1 -> I18n.tr("Demain")
        else -> d.date.dayOfWeek.getDisplayName(TextStyle.SHORT, I18n.locale).replaceFirstChar { it.uppercase() } + " " + d.date.dayOfMonth
    }
    Row(Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        RawText(name, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Medium, modifier = Modifier.width(96.dp.grow()), maxLines = 1)
        androidx.compose.material3.Text(WeatherCodes.emoji(d.code), fontSize = 20.sp)
        RawText(" ${d.rain}%", style = MaterialTheme.typography.labelSmall, color = cs.primary, modifier = Modifier.width(44.dp.grow()))
        RawText(deg(d.min), style = MaterialTheme.typography.bodyMedium, color = cs.onSurfaceVariant, modifier = Modifier.width(36.dp.grow()))
        // Barre min → max sur l'échelle de la semaine
        val span = (hi - lo).coerceAtLeast(1.0)
        val start = ((d.min - lo) / span).toFloat().coerceIn(0f, 1f)
        val end = ((d.max - lo) / span).toFloat().coerceIn(start, 1f)
        Box(Modifier.weight(1f).height(6.dp).background(cs.surfaceContainerHighest, CircleShape)) {
            Row(Modifier.fillMaxSize()) {
                if (start > 0f) Spacer(Modifier.weight(start))
                Box(Modifier.weight((end - start).coerceAtLeast(0.02f)).fillMaxHeight().background(cs.tertiary, CircleShape))
                if (end < 1f) Spacer(Modifier.weight(1f - end))
            }
        }
        RawText(" " + deg(d.max), style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold, modifier = Modifier.width(40.dp.grow()))
    }
}

@Composable
private fun PlaceRow(p: WeatherPlace, icon: androidx.compose.ui.graphics.vector.ImageVector, onClick: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 8.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(icon, null, tint = MaterialTheme.colorScheme.primary)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            RawText(p.name, style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.Medium)
            if (p.detail.isNotBlank()) RawText(p.detail, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun Hint2(text: String) {
    Text(text, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
}
