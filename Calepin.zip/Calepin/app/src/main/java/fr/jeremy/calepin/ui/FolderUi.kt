package fr.jeremy.calepin.ui

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CreateNewFolder
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.FolderOff
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Notes
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import fr.jeremy.calepin.NotesViewModel

/** Dernier élément d'un chemin « A/B/C » → « C ». */
fun folderName(path: String) = path.substringAfterLast('/')

/** Chemin lisible : « Travail › Clients ». */
fun folderLabel(path: String) = if (path.isEmpty()) "Sans dossier" else path.replace("/", " › ")

/** Sous-dossiers directs de [parent] ("" = racine). */
fun childrenOf(all: List<String>, parent: String): List<String> =
    all.filter { p -> if (parent.isEmpty()) '/' !in p else p.startsWith("$parent/") && '/' !in p.substring(parent.length + 1) }

/**
 * Barre de dossiers sous la recherche : « Toutes », « Sans dossier », les dossiers du niveau affiché,
 * et « + Dossier ». Appui long sur un dossier : renommer, déplacer, supprimer.
 */
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun FolderBar(vm: NotesViewModel, current: String?, folders: List<String>) {
    var creating by remember { mutableStateOf(false) }
    var menuFor by remember { mutableStateOf<String?>(null) }
    var renaming by remember { mutableStateOf<String?>(null) }
    var moving by remember { mutableStateOf<String?>(null) }
    var deleting by remember { mutableStateOf<String?>(null) }
    val haptic = LocalHapticFeedback.current
    val parent = current.orEmpty()

    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        if (!current.isNullOrEmpty()) {
            // Fil d'Ariane du dossier ouvert
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(
                    onClick = { vm.openFolder(current.substringBeforeLast('/', "").ifEmpty { null }) },
                    modifier = Modifier.size(36.dp),
                ) { Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Dossier parent") }
                Icon(Icons.Filled.FolderOpen, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(20.dp))
                Spacer(Modifier.width(6.dp))
                Text(
                    folderLabel(current),
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f),
                )
                Box {
                    IconButton(onClick = { menuFor = current }, modifier = Modifier.size(36.dp)) {
                        Icon(Icons.Filled.MoreVert, contentDescription = "Actions du dossier")
                    }
                    FolderMenu(
                        expanded = menuFor == current,
                        onDismiss = { menuFor = null },
                        onRename = { menuFor = null; renaming = current },
                        onMove = { menuFor = null; moving = current },
                        onDelete = { menuFor = null; deleting = current },
                    )
                }
            }
        }
        Row(
            Modifier.horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            if (current == null || current.isEmpty()) {
                FolderChip("Toutes", Icons.Filled.Notes, selected = current == null) { vm.openFolder(null) }
                FolderChip("Sans dossier", Icons.Filled.FolderOff, selected = current == "") { vm.openFolder("") }
            }
            childrenOf(folders, parent).forEach { f ->
                Box {
                    FolderChip(
                        folderName(f), Icons.Filled.Folder, selected = false,
                        onLongClick = { haptic.performHapticFeedback(HapticFeedbackType.LongPress); menuFor = f },
                    ) { vm.openFolder(f) }
                    FolderMenu(
                        expanded = menuFor == f,
                        onDismiss = { menuFor = null },
                        onRename = { menuFor = null; renaming = f },
                        onMove = { menuFor = null; moving = f },
                        onDelete = { menuFor = null; deleting = f },
                    )
                }
            }
            FolderChip(if (current.isNullOrEmpty()) "Dossier" else "Sous-dossier", Icons.Filled.Add, selected = false) {
                creating = true
            }
        }
    }

    if (creating) {
        FolderNameDialog(
            title = if (parent.isEmpty()) "Nouveau dossier" else "Nouveau sous-dossier dans « ${folderName(parent)} »",
            initial = "",
            taken = childrenOf(folders, parent).map { folderName(it) },
            onDismiss = { creating = false },
        ) { name ->
            creating = false
            vm.createFolder(if (parent.isEmpty()) name else "$parent/$name")
        }
    }
    renaming?.let { f ->
        val p = f.substringBeforeLast('/', "")
        FolderNameDialog(
            title = "Renommer le dossier",
            initial = folderName(f),
            taken = childrenOf(folders, p).map { folderName(it) }.filter { it != folderName(f) },
            onDismiss = { renaming = null },
        ) { name ->
            renaming = null
            vm.renameFolder(f, if (p.isEmpty()) name else "$p/$name")
        }
    }
    moving?.let { f ->
        FolderPickerDialog(
            vm = vm,
            title = "Déplacer « ${folderName(f)} » dans…",
            folders = folders.filter { it != f && !it.startsWith("$f/") },
            current = f.substringBeforeLast('/', ""),
            noneLabel = "Racine (aucun dossier parent)",
            onDismiss = { moving = null },
        ) { target ->
            moving = null
            val dest = if (target.isEmpty()) folderName(f) else "$target/${folderName(f)}"
            if (dest != f) {
                if (dest in folders) vm.renameFolder(f, "$dest (2)") else vm.renameFolder(f, dest)
            }
        }
    }
    deleting?.let { f ->
        val p = f.substringBeforeLast('/', "")
        AlertDialog(
            onDismissRequest = { deleting = null },
            title = { Text("Supprimer le dossier « ${folderName(f)} » ?") },
            text = {
                Text(
                    "Aucune note n'est effacée : ses notes et sous-dossiers sont déplacés dans " +
                        (if (p.isEmpty()) "« Sans dossier »." else "« ${folderLabel(p)} »."),
                )
            },
            confirmButton = {
                TextButton(onClick = { deleting = null; vm.deleteFolder(f) }) {
                    Text("Supprimer le dossier", color = MaterialTheme.colorScheme.error)
                }
            },
            dismissButton = { TextButton(onClick = { deleting = null }) { Text("Annuler") } },
        )
    }
}

@Composable
private fun FolderMenu(expanded: Boolean, onDismiss: () -> Unit, onRename: () -> Unit, onMove: () -> Unit, onDelete: () -> Unit) {
    DropdownMenu(expanded = expanded, onDismissRequest = onDismiss) {
        DropdownMenuItem(text = { Text("Renommer") }, leadingIcon = { Icon(Icons.Filled.Edit, null) }, onClick = onRename)
        DropdownMenuItem(text = { Text("Déplacer dans…") }, leadingIcon = { Icon(Icons.Filled.Folder, null) }, onClick = onMove)
        DropdownMenuItem(
            text = { Text("Supprimer le dossier") },
            leadingIcon = { Icon(Icons.Filled.Delete, null, tint = MaterialTheme.colorScheme.error) },
            onClick = onDelete,
        )
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun FolderChip(
    label: String,
    icon: ImageVector,
    selected: Boolean,
    onLongClick: (() -> Unit)? = null,
    onClick: () -> Unit,
) {
    val shape = RoundedCornerShape(10.dp)
    Surface(
        shape = shape,
        color = if (selected) MaterialTheme.colorScheme.secondaryContainer else MaterialTheme.colorScheme.surfaceContainerHigh,
        modifier = Modifier
            .clip(shape)
            .combinedClickable(onClick = onClick, onLongClick = onLongClick),
    ) {
        Row(Modifier.padding(horizontal = 12.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(
                icon, contentDescription = null, modifier = Modifier.size(18.dp),
                tint = if (selected) MaterialTheme.colorScheme.onSecondaryContainer else MaterialTheme.colorScheme.primary,
            )
            Spacer(Modifier.width(6.dp))
            Text(label, style = MaterialTheme.typography.labelLarge, maxLines = 1)
        }
    }
}

/** Saisie d'un nom de dossier, avec contrôle des doublons. */
@Composable
fun FolderNameDialog(
    title: String,
    initial: String,
    taken: List<String>,
    onDismiss: () -> Unit,
    onConfirm: (String) -> Unit,
) {
    var name by remember { mutableStateOf(initial) }
    val clean = name.replace('/', '-').trim()
    val error = when {
        clean.isEmpty() -> null
        taken.any { it.equals(clean, ignoreCase = true) } -> "Un dossier porte déjà ce nom ici"
        else -> null
    }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            OutlinedTextField(
                value = name,
                onValueChange = { if (it.length <= 40) name = it },
                label = { Text("Nom du dossier") },
                singleLine = true,
                isError = error != null,
                supportingText = if (error != null) { { Text(error) } } else null,
            )
        },
        confirmButton = {
            TextButton(onClick = { onConfirm(clean) }, enabled = clean.isNotEmpty() && error == null) { Text("Valider") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Annuler") } },
    )
}

/**
 * Choix d'un dossier (déplacer des notes, dossier d'une note). [onPick] reçoit "" pour « aucun dossier ».
 * On peut aussi créer un dossier depuis cette fenêtre.
 */
@Composable
fun FolderPickerDialog(
    vm: NotesViewModel,
    title: String,
    folders: List<String>,
    current: String?,
    noneLabel: String = "Sans dossier",
    onDismiss: () -> Unit,
    onPick: (String) -> Unit,
) {
    var newIn by remember { mutableStateOf<String?>(null) }
    var extra by remember { mutableStateOf(listOf<String>()) }
    val all = (folders + extra).distinct().sortedWith(compareBy(String.CASE_INSENSITIVE_ORDER) { it })

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            Column(
                Modifier
                    .heightIn(max = 420.dp)
                    .verticalScroll(rememberScrollState()),
            ) {
                PickRow(noneLabel, Icons.Filled.FolderOff, 0, current == "") { onPick("") }
                HorizontalDivider(Modifier.padding(vertical = 4.dp))
                // Arborescence : chaque dossier suivi de ses sous-dossiers
                fun tree(parent: String, depth: Int): List<Pair<String, Int>> =
                    childrenOf(all, parent).flatMap { listOf(it to depth) + tree(it, depth + 1) }
                tree("", 0).forEach { (f, depth) ->
                    PickRow(folderName(f), Icons.Filled.Folder, depth, current == f) { onPick(f) }
                }
                if (all.isEmpty()) {
                    Text(
                        "Aucun dossier pour l'instant.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(8.dp),
                    )
                }
                TextButton(onClick = { newIn = "" }) {
                    Icon(Icons.Filled.CreateNewFolder, null)
                    Spacer(Modifier.width(8.dp))
                    Text("Nouveau dossier")
                }
            }
        },
        confirmButton = {},
        dismissButton = { TextButton(onClick = onDismiss) { Text("Annuler") } },
    )

    newIn?.let { parent ->
        FolderNameDialog(
            title = "Nouveau dossier",
            initial = "",
            taken = childrenOf(all, parent).map { folderName(it) },
            onDismiss = { newIn = null },
        ) { name ->
            newIn = null
            val path = if (parent.isEmpty()) name else "$parent/$name"
            vm.createFolder(path)
            extra = extra + path
        }
    }
}

@Composable
private fun PickRow(label: String, icon: ImageVector, depth: Int, selected: Boolean, onClick: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .clickable(onClick = onClick)
            .padding(start = (8 + depth * 20).dp, top = 10.dp, bottom = 10.dp, end = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(icon, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(20.dp))
        Spacer(Modifier.width(10.dp))
        Text(
            label,
            style = MaterialTheme.typography.bodyLarge,
            fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
            color = if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
        )
    }
}
