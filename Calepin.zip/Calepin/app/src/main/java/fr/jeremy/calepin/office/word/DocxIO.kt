package fr.jeremy.calepin.office.word

import org.w3c.dom.Element
import org.w3c.dom.Node
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream
import javax.xml.parsers.DocumentBuilderFactory

private const val W = "http://schemas.openxmlformats.org/wordprocessingml/2006/main"
private const val R = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"
private const val A = "http://schemas.openxmlformats.org/drawingml/2006/main"
private const val PKG_R = "http://schemas.openxmlformats.org/package/2006/relationships"

/** Document Word lu : le document, ses images (nom → octets) et ce qui a été simplifié. */
class DocxRead(val doc: WordDoc, val images: Map<String, ByteArray>, val warnings: List<String>, val title: String?)

/**
 * Lecture d'un fichier Word (.docx) : paragraphes et leurs styles (titres, citations), listes à puces et
 * numérotées, gras, italique, souligné, barré, couleurs, surlignage, liens, alignement, tableaux, images,
 * sauts de page, en-tête, pied de page et mise en page. Les modifications suivies sont acceptées.
 */
object DocxReader {
    /** Couleurs de surlignage de Word. */
    private val HIGHLIGHT = mapOf(
        "yellow" to "#FFFF00", "green" to "#00FF00", "cyan" to "#00FFFF", "magenta" to "#FF00FF", "blue" to "#0000FF",
        "red" to "#FF0000", "darkBlue" to "#000080", "darkCyan" to "#008080", "darkGreen" to "#008000", "darkMagenta" to "#800080",
        "darkRed" to "#800000", "darkYellow" to "#808000", "darkGray" to "#808080", "lightGray" to "#C0C0C0", "black" to "#000000",
    )

    private fun xml(bytes: ByteArray): org.w3c.dom.Document {
        val f = DocumentBuilderFactory.newInstance()
        f.isNamespaceAware = true
        // Pas de fichiers extérieurs (sécurité)
        runCatching { f.setFeature("http://apache.org/xml/features/disallow-doctype-decl", true) }
        runCatching { f.setFeature("http://xml.org/sax/features/external-general-entities", false) }
        runCatching { f.setFeature("http://xml.org/sax/features/external-parameter-entities", false) }
        runCatching { f.isExpandEntityReferences = false }
        return f.newDocumentBuilder().parse(ByteArrayInputStream(bytes))
    }

    private fun Element.kids(): List<Element> {
        val out = ArrayList<Element>()
        var n = firstChild
        while (n != null) { if (n.nodeType == Node.ELEMENT_NODE) out += n as Element; n = n.nextSibling }
        return out
    }
    private fun Element.w(local: String) = kids().firstOrNull { it.namespaceURI == W && it.localName == local }
    private fun Element.wv(local: String): String? = w(local)?.let { e -> e.getAttributeNS(W, "val").takeIf { it.isNotEmpty() } ?: "" }
    private fun Element.attrW(name: String) = getAttributeNS(W, name).takeIf { it.isNotEmpty() }
    private fun Element.isW(local: String) = namespaceURI == W && localName == local
    /** Propriété booléenne de Word : présente sans valeur = vrai ; « 0 », « false », « none » = faux. */
    private fun Element.flag(local: String): Boolean? = w(local)?.let { e -> e.getAttributeNS(W, "val").let { it.isEmpty() || (it != "0" && it != "false" && it != "none") } }

    fun read(bytes: ByteArray): DocxRead {
        val parts = HashMap<String, ByteArray>()
        ZipInputStream(ByteArrayInputStream(bytes)).use { z ->
            var e: ZipEntry? = z.nextEntry
            var total = 0L
            while (e != null) {
                if (!e.isDirectory) {
                    val b = z.readBytes()
                    total += b.size
                    if (total > 300L * 1024 * 1024) error("Document trop gros")
                    parts[e.name.removePrefix("/")] = b
                }
                e = z.nextEntry
            }
        }
        val docName = rels(parts, "_rels/.rels").values.firstOrNull { it.type.endsWith("/officeDocument") }?.target?.removePrefix("/") ?: "word/document.xml"
        val docXml = parts[docName] ?: error("Ce fichier n'est pas un document Word (.docx).")
        val base = docName.substringBeforeLast('/', "")
        val docRels = rels(parts, (if (base.isEmpty()) "" else "$base/") + "_rels/" + docName.substringAfterLast('/') + ".rels")
        val ctx = Ctx(parts, base, docRels)
        ctx.readStyles(parts["$base/styles.xml"])
        ctx.readNumbering(docRels.values.firstOrNull { it.type.endsWith("/numbering") }?.let { parts[ctx.path(it.target)] })

        val root = xml(docXml).documentElement
        val body = root.w("body") ?: error("Document vide")

        // Mise en page d'abord (la largeur des images en dépend), avec en-tête et pied de page
        val sect = body.w("sectPr")
        var page = ctx.page
        if (sect != null) {
            sect.w("pgSz")?.let { sz ->
                val w0 = sz.attrW("w")?.toIntOrNull() ?: 11906
                val h0 = sz.attrW("h")?.toIntOrNull() ?: 16838
                val land = sz.attrW("orient") == "landscape" || w0 > h0
                val pw = minOf(w0, h0)
                val paper = Paper.entries.minByOrNull { kotlin.math.abs(it.wTwips - pw) } ?: Paper.A4
                page = page.copy(paper = paper, landscape = land)
            }
            sect.w("pgMar")?.let { m ->
                val l = m.attrW("left")?.toIntOrNull() ?: m.attrW("start")?.toIntOrNull()
                if (l != null) page = page.copy(marginMm = Math.round(l / 56.6929f).coerceIn(5, 60))
            }
            if (sect.w("cols")?.attrW("num")?.toIntOrNull()?.let { it > 1 } == true) ctx.warn("Les colonnes sont affichées sur une seule colonne.")
            fun part(kind: String): String? = sect.kids().filter { it.isW(kind + "Reference") }
                .sortedBy { if (it.attrW("type") == "default") 0 else 1 }
                .firstNotNullOfOrNull { ref -> docRels[ref.getAttributeNS(R, "id")]?.let { parts[ctx.path(it.target)] } }?.let { String(it, Charsets.UTF_8) }
            part("header")?.let { x -> page = page.copy(header = plainOfPart(x)) }
            part("footer")?.let { x ->
                val numbers = x.contains("PAGE", ignoreCase = false) && (x.contains("w:fldSimple") || x.contains("instrText"))
                page = page.copy(footer = plainOfPart(x).let { f -> if (numbers) f.replace(Regex("(\\s*[·\\-–|]\\s*)?(page\\s*)?\\d+(\\s*/\\s*\\d+)?$", RegexOption.IGNORE_CASE), "") else f }.trim(), pageNumbers = numbers)
            }
        }
        ctx.page = page
        ctx.blockChildren(body)
        ctx.flushText()
        if (parts.keys.any { it.endsWith("comments.xml") }) ctx.warn("Les commentaires ne sont pas affichés (ils seront retirés à l'enregistrement).")
        if (ctx.footnotes) ctx.warn("Les notes de bas de page ne sont pas affichées.")

        val title = parts["docProps/core.xml"]?.let { c ->
            runCatching { xml(c).documentElement.getElementsByTagNameNS("http://purl.org/dc/elements/1.1/", "title").item(0)?.textContent?.trim() }.getOrNull()
        }?.takeIf { it.isNotBlank() }
        val doc = WordDoc(ctx.blocks.ifEmpty { listOf(DocBlock.Text()) }, ctx.page).normalized()
        return DocxRead(doc, ctx.images, ctx.warnings.distinct(), title)
    }

    /** Texte d'un en-tête ou d'un pied de page (sans les champs). */
    private fun plainOfPart(xmlText: String): String = runCatching {
        val root = xml(xmlText.toByteArray()).documentElement
        val paras = root.getElementsByTagNameNS(W, "p")
        (0 until paras.length).map { i ->
            val p = paras.item(i) as Element
            val ts = p.getElementsByTagNameNS(W, "t")
            (0 until ts.length).joinToString("") { ts.item(it).textContent }
        }.filter { it.isNotBlank() }.joinToString(" · ").trim()
    }.getOrDefault("")

    private class Rel(val type: String, val target: String, val external: Boolean)

    private fun rels(parts: Map<String, ByteArray>, name: String): Map<String, Rel> {
        val b = parts[name] ?: return emptyMap()
        return runCatching {
            val root = xml(b).documentElement
            val list = root.getElementsByTagNameNS(PKG_R, "Relationship")
            (0 until list.length).associate { i ->
                val e = list.item(i) as Element
                e.getAttribute("Id") to Rel(e.getAttribute("Type"), e.getAttribute("Target"), e.getAttribute("TargetMode") == "External")
            }
        }.getOrDefault(emptyMap())
    }

    private class Ctx(val parts: Map<String, ByteArray>, val base: String, val rels: Map<String, Rel>) {
        val blocks = ArrayList<DocBlock>()
        val lines = ArrayList<String>()
        val images = LinkedHashMap<String, ByteArray>()
        val warnings = ArrayList<String>()
        var page = PageSetup()
        var footnotes = false
        /** Identifiant du style → nom (« heading 1 », « Title »…) et style parent. */
        val styleNames = HashMap<String, String>()
        val styleBased = HashMap<String, String>()
        val styleNum = HashMap<String, Pair<String, Int>>()
        /** numId → (abstractNumId, départs remplacés) ; abstract → niveaux (format). */
        val numAbstract = HashMap<String, String>()
        val numStart = HashMap<String, MutableMap<Int, Int>>()
        val abstractFmt = HashMap<String, MutableMap<Int, Pair<String, Int>>>()
        val counters = HashMap<String, IntArray>()
        var lastNum: String? = null
        val lastNumOf = HashMap<String, String>()
        private var imgN = 0
        private var fontWarned = false
        var defaultSize = 22
        var defaultFont: String? = null

        fun warn(s: String) { warnings += s }
        fun path(target: String): String = if (target.startsWith("/")) target.removePrefix("/") else normalize((if (base.isEmpty()) "" else "$base/") + target)
        private fun normalize(p: String): String {
            val out = ArrayList<String>()
            p.split('/').forEach { s -> when (s) { ".." -> if (out.isNotEmpty()) out.removeAt(out.lastIndex); ".", "" -> {}; else -> out += s } }
            return out.joinToString("/")
        }

        fun readStyles(b: ByteArray?) {
            b ?: return
            runCatching {
                val root = xml(b).documentElement
                root.w("docDefaults")?.w("rPrDefault")?.w("rPr")?.let { rpr ->
                    rpr.w("sz")?.attrW("val")?.toIntOrNull()?.let { defaultSize = it }
                    rpr.w("rFonts")?.let { f -> (f.attrW("ascii") ?: f.attrW("hAnsi"))?.let { defaultFont = it } }
                }
                root.kids().filter { it.isW("style") }.forEach { s ->
                    val id = s.attrW("styleId") ?: return@forEach
                    s.wv("name")?.let { styleNames[id] = it.lowercase() }
                    s.wv("basedOn")?.let { styleBased[id] = it }
                    s.w("pPr")?.w("numPr")?.let { np -> np.wv("numId")?.let { styleNum[id] = it to (np.wv("ilvl")?.toIntOrNull() ?: 0) } }
                    if (s.attrW("default") == "1" && s.attrW("type") == "paragraph") {
                        s.w("rPr")?.let { rpr ->
                            rpr.w("sz")?.attrW("val")?.toIntOrNull()?.let { defaultSize = it }
                            rpr.w("rFonts")?.let { f -> (f.attrW("ascii") ?: f.attrW("hAnsi"))?.let { defaultFont = it } }
                        }
                    }
                }
                page = page.copy(sizePt = (defaultSize / 2).coerceIn(6, 40), font = defaultFont?.takeIf { !it.startsWith("+") } ?: page.font)
            }
        }

        fun readNumbering(b: ByteArray?) {
            b ?: return
            runCatching {
                val root = xml(b).documentElement
                root.kids().filter { it.isW("abstractNum") }.forEach { an ->
                    val id = an.attrW("abstractNumId") ?: return@forEach
                    val m = HashMap<Int, Pair<String, Int>>()
                    an.kids().filter { it.isW("lvl") }.forEach { l ->
                        val lv = l.attrW("ilvl")?.toIntOrNull() ?: 0
                        m[lv] = (l.wv("numFmt") ?: "decimal") to (l.wv("start")?.toIntOrNull() ?: 1)
                    }
                    abstractFmt[id] = m
                }
                root.kids().filter { it.isW("num") }.forEach { n ->
                    val id = n.attrW("numId") ?: return@forEach
                    n.wv("abstractNumId")?.let { numAbstract[id] = it }
                    n.kids().filter { it.isW("lvlOverride") }.forEach { o ->
                        val lv = o.attrW("ilvl")?.toIntOrNull() ?: 0
                        o.w("startOverride")?.attrW("val")?.toIntOrNull()?.let { numStart.getOrPut(id) { HashMap() }[lv] = it }
                    }
                }
            }
        }

        /** Nom du style de paragraphe, en remontant les styles parents. */
        fun styleName(id: String?): String? {
            var cur = id
            var guard = 0
            while (cur != null && guard++ < 10) {
                val n = styleNames[cur]
                if (n != null && (n.startsWith("heading") || n == "title" || n == "subtitle" || "quote" in n || n.startsWith("list"))) return n
                cur = styleBased[cur]
            }
            return id?.let { styleNames[it] }
        }

        fun flushText() {
            if (lines.isEmpty()) return
            blocks += DocBlock.Text(text = lines.joinToString("\n"))
            lines.clear()
        }

        /** Contenu d'un corps de document, d'une cellule, d'un champ de saisie… */
        fun blockChildren(parent: Element) {
            for (e in parent.kids()) {
                when {
                    e.isW("p") -> paragraph(e)
                    e.isW("tbl") -> { flushText(); table(e) }
                    e.isW("sdt") -> e.w("sdtContent")?.let { blockChildren(it) }
                    e.isW("customXml") || e.isW("ins") || e.isW("smartTag") -> blockChildren(e)
                    e.isW("altChunk") -> warn("Une partie collée d'un autre format n'a pas pu être lue.")
                }
            }
        }

        private fun table(tbl: Element) {
            val rows = ArrayList<List<String>>()
            var header = false
            tbl.kids().filter { it.isW("tr") }.forEachIndexed { ri, tr ->
                if (ri == 0 && tr.w("trPr")?.w("tblHeader") != null) header = true
                val cells = ArrayList<String>()
                tr.kids().filter { it.isW("tc") || it.isW("sdt") }.forEach { tc0 ->
                    val tc = if (tc0.isW("sdt")) tc0.w("sdtContent")?.w("tc") ?: return@forEach else tc0
                    val span = tc.w("tcPr")?.w("gridSpan")?.attrW("val")?.toIntOrNull() ?: 1
                    val paras = ArrayList<String>()
                    tc.kids().forEach { c ->
                        when {
                            c.isW("p") -> paras += paragraphText(c).first
                            c.isW("tbl") -> { warn("Les tableaux dans un tableau sont simplifiés."); c.getElementsByTagNameNS(W, "t").let { l -> paras += (0 until l.length).joinToString(" ") { l.item(it).textContent } } }
                        }
                    }
                    // Lignes vides en fin de cellule retirées
                    while (paras.size > 1 && paras.last().isBlank()) paras.removeAt(paras.lastIndex)
                    cells += paras.joinToString("\n")
                    repeat(span - 1) { cells += "" }
                }
                rows += cells
            }
            if (rows.isEmpty()) return
            val cols = rows.maxOf { it.size }
            // Un tableau d'une seule cellule (cadre) : son texte devient un paragraphe
            if (cols == 1 && rows.size == 1) { lines += rows[0][0].split('\n'); return }
            if (!header) header = rows.size > 1 && rows[0].all { c -> c.isNotBlank() && c.startsWith("**") && c.endsWith("**") }
            blocks += DocBlock.Table(rows = rows.map { r -> r + List(cols - r.size) { "" } }, header = header)
        }

        private fun paragraph(p: Element) {
            val ppr = p.w("pPr")
            if (ppr?.flag("pageBreakBefore") == true) { flushText(); blocks += DocBlock.PageBreak() }
            val (text, pieces) = paragraphText(p)
            // Images et sauts de page au milieu du paragraphe : le paragraphe est coupé
            if (pieces.isEmpty()) { lines += prefixed(ppr, text); return }
            var first = true
            pieces.forEach { piece ->
                when (piece) {
                    is Piece.T -> if (piece.text.isNotBlank() || first) { lines += prefixed(ppr, piece.text) }
                    is Piece.Img -> { flushText(); blocks += piece.block }
                    Piece.Break -> { flushText(); blocks += DocBlock.PageBreak() }
                }
                first = false
            }
        }

        /** Préfixe du paragraphe (titre, liste, citation) et alignement. */
        private fun prefixed(ppr: Element?, inline: String): String {
            val styleId = ppr?.wv("pStyle")
            val name = styleName(styleId) ?: ""
            var numId = ppr?.w("numPr")?.wv("numId")
            var ilvl = ppr?.w("numPr")?.wv("ilvl")?.toIntOrNull() ?: 0
            if (numId == null && styleId != null) styleNum[styleId]?.let {
                numId = it.first
                // « List Bullet 2 », « List Number 3 » : le niveau est dans le nom du style
                ilvl = if (it.second == 0 && Regex("^list (bullet|number) \\d$").matches(name)) listLevel(name) else it.second
            }
            if (numId == "0") numId = null
            val outline = ppr?.wv("outlineLvl")?.toIntOrNull()
            val prefix = when {
                name == "title" -> "# "
                name.startsWith("heading 1") || outline == 0 -> "# "
                name.startsWith("heading 2") || outline == 1 -> "## "
                name.startsWith("heading") || name == "subtitle" || (outline != null && outline in 2..8) -> "### "
                numId != null -> listPrefix(numId!!, ilvl.coerceIn(0, 8))
                name.startsWith("list bullet") -> { lastNum = null; "  ".repeat(listLevel(name)) + "- " }
                name.startsWith("list number") -> "  ".repeat(listLevel(name)) + "1. "
                "quote" in name -> "> "
                else -> ""
            }
            if (numId == null) lastNum = null
            val jc = ppr?.wv("jc")
            val align = when (jc) { "center" -> "[center]"; "right", "end" -> "[right]"; else -> "" }
            val body = inline.replace('\n', ' ')
            if (prefix.startsWith("#") && body.isBlank()) return ""
            return prefix + body + if (body.isNotBlank()) align else ""
        }

        private fun listLevel(name: String) = name.lastOrNull()?.digitToIntOrNull()?.let { (it - 1).coerceIn(0, 8) } ?: 0

        private fun listPrefix(numId: String, lvl: Int): String {
            val abs = numAbstract[numId]
            val fmt = abs?.let { abstractFmt[it]?.get(lvl) }
            val ind = "  ".repeat(lvl)
            if (fmt == null || fmt.first == "bullet" || fmt.first == "none") return "$ind- "
            // Compteurs par liste (les niveaux plus profonds repartent à leur début)
            val key = abs
            val c = counters.getOrPut(key) { IntArray(9) }
            // Autre liste du même modèle qui repart de son début
            if (lastNumOf[key] != numId && numStart[numId] != null) c.fill(0)
            lastNumOf[key] = numId
            val start = numStart[numId]?.get(lvl) ?: fmt.second
            c[lvl] = if (c[lvl] == 0) start else c[lvl] + 1
            for (k in lvl + 1 until 9) c[k] = 0
            lastNum = key
            return "$ind${c[lvl]}. "
        }

        private sealed interface Piece {
            data class T(val text: String) : Piece
            data class Img(val block: DocBlock.Image) : Piece
            data object Break : Piece
        }

        /** Texte d'un paragraphe (écriture de Calepin) et, s'il en contient, ses morceaux (texte, images, sauts). */
        fun paragraphText(p: Element): Pair<String, List<Piece>> {
            val runs = ArrayList<WordMarkup.Run>()
            val pieces = ArrayList<Piece>()
            var hasObject = false
            var inInstr = false

            fun cut() {
                pieces += Piece.T(WordMarkup.markup(runs)); runs.clear()
            }

            fun runProps(rpr: Element?): WordMarkup.Run {
                if (rpr == null) return WordMarkup.Run("")
                val color = rpr.w("color")?.attrW("val")?.takeIf { it.length == 6 && it != "000000" && !it.equals("auto", true) }?.let { "#" + it.uppercase() }
                val hl = rpr.w("highlight")?.attrW("val")?.let { HIGHLIGHT[it] }
                    ?: rpr.w("shd")?.attrW("fill")?.takeIf { it.length == 6 && !it.equals("auto", true) && !it.equals("FFFFFF", true) }?.let { "#" + it.uppercase() }
                val u = rpr.flag("u") == true
                if (!fontWarned) {
                    val sz = rpr.w("sz")?.attrW("val")?.toIntOrNull()
                    if (sz != null && kotlin.math.abs(sz - defaultSize) >= 6) { fontWarned = true; warn("Les tailles de caractères particulières sont ramenées à la taille du texte (les titres gardent leur style).") }
                }
                return WordMarkup.Run(
                    "",
                    bold = rpr.flag("b") == true,
                    italic = rpr.flag("i") == true,
                    underline = u,
                    strike = rpr.flag("strike") == true || rpr.flag("dstrike") == true,
                    color = color,
                    highlight = hl,
                )
            }

            fun runContent(r: Element, link: String?) {
                val props = runProps(r.w("rPr")).copy(link = link)
                for (c in r.kids()) {
                    when {
                        c.isW("t") -> if (!inInstr) runs += props.copy(text = c.textContent)
                        c.isW("tab") || c.isW("ptab") -> runs += props.copy(text = "\t")
                        c.isW("br") -> when (c.attrW("type")) {
                            "page" -> { hasObject = true; cut(); pieces += Piece.Break }
                            "column" -> {}
                            else -> runs += props.copy(text = "\n")
                        }
                        c.isW("cr") -> runs += props.copy(text = "\n")
                        c.isW("noBreakHyphen") -> runs += props.copy(text = "-")
                        c.isW("sym") -> c.attrW("char")?.toIntOrNull(16)?.let { code ->
                            // Symboles Wingdings des cases et puces
                            val ch = when (code) { 0xF0A8, 0xF06F, 0xF071 -> "☐"; 0xF0FE, 0xF078 -> "☑"; 0xF0B7, 0xF0A7 -> "•"; else -> null }
                            ch?.let { runs += props.copy(text = it) }
                        }
                        c.isW("fldChar") -> when (c.attrW("fldCharType")) { "begin" -> inInstr = true; "separate", "end" -> inInstr = false }
                        c.isW("instrText") -> {}
                        c.isW("footnoteReference") || c.isW("endnoteReference") -> footnotes = true
                        c.isW("drawing") || c.isW("pict") || c.isW("object") -> image(c)?.let { img ->
                            hasObject = true; cut(); pieces += Piece.Img(img)
                        }
                        c.isW("AlternateContent") || c.localName == "AlternateContent" -> {
                            // Image ou zone de texte proposée sous deux formes : on prend la première
                            val choice = c.kids().firstOrNull { it.localName == "Choice" } ?: c.kids().firstOrNull { it.localName == "Fallback" }
                            choice?.let { ch ->
                                val txbx = ch.getElementsByTagNameNS(W, "txbxContent")
                                if (txbx.length > 0) {
                                    warn("Les zones de texte sont mises dans le texte.")
                                    val t = txbx.item(0) as Element
                                    val ps = t.getElementsByTagNameNS(W, "p")
                                    (0 until ps.length).forEach { i -> runs += props.copy(text = (if (i > 0) "\n" else "") + paragraphText(ps.item(i) as Element).first) }
                                } else image(ch)?.let { img -> hasObject = true; cut(); pieces += Piece.Img(img) }
                            }
                        }
                    }
                }
            }

            fun inline(parent: Element, link: String?) {
                for (c in parent.kids()) {
                    when {
                        c.isW("r") -> runContent(c, link)
                        c.isW("hyperlink") -> {
                            val id = c.getAttributeNS(R, "id")
                            val url = rels[id]?.takeIf { it.external }?.target?.takeIf { it.startsWith("http") || it.startsWith("mailto:") || it.startsWith("tel:") }
                            inline(c, url)
                        }
                        c.isW("fldSimple") -> {
                            val instr = c.attrW("instr").orEmpty()
                            val url = Regex("HYPERLINK\\s+\"([^\"]+)\"").find(instr)?.groupValues?.get(1)
                            inline(c, url ?: link)
                        }
                        c.isW("ins") || c.isW("smartTag") || c.isW("customXml") || c.isW("sdt") || c.isW("sdtContent") || c.isW("moveTo") -> inline(c, link)
                        c.isW("del") || c.isW("moveFrom") -> {}
                        c.namespaceURI?.contains("math") == true -> { warn("Les équations ne sont pas affichées."); runs += WordMarkup.Run("[équation]") }
                    }
                }
            }

            inline(p, null)
            // Saut de ligne en fin de paragraphe : retiré
            val text = WordMarkup.markup(runs)
            if (!hasObject) return text to emptyList()
            pieces += Piece.T(text)
            return "" to pieces
        }

        /** Image d'un dessin (« drawing » ou ancien « pict ») : enregistrée, avec sa largeur. */
        private fun image(e: Element): DocBlock.Image? {
            val blip = e.getElementsByTagNameNS(A, "blip").item(0) as? Element
            val embed = blip?.getAttributeNS(R, "embed")?.takeIf { it.isNotEmpty() }
                ?: (e.getElementsByTagNameNS("urn:schemas-microsoft-com:vml", "imagedata").item(0) as? Element)?.getAttributeNS(R, "id")?.takeIf { it.isNotEmpty() }
            if (embed == null) {
                val g = e.getElementsByTagNameNS(A, "graphicData").item(0) as? Element
                val uri = g?.getAttribute("uri").orEmpty()
                if ("chart" in uri) warn("Les graphiques ne sont pas affichés.")
                else if ("diagram" in uri) warn("Les SmartArt ne sont pas affichés.")
                else if (e.getElementsByTagNameNS(W, "txbxContent").length > 0) warn("Les zones de texte sont simplifiées.")
                return null
            }
            val rel = rels[embed] ?: return null
            if (rel.external) return null
            val bytes = parts[path(rel.target)] ?: return null
            val ext = rel.target.substringAfterLast('.', "png").lowercase().let { if (it == "jpeg") "jpg" else it }
            if (ext !in setOf("png", "jpg", "gif", "bmp", "webp")) { warn("Certaines images (format $ext) ne sont pas affichées."); return null }
            imgN++
            val name = "img_$imgN.$ext"
            images[name] = bytes
            val extent = (e.getElementsByTagNameNS("http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing", "extent").item(0) as? Element)
                ?.getAttribute("cx")?.toLongOrNull()
            val pct = extent?.let { Math.round(it / 635.0 / page.textWidthTwips * 100).toInt() }?.coerceIn(10, 100) ?: 100
            if (e.getElementsByTagNameNS("http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing", "anchor").length > 0) {
                warn("Les images placées librement sont mises dans le texte.")
            }
            return DocBlock.Image(file = name, widthPct = pct)
        }
    }
}

/**
 * Écriture d'un fichier Word (.docx) à partir du document de Calepin : styles de Word (Titre 1, 2, 3,
 * Citation), vraies listes à puces et numérotées, tableaux, images, liens, en-tête, pied de page et
 * numéros de page. Le fichier s'ouvre dans Word, LibreOffice, Google Docs, Pages…
 */
object DocxWriter {
    private fun esc(s: String) = buildString(s.length) {
        for (c in s) when (c) {
            '&' -> append("&amp;"); '<' -> append("&lt;"); '>' -> append("&gt;"); '"' -> append("&quot;")
            else -> if (c.code < 0x20 && c != '\t' && c != '\n' && c != '\r') {} else append(c)
        }
    }

    private class Out(val page: PageSetup, val image: (String) -> ByteArray?) {
        val body = StringBuilder()
        val rels = ArrayList<Triple<String, String, String?>>() // id, type, target (mode External si url)
        val media = LinkedHashMap<String, ByteArray>()
        val numbered = ArrayList<Int>() // départs des listes numérotées (une liste Word par liste)
        var docPr = 1
        private var relN = 10

        fun rel(type: String, target: String, external: Boolean = false): String {
            val id = "rId" + (++relN)
            rels += Triple(id, type, if (external) "EXT:$target" else target)
            return id
        }
    }

    fun write(doc: WordDoc, title: String, image: (String) -> ByteArray?): ByteArray {
        val o = Out(doc.page, image)
        doc.blocks.forEachIndexed { bi, b ->
            when (b) {
                is DocBlock.Text -> textBlock(o, b.text)
                is DocBlock.Table -> table(o, b)
                is DocBlock.Image -> imageBlock(o, b)
                is DocBlock.PageBreak -> o.body.append("<w:p><w:r><w:br w:type=\"page\"/></w:r></w:p>")
            }
        }
        val pg = doc.page
        val hasHeader = pg.header.isNotBlank()
        val hasFooter = pg.footer.isNotBlank() || pg.pageNumbers
        val headerId = if (hasHeader) o.rel("http://schemas.openxmlformats.org/officeDocument/2006/relationships/header", "header1.xml") else null
        val footerId = if (hasFooter) o.rel("http://schemas.openxmlformats.org/officeDocument/2006/relationships/footer", "footer1.xml") else null
        val sect = buildString {
            append("<w:sectPr>")
            headerId?.let { append("<w:headerReference w:type=\"default\" r:id=\"$it\"/>") }
            footerId?.let { append("<w:footerReference w:type=\"default\" r:id=\"$it\"/>") }
            append("<w:pgSz w:w=\"${pg.widthTwips}\" w:h=\"${pg.heightTwips}\"" + (if (pg.landscape) " w:orient=\"landscape\"" else "") + "/>")
            val m = pg.marginTwips
            append("<w:pgMar w:top=\"$m\" w:right=\"$m\" w:bottom=\"$m\" w:left=\"$m\" w:header=\"567\" w:footer=\"567\" w:gutter=\"0\"/>")
            append("</w:sectPr>")
        }
        // Le dernier élément du corps doit être un paragraphe (Word l'exige après un tableau)
        if (o.body.endsWith("</w:tbl>")) o.body.append("<w:p/>")
        val document = XML_HEAD + "<w:document $NS><w:body>" + o.body + sect + "</w:body></w:document>"

        val files = LinkedHashMap<String, ByteArray>()
        val ct = StringBuilder(XML_HEAD + "<Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\">" +
            "<Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/>" +
            "<Default Extension=\"xml\" ContentType=\"application/xml\"/>")
        val exts = o.media.keys.map { it.substringAfterLast('.').lowercase() }.toSet()
        exts.forEach { e -> ct.append("<Default Extension=\"$e\" ContentType=\"${mimeOf(e)}\"/>") }
        ct.append("<Override PartName=\"/word/document.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml\"/>")
        ct.append("<Override PartName=\"/word/styles.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.wordprocessingml.styles+xml\"/>")
        ct.append("<Override PartName=\"/word/numbering.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.wordprocessingml.numbering+xml\"/>")
        ct.append("<Override PartName=\"/word/settings.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.wordprocessingml.settings+xml\"/>")
        if (hasHeader) ct.append("<Override PartName=\"/word/header1.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.wordprocessingml.header+xml\"/>")
        if (hasFooter) ct.append("<Override PartName=\"/word/footer1.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.wordprocessingml.footer+xml\"/>")
        ct.append("<Override PartName=\"/docProps/core.xml\" ContentType=\"application/vnd.openxmlformats-package.core-properties+xml\"/>")
        ct.append("<Override PartName=\"/docProps/app.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.extended-properties+xml\"/>")
        ct.append("</Types>")
        files["[Content_Types].xml"] = ct.toString().toByteArray()
        files["_rels/.rels"] = (XML_HEAD + "<Relationships xmlns=\"$PKG_R\">" +
            "<Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument\" Target=\"word/document.xml\"/>" +
            "<Relationship Id=\"rId2\" Type=\"http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties\" Target=\"docProps/core.xml\"/>" +
            "<Relationship Id=\"rId3\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/extended-properties\" Target=\"docProps/app.xml\"/>" +
            "</Relationships>").toByteArray()
        files["word/document.xml"] = document.toByteArray()
        val dr = StringBuilder(XML_HEAD + "<Relationships xmlns=\"$PKG_R\">" +
            "<Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles\" Target=\"styles.xml\"/>" +
            "<Relationship Id=\"rId2\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/numbering\" Target=\"numbering.xml\"/>" +
            "<Relationship Id=\"rId3\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/settings\" Target=\"settings.xml\"/>")
        o.rels.forEach { (id, type, target) ->
            if (target != null && target.startsWith("EXT:")) dr.append("<Relationship Id=\"$id\" Type=\"$type\" Target=\"${esc(target.removePrefix("EXT:"))}\" TargetMode=\"External\"/>")
            else dr.append("<Relationship Id=\"$id\" Type=\"$type\" Target=\"${esc(target ?: "")}\"/>")
        }
        dr.append("</Relationships>")
        files["word/_rels/document.xml.rels"] = dr.toString().toByteArray()
        files["word/styles.xml"] = styles(pg).toByteArray()
        files["word/numbering.xml"] = numbering(o.numbered).toByteArray()
        files["word/settings.xml"] = (XML_HEAD + "<w:settings $NS><w:defaultTabStop w:val=\"708\"/><w:characterSpacingControl w:val=\"doNotCompress\"/><w:compat><w:compatSetting w:name=\"compatibilityMode\" w:uri=\"http://schemas.microsoft.com/office/word\" w:val=\"15\"/></w:compat></w:settings>").toByteArray()
        if (hasHeader) files["word/header1.xml"] = (XML_HEAD + "<w:hdr $NS>" + headerFooterPara(pg.header, false, pg) + "</w:hdr>").toByteArray()
        if (hasFooter) files["word/footer1.xml"] = (XML_HEAD + "<w:ftr $NS>" + headerFooterPara(pg.footer, pg.pageNumbers, pg) + "</w:ftr>").toByteArray()
        o.media.forEach { (n, b) -> files["word/media/$n"] = b }
        val now = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.ROOT).apply { timeZone = TimeZone.getTimeZone("UTC") }.format(Date())
        files["docProps/core.xml"] = (XML_HEAD + "<cp:coreProperties xmlns:cp=\"http://schemas.openxmlformats.org/package/2006/metadata/core-properties\" " +
            "xmlns:dc=\"http://purl.org/dc/elements/1.1/\" xmlns:dcterms=\"http://purl.org/dc/terms/\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\">" +
            "<dc:title>${esc(title)}</dc:title><dc:creator>Calepin</dc:creator>" +
            "<dcterms:created xsi:type=\"dcterms:W3CDTF\">$now</dcterms:created><dcterms:modified xsi:type=\"dcterms:W3CDTF\">$now</dcterms:modified>" +
            "</cp:coreProperties>").toByteArray()
        files["docProps/app.xml"] = (XML_HEAD + "<Properties xmlns=\"http://schemas.openxmlformats.org/officeDocument/2006/extended-properties\"><Application>Calepin</Application></Properties>").toByteArray()

        val bo = ByteArrayOutputStream()
        ZipOutputStream(bo).use { z ->
            files.forEach { (n, b) ->
                z.putNextEntry(ZipEntry(n)); z.write(b); z.closeEntry()
            }
        }
        return bo.toByteArray()
    }

    private const val XML_HEAD = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>"
    private const val NS = "xmlns:w=\"$W\" xmlns:r=\"$R\" " +
        "xmlns:wp=\"http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing\" " +
        "xmlns:a=\"$A\" xmlns:pic=\"http://schemas.openxmlformats.org/drawingml/2006/picture\""

    private fun mimeOf(e: String) = when (e) { "jpg", "jpeg" -> "image/jpeg"; "gif" -> "image/gif"; "bmp" -> "image/bmp"; "webp" -> "image/webp"; else -> "image/png" }

    private fun headerFooterPara(text: String, pageNumber: Boolean, pg: PageSetup): String {
        val sb = StringBuilder("<w:p><w:pPr><w:jc w:val=\"center\"/></w:pPr>")
        val rpr = "<w:rPr><w:color w:val=\"7F7F7F\"/><w:sz w:val=\"18\"/></w:rPr>"
        if (text.isNotBlank()) sb.append("<w:r>$rpr<w:t xml:space=\"preserve\">${esc(text)}</w:t></w:r>")
        if (pageNumber) {
            if (text.isNotBlank()) sb.append("<w:r>$rpr<w:t xml:space=\"preserve\"> · </w:t></w:r>")
            sb.append("<w:fldSimple w:instr=\" PAGE \"><w:r>$rpr<w:t>1</w:t></w:r></w:fldSimple>")
        }
        return sb.append("</w:p>").toString()
    }

    // ------------------------------------------------------------------ Paragraphes

    private fun textBlock(o: Out, text: String) {
        var currentNum = 0 // numId de la liste numérotée en cours (0 : aucune)
        text.split('\n').forEach { line ->
            val p = WordMarkup.parse(line)
            if (p.kind == WordMarkup.Kind.NUMBER) {
                if (currentNum == 0) {
                    o.numbered += p.number.coerceAtLeast(1)
                    currentNum = o.numbered.size + 1 // numId 1 : puces ; 2… : listes numérotées
                }
            } else if (!(WordMarkup.isList(p.kind) && p.level > 0)) {
                currentNum = 0
            }
            o.body.append(paragraph(o, line, p, currentNum))
        }
    }

    private fun paragraph(o: Out, line: String, p: WordMarkup.Line, numId: Int): String {
        val align = WordMarkup.alignOf(line)
        var inner = WordMarkup.body(line)
        val ppr = StringBuilder()
        when (p.kind) {
            WordMarkup.Kind.H1 -> ppr.append("<w:pStyle w:val=\"Heading1\"/>")
            WordMarkup.Kind.H2 -> ppr.append("<w:pStyle w:val=\"Heading2\"/>")
            WordMarkup.Kind.H3 -> ppr.append("<w:pStyle w:val=\"Heading3\"/>")
            WordMarkup.Kind.QUOTE -> ppr.append("<w:pStyle w:val=\"Quote\"/>")
            WordMarkup.Kind.BULLET -> ppr.append("<w:pStyle w:val=\"ListParagraph\"/><w:numPr><w:ilvl w:val=\"${p.level}\"/><w:numId w:val=\"1\"/></w:numPr>")
            WordMarkup.Kind.NUMBER -> ppr.append("<w:pStyle w:val=\"ListParagraph\"/><w:numPr><w:ilvl w:val=\"${p.level}\"/><w:numId w:val=\"${numId.coerceAtLeast(2)}\"/></w:numPr>")
            WordMarkup.Kind.CHECK -> {
                ppr.append("<w:pStyle w:val=\"ListParagraph\"/><w:ind w:left=\"${720 + 360 * p.level}\" w:hanging=\"360\"/>")
                inner = (if (p.done) "☑ " else "☐ ") + inner
            }
            WordMarkup.Kind.NORMAL -> {}
        }
        if (WordMarkup.isList(p.kind)) ppr.append("<w:spacing w:after=\"40\"/>")
        when (align) { "center" -> ppr.append("<w:jc w:val=\"center\"/>"); "right" -> ppr.append("<w:jc w:val=\"right\"/>") }
        val runs = StringBuilder()
        WordMarkup.runs(inner).forEach { r -> runs.append(run(o, r, done = p.kind == WordMarkup.Kind.CHECK && p.done)) }
        return "<w:p>" + (if (ppr.isNotEmpty()) "<w:pPr>$ppr</w:pPr>" else "") + runs + "</w:p>"
    }

    private fun run(o: Out, r: WordMarkup.Run, done: Boolean = false): String {
        val rpr = StringBuilder()
        if (r.link != null) rpr.append("<w:rStyle w:val=\"Hyperlink\"/>")
        if (r.bold) rpr.append("<w:b/>")
        if (r.italic) rpr.append("<w:i/>")
        if (r.strike) rpr.append("<w:strike/>")
        r.color?.let { rpr.append("<w:color w:val=\"${it.removePrefix("#")}\"/>") }
        if (r.underline) rpr.append("<w:u w:val=\"single\"/>")
        r.highlight?.let { rpr.append("<w:shd w:val=\"clear\" w:color=\"auto\" w:fill=\"${it.removePrefix("#")}\"/>") }
        val props = if (rpr.isEmpty()) "" else "<w:rPr>$rpr</w:rPr>"
        val content = StringBuilder()
        // Tabulations et retours à la ligne gardés
        val parts = r.text.split('\n')
        parts.forEachIndexed { i, part ->
            if (i > 0) content.append("<w:br/>")
            part.split('\t').forEachIndexed { j, t ->
                if (j > 0) content.append("<w:tab/>")
                if (t.isNotEmpty()) content.append("<w:t xml:space=\"preserve\">").append(esc(t)).append("</w:t>")
            }
        }
        val runXml = "<w:r>$props$content</w:r>"
        if (r.link == null) return runXml
        val id = o.rel("http://schemas.openxmlformats.org/officeDocument/2006/relationships/hyperlink", r.link, external = true)
        return "<w:hyperlink r:id=\"$id\" w:history=\"1\">$runXml</w:hyperlink>"
    }

    // ------------------------------------------------------------------ Tableaux

    private fun table(o: Out, t: DocBlock.Table) {
        val cols = t.cols.coerceAtLeast(1)
        val total = o.page.textWidthTwips
        // Largeurs selon la longueur du texte des colonnes (bornées)
        val lens = (0 until cols).map { c -> t.rows.maxOfOrNull { r -> WordMarkup.plainLines(r.getOrElse(c) { "" }).length.coerceIn(4, 40) }?.toFloat() ?: 4f }
        val widths = lens.map { (it / lens.sum() * total).toInt() }
        val sb = StringBuilder("<w:tbl><w:tblPr><w:tblStyle w:val=\"TableGrid\"/><w:tblW w:w=\"5000\" w:type=\"pct\"/><w:tblLook w:val=\"04A0\" w:firstRow=\"1\" w:lastRow=\"0\" w:firstColumn=\"0\" w:lastColumn=\"0\" w:noHBand=\"0\" w:noVBand=\"1\"/></w:tblPr><w:tblGrid>")
        widths.forEach { sb.append("<w:gridCol w:w=\"$it\"/>") }
        sb.append("</w:tblGrid>")
        t.rows.forEachIndexed { ri, row ->
            val head = t.header && ri == 0
            sb.append("<w:tr>")
            if (head) sb.append("<w:trPr><w:tblHeader/></w:trPr>")
            for (c in 0 until cols) {
                val cell = row.getOrElse(c) { "" }
                sb.append("<w:tc><w:tcPr><w:tcW w:w=\"${widths[c]}\" w:type=\"dxa\"/>")
                if (head) sb.append("<w:shd w:val=\"clear\" w:color=\"auto\" w:fill=\"DEEAF6\"/>")
                sb.append("</w:tcPr>")
                cell.split('\n').forEach { line ->
                    val p = WordMarkup.parse(line)
                    val inner = WordMarkup.body(line)
                    val align = WordMarkup.alignOf(line)
                    sb.append("<w:p><w:pPr><w:spacing w:before=\"20\" w:after=\"20\"/>")
                    when (align) { "center" -> sb.append("<w:jc w:val=\"center\"/>"); "right" -> sb.append("<w:jc w:val=\"right\"/>") }
                    sb.append("</w:pPr>")
                    val prefix = when (p.kind) { WordMarkup.Kind.BULLET -> "• "; WordMarkup.Kind.CHECK -> if (p.done) "☑ " else "☐ "; WordMarkup.Kind.NUMBER -> "${p.number}. "; else -> "" }
                    if (prefix.isNotEmpty()) sb.append("<w:r><w:t xml:space=\"preserve\">$prefix</w:t></w:r>")
                    WordMarkup.runs(inner).forEach { r -> sb.append(run(o, if (head) r.copy(bold = true) else r)) }
                    sb.append("</w:p>")
                }
                sb.append("</w:tc>")
            }
            sb.append("</w:tr>")
        }
        sb.append("</w:tbl>")
        o.body.append(sb)
    }

    // ------------------------------------------------------------------ Images

    private fun imageBlock(o: Out, b: DocBlock.Image) {
        val bytes = o.image(b.file) ?: return
        val size = ImageSize.of(bytes) ?: (800 to 600)
        val ext = b.file.substringAfterLast('.', "png").lowercase().let { if (it == "jpeg") "jpg" else it }
        val name = "image${o.media.size + 1}.$ext"
        o.media[name] = bytes
        val id = o.rel("http://schemas.openxmlformats.org/officeDocument/2006/relationships/image", "media/$name")
        val maxW = o.page.textWidthTwips * 635L
        val cx = (maxW * b.widthPct.coerceIn(10, 100) / 100)
        val cy = (cx * size.second / size.first.coerceAtLeast(1))
        val n = o.docPr++
        val jc = when (b.align) { "left" -> "left"; "right" -> "right"; else -> "center" }
        o.body.append(
            "<w:p><w:pPr><w:jc w:val=\"$jc\"/></w:pPr><w:r><w:drawing><wp:inline distT=\"0\" distB=\"0\" distL=\"0\" distR=\"0\">" +
                "<wp:extent cx=\"$cx\" cy=\"$cy\"/><wp:docPr id=\"$n\" name=\"Image $n\"/>" +
                "<wp:cNvGraphicFramePr><a:graphicFrameLocks noChangeAspect=\"1\"/></wp:cNvGraphicFramePr>" +
                "<a:graphic><a:graphicData uri=\"http://schemas.openxmlformats.org/drawingml/2006/picture\">" +
                "<pic:pic><pic:nvPicPr><pic:cNvPr id=\"$n\" name=\"$name\"/><pic:cNvPicPr/></pic:nvPicPr>" +
                "<pic:blipFill><a:blip r:embed=\"$id\"/><a:stretch><a:fillRect/></a:stretch></pic:blipFill>" +
                "<pic:spPr><a:xfrm><a:off x=\"0\" y=\"0\"/><a:ext cx=\"$cx\" cy=\"$cy\"/></a:xfrm><a:prstGeom prst=\"rect\"><a:avLst/></a:prstGeom></pic:spPr>" +
                "</pic:pic></a:graphicData></a:graphic></wp:inline></w:drawing></w:r></w:p>"
        )
    }

    // ------------------------------------------------------------------ Styles et listes

    private fun styles(pg: PageSetup): String {
        val f = esc(pg.font)
        val sz = pg.sizePt * 2
        fun heading(id: String, name: String, size: Int, lvl: Int, color: String) =
            "<w:style w:type=\"paragraph\" w:styleId=\"$id\"><w:name w:val=\"$name\"/><w:basedOn w:val=\"Normal\"/><w:next w:val=\"Normal\"/><w:uiPriority w:val=\"9\"/><w:qFormat/>" +
                "<w:pPr><w:keepNext/><w:keepLines/><w:spacing w:before=\"${if (lvl == 0) 360 else 240}\" w:after=\"80\"/><w:outlineLvl w:val=\"$lvl\"/></w:pPr>" +
                "<w:rPr><w:b/><w:color w:val=\"$color\"/><w:sz w:val=\"$size\"/><w:szCs w:val=\"$size\"/></w:rPr></w:style>"
        return XML_HEAD + "<w:styles $NS>" +
            "<w:docDefaults><w:rPrDefault><w:rPr><w:rFonts w:ascii=\"$f\" w:hAnsi=\"$f\" w:eastAsia=\"$f\" w:cs=\"$f\"/>" +
            "<w:sz w:val=\"$sz\"/><w:szCs w:val=\"$sz\"/><w:lang w:val=\"fr-FR\" w:eastAsia=\"en-US\" w:bidi=\"ar-SA\"/></w:rPr></w:rPrDefault>" +
            "<w:pPrDefault><w:pPr><w:spacing w:after=\"120\" w:line=\"276\" w:lineRule=\"auto\"/></w:pPr></w:pPrDefault></w:docDefaults>" +
            "<w:style w:type=\"paragraph\" w:default=\"1\" w:styleId=\"Normal\"><w:name w:val=\"Normal\"/><w:qFormat/></w:style>" +
            heading("Heading1", "heading 1", sz + 12, 0, "2F5496") +
            heading("Heading2", "heading 2", sz + 6, 1, "2F5496") +
            heading("Heading3", "heading 3", sz + 2, 2, "1F3763") +
            "<w:style w:type=\"paragraph\" w:styleId=\"Quote\"><w:name w:val=\"Quote\"/><w:basedOn w:val=\"Normal\"/><w:next w:val=\"Normal\"/><w:qFormat/>" +
            "<w:pPr><w:ind w:left=\"567\" w:right=\"567\"/><w:pBdr><w:left w:val=\"single\" w:sz=\"18\" w:space=\"8\" w:color=\"A5A5A5\"/></w:pBdr></w:pPr>" +
            "<w:rPr><w:i/><w:color w:val=\"404040\"/></w:rPr></w:style>" +
            "<w:style w:type=\"paragraph\" w:styleId=\"ListParagraph\"><w:name w:val=\"List Paragraph\"/><w:basedOn w:val=\"Normal\"/><w:qFormat/><w:pPr><w:ind w:left=\"720\"/><w:contextualSpacing/></w:pPr></w:style>" +
            "<w:style w:type=\"character\" w:default=\"1\" w:styleId=\"DefaultParagraphFont\"><w:name w:val=\"Default Paragraph Font\"/><w:uiPriority w:val=\"1\"/><w:semiHidden/></w:style>" +
            "<w:style w:type=\"character\" w:styleId=\"Hyperlink\"><w:name w:val=\"Hyperlink\"/><w:basedOn w:val=\"DefaultParagraphFont\"/><w:rPr><w:color w:val=\"0563C1\"/><w:u w:val=\"single\"/></w:rPr></w:style>" +
            "<w:style w:type=\"table\" w:default=\"1\" w:styleId=\"TableNormal\"><w:name w:val=\"Normal Table\"/><w:semiHidden/><w:tblPr><w:tblInd w:w=\"0\" w:type=\"dxa\"/>" +
            "<w:tblCellMar><w:top w:w=\"0\" w:type=\"dxa\"/><w:left w:w=\"108\" w:type=\"dxa\"/><w:bottom w:w=\"0\" w:type=\"dxa\"/><w:right w:w=\"108\" w:type=\"dxa\"/></w:tblCellMar></w:tblPr></w:style>" +
            "<w:style w:type=\"table\" w:styleId=\"TableGrid\"><w:name w:val=\"Table Grid\"/><w:basedOn w:val=\"TableNormal\"/><w:pPr><w:spacing w:after=\"0\" w:line=\"240\" w:lineRule=\"auto\"/></w:pPr>" +
            "<w:tblPr><w:tblBorders>" + listOf("top", "left", "bottom", "right", "insideH", "insideV").joinToString("") { "<w:$it w:val=\"single\" w:sz=\"4\" w:space=\"0\" w:color=\"A6A6A6\"/>" } +
            "</w:tblBorders><w:tblCellMar><w:top w:w=\"40\" w:type=\"dxa\"/><w:left w:w=\"108\" w:type=\"dxa\"/><w:bottom w:w=\"40\" w:type=\"dxa\"/><w:right w:w=\"108\" w:type=\"dxa\"/></w:tblCellMar></w:tblPr></w:style>" +
            "</w:styles>"
    }

    private fun numbering(starts: List<Int>): String {
        val bullets = listOf("•", "◦", "▪")
        val fmts = listOf("decimal" to "%1.", "lowerLetter" to "%2.", "lowerRoman" to "%3.")
        val sb = StringBuilder(XML_HEAD + "<w:numbering $NS>")
        sb.append("<w:abstractNum w:abstractNumId=\"0\"><w:multiLevelType w:val=\"hybridMultilevel\"/>")
        for (l in 0..8) {
            sb.append("<w:lvl w:ilvl=\"$l\"><w:start w:val=\"1\"/><w:numFmt w:val=\"bullet\"/><w:lvlText w:val=\"${bullets[l % 3]}\"/><w:lvlJc w:val=\"left\"/>" +
                "<w:pPr><w:ind w:left=\"${720 + 360 * l}\" w:hanging=\"360\"/></w:pPr><w:rPr><w:rFonts w:ascii=\"Arial\" w:hAnsi=\"Arial\"/></w:rPr></w:lvl>")
        }
        sb.append("</w:abstractNum>")
        sb.append("<w:abstractNum w:abstractNumId=\"1\"><w:multiLevelType w:val=\"hybridMultilevel\"/>")
        for (l in 0..8) {
            val (fmt, _) = fmts[l % 3]
            sb.append("<w:lvl w:ilvl=\"$l\"><w:start w:val=\"1\"/><w:numFmt w:val=\"$fmt\"/><w:lvlText w:val=\"%${l + 1}.\"/><w:lvlJc w:val=\"left\"/>" +
                "<w:pPr><w:ind w:left=\"${720 + 360 * l}\" w:hanging=\"360\"/></w:pPr></w:lvl>")
        }
        sb.append("</w:abstractNum>")
        sb.append("<w:num w:numId=\"1\"><w:abstractNumId w:val=\"0\"/></w:num>")
        // Une numérotation par liste : chaque liste repart de son premier numéro
        starts.forEachIndexed { i, s ->
            sb.append("<w:num w:numId=\"${i + 2}\"><w:abstractNumId w:val=\"1\"/><w:lvlOverride w:ilvl=\"0\"><w:startOverride w:val=\"$s\"/></w:lvlOverride></w:num>")
        }
        if (starts.isEmpty()) sb.append("<w:num w:numId=\"2\"><w:abstractNumId w:val=\"1\"/></w:num>")
        sb.append("</w:numbering>")
        return sb.toString()
    }
}

/** Taille en pixels d'une image PNG, JPEG, GIF, BMP ou WebP, lue dans son en-tête. */
object ImageSize {
    fun of(b: ByteArray): Pair<Int, Int>? = runCatching {
        fun u16be(i: Int) = ((b[i].toInt() and 0xFF) shl 8) or (b[i + 1].toInt() and 0xFF)
        fun u16le(i: Int) = (b[i].toInt() and 0xFF) or ((b[i + 1].toInt() and 0xFF) shl 8)
        fun u32be(i: Int) = (u16be(i) shl 16) or u16be(i + 2)
        fun u32le(i: Int) = u16le(i) or (u16le(i + 2) shl 16)
        when {
            b.size > 24 && b[0] == 0x89.toByte() && b[1] == 'P'.code.toByte() -> u32be(16) to u32be(20)
            b.size > 10 && b[0] == 'G'.code.toByte() && b[1] == 'I'.code.toByte() -> u16le(6) to u16le(8)
            b.size > 26 && b[0] == 'B'.code.toByte() && b[1] == 'M'.code.toByte() -> u32le(18) to kotlin.math.abs(u32le(22))
            b.size > 30 && String(b, 0, 4) == "RIFF" && String(b, 8, 4) == "WEBP" -> when (String(b, 12, 4)) {
                "VP8X" -> (1 + (u16le(24) or ((b[26].toInt() and 0xFF) shl 16))) to (1 + (u16le(27) or ((b[29].toInt() and 0xFF) shl 16)))
                "VP8L" -> { val v = u32le(21); (1 + (v and 0x3FFF)) to (1 + ((v shr 14) and 0x3FFF)) }
                else -> (u16le(26) and 0x3FFF) to (u16le(28) and 0x3FFF)
            }
            b.size > 4 && b[0] == 0xFF.toByte() && b[1] == 0xD8.toByte() -> {
                var i = 2
                var res: Pair<Int, Int>? = null
                while (i + 9 < b.size) {
                    if (b[i] != 0xFF.toByte()) { i++; continue }
                    val m = b[i + 1].toInt() and 0xFF
                    if (m in 0xC0..0xCF && m != 0xC4 && m != 0xC8 && m != 0xCC) { res = u16be(i + 7) to u16be(i + 5); break }
                    if (m == 0xD8 || m == 0x01 || m in 0xD0..0xD7) { i += 2; continue }
                    i += 2 + u16be(i + 2)
                }
                res
            }
            else -> null
        }
    }.getOrNull()?.takeIf { it.first > 0 && it.second > 0 }
}
