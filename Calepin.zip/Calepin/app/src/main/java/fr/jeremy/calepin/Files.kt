package fr.jeremy.calepin

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.core.content.FileProvider
import java.io.File

/** Partage et enregistrement de fichiers vers les autres applis. */
object Files {
    private fun authority(ctx: Context) = ctx.packageName + ".files"

    fun uriFor(ctx: Context, file: File): Uri = FileProvider.getUriForFile(ctx, authority(ctx), file)

    /** Écrit les octets dans le cache puis ouvre « Partager ». */
    fun shareBytes(ctx: Context, bytes: ByteArray, fileName: String, mime: String) {
        val dir = File(ctx.cacheDir, "exports").apply { mkdirs() }
        dir.listFiles()?.forEach { it.delete() }
        val f = File(dir, fileName)
        f.writeBytes(bytes)
        shareFile(ctx, f, mime, fileName)
    }

    fun shareFile(ctx: Context, file: File, mime: String, title: String) {
        LockGuard.external()
        val i = Intent(Intent.ACTION_SEND).apply {
            type = mime
            putExtra(Intent.EXTRA_STREAM, uriFor(ctx, file))
            putExtra(Intent.EXTRA_SUBJECT, title)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        try {
            ctx.startActivity(Intent.createChooser(i, "Partager « $title »").addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION))
        } catch (e: Exception) {
            Toast.makeText(ctx, "Aucune application pour partager ce fichier", Toast.LENGTH_SHORT).show()
        }
    }

    /** Intent « Enregistrer sous… » : l'utilisateur choisit le dossier (Téléchargements, Drive…). */
    fun createDocumentIntent(fileName: String, mime: String): Intent =
        Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = mime
            putExtra(Intent.EXTRA_TITLE, fileName)
        }

    fun write(ctx: Context, uri: Uri, bytes: ByteArray): Boolean = try {
        ctx.contentResolver.openOutputStream(uri, "wt")?.use { it.write(bytes) }
        true
    } catch (e: Exception) {
        false
    }
}
