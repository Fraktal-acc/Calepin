package fr.jeremy.calepin.ui

import android.app.Activity
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.pdf.PdfRenderer
import android.os.ParcelFileDescriptor
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowLeft
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Business
import androidx.compose.material.icons.filled.SaveAlt
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import fr.jeremy.calepin.BuildConfig
import fr.jeremy.calepin.Files
import fr.jeremy.calepin.LockGuard
import fr.jeremy.calepin.NotesViewModel
import fr.jeremy.calepin.data.Note
import fr.jeremy.calepin.export.ExportFormat
import fr.jeremy.calepin.export.Exporters
import fr.jeremy.calepin.export.PdfStyle
import fr.jeremy.calepin.i18n.RawText
import fr.jeremy.calepin.i18n.Text
import fr.jeremy.calepin.text.AutoLayout
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

/** Réglages gardés d'une fois sur l'autre. */
private object LayoutPrefs {
    private fun p(ctx: android.content.Context) = ctx.applicationContext.getSharedPreferences("calepin_layout_pdf", android.content.Context.MODE_PRIVATE)
    fun style(ctx: android.content.Context) = runCatching { PdfStyle.valueOf(p(ctx).getString("style", null) ?: "") }.getOrDefault(PdfStyle.MODERNE)
    fun summary(ctx: android.content.Context) = p(ctx).getBoolean("summary", true)
    fun save(ctx: android.content.Context, s: PdfStyle, summary: Boolean) { p(ctx).edit().putString("style", s.name).putBoolean("summary", summary).apply() }
}

/** PDF mis en page avec les réglages habituels (assistant vocal, sans écran). */
suspend fun quickLayoutPdf(vm: NotesViewModel, ctx: android.content.Context, notes: List<Note>): ByteArray =
    vm.layoutPdf(notes, LayoutPrefs.style(ctx), AutoLayout.Options(summary = LayoutPrefs.summary(ctx)), useAi = false).bytes

/**
 * Assistant de mise en page : la note (ou les notes choisies) devient un PDF soigné. Aperçu des pages,
 * choix de la présentation, encadré « En bref », réorganisation par l'IA (Calepin IA), puis partage,
 * enregistrement ou ajout au Bureau.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LayoutPdfSheet(vm: NotesViewModel, notes: List<Note>, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var style by remember { mutableStateOf(LayoutPrefs.style(ctx)) }
    var summary by remember { mutableStateOf(LayoutPrefs.summary(ctx)) }
    var photos by remember { mutableStateOf(true) }
    var useAi by remember { mutableStateOf(false) }
    val aiReady = remember { vm.aiReady() }
    var busy by remember { mutableStateOf(true) }
    var progress by remember { mutableStateOf("Mise en page…") }
    var bytes by remember { mutableStateOf<ByteArray?>(null) }
    var pageCount by remember { mutableIntStateOf(0) }
    var pageIndex by remember { mutableIntStateOf(0) }
    var preview by remember { mutableStateOf<Bitmap?>(null) }
    // Texte réorganisé par l'IA : gardé pour ne pas relancer l'IA à chaque changement de présentation
    var aiTexts by remember { mutableStateOf<Map<Long, String>?>(null) }
    var kept by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    val previewFile = remember { File(ctx.cacheDir, "mise_en_page_apercu.pdf") }
    val name = remember(notes) { Exporters.fileName(notes, ExportFormat.PDF) }

    val saver = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { res ->
        val uri = res.data?.data
        val b = bytes
        if (res.resultCode == Activity.RESULT_OK && uri != null && b != null) {
            val ok = Files.write(ctx, uri, b)
            fr.jeremy.calepin.i18n.I18n.toast(ctx, if (ok) "PDF enregistré" else "Impossible d'écrire le fichier", Toast.LENGTH_SHORT).show()
        }
    }

    // Nouvelle mise en page à chaque changement de réglage
    LaunchedEffect(style, summary, photos, useAi) {
        delay(200)
        busy = true
        error = null
        LayoutPrefs.save(ctx, style, summary)
        val opts = AutoLayout.Options(summary = summary, photos = photos)
        val cache = aiTexts
        val r = runCatching {
            if (useAi && cache == null) {
                vm.layoutPdf(notes, style, opts, useAi = true) { progress = it }.also { res ->
                    aiTexts = res.aiTexts
                    if (res.aiTexts.isEmpty()) error = "L'IA n'a pas pu mettre en page la note" + (res.aiError?.let { " ($it)" } ?: "") + ". Mise en page automatique sans IA."
                }
            } else {
                progress = "Mise en page…"
                val list = if (useAi && cache != null) notes.map { n -> cache[n.id]?.let { n.copy(content = it) } ?: n } else notes
                vm.layoutPdf(list, style, opts, useAi = false)
            }
        }
        val b = r.getOrNull()?.bytes
        if (b == null) {
            error = "La mise en page a échoué : " + (r.exceptionOrNull()?.message ?: "erreur inconnue")
            busy = false
            return@LaunchedEffect
        }
        bytes = b
        val (n, bm) = withContext(Dispatchers.IO) {
            previewFile.writeBytes(b)
            renderPage(previewFile, pageIndex)
        }
        pageCount = n
        if (pageIndex >= n) pageIndex = 0
        preview = bm
        busy = false
    }
    LaunchedEffect(pageIndex) {
        if (bytes == null || busy) return@LaunchedEffect
        preview = withContext(Dispatchers.IO) { renderPage(previewFile, pageIndex).second }
    }

    ModalBottomSheet(onDismissRequest = onDismiss, sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)) {
        Column(
            Modifier
                .padding(horizontal = 20.dp)
                .padding(bottom = 28.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.AutoAwesome, null, tint = MaterialTheme.colorScheme.primary)
                Text(
                    if (notes.size == 1) "  Mise en page PDF" else "  Mise en page de ${notes.size} notes",
                    style = MaterialTheme.typography.titleLarge,
                )
            }
            Text(
                "L'assistant range la note tout seul : titres, listes, cases à cocher, tableaux, photos, et un encadré avec les dates, numéros et adresses.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )

            // Aperçu de la page
            Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                Surface(
                    shape = MaterialTheme.shapes.small,
                    shadowElevation = 4.dp,
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                    modifier = Modifier.widthIn(max = 340.dp).fillMaxWidth().aspectRatio(595f / 842f),
                ) {
                    Box(Modifier.background(androidx.compose.ui.graphics.Color.White), contentAlignment = Alignment.Center) {
                        preview?.let { Image(it.asImageBitmap(), "Aperçu de la page ${pageIndex + 1}", contentScale = ContentScale.Fit, modifier = Modifier.fillMaxWidth()) }
                        if (busy) {
                            Column(
                                Modifier.background(androidx.compose.ui.graphics.Color.White.copy(alpha = 0.8f)).padding(16.dp),
                                horizontalAlignment = Alignment.CenterHorizontally,
                            ) {
                                CircularProgressIndicator(Modifier.size(28.dp))
                                Text(progress, style = MaterialTheme.typography.bodySmall, color = androidx.compose.ui.graphics.Color.DarkGray, modifier = Modifier.padding(top = 8.dp))
                            }
                        }
                    }
                }
            }
            if (pageCount > 1) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = { if (pageIndex > 0) pageIndex-- }, enabled = pageIndex > 0 && !busy) { Icon(Icons.AutoMirrored.Filled.KeyboardArrowLeft, "Page précédente") }
                    RawText("Page ${pageIndex + 1} / $pageCount", style = MaterialTheme.typography.bodyMedium)
                    IconButton(onClick = { if (pageIndex < pageCount - 1) pageIndex++ }, enabled = pageIndex < pageCount - 1 && !busy) { Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, "Page suivante") }
                }
            }
            error?.let { Text(it, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error) }

            // Présentation
            Text("Présentation", style = MaterialTheme.typography.titleSmall)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                PdfStyle.entries.forEach { s ->
                    FilterChip(selected = style == s, onClick = { style = s }, label = { Text(s.label) }, enabled = !busy)
                }
            }
            Text(style.hint, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)

            OptionRow("Encadré « En bref »", "Dates, numéros, adresses et liens de la note, en haut", summary, !busy) { summary = it }
            OptionRow("Photos", "Les photos à leur place, avec le texte à côté", photos, !busy) { photos = it }
            if (BuildConfig.AI) {
                OptionRow(
                    "Réorganiser avec l'IA",
                    if (aiReady) "L'IA regroupe le texte en sections, corrige les fautes, sans rien inventer (hors ligne)"
                    else "Installe d'abord un modèle d'IA (Paramètres → Intelligence artificielle)",
                    useAi, !busy && aiReady,
                ) { useAi = it }
                val ai = aiTexts
                if (useAi && ai != null && notes.size == 1 && ai.isNotEmpty() && !kept) {
                    TextButton(onClick = {
                        ai.forEach { (id, t) -> vm.keepAiLayout(id, t) }
                        kept = true
                        fr.jeremy.calepin.i18n.I18n.toast(ctx, "Texte de la note remplacé (l'ancien est dans « Versions précédentes »)", Toast.LENGTH_LONG).show()
                    }) { Text("Garder ce texte réorganisé dans la note") }
                }
            }

            // Actions
            Row(Modifier.fillMaxWidth().padding(top = 6.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(
                    onClick = { bytes?.let { LockGuard.external(); Files.shareBytes(ctx, it, name, "application/pdf") } },
                    enabled = !busy && bytes != null, modifier = Modifier.weight(1f),
                ) {
                    Icon(Icons.Filled.Share, null, Modifier.size(18.dp)); Text(" Partager")
                }
                OutlinedButton(
                    onClick = { LockGuard.external(); saver.launch(Files.createDocumentIntent(name, "application/pdf")) },
                    enabled = !busy && bytes != null, modifier = Modifier.weight(1f),
                ) {
                    Icon(Icons.Filled.SaveAlt, null, Modifier.size(18.dp)); Text(" Enregistrer")
                }
            }
            Button(
                onClick = {
                    val b = bytes ?: return@Button
                    scope.launch {
                        val e = runCatching { fr.jeremy.calepin.office.PdfLibrary.get(ctx).addBytes(b, name.removeSuffix(".pdf")) }.getOrNull()
                        if (e == null) {
                            fr.jeremy.calepin.i18n.I18n.toast(ctx, "Impossible d'ajouter le PDF au Bureau", Toast.LENGTH_SHORT).show()
                        } else {
                            fr.jeremy.calepin.i18n.I18n.toast(ctx, "PDF ajouté au Bureau", Toast.LENGTH_SHORT).show()
                            onDismiss()
                            vm.navigation.value = "pdf:" + e.id
                        }
                    }
                },
                enabled = !busy && bytes != null,
                modifier = Modifier.fillMaxWidth(),
            ) {
                Icon(Icons.Filled.Business, null, Modifier.size(18.dp)); Text("  Ajouter au Bureau et ouvrir")
            }
        }
    }
}

@Composable
private fun OptionRow(title: String, sub: String, checked: Boolean, enabled: Boolean, onChange: (Boolean) -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.bodyLarge)
            Text(sub, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Switch(checked = checked, onCheckedChange = onChange, enabled = enabled)
    }
}

/** Nombre de pages et image de la page [index] (fond blanc). */
private fun renderPage(f: File, index: Int): Pair<Int, Bitmap?> = runCatching {
    ParcelFileDescriptor.open(f, ParcelFileDescriptor.MODE_READ_ONLY).use { fd ->
        PdfRenderer(fd).use { r ->
            val n = r.pageCount
            if (n == 0) return@use 0 to null
            r.openPage(index.coerceIn(0, n - 1)).use { p ->
                val wpx = 900
                val bm = Bitmap.createBitmap(wpx, (wpx * p.height / p.width.toFloat()).toInt(), Bitmap.Config.ARGB_8888)
                bm.eraseColor(Color.WHITE)
                p.render(bm, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                n to bm
            }
        }
    }
}.getOrDefault(0 to null)
