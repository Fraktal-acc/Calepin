package fr.jeremy.calepin.control

import android.content.Context
import android.net.wifi.WifiManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.Socket
import java.net.SocketTimeoutException

/** Un appareil trouvé sur le Wi-Fi. [kind] null : appareil vu mais pas (encore) pilotable par Calepin IA. */
data class FoundDevice(val host: String, val kind: Kind?, val label: String, val details: String = "")

/**
 * Recherche des appareils de la maison : annonces UPnP/SSDP (télés, box, Hue…), annonces Yeelight,
 * puis tour rapide des adresses du réseau sur les ports des télécommandes réseau connues.
 */
object Discovery {

    private val PORTS = listOf(80, 8080, 6466, 8001, 3000, 3001, 8060, 8123, 55443)

    private data class Ssdp(val host: String, val server: String, val location: String, var name: String = "", var maker: String = "", var model: String = "")

    suspend fun scan(ctx: Context, onProgress: (Int, String) -> Unit): List<FoundDevice> = withContext(Dispatchers.IO) {
        val ip = LanScanner.localIp() ?: return@withContext emptyList()
        val prefix = ip.substringBeforeLast('.')
        val wifi = ctx.applicationContext.getSystemService(Context.WIFI_SERVICE) as? WifiManager
        val lock = runCatching { wifi?.createMulticastLock("calepin-ia")?.apply { setReferenceCounted(false); acquire() } }.getOrNull()
        try {
            onProgress(2, "Écoute des annonces des appareils…")
            val ssdp = ssdpSearch()
            val yeelights = yeelightSearch()
            onProgress(10, "Lecture des descriptions…")
            ssdp.values.take(40).forEach { s -> describe(s) }

            // Tour des adresses : ports ouverts par adresse
            val gate = Semaphore(64)
            var done = 0
            val open: Map<String, List<Int>> = coroutineScope {
                (1..254).map { i ->
                    async {
                        gate.withPermit {
                            val host = "$prefix.$i"
                            val ports = if (host == ip) emptyList() else PORTS.filter { p -> isOpen(host, p) }
                            synchronized(this@Discovery) {
                                done++
                                if (done % 16 == 0) onProgress(10 + done * 70 / 254, "Recherche sur le réseau… $done/254")
                            }
                            host to ports
                        }
                    }
                }.awaitAll().filter { it.second.isNotEmpty() }.toMap()
            }

            onProgress(82, "Identification des appareils…")
            val hosts = (open.keys + ssdp.keys + yeelights).distinct()
            val found = hosts.mapNotNull { host -> identify(host, open[host].orEmpty(), ssdp[host], host in yeelights) }
            onProgress(100, "Terminé")
            found.sortedWith(compareBy({ it.kind == null }, { it.label.lowercase() }))
        } finally {
            runCatching { lock?.release() }
        }
    }

    private fun isOpen(host: String, port: Int): Boolean = try {
        Socket().use { it.connect(InetSocketAddress(host, port), 250); true }
    } catch (e: Exception) {
        false
    }

    private fun ssdpSearch(): Map<String, Ssdp> {
        val out = linkedMapOf<String, Ssdp>()
        runCatching {
            DatagramSocket().use { s ->
                s.soTimeout = 400
                val msg = "M-SEARCH * HTTP/1.1\r\nHOST: 239.255.255.250:1900\r\nMAN: \"ssdp:discover\"\r\nMX: 2\r\nST: ssdp:all\r\n\r\n".toByteArray()
                val group = InetAddress.getByName("239.255.255.250")
                repeat(2) { s.send(DatagramPacket(msg, msg.size, group, 1900)) }
                val buf = ByteArray(4096)
                val end = System.currentTimeMillis() + 3000
                while (System.currentTimeMillis() < end) {
                    val p = DatagramPacket(buf, buf.size)
                    try {
                        s.receive(p)
                    } catch (e: SocketTimeoutException) {
                        continue
                    }
                    val text = String(p.data, 0, p.length)
                    val headers = text.lines().mapNotNull { l -> l.indexOf(':').takeIf { it > 0 }?.let { l.substring(0, it).trim().lowercase() to l.substring(it + 1).trim() } }.toMap()
                    val host = p.address.hostAddress ?: continue
                    val existing = out[host]
                    val location = headers["location"].orEmpty()
                    if (existing == null || (existing.location.isBlank() && location.isNotBlank())) {
                        out[host] = Ssdp(host, headers["server"].orEmpty(), location)
                    }
                }
            }
        }
        return out
    }

    private fun yeelightSearch(): Set<String> {
        val out = mutableSetOf<String>()
        runCatching {
            DatagramSocket().use { s ->
                s.soTimeout = 400
                val msg = "M-SEARCH * HTTP/1.1\r\nHOST: 239.255.255.250:1982\r\nMAN: \"ssdp:discover\"\r\nST: wifi_bulb\r\n".toByteArray()
                s.send(DatagramPacket(msg, msg.size, InetAddress.getByName("239.255.255.250"), 1982))
                val buf = ByteArray(2048)
                val end = System.currentTimeMillis() + 1500
                while (System.currentTimeMillis() < end) {
                    val p = DatagramPacket(buf, buf.size)
                    try {
                        s.receive(p)
                    } catch (e: SocketTimeoutException) {
                        continue
                    }
                    if (String(p.data, 0, p.length).contains("yeelight", true)) p.address.hostAddress?.let { out += it }
                }
            }
        }
        return out
    }

    /** Nom, fabricant et modèle lus dans la description UPnP de l'appareil. */
    private fun describe(s: Ssdp) {
        if (s.location.isBlank()) return
        val xml = Http.get(s.location, 2500, 800) ?: return
        fun tag(t: String) = Regex("<$t>([^<]{1,80})</$t>").find(xml)?.groupValues?.get(1)?.trim().orEmpty()
        s.name = tag("friendlyName")
        s.maker = tag("manufacturer")
        s.model = tag("modelName")
    }

    private fun identify(host: String, ports: List<Int>, s: Ssdp?, yeelight: Boolean): FoundDevice? {
        val upnp = listOf(s?.name, s?.maker, s?.model).filter { !it.isNullOrBlank() }.joinToString(" · ")
        val text = (upnp + " " + s?.server.orEmpty()).lowercase()
        fun found(kind: Kind?, label: String) = FoundDevice(host, kind, label.ifBlank { kind?.label ?: "Appareil" }, upnp.ifBlank { s?.server.orEmpty() })
        val name = s?.name.orEmpty()

        if (8080 in ports && OrangeDecoder.probe(host)) return found(Kind.ORANGE, "Décodeur TV d'Orange")
        if (6466 in ports) return found(Kind.ANDROID_TV, name.ifBlank { "Android TV / Google TV" })
        if (80 in ports && BraviaTv.probe(host)) return found(Kind.BRAVIA, name.ifBlank { "Téléviseur Sony" })
        if (8001 in ports && SamsungTv.probe(host)) return found(Kind.SAMSUNG, name.ifBlank { "Téléviseur Samsung" })
        if ((3000 in ports || 3001 in ports) && ("webos" in text || "lg" in text)) return found(Kind.LG, name.ifBlank { "Téléviseur LG" })
        if (8060 in ports && RokuTv.probe(host)) return found(Kind.ROKU, name.ifBlank { "Roku" })
        if ("freebox player" in text || ("freebox" in text && "player" in text)) return found(Kind.FREEBOX_PLAYER, name.ifBlank { "Freebox Player" })
        if (yeelight || 55443 in ports) return found(Kind.YEELIGHT, "Ampoule Yeelight")
        if (8123 in ports && SmartHome.haProbe(host)) return found(Kind.HOME_ASSISTANT, "Home Assistant")
        if (80 in ports) {
            if (SmartHome.hueProbe(host)) return found(Kind.HUE, name.ifBlank { "Pont Philips Hue" })
            if (SmartHome.shellyProbe(host)) return found(Kind.SHELLY, name.ifBlank { "Shelly" })
            if (SmartHome.wledProbe(host)) return found(Kind.WLED, name.ifBlank { "WLED" })
            if (SmartHome.tasmotaProbe(host)) return found(Kind.TASMOTA, name.ifBlank { "Tasmota" })
        }
        if ((3000 in ports || 3001 in ports) && s == null) return found(Kind.LG, "Téléviseur LG ?")
        // Vu, mais pas pilotable : box, imprimante, enceinte… On l'affiche si on connaît au moins un nom.
        val dns = runCatching { InetAddress.getByName(host).canonicalHostName }.getOrNull()?.takeIf { it != host }
        val label = name.ifBlank { dns?.substringBefore('.').orEmpty() }
        return if (label.isBlank() && upnp.isBlank()) null else found(null, label.ifBlank { "Appareil" })
    }
}
