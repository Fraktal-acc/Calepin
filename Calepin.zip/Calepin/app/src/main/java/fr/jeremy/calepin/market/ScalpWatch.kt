package fr.jeremy.calepin.market

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Build
import android.os.IBinder
import android.os.VibrationEffect
import android.os.Vibrator
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import org.json.JSONObject
import java.util.Locale

/** Position prise depuis l'assistant de scalping (suivie jusqu'à la sortie). */
data class ScalpPosition(
    val symbol: String,
    val name: String,
    val side: ScalpSide,
    val entry: Double,
    val stop: Double,
    val target1: Double,
    val target2: Double,
    val time: Long,
    /** Ouverte aussi dans le portefeuille de simulation. */
    val simulated: Boolean = false,
)

/**
 * Scalping en direct : instrument regardé, instruments surveillés, bougies d'une minute tenues à jour,
 * dernier signal de chacun, position suivie, alertes (son, vibration, notification) et surveillance en
 * arrière-plan (service au premier plan, une vérification toutes les 15 secondes).
 */
object ScalpWatch {
    private const val PREFS = "market_scalp"
    private const val CHANNEL = "calepin_scalping"
    const val MAX_WATCH = 6

    private val _focus = MutableStateFlow("")
    /** Instrument affiché dans l'assistant. */
    val focus: StateFlow<String> = _focus
    private val _watched = MutableStateFlow<Set<String>>(emptySet())
    /** Instruments surveillés (alertes). */
    val watched: StateFlow<Set<String>> = _watched
    private val _signals = MutableStateFlow<Map<String, ScalpSignal>>(emptyMap())
    val signals: StateFlow<Map<String, ScalpSignal>> = _signals
    private val _series = MutableStateFlow<Map<String, Series>>(emptyMap())
    /** Bougies d'une minute de chaque instrument suivi. */
    val series: StateFlow<Map<String, Series>> = _series
    private val _position = MutableStateFlow<ScalpPosition?>(null)
    val position: StateFlow<ScalpPosition?> = _position
    private val _sound = MutableStateFlow(true)
    /** Son et vibration quand un signal « entrer » apparaît. */
    val sound: StateFlow<Boolean> = _sound
    private val _background = MutableStateFlow(false)
    /** Surveillance quand l'appli est fermée. */
    val background: StateFlow<Boolean> = _background
    private val _errors = MutableStateFlow<Map<String, String>>(emptyMap())
    val errors: StateFlow<Map<String, String>> = _errors

    @Volatile private var loaded = false
    /** Signaux déjà annoncés (instrument, bougie, sens) : pas deux alertes pour le même. */
    private val announced = HashSet<String>()
    private var lastAdvice = ""

    private fun p(ctx: Context) = ctx.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun init(ctx: Context) {
        if (loaded) return
        synchronized(this) {
            if (loaded) return
            val p = p(ctx)
            _focus.value = p.getString("focus", "").orEmpty()
            _watched.value = p.getString("watched", "").orEmpty().split(',').filter { it.isNotBlank() }.toSet()
            _sound.value = p.getBoolean("sound", true)
            _background.value = p.getBoolean("background", false)
            _position.value = p.getString("position", null)?.let { runCatching { posFrom(JSONObject(it)) }.getOrNull() }
            loaded = true
        }
    }

    fun setFocus(ctx: Context, symbol: String) {
        _focus.value = symbol
        p(ctx).edit().putString("focus", symbol).apply()
    }

    fun toggleWatch(ctx: Context, symbol: String): Boolean {
        val cur = _watched.value
        val next = if (symbol in cur) cur - symbol else if (cur.size >= MAX_WATCH) return false else cur + symbol
        _watched.value = next
        p(ctx).edit().putString("watched", next.joinToString(",")).apply()
        return true
    }

    fun setSound(ctx: Context, on: Boolean) {
        _sound.value = on
        p(ctx).edit().putBoolean("sound", on).apply()
    }

    fun setBackground(ctx: Context, on: Boolean) {
        _background.value = on
        p(ctx).edit().putBoolean("background", on).apply()
        val i = Intent(ctx, ScalpWatchService::class.java)
        if (on) runCatching { ContextCompat.startForegroundService(ctx, i) } else ctx.stopService(i)
    }

    /** Relance la surveillance après un redémarrage de l'appli, si elle était demandée. */
    fun resume(ctx: Context) {
        init(ctx)
        if (_background.value && symbolsToCheck().isNotEmpty()) runCatching { ContextCompat.startForegroundService(ctx, Intent(ctx, ScalpWatchService::class.java)) }
    }

    fun enter(ctx: Context, pos: ScalpPosition) {
        _position.value = pos
        lastAdvice = ""
        p(ctx).edit().putString("position", posJson(pos).toString()).apply()
    }

    fun exit(ctx: Context) {
        _position.value = null
        lastAdvice = ""
        p(ctx).edit().remove("position").apply()
    }

    /** Instruments à vérifier : surveillés, regardé et celui de la position en cours. */
    fun symbolsToCheck(): Set<String> = buildSet {
        addAll(_watched.value)
        _focus.value.takeIf { it.isNotBlank() }?.let { add(it) }
        _position.value?.symbol?.let { add(it) }
    }

    /** Bougies d'une minute à jour (historique chargé une fois, puis seulement les dernières). */
    suspend fun refresh(symbol: String): Series? {
        val cur = _series.value[symbol]
        val s = runCatching {
            if (cur == null || cur.candles.size < Scalper.MIN_CANDLES) MarketData.series(symbol, Timeframe.M1)
            else MarketData.merge(cur, MarketData.latest(symbol, Timeframe.M1), Timeframe.M1)
        }.onFailure { e -> _errors.value = _errors.value + (symbol to (e.message ?: "erreur")) }.getOrNull() ?: return cur
        _errors.value = _errors.value - symbol
        _series.value = _series.value + (symbol to s)
        val sig = Scalper.analyze(s.candles, System.currentTimeMillis() / 1000, s.price)
        _signals.value = if (sig == null) _signals.value - symbol else _signals.value + (symbol to sig)
        return s
    }

    /**
     * Vérifie [symbols] et prévient des nouveaux signaux « entrer » (et des conseils de sortie de la position).
     * [notify] : notification Android en plus du son et de la vibration.
     */
    suspend fun checkAll(ctx: Context, symbols: Collection<String>, notify: Boolean) {
        init(ctx)
        Market.init(ctx)
        val names = Market.watch.value.associate { it.symbol to it.name }
        for (sym in symbols) {
            val s = refresh(sym) ?: continue
            val sig = _signals.value[sym] ?: continue
            val name = names[sym] ?: s.name
            if (sig.state == ScalpState.ENTER && sig.side != null) {
                val key = sym + "|" + sig.candleTime + "|" + sig.side
                val fresh = synchronized(announced) { announced.add(key) }
                if (fresh) alert(ctx, sym, name, sig, notify)
            }
            val pos = _position.value
            if (pos != null && pos.symbol == sym) {
                val adv = Scalper.follow(pos.side, pos.entry, pos.stop, pos.target1, pos.target2, s.price, sig)
                if (adv.text != lastAdvice && (adv.exit || adv.reachedT1)) {
                    lastAdvice = adv.text
                    if (_sound.value) beep(ctx, adv.exit)
                    if (notify) post(ctx, ("$name : " + adv.text), String.format(Locale.FRANCE, "%+.2f %% · %+.1f R", adv.pnlPct, adv.r), sym.hashCode() + 1)
                }
            }
        }
    }

    private fun price(x: Double): String = String.format(Locale.FRANCE, if (kotlin.math.abs(x) < 20) "%.4f" else "%.2f", x)

    private fun alert(ctx: Context, sym: String, name: String, sig: ScalpSignal, notify: Boolean) {
        if (_sound.value) beep(ctx, false)
        if (!notify) return
        val head = if (sig.side == ScalpSide.LONG) "ACHETER" else "VENDRE À DÉCOUVERT"
        val body = "Entrée " + price(sig.entry) + " · stop " + price(sig.stop) + " · objectif " + price(sig.target1) +
            " (gain/risque " + String.format(Locale.FRANCE, "%.1f", sig.rr) + ")" +
            (sig.setups.firstOrNull()?.let { "\n$it" } ?: "")
        post(ctx, "$head · $name ($sym)", body, (sym + sig.candleTime).hashCode())
    }

    private fun channel(ctx: Context) {
        val nm = ctx.getSystemService(NotificationManager::class.java) ?: return
        if (nm.getNotificationChannel(CHANNEL) == null) {
            nm.createNotificationChannel(NotificationChannel(CHANNEL, "Bourse : scalping", NotificationManager.IMPORTANCE_HIGH))
        }
    }

    private fun post(ctx: Context, title: String, body: String, id: Int) {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) return
        channel(ctx)
        val n = NotificationCompat.Builder(ctx, CHANNEL)
            .setSmallIcon(fr.jeremy.calepin.R.drawable.ic_notification)
            .setContentTitle(title)
            .setContentText(body.lineSequence().first())
            .setStyle(NotificationCompat.BigTextStyle().bigText(body))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setContentIntent(fr.jeremy.calepin.widgets.Widgets.open(ctx, "market", 7320))
            .setAutoCancel(true)
            .setTimeoutAfter(5 * 60_000L)
            .build()
        runCatching { NotificationManagerCompat.from(ctx).notify(id, n) }
    }

    /** Bip et vibration (deux bips pour une sortie). */
    fun beep(ctx: Context, exit: Boolean) {
        runCatching {
            val tg = ToneGenerator(AudioManager.STREAM_NOTIFICATION, 90)
            tg.startTone(if (exit) ToneGenerator.TONE_PROP_BEEP2 else ToneGenerator.TONE_PROP_ACK, 400)
            android.os.Handler(android.os.Looper.getMainLooper()).postDelayed({ tg.release() }, 800)
        }
        runCatching {
            val v = ctx.getSystemService(Vibrator::class.java)
            v?.vibrate(VibrationEffect.createWaveform(if (exit) longArrayOf(0, 120, 120, 120, 120, 300) else longArrayOf(0, 250, 100, 250), -1))
        }
    }

    /** Notification permanente de la surveillance. */
    internal fun foregroundNotification(ctx: Context): android.app.Notification {
        channel(ctx)
        val n = symbolsToCheck().size
        return NotificationCompat.Builder(ctx, CHANNEL)
            .setSmallIcon(fr.jeremy.calepin.R.drawable.ic_notification)
            .setContentTitle("Scalping : surveillance en cours")
            .setContentText("$n instrument(s) vérifié(s) toutes les 15 secondes")
            .setOngoing(true)
            .setSilent(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setContentIntent(fr.jeremy.calepin.widgets.Widgets.open(ctx, "market", 7321))
            .build()
    }

    private fun posJson(x: ScalpPosition) = JSONObject().put("s", x.symbol).put("n", x.name).put("side", x.side.name).put("e", x.entry)
        .put("st", x.stop).put("t1", x.target1).put("t2", x.target2).put("t", x.time).put("sim", x.simulated)

    private fun posFrom(o: JSONObject) = ScalpPosition(
        o.optString("s"), o.optString("n"), ScalpSide.valueOf(o.optString("side", "LONG")), o.optDouble("e"),
        o.optDouble("st"), o.optDouble("t1"), o.optDouble("t2"), o.optLong("t"), o.optBoolean("sim"),
    )
}

/** Surveillance de scalping quand l'appli est fermée : une vérification toutes les 15 secondes. */
class ScalpWatchService : Service() {
    private var scope: CoroutineScope? = null
    private var job: Job? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        ScalpWatch.init(this)
        val type = if (Build.VERSION.SDK_INT >= 29) ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC else 0
        runCatching { ServiceCompat.startForeground(this, 7322, ScalpWatch.foregroundNotification(this), type) }
            .onFailure { stopSelf(); return START_NOT_STICKY }
        if (job?.isActive != true) {
            val sc = CoroutineScope(SupervisorJob() + Dispatchers.IO)
            scope = sc
            job = sc.launch {
                while (isActive) {
                    val syms = ScalpWatch.symbolsToCheck()
                    if (!ScalpWatch.background.value || syms.isEmpty()) break
                    runCatching { ScalpWatch.checkAll(applicationContext, syms, notify = true) }
                    delay(15_000L)
                }
                stopSelf()
            }
        }
        return START_STICKY
    }

    override fun onDestroy() {
        scope?.cancel()
        super.onDestroy()
    }

    // Android 15 : temps limité pour ce type de service ; on s'arrête proprement
    override fun onTimeout(startId: Int, fgsType: Int) {
        stopSelf()
    }
}
