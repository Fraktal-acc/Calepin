package fr.jeremy.calepin.market

import java.util.Locale
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/** Un élément de l'analyse : sa note (-1 vente … +1 achat), son poids, et ce qui a été vu. */
data class Factor(val name: String, val value: Double, val weight: Double, val detail: String)

/** Niveau de prix remarquable (Fibonacci, support, résistance). */
data class Level(val price: Double, val label: String)

/** Plan proposé : entrée, stop, objectifs, rapport gain / risque. */
data class TradePlan(val buy: Boolean, val entry: Double, val stop: Double, val target1: Double, val target2: Double) {
    val risk: Double get() = abs(entry - stop)
    val rr: Double get() = if (risk > 0) abs(target1 - entry) / risk else 0.0
}

/** Ce qu'auraient donné les signaux de l'analyse dans le passé de cet instrument. */
data class Backtest(val trades: Int, val wins: Int, val avgR: Double) {
    val winRate: Double get() = if (trades > 0) wins * 100.0 / trades else Double.NaN
}

/** Résultat complet. [score] de -100 (vente forte) à +100 (achat fort). */
data class AnalysisResult(
    val score: Double,
    val factors: List<Factor>,
    val fib: List<Level>,
    val supports: List<Level>,
    val resistances: List<Level>,
    val plan: TradePlan?,
    val backtest: Backtest?,
    val atr: Double,
    val adx: Double,
) {
    /** Confiance (0-100) : force du signal, corrigée par sa réussite passée sur cet instrument. */
    val confidence: Double
        get() {
            val base = min(100.0, abs(score) * 1.25)
            val bt = backtest
            if (bt == null || bt.trades < 8 || bt.winRate.isNaN()) return base * 0.8
            // Taux de réussite de 40 % (seuil de rentabilité pour un gain 1,5 fois le risque) = neutre
            val adj = (bt.winRate - 40.0) * 1.2
            return (base + adj).coerceIn(0.0, 100.0)
        }

    val verdict: String
        get() = when {
            plan == null && abs(score) >= 35 -> "Signal sans plan rentable : attendre"
            score >= 60 -> "Achat fort"
            score >= 35 -> "Achat"
            score <= -60 -> "Vente forte"
            score <= -35 -> "Vente"
            else -> "Neutre : attendre"
        }
}

/**
 * Analyse technique combinée : tendance (moyennes, ADX), élan (RSI, MACD, stochastique), excès (Bollinger),
 * Fibonacci, supports et résistances, volume, figures de bougies, et tendance de l'unité de temps supérieure.
 * Chaque élément donne une note pondérée ; la somme donne un score, un plan (entrée, stop, objectifs)
 * et un contrôle sur l'historique de l'instrument (combien de fois ces signaux ont marché).
 */
class Analyzer(private val c: List<Candle>) {
    private val n = c.size
    private val close = c.map { it.c }
    private val ema20 = Indicators.ema(close, 20)
    private val ema50 = Indicators.ema(close, 50)
    private val sma200 = Indicators.sma(close, 200)
    private val rsi = Indicators.rsi(close, 14)
    private val macd = Indicators.macd(close)
    private val boll = Indicators.bollinger(close, 20, 2.0)
    private val stochK = Indicators.stochastic(c, 14)
    private val stochD = Indicators.sma(stochK.map { if (it.isNaN()) 50.0 else it }, 3)
    private val atr = Indicators.atr(c, 14)
    private val adx = Indicators.adx(c, 14)
    private val obv = Indicators.obv(c)
    private val volAvg = Indicators.sma(c.map { it.v }, 20)
    private val swingK = 3

    private fun f(x: Double, d: Int = 2) = String.format(Locale.FRANCE, "%.${d}f", x)

    /** Point haut confirmé en [i] (le plus haut des [swingK] bougies de chaque côté), connu à partir de i + swingK. */
    private fun isSwingHigh(i: Int) = i - swingK >= 0 && i + swingK < n && (i - swingK..i + swingK).all { c[it].h <= c[i].h }
    private fun isSwingLow(i: Int) = i - swingK >= 0 && i + swingK < n && (i - swingK..i + swingK).all { c[it].l >= c[i].l }

    /** Supports et résistances connus à la bougie [i] (sans regarder l'avenir). */
    private fun levelsAt(i: Int, lookback: Int = 120): Pair<List<Double>, List<Double>> {
        val lows = ArrayList<Double>()
        val highs = ArrayList<Double>()
        val from = max(swingK, i - lookback)
        for (k in from..(i - swingK)) {
            if (isSwingLow(k)) lows += c[k].l
            if (isSwingHigh(k)) highs += c[k].h
        }
        return lows to highs
    }

    /** Fibonacci sur le dernier grand mouvement (jusqu'à [i]) : (niveaux, mouvement haussier ?). */
    private fun fibAt(i: Int, lookback: Int = 120): Pair<List<Level>, Boolean>? {
        val from = max(0, i - lookback + 1)
        if (i - from < 20) return null
        var hiIdx = from; var loIdx = from
        for (k in from..i) {
            if (c[k].h > c[hiIdx].h) hiIdx = k
            if (c[k].l < c[loIdx].l) loIdx = k
        }
        val hi = c[hiIdx].h
        val lo = c[loIdx].l
        val range = hi - lo
        if (range <= 0) return null
        val up = loIdx < hiIdx
        val ratios = listOf(0.0, 0.236, 0.382, 0.5, 0.618, 0.786, 1.0)
        val levels = ratios.map { r ->
            val p = if (up) hi - range * r else lo + range * r
            Level(p, "Fibo " + f(r * 100, 1).removeSuffix(",0") + " %")
        }.toMutableList()
        // Extensions (objectifs au-delà du mouvement)
        listOf(1.272, 1.618).forEach { r ->
            val p = if (up) lo + range * r else hi - range * r
            levels += Level(p, "Extension " + f(r * 100, 1).removeSuffix(",0") + " %")
        }
        return levels to up
    }

    private fun v(x: List<Double>, i: Int) = if (i in x.indices) x[i] else Double.NaN

    /** Notes de chaque élément à la bougie [i]. [full] : avec les textes (sinon calcul rapide pour le contrôle historique). */
    fun factorsAt(i: Int, htf: List<Candle>? = null): List<Factor> {
        val out = ArrayList<Factor>()
        val cl = close[i]
        val a = v(atr, i).takeIf { !it.isNaN() && it > 0 } ?: return out
        val adxV = v(adx, i)
        val trending = !adxV.isNaN() && adxV >= 25
        val ranging = !adxV.isNaN() && adxV < 20
        val trendW = when { trending -> 26.0; ranging -> 12.0; else -> 20.0 }
        val revW = when { trending -> 0.7; ranging -> 1.3; else -> 1.0 }

        // 1. Tendance (moyennes)
        val e20 = v(ema20, i); val e50 = v(ema50, i); val s200 = v(sma200, i)
        if (!e50.isNaN() && !e20.isNaN()) {
            var t = 0.0
            t += if (cl > e50) 0.35 else -0.35
            t += if (e20 > e50) 0.35 else -0.35
            if (!s200.isNaN()) t += if (cl > s200) 0.3 else -0.3
            val slope = if (i >= 5 && !v(ema50, i - 5).isNaN()) (e50 - ema50[i - 5]) / a else 0.0
            val txt = buildString {
                append(if (t > 0.2) "Tendance haussière" else if (t < -0.2) "Tendance baissière" else "Tendance hésitante")
                append(" (cours ").append(if (cl > e50) "au-dessus" else "en dessous").append(" de la MME 50")
                if (!s200.isNaN()) append(", ").append(if (cl > s200) "au-dessus" else "en dessous").append(" de la MM 200")
                append(")")
                if (!adxV.isNaN()) append(" · ADX ").append(f(adxV, 0)).append(if (trending) " : tendance forte" else if (ranging) " : pas de vraie tendance" else "")
            }
            out += Factor("Tendance", (t + slope.coerceIn(-1.0, 1.0) * 0.15).coerceIn(-1.0, 1.0), trendW, txt)
        }

        // 2. RSI (excès et divergences)
        val r = v(rsi, i)
        if (!r.isNaN()) {
            var x = when {
                r < 30 -> ((30 - r) / 12 + 0.4).coerceAtMost(1.0)
                r > 70 -> -((r - 70) / 12 + 0.4).coerceAtMost(1.0)
                else -> (r - 50) / 50 * 0.4
            }
            var txt = "RSI " + f(r, 1) + when { r < 30 -> " : survendu (rebond possible)"; r > 70 -> " : suracheté (repli possible)"; r >= 50 -> " : élan acheteur"; else -> " : élan vendeur" }
            divergence(i)?.let { (bull, d) -> x = if (bull) max(x, 0.8) else min(x, -0.8); txt += " · " + d }
            out += Factor("RSI", x, 15.0 * (if (r < 30 || r > 70) revW else 1.0), txt)
        }

        // 3. MACD
        val (ml, ms, mh) = macd
        val h0 = v(mh, i); val h1 = v(mh, i - 1)
        if (!h0.isNaN() && !h1.isNaN()) {
            var x = if (h0 > 0) 0.4 else -0.4
            var txt = if (h0 > 0) "MACD au-dessus de son signal" else "MACD sous son signal"
            val crossUp = (1..3).any { k -> !v(mh, i - k).isNaN() && v(mh, i - k) <= 0 && v(mh, i - k + 1) > 0 }
            val crossDn = (1..3).any { k -> !v(mh, i - k).isNaN() && v(mh, i - k) >= 0 && v(mh, i - k + 1) < 0 }
            if (crossUp) { x = 0.9; txt = "MACD vient de croiser son signal vers le haut" }
            if (crossDn) { x = -0.9; txt = "MACD vient de croiser son signal vers le bas" }
            if (!crossUp && !crossDn) {
                if (h0 > h1) { x += 0.2; txt += if (h0 > 0) ", élan acheteur qui se renforce" else ", baisse qui ralentit" }
                else { x -= 0.2; txt += if (h0 > 0) ", élan acheteur qui faiblit" else ", élan vendeur qui se renforce" }
            }
            if (v(ml, i) > 0 && x > 0) txt += " (en zone positive)"
            if (v(ml, i) < 0 && x < 0) txt += " (en zone négative)"
            out += Factor("MACD", x.coerceIn(-1.0, 1.0), 15.0, txt)
        }

        // 4. Bollinger
        val (bl, bm, bh) = boll
        val lo = v(bl, i); val hi = v(bh, i); val mid = v(bm, i)
        if (!lo.isNaN() && hi > lo) {
            val pb = (cl - lo) / (hi - lo)
            val bw = (hi - lo) / mid
            var minBw = Double.MAX_VALUE
            for (k in max(20, i - 120)..i) { val w = (v(bh, k) - v(bl, k)) / v(bm, k); if (!w.isNaN()) minBw = min(minBw, w) }
            val squeeze = bw <= minBw * 1.15
            val x = when {
                pb < 0 -> 0.8
                pb > 1 -> -0.8
                pb < 0.15 -> 0.4
                pb > 0.85 -> -0.4
                else -> 0.0
            }
            var txt = "Position dans les bandes : " + f(pb * 100, 0) + " %" + when {
                pb < 0 -> " (sous la bande basse : excès de baisse)"
                pb > 1 -> " (au-dessus de la bande haute : excès de hausse)"
                else -> ""
            }
            if (squeeze) txt += " · Bandes resserrées : un mouvement fort se prépare"
            out += Factor("Bollinger", x, 10.0 * revW, txt)
        }

        // 5. Stochastique
        val k0 = v(stochK, i); val d0 = v(stochD, i)
        if (!k0.isNaN() && !d0.isNaN()) {
            val x = when {
                k0 < 20 && k0 > d0 -> 0.8
                k0 > 80 && k0 < d0 -> -0.8
                k0 < 20 -> 0.4
                k0 > 80 -> -0.4
                else -> 0.0
            }
            val txt = "Stochastique " + f(k0, 0) + when {
                k0 < 20 && k0 > d0 -> " : survendu et qui remonte"
                k0 > 80 && k0 < d0 -> " : suracheté et qui redescend"
                k0 < 20 -> " : survendu"
                k0 > 80 -> " : suracheté"
                else -> " : neutre"
            }
            out += Factor("Stochastique", x, 8.0 * revW, txt)
        }

        // 6. Fibonacci
        fibAt(i)?.let { (levels, up) ->
            val key = levels.filter { it.label.startsWith("Fibo 38") || it.label.startsWith("Fibo 50") || it.label.startsWith("Fibo 61") }
            val near = key.minByOrNull { abs(it.price - cl) }
            if (near != null && abs(near.price - cl) <= 0.6 * a) {
                val bullCandle = c[i].c > c[i].o
                val x = if (up) (0.6 + if (bullCandle) 0.3 else 0.0) else -(0.6 + if (!bullCandle) 0.3 else 0.0)
                out += Factor("Fibonacci", x, 12.0,
                    (if (up) "Repli sur le " else "Rebond sous le ") + near.label + " (" + f(near.price) + ")" +
                        (if (up) " d'un mouvement haussier : zone d'achat classique" else " d'un mouvement baissier : zone de vente classique"))
            } else {
                out += Factor("Fibonacci", 0.0, 6.0, "Cours loin des niveaux clés de Fibonacci (38,2 – 50 – 61,8 %)")
            }
        }

        // 7. Supports et résistances, cassures
        val (sup, res) = levelsAt(i)
        val below = sup.filter { it <= cl }.maxOrNull()
        val above = res.filter { it >= cl }.minOrNull()
        var sx = 0.0
        val sTxt = ArrayList<String>()
        if (below != null && cl - below <= a) { sx += 0.6; sTxt += "proche d'un support (" + f(below) + ")" }
        if (above != null && above - cl <= a) { sx -= 0.6; sTxt += "proche d'une résistance (" + f(above) + ")" }
        if (i >= 21) {
            val prevHigh = (i - 20 until i).maxOf { c[it].h }
            val prevLow = (i - 20 until i).minOf { c[it].l }
            val va = v(volAvg, i - 1)
            val strongVol = !va.isNaN() && va > 0 && c[i].v > va * 1.3
            if (cl > prevHigh) { sx += if (strongVol) 0.9 else 0.5; sTxt += "cassure du plus haut de 20 bougies" + if (strongVol) " avec volume" else "" }
            if (cl < prevLow) { sx -= if (strongVol) 0.9 else 0.5; sTxt += "cassure du plus bas de 20 bougies" + if (strongVol) " avec volume" else "" }
        }
        out += Factor("Supports / résistances", sx.coerceIn(-1.0, 1.0), 10.0, if (sTxt.isEmpty()) "Pas de niveau proche" else sTxt.joinToString(" · ").replaceFirstChar { it.uppercase() })

        // 8. Volume (OBV)
        if (i >= 10 && c.subList(i - 10, i + 1).any { it.v > 0 }) {
            val ob = obv[i] - obv[i - 10]
            val pr = cl - close[i - 10]
            val x = when {
                ob > 0 && pr > 0 -> 0.5
                ob < 0 && pr < 0 -> -0.5
                ob > 0 && pr <= 0 -> 0.4
                ob < 0 && pr >= 0 -> -0.4
                else -> 0.0
            }
            val txt = when {
                ob > 0 && pr > 0 -> "Volumes qui confirment la hausse"
                ob < 0 && pr < 0 -> "Volumes qui confirment la baisse"
                ob > 0 -> "Acheteurs présents malgré la baisse (accumulation)"
                ob < 0 -> "Vendeurs présents malgré la hausse (distribution)"
                else -> "Volumes neutres"
            }
            out += Factor("Volume", x, 5.0, txt)
        }

        // 9. Figures de bougies
        if (i >= 1) {
            val p = c[i - 1]; val q = c[i]
            val body = abs(q.c - q.o)
            val range = (q.h - q.l).takeIf { it > 0 } ?: 1e-9
            val lowerWick = min(q.o, q.c) - q.l
            val upperWick = q.h - max(q.o, q.c)
            val (x, txt) = when {
                p.c < p.o && q.c > q.o && q.c >= p.o && q.o <= p.c -> 0.8 to "Avalement haussier (retournement à la hausse)"
                p.c > p.o && q.c < q.o && q.c <= p.o && q.o >= p.c -> -0.8 to "Avalement baissier (retournement à la baisse)"
                lowerWick > 2 * body && upperWick < body && body / range < 0.4 -> 0.6 to "Marteau (rejet des prix bas)"
                upperWick > 2 * body && lowerWick < body && body / range < 0.4 -> -0.6 to "Étoile filante (rejet des prix hauts)"
                else -> 0.0 to "Pas de figure de retournement"
            }
            out += Factor("Bougies", x, 5.0, txt)
        }

        // 10. Tendance de l'unité de temps supérieure
        if (htf != null && htf.size >= 60) {
            val hc = htf.map { it.c }
            val he20 = Indicators.ema(hc, 20).last(); val he50 = Indicators.ema(hc, 50).last()
            val hl = hc.last()
            if (!he50.isNaN()) {
                var t = 0.0
                t += if (hl > he50) 0.5 else -0.5
                t += if (he20 > he50) 0.5 else -0.5
                out += Factor("Tendance de fond", t, 15.0,
                    if (t > 0) "L'unité de temps supérieure est haussière : les achats vont dans le sens du courant"
                    else if (t < 0) "L'unité de temps supérieure est baissière : les ventes vont dans le sens du courant"
                    else "L'unité de temps supérieure est hésitante")
            }
        }
        return out
    }

    /** Divergence RSI sur les deux derniers creux (ou sommets) des 40 dernières bougies. */
    private fun divergence(i: Int): Pair<Boolean, String>? {
        val lows = ArrayList<Int>(); val highs = ArrayList<Int>()
        for (k in max(swingK, i - 40)..(i - swingK)) {
            if (isSwingLow(k)) lows += k
            if (isSwingHigh(k)) highs += k
        }
        if (lows.size >= 2) {
            val a = lows[lows.size - 2]; val b = lows.last()
            if (c[b].l < c[a].l && v(rsi, b) > v(rsi, a) + 2) return true to "divergence haussière (prix plus bas, RSI plus haut)"
        }
        if (highs.size >= 2) {
            val a = highs[highs.size - 2]; val b = highs.last()
            if (c[b].h > c[a].h && v(rsi, b) < v(rsi, a) - 2) return false to "divergence baissière (prix plus haut, RSI plus bas)"
        }
        return null
    }

    fun scoreOf(factors: List<Factor>): Double {
        val w = factors.sumOf { it.weight }
        if (w <= 0) return 0.0
        return (factors.sumOf { it.value * it.weight } / w * 100).coerceIn(-100.0, 100.0)
    }

    /** Plan pour un achat ou une vente au cours actuel : stop sous un support (ou 2 ATR), objectifs sur les résistances suivantes. */
    private fun planAt(i: Int, buy: Boolean, fib: List<Level>): TradePlan? {
        val entry = close[i]
        val a = v(atr, i).takeIf { !it.isNaN() && it > 0 } ?: return null
        val (sup, res) = levelsAt(i)
        val fibPrices = fib.map { it.price }
        return if (buy) {
            val supports = (sup + fibPrices).filter { it < entry - 0.3 * a }
            val stopBase = supports.maxOrNull()?.let { it - 0.3 * a } ?: (entry - 2 * a)
            val stop = stopBase.coerceIn(entry - 3 * a, entry - 0.8 * a)
            val risk = entry - stop
            val targets = (res + fibPrices).filter { it > entry + 0.5 * risk }.sorted()
            val t1 = targets.firstOrNull { it >= entry + risk } ?: (entry + 1.5 * risk)
            val t2 = targets.firstOrNull { it > t1 + 0.5 * a } ?: (entry + 3 * risk)
            TradePlan(true, entry, stop, t1, max(t2, t1))
        } else {
            val resist = (res + fibPrices).filter { it > entry + 0.3 * a }
            val stopBase = resist.minOrNull()?.let { it + 0.3 * a } ?: (entry + 2 * a)
            val stop = stopBase.coerceIn(entry + 0.8 * a, entry + 3 * a)
            val risk = stop - entry
            val targets = (sup + fibPrices).filter { it < entry - 0.5 * risk }.sortedDescending()
            val t1 = targets.firstOrNull { it <= entry - risk } ?: (entry - 1.5 * risk)
            val t2 = targets.firstOrNull { it < t1 - 0.5 * a } ?: (entry - 3 * risk)
            TradePlan(false, entry, stop, t1, min(t2, t1))
        }
    }

    /**
     * Contrôle sur l'historique : chaque fois que le score a dépassé [threshold] (ou -threshold), on simule
     * une position avec un stop à 1,5 ATR et un objectif à 2,25 ATR (gain 1,5 fois le risque) pendant 30 bougies.
     */
    fun backtest(threshold: Double = 35.0, horizon: Int = 30): Backtest? {
        val start = if (n > 260) 210 else 60
        if (n - start < 40) return null
        var trades = 0; var wins = 0; var sumR = 0.0
        var i = start
        while (i < n - 2) {
            val s = scoreOf(factorsAt(i))
            val a = v(atr, i)
            if (abs(s) >= threshold && !a.isNaN() && a > 0) {
                val buy = s > 0
                val entry = close[i]
                val stop = if (buy) entry - 1.5 * a else entry + 1.5 * a
                val target = if (buy) entry + 2.25 * a else entry - 2.25 * a
                var j = i + 1
                var outcome = 0
                while (j < n && j <= i + horizon) {
                    val q = c[j]
                    val hitStop = if (buy) q.l <= stop else q.h >= stop
                    val hitTarget = if (buy) q.h >= target else q.l <= target
                    if (hitStop) { outcome = -1; break }
                    if (hitTarget) { outcome = 1; break }
                    j++
                }
                if (outcome == 0 && j >= n) break // pas encore terminé : on ne compte pas
                trades++
                when (outcome) {
                    1 -> { wins++; sumR += 1.5 }
                    -1 -> sumR -= 1.0
                    else -> { val endP = close[min(j, n - 1)]; sumR += (if (buy) endP - entry else entry - endP) / (1.5 * a) }
                }
                i = j + 1
            } else i++
        }
        return Backtest(trades, wins, if (trades > 0) sumR / trades else 0.0)
    }

    /** Niveaux de Fibonacci du dernier grand mouvement (pour le graphique). */
    fun fibonacci(): List<Level> = if (n > 0) fibAt(n - 1)?.first.orEmpty() else emptyList()

    /** Analyse de la dernière bougie. [htf] : bougies de l'unité de temps supérieure (tendance de fond). */
    fun analyze(htf: List<Candle>? = null, withBacktest: Boolean = true): AnalysisResult? {
        if (n < 60) return null
        val i = n - 1
        val factors = factorsAt(i, htf)
        if (factors.isEmpty()) return null
        val score = scoreOf(factors)
        val fib = fibAt(i)?.first.orEmpty()
        val (sup, res) = levelsAt(i)
        val cl = close[i]
        val supports = sup.filter { it < cl }.distinct().sortedDescending().take(3).map { Level(it, "Support") }
        val resistances = res.filter { it > cl }.distinct().sorted().take(3).map { Level(it, "Résistance") }
        var plan = if (abs(score) >= 35) planAt(i, score > 0, fib) else null
        // Un signal dont le gain possible ne couvre pas au moins 1,3 fois le risque n'est pas proposé
        if (plan != null && plan.rr < 1.3) plan = null
        return AnalysisResult(
            score = score, factors = factors, fib = fib, supports = supports, resistances = resistances,
            plan = plan, backtest = if (withBacktest) backtest() else null,
            atr = v(atr, i), adx = v(adx, i),
        )
    }

    companion object {
        /** Unité de temps supérieure utilisée pour la tendance de fond. */
        fun higher(tf: Timeframe): Timeframe? = when (tf) {
            Timeframe.M5 -> Timeframe.M30
            Timeframe.M15 -> Timeframe.H1
            Timeframe.M30 -> Timeframe.H4
            Timeframe.H1 -> Timeframe.H4
            Timeframe.H4 -> Timeframe.D1
            Timeframe.D1 -> Timeframe.W1
            Timeframe.W1 -> null
        }
    }
}
