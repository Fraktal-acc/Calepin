package fr.jeremy.calepin.control

import android.content.Context
import kotlinx.coroutines.runBlocking

/**
 * Une touche envoyée sans ouvrir l'écran Télécommande (widget, scénario) :
 * le son et la mise en marche vont à la télé, les chaînes au décodeur, s'il y en a un.
 */
object QuickRemote {
    fun target(ctx: Context, key: RemoteKey): HomeDevice? {
        val all = DeviceStore(ctx).all().filter { it.role == Role.TV || it.role == Role.DECODER }
        fun best(role: Role) = all.firstOrNull { it.role == role && it.isDefault } ?: all.firstOrNull { it.role == role }
        val channel = key == RemoteKey.CH_UP || key == RemoteKey.CH_DOWN || key.digit != null
        return if (channel) best(Role.DECODER) ?: best(Role.TV) else best(Role.TV) ?: best(Role.DECODER)
    }

    /** À appeler hors du fil principal. */
    fun press(ctx: Context, key: RemoteKey): Boolean {
        val store = DeviceStore(ctx)
        val d = target(ctx, key) ?: return false
        val s = RemoteDrivers.open(d, store) ?: return false
        return try {
            runBlocking { runCatching { s.press(key) }.getOrDefault(false) }
        } finally {
            runCatching { s.close() }
        }
    }
}
