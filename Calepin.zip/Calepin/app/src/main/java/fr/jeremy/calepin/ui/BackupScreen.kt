package fr.jeremy.calepin.ui

import android.app.Activity
import android.content.Intent
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Backup
import androidx.compose.material.icons.filled.Restore
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import fr.jeremy.calepin.i18n.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import fr.jeremy.calepin.LockGuard
import fr.jeremy.calepin.NotesViewModel
import fr.jeremy.calepin.export.FullBackup
import kotlinx.coroutines.launch
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Sauvegarde complète chiffrée et restauration (changement de téléphone, sécurité). */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BackupScreen(vm: NotesViewModel, onClose: () -> Unit) {
    val scope = rememberCoroutineScope()
    var password by remember { mutableStateOf("") }
    var password2 by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf<String?>(null) }
    var result by remember { mutableStateOf<String?>(null) }
    var staged by remember { mutableStateOf<File?>(null) }
    var restorePassword by remember { mutableStateOf("") }
    var last by remember { mutableStateOf(vm.lastBackup()) }
    BackHandler { onClose() }

    val create = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { res ->
        val uri = res.data?.data
        if (res.resultCode == Activity.RESULT_OK && uri != null) {
            busy = "Sauvegarde en cours…"
            scope.launch {
                val r = vm.backupTo(uri, password.ifBlank { null }) { busy = it }
                busy = null
                result = r.fold({ last = vm.lastBackup(); if (password.isBlank()) "Sauvegarde terminée (sans mot de passe)." else "Sauvegarde terminée. Garde bien ton mot de passe : sans lui, le fichier est illisible." }, { "Échec : ${it.message}" })
            }
        }
    }

    fun restore(file: File, pwd: String?) {
        busy = "Restauration en cours…"
        scope.launch {
            val r = vm.restoreFrom(file, pwd)
            busy = null
            r.onSuccess { result = it; staged = null; restorePassword = "" }
                .onFailure { e ->
                    if (e is FullBackup.WrongPassword) { result = e.message; staged = file } else { result = "Échec : ${e.message}"; staged = null }
                }
        }
    }

    val open = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { res ->
        val uri = res.data?.data
        if (res.resultCode == Activity.RESULT_OK && uri != null) {
            busy = "Lecture du fichier…"
            scope.launch {
                vm.stageBackup(uri).onSuccess { (f, encrypted) ->
                    busy = null
                    if (encrypted) staged = f else restore(f, null)
                }.onFailure { busy = null; result = "Échec : ${it.message}" }
            }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Sauvegarde") },
                navigationIcon = { IconButton(onClick = onClose) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Retour") } },
            )
        },
    ) { pad ->
        Column(
            Modifier.fillMaxSize().padding(pad).verticalScroll(rememberScrollState()).padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Text(
                "Un seul fichier contient tout Calepin : notes, dossiers, agenda, photos, croquis, vidéos, mémos vocaux, clients et interventions, scénarios et réglages.",
                style = MaterialTheme.typography.bodyMedium,
            )
            Text(
                if (last > 0) fr.jeremy.calepin.i18n.I18n.tr("Dernière sauvegarde :") + " " + SimpleDateFormat(fr.jeremy.calepin.i18n.I18n.pattern("EEEE d MMMM yyyy 'à' HH'h'mm"), fr.jeremy.calepin.i18n.I18n.locale).format(Date(last))
                else "Aucune sauvegarde faite depuis ce téléphone.",
                style = MaterialTheme.typography.labelLarge,
                color = MaterialTheme.colorScheme.primary,
            )
            busy?.let {
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer)) {
                    androidx.compose.foundation.layout.Row(Modifier.padding(14.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        CircularProgressIndicator(Modifier.padding(2.dp))
                        Text(it)
                    }
                }
            }
            result?.let {
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerHigh)) { Text(it, Modifier.padding(14.dp)) }
            }

            Text("Sauvegarder", style = MaterialTheme.typography.titleMedium)
            OutlinedTextField(
                password, { password = it }, label = { Text("Mot de passe (recommandé)") }, singleLine = true,
                visualTransformation = PasswordVisualTransformation(), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                modifier = Modifier.fillMaxWidth(),
            )
            if (password.isNotEmpty()) {
                OutlinedTextField(
                    password2, { password2 = it }, label = { Text("Confirme le mot de passe") }, singleLine = true,
                    visualTransformation = PasswordVisualTransformation(), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                    isError = password2.isNotEmpty() && password2 != password,
                    modifier = Modifier.fillMaxWidth(),
                )
            }
            Text(
                "Avec un mot de passe, le fichier est chiffré (AES-256) : tu peux le garder sur Google Drive ou l'envoyer par mail sans risque. " +
                    "Choisis « Drive » dans la fenêtre d'enregistrement pour le mettre dans ton Google Drive.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Button(
                enabled = busy == null && (password.isEmpty() || password == password2),
                onClick = {
                    LockGuard.external()
                    val name = "Calepin-" + SimpleDateFormat(fr.jeremy.calepin.i18n.I18n.pattern("yyyy-MM-dd"), fr.jeremy.calepin.i18n.I18n.locale).format(Date()) + ".calepin"
                    create.launch(Intent(Intent.ACTION_CREATE_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("application/octet-stream").putExtra(Intent.EXTRA_TITLE, name))
                },
                modifier = Modifier.fillMaxWidth(),
            ) { Icon(Icons.Filled.Backup, null); Text("  Créer la sauvegarde") }

            HorizontalDivider()
            Text("Restaurer", style = MaterialTheme.typography.titleMedium)
            Text(
                "Ajoute le contenu d'une sauvegarde à ce téléphone : rien n'est effacé, et une note déjà présente n'est pas dupliquée.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            OutlinedButton(
                enabled = busy == null,
                onClick = {
                    LockGuard.external()
                    open.launch(Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("*/*"))
                },
                modifier = Modifier.fillMaxWidth(),
            ) { Icon(Icons.Filled.Restore, null); Text("  Choisir une sauvegarde (.calepin)") }
        }
    }

    staged?.let { f ->
        AlertDialog(
            onDismissRequest = { staged = null },
            title = { Text("Sauvegarde protégée") },
            text = {
                OutlinedTextField(
                    restorePassword, { restorePassword = it }, label = { Text("Mot de passe") }, singleLine = true,
                    visualTransformation = PasswordVisualTransformation(),
                )
            },
            confirmButton = { TextButton(enabled = restorePassword.isNotEmpty(), onClick = { staged = null; restore(f, restorePassword) }) { Text("Restaurer") } },
            dismissButton = { TextButton(onClick = { staged = null; f.delete() }) { Text("Annuler") } },
        )
    }
}
