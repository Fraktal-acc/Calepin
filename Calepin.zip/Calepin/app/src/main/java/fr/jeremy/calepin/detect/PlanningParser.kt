package fr.jeremy.calepin.detect

import java.util.Calendar

/** Un créneau de travail repéré dans un planning. */
data class Shift(
    val start: Long,
    val end: Long,
    /** Texte restant sur la ligne (site, poste…), pour le titre. */
    val label: String,
    val source: String,
    /** Indisponibilité, visite médicale, congé… : pas une vacation (ni heures de travail, ni réveil). */
    val absence: Boolean = false,
    /** Journée entière (absence sans horaires) ; [end] = minuit du dernier jour. */
    val allDay: Boolean = false,
)

/**
 * Lit le texte d'un planning (extrait d'un PDF) et en tire les jours et horaires de travail.
 * Formats gérés :
 *  - une ligne par jour : « Lundi 12/10/2026  Site A  08:00 - 16:00 », « Mar 13 : 8h-12h / 14h-18h »
 *  - tableau en colonnes : une ligne de dates (« Lun 12  Mar 13  Mer 14 ») puis une ligne d'horaires
 *  - date sur une ligne, horaires sur la suivante
 *  - postes de nuit (« 19:00 - 07:00 » finit le lendemain), jours de repos ignorés (Repos, RH, CP, Congé…)
 */
object PlanningParser {

    private const val MONTHS = "janvier|janv|février|fevrier|févr|fevr|fév|fev|mars|avril|avr|mai|juin|juillet|juil|" +
        "août|aout|septembre|sept|octobre|oct|novembre|nov|décembre|decembre|déc|dec"
    private val MONTH_INDEX = mapOf(
        "janv" to 0, "févr" to 1, "fevr" to 1, "fév" to 1, "fev" to 1, "mars" to 2, "avr" to 3, "mai" to 4, "juin" to 5,
        "juil" to 6, "août" to 7, "aout" to 7, "sept" to 8, "oct" to 9, "nov" to 10, "déc" to 11, "dec" to 11,
    )

    private fun monthOf(word: String): Int? {
        val w = word.lowercase().trimEnd('.')
        return MONTH_INDEX.entries.firstOrNull { w.startsWith(it.key) }?.value
    }

    private val WEEKDAY = mapOf(
        "lu" to Calendar.MONDAY, "ma" to Calendar.TUESDAY, "me" to Calendar.WEDNESDAY, "je" to Calendar.THURSDAY,
        "ve" to Calendar.FRIDAY, "sa" to Calendar.SATURDAY, "di" to Calendar.SUNDAY,
    )

    // « Octobre 2026 » : contexte de mois/année pour les dates sans mois
    private val rxMonthYear = Regex("""(?i)(?<![\p{L}])($MONTHS)\.?\s+(\d{4})""")
    // 12/10/2026, 12.10.26, 12-10, 12/10
    private val rxNumDate = Regex("""(?<![\d/.:])(\d{1,2})[/.\-](\d{1,2})(?:[/.\-](\d{4}|\d{2}))?(?![\d/:]|\.\d)""")
    // 12 octobre (2026)
    private val rxTextDate = Regex("""(?i)(?<![\p{L}\d])(1er|\d{1,2})\s+($MONTHS)\.?(?:\s+(\d{4}))?(?!\p{L})""")
    // Lun 12, Lundi 12, Lu. 12 (sans mois)
    private val rxDayOnly = Regex("""(?i)(?<![\p{L}])(lu|ma|me|je|ve|sa|di)[\p{L}]*\.?\s+(1er|\d{1,2})(?![\d/.:\-]|\s*(?:h|H)\d|\s*(?:$MONTHS))""")

    private const val T = """([01]?\d|2[0-4])\s*(?:[hH:]\s*([0-5]\d)?)"""
    private val rxRange = Regex("""(?<![\d:])$T\s*(?:-|–|—|à|a|>|au|/)\s*$T(?![\d])""")
    private val rxTime = Regex("""(?<![\d:/.])([01]?\d|2[0-4])\s*[hH:]\s*([0-5]\d)?(?![\d/.])""")
    private val rxOff = Regex(
        """(?i)(?<![\p{L}])(repos|rh|r\.h\.|cp|c\.p\.|congés?|conges?|off|férié|ferie|absent|absence|maladie|rtt|libre|récup|recup)(?![\p{L}])"""
    )

    private data class Found(val pos: Int, val end: Int, val day: Long, val explicitYear: Boolean)

    private sealed interface Cell { val pos: Int }
    private data class RangeCell(override val pos: Int, val end: Int, val h1: Int, val m1: Int, val h2: Int, val m2: Int) : Cell
    private data class OffCell(override val pos: Int, val end: Int) : Cell

    fun parse(text: String, now: Long = System.currentTimeMillis()): List<Shift> {
        val nowCal = Calendar.getInstance().apply { timeInMillis = now }
        var ctxYear = nowCal.get(Calendar.YEAR)
        var ctxMonth = nowCal.get(Calendar.MONTH)
        rxMonthYear.find(text)?.let { m ->
            monthOf(m.groupValues[1])?.let { ctxMonth = it }
            ctxYear = m.groupValues[2].toInt()
        }

        val out = mutableListOf<Shift>()
        var pendingDates: List<Found> = emptyList()
        var lastDate: Long? = null

        for (raw in text.lines()) {
            val line = raw.replace('\u00A0', ' ').trim()
            if (line.isEmpty()) continue

            // Le contexte de mois peut changer au fil du document (« Novembre 2026 »)
            rxMonthYear.find(line)?.let { m ->
                monthOf(m.groupValues[1])?.let { ctxMonth = it }
                ctxYear = m.groupValues[2].toInt()
            }

            val dates = findDates(line, ctxYear, ctxMonth)
            dates.lastOrNull { it.explicitYear }?.let {
                val c = Calendar.getInstance().apply { timeInMillis = it.day }
                ctxYear = c.get(Calendar.YEAR); ctxMonth = c.get(Calendar.MONTH)
            }
            val masked = mask(line, dates.map { it.pos until it.end })
            val cells = findCells(masked)
            val ranges = cells.filterIsInstance<RangeCell>()

            when {
                dates.isNotEmpty() && cells.isNotEmpty() && dates.size == cells.size && dates.size > 1 -> {
                    dates.zip(cells).forEach { (d, c) -> if (c is RangeCell) out += shift(d.day, c, line, masked, cells) }
                    pendingDates = emptyList(); lastDate = dates.last().day
                }
                dates.size == 1 && ranges.isNotEmpty() -> {
                    ranges.forEach { out += shift(dates[0].day, it, line, masked, cells) }
                    pendingDates = emptyList(); lastDate = dates[0].day
                }
                dates.isNotEmpty() && cells.isEmpty() -> {
                    pendingDates = dates; lastDate = dates.last().day
                }
                dates.isEmpty() && cells.isNotEmpty() -> {
                    if (pendingDates.size > 1 && pendingDates.size == cells.size) {
                        pendingDates.zip(cells).forEach { (d, c) -> if (c is RangeCell) out += shift(d.day, c, line, masked, cells) }
                        pendingDates = emptyList()
                    } else if (lastDate != null && pendingDates.size <= 1) {
                        ranges.forEach { out += shift(lastDate!!, it, line, masked, cells) }
                    }
                }
                dates.size > 1 && ranges.isNotEmpty() -> {
                    // Plus de dates que d'horaires : on associe chaque horaire à la date qui le précède
                    ranges.forEach { r ->
                        val d = dates.lastOrNull { it.pos < r.pos } ?: dates.first()
                        out += shift(d.day, r, line, masked, cells)
                    }
                    pendingDates = emptyList(); lastDate = dates.last().day
                }
            }
        }
        return out.distinctBy { it.start to it.end }.sortedBy { it.start }
    }

    private fun shift(day: Long, r: RangeCell, line: String, masked: String, cells: List<Cell>): Shift {
        val s = at(day, r.h1, r.m1, 0)
        var e = at(day, r.h2, r.m2, 0)
        if (e <= s) e = at(day, r.h2, r.m2, 1) // poste de nuit : finit le lendemain (même au changement d'heure)
        val label = cells.fold(masked) { acc, c ->
            val end = when (c) { is RangeCell -> c.end; is OffCell -> c.end }
            acc.replaceRange(c.pos, end, " ".repeat(end - c.pos))
        }.replace(Regex("""[|;:,()\[\]\-–—/]+"""), " ")
            .replace(Regex("""(?i)(?<![\p{L}])(lundi|mardi|mercredi|jeudi|vendredi|samedi|dimanche|lun|mar|mer|jeu|ven|sam|dim|de|à|horaires?|début|fin|poste)(?![\p{L}])\.?"""), " ")
            .replace(Regex("""\s+"""), " ").trim()
            .let { stripConnectors(it) }
        return Shift(s, e, label.take(60), line)
    }

    private val CONNECTORS = setOf("le", "la", "les", "l'", "du", "des", "au", "aux", "à", "a", "de", "en", "et", "vos", "votre")

    private fun stripConnectors(s: String): String {
        val words = s.split(' ').toMutableList()
        while (words.isNotEmpty() && words.first().lowercase() in CONNECTORS) words.removeAt(0)
        while (words.isNotEmpty() && words.last().lowercase() in CONNECTORS) words.removeAt(words.lastIndex)
        return words.joinToString(" ")
    }

    /** Jour [day] (+ [plusDays]) à h:m, en heure locale (correct aux changements d'heure). */
    private fun at(day: Long, h: Int, m: Int, plusDays: Int): Long = Calendar.getInstance().apply {
        timeInMillis = day
        add(Calendar.DAY_OF_YEAR, plusDays)
        set(Calendar.HOUR_OF_DAY, h); set(Calendar.MINUTE, m); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
    }.timeInMillis

    private fun mask(s: String, ranges: List<IntRange>): String {
        val ch = s.toCharArray()
        ranges.forEach { r -> for (i in r) if (i in ch.indices) ch[i] = ' ' }
        return String(ch)
    }

    /** Horaires (plages) et mentions de repos, dans l'ordre de la ligne. */
    private fun findCells(s: String): List<Cell> {
        val cells = mutableListOf<Cell>()
        val used = BooleanArray(s.length)
        rxRange.findAll(s).forEach { m ->
            val g = m.groupValues
            val h1 = g[1].toInt(); val m1 = g[2].toIntOrNull() ?: 0
            val h2 = g[3].toInt(); val m2 = g[4].toIntOrNull() ?: 0
            if (h1 > 24 || h2 > 24) return@forEach
            cells += RangeCell(m.range.first, m.range.last + 1, h1 % 24, m1, h2 % 24, m2)
            for (i in m.range) used[i] = true
        }
        // Deux heures seules (colonnes « Début » « Fin ») : 08:00   16:00
        val singles = rxTime.findAll(s).filter { m -> m.range.none { used[it] } }.toList()
        if (singles.size >= 2 && singles.size % 2 == 0 && cells.isEmpty()) {
            singles.chunked(2).forEach { (a, b) ->
                cells += RangeCell(
                    a.range.first, b.range.last + 1,
                    a.groupValues[1].toInt() % 24, a.groupValues[2].toIntOrNull() ?: 0,
                    b.groupValues[1].toInt() % 24, b.groupValues[2].toIntOrNull() ?: 0,
                )
            }
        }
        rxOff.findAll(s).forEach { m -> if (m.range.none { it < used.size && used[it] }) cells += OffCell(m.range.first, m.range.last + 1) }
        return cells.sortedBy { it.pos }
    }

    private fun findDates(line: String, year: Int, month: Int): List<Found> {
        val found = mutableListOf<Found>()
        fun free(r: IntRange) = found.none { it.pos <= r.last && r.first < it.end }

        rxTextDate.findAll(line).forEach { m ->
            val d = if (m.groupValues[1].equals("1er", true)) 1 else m.groupValues[1].toInt()
            val mo = monthOf(m.groupValues[2]) ?: return@forEach
            val y = m.groupValues[3].toIntOrNull()
            day(y ?: year, mo, d)?.let { found += Found(m.range.first, m.range.last + 1, it, y != null) }
        }
        rxNumDate.findAll(line).forEach { m ->
            if (!free(m.range)) return@forEach
            val d = m.groupValues[1].toInt(); val mo = m.groupValues[2].toInt() - 1
            if (d !in 1..31 || mo !in 0..11) return@forEach
            // « 08.00 » ou « 8-12 » ne sont pas des dates : on exige un séparateur « / » ou une année
            val sep = line[m.groups[1]!!.range.last + 1]
            val yRaw = m.groupValues[3]
            if (yRaw.isEmpty() && sep != '/') return@forEach
            val y = yRaw.toIntOrNull()?.let { if (it < 100) 2000 + it else it }
            day(y ?: year, mo, d)?.let { found += Found(m.range.first, m.range.last + 1, it, y != null) }
        }
        rxDayOnly.findAll(line).forEach { m ->
            if (!free(m.range)) return@forEach
            val wd = WEEKDAY[m.groupValues[1].lowercase()] ?: return@forEach
            val d = if (m.groupValues[2].equals("1er", true)) 1 else m.groupValues[2].toInt()
            // On cherche le mois (courant, suivant ou précédent) où ce jour tombe bien ce jour de la semaine
            val candidates = listOf(0, 1, -1).mapNotNull { k ->
                val c = Calendar.getInstance().apply { clear(); set(year, month, 1); add(Calendar.MONTH, k) }
                day(c.get(Calendar.YEAR), c.get(Calendar.MONTH), d)
            }
            val ok = candidates.firstOrNull { Calendar.getInstance().apply { timeInMillis = it }.get(Calendar.DAY_OF_WEEK) == wd }
                ?: candidates.firstOrNull() ?: return@forEach
            found += Found(m.range.first, m.range.last + 1, ok, false)
        }
        return found.sortedBy { it.pos }
    }

    private fun day(y: Int, m: Int, d: Int): Long? = try {
        Calendar.getInstance().apply { isLenient = false; clear(); set(y, m, d) }.timeInMillis
    } catch (e: IllegalArgumentException) {
        null
    }
}
