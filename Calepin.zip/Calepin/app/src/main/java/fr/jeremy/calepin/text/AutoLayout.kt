package fr.jeremy.calepin.text

import fr.jeremy.calepin.detect.EntityDetector
import fr.jeremy.calepin.detect.EntityType
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Mise en page automatique d'une note, pour en faire un beau PDF : le texte est découpé en titres,
 * paragraphes, listes, tâches, tableaux, citations et photos, la typographie française est corrigée,
 * et les informations utiles (dates, numéros, adresses…) sont regroupées dans un encadré « En bref ».
 *
 * Les textes des blocs gardent la mise en forme de la note (gras, italique, couleurs) : le rendu PDF
 * la reproduit. Rien n'est inventé ni retiré.
 */
object AutoLayout {

    data class Item(val text: String, val level: Int = 0, val done: Boolean? = null)

    sealed interface Block {
        data class Heading(val level: Int, val text: String) : Block
        data class Paragraph(val text: String, val align: String? = null) : Block
        data class ListBlock(val items: List<Item>, val numbered: Boolean) : Block
        data class Tasks(val items: List<Item>) : Block
        data class KeyValues(val rows: List<Pair<String, String>>) : Block
        data class Table(val header: List<String>?, val rows: List<List<String>>) : Block
        data class Quote(val text: String) : Block
        data class Photo(val file: String, val video: Boolean, val side: NoteLayout.Side?, val width: Int) : Block
        data class Thumbs(val files: List<String>) : Block
        data object Divider : Block
        /** Saut de page (documents Word). */
        data object PageBreak : Block
    }

    /** Ligne de l'encadré « En bref » : « Dates » → « 12 octobre 2026 à 14h30 · … ». */
    data class Fact(val label: String, val values: List<String>)

    data class Doc(val title: String, val meta: String, val facts: List<Fact>, val blocks: List<Block>)

    data class Options(
        /** Encadré « En bref » avec les dates, numéros, adresses, e-mails et liens trouvés. */
        val summary: Boolean = true,
        /** Titres devinés (lignes courtes en majuscules, terminées par « : »…) en plus des titres « # ». */
        val guessHeadings: Boolean = true,
        /** Guillemets « », points de suspension, espaces avant « : ; ! ? ». */
        val typography: Boolean = true,
        val photos: Boolean = true,
    )

    // ------------------------------------------------------------------ Lignes reconnues

    private val heading = Regex("^(#{1,3})\\s+(.+)$")
    private val bullet = Regex("^([ \\t]*)([-•*–·▪◦]|\\d{1,2}[.)]|[a-zA-Z][)])\\s+(.*)$")
    private val numberedMark = Regex("^(\\d{1,2}[.)]|[a-zA-Z][)])$")
    private val task = Regex("^([ \\t]*)(☐|☑|\\[ ?\\]|\\[[xX]\\])\\s*(.*)$")
    private val quote = Regex("^\\s*>\\s?(.*)$")
    private val divider = Regex("^\\s*(-{3,}|_{3,}|\\*{3,}|={3,}|—{2,})\\s*$")
    private val keyValue = Regex("^([^:\\n]{2,32}?)\\s*:\\s+(\\S.*)$")
    private val tableSep = Regex("^\\s*\\|?\\s*:?-{2,}:?\\s*(\\|\\s*:?-{2,}:?\\s*)*\\|?\\s*$")
    private val alignToken = Regex("\\[(center|right)]")

    /** Texte sans repères (pour décider du type d'une ligne). */
    private fun plainOf(s: String) = MarkdownSigns.plain(RichText.strip(s)).trim()

    private fun isTableRow(l: String): Boolean {
        val t = l.trim()
        if (t.isEmpty() || tableSep.matches(t)) return false
        return ('|' in t || '\t' in t) && cells(t).count { it.isNotEmpty() } >= 2
    }

    private fun cells(l: String): List<String> =
        if ('|' in l) l.trim().removePrefix("|").removeSuffix("|").split('|').map { it.trim() }
        else l.trim().split('\t').map { it.trim() }.filter { it.isNotEmpty() }

    /** Clé d'une ligne « Clé : valeur » (pas une phrase ni une heure). */
    private fun kvOf(l: String): Pair<String, String>? {
        val m = keyValue.find(l.trim()) ?: return null
        val k = m.groupValues[1].trim()
        val kp = plainOf(k)
        if (kp.isEmpty() || kp.split(' ').size > 4 || kp.count { it.isDigit() } > 2) return null
        if (kp.first().isLowerCase() && kp.split(' ').size > 2) return null
        if (Regex("(?i)^(https?|mailto)$").matches(kp)) return null
        return k to m.groupValues[2].trim()
    }

    private val endPunct = setOf('.', ',', ';', '!', '?', '…')

    /** Ligne qui ressemble à un titre (sans signe « # »). */
    private fun looksLikeTitle(p: String): Int? {
        if (p.length !in 2..60 || p.last() in endPunct) return null
        val letters = p.filter { it.isLetter() }
        if (letters.length >= 3 && letters.all { it.isUpperCase() }) return 1
        if (p.endsWith(":") && p.length <= 50 && p.split(' ').size <= 7) return 2
        return null
    }

    // ------------------------------------------------------------------ Typographie

    /** Typographie française : « guillemets », points de suspension, espaces fines avant ; : ! ? */
    fun typo(s0: String): String {
        if (s0.isBlank()) return s0
        var s = s0.replace("...", "…").replace(Regex("[ \\t]{2,}"), " ")
        // Apostrophe typographique entre deux lettres (« l'arrosage » → « l’arrosage »)
        s = Regex("(?<=\\p{L})'(?=\\p{L})").replace(s, "’")
        // Tiret entre deux mots → tiret demi-cadratin
        s = s.replace(" - ", " – ")
        // Guillemets droits par paires → « »
        s = Regex("\"\\s*([^\"\\n]+?)\\s*\"").replace(s) { "«\u00A0" + it.groupValues[1] + "\u00A0»" }
        // « ; ! ? » : espace fine insécable devant (pas dans une adresse web ni « ?? »)
        s = Regex("(?<=[\\p{L}\\d)»*_~\\]])[ \\u00A0]?([;!?])(?=\\s|$|[»)])").replace(s) { m ->
            if (isInUrl(s, m.range.first)) m.value else " " + m.groupValues[1]
        }
        // « : » suivi d'une espace (pas les heures 14:30 ni http:)
        s = Regex("(?<=[\\p{L}\\d)»*_~\\]])[ \\u00A0]?:(?=\\s|$)").replace(s) { m ->
            if (isInUrl(s, m.range.first)) m.value else " :"
        }
        return s
    }

    private fun isInUrl(s: String, at: Int): Boolean {
        if (at <= 0) return false
        val start = s.lastIndexOfAny(charArrayOf(' ', '\n', '('), at - 1).let { if (it < 0) 0 else it + 1 }
        val word = if (start < at) s.substring(start, at) else ""
        return word.contains("://") || word.startsWith("www.") || word.contains('@')
    }

    /** Majuscule au début (après les repères de couleur ou de gras). */
    private fun capitalize(s: String): String {
        var i = 0
        while (i < s.length) {
            val c = s[i]
            when {
                c == '[' -> { val e = s.indexOf(']', i); if (e < 0) return s; i = e + 1 }
                c == '*' || c == '_' || c == '~' || c == ' ' || c == '«' || c == ' ' -> i++
                c.isLetter() -> return if (c.isLowerCase() && !looksLikeCode(s, i)) s.substring(0, i) + c.uppercaseChar() + s.substring(i + 1) else s
                else -> return s
            }
        }
        return s
    }

    /** Ne pas mettre de majuscule à « www.site.fr », « iphone », une adresse mail… */
    private fun looksLikeCode(s: String, i: Int): Boolean {
        val w = s.substring(i).takeWhile { !it.isWhitespace() }
        return w.startsWith("www.") || '@' in w || "://" in w || (w.length > 1 && w.drop(1).any { it.isUpperCase() })
    }

    private fun clean(s: String, o: Options) = if (o.typography) capitalize(typo(s.trim())) else s.trim()

    // ------------------------------------------------------------------ Découpage

    fun build(title: String, content: String, updatedAt: Long, tags: List<String> = emptyList(), folder: String = "", o: Options = Options()): Doc {
        val text = content.replace("\r\n", "\n").replace('\r', '\n')
        val blocks = blocks(text, o).toMutableList()
        // Sans titre : la première ligne courte devient le titre
        var t = title.trim()
        if (t.isEmpty()) {
            val first = blocks.firstOrNull()
            when {
                first is Block.Heading -> { t = plainOf(first.text); blocks.removeAt(0) }
                first is Block.Paragraph -> {
                    val firstLine = first.text.substringBefore('\n')
                    if (plainOf(firstLine).length in 1..70) {
                        t = plainOf(firstLine).trimEnd('.', ':')
                        val rest = first.text.substringAfter('\n', "")
                        if (rest.isBlank()) blocks.removeAt(0) else blocks[0] = first.copy(text = capitalize(rest))
                    }
                }
            }
        }
        if (t.isEmpty()) t = "Note"
        // Premier titre identique au titre de la note : inutile de le répéter
        (blocks.firstOrNull() as? Block.Heading)?.let { if (TextNormLite.norm(plainOf(it.text)) == TextNormLite.norm(t)) blocks.removeAt(0) }
        val fmt = SimpleDateFormat("d MMMM yyyy", Locale.FRANCE)
        val meta = listOfNotNull(
            folder.takeIf { it.isNotBlank() }?.replace("/", " › "),
            tags.takeIf { it.isNotEmpty() }?.joinToString(", "),
            "Mise à jour le " + fmt.format(Date(updatedAt)),
        ).joinToString(" · ")
        // En bref : seulement ce qui n'est pas déjà bien visible (titre, petit tableau « Clé : valeur »)
        val shown = TextNormLite.norm((listOf(t) + blocks.filterIsInstance<Block.KeyValues>().flatMap { kv -> kv.rows.map { it.second } }).joinToString(" | ") { plainOf(it) })
        val facts = if (!o.summary) emptyList() else facts(MarkdownSigns.plain(RichText.strip(NoteLayout.marker.replace(text, ""))))
            .map { f -> f.copy(values = f.values.filter { v -> TextNormLite.norm(v) !in shown }) }
            .filter { it.values.isNotEmpty() }
            .map { f -> f.copy(label = f.label.removeSuffix("s").let { b -> if (f.values.size > 1) b + "s" else b }) }
        return Doc(if (o.typography) typo(t) else t, meta, facts, blocks)
    }

    fun blocks(text: String, o: Options = Options()): List<Block> {
        val lines = text.split('\n')
        val out = ArrayList<Block>()
        val para = ArrayList<String>()
        var paraAlign: String? = null

        fun flushPara() {
            if (para.isEmpty()) return
            out += Block.Paragraph(para.joinToString("\n") { clean(it, o) }, paraAlign)
            para.clear(); paraAlign = null
        }

        fun noAlign(l: String) = alignToken.replace(l, "").trimEnd()

        var i = 0
        while (i < lines.size) {
            val raw = lines[i]
            // Alignement choisi dans la note (« [center] » en fin de ligne)
            val align = alignToken.find(raw)?.groupValues?.get(1)
            val line = noAlign(raw)
            if (line.isBlank()) { flushPara(); i++; continue }

            // Photos et vidéos
            val photo = NoteLayout.markerAlone.matchEntire(line)
            if (photo != null) {
                flushPara()
                val spec = NoteLayout.specOf(photo)
                if (o.photos) {
                    val last = out.lastOrNull()
                    when {
                        spec.side != null -> out += Block.Photo(spec.file, spec.video, spec.side, spec.width)
                        last is Block.Thumbs && i > 0 && NoteLayout.markerAlone.matches(noAlign(lines[i - 1])) ->
                            out[out.lastIndex] = Block.Thumbs(last.files + spec.file)
                        else -> out += Block.Thumbs(listOf(spec.file))
                    }
                }
                i++; continue
            }
            val l0 = NoteLayout.marker.replace(line, "").trimEnd()
            if (l0.isBlank()) { i++; continue }

            if (divider.matches(l0)) { flushPara(); out += Block.Divider; i++; continue }

            val h = heading.find(l0.trim())
            if (h != null) {
                flushPara()
                out += Block.Heading(h.groupValues[1].length, clean(h.groupValues[2], o))
                i++; continue
            }

            // Tâches
            if (task.containsMatchIn(l0)) {
                flushPara()
                val items = ArrayList<Item>()
                while (i < lines.size) {
                    val m = task.find(noAlign(lines[i])) ?: break
                    val done = m.groupValues[2].let { it == "☑" || it.contains('x', ignoreCase = true) }
                    items += Item(clean(m.groupValues[3], o), indent(m.groupValues[1]), done)
                    i++
                }
                out += Block.Tasks(items)
                continue
            }

            // Listes à puces ou numérotées
            val b0 = bullet.find(l0)
            if (b0 != null && b0.groupValues[3].isNotBlank()) {
                flushPara()
                val numbered = numberedMark.matches(b0.groupValues[2])
                val items = ArrayList<Item>()
                while (i < lines.size) {
                    val l = noAlign(lines[i])
                    val m = bullet.find(l)
                    if (m != null && m.groupValues[3].isNotBlank() && !task.containsMatchIn(l)) {
                        items += Item(clean(m.groupValues[3], o), indent(m.groupValues[1]))
                        i++
                    } else if (items.isNotEmpty() && l.isNotBlank() && (l.startsWith("  ") || l.startsWith("\t"))) {
                        // Suite de la puce sur la ligne suivante (décalée)
                        val last = items.removeAt(items.lastIndex)
                        items += last.copy(text = last.text + " " + clean(l, o))
                        i++
                    } else break
                }
                out += Block.ListBlock(items, numbered)
                continue
            }

            // Citation
            if (quote.matches(l0)) {
                flushPara()
                val q = ArrayList<String>()
                while (i < lines.size) {
                    val m = quote.matchEntire(noAlign(lines[i])) ?: break
                    q += clean(m.groupValues[1], o); i++
                }
                out += Block.Quote(q.joinToString("\n"))
                continue
            }

            // Tableau : au moins deux lignes avec des « | » (ou des tabulations)
            if (isTableRow(l0) && i + 1 < lines.size && (isTableRow(lines[i + 1]) || tableSep.matches(lines[i + 1]))) {
                flushPara()
                val rows = ArrayList<List<String>>()
                var header: List<String>? = null
                while (i < lines.size && lines[i].isNotBlank() && (isTableRow(lines[i]) || tableSep.matches(lines[i]))) {
                    if (tableSep.matches(lines[i])) { if (rows.size == 1 && header == null) header = rows.removeAt(0) }
                    else rows += cells(noAlign(lines[i])).map { clean(it, o) }
                    i++
                }
                val cols = maxOf(header?.size ?: 0, rows.maxOfOrNull { it.size } ?: 0)
                out += Block.Table(header?.let { pad(it, cols) }, rows.map { pad(it, cols) })
                continue
            }

            // « Clé : valeur » sur plusieurs lignes de suite : petit tableau
            if (kvOf(l0) != null && i + 1 < lines.size && kvOf(noAlign(lines[i + 1])) != null) {
                flushPara()
                val rows = ArrayList<Pair<String, String>>()
                while (i < lines.size) {
                    val p = kvOf(noAlign(lines[i])) ?: break
                    rows += clean(p.first, o) to clean(p.second, o)
                    i++
                }
                out += Block.KeyValues(rows)
                continue
            }

            // Titre deviné : ligne courte isolée (majuscules, ou terminée par « : ») suivie d'un contenu
            if (o.guessHeadings && para.isEmpty() && (i == 0 || lines[i - 1].isBlank())) {
                val lvl = looksLikeTitle(plainOf(l0))
                val hasNext = (i + 1 until lines.size).any { lines[it].isNotBlank() }
                if (lvl != null && hasNext) {
                    out += Block.Heading(lvl, clean(titleCase(l0.trim().removeSuffix(":").trimEnd()), o))
                    i++; continue
                }
            }

            if (para.isEmpty()) paraAlign = align
            para += l0
            i++
        }
        flushPara()
        return out
    }

    private fun indent(ws: String): Int = (ws.replace("\t", "    ").length / 2).coerceIn(0, 3)

    private fun pad(l: List<String>, n: Int) = if (l.size >= n) l.take(n) else l + List(n - l.size) { "" }

    /** « COURSES DE LA SEMAINE » → « Courses de la semaine » (les sigles courts restent en majuscules). */
    private fun titleCase(s: String): String {
        val letters = s.filter { it.isLetter() }
        if (letters.length < 3 || !letters.all { it.isUpperCase() }) return s
        val words = s.split(' ')
        if (words.size == 1 && letters.length <= 4) return s
        return words.mapIndexed { i, w ->
            val lw = w.lowercase(Locale.FRANCE)
            if (i == 0) lw.replaceFirstChar { it.uppercase() } else lw
        }.joinToString(" ")
    }

    // ------------------------------------------------------------------ En bref

    fun facts(plain: String): List<Fact> {
        val ents = runCatching { EntityDetector.detect(plain) }.getOrDefault(emptyList())
        if (ents.isEmpty()) return emptyList()
        fun of(t: EntityType, label: String, max: Int = 4) =
            ents.filter { it.type == t }.map { it.text.trim().trim(',', '.', ';') }.distinctBy { TextNormLite.norm(it) }.take(max)
                .takeIf { it.isNotEmpty() }?.let { Fact(label, it) }
        return listOfNotNull(
            of(EntityType.DATE, "Date"),
            of(EntityType.PHONE, "Téléphone"),
            of(EntityType.ADDRESS, "Adresse", 3),
            of(EntityType.EMAIL, "E-mail"),
            of(EntityType.URL, "Lien", 3),
        ).map { if (it.values.size > 1) it.copy(label = it.label + "s") else it }
    }

    // ------------------------------------------------------------------ Assistant IA

    /**
     * Consigne donnée au modèle d'IA (Calepin IA) : il réorganise la note avec les conventions comprises
     * ci-dessus, sans rien inventer. Les photos sont remplacées par « [PHOTO n] » avant et remises après.
     */
    const val AI_INSTRUCTION =
        "Mets en page ce texte pour en faire un document clair et agréable à lire. Utilise uniquement ces conventions : " +
            "« # » devant le titre principal, « ## » devant chaque section, « - » devant les éléments de liste, " +
            "« 1. » pour les étapes, « ☐ » devant les choses à faire (« ☑ » si c'est fait), « Clé : valeur » pour les informations courtes, " +
            "« **mot** » pour ce qui est important. Regroupe ce qui va ensemble sous des sections courtes et parlantes. " +
            "Corrige les fautes. Garde toutes les informations (noms, dates, heures, montants, numéros, adresses) exactement. " +
            "N'invente rien, n'ajoute ni introduction ni conclusion. Garde chaque ligne « [PHOTO n] » telle quelle, seule sur sa ligne."

    /** Photos remplacées par « [PHOTO n] » pour l'IA ; renvoie le texte et les repères d'origine. */
    fun hidePhotos(text: String): Pair<String, List<String>> {
        val markers = ArrayList<String>()
        val t = NoteLayout.markerAlone.replace(text) { m -> markers += m.value.trim(); "[PHOTO ${markers.size}]" }
        return t to markers
    }

    /** Remet les photos à leur place dans la réponse de l'IA (celles qu'elle a oubliées vont à la fin). */
    fun restorePhotos(ai: String, markers: List<String>): String {
        var t = ai
        val missing = ArrayList<String>()
        markers.forEachIndexed { i, m ->
            val rx = Regex("(?im)^\\s*\\[\\s*photo\\s*${i + 1}\\s*]\\s*$")
            if (rx.containsMatchIn(t)) t = rx.replaceFirst(t, Regex.escapeReplacement(m)) else missing += m
        }
        t = Regex("(?i)\\[\\s*photo\\s*\\d+\\s*]").replace(t, "")
        return if (missing.isEmpty()) t else t.trimEnd() + "\n\n" + missing.joinToString("\n")
    }

    /** Réponse de l'IA nettoyée (blocs de code « ``` », phrase d'introduction). */
    fun cleanAi(s: String): String {
        var t = s.trim()
        val first = t.lineSequence().firstOrNull().orEmpty()
        if (Regex("(?i)^(voici|voilà|bien sûr|d'accord)\\b.*:\\s*$").matches(first)) t = t.substringAfter('\n', "").trim()
        t = Regex("^```[a-zA-Z]*\\s*\n").replace(t, "")
        t = Regex("\n?```\\s*$").replace(t, "")
        return t.trim()
    }
}

/** Comparaison sans accents ni majuscules (copie légère de TextNorm, sans dépendance Android). */
internal object TextNormLite {
    fun norm(s: String): String = java.text.Normalizer.normalize(s.lowercase(Locale.FRANCE), java.text.Normalizer.Form.NFD)
        .replace(Regex("\\p{M}+"), "").replace(Regex("\\s+"), " ").trim()
}
