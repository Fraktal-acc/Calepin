package fr.jeremy.calepin.ui

import android.Manifest
import android.content.ContentUris
import android.content.Context
import android.content.pm.PackageManager
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Alarm
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.LibraryMusic
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.PhoneInTalk
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.core.content.ContextCompat
import fr.jeremy.calepin.i18n.I18n
import fr.jeremy.calepin.i18n.RawText
import fr.jeremy.calepin.i18n.Text
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** Un son proposé : [uri] vide = sonnerie par défaut du téléphone. */
data class SoundItem(val uri: String, val title: String, val detail: String = "")

/** Sons du téléphone rangés par dossier. */
private data class SoundGroup(val title: String, val items: List<SoundItem>)

/** Formats que le lecteur d'Android sait jouer pour une alarme. */
private val COMPATIBLE = mapOf(
    "audio/mpeg" to "MP3", "audio/mp3" to "MP3", "audio/mp4" to "M4A", "audio/x-m4a" to "M4A", "audio/m4a" to "M4A", "audio/aac" to "AAC",
    "audio/aac-adts" to "AAC", "audio/ogg" to "OGG", "application/ogg" to "OGG", "audio/opus" to "Opus", "audio/flac" to "FLAC",
    "audio/x-flac" to "FLAC", "audio/wav" to "WAV", "audio/x-wav" to "WAV", "audio/vnd.wave" to "WAV", "audio/midi" to "MIDI",
    "audio/x-midi" to "MIDI", "audio/sp-midi" to "MIDI", "audio/amr" to "AMR", "audio/3gpp" to "3GP", "audio/x-matroska" to "MKA",
    "audio/webm" to "WEBM",
)

private fun audioPermission() = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO else Manifest.permission.READ_EXTERNAL_STORAGE

private fun hasAudioPermission(ctx: Context) = ContextCompat.checkSelfPermission(ctx, audioPermission()) == PackageManager.PERMISSION_GRANTED

/** Sonneries intégrées au téléphone (alarmes, sonneries d'appel, notifications). */
private fun systemSounds(ctx: Context, type: Int): List<SoundItem> = runCatching {
    val rm = RingtoneManager(ctx).apply { setType(type) }
    val c = rm.cursor
    val out = ArrayList<SoundItem>()
    while (c.moveToNext()) {
        val uri = rm.getRingtoneUri(c.position)?.toString() ?: continue
        out += SoundItem(uri, c.getString(RingtoneManager.TITLE_COLUMN_INDEX) ?: "?")
    }
    out
}.getOrDefault(emptyList())

/** Sons enregistrés sur le téléphone (dossiers Sonneries, Alarmes, Notifications, Musique, Téléchargements…), formats compatibles. */
private fun storedSounds(ctx: Context): List<SoundGroup> {
    if (!hasAudioPermission(ctx)) return emptyList()
    val cols = mutableListOf(
        MediaStore.Audio.Media._ID, MediaStore.Audio.Media.TITLE, MediaStore.Audio.Media.MIME_TYPE,
        MediaStore.Audio.Media.DURATION, MediaStore.Audio.Media.DISPLAY_NAME,
    )
    @Suppress("DEPRECATION")
    val folderCol = if (Build.VERSION.SDK_INT >= 29) MediaStore.Audio.Media.RELATIVE_PATH else MediaStore.Audio.Media.DATA
    cols += folderCol
    val byFolder = LinkedHashMap<String, MutableList<SoundItem>>()
    runCatching {
        ctx.contentResolver.query(
            MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, cols.toTypedArray(), null, null,
            MediaStore.Audio.Media.TITLE + " COLLATE NOCASE ASC",
        )?.use { c ->
            val iId = c.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
            val iTitle = c.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
            val iMime = c.getColumnIndexOrThrow(MediaStore.Audio.Media.MIME_TYPE)
            val iDur = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
            val iName = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DISPLAY_NAME)
            val iFolder = c.getColumnIndexOrThrow(folderCol)
            while (c.moveToNext()) {
                val mime = c.getString(iMime)?.lowercase() ?: continue
                val ext = c.getString(iName)?.substringAfterLast('.', "")?.uppercase().orEmpty()
                val format = COMPATIBLE[mime] ?: if (ext in setOf("MP3", "M4A", "AAC", "OGG", "OPUS", "FLAC", "WAV", "MID", "MIDI", "AMR")) ext else continue
                val uri = ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, c.getLong(iId)).toString()
                val dur = c.getLong(iDur) / 1000
                val raw = c.getString(iFolder).orEmpty()
                val folder = (if (Build.VERSION.SDK_INT >= 29) raw.trimEnd('/') else raw.substringBeforeLast('/').substringAfter("/0/"))
                    .ifBlank { "/" }
                val detail = format + if (dur > 0) " · %d:%02d".format(dur / 60, dur % 60) else ""
                byFolder.getOrPut(folder) { ArrayList() } += SoundItem(uri, c.getString(iTitle) ?: c.getString(iName) ?: "?", detail)
            }
        }
    }
    // Les dossiers de sons d'abord, puis les autres par ordre alphabétique
    val priority = listOf("ringtones", "alarms", "notifications", "music", "download")
    return byFolder.entries.sortedWith(compareBy<Map.Entry<String, MutableList<SoundItem>>>({ e ->
        val first = e.key.substringBefore('/').lowercase()
        priority.indexOf(first).let { if (it < 0) priority.size else it }
    }, { it.key.lowercase() })).map { SoundGroup(it.key, it.value) }
}

/**
 * Choix d'une sonnerie : sons intégrés au téléphone (alarmes, sonneries, notifications) et sons enregistrés
 * dans les dossiers du téléphone, dans les formats compatibles. Chaque son peut être écouté avant de choisir.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SoundPickerDialog(current: String, alarm: Boolean, onDismiss: () -> Unit, onPick: (String) -> Unit) {
    val ctx = LocalContext.current
    var query by remember { mutableStateOf("") }
    var chosen by remember { mutableStateOf(current) }
    var playing by remember { mutableStateOf<String?>(null) }
    var alarms by remember { mutableStateOf<List<SoundItem>?>(null) }
    var ringtones by remember { mutableStateOf<List<SoundItem>>(emptyList()) }
    var notifs by remember { mutableStateOf<List<SoundItem>>(emptyList()) }
    var stored by remember { mutableStateOf<List<SoundGroup>>(emptyList()) }
    var permitted by remember { mutableStateOf(hasAudioPermission(ctx)) }
    val player = remember { arrayOfNulls<MediaPlayer>(1) }

    fun stop() {
        player[0]?.runCatching { stop(); release() }
        player[0] = null
        playing = null
    }
    fun play(uri: String) {
        stop()
        val u = if (uri.isBlank()) RingtoneManager.getDefaultUri(if (alarm) RingtoneManager.TYPE_ALARM else RingtoneManager.TYPE_NOTIFICATION) else Uri.parse(uri)
        runCatching {
            player[0] = MediaPlayer().apply {
                setAudioAttributes(AudioAttributes.Builder().setUsage(if (alarm) AudioAttributes.USAGE_ALARM else AudioAttributes.USAGE_NOTIFICATION).build())
                setDataSource(ctx, u)
                setOnCompletionListener { if (playing == uri) playing = null }
                prepare()
                start()
            }
            playing = uri
        }.onFailure { I18n.toast(ctx, "Ce son ne peut pas être lu", android.widget.Toast.LENGTH_SHORT).show() }
    }
    DisposableEffect(Unit) { onDispose { stop() } }

    LaunchedEffect(permitted) {
        withContext(Dispatchers.IO) {
            val a = systemSounds(ctx, RingtoneManager.TYPE_ALARM)
            val r = systemSounds(ctx, RingtoneManager.TYPE_RINGTONE)
            val n = systemSounds(ctx, RingtoneManager.TYPE_NOTIFICATION)
            val s = storedSounds(ctx)
            alarms = a; ringtones = r; notifs = n; stored = s
        }
    }
    val askAudio = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { permitted = it }

    val q = query.trim().lowercase()
    fun List<SoundItem>.f() = if (q.isEmpty()) this else filter { it.title.lowercase().contains(q) }
    fun close() { stop(); onDismiss() }

    Dialog(onDismissRequest = { close() }, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Scaffold(
            // Fond plein : le thème rend le fond transparent (fonds animés), ce qui laisserait voir l'écran dessous
            containerColor = MaterialTheme.colorScheme.surface,
            topBar = {
                TopAppBar(
                    title = { FitText(if (alarm) "Sonnerie de l'alarme" else "Son du rappel") },
                    navigationIcon = { IconButton(onClick = { close() }) { Icon(Icons.Filled.Close, "Fermer") } },
                    actions = {
                        TextButton(onClick = { stop(); onPick(chosen); onDismiss() }) { Text("Choisir") }
                    },
                )
            },
        ) { pad ->
            Column(
                Modifier
                    .fillMaxSize()
                    .padding(pad)
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 16.dp)
                    .padding(bottom = 32.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                OutlinedTextField(
                    value = query, onValueChange = { query = it },
                    modifier = Modifier.fillMaxWidth(), singleLine = true,
                    placeholder = { Text("Rechercher un son") },
                    leadingIcon = { Icon(Icons.Filled.Search, null) },
                    shape = MaterialTheme.shapes.large,
                )
                SoundRow(SoundItem("", I18n.tr("Sonnerie par défaut du téléphone")), chosen, playing, { chosen = it }, { if (playing == it) stop() else play(it) })

                val a = alarms
                if (a == null) {
                    CircularProgressIndicator(Modifier.size(28.dp))
                } else {
                    val groups = listOf(
                        Triple("Alarmes du téléphone", Icons.Filled.Alarm, a.f()),
                        Triple("Sonneries du téléphone", Icons.Filled.PhoneInTalk, ringtones.f()),
                        Triple("Notifications du téléphone", Icons.Filled.NotificationsActive, notifs.f()),
                    ).let { if (alarm) it else listOf(it[2], it[0], it[1]) }
                    groups.forEachIndexed { i, (title, icon, list) ->
                        if (list.isEmpty()) return@forEachIndexed
                        FoldSection(
                            title, icon,
                            summary = I18n.trf("{0} sons", list.size),
                            startOpen = i == 0 || q.isNotEmpty() || list.any { it.uri == chosen },
                        ) {
                            list.forEach { s -> SoundRow(s, chosen, playing, { chosen = it }, { if (playing == it) stop() else play(it) }) }
                        }
                    }
                    SubTitle("Sons enregistrés sur le téléphone")
                    if (!permitted) {
                        Text(
                            "Pour proposer tes propres sons (dossiers Sonneries, Alarmes, Musique, Téléchargements…), Calepin doit pouvoir lire les fichiers audio.",
                            style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                        Button(onClick = { fr.jeremy.calepin.LockGuard.external(); askAudio.launch(audioPermission()) }) { Text("Autoriser l'accès aux sons") }
                    } else if (stored.isEmpty()) {
                        Text("Aucun son trouvé dans les dossiers du téléphone.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    } else {
                        stored.forEach { g ->
                            val list = g.items.f()
                            if (list.isEmpty()) return@forEach
                            FoldSection(
                                g.title, if (g.title.lowercase().startsWith("music")) Icons.Filled.LibraryMusic else Icons.Filled.Folder,
                                summary = I18n.trf("{0} sons", list.size),
                                startOpen = q.isNotEmpty() || list.any { it.uri == chosen },
                                translate = false,
                            ) {
                                list.forEach { s -> SoundRow(s, chosen, playing, { chosen = it }, { if (playing == it) stop() else play(it) }) }
                            }
                        }
                    }
                    Text(
                        "Formats compatibles : MP3, M4A / AAC, OGG, Opus, FLAC, WAV, MIDI, AMR. " +
                            "Pour ajouter un son, copie-le dans le dossier « Ringtones » (Sonneries) ou « Alarms » du téléphone, par exemple avec l'explorateur de fichiers de Calepin.",
                        style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
        }
    }
}

@Composable
private fun SoundRow(s: SoundItem, chosen: String, playing: String?, onChoose: (String) -> Unit, onPlay: (String) -> Unit) {
    val sel = s.uri == chosen
    val cs = MaterialTheme.colorScheme
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(if (sel) cs.secondaryContainer else androidx.compose.ui.graphics.Color.Transparent)
            .clickable { onChoose(s.uri); onPlay(s.uri) },
        verticalAlignment = Alignment.CenterVertically,
    ) {
        RadioButton(selected = sel, onClick = { onChoose(s.uri) })
        Column(Modifier.weight(1f)) {
            RawText(s.title, style = MaterialTheme.typography.bodyLarge, fontWeight = if (sel) FontWeight.SemiBold else FontWeight.Normal, maxLines = 1, overflow = TextOverflow.Ellipsis)
            if (s.detail.isNotBlank()) RawText(s.detail, style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
        }
        IconButton(onClick = { onPlay(s.uri) }) {
            Icon(if (playing == s.uri) Icons.Filled.Stop else Icons.Filled.PlayArrow, if (playing == s.uri) "Arrêter" else "Écouter", tint = cs.primary)
        }
        Spacer(Modifier.width(4.dp))
    }
}
