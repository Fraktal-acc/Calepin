package fr.jeremy.calepin.ui.tools

import android.Manifest
import android.content.Intent
import android.os.Build
import android.provider.Settings
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.BatteryChargingFull
import androidx.compose.material.icons.filled.CleaningServices
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import fr.jeremy.calepin.LockGuard
import fr.jeremy.calepin.i18n.I18n
import fr.jeremy.calepin.i18n.RawText
import fr.jeremy.calepin.i18n.Text
import fr.jeremy.calepin.tools.AppSize
import fr.jeremy.calepin.tools.Cleaner
import fr.jeremy.calepin.tools.JunkFile
import fr.jeremy.calepin.tools.JunkKind
import fr.jeremy.calepin.tools.PhoneInfo
import fr.jeremy.calepin.tools.ScanResult
import fr.jeremy.calepin.tools.StorageAccess
import fr.jeremy.calepin.tools.formatSize
import fr.jeremy.calepin.ui.FitText
import fr.jeremy.calepin.ui.FoldSection
import fr.jeremy.calepin.ui.LinkCard
import fr.jeremy.calepin.ui.SubTitle
import fr.jeremy.calepin.ui.appBorder
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

// ------------------------------------------------------------------ Éléments communs

@OptIn(ExperimentalMaterial3Api::class)
@Composable
internal fun ToolScaffold(title: String, onClose: () -> Unit, actions: @Composable () -> Unit = {}, content: @Composable ColumnScope.() -> Unit) {
    BackHandler { onClose() }
    Scaffold(
        topBar = {
            TopAppBar(
                title = { FitText(title) },
                navigationIcon = { IconButton(onClick = onClose) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Retour") } },
                actions = { actions() },
            )
        },
    ) { pad ->
        Column(
            Modifier
                .fillMaxSize()
                .padding(pad)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp)
                .padding(bottom = 40.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            content = content,
        )
    }
}

@Composable
internal fun ToolHint(text: String) {
    Text(text, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
}

/** Barre d'utilisation : « Stockage — 87 Go utilisés sur 128 Go ». */
@Composable
internal fun UsageBar(label: String, used: Long, total: Long, icon: androidx.compose.ui.graphics.vector.ImageVector) {
    val cs = MaterialTheme.colorScheme
    val ratio = if (total > 0) (used.toFloat() / total).coerceIn(0f, 1f) else 0f
    val color = when {
        ratio > 0.9f -> cs.error
        ratio > 0.75f -> Color(0xFFE6A23C)
        else -> cs.primary
    }
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, null, Modifier.size(18.dp), tint = color)
            Spacer(Modifier.width(6.dp))
            Text(label, style = MaterialTheme.typography.titleSmall, modifier = Modifier.weight(1f))
            RawText("${(ratio * 100).toInt()} %", style = MaterialTheme.typography.titleSmall, color = color, fontWeight = FontWeight.SemiBold)
        }
        LinearProgressIndicator(progress = { ratio }, modifier = Modifier.fillMaxWidth().height(8.dp), color = color, trackColor = cs.surfaceContainerHighest)
        Text(
            I18n.trf("{0} utilisés sur {1} · {2} libres", formatSize(used), formatSize(total), formatSize(total - used)),
            style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant,
        )
    }
}

/** Accès à tous les fichiers : vérifié à chaque retour dans l'appli (après le passage par les réglages). */
@Composable
internal fun rememberStorageGranted(): Pair<Boolean, () -> Unit> {
    val ctx = LocalContext.current
    var granted by remember { mutableStateOf(StorageAccess.granted(ctx)) }
    val owner = LocalLifecycleOwner.current
    DisposableEffect(owner) {
        val obs = LifecycleEventObserver { _, e -> if (e == Lifecycle.Event.ON_RESUME) granted = StorageAccess.granted(ctx) }
        owner.lifecycle.addObserver(obs)
        onDispose { owner.lifecycle.removeObserver(obs) }
    }
    val legacy = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted = StorageAccess.granted(ctx) }
    val ask: () -> Unit = {
        LockGuard.external()
        if (Build.VERSION.SDK_INT >= 30) runCatching { ctx.startActivity(StorageAccess.settingsIntent(ctx)) }
            .onFailure { runCatching { ctx.startActivity(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION)) } }
        else legacy.launch(Manifest.permission.WRITE_EXTERNAL_STORAGE)
    }
    return granted to ask
}

@Composable
internal fun StorageAccessCard(onAsk: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    Surface(shape = MaterialTheme.shapes.large, color = cs.secondaryContainer, border = appBorder(), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Accès aux fichiers du téléphone", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold, color = cs.onSecondaryContainer)
            Text(
                "Pour parcourir et nettoyer les fichiers, Android demande d'autoriser Calepin à « gérer tous les fichiers ». " +
                    "Tout reste sur le téléphone : rien n'est envoyé nulle part.",
                style = MaterialTheme.typography.bodySmall, color = cs.onSecondaryContainer,
            )
            Button(onClick = onAsk) { Text("Autoriser l'accès") }
        }
    }
}

// ------------------------------------------------------------------ Téléphone (accueil des outils)

@Composable
fun PhoneScreen(onOptimizer: () -> Unit, onCleaner: () -> Unit, onFiles: () -> Unit, onClose: () -> Unit) {
    val ctx = LocalContext.current
    var tick by remember { mutableStateOf(0) }
    var refreshing by remember { mutableStateOf(false) }
    val storage = remember(tick) { PhoneInfo.storage() }
    val ram = remember(tick) { PhoneInfo.ram(ctx) }
    val battery = remember(tick) { PhoneInfo.battery(ctx) }
    // Actualiser aussi en revenant sur l'écran (après un nettoyage par exemple)
    LaunchedEffect(refreshing) {
        if (refreshing) { kotlinx.coroutines.delay(500); refreshing = false }
    }
    ToolScaffold("Téléphone", onClose, actions = {
        IconButton(onClick = { tick++; refreshing = true }) { Icon(Icons.Filled.Refresh, "Actualiser") }
    }) {
        if (refreshing) LinearProgressIndicator(Modifier.fillMaxWidth())
        OutlinedButton(onClick = { tick++; refreshing = true }, modifier = Modifier.fillMaxWidth()) {
            Icon(Icons.Filled.Refresh, null, Modifier.size(18.dp)); Text("  Actualiser")
        }
        Surface(shape = MaterialTheme.shapes.large, color = MaterialTheme.colorScheme.surfaceContainerLow, border = appBorder(), modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                UsageBar("Stockage", storage.used, storage.total, Icons.Filled.Storage)
                UsageBar("Mémoire vive", ram.used, ram.total, Icons.Filled.Memory)
                battery?.let { b ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Filled.BatteryChargingFull, null, Modifier.size(18.dp), tint = MaterialTheme.colorScheme.primary)
                        Spacer(Modifier.width(6.dp))
                        Text("Batterie", style = MaterialTheme.typography.titleSmall, modifier = Modifier.weight(1f))
                        RawText(
                            "${b.level} % · ${"%.0f".format(b.temperature)} °C" + if (b.charging) " · ⚡" else "",
                            style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold,
                        )
                    }
                }
            }
        }
        LinkCard("Optimiseur", Icons.Filled.Speed, "État du téléphone, mémoire, batterie, applis les plus lourdes", onOptimizer)
        LinkCard("Nettoyeur", Icons.Filled.CleaningServices, "Fichiers inutiles, doublons, gros fichiers", onCleaner)
        LinkCard("Fichiers", Icons.Filled.Folder, "Parcourir, ouvrir, partager, déplacer les fichiers du téléphone", onFiles)
    }
}

// ------------------------------------------------------------------ Optimiseur

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun OptimizerScreen(onCleaner: () -> Unit, onClose: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var tick by remember { mutableStateOf(0) }
    val storage = remember(tick) { PhoneInfo.storage() }
    val ram = remember(tick) { PhoneInfo.ram(ctx) }
    val battery = remember(tick) { PhoneInfo.battery(ctx) }
    var cache by remember { mutableStateOf(0L) }
    var apps by remember { mutableStateOf<List<AppSize>?>(null) }
    var busy by remember { mutableStateOf(false) }
    var report by remember { mutableStateOf<String?>(null) }
    LaunchedEffect(tick) {
        cache = withContext(Dispatchers.IO) { PhoneInfo.appCacheSize(ctx) }
    }
    LaunchedEffect(Unit) {
        apps = withContext(Dispatchers.IO) { runCatching { PhoneInfo.apps(ctx) }.getOrDefault(emptyList()) }
    }
    fun open(i: Intent) { LockGuard.external(); runCatching { ctx.startActivity(i) } }

    // Note globale : place libre, mémoire libre, température de la batterie
    val score = run {
        val s = (storage.free.toFloat() / storage.total).coerceIn(0f, 1f)
        val r = (ram.available.toFloat() / ram.total).coerceIn(0f, 1f)
        val t = battery?.temperature ?: 30f
        val heat = if (t > 42) 0.4f else if (t > 38) 0.7f else 1f
        ((minOf(1f, s * 2.5f) * 50 + minOf(1f, r * 2.5f) * 30 + heat * 20)).toInt().coerceIn(0, 100)
    }

    ToolScaffold("Optimiseur", onClose) {
        val cs = MaterialTheme.colorScheme
        Surface(shape = MaterialTheme.shapes.large, color = cs.primaryContainer, border = appBorder(), modifier = Modifier.fillMaxWidth()) {
            Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(contentAlignment = Alignment.Center) {
                    CircularProgressIndicator(
                        progress = { score / 100f }, modifier = Modifier.size(84.dp), strokeWidth = 8.dp,
                        color = if (score >= 70) cs.primary else if (score >= 45) Color(0xFFE6A23C) else cs.error,
                        trackColor = cs.surfaceContainerHighest,
                    )
                    RawText("$score", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold, color = cs.onPrimaryContainer)
                }
                Spacer(Modifier.width(16.dp))
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(
                        when {
                            score >= 75 -> "Ton téléphone est en forme"
                            score >= 50 -> "Quelques optimisations possibles"
                            else -> "Ton téléphone a besoin d'un coup de propre"
                        },
                        style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold, color = cs.onPrimaryContainer,
                    )
                    Button(enabled = !busy, onClick = {
                        busy = true
                        scope.launch {
                            val freedRam = withContext(Dispatchers.IO) { PhoneInfo.freeMemory(ctx) }
                            val freedCache = withContext(Dispatchers.IO) { PhoneInfo.clearAppCache(ctx) }
                            report = I18n.trf("Mémoire vive libérée : {0} · cache de Calepin vidé : {1}", formatSize(freedRam), formatSize(freedCache))
                            busy = false
                            tick++
                        }
                    }) {
                        if (busy) CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp, color = cs.onPrimary)
                        else Text("Optimiser maintenant")
                    }
                }
            }
        }
        report?.let { Text(it, style = MaterialTheme.typography.bodyMedium, color = cs.primary) }

        FoldSection("Stockage", Icons.Filled.Storage, summary = I18n.trf("{0} libres", formatSize(storage.free)), startOpen = true) {
            UsageBar("Stockage", storage.used, storage.total, Icons.Filled.Storage)
            Text(I18n.trf("Cache de Calepin : {0}", formatSize(cache)), style = MaterialTheme.typography.bodyMedium)
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = onCleaner) { Text("Ouvrir le nettoyeur") }
                OutlinedButton(onClick = { open(Intent(Settings.ACTION_INTERNAL_STORAGE_SETTINGS)) }) { Text("Réglages du stockage") }
            }
        }
        FoldSection("Mémoire vive", Icons.Filled.Memory, summary = I18n.trf("{0} libres", formatSize(ram.available))) {
            UsageBar("Mémoire vive", ram.used, ram.total, Icons.Filled.Memory)
            ToolHint(
                "« Optimiser maintenant » ferme les applis restées en arrière-plan. Android gère lui-même la mémoire : " +
                    "il est normal qu'elle soit bien remplie, c'est ce qui rend les applis rapides à rouvrir."
            )
        }
        battery?.let { b ->
            FoldSection("Batterie", Icons.Filled.BatteryChargingFull, summary = "${b.level} %") {
                InfoLine("Charge", "${b.level} %" + if (b.charging) " · " + I18n.tr("en charge") else "")
                InfoLine("Température", "%.1f °C".format(b.temperature))
                InfoLine("État", I18n.tr(b.health))
                if (b.voltage > 0) InfoLine("Tension", "%.2f V".format(b.voltage / 1000f))
                if (b.temperature > 40) ToolHint("La batterie chauffe : ferme les jeux ou la navigation GPS, retire la coque pendant la charge.")
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { open(Intent(Intent.ACTION_POWER_USAGE_SUMMARY)) }) { Text("Utilisation de la batterie") }
                    OutlinedButton(onClick = { open(Intent(Settings.ACTION_BATTERY_SAVER_SETTINGS)) }) { Text("Économiseur d'énergie") }
                }
            }
        }
        FoldSection("Applis les plus lourdes", Icons.Filled.Apps, summary = apps?.let { I18n.trf("{0} applis installées", it.size) }) {
            val list = apps
            if (list == null) CircularProgressIndicator(Modifier.size(24.dp))
            else {
                ToolHint("Touche une appli pour voir sa place réelle (données et cache) ou la désinstaller.")
                list.filter { !it.system }.take(15).forEach { app ->
                    Row(
                        Modifier.fillMaxWidth().clickable { open(PhoneInfo.appDetailsIntent(app.pkg)) }.padding(vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Column(Modifier.weight(1f)) {
                            RawText(app.label, style = MaterialTheme.typography.bodyLarge, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            RawText(formatSize(app.size), style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
                        }
                        if (app.pkg != ctx.packageName) TextButton(onClick = { open(PhoneInfo.uninstallIntent(app.pkg)) }) { Text("Désinstaller") }
                    }
                }
                OutlinedButton(onClick = { open(Intent(Settings.ACTION_MANAGE_APPLICATIONS_SETTINGS)) }) { Text("Toutes les applis") }
            }
        }
    }
}

@Composable
private fun InfoLine(label: String, value: String) {
    Row(Modifier.fillMaxWidth()) {
        Text(label, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.weight(1f))
        RawText(value, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Medium)
    }
}

// ------------------------------------------------------------------ Nettoyeur

@Composable
fun CleanerScreen(onClose: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val (granted, ask) = rememberStorageGranted()
    var result by remember { mutableStateOf<ScanResult?>(null) }
    var scanning by remember { mutableStateOf(false) }
    var scanned by remember { mutableStateOf(0) }
    var selected by remember { mutableStateOf<Set<String>>(emptySet()) }
    var confirm by remember { mutableStateOf(false) }
    var round by remember { mutableStateOf(0) }

    LaunchedEffect(granted, round) {
        scanning = true
        scanned = 0
        val r = Cleaner.scan(ctx) { n, _ -> scanned = n }
        result = r
        // Cochés d'office : les catégories sans risque, et pour les doublons rien
        selected = r.items.filterKeys { it.preselected }.values.flatten().map { it.file.absolutePath }.toSet()
        scanning = false
    }

    val all = result?.items?.values?.flatten().orEmpty()
    val chosen = all.filter { it.file.absolutePath in selected }
    val chosenSize = chosen.sumOf { it.size }

    ToolScaffold("Nettoyeur", onClose) {
        val cs = MaterialTheme.colorScheme
        if (!granted) StorageAccessCard(ask)
        Surface(shape = MaterialTheme.shapes.large, color = cs.primaryContainer, border = appBorder(), modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                if (scanning) {
                    Text("Analyse du téléphone…", style = MaterialTheme.typography.titleMedium, color = cs.onPrimaryContainer)
                    LinearProgressIndicator(Modifier.fillMaxWidth())
                    Text(I18n.trf("{0} fichiers examinés", scanned), style = MaterialTheme.typography.bodySmall, color = cs.onPrimaryContainer)
                } else {
                    RawText(formatSize(chosenSize), style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold, color = cs.onPrimaryContainer)
                    Text(I18n.trf("à libérer · {0} éléments sélectionnés", chosen.size), style = MaterialTheme.typography.bodyMedium, color = cs.onPrimaryContainer)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(enabled = chosen.isNotEmpty(), onClick = { confirm = true }) { Text("Nettoyer") }
                        OutlinedButton(onClick = { round++ }) { Text("Analyser à nouveau") }
                    }
                }
            }
        }
        result?.let { r ->
            JunkKind.entries.forEach { kind ->
                val items = r.items[kind].orEmpty()
                if (items.isEmpty()) return@forEach
                val sel = items.filter { it.file.absolutePath in selected }
                FoldSection(
                    kind.label,
                    iconFor(kind),
                    summary = I18n.trf("{0} · {1} élément{2}", formatSize(items.sumOf { it.size }), items.size, if (items.size > 1) "s" else ""),
                ) {
                    ToolHint(kind.desc)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        val allSel = sel.size == items.filter { !it.keep }.size && sel.isNotEmpty()
                        Checkbox(checked = allSel, onCheckedChange = { on ->
                            val paths = items.filter { !it.keep }.map { it.file.absolutePath }
                            selected = if (on) selected + paths else selected - paths.toSet()
                        })
                        Text(if (kind == JunkKind.DUPLICATES) "Cocher toutes les copies (un exemplaire gardé)" else "Tout cocher", style = MaterialTheme.typography.bodyMedium)
                    }
                    var shown by remember { mutableStateOf(60) }
                    var lastGroup = -1
                    items.sortedWith(compareBy<JunkFile> { it.group }.thenByDescending { it.size }).let { if (kind == JunkKind.DUPLICATES) it else items }
                        .take(shown).forEach { j ->
                            if (kind == JunkKind.DUPLICATES && j.group != lastGroup) {
                                lastGroup = j.group
                                SubTitle(j.file.name)
                            }
                            JunkRow(j, j.file.absolutePath in selected) { on ->
                                selected = if (on) selected + j.file.absolutePath else selected - j.file.absolutePath
                            }
                        }
                    if (items.size > shown) TextButton(onClick = { shown += 100 }) { Text(I18n.trf("Voir {0} de plus", minOf(100, items.size - shown))) }
                }
            }
            if (all.isEmpty() && !scanning) ToolHint("Rien à nettoyer : ton téléphone est propre.")
        }
        ToolHint(
            "Android ne permet pas à une appli de vider le cache des autres applis. Pour une appli précise : " +
                "Optimiseur → Applis les plus lourdes → touche l'appli → Stockage → Vider le cache."
        )
    }

    if (confirm) {
        AlertDialog(
            onDismissRequest = { confirm = false },
            title = { Text("Supprimer ces fichiers ?") },
            text = { Text(I18n.trf("{0} éléments ({1}) seront supprimés définitivement.", chosen.size, formatSize(chosenSize))) },
            confirmButton = {
                TextButton(onClick = {
                    confirm = false
                    scope.launch {
                        val freed = Cleaner.delete(chosen)
                        I18n.toast(ctx, I18n.trf("{0} libérés", formatSize(freed)), Toast.LENGTH_LONG).show()
                        round++
                    }
                }) { Text("Supprimer", color = MaterialTheme.colorScheme.error) }
            },
            dismissButton = { TextButton(onClick = { confirm = false }) { Text("Annuler") } },
        )
    }
}

private fun iconFor(k: JunkKind) = when (k) {
    JunkKind.APP_CACHE -> Icons.Filled.CleaningServices
    JunkKind.TEMP -> Icons.Filled.CleaningServices
    JunkKind.THUMBS -> androidx.compose.material.icons.Icons.Filled.Folder
    JunkKind.EMPTY -> Icons.Filled.Folder
    JunkKind.APK -> Icons.Filled.Apps
    JunkKind.DUPLICATES -> Icons.Filled.Storage
    JunkKind.BIG -> Icons.Filled.Storage
}

@Composable
private fun JunkRow(j: JunkFile, checked: Boolean, onCheck: (Boolean) -> Unit) {
    val root = StorageAccess.root.absolutePath
    Row(
        Modifier.fillMaxWidth().clickable { onCheck(!checked) },
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Checkbox(checked = checked, onCheckedChange = onCheck)
        Column(Modifier.weight(1f)) {
            RawText(j.file.name, style = MaterialTheme.typography.bodyMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
            RawText(
                (j.file.parent ?: "").removePrefix(root).ifEmpty { "/" } + if (j.keep) " · " + I18n.tr("exemplaire gardé") else "",
                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis,
            )
        }
        if (j.size > 0) RawText(formatSize(j.size), style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.SemiBold)
    }
}
