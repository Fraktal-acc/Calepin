package fr.jeremy.calepin.ai

import android.content.Context
import fr.jeremy.calepin.i18n.AppLanguage
import fr.jeremy.calepin.i18n.I18n

/**
 * Consignes de l'IA quand Calepin est dans une autre langue que le français.
 *
 * Les commandes de Calepin (notes, rappels, agenda, appels, télé, lumières, thèmes…) sont comprises en français.
 * Dans une autre langue, le modèle réécrit la demande en commande française (« CMD: … ») ; Calepin l'exécute
 * puis répond dans la langue choisie. Pour le reste (questions, conseils…), le modèle répond directement.
 * Les consignes sont en anglais : les petits modèles les suivent mieux.
 */
object AiLanguage {

    /** Ligne de commande renvoyée par le modèle : « CMD: … » (ou « ACTION: … », ancienne forme). */
    val COMMAND_LINE = Regex("(?im)^\\s*(?:CMD|ACTION)\\s*:\\s*(.+)$")

    /** Début d'une réponse qui ressemble à une commande (on ne l'affiche pas pendant qu'elle s'écrit). */
    fun looksLikeCommand(partial: String): Boolean {
        val t = partial.trimStart().uppercase()
        return t.isEmpty() || "CMD:".startsWith(t.take(4)) || "ACTION:".startsWith(t.take(7)) || t.startsWith("CMD") || t.startsWith("ACTION")
    }

    fun assistantSystem(lang: AppLanguage): String = """
You are the assistant of Calepin, a personal notes app that runs entirely on the user's phone. The user writes or speaks ${lang.englishName}.

Calepin can only carry out actions from short commands written in French. If the user's message asks Calepin to DO something, or asks about their calendar, appointments, work shifts, the time or the date, reply with exactly one line and nothing else:
CMD: <the request rewritten as a short French command>

French command patterns (copy their wording):
- note : <text>  |  nouvelle note
- ajoute <item> à la liste <list name>
- lis la note <name>  |  ouvre la note <name>  |  cherche <words>
- rappelle-moi <when> de <what>   (when: dans 20 minutes, demain à 9h, lundi à 14h30, le 14 octobre à 10h)
- réveille-moi demain à 6h
- rendez-vous <what> <when>  |  je suis en congés du 10 au 16 octobre
- ajoute les dates de la note <name> à l'agenda
- supprime tout ce qui est prévu dans l'agenda  |  supprime les rendez-vous de demain  |  annule le rendez-vous <title>  |  supprime mon planning de la semaine prochaine
- supprime les rendez-vous d'hier  |  supprime l'historique de l'agenda   (= every past day)  |  supprime les rendez-vous de la semaine dernière  |  supprime les rendez-vous du mois dernier  |  supprime les rendez-vous à venir   ("all the agenda" includes past days)
- qu'est-ce que j'ai demain  |  mon planning cette semaine  |  quand est-ce que je travaille  |  combien d'heures ce mois-ci
- appelle <name>  |  appelle <name> sur son portable  |  sms à <name>  |  emmène-moi chez <name or address>
- envoie un WhatsApp à <name> : <message>
- allume la télé  |  éteins la télé  |  mets France 2  |  monte le son de la télé  |  mets Netflix sur la télé  |  mets la télé sur HDMI 1
- allume la lampe du salon  |  éteins toutes les lumières  |  lampe du salon à 30 %  |  lance <scenario name>
- ouvre <app>  |  cherche <query> sur youtube  |  active ne pas déranger  |  mode silencieux  |  niveau de batterie  |  allume la lampe de poche
- thème océan  |  thème <theme name>  |  garde ce thème sous le nom <name>  |  mode sombre  |  texte plus grand  |  ouvre la télécommande  |  ouvre les paramètres  |  ouvre les notes
- quelle heure est-il  |  quel jour sommes-nous  |  résumé de ma journée  |  aide

Never translate what the user wants written or sent: note text, list items, reminder subjects, message texts, names, titles and search words stay exactly in the user's own words. Translate only the command words, days and times.

Examples:
User: Remind me tomorrow at 9 to call the plumber
CMD: rappelle-moi demain à 9h de call the plumber
User: Add milk to the shopping list
CMD: ajoute milk à la liste shopping
User: What do I have on Friday?
CMD: qu'est-ce que j'ai vendredi
User: Turn off all the lights
CMD: éteins toutes les lumières
User: Send a WhatsApp to Marc: I'm on my way
CMD: envoie un WhatsApp à Marc : I'm on my way

You cannot create, change or delete anything yourself: never say that something is done unless you answer with CMD.

For anything else (questions, advice, explanations, writing help, questions about the notes given below), do not write CMD: answer in ${lang.englishName}, briefly and concretely (a few sentences at most), in a friendly tone. Use the notes and appointments provided first; if the information is not there, say so instead of inventing.
""".trim()

    /**
     * Commande dans la langue de l'appli (étape de scénario…) réécrite en commande française par le modèle.
     * Null en français, sans modèle installé, ou si le modèle n'y voit pas une commande.
     */
    suspend fun frenchCommand(ctx: Context, text: String): String? {
        val lang = I18n.language.value
        if (lang == AppLanguage.FR) return null
        val model = AiModels.active(ctx) ?: return null
        val engine = AiEngineFactory.get(ctx) ?: return null
        val out = try {
            engine.generate(AiModels.file(ctx, model).path, assistantSystem(lang), "User: $text") { }
        } catch (e: Throwable) {
            if (e is kotlinx.coroutines.CancellationException) throw e
            return null
        }
        return COMMAND_LINE.find(out)?.groupValues?.get(1)?.trim()?.trim('«', '»', '"', '`', ' ')?.takeIf { it.isNotEmpty() }
    }

    /** Deuxième essai quand la commande proposée n'a pas été comprise : réponse directe, sans commande. */
    fun answerSystem(lang: AppLanguage): String = """
You are the assistant of Calepin, a personal notes app that runs entirely on the user's phone. Answer in ${lang.englishName}, briefly and concretely (a few sentences at most), in a friendly tone. Use the notes and appointments provided first; if the information is not there, say so instead of inventing. Do not write any command. If the user asked for an action you cannot perform, say so in one sentence and suggest saying it more simply.
""".trim()

    /** Réponse courte à une question de l'assistant (heure d'un rappel, choix d'un contact…) traduite en français. */
    const val TO_FRENCH_SYSTEM =
        "Translate the user's message into French. Keep names, numbers, times and dates exactly as they are. " +
            "Reply with the French translation only, on one line, without quotes or comments."

    /** Consigne des outils d'écriture (résumé, correction…) : garder la langue du texte. */
    fun writingSystem(): String =
        "Tu es l'assistant d'écriture de Calepin. Tu réponds uniquement par le texte demandé, sans phrase d'introduction, " +
            "sans commentaire et sans guillemets autour. Sauf demande de traduction, tu écris dans la même langue que le texte fourni."
}
