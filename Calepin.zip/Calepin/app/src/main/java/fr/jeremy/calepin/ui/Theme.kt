package fr.jeremy.calepin.ui

import android.content.Context
import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Event
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Place
import androidx.compose.material3.ColorScheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import fr.jeremy.calepin.detect.EntityType
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

// ------------------------------------------------------------------ Choix d'apparence

/** Palettes de couleurs : [primary], [secondary], [tertiary], et la teinte des fonds [neutral]. */
enum class Palette(val label: String, val primary: Long, val secondary: Long, val tertiary: Long, val neutral: Long) {
    MEDITERRANEE("Méditerranée", 0xFF1F5F7A, 0xFFB4602A, 0xFF55703A, 0xFFF8F7F3),
    OCEAN("Océan", 0xFF0B57D0, 0xFF00838F, 0xFF5C6BC0, 0xFFF5F8FD),
    FORET("Forêt", 0xFF2E6B3F, 0xFF8D6E2F, 0xFF3F7F7A, 0xFFF5F7F2),
    LAVANDE("Lavande", 0xFF6750A4, 0xFF9C4F8C, 0xFF4F6FA8, 0xFFF8F5FB),
    SOLEIL("Soleil", 0xFFB45309, 0xFFC2410C, 0xFF7C6F00, 0xFFFBF7F0),
    CORAIL("Corail", 0xFFC2410C, 0xFFBE185D, 0xFF0F766E, 0xFFFCF6F4),
    ROSE("Rose", 0xFFB0306A, 0xFF8E4B9A, 0xFFC0584A, 0xFFFCF5F8),
    ARDOISE("Ardoise", 0xFF37474F, 0xFF5D6B75, 0xFF6D5D4F, 0xFFF6F7F8),
    DYNAMIQUE("Couleurs du fond d'écran", 0xFF1F5F7A, 0xFFB4602A, 0xFF55703A, 0xFFF8F7F3),
}

enum class DarkMode(val label: String) { SYSTEM("Comme le téléphone"), LIGHT("Clair"), DARK("Sombre"), BLACK("Noir (écran OLED)") }

enum class TextSize(val label: String, val scale: Float) { SMALL("Petit", 0.9f), NORMAL("Normal", 1f), LARGE("Grand", 1.15f), XLARGE("Très grand", 1.3f) }

enum class ShapeStyle(val label: String, val small: Int, val medium: Int, val large: Int) {
    ROUNDED("Arrondi", 10, 14, 22), SOFT("Doux", 6, 10, 14), SQUARE("Carré", 2, 4, 6), PILL("Très arrondi", 16, 24, 32),
}

enum class HomeStyle(val label: String) { GRID("Tuiles"), LIST("Liste"), COMPACT("Compact") }

/** Réglages d'apparence, partagés par tous les écrans (et l'écran d'alarme). */
class Appearance private constructor(ctx: Context) {
    private val p = ctx.applicationContext.getSharedPreferences("calepin_appearance", Context.MODE_PRIVATE)

    private inline fun <reified T : Enum<T>> load(key: String, def: T): T =
        p.getString(key, null)?.let { n -> enumValues<T>().firstOrNull { it.name == n } } ?: def

    private val _palette = MutableStateFlow(load("palette", Palette.MEDITERRANEE))
    val palette: StateFlow<Palette> = _palette
    fun setPalette(v: Palette) { p.edit().putString("palette", v.name).apply(); _palette.value = v }

    private val _dark = MutableStateFlow(load("dark", DarkMode.SYSTEM))
    val dark: StateFlow<DarkMode> = _dark
    fun setDark(v: DarkMode) { p.edit().putString("dark", v.name).apply(); _dark.value = v }

    private val _text = MutableStateFlow(load("text", TextSize.NORMAL))
    val text: StateFlow<TextSize> = _text
    fun setText(v: TextSize) { p.edit().putString("text", v.name).apply(); _text.value = v }

    private val _shapes = MutableStateFlow(load("shapes", ShapeStyle.ROUNDED))
    val shapes: StateFlow<ShapeStyle> = _shapes
    fun setShapes(v: ShapeStyle) { p.edit().putString("shapes", v.name).apply(); _shapes.value = v }

    private val _home = MutableStateFlow(load("home", HomeStyle.GRID))
    val home: StateFlow<HomeStyle> = _home
    fun setHome(v: HomeStyle) { p.edit().putString("home", v.name).apply(); _home.value = v }

    companion object {
        @Volatile private var instance: Appearance? = null
        fun get(ctx: Context): Appearance = instance ?: synchronized(this) { instance ?: Appearance(ctx).also { instance = it } }
    }
}

// ------------------------------------------------------------------ Construction des couleurs

private fun c(v: Long) = Color(v)

private fun lightScheme(pal: Palette): ColorScheme {
    val p = c(pal.primary); val s = c(pal.secondary); val t = c(pal.tertiary); val n = c(pal.neutral)
    val ink = Color(0xFF1B1C1E)
    return lightColorScheme(
        primary = p, onPrimary = Color.White,
        primaryContainer = lerp(p, Color.White, 0.82f), onPrimaryContainer = lerp(p, Color.Black, 0.6f),
        secondary = s, onSecondary = Color.White,
        secondaryContainer = lerp(s, Color.White, 0.8f), onSecondaryContainer = lerp(s, Color.Black, 0.65f),
        tertiary = t, onTertiary = Color.White,
        tertiaryContainer = lerp(t, Color.White, 0.8f), onTertiaryContainer = lerp(t, Color.Black, 0.65f),
        background = n, onBackground = ink, surface = n, onSurface = ink,
        surfaceVariant = lerp(n, p, 0.08f), onSurfaceVariant = lerp(ink, p, 0.25f).copy(alpha = 0.85f),
        surfaceContainerLowest = Color.White,
        surfaceContainerLow = lerp(n, p, 0.03f),
        surfaceContainer = lerp(n, p, 0.06f),
        surfaceContainerHigh = lerp(n, p, 0.09f),
        surfaceContainerHighest = lerp(n, p, 0.12f),
        outline = lerp(ink, n, 0.55f), outlineVariant = lerp(ink, n, 0.8f),
    )
}

private fun darkScheme(pal: Palette, black: Boolean): ColorScheme {
    val p = lerp(c(pal.primary), Color.White, 0.5f); val s = lerp(c(pal.secondary), Color.White, 0.45f); val t = lerp(c(pal.tertiary), Color.White, 0.45f)
    val base = if (black) Color.Black else lerp(Color(0xFF101214), c(pal.primary), 0.06f)
    val ink = Color(0xFFE4E3E0)
    return darkColorScheme(
        primary = p, onPrimary = lerp(c(pal.primary), Color.Black, 0.6f),
        primaryContainer = lerp(c(pal.primary), Color.Black, 0.35f), onPrimaryContainer = lerp(p, Color.White, 0.6f),
        secondary = s, onSecondary = lerp(c(pal.secondary), Color.Black, 0.6f),
        secondaryContainer = lerp(c(pal.secondary), Color.Black, 0.45f), onSecondaryContainer = lerp(s, Color.White, 0.6f),
        tertiary = t, onTertiary = lerp(c(pal.tertiary), Color.Black, 0.6f),
        tertiaryContainer = lerp(c(pal.tertiary), Color.Black, 0.45f), onTertiaryContainer = lerp(t, Color.White, 0.6f),
        background = base, onBackground = ink, surface = base, onSurface = ink,
        surfaceVariant = lerp(base, p, 0.12f), onSurfaceVariant = lerp(ink, p, 0.2f).copy(alpha = 0.8f),
        surfaceContainerLowest = base,
        surfaceContainerLow = lerp(base, p, if (black) 0.06f else 0.05f),
        surfaceContainer = lerp(base, p, if (black) 0.09f else 0.08f),
        surfaceContainerHigh = lerp(base, p, 0.12f),
        surfaceContainerHighest = lerp(base, p, 0.15f),
        outline = lerp(ink, base, 0.5f), outlineVariant = lerp(ink, base, 0.78f),
    )
}

@Composable
fun CalepinTheme(content: @Composable () -> Unit) {
    val ctx = LocalContext.current
    val a = remember { Appearance.get(ctx) }
    val palette by a.palette.collectAsStateWithLifecycle()
    val mode by a.dark.collectAsStateWithLifecycle()
    val text by a.text.collectAsStateWithLifecycle()
    val shapeStyle by a.shapes.collectAsStateWithLifecycle()
    val system = isSystemInDarkTheme()
    val dark = when (mode) {
        DarkMode.SYSTEM -> system
        DarkMode.LIGHT -> false
        DarkMode.DARK, DarkMode.BLACK -> true
    }
    val black = mode == DarkMode.BLACK
    val scheme = when {
        palette == Palette.DYNAMIQUE && Build.VERSION.SDK_INT >= 31 ->
            if (dark) dynamicDarkColorScheme(ctx).let { if (black) it.copy(background = Color.Black, surface = Color.Black) else it }
            else dynamicLightColorScheme(ctx)
        dark -> darkScheme(palette, black)
        else -> lightScheme(palette)
    }
    val shapes = Shapes(
        extraSmall = RoundedCornerShape((shapeStyle.small / 2).dp),
        small = RoundedCornerShape(shapeStyle.small.dp),
        medium = RoundedCornerShape(shapeStyle.medium.dp),
        large = RoundedCornerShape(shapeStyle.large.dp),
        extraLarge = RoundedCornerShape((shapeStyle.large + 6).dp),
    )
    val density = LocalDensity.current
    CompositionLocalProvider(LocalDensity provides Density(density.density, density.fontScale * text.scale)) {
        MaterialTheme(colorScheme = scheme, shapes = shapes, content = content)
    }
}

fun EntityType.icon(): ImageVector = when (this) {
    EntityType.PHONE -> Icons.Filled.Phone
    EntityType.EMAIL -> Icons.Filled.Email
    EntityType.URL -> Icons.Filled.Language
    EntityType.DATE -> Icons.Filled.Event
    EntityType.ADDRESS -> Icons.Filled.Place
}
