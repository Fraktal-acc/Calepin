package fr.jeremy.calepin.ui

import android.app.Activity
import android.content.Context
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat
import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.CornerBasedShape
import androidx.compose.foundation.shape.CutCornerShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Event
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Place
import androidx.compose.material3.ColorScheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.foundation.layout.fillMaxSize
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import fr.jeremy.calepin.detect.EntityType
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

// ------------------------------------------------------------------ Choix d'apparence

/**
 * Décor propre à un thème : fond (fixe ou animé) et style des icônes « selon le thème ».
 * [animated] : le décor bouge (si les animations sont activées).
 */
enum class Deco(val animated: Boolean = false) {
    NONE, PAPER,
    NEON(true), GRIMOIRE(true), TERMINAL(true), SUNSET(true), AURORA(true),
    STARS(true), SNOW(true), FOG(true), BLOOD(true), RAIN(true), LEAVES(true), ENERGY(true),
    SHADOWS(true), FIREFLIES(true), BUBBLES(true), STORM(true), SAKURA(true),
    WAVES(true), LAVA(true), BOKEH(true), CONFETTI(true), DUNES(true), NEBULA(true), FLAMES(true), HEARTS(true),
    CIRCUIT(true), GEARS(true),
    /** Soleil qui rayonne, nuages qui passent : utilisés par le thème selon l'heure et la météo. */
    SUNNY(true), CLOUDS(true),
    /** Paysages peints (voir Landscapes.kt). */
    MOUNTAINS(true), SEASCAPE(true), FOREST(true), CITY(true), STARRY_DESERT(true), LAKE_AURORA(true),
    TROPICAL(true), SAVANNA(true), LAVENDER(true), RIVIERA(true),
    /** Décors inspirés d'autres cultures. */
    SEIGAIHA(true), LANTERNS(true), MANDALA(true), ZELLIGE(true), PAPEL(true), MEANDER(true),
}

/**
 * Thèmes : [primary], [secondary], [tertiary] et la teinte des fonds [neutral].
 * [forceDark] : null = suit le réglage clair/sombre, vrai/faux = le thème impose son ambiance.
 * [vivid] : couleurs gardées éclatantes en mode sombre (néon…).
 * [font] : police du texte ; [titleFont] : police des titres.
 * [group] : rubrique dans l'écran Apparence.
 */
enum class Palette(
    val label: String,
    val primary: Long,
    val secondary: Long,
    val tertiary: Long,
    val neutral: Long,
    val forceDark: Boolean? = null,
    val vivid: Boolean = false,
    val font: FontChoice = FontChoice.SANS,
    val shape: ShapeStyle = ShapeStyle.ROUNDED,
    val deco: Deco = Deco.NONE,
    val titleFont: FontChoice = font,
    val group: Int = 0,
) {
    MEDITERRANEE("Méditerranée", 0xFF1F5F7A, 0xFFB4602A, 0xFF55703A, 0xFFF8F7F3),
    OCEAN("Océan", 0xFF0B57D0, 0xFF00838F, 0xFF5C6BC0, 0xFFF5F8FD),
    FORET("Forêt", 0xFF2E6B3F, 0xFF8D6E2F, 0xFF3F7F7A, 0xFFF5F7F2),
    LAVANDE("Lavande", 0xFF6750A4, 0xFF9C4F8C, 0xFF4F6FA8, 0xFFF8F5FB),
    SOLEIL("Soleil", 0xFFB45309, 0xFFC2410C, 0xFF7C6F00, 0xFFFBF7F0),
    CORAIL("Corail", 0xFFC2410C, 0xFFBE185D, 0xFF0F766E, 0xFFFCF6F4),
    ROSE("Rose", 0xFFB0306A, 0xFF8E4B9A, 0xFFC0584A, 0xFFFCF5F8),
    ARDOISE("Ardoise", 0xFF37474F, 0xFF5D6B75, 0xFF6D5D4F, 0xFFF6F7F8),
    PARCHEMIN("Parchemin", 0xFF7A4E2D, 0xFF8E2C2C, 0xFF5B6B2F, 0xFFF3E9D2, forceDark = false, font = FontChoice.SERIF, shape = ShapeStyle.SOFT, deco = Deco.PAPER, titleFont = FontChoice.MEDIEVALE),
    MENTHE("Menthe", 0xFF0F7B6C, 0xFF3A7CA5, 0xFF7A8F2E, 0xFFF3F9F7),
    TURQUOISE("Turquoise", 0xFF00838F, 0xFFE64A19, 0xFF6A1B9A, 0xFFF2FAFA),
    INDIGO("Indigo", 0xFF3949AB, 0xFF00897B, 0xFFD81B60, 0xFFF6F6FC),
    CERISE("Cerise", 0xFFC2185B, 0xFF5E35B1, 0xFFEF6C00, 0xFFFDF4F7),
    BORDEAUX("Bordeaux", 0xFF7B1E3A, 0xFFA8763E, 0xFF4E5B8A, 0xFFFAF5F5, font = FontChoice.SERIF, titleFont = FontChoice.SERIF),
    SABLE("Sable", 0xFF8A6A3B, 0xFF4F7A6B, 0xFFA0522D, 0xFFFAF6EE, shape = ShapeStyle.SOFT),
    OLIVE("Olive", 0xFF5B6B2F, 0xFF8D5524, 0xFF2F6B6B, 0xFFF7F7F0),
    MONOCHROME("Monochrome", 0xFF212121, 0xFF616161, 0xFF424242, 0xFFF7F7F7, shape = ShapeStyle.SQUARE),
    NUIT("Nuit bleue", 0xFF8AB4F8, 0xFFF28B82, 0xFF81C995, 0xFF0F1724, forceDark = true, vivid = true),
    GRAPHITE("Graphite", 0xFFB0BEC5, 0xFFFFB74D, 0xFF80CBC4, 0xFF121416, forceDark = true, vivid = true, shape = ShapeStyle.SOFT),

    // Ambiances (sombres, souvent animées)
    CYBERPUNK("Cyberpunk", 0xFFFF2BD6, 0xFF00F0FF, 0xFFF5FF3B, 0xFF0A0614, true, true, FontChoice.MONO, ShapeStyle.CUT, Deco.NEON, FontChoice.FUTURISTE, 1),
    DARK_FANTASY("Dark fantasy", 0xFFB3243A, 0xFFD4AF37, 0xFF8A5CC7, 0xFF120B0E, true, true, FontChoice.SERIF, ShapeStyle.CUT, Deco.GRIMOIRE, FontChoice.GOTHIQUE, 1),
    SYNTHWAVE("Synthwave", 0xFFFF6EC7, 0xFFFF9E3D, 0xFF9D6BFF, 0xFF1A0B2E, true, true, FontChoice.SANS, ShapeStyle.PILL, Deco.SUNSET, FontChoice.HOLOGRAMME, 1),
    TERMINAL("Terminal rétro", 0xFF33FF66, 0xFFFFB000, 0xFF3FD0C9, 0xFF030803, true, true, FontChoice.MONO, ShapeStyle.SQUARE, Deco.TERMINAL, FontChoice.PIXEL, 1),
    AURORE("Aurore boréale", 0xFF2DD4BF, 0xFFA78BFA, 0xFF4ADE80, 0xFF06121C, true, true, deco = Deco.AURORA, group = 1),
    LUCIOLES("Nuit des lucioles", 0xFFE8F56B, 0xFF7FD18B, 0xFFFFB86B, 0xFF07130C, true, true, FontChoice.SANS, ShapeStyle.PILL, Deco.FIREFLIES, FontChoice.DOUCE, 1),
    ABYSSES("Abysses", 0xFF3DDCFF, 0xFF7B7CFF, 0xFF2EF2B5, 0xFF020B18, true, true, deco = Deco.BUBBLES, shape = ShapeStyle.PILL, group = 1),
    ORAGE("Orage", 0xFFB9C7FF, 0xFFFFE066, 0xFF8FA3B8, 0xFF0B0E16, true, true, deco = Deco.STORM, titleFont = FontChoice.CONDENSEE, group = 1),
    SAKURA("Sakura", 0xFFD94F7A, 0xFF6B8F71, 0xFFB78BC9, 0xFFFFF6F8, false, false, FontChoice.SANS, ShapeStyle.PILL, Deco.SAKURA, FontChoice.DOUCE, 1),
    LAGON("Lagon", 0xFF00BCD4, 0xFFFFD54F, 0xFF26A69A, 0xFF03161F, true, true, FontChoice.SANS, ShapeStyle.PILL, Deco.WAVES, FontChoice.DOUCE, 1),
    LAVE("Lampe à lave", 0xFFFF5722, 0xFFFFC107, 0xFFE91E63, 0xFF1A0705, true, true, FontChoice.SANS, ShapeStyle.PILL, Deco.LAVA, FontChoice.CONDENSEE, 1),
    VILLE("Lumières de la ville", 0xFFFFB74D, 0xFF64B5F6, 0xFFF06292, 0xFF0D0D14, true, true, FontChoice.SANS, ShapeStyle.ROUNDED, Deco.BOKEH, FontChoice.CONDENSEE, 1),
    FETE("Fête", 0xFFE91E63, 0xFF0288D1, 0xFFF9A825, 0xFFFFFBF2, false, false, FontChoice.SANS, ShapeStyle.PILL, Deco.CONFETTI, FontChoice.MARQUEUR, 1),
    DESERT("Désert", 0xFFE0A050, 0xFFC1440E, 0xFF5D8AA8, 0xFF1E140C, true, true, FontChoice.SERIF, ShapeStyle.SOFT, Deco.DUNES, FontChoice.CONDENSEE, 1),
    NEBULEUSE("Nébuleuse", 0xFFB388FF, 0xFFFF80AB, 0xFF80D8FF, 0xFF07051A, true, true, FontChoice.SANS, ShapeStyle.ROUNDED, Deco.NEBULA, FontChoice.FUTURISTE, 1),
    BRASIER("Brasier", 0xFFFF6D00, 0xFFFFD600, 0xFFD50000, 0xFF120603, true, true, FontChoice.SANS, ShapeStyle.CUT, Deco.FLAMES, FontChoice.CONDENSEE, 1),
    ROMANCE("Romance", 0xFFD81B60, 0xFFAD1457, 0xFFFF7043, 0xFFFFF5F7, false, false, FontChoice.SERIF, ShapeStyle.PILL, Deco.HEARTS, FontChoice.DOUCE, 1),
    AUTOMNE("Automne", 0xFFD35400, 0xFF8E5B2E, 0xFFB7950B, 0xFFFBF5EC, false, false, FontChoice.SERIF, ShapeStyle.SOFT, Deco.LEAVES, FontChoice.MARQUEUR, 1),
    HIVER("Nuit d'hiver", 0xFF90CAF9, 0xFFB0BEC5, 0xFFCE93D8, 0xFF0B1622, true, true, FontChoice.SANS, ShapeStyle.ROUNDED, Deco.SNOW, FontChoice.DOUCE, 1),

    // Inspirés de films, séries et mangas (couleurs et ambiances, sans logos ni personnages)
    GALAXIE("Galaxie lointaine", 0xFF3FA9FF, 0xFFFF3B3B, 0xFFFFD34D, 0xFF05070F, true, true, FontChoice.SANS, ShapeStyle.SQUARE, Deco.STARS, FontChoice.FUTURISTE, 2),
    ROYAUMES("Royaumes de glace et de feu", 0xFF9CC9E6, 0xFFD9480F, 0xFFC9A227, 0xFF0E1116, true, true, FontChoice.SERIF, ShapeStyle.SOFT, Deco.SNOW, FontChoice.MEDIEVALE, 2),
    APOCALYPSE("Apocalypse zombie", 0xFF8DA34A, 0xFFA32222, 0xFFB5652B, 0xFF11130E, true, true, FontChoice.SANS, ShapeStyle.SQUARE, Deco.FOG, FontChoice.HORREUR, 2),
    MEDICO_LEGAL("Labo médico-légal", 0xFF9B0A0A, 0xFF2B2B2B, 0xFF3A6EA5, 0xFFF6F3EE, false, false, FontChoice.SANS, ShapeStyle.SQUARE, Deco.BLOOD, FontChoice.SANGLANTE, 2),
    NAPLES("Naples noir", 0xFFE0A13A, 0xFF7E98A5, 0xFFC0473A, 0xFF0C0C0D, true, true, FontChoice.SANS, ShapeStyle.SQUARE, Deco.RAIN, FontChoice.CONDENSEE, 2),
    NINJA("Voie du ninja", 0xFFFF7A00, 0xFF2F6BFF, 0xFF4CAF50, 0xFF15110D, true, true, FontChoice.SANS, ShapeStyle.ROUNDED, Deco.LEAVES, FontChoice.SAMOURAI, 2),
    AURA("Aura de combat", 0xFFFFC400, 0xFFFF6D00, 0xFF448AFF, 0xFF0B0F1F, true, true, FontChoice.SANS, ShapeStyle.CUT, Deco.ENERGY, FontChoice.MANGA, 2),
    CARNET_MAUDIT("Carnet maudit", 0xFFEDEDED, 0xFFC4002B, 0xFF8C8C8C, 0xFF080808, true, true, FontChoice.MACHINE, ShapeStyle.SQUARE, Deco.SHADOWS, FontChoice.GOTHIQUE, 2),
    PIRATES("Mers des pirates", 0xFFD4A84B, 0xFFB23A3A, 0xFF2E9D80, 0xFF071218, true, true, FontChoice.SERIF, ShapeStyle.SOFT, Deco.WAVES, FontChoice.MEDIEVALE, 2),
    FAR_WEST("Far West", 0xFFD9822B, 0xFFB5482A, 0xFF8BAF3A, 0xFF1C120A, true, true, FontChoice.MACHINE, ShapeStyle.SQUARE, Deco.DUNES, FontChoice.CONDENSEE, 2),
    RESEAU("Réseau fantôme", 0xFF00E5FF, 0xFFFF1744, 0xFF76FF03, 0xFF020812, true, true, FontChoice.MONO, ShapeStyle.CUT, Deco.CIRCUIT, FontChoice.FUTURISTE, 2),
    VAMPIRES("Nuit des vampires", 0xFFD32F2F, 0xFFBDBDBD, 0xFF9C4DCC, 0xFF0A0405, true, true, FontChoice.SERIF, ShapeStyle.CUT, Deco.FOG, FontChoice.GOTHIQUE, 2),
    VOLCAN("Île du volcan", 0xFFFF7043, 0xFF66BB6A, 0xFFFFCA28, 0xFF140A06, true, true, FontChoice.SANS, ShapeStyle.ROUNDED, Deco.FLAMES, FontChoice.MANGA, 2),

    /** Change tout seul selon le moment de la journée et le temps qu'il fait (voir [AdaptiveTheme]). */
    ADAPTATIF("Selon l'heure et la météo", 0xFF0277BD, 0xFFF9A825, 0xFF2E7D32, 0xFFF7FAFD, false, false, FontChoice.SANS, ShapeStyle.ROUNDED, Deco.SUNNY, FontChoice.DOUCE, 1),

    // Inspirés d'autres cultures
    JAPON("Japon zen", 0xFFC0392B, 0xFF1D3557, 0xFFB08D57, 0xFFF7F3EA, false, false, FontChoice.SERIF, ShapeStyle.SOFT, Deco.SEIGAIHA, FontChoice.SAMOURAI, 5),
    CHINE("Nouvel an chinois", 0xFFFF5A4E, 0xFFF4C430, 0xFF2A9D8F, 0xFF1A0505, true, true, FontChoice.SERIF, ShapeStyle.ROUNDED, Deco.LANTERNS, FontChoice.SAMOURAI, 5),
    INDE("Couleurs de l'Inde", 0xFFFF9933, 0xFFFF4F8B, 0xFF4CAF50, 0xFF1A0F05, true, true, FontChoice.SANS, ShapeStyle.PILL, Deco.MANDALA, FontChoice.DOUCE, 5),
    MAROC("Riad marocain", 0xFF4A90E2, 0xFFE0A526, 0xFF3FA36B, 0xFF0D1626, true, true, FontChoice.SERIF, ShapeStyle.SOFT, Deco.ZELLIGE, FontChoice.MEDIEVALE, 5),
    MEXIQUE("Fiesta mexicaine", 0xFFD81B60, 0xFFEF6C00, 0xFF00838F, 0xFFFFF8EE, false, false, FontChoice.SANS, ShapeStyle.PILL, Deco.PAPEL, FontChoice.MARQUEUR, 5),
    GRECE("Grèce antique", 0xFF0D5EAF, 0xFFC9A227, 0xFF4F7F3A, 0xFFF5F8FC, false, false, FontChoice.SERIF, ShapeStyle.SQUARE, Deco.MEANDER, FontChoice.SERIF, 5),
    EGYPTE("Égypte ancienne", 0xFFD4AF37, 0xFF2BA3B8, 0xFFE0602E, 0xFF15100A, true, true, FontChoice.SERIF, ShapeStyle.SQUARE, Deco.DUNES, FontChoice.MEDIEVALE, 5),
    AFRIQUE("Savane africaine", 0xFFFFA726, 0xFFEF5350, 0xFF8BC34A, 0xFF120B05, true, true, FontChoice.SANS, ShapeStyle.ROUNDED, Deco.SAVANNA, FontChoice.CONDENSEE, 5),
    NORDIQUE("Nuit nordique", 0xFF88C0D0, 0xFFD08770, 0xFFA3BE8C, 0xFF0F1620, true, true, FontChoice.SANS, ShapeStyle.SOFT, Deco.LAKE_AURORA, FontChoice.DOUCE, 5),
    POLYNESIE("Polynésie", 0xFF1DE9B6, 0xFFFF7043, 0xFFFFD54F, 0xFF041A1C, true, true, FontChoice.SANS, ShapeStyle.PILL, Deco.TROPICAL, FontChoice.DOUCE, 5),

    // Paysages peints, plus réalistes
    MONTAGNES("Montagnes à l'aube", 0xFFFFB074, 0xFF9DB8E8, 0xFFB5D88A, 0xFF101622, true, true, FontChoice.SANS, ShapeStyle.ROUNDED, Deco.MOUNTAINS, FontChoice.CONDENSEE, 6),
    OCEAN_SOIR("Océan au couchant", 0xFFFF9A6A, 0xFF7FD3F7, 0xFFFFD180, 0xFF0B1220, true, true, FontChoice.SANS, ShapeStyle.ROUNDED, Deco.SEASCAPE, FontChoice.DOUCE, 6),
    FORET_BRUME("Forêt dans la brume", 0xFFA5D6A7, 0xFFFFE082, 0xFFB0BEC5, 0xFF0C1410, true, true, FontChoice.SERIF, ShapeStyle.SOFT, Deco.FOREST, FontChoice.SERIF, 6),
    VILLE_NUIT("Ville la nuit", 0xFFFFC857, 0xFF64C8F8, 0xFFFF7BA9, 0xFF070A14, true, true, FontChoice.SANS, ShapeStyle.ROUNDED, Deco.CITY, FontChoice.CONDENSEE, 6),
    DESERT_ETOILE("Désert sous les étoiles", 0xFFE6B87A, 0xFFB0B8F0, 0xFFFFE0B2, 0xFF070812, true, true, FontChoice.SANS, ShapeStyle.SOFT, Deco.STARRY_DESERT, FontChoice.FUTURISTE, 6),
    CHAMPS_LAVANDE("Champs de lavande", 0xFFB39DDB, 0xFFFFB74D, 0xFF9CCC65, 0xFF140F1E, true, true, FontChoice.SERIF, ShapeStyle.PILL, Deco.LAVENDER, FontChoice.DOUCE, 6),
    COTE_AZUR("Côte d'Azur", 0xFF4FC3F7, 0xFFFFB74D, 0xFFFF8A80, 0xFF06141E, true, true, FontChoice.SANS, ShapeStyle.ROUNDED, Deco.RIVIERA, FontChoice.DOUCE, 6),

    ALEATOIRE("Aléatoire", 0xFF6750A4, 0xFFB4602A, 0xFF0F766E, 0xFFF8F7F3, group = 3),
    DYNAMIQUE("Couleurs du fond d'écran", 0xFF1F5F7A, 0xFFB4602A, 0xFF55703A, 0xFFF8F7F3, group = 3),

    /** Thème personnel (enregistré par l'utilisateur) : ses couleurs viennent de [Appearance.customThemes]. */
    PERSO("Mes thèmes", 0xFF6750A4, 0xFFB4602A, 0xFF0F766E, 0xFFF8F7F3, group = 4),
    ;

    fun spec() = ThemeSpec(Color(primary), Color(secondary), Color(tertiary), Color(neutral), forceDark, vivid, font, shape, deco, titleFont)
}

/** Description complète d'un thème (couleurs, ambiance, police, formes, décor). */
data class ThemeSpec(
    val primary: Color,
    val secondary: Color,
    val tertiary: Color,
    val neutral: Color,
    val forceDark: Boolean?,
    val vivid: Boolean,
    val font: FontChoice,
    val shape: ShapeStyle,
    val deco: Deco,
    val titleFont: FontChoice = font,
)

/**
 * Thème personnel nommé : un tirage au sort gardé, ou le thème du moment avec tous ses réglages
 * ([extras] : couleurs du texte, des titres, des bordures, des widgets, style des icônes, mode sombre).
 */
data class CustomTheme(val id: String, val name: String, val spec: ThemeSpec, val extras: String? = null)

/** Enregistrement des thèmes personnels (JSON dans les réglages). */
object ThemeJson {
    fun toJson(c: CustomTheme): org.json.JSONObject = org.json.JSONObject()
        .put("id", c.id).put("name", c.name)
        .put("primary", c.spec.primary.toArgb()).put("secondary", c.spec.secondary.toArgb())
        .put("tertiary", c.spec.tertiary.toArgb()).put("neutral", c.spec.neutral.toArgb())
        .put("dark", c.spec.forceDark?.toString() ?: "auto").put("vivid", c.spec.vivid)
        .put("font", c.spec.font.name).put("shape", c.spec.shape.name).put("deco", c.spec.deco.name).put("title", c.spec.titleFont.name)
        .apply { if (c.extras != null) put("extras", c.extras) }

    fun fromJson(o: org.json.JSONObject): CustomTheme? = runCatching {
        fun <T : Enum<T>> en(values: Array<T>, key: String, def: T): T = values.firstOrNull { it.name == o.optString(key) } ?: def
        CustomTheme(
            id = o.getString("id"),
            name = o.optString("name").ifBlank { "Thème" },
            spec = ThemeSpec(
                primary = Color(o.getInt("primary")), secondary = Color(o.getInt("secondary")),
                tertiary = Color(o.getInt("tertiary")), neutral = Color(o.getInt("neutral")),
                forceDark = when (o.optString("dark")) { "true" -> true; "false" -> false; else -> null },
                vivid = o.optBoolean("vivid"),
                font = en(FontChoice.entries.toTypedArray(), "font", FontChoice.SANS),
                shape = en(ShapeStyle.entries.toTypedArray(), "shape", ShapeStyle.ROUNDED),
                deco = en(Deco.entries.toTypedArray(), "deco", Deco.NONE),
                titleFont = en(FontChoice.entries.toTypedArray(), "title", FontChoice.SANS),
            ),
            extras = o.optString("extras").ifBlank { null },
        )
    }.getOrNull()

    fun listToString(l: List<CustomTheme>): String = org.json.JSONArray().apply { l.forEach { put(toJson(it)) } }.toString()

    fun listFromString(s: String?): List<CustomTheme> = runCatching {
        val a = org.json.JSONArray(s ?: return emptyList())
        (0 until a.length()).mapNotNull { fromJson(a.getJSONObject(it)) }
    }.getOrDefault(emptyList())
}

/**
 * Couleur choisie pour le texte, les titres ou les bordures.
 * [AUTO] : celle du thème ; [NONE] : aucune (bordures seulement) ; sinon une couleur ARGB.
 */
object ColorPref {
    const val AUTO = -1L
    const val NONE = 0L
    fun color(v: Long): Color? = if (v == AUTO || v == NONE) null else Color(v.toInt())
    /** Valeur à enregistrer pour une couleur (toujours positive, pour ne pas se confondre avec AUTO). */
    fun of(c: Color): Long = c.toArgb().toLong() and 0xFFFFFFFFL
}

/** Tirage d'un thème au hasard : harmonie de couleurs, ambiance, police et décor. */
object RandomTheme {
    fun roll(): ThemeSpec {
        val r = kotlin.random.Random(System.nanoTime())
        val h = r.nextFloat() * 360f
        val scheme = r.nextInt(3)
        val h2 = (h + when (scheme) { 0 -> 30f; 1 -> 120f; else -> 180f }) % 360f
        val h3 = (h + when (scheme) { 0 -> 330f; 1 -> 240f; else -> 150f }) % 360f
        val dark = r.nextBoolean()
        return if (dark) {
            ThemeSpec(
                primary = Color.hsv(h, 0.75f + r.nextFloat() * 0.25f, 1f),
                secondary = Color.hsv(h2, 0.7f, 0.95f),
                tertiary = Color.hsv(h3, 0.6f, 0.95f),
                neutral = Color.hsv(h, 0.45f, 0.06f + r.nextFloat() * 0.05f),
                forceDark = true, vivid = true,
                font = listOf(FontChoice.SANS, FontChoice.MONO, FontChoice.SERIF).random(r),
                shape = listOf(ShapeStyle.CUT, ShapeStyle.ROUNDED, ShapeStyle.PILL, ShapeStyle.SQUARE).random(r),
                deco = Deco.entries.filter { it.animated && it != Deco.SAKURA && it != Deco.BLOOD }.random(r),
                titleFont = FontChoice.entries.filter { it.display }.random(r),
            )
        } else {
            ThemeSpec(
                primary = Color.hsv(h, 0.7f, 0.55f),
                secondary = Color.hsv(h2, 0.65f, 0.6f),
                tertiary = Color.hsv(h3, 0.55f, 0.5f),
                neutral = Color.hsv(h, 0.05f, 0.97f),
                forceDark = false, vivid = false,
                font = listOf(FontChoice.SANS, FontChoice.SERIF, FontChoice.CRAYON).random(r),
                shape = listOf(ShapeStyle.ROUNDED, ShapeStyle.SOFT, ShapeStyle.PILL).random(r),
                deco = listOf(Deco.NONE, Deco.PAPER, Deco.SAKURA, Deco.BLOOD, Deco.CONFETTI, Deco.HEARTS, Deco.LEAVES).random(r),
                titleFont = listOf(FontChoice.DOUCE, FontChoice.MEDIEVALE, FontChoice.MARQUEUR, FontChoice.CONDENSEE).random(r),
            )
        }
    }
}

enum class DarkMode(val label: String) { SYSTEM("Comme le téléphone"), LIGHT("Clair"), DARK("Sombre"), BLACK("Noir (écran OLED)") }

enum class TextSize(val label: String, val scale: Float) { SMALL("Petit", 0.9f), NORMAL("Normal", 1f), LARGE("Grand", 1.15f), XLARGE("Très grand", 1.3f) }

enum class ShapeStyle(val label: String, val small: Int, val medium: Int, val large: Int, val cut: Boolean = false) {
    AUTO("Selon le thème", 10, 14, 22),
    ROUNDED("Arrondi", 10, 14, 22), SOFT("Doux", 6, 10, 14), SQUARE("Carré", 2, 4, 6), PILL("Très arrondi", 16, 24, 32),
    CUT("Biseauté", 4, 8, 12, cut = true),
}

/** Présentations des rubriques de l'accueil. */
enum class HomeStyle(val label: String) {
    GRID("Tuiles"), GRID3("Grille"), MOSAIC("Mosaïque"), CARDS("Grandes cartes"), CAROUSEL("Carrousel"), LIST("Liste"), COMPACT("Icônes"),
}

/** Styles d'icônes de l'accueil. */
enum class IconStyle(val label: String) {
    AUTO("Selon le thème"), PLEIN("Pleines"), CONTOUR("Contour"), BULLE("Bulles dégradées"),
    NEON("Néon"), GRIMOIRE("Grimoire"), TERMINAL("Terminal"), MINIMAL("Minimalistes"),
    HOLOGRAMME("Hologramme"), BLASON("Blason"), MANGA("Manga"), GRUNGE("Grunge"), ENCRE("Encre"), VITRAIL("Vitrail"),
    AQUARELLE("Aquarelle"), VAGUE("Vagues"), GLACE("Glace"), VERRE("Verre dépoli"), FLAMME("Flammes"), COEUR("Cœurs"),
    PLANETE("Planètes"), CIRCUIT("Circuit"), ENGRENAGE("Engrenages"), SCEAU("Sceau japonais"), LANTERNE("Lanternes"),
    ZELLIGE("Zellige"), PAPEL("Papel picado"), GRECQUE("Grecque"),
}

/** Où afficher la photo ou la vidéo de fond. */
enum class WallScope(val label: String) { HOME("Accueil seulement"), ALL("Partout") }

/** Style des widgets de l'écran du téléphone. */
enum class WidgetStyle(val label: String) { AUTO("Comme le téléphone"), CLAIR("Clair"), SOMBRE("Sombre"), VERRE("Transparent"), NEON("Néon"), THEME("Couleurs du thème") }

/** Ce que les écrans doivent savoir du thème en cours, au-delà des couleurs. */
data class Look(
    val deco: Deco,
    val icons: IconStyle,
    val dark: Boolean,
    val bg: Color = Color.White,
    val animate: Boolean = false,
    /** Bordures des cartes : [ColorPref.AUTO] (selon le thème), [ColorPref.NONE] ou une couleur. */
    val border: Long = ColorPref.AUTO,
    /** Couleurs des icônes choisies à la main : par icône (nom de [AppIcon]) et « * » pour toutes. */
    val iconColors: Map<String, IconColors> = emptyMap(),
)

val LocalLook = staticCompositionLocalOf { Look(Deco.NONE, IconStyle.PLEIN, false) }

/** Réglages d'apparence, partagés par tous les écrans (et l'écran d'alarme). */
class Appearance private constructor(ctx: Context) {
    private val p = ctx.applicationContext.getSharedPreferences("calepin_appearance", Context.MODE_PRIVATE)

    private inline fun <reified T : Enum<T>> load(key: String, def: T): T =
        p.getString(key, null)?.let { n -> enumValues<T>().firstOrNull { it.name == n } } ?: def

    private val _palette = MutableStateFlow(load("palette", Palette.MEDITERRANEE))
    val palette: StateFlow<Palette> = _palette
    fun setPalette(v: Palette) {
        p.edit().putString("palette", v.name).apply()
        if (v == Palette.ALEATOIRE) reroll()
        _palette.value = v
    }

    // ------------------------------------------------------------ Thèmes personnels

    private val _customThemes = MutableStateFlow(ThemeJson.listFromString(p.getString("custom_themes", null)))
    val customThemes: StateFlow<List<CustomTheme>> = _customThemes

    /** Thème personnel choisi (quand la palette est [Palette.PERSO]). */
    private val _customId = MutableStateFlow(p.getString("custom_id", "") ?: "")
    val customId: StateFlow<String> = _customId

    fun selectCustom(id: String) {
        p.edit().putString("custom_id", id).putString("palette", Palette.PERSO.name).apply()
        _customId.value = id
        _palette.value = Palette.PERSO
        // Thème enregistré avec tous ses réglages : on les remet tels qu'ils étaient
        _customThemes.value.firstOrNull { it.id == id }?.extras?.let { ex ->
            runCatching {
                val o = org.json.JSONObject(ex)
                setFont(FontChoice.AUTO); setBodyFont(FontChoice.AUTO); setShapes(ShapeStyle.AUTO); setDecoOverride("")
                setTextColor(o.optLong("text", ColorPref.AUTO)); setTitleColor(o.optLong("title", ColorPref.AUTO))
                setBorderColor(o.optLong("border", ColorPref.AUTO))
                setWidgetBorder(o.optLong("wborder", ColorPref.AUTO)); setWidgetText(o.optLong("wtext", ColorPref.AUTO))
                IconStyle.entries.firstOrNull { it.name == o.optString("icons") }?.let { setIcons(it) }
                setIconColors(IconColors.decode(o.optString("icon_colors", "")))
                DarkMode.entries.firstOrNull { it.name == o.optString("dark") }?.let { setDark(it) }
            }
        }
    }

    /**
     * Enregistre le thème tel qu'il est affiché (couleurs, polices, formes, fond, couleurs du texte,
     * des titres et des bordures, widgets, icônes) sous ce nom, dans « Mes thèmes ».
     */
    fun saveCurrent(name: String): CustomTheme {
        val base = spec(_palette.value)
        val spec = base.copy(
            font = if (_bodyFont.value == FontChoice.AUTO) base.font else _bodyFont.value,
            titleFont = if (_font.value == FontChoice.AUTO) base.titleFont else _font.value,
            shape = if (_shapes.value == ShapeStyle.AUTO) base.shape else _shapes.value,
            deco = Deco.entries.firstOrNull { it.name == _decoOverride.value } ?: base.deco,
        )
        val extras = org.json.JSONObject()
            .put("text", _textColor.value).put("title", _titleColor.value).put("border", _borderColor.value)
            .put("wborder", _widgetBorder.value).put("wtext", _widgetText.value)
            .put("icons", _icons.value.name).put("dark", _dark.value.name)
            .put("icon_colors", IconColors.encode(_iconColors.value))
            .toString()
        val c = CustomTheme(java.util.UUID.randomUUID().toString(), name.trim().ifBlank { "Mon thème" }.take(40), spec, extras)
        storeCustom(_customThemes.value + c)
        selectCustom(c.id)
        return c
    }

    /** Garde le thème tiré au sort sous ce nom et l'applique. */
    fun saveCustom(name: String, spec: ThemeSpec): CustomTheme {
        val c = CustomTheme(java.util.UUID.randomUUID().toString(), name.trim().ifBlank { "Mon thème" }.take(40), spec)
        storeCustom(_customThemes.value + c)
        selectCustom(c.id)
        return c
    }

    fun renameCustom(id: String, name: String) {
        storeCustom(_customThemes.value.map { if (it.id == id) it.copy(name = name.trim().ifBlank { it.name }.take(40)) else it })
    }

    fun deleteCustom(id: String) {
        storeCustom(_customThemes.value.filter { it.id != id })
        if (_customId.value == id && _palette.value == Palette.PERSO) setPalette(Palette.MEDITERRANEE)
    }

    private fun storeCustom(l: List<CustomTheme>) {
        p.edit().putString("custom_themes", ThemeJson.listToString(l)).apply()
        _customThemes.value = l
    }

    /** Thème personnel en cours (null si aucun ou supprimé). */
    fun currentCustom(): CustomTheme? = _customThemes.value.firstOrNull { it.id == _customId.value }

    // ------------------------------------------------------------ Couleurs choisies (texte, titres, bordures)

    private val _textColor = MutableStateFlow(p.getLong("text_color", ColorPref.AUTO))
    val textColor: StateFlow<Long> = _textColor
    fun setTextColor(v: Long) { p.edit().putLong("text_color", v).apply(); _textColor.value = v }

    private val _titleColor = MutableStateFlow(p.getLong("title_color", ColorPref.AUTO))
    val titleColor: StateFlow<Long> = _titleColor
    fun setTitleColor(v: Long) { p.edit().putLong("title_color", v).apply(); _titleColor.value = v }

    /** Bordures des cartes, tuiles, champs et séparateurs dans l'appli. */
    private val _borderColor = MutableStateFlow(p.getLong("border_color", ColorPref.AUTO))
    val borderColor: StateFlow<Long> = _borderColor
    fun setBorderColor(v: Long) { p.edit().putLong("border_color", v).apply(); _borderColor.value = v }

    /** Bordure des widgets de l'écran du téléphone. */
    private val _widgetBorder = MutableStateFlow(p.getLong("widget_border", ColorPref.AUTO))
    val widgetBorder: StateFlow<Long> = _widgetBorder
    fun setWidgetBorder(v: Long) { p.edit().putLong("widget_border", v).apply(); _widgetBorder.value = v }

    /** Texte des widgets. */
    private val _widgetText = MutableStateFlow(p.getLong("widget_text", ColorPref.AUTO))
    val widgetText: StateFlow<Long> = _widgetText
    fun setWidgetText(v: Long) { p.edit().putLong("widget_text", v).apply(); _widgetText.value = v }

    /** Thème tiré au sort (nouveau tirage à chaque lancement quand « Aléatoire » est choisi). */
    private val _random = MutableStateFlow(RandomTheme.roll())
    val random: StateFlow<ThemeSpec> = _random
    fun reroll() { _random.value = RandomTheme.roll() }

    private val _dark = MutableStateFlow(load("dark", DarkMode.SYSTEM))
    val dark: StateFlow<DarkMode> = _dark
    fun setDark(v: DarkMode) { p.edit().putString("dark", v.name).apply(); _dark.value = v }

    private val _text = MutableStateFlow(load("text", TextSize.NORMAL))
    val text: StateFlow<TextSize> = _text
    fun setText(v: TextSize) { p.edit().putString("text", v.name).apply(); _text.value = v }

    private val _shapes = MutableStateFlow(load("shapes", ShapeStyle.AUTO))
    val shapes: StateFlow<ShapeStyle> = _shapes
    fun setShapes(v: ShapeStyle) { p.edit().putString("shapes", v.name).apply(); _shapes.value = v }

    /** Police des titres (l'ancien réglage « police » s'applique aux titres). */
    private val _font = MutableStateFlow(load("font", FontChoice.AUTO))
    val font: StateFlow<FontChoice> = _font
    fun setFont(v: FontChoice) { p.edit().putString("font", v.name).apply(); _font.value = v }

    /** Police du texte. */
    private val _bodyFont = MutableStateFlow(load("body_font", FontChoice.AUTO))
    val bodyFont: StateFlow<FontChoice> = _bodyFont
    fun setBodyFont(v: FontChoice) { p.edit().putString("body_font", v.name).apply(); _bodyFont.value = v }

    /** Décors animés (désactivables pour économiser la batterie). */
    private val _animations = MutableStateFlow(p.getBoolean("animations", true))
    val animations: StateFlow<Boolean> = _animations
    fun setAnimations(v: Boolean) { p.edit().putBoolean("animations", v).apply(); _animations.value = v }

    /** Fond personnel : fichier (photo, image animée ou vidéo) dans le stockage de l'appli, ou vide. */
    private val _wallpaper = MutableStateFlow(p.getString("wallpaper", "") ?: "")
    val wallpaper: StateFlow<String> = _wallpaper
    fun setWallpaper(name: String) { p.edit().putString("wallpaper", name).apply(); _wallpaper.value = name }

    /** Voile de la couleur du thème par-dessus le fond, pour garder le texte lisible (0 à 0,9). */
    private val _wallDim = MutableStateFlow(p.getFloat("wall_dim", 0.45f))
    val wallDim: StateFlow<Float> = _wallDim
    fun setWallDim(v: Float) { p.edit().putFloat("wall_dim", v).apply(); _wallDim.value = v }

    private val _wallScope = MutableStateFlow(load("wall_scope", WallScope.ALL))
    val wallScope: StateFlow<WallScope> = _wallScope
    fun setWallScope(v: WallScope) { p.edit().putString("wall_scope", v.name).apply(); _wallScope.value = v }

    private val _widgetStyle = MutableStateFlow(load("widget_style", WidgetStyle.AUTO))
    val widgetStyle: StateFlow<WidgetStyle> = _widgetStyle
    fun setWidgetStyle(v: WidgetStyle) { p.edit().putString("widget_style", v.name).apply(); _widgetStyle.value = v }

    /** Vrai quand l'écran d'accueil est affiché (pour un fond limité à l'accueil). */
    val onHome = MutableStateFlow(true)

    private val _icons = MutableStateFlow(load("icons", IconStyle.AUTO))
    val icons: StateFlow<IconStyle> = _icons
    fun setIcons(v: IconStyle) { p.edit().putString("icons", v.name).apply(); _icons.value = v }

    /** Couleurs des icônes : « * » pour toutes, ou le nom d'une icône ([AppIcon]) pour une seule. */
    private val _iconColors = MutableStateFlow(IconColors.decode(p.getString("icon_colors", null)))
    val iconColors: StateFlow<Map<String, IconColors>> = _iconColors
    fun setIconColor(key: String, slot: IconSlot, v: Long) {
        val cur = _iconColors.value[key] ?: IconColors()
        val next = (_iconColors.value + (key to cur.with(slot, v))).filterValues { !it.isAuto }
        setIconColors(next)
    }
    fun resetIconColors(key: String?) = setIconColors(if (key == null) emptyMap() else _iconColors.value - key)
    fun setIconColors(m: Map<String, IconColors>) {
        p.edit().putString("icon_colors", IconColors.encode(m)).apply()
        _iconColors.value = m
    }

    /** Rubriques de l'accueil affichées, dans l'ordre choisi (les absentes sont masquées ; « Paramètres » reste toujours). */
    private val _homeTiles = MutableStateFlow(loadHomeTiles())
    val homeTiles: StateFlow<List<String>> = _homeTiles
    fun setHomeTiles(l: List<String>) {
        val clean = l.filter { it in HOME_TILES }.distinct()
        p.edit().putString("home_tiles", clean.joinToString(",")).putString("home_tiles_seen", HOME_TILES.joinToString(",")).apply()
        _homeTiles.value = clean
    }

    /** Les rubriques ajoutées dans une nouvelle version apparaissent d'office (avant « Paramètres »). */
    private fun loadHomeTiles(): List<String> {
        val saved = p.getString("home_tiles", null)?.split(',')?.filter { it in HOME_TILES } ?: return HOME_TILES
        val seen = p.getString("home_tiles_seen", null)?.split(',')?.toSet() ?: LEGACY_TILES
        val added = HOME_TILES.filter { it !in seen && it !in saved }
        if (added.isEmpty()) return saved
        return saved + added
    }

    /** Fond animé choisi à part du thème ("" = celui du thème). */
    private val _decoOverride = MutableStateFlow(p.getString("deco_override", "") ?: "")
    val decoOverride: StateFlow<String> = _decoOverride
    fun setDecoOverride(v: String) { p.edit().putString("deco_override", v).apply(); _decoOverride.value = v }

    /** Afficher la météo sur l'accueil. */
    private val _showWeather = MutableStateFlow(p.getBoolean("show_weather", true))
    val showWeather: StateFlow<Boolean> = _showWeather
    fun setShowWeather(v: Boolean) { p.edit().putBoolean("show_weather", v).apply(); _showWeather.value = v }

    private val _home = MutableStateFlow(load("home", HomeStyle.GRID))
    val home: StateFlow<HomeStyle> = _home
    fun setHome(v: HomeStyle) { p.edit().putString("home", v.name).apply(); _home.value = v }

    /** Thème effectif (le tirage au sort pour « Aléatoire »). */
    fun spec(pal: Palette = palette.value): ThemeSpec = when (pal) {
        Palette.ALEATOIRE -> random.value
        Palette.PERSO -> currentCustom()?.spec ?: Palette.MEDITERRANEE.spec()
        Palette.ADAPTATIF -> AdaptiveTheme.now()
        else -> pal.spec()
    }

    companion object {
        /** Rubriques possibles de l'accueil, dans l'ordre d'origine. */
        val HOME_TILES = listOf("notes", "agenda", "contacts", "remote", "devices", "pro", "phone", "games")

        /** Rubriques des versions précédentes (pour repérer les nouvelles). */
        private val LEGACY_TILES = setOf("notes", "agenda", "assistant", "contacts", "remote", "devices", "pro", "games", "appearance", "settings")

        /** Nom affiché de chaque rubrique (pour l'écran Apparence). */
        val HOME_TILE_LABELS = mapOf(
            "notes" to "Notes", "agenda" to "Agenda", "contacts" to "Contacts",
            "remote" to "Télécommande", "devices" to "Maison", "pro" to "Pro", "phone" to "Téléphone", "games" to "Détente",
        )

        @Volatile private var instance: Appearance? = null
        fun get(ctx: Context): Appearance = instance ?: synchronized(this) { instance ?: Appearance(ctx).also { instance = it } }

        /** Style d'icônes qui va avec chaque décor. */
        fun iconsFor(deco: Deco, dark: Boolean): IconStyle = when (deco) {
            Deco.NEON, Deco.SUNSET -> IconStyle.NEON
            Deco.GRIMOIRE -> IconStyle.GRIMOIRE
            Deco.SNOW, Deco.LAKE_AURORA -> IconStyle.GLACE
            Deco.TERMINAL -> IconStyle.TERMINAL
            Deco.AURORA, Deco.FIREFLIES, Deco.BUBBLES -> IconStyle.BULLE
            Deco.PAPER -> IconStyle.CONTOUR
            Deco.STARS, Deco.STORM -> IconStyle.HOLOGRAMME
            Deco.FOG, Deco.BLOOD, Deco.RAIN -> IconStyle.GRUNGE
            Deco.LEAVES, Deco.SHADOWS, Deco.SAKURA -> IconStyle.ENCRE
            Deco.ENERGY -> IconStyle.MANGA
            Deco.WAVES, Deco.SEASCAPE, Deco.RIVIERA, Deco.TROPICAL -> IconStyle.VAGUE
            Deco.BOKEH, Deco.CITY -> IconStyle.VERRE
            Deco.NEBULA, Deco.STARRY_DESERT -> IconStyle.PLANETE
            Deco.LAVA, Deco.FLAMES -> IconStyle.FLAMME
            Deco.CONFETTI, Deco.PAPEL -> IconStyle.PAPEL
            Deco.HEARTS -> IconStyle.COEUR
            Deco.DUNES -> IconStyle.BLASON
            Deco.GEARS -> IconStyle.ENGRENAGE
            Deco.CIRCUIT -> IconStyle.CIRCUIT
            Deco.SUNNY, Deco.CLOUDS, Deco.LAVENDER, Deco.SAVANNA, Deco.MOUNTAINS, Deco.FOREST -> IconStyle.AQUARELLE
            Deco.SEIGAIHA -> IconStyle.SCEAU
            Deco.LANTERNS -> IconStyle.LANTERNE
            Deco.ZELLIGE, Deco.MANDALA -> IconStyle.ZELLIGE
            Deco.MEANDER -> IconStyle.GRECQUE
            Deco.NONE -> if (dark) IconStyle.PLEIN else IconStyle.PLEIN
        }
    }
}

// ------------------------------------------------------------------ Construction des couleurs

private fun lightScheme(sp: ThemeSpec): ColorScheme {
    val p = sp.primary; val s = sp.secondary; val t = sp.tertiary; val n = sp.neutral
    val ink = if (sp.deco == Deco.PAPER) Color(0xFF2B1D12) else Color(0xFF1B1C1E)
    return lightColorScheme(
        primary = p, onPrimary = Color.White,
        primaryContainer = lerp(p, Color.White, 0.82f), onPrimaryContainer = lerp(p, Color.Black, 0.6f),
        secondary = s, onSecondary = Color.White,
        secondaryContainer = lerp(s, Color.White, 0.8f), onSecondaryContainer = lerp(s, Color.Black, 0.65f),
        tertiary = t, onTertiary = Color.White,
        tertiaryContainer = lerp(t, Color.White, 0.8f), onTertiaryContainer = lerp(t, Color.Black, 0.65f),
        background = n, onBackground = ink, surface = n, onSurface = ink,
        surfaceVariant = lerp(n, p, 0.08f), onSurfaceVariant = lerp(ink, p, 0.25f).copy(alpha = 0.85f),
        surfaceContainerLowest = lerp(n, Color.White, 0.6f),
        surfaceContainerLow = lerp(n, p, 0.03f),
        surfaceContainer = lerp(n, p, 0.06f),
        surfaceContainerHigh = lerp(n, p, 0.09f),
        surfaceContainerHighest = lerp(n, p, 0.12f),
        outline = lerp(ink, n, 0.55f), outlineVariant = lerp(ink, n, 0.8f),
    )
}

private fun darkScheme(sp: ThemeSpec, black: Boolean): ColorScheme {
    val p = lerp(sp.primary, Color.White, 0.5f); val s = lerp(sp.secondary, Color.White, 0.45f); val t = lerp(sp.tertiary, Color.White, 0.45f)
    val base = if (black) Color.Black else lerp(Color(0xFF101214), sp.primary, 0.06f)
    val ink = Color(0xFFE4E3E0)
    return darkColorScheme(
        primary = p, onPrimary = lerp(sp.primary, Color.Black, 0.6f),
        primaryContainer = lerp(sp.primary, Color.Black, 0.35f), onPrimaryContainer = lerp(p, Color.White, 0.6f),
        secondary = s, onSecondary = lerp(sp.secondary, Color.Black, 0.6f),
        secondaryContainer = lerp(sp.secondary, Color.Black, 0.45f), onSecondaryContainer = lerp(s, Color.White, 0.6f),
        tertiary = t, onTertiary = lerp(sp.tertiary, Color.Black, 0.6f),
        tertiaryContainer = lerp(sp.tertiary, Color.Black, 0.45f), onTertiaryContainer = lerp(t, Color.White, 0.6f),
        background = base, onBackground = ink, surface = base, onSurface = ink,
        surfaceVariant = lerp(base, p, 0.12f), onSurfaceVariant = lerp(ink, p, 0.2f).copy(alpha = 0.8f),
        surfaceContainerLowest = base,
        surfaceContainerLow = lerp(base, p, if (black) 0.06f else 0.05f),
        surfaceContainer = lerp(base, p, if (black) 0.09f else 0.08f),
        surfaceContainerHigh = lerp(base, p, 0.12f),
        surfaceContainerHighest = lerp(base, p, 0.15f),
        outline = lerp(ink, base, 0.5f), outlineVariant = lerp(ink, base, 0.78f),
    )
}

/** Thèmes sombres à couleurs éclatantes (néon, grimoire, terminal…) : fond profond, accents purs. */
private fun vividScheme(sp: ThemeSpec, black: Boolean): ColorScheme {
    val base = if (black) Color.Black else sp.neutral
    val p = sp.primary; val s = sp.secondary; val t = sp.tertiary
    val ink = lerp(Color(0xFFEDEBF2), p, 0.08f)
    return darkColorScheme(
        primary = p, onPrimary = lerp(base, Color.Black, 0.5f),
        primaryContainer = lerp(base, p, 0.28f), onPrimaryContainer = lerp(p, Color.White, 0.35f),
        secondary = s, onSecondary = lerp(base, Color.Black, 0.5f),
        secondaryContainer = lerp(base, s, 0.24f), onSecondaryContainer = lerp(s, Color.White, 0.35f),
        tertiary = t, onTertiary = lerp(base, Color.Black, 0.5f),
        tertiaryContainer = lerp(base, t, 0.22f), onTertiaryContainer = lerp(t, Color.White, 0.35f),
        background = base, onBackground = ink, surface = base, onSurface = ink,
        surfaceVariant = lerp(base, p, 0.14f), onSurfaceVariant = lerp(ink, s, 0.3f).copy(alpha = 0.85f),
        surfaceContainerLowest = base,
        surfaceContainerLow = lerp(base, p, 0.07f),
        surfaceContainer = lerp(base, p, 0.1f),
        surfaceContainerHigh = lerp(base, p, 0.14f),
        surfaceContainerHighest = lerp(base, p, 0.18f),
        outline = lerp(p, base, 0.35f), outlineVariant = lerp(p, base, 0.7f),
    )
}

private fun Typography.withFont(f: FontFamily, t: FontFamily = f, tc: Color = Color.Unspecified) = Typography(
    displayLarge = displayLarge.copy(fontFamily = t, color = tc), displayMedium = displayMedium.copy(fontFamily = t, color = tc), displaySmall = displaySmall.copy(fontFamily = t, color = tc),
    headlineLarge = headlineLarge.copy(fontFamily = t, color = tc), headlineMedium = headlineMedium.copy(fontFamily = t, color = tc), headlineSmall = headlineSmall.copy(fontFamily = t, color = tc),
    titleLarge = titleLarge.copy(fontFamily = t, color = tc), titleMedium = titleMedium.copy(fontFamily = f, color = tc), titleSmall = titleSmall.copy(fontFamily = f, color = tc),
    bodyLarge = bodyLarge.copy(fontFamily = f), bodyMedium = bodyMedium.copy(fontFamily = f), bodySmall = bodySmall.copy(fontFamily = f),
    labelLarge = labelLarge.copy(fontFamily = f), labelMedium = labelMedium.copy(fontFamily = f), labelSmall = labelSmall.copy(fontFamily = f),
)

@Composable
fun CalepinTheme(content: @Composable () -> Unit) {
    val ctx = LocalContext.current
    remember { fr.jeremy.calepin.i18n.I18n.init(ctx) }
    val lang by fr.jeremy.calepin.i18n.I18n.language.collectAsStateWithLifecycle()
    val a = remember { Appearance.get(ctx) }
    val palette by a.palette.collectAsStateWithLifecycle()
    val random by a.random.collectAsStateWithLifecycle()
    val mode by a.dark.collectAsStateWithLifecycle()
    val text by a.text.collectAsStateWithLifecycle()
    val shapeChoice by a.shapes.collectAsStateWithLifecycle()
    val fontChoice by a.font.collectAsStateWithLifecycle()
    val bodyChoice by a.bodyFont.collectAsStateWithLifecycle()
    val iconChoice by a.icons.collectAsStateWithLifecycle()
    val iconColors by a.iconColors.collectAsStateWithLifecycle()
    val animations by a.animations.collectAsStateWithLifecycle()
    val customs by a.customThemes.collectAsStateWithLifecycle()
    val customId by a.customId.collectAsStateWithLifecycle()
    val textColor by a.textColor.collectAsStateWithLifecycle()
    val titleColor by a.titleColor.collectAsStateWithLifecycle()
    val borderColor by a.borderColor.collectAsStateWithLifecycle()
    val decoChoice by a.decoOverride.collectAsStateWithLifecycle()
    // Thème « selon l'heure et la météo » : recalculé quand la météo change et toutes les 5 minutes
    val adaptiveWeather by fr.jeremy.calepin.weather.WeatherRepo.forecast.collectAsStateWithLifecycle()
    var adaptiveClock by remember { mutableStateOf(System.currentTimeMillis() / 300_000L) }
    LaunchedEffect(palette) {
        if (palette == Palette.ADAPTATIF) {
            fr.jeremy.calepin.weather.WeatherRepo.loadCached(ctx)
            runCatching { fr.jeremy.calepin.weather.WeatherRepo.refresh(ctx) }
            while (true) {
                kotlinx.coroutines.delay(60_000L)
                adaptiveClock = System.currentTimeMillis() / 300_000L
            }
        }
    }
    val spec = when (palette) {
        Palette.ALEATOIRE -> random
        Palette.PERSO -> customs.firstOrNull { it.id == customId }?.spec ?: Palette.MEDITERRANEE.spec()
        Palette.ADAPTATIF -> remember(adaptiveClock, adaptiveWeather) { AdaptiveTheme.now() }
        else -> palette.spec()
    }
    val system = isSystemInDarkTheme()
    val dark = spec.forceDark ?: when (mode) {
        DarkMode.SYSTEM -> system
        DarkMode.LIGHT -> false
        DarkMode.DARK, DarkMode.BLACK -> true
    }
    val black = mode == DarkMode.BLACK && dark
    val baseScheme = when {
        palette == Palette.DYNAMIQUE && Build.VERSION.SDK_INT >= 31 ->
            if (dark) dynamicDarkColorScheme(ctx).let { if (black) it.copy(background = Color.Black, surface = Color.Black) else it }
            else dynamicLightColorScheme(ctx)
        dark && spec.vivid -> vividScheme(spec, black)
        dark -> darkScheme(spec, black)
        else -> lightScheme(spec)
    }
    // Couleurs choisies par l'utilisateur : texte et bordures
    val scheme = baseScheme.let { s0 ->
        var s1 = s0
        ColorPref.color(textColor)?.let { c ->
            s1 = s1.copy(onBackground = c, onSurface = c, onSurfaceVariant = c.copy(alpha = 0.78f))
        }
        ColorPref.color(borderColor)?.let { c -> s1 = s1.copy(outline = c, outlineVariant = c.copy(alpha = 0.7f)) }
        s1
    }
    val shapeStyle = if (shapeChoice == ShapeStyle.AUTO) spec.shape else shapeChoice
    fun corner(v: Int): CornerBasedShape = if (shapeStyle.cut) CutCornerShape(v.dp) else RoundedCornerShape(v.dp)
    val shapes = Shapes(
        extraSmall = corner(shapeStyle.small / 2),
        small = corner(shapeStyle.small),
        medium = corner(shapeStyle.medium),
        large = corner(shapeStyle.large),
        extraLarge = corner(shapeStyle.large + 6),
    )
    val titleF = (if (fontChoice == FontChoice.AUTO) spec.titleFont else fontChoice).family(ctx)
    val bodyF = (if (bodyChoice == FontChoice.AUTO) spec.font else bodyChoice).family(ctx)
    val titleC = ColorPref.color(titleColor) ?: Color.Unspecified
    val typography = remember(titleF, bodyF, titleC) { Typography().withFont(bodyF, titleF, titleC) }
    val realBg = scheme.background
    // Fond choisi à part (indépendant du thème), sinon celui du thème
    val deco = Deco.entries.firstOrNull { it.name == decoChoice } ?: spec.deco
    val look = Look(
        deco = deco,
        icons = if (iconChoice == IconStyle.AUTO) Appearance.iconsFor(deco, dark) else iconChoice,
        dark = dark,
        bg = realBg,
        animate = animations && deco.animated,
        border = borderColor,
        iconColors = iconColors,
    )
    // Icônes de la barre d'état lisibles sur fond clair comme sombre
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as? Activity)?.window ?: return@SideEffect
            WindowCompat.getInsetsController(window, view).apply {
                isAppearanceLightStatusBars = !dark
                isAppearanceLightNavigationBars = !dark
            }
        }
    }
    val density = LocalDensity.current
    CompositionLocalProvider(
        LocalDensity provides Density(density.density, density.fontScale * text.scale),
        LocalLook provides look,
        fr.jeremy.calepin.i18n.LocalLanguage provides lang,
    ) {
        // Le fond (couleur, décor animé, photo ou vidéo) est peint une seule fois derrière tous les écrans :
        // les écrans gardent un fond transparent pour le laisser voir.
        MaterialTheme(colorScheme = scheme.copy(background = Color.Transparent), shapes = shapes, typography = typography) {
            androidx.compose.foundation.layout.Box(androidx.compose.ui.Modifier.fillMaxSize()) {
                ThemeBackground(look, scheme)
                content()
            }
        }
    }
}

/**
 * Bordure d'une carte selon le réglage « Bordures » : [fallback] (celle du thème) en automatique,
 * aucune, ou la couleur choisie.
 */
@Composable
fun appBorder(fallback: androidx.compose.foundation.BorderStroke? = null): androidx.compose.foundation.BorderStroke? {
    val b = LocalLook.current.border
    return when (b) {
        ColorPref.AUTO -> fallback
        ColorPref.NONE -> null
        else -> androidx.compose.foundation.BorderStroke(1.5.dp, Color(b.toInt()))
    }
}

/** Agrandissement du texte en cours (taille choisie dans Apparence × réglage du téléphone), jamais sous 1. */
@Composable
fun textGrowth(): Float = LocalDensity.current.fontScale.coerceIn(1f, 2f)

/** Agrandit une dimension fixe au même rythme que le texte, pour que les libellés ne soient jamais coupés. */
@Composable
fun Dp.grow(): Dp = this * textGrowth()

fun EntityType.icon(): ImageVector = when (this) {
    EntityType.PHONE -> Icons.Filled.Phone
    EntityType.EMAIL -> Icons.Filled.Email
    EntityType.URL -> Icons.Filled.Language
    EntityType.DATE -> Icons.Filled.Event
    EntityType.ADDRESS -> Icons.Filled.Place
}


/**
 * Thème qui suit la journée et le temps : aube, jour, soir et nuit, avec ciel dégagé, nuages, pluie,
 * neige, brouillard ou orage (météo du lieu choisi dans l'écran Météo ; sans lieu, seule l'heure compte).
 */
object AdaptiveTheme {
    private enum class Moment { AUBE, JOUR, SOIR, NUIT }
    private enum class Sky { CLAIR, NUAGES, BROUILLARD, PLUIE, NEIGE, ORAGE }

    private fun minutes(hhmm: String?, def: Int): Int = runCatching {
        val (h, m) = hhmm!!.trim().split(':').map { it.toInt() }
        h * 60 + m
    }.getOrDefault(def)

    private fun sky(code: Int?): Sky = when (code) {
        null, 0, 1 -> Sky.CLAIR
        2, 3 -> Sky.NUAGES
        45, 48 -> Sky.BROUILLARD
        in 51..67, in 80..82 -> Sky.PLUIE
        in 71..77, 85, 86 -> Sky.NEIGE
        in 95..99 -> Sky.ORAGE
        else -> Sky.CLAIR
    }

    private fun s(p: Long, sc: Long, t: Long, n: Long, dark: Boolean, deco: Deco, font: FontChoice = FontChoice.SANS) =
        ThemeSpec(Color(p), Color(sc), Color(t), Color(n), dark, dark, font, ShapeStyle.ROUNDED, deco, FontChoice.DOUCE)

    /** Ambiance du moment. */
    fun now(): ThemeSpec {
        val f = fr.jeremy.calepin.weather.WeatherRepo.forecast.value
        val today = f?.days?.firstOrNull()
        val t = java.time.LocalTime.now().let { it.hour * 60 + it.minute }
        val rise = minutes(today?.sunrise, 7 * 60)
        val set = minutes(today?.sunset, 20 * 60)
        val moment = when {
            t in (rise - 45)..(rise + 60) -> Moment.AUBE
            t in (set - 60)..(set + 45) -> Moment.SOIR
            t in rise..set -> Moment.JOUR
            else -> Moment.NUIT
        }
        // Météo de moins de 3 heures seulement (sinon, ciel dégagé par défaut)
        val code = f?.takeIf { System.currentTimeMillis() - it.fetchedAt < 3 * 3_600_000L }?.code
        return when (sky(code)) {
            Sky.ORAGE -> s(0xFFB9C7FF, 0xFFFFE066, 0xFF8FA3B8, 0xFF0B0E16, true, Deco.STORM)
            Sky.NEIGE -> if (moment == Moment.JOUR) s(0xFF90CAF9, 0xFFE1F5FE, 0xFFCE93D8, 0xFF1B2A3A, true, Deco.SNOW)
                else s(0xFF90CAF9, 0xFFB0BEC5, 0xFFCE93D8, 0xFF0B1622, true, Deco.SNOW)
            Sky.PLUIE -> if (moment == Moment.JOUR) s(0xFF64B5F6, 0xFFFFB74D, 0xFF80CBC4, 0xFF16202A, true, Deco.RAIN)
                else s(0xFF90A4FF, 0xFFFFD180, 0xFF80DEEA, 0xFF0A0E14, true, Deco.RAIN)
            Sky.BROUILLARD -> s(0xFFB0BEC5, 0xFFFFCC80, 0xFF90A4AE, 0xFF15191D, true, Deco.FOG)
            Sky.NUAGES -> when (moment) {
                Moment.JOUR -> s(0xFF3D6E9E, 0xFFB4602A, 0xFF5E7D6C, 0xFFF2F4F7, false, Deco.CLOUDS)
                Moment.AUBE, Moment.SOIR -> s(0xFFFF8A65, 0xFFB39DDB, 0xFFFFD54F, 0xFF1C1424, true, Deco.CLOUDS)
                Moment.NUIT -> s(0xFF9FA8DA, 0xFFFFCC80, 0xFF80CBC4, 0xFF0E1220, true, Deco.CLOUDS)
            }
            Sky.CLAIR -> when (moment) {
                Moment.AUBE -> s(0xFFFF8A65, 0xFFFFD54F, 0xFFBA68C8, 0xFF1E1426, true, Deco.SUNNY)
                Moment.JOUR -> s(0xFF0277BD, 0xFFF9A825, 0xFF2E7D32, 0xFFF7FAFD, false, Deco.SUNNY)
                Moment.SOIR -> s(0xFFFF7043, 0xFFFFB300, 0xFFAB47BC, 0xFF1A1020, true, Deco.SUNNY)
                Moment.NUIT -> s(0xFF8AB4F8, 0xFFFFE082, 0xFFB39DDB, 0xFF070B18, true, Deco.STARS)
            }
        }
    }
}
