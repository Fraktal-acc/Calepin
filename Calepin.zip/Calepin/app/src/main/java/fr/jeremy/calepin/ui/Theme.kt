package fr.jeremy.calepin.ui

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Event
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Place
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import fr.jeremy.calepin.detect.EntityType

// Bleu de la baie, ocre des façades, vert d'olivier.
private val Light = lightColorScheme(
    primary = Color(0xFF1F5F7A),
    onPrimary = Color.White,
    primaryContainer = Color(0xFFCDE6F2),
    onPrimaryContainer = Color(0xFF0B2E3D),
    secondary = Color(0xFFB4602A),
    secondaryContainer = Color(0xFFFFDCC4),
    onSecondaryContainer = Color(0xFF3A1A05),
    tertiary = Color(0xFF55703A),
    background = Color(0xFFF8F7F3),
    surface = Color(0xFFF8F7F3),
    surfaceContainerLow = Color(0xFFF0EFEA),
    surfaceContainer = Color(0xFFEAE9E3),
)

private val Dark = darkColorScheme(
    primary = Color(0xFF8CCBE6),
    onPrimary = Color(0xFF00344A),
    primaryContainer = Color(0xFF184C62),
    onPrimaryContainer = Color(0xFFCDE6F2),
    secondary = Color(0xFFF3A874),
    secondaryContainer = Color(0xFF6B3410),
    onSecondaryContainer = Color(0xFFFFDCC4),
    tertiary = Color(0xFFA9CF85),
    background = Color(0xFF111416),
    surface = Color(0xFF111416),
    surfaceContainerLow = Color(0xFF191D20),
    surfaceContainer = Color(0xFF1F2427),
)

@Composable
fun CalepinTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = if (isSystemInDarkTheme()) Dark else Light, content = content)
}

fun EntityType.icon(): ImageVector = when (this) {
    EntityType.PHONE -> Icons.Filled.Phone
    EntityType.EMAIL -> Icons.Filled.Email
    EntityType.URL -> Icons.Filled.Language
    EntityType.DATE -> Icons.Filled.Event
    EntityType.ADDRESS -> Icons.Filled.Place
}
