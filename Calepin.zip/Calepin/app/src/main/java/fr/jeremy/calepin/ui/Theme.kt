package fr.jeremy.calepin.ui

import android.app.Activity
import android.content.Context
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat
import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.CornerBasedShape
import androidx.compose.foundation.shape.CutCornerShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Event
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Place
import androidx.compose.material3.ColorScheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import fr.jeremy.calepin.detect.EntityType
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

// ------------------------------------------------------------------ Choix d'apparence

/** Décor propre à un thème : fond de l'accueil et style des icônes « selon le thème ». */
enum class Deco { NONE, NEON, GRIMOIRE, TERMINAL, SUNSET, AURORA, PAPER }

enum class FontChoice(val label: String) {
    AUTO("Selon le thème"), SANS("Classique"), SERIF("Élégante"), MONO("Machine à écrire"), CURSIVE("Manuscrite");

    fun family(): FontFamily = when (this) {
        SERIF -> FontFamily.Serif
        MONO -> FontFamily.Monospace
        CURSIVE -> FontFamily.Cursive
        else -> FontFamily.Default
    }
}

/**
 * Thèmes : [primary], [secondary], [tertiary] et la teinte des fonds [neutral].
 * [forceDark] : null = suit le réglage clair/sombre, vrai/faux = le thème impose son ambiance.
 * [vivid] : couleurs gardées éclatantes en mode sombre (néon…).
 */
enum class Palette(
    val label: String,
    val primary: Long,
    val secondary: Long,
    val tertiary: Long,
    val neutral: Long,
    val forceDark: Boolean? = null,
    val vivid: Boolean = false,
    val font: FontChoice = FontChoice.SANS,
    val shape: ShapeStyle = ShapeStyle.ROUNDED,
    val deco: Deco = Deco.NONE,
) {
    MEDITERRANEE("Méditerranée", 0xFF1F5F7A, 0xFFB4602A, 0xFF55703A, 0xFFF8F7F3),
    OCEAN("Océan", 0xFF0B57D0, 0xFF00838F, 0xFF5C6BC0, 0xFFF5F8FD),
    FORET("Forêt", 0xFF2E6B3F, 0xFF8D6E2F, 0xFF3F7F7A, 0xFFF5F7F2),
    LAVANDE("Lavande", 0xFF6750A4, 0xFF9C4F8C, 0xFF4F6FA8, 0xFFF8F5FB),
    SOLEIL("Soleil", 0xFFB45309, 0xFFC2410C, 0xFF7C6F00, 0xFFFBF7F0),
    CORAIL("Corail", 0xFFC2410C, 0xFFBE185D, 0xFF0F766E, 0xFFFCF6F4),
    ROSE("Rose", 0xFFB0306A, 0xFF8E4B9A, 0xFFC0584A, 0xFFFCF5F8),
    ARDOISE("Ardoise", 0xFF37474F, 0xFF5D6B75, 0xFF6D5D4F, 0xFFF6F7F8),
    CYBERPUNK("Cyberpunk", 0xFFFF2BD6, 0xFF00F0FF, 0xFFF5FF3B, 0xFF0A0614, forceDark = true, vivid = true, font = FontChoice.MONO, shape = ShapeStyle.CUT, deco = Deco.NEON),
    DARK_FANTASY("Dark fantasy", 0xFFB3243A, 0xFFD4AF37, 0xFF8A5CC7, 0xFF120B0E, forceDark = true, vivid = true, font = FontChoice.SERIF, shape = ShapeStyle.CUT, deco = Deco.GRIMOIRE),
    SYNTHWAVE("Synthwave", 0xFFFF6EC7, 0xFFFF9E3D, 0xFF9D6BFF, 0xFF1A0B2E, forceDark = true, vivid = true, deco = Deco.SUNSET, shape = ShapeStyle.PILL),
    TERMINAL("Terminal rétro", 0xFF33FF66, 0xFFFFB000, 0xFF3FD0C9, 0xFF030803, forceDark = true, vivid = true, font = FontChoice.MONO, shape = ShapeStyle.SQUARE, deco = Deco.TERMINAL),
    AURORE("Aurore boréale", 0xFF2DD4BF, 0xFFA78BFA, 0xFF4ADE80, 0xFF06121C, forceDark = true, vivid = true, deco = Deco.AURORA),
    PARCHEMIN("Parchemin", 0xFF7A4E2D, 0xFF8E2C2C, 0xFF5B6B2F, 0xFFF3E9D2, forceDark = false, font = FontChoice.SERIF, shape = ShapeStyle.SOFT, deco = Deco.PAPER),
    ALEATOIRE("Aléatoire", 0xFF6750A4, 0xFFB4602A, 0xFF0F766E, 0xFFF8F7F3),
    DYNAMIQUE("Couleurs du fond d'écran", 0xFF1F5F7A, 0xFFB4602A, 0xFF55703A, 0xFFF8F7F3),
    ;

    fun spec() = ThemeSpec(Color(primary), Color(secondary), Color(tertiary), Color(neutral), forceDark, vivid, font, shape, deco)
}

/** Description complète d'un thème (couleurs, ambiance, police, formes, décor). */
data class ThemeSpec(
    val primary: Color,
    val secondary: Color,
    val tertiary: Color,
    val neutral: Color,
    val forceDark: Boolean?,
    val vivid: Boolean,
    val font: FontChoice,
    val shape: ShapeStyle,
    val deco: Deco,
)

/** Tirage d'un thème au hasard : harmonie de couleurs, ambiance, police et décor. */
object RandomTheme {
    fun roll(): ThemeSpec {
        val r = kotlin.random.Random(System.nanoTime())
        val h = r.nextFloat() * 360f
        val scheme = r.nextInt(3)
        val h2 = (h + when (scheme) { 0 -> 30f; 1 -> 120f; else -> 180f }) % 360f
        val h3 = (h + when (scheme) { 0 -> 330f; 1 -> 240f; else -> 150f }) % 360f
        val dark = r.nextBoolean()
        return if (dark) {
            ThemeSpec(
                primary = Color.hsv(h, 0.75f + r.nextFloat() * 0.25f, 1f),
                secondary = Color.hsv(h2, 0.7f, 0.95f),
                tertiary = Color.hsv(h3, 0.6f, 0.95f),
                neutral = Color.hsv(h, 0.45f, 0.06f + r.nextFloat() * 0.05f),
                forceDark = true, vivid = true,
                font = listOf(FontChoice.SANS, FontChoice.MONO, FontChoice.SERIF).random(r),
                shape = listOf(ShapeStyle.CUT, ShapeStyle.ROUNDED, ShapeStyle.PILL, ShapeStyle.SQUARE).random(r),
                deco = listOf(Deco.NEON, Deco.AURORA, Deco.SUNSET, Deco.GRIMOIRE, Deco.TERMINAL, Deco.NONE).random(r),
            )
        } else {
            ThemeSpec(
                primary = Color.hsv(h, 0.7f, 0.55f),
                secondary = Color.hsv(h2, 0.65f, 0.6f),
                tertiary = Color.hsv(h3, 0.55f, 0.5f),
                neutral = Color.hsv(h, 0.05f, 0.97f),
                forceDark = false, vivid = false,
                font = listOf(FontChoice.SANS, FontChoice.SERIF, FontChoice.CURSIVE).random(r),
                shape = listOf(ShapeStyle.ROUNDED, ShapeStyle.SOFT, ShapeStyle.PILL).random(r),
                deco = listOf(Deco.NONE, Deco.PAPER, Deco.AURORA).random(r),
            )
        }
    }
}

enum class DarkMode(val label: String) { SYSTEM("Comme le téléphone"), LIGHT("Clair"), DARK("Sombre"), BLACK("Noir (écran OLED)") }

enum class TextSize(val label: String, val scale: Float) { SMALL("Petit", 0.9f), NORMAL("Normal", 1f), LARGE("Grand", 1.15f), XLARGE("Très grand", 1.3f) }

enum class ShapeStyle(val label: String, val small: Int, val medium: Int, val large: Int, val cut: Boolean = false) {
    AUTO("Selon le thème", 10, 14, 22),
    ROUNDED("Arrondi", 10, 14, 22), SOFT("Doux", 6, 10, 14), SQUARE("Carré", 2, 4, 6), PILL("Très arrondi", 16, 24, 32),
    CUT("Biseauté", 4, 8, 12, cut = true),
}

enum class HomeStyle(val label: String) { GRID("Tuiles"), LIST("Liste"), COMPACT("Compact") }

/** Styles d'icônes de l'accueil. */
enum class IconStyle(val label: String) {
    AUTO("Selon le thème"), PLEIN("Pleines"), CONTOUR("Contour"), BULLE("Bulles dégradées"),
    NEON("Néon"), GRIMOIRE("Grimoire"), TERMINAL("Terminal"), MINIMAL("Minimalistes"),
}

/** Ce que les écrans doivent savoir du thème en cours, au-delà des couleurs. */
data class Look(val deco: Deco, val icons: IconStyle, val dark: Boolean)

val LocalLook = staticCompositionLocalOf { Look(Deco.NONE, IconStyle.PLEIN, false) }

/** Réglages d'apparence, partagés par tous les écrans (et l'écran d'alarme). */
class Appearance private constructor(ctx: Context) {
    private val p = ctx.applicationContext.getSharedPreferences("calepin_appearance", Context.MODE_PRIVATE)

    private inline fun <reified T : Enum<T>> load(key: String, def: T): T =
        p.getString(key, null)?.let { n -> enumValues<T>().firstOrNull { it.name == n } } ?: def

    private val _palette = MutableStateFlow(load("palette", Palette.MEDITERRANEE))
    val palette: StateFlow<Palette> = _palette
    fun setPalette(v: Palette) {
        p.edit().putString("palette", v.name).apply()
        if (v == Palette.ALEATOIRE) reroll()
        _palette.value = v
    }

    /** Thème tiré au sort (nouveau tirage à chaque lancement quand « Aléatoire » est choisi). */
    private val _random = MutableStateFlow(RandomTheme.roll())
    val random: StateFlow<ThemeSpec> = _random
    fun reroll() { _random.value = RandomTheme.roll() }

    private val _dark = MutableStateFlow(load("dark", DarkMode.SYSTEM))
    val dark: StateFlow<DarkMode> = _dark
    fun setDark(v: DarkMode) { p.edit().putString("dark", v.name).apply(); _dark.value = v }

    private val _text = MutableStateFlow(load("text", TextSize.NORMAL))
    val text: StateFlow<TextSize> = _text
    fun setText(v: TextSize) { p.edit().putString("text", v.name).apply(); _text.value = v }

    private val _shapes = MutableStateFlow(load("shapes", ShapeStyle.AUTO))
    val shapes: StateFlow<ShapeStyle> = _shapes
    fun setShapes(v: ShapeStyle) { p.edit().putString("shapes", v.name).apply(); _shapes.value = v }

    private val _font = MutableStateFlow(load("font", FontChoice.AUTO))
    val font: StateFlow<FontChoice> = _font
    fun setFont(v: FontChoice) { p.edit().putString("font", v.name).apply(); _font.value = v }

    private val _icons = MutableStateFlow(load("icons", IconStyle.AUTO))
    val icons: StateFlow<IconStyle> = _icons
    fun setIcons(v: IconStyle) { p.edit().putString("icons", v.name).apply(); _icons.value = v }

    private val _home = MutableStateFlow(load("home", HomeStyle.GRID))
    val home: StateFlow<HomeStyle> = _home
    fun setHome(v: HomeStyle) { p.edit().putString("home", v.name).apply(); _home.value = v }

    /** Thème effectif (le tirage au sort pour « Aléatoire »). */
    fun spec(pal: Palette = palette.value): ThemeSpec = if (pal == Palette.ALEATOIRE) random.value else pal.spec()

    companion object {
        @Volatile private var instance: Appearance? = null
        fun get(ctx: Context): Appearance = instance ?: synchronized(this) { instance ?: Appearance(ctx).also { instance = it } }

        /** Style d'icônes qui va avec chaque décor. */
        fun iconsFor(deco: Deco, dark: Boolean): IconStyle = when (deco) {
            Deco.NEON, Deco.SUNSET -> IconStyle.NEON
            Deco.GRIMOIRE -> IconStyle.GRIMOIRE
            Deco.TERMINAL -> IconStyle.TERMINAL
            Deco.AURORA -> IconStyle.BULLE
            Deco.PAPER -> IconStyle.CONTOUR
            Deco.NONE -> IconStyle.PLEIN
        }
    }
}

// ------------------------------------------------------------------ Construction des couleurs

private fun lightScheme(sp: ThemeSpec): ColorScheme {
    val p = sp.primary; val s = sp.secondary; val t = sp.tertiary; val n = sp.neutral
    val ink = if (sp.deco == Deco.PAPER) Color(0xFF2B1D12) else Color(0xFF1B1C1E)
    return lightColorScheme(
        primary = p, onPrimary = Color.White,
        primaryContainer = lerp(p, Color.White, 0.82f), onPrimaryContainer = lerp(p, Color.Black, 0.6f),
        secondary = s, onSecondary = Color.White,
        secondaryContainer = lerp(s, Color.White, 0.8f), onSecondaryContainer = lerp(s, Color.Black, 0.65f),
        tertiary = t, onTertiary = Color.White,
        tertiaryContainer = lerp(t, Color.White, 0.8f), onTertiaryContainer = lerp(t, Color.Black, 0.65f),
        background = n, onBackground = ink, surface = n, onSurface = ink,
        surfaceVariant = lerp(n, p, 0.08f), onSurfaceVariant = lerp(ink, p, 0.25f).copy(alpha = 0.85f),
        surfaceContainerLowest = lerp(n, Color.White, 0.6f),
        surfaceContainerLow = lerp(n, p, 0.03f),
        surfaceContainer = lerp(n, p, 0.06f),
        surfaceContainerHigh = lerp(n, p, 0.09f),
        surfaceContainerHighest = lerp(n, p, 0.12f),
        outline = lerp(ink, n, 0.55f), outlineVariant = lerp(ink, n, 0.8f),
    )
}

private fun darkScheme(sp: ThemeSpec, black: Boolean): ColorScheme {
    val p = lerp(sp.primary, Color.White, 0.5f); val s = lerp(sp.secondary, Color.White, 0.45f); val t = lerp(sp.tertiary, Color.White, 0.45f)
    val base = if (black) Color.Black else lerp(Color(0xFF101214), sp.primary, 0.06f)
    val ink = Color(0xFFE4E3E0)
    return darkColorScheme(
        primary = p, onPrimary = lerp(sp.primary, Color.Black, 0.6f),
        primaryContainer = lerp(sp.primary, Color.Black, 0.35f), onPrimaryContainer = lerp(p, Color.White, 0.6f),
        secondary = s, onSecondary = lerp(sp.secondary, Color.Black, 0.6f),
        secondaryContainer = lerp(sp.secondary, Color.Black, 0.45f), onSecondaryContainer = lerp(s, Color.White, 0.6f),
        tertiary = t, onTertiary = lerp(sp.tertiary, Color.Black, 0.6f),
        tertiaryContainer = lerp(sp.tertiary, Color.Black, 0.45f), onTertiaryContainer = lerp(t, Color.White, 0.6f),
        background = base, onBackground = ink, surface = base, onSurface = ink,
        surfaceVariant = lerp(base, p, 0.12f), onSurfaceVariant = lerp(ink, p, 0.2f).copy(alpha = 0.8f),
        surfaceContainerLowest = base,
        surfaceContainerLow = lerp(base, p, if (black) 0.06f else 0.05f),
        surfaceContainer = lerp(base, p, if (black) 0.09f else 0.08f),
        surfaceContainerHigh = lerp(base, p, 0.12f),
        surfaceContainerHighest = lerp(base, p, 0.15f),
        outline = lerp(ink, base, 0.5f), outlineVariant = lerp(ink, base, 0.78f),
    )
}

/** Thèmes sombres à couleurs éclatantes (néon, grimoire, terminal…) : fond profond, accents purs. */
private fun vividScheme(sp: ThemeSpec, black: Boolean): ColorScheme {
    val base = if (black) Color.Black else sp.neutral
    val p = sp.primary; val s = sp.secondary; val t = sp.tertiary
    val ink = lerp(Color(0xFFEDEBF2), p, 0.08f)
    return darkColorScheme(
        primary = p, onPrimary = lerp(base, Color.Black, 0.5f),
        primaryContainer = lerp(base, p, 0.28f), onPrimaryContainer = lerp(p, Color.White, 0.35f),
        secondary = s, onSecondary = lerp(base, Color.Black, 0.5f),
        secondaryContainer = lerp(base, s, 0.24f), onSecondaryContainer = lerp(s, Color.White, 0.35f),
        tertiary = t, onTertiary = lerp(base, Color.Black, 0.5f),
        tertiaryContainer = lerp(base, t, 0.22f), onTertiaryContainer = lerp(t, Color.White, 0.35f),
        background = base, onBackground = ink, surface = base, onSurface = ink,
        surfaceVariant = lerp(base, p, 0.14f), onSurfaceVariant = lerp(ink, s, 0.3f).copy(alpha = 0.85f),
        surfaceContainerLowest = base,
        surfaceContainerLow = lerp(base, p, 0.07f),
        surfaceContainer = lerp(base, p, 0.1f),
        surfaceContainerHigh = lerp(base, p, 0.14f),
        surfaceContainerHighest = lerp(base, p, 0.18f),
        outline = lerp(p, base, 0.35f), outlineVariant = lerp(p, base, 0.7f),
    )
}

private fun Typography.withFont(f: FontFamily) = Typography(
    displayLarge = displayLarge.copy(fontFamily = f), displayMedium = displayMedium.copy(fontFamily = f), displaySmall = displaySmall.copy(fontFamily = f),
    headlineLarge = headlineLarge.copy(fontFamily = f), headlineMedium = headlineMedium.copy(fontFamily = f), headlineSmall = headlineSmall.copy(fontFamily = f),
    titleLarge = titleLarge.copy(fontFamily = f), titleMedium = titleMedium.copy(fontFamily = f), titleSmall = titleSmall.copy(fontFamily = f),
    bodyLarge = bodyLarge.copy(fontFamily = f), bodyMedium = bodyMedium.copy(fontFamily = f), bodySmall = bodySmall.copy(fontFamily = f),
    labelLarge = labelLarge.copy(fontFamily = f), labelMedium = labelMedium.copy(fontFamily = f), labelSmall = labelSmall.copy(fontFamily = f),
)

@Composable
fun CalepinTheme(content: @Composable () -> Unit) {
    val ctx = LocalContext.current
    val a = remember { Appearance.get(ctx) }
    val palette by a.palette.collectAsStateWithLifecycle()
    val random by a.random.collectAsStateWithLifecycle()
    val mode by a.dark.collectAsStateWithLifecycle()
    val text by a.text.collectAsStateWithLifecycle()
    val shapeChoice by a.shapes.collectAsStateWithLifecycle()
    val fontChoice by a.font.collectAsStateWithLifecycle()
    val iconChoice by a.icons.collectAsStateWithLifecycle()
    val spec = if (palette == Palette.ALEATOIRE) random else palette.spec()
    val system = isSystemInDarkTheme()
    val dark = spec.forceDark ?: when (mode) {
        DarkMode.SYSTEM -> system
        DarkMode.LIGHT -> false
        DarkMode.DARK, DarkMode.BLACK -> true
    }
    val black = mode == DarkMode.BLACK && dark
    val scheme = when {
        palette == Palette.DYNAMIQUE && Build.VERSION.SDK_INT >= 31 ->
            if (dark) dynamicDarkColorScheme(ctx).let { if (black) it.copy(background = Color.Black, surface = Color.Black) else it }
            else dynamicLightColorScheme(ctx)
        dark && spec.vivid -> vividScheme(spec, black)
        dark -> darkScheme(spec, black)
        else -> lightScheme(spec)
    }
    val shapeStyle = if (shapeChoice == ShapeStyle.AUTO) spec.shape else shapeChoice
    fun corner(v: Int): CornerBasedShape = if (shapeStyle.cut) CutCornerShape(v.dp) else RoundedCornerShape(v.dp)
    val shapes = Shapes(
        extraSmall = corner(shapeStyle.small / 2),
        small = corner(shapeStyle.small),
        medium = corner(shapeStyle.medium),
        large = corner(shapeStyle.large),
        extraLarge = corner(shapeStyle.large + 6),
    )
    val font = (if (fontChoice == FontChoice.AUTO) spec.font else fontChoice).family()
    val typography = remember(font) { Typography().withFont(font) }
    val look = Look(
        deco = spec.deco,
        icons = if (iconChoice == IconStyle.AUTO) Appearance.iconsFor(spec.deco, dark) else iconChoice,
        dark = dark,
    )
    // Icônes de la barre d'état lisibles sur fond clair comme sombre
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as? Activity)?.window ?: return@SideEffect
            WindowCompat.getInsetsController(window, view).apply {
                isAppearanceLightStatusBars = !dark
                isAppearanceLightNavigationBars = !dark
            }
        }
    }
    val density = LocalDensity.current
    CompositionLocalProvider(
        LocalDensity provides Density(density.density, density.fontScale * text.scale),
        LocalLook provides look,
    ) {
        MaterialTheme(colorScheme = scheme, shapes = shapes, typography = typography, content = content)
    }
}

fun EntityType.icon(): ImageVector = when (this) {
    EntityType.PHONE -> Icons.Filled.Phone
    EntityType.EMAIL -> Icons.Filled.Email
    EntityType.URL -> Icons.Filled.Language
    EntityType.DATE -> Icons.Filled.Event
    EntityType.ADDRESS -> Icons.Filled.Place
}
