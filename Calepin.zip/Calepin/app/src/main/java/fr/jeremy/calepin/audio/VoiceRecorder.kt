package fr.jeremy.calepin.audio

import android.annotation.SuppressLint
import android.content.Context
import android.media.AudioRecord
import android.media.MediaRecorder
import android.os.Build
import fr.jeremy.calepin.AudioFormat
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileOutputStream
import kotlin.math.abs

/**
 * Enregistre la voix :
 *  - M4A (AAC) avec l'encodeur intégré d'Android ;
 *  - MP3 en captant le son brut puis en l'encodant au fil de l'eau (Shine).
 * L'appelant doit avoir obtenu la permission RECORD_AUDIO.
 */
class VoiceRecorder(private val context: Context) {

    private var mediaRecorder: MediaRecorder? = null
    private var audioRecord: AudioRecord? = null
    private var thread: Thread? = null
    @Volatile private var running = false
    @Volatile private var peak = 0
    private var startedAt = 0L
    private var error: Throwable? = null

    /** Niveau sonore récent, de 0 à 1 (pour l'indicateur). */
    fun level(): Float {
        val raw = mediaRecorder?.let { runCatching { it.maxAmplitude }.getOrDefault(0) } ?: peak.also { peak = 0 }
        return (raw / 20_000f).coerceIn(0f, 1f)
    }

    fun elapsedMs(): Long = if (startedAt == 0L) 0 else System.currentTimeMillis() - startedAt

    fun start(file: File, format: AudioFormat, bitrateKbps: Int) {
        file.parentFile?.mkdirs()
        error = null
        when (format) {
            AudioFormat.M4A -> startM4a(file, bitrateKbps)
            AudioFormat.MP3 -> startMp3(file, bitrateKbps)
        }
        startedAt = System.currentTimeMillis()
    }

    @Suppress("DEPRECATION")
    private fun startM4a(file: File, bitrateKbps: Int) {
        val r = if (Build.VERSION.SDK_INT >= 31) MediaRecorder(context) else MediaRecorder()
        r.setAudioSource(MediaRecorder.AudioSource.MIC)
        r.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
        r.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
        r.setAudioSamplingRate(SAMPLE_RATE)
        r.setAudioChannels(1)
        r.setAudioEncodingBitRate(bitrateKbps * 1000)
        r.setOutputFile(file.absolutePath)
        r.prepare()
        r.start()
        mediaRecorder = r
    }

    @SuppressLint("MissingPermission")
    private fun startMp3(file: File, bitrateKbps: Int) {
        val minBuf = AudioRecord.getMinBufferSize(
            SAMPLE_RATE, android.media.AudioFormat.CHANNEL_IN_MONO, android.media.AudioFormat.ENCODING_PCM_16BIT,
        )
        val rec = AudioRecord(
            MediaRecorder.AudioSource.MIC, SAMPLE_RATE,
            android.media.AudioFormat.CHANNEL_IN_MONO, android.media.AudioFormat.ENCODING_PCM_16BIT,
            maxOf(minBuf, SAMPLE_RATE), // ~0,5 s de marge
        )
        check(rec.state == AudioRecord.STATE_INITIALIZED) { "Micro indisponible" }
        val encoder = Mp3Encoder(SAMPLE_RATE, 1, bitrateKbps, BufferedOutputStream(FileOutputStream(file)))
        audioRecord = rec
        running = true
        rec.startRecording()
        thread = Thread({
            val buf = ShortArray(2048)
            try {
                while (running) {
                    val n = rec.read(buf, 0, buf.size)
                    if (n > 0) {
                        var p = 0
                        for (i in 0 until n) { val a = abs(buf[i].toInt()); if (a > p) p = a }
                        if (p > peak) peak = p
                        encoder.write(buf, n)
                    }
                }
            } catch (t: Throwable) {
                error = t
            } finally {
                runCatching { encoder.close() }
            }
        }, "calepin-mp3").apply { start() }
    }

    /** Arrête et renvoie la durée en millisecondes. */
    fun stop(): Long {
        val duration = elapsedMs()
        mediaRecorder?.let { r ->
            runCatching { r.stop() }
            r.release()
        }
        mediaRecorder = null
        audioRecord?.let { r ->
            running = false
            runCatching { r.stop() }
            thread?.join(3000)
            r.release()
        }
        audioRecord = null
        thread = null
        startedAt = 0L
        error?.let { throw it }
        return duration
    }

    /** Annule sans garder le fichier. */
    fun cancel(file: File) {
        runCatching { stop() }
        file.delete()
    }

    companion object {
        const val SAMPLE_RATE = 44100
        fun dir(context: Context): File = File(context.filesDir, "recordings")
    }
}
