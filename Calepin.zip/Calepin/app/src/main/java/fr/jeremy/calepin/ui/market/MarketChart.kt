package fr.jeremy.calepin.ui.market

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.ShowChart
import androidx.compose.material.icons.filled.ZoomIn
import androidx.compose.material.icons.filled.ZoomOut
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import fr.jeremy.calepin.i18n.I18n
import fr.jeremy.calepin.i18n.RawText
import fr.jeremy.calepin.i18n.Text
import fr.jeremy.calepin.market.Candle
import fr.jeremy.calepin.market.Indicators
import fr.jeremy.calepin.market.MarketData
import fr.jeremy.calepin.market.Series
import fr.jeremy.calepin.market.Timeframe
import fr.jeremy.calepin.ui.appBorder
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import kotlin.math.abs

private val UPC = Color(0xFF2E9E4F)
private val DOWNC = Color(0xFFE0453A)

private fun intraday(tf: Timeframe) = tf != Timeframe.D1 && tf != Timeframe.W1

private fun fmt(pattern: String, t: Long) = SimpleDateFormat(fr.jeremy.calepin.i18n.I18n.pattern(pattern), I18n.locale).format(Date(t * 1000))

/** Date et heure complètes d'une bougie (au-dessus du graphique). */
private fun fullTime(tf: Timeframe, t: Long): String = when {
    intraday(tf) -> fmt("EEE d MMM HH:mm", t)
    tf == Timeframe.D1 -> fmt("EEE d MMM yyyy", t)
    else -> I18n.tr("Semaine du") + " " + fmt("d MMM yyyy", t)
}

private fun sameDay(a: Long, b: Long): Boolean {
    val x = Calendar.getInstance().apply { timeInMillis = a * 1000 }
    val y = Calendar.getInstance().apply { timeInMillis = b * 1000 }
    return x.get(Calendar.YEAR) == y.get(Calendar.YEAR) && x.get(Calendar.DAY_OF_YEAR) == y.get(Calendar.DAY_OF_YEAR)
}

private fun sameYear(a: Long, b: Long): Boolean {
    val x = Calendar.getInstance().apply { timeInMillis = a * 1000 }
    val y = Calendar.getInstance().apply { timeInMillis = b * 1000 }
    return x.get(Calendar.YEAR) == y.get(Calendar.YEAR)
}

/** Libellé de l'axe du temps : heure en séance, date au changement de jour, mois et année sur les longues durées. */
private fun axisLabel(tf: Timeframe, t: Long, prev: Long?): String = when {
    intraday(tf) -> if (prev == null || !sameDay(prev, t)) fmt("d MMM", t) + "\n" + fmt("HH:mm", t) else fmt("HH:mm", t)
    tf == Timeframe.D1 -> if (prev == null || !sameYear(prev, t)) fmt("d MMM", t) + "\n" + fmt("yyyy", t) else fmt("d MMM", t)
    else -> fmt("MMM", t) + "\n" + fmt("yyyy", t)
}

private fun numFmt(x: Double, d: Int): String = if (x.isNaN()) "–" else String.format(Locale.FRANCE, "%,.${d}f", x).replace(' ', ' ')

private fun decimals(price: Double) = when {
    abs(price) < 2 -> 4
    abs(price) < 20 -> 3
    else -> 2
}

/** Nombres de bougies affichées (zoom). */
private val ZOOMS = listOf(20, 40, 60, 90, 130, 200, 300, 500)

/**
 * Graphique d'un instrument dans une bulle : durée des bougies au choix, bougies ou courbe, zoom,
 * prix à droite, heure ou date en bas, et le détail de la bougie touchée (glisser le doigt pour parcourir).
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ChartCard(symbol: String, reload: Int) {
    var tf by rememberSaveable { mutableStateOf(Timeframe.D1) }
    var candlesMode by rememberSaveable { mutableStateOf(true) }
    var zoom by rememberSaveable { mutableIntStateOf(3) }
    var selected by remember(symbol, tf) { mutableStateOf<Int?>(null) }
    val series by produceState<Series?>(null, symbol, tf, reload) {
        value = null
        value = runCatching { withContext(Dispatchers.IO) { MarketData.series(symbol, tf) } }.getOrNull()
    }
    val cs = MaterialTheme.colorScheme
    Surface(shape = MaterialTheme.shapes.large, color = cs.surfaceContainerLow, border = appBorder(), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            // Durée d'une bougie : 7 cases de même taille, toutes visibles
            TimeframePicker(tf) { tf = it; selected = null }
            val s = series
            val all = s?.candles.orEmpty()
            if (s == null || all.size < 2) {
                Box(Modifier.fillMaxWidth().height(260.dp), contentAlignment = Alignment.Center) {
                    Text(if (s == null) "Chargement des cours…" else "Graphique indisponible pour cette période.", color = cs.onSurfaceVariant)
                }
                return@Column
            }
            val count = ZOOMS[zoom.coerceIn(0, ZOOMS.size - 1)].coerceAtMost(all.size)
            val start = all.size - count
            val closesAll = all.map { it.c }
            val ma20 = Indicators.sma(closesAll, 20)
            val (bl, _, bh) = Indicators.bollinger(closesAll, 20, 2.0)
            val view = all.subList(start, all.size)
            val sel = selected?.coerceIn(0, view.size - 1)
            val shown = view[sel ?: (view.size - 1)]
            val prevClose = if (sel == null) s.prevClose.takeIf { it > 0 && tf == Timeframe.D1 } ?: view.first().o
            else (if (start + sel > 0) all[start + sel - 1].c else shown.o)
            val ch = if (prevClose > 0) (shown.c - prevClose) / prevClose * 100 else 0.0
            val d = decimals(shown.c)
            // Détail de la bougie touchée (ou de la dernière)
            Column {
                RawText(fullTime(tf, shown.t), style = MaterialTheme.typography.labelMedium, color = cs.onSurfaceVariant)
                Row(verticalAlignment = Alignment.Bottom) {
                    RawText(numFmt(shown.c, d), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.width(8.dp))
                    RawText((if (ch >= 0) "+" else "") + numFmt(ch, 2) + " %", color = if (ch >= 0) UPC else DOWNC, style = MaterialTheme.typography.titleSmall)
                }
                RawText(
                    I18n.tr("Ouv.") + " " + numFmt(shown.o, d) + "   " + I18n.tr("Haut") + " " + numFmt(shown.h, d) + "   " +
                        I18n.tr("Bas") + " " + numFmt(shown.l, d) + (if (shown.v > 0) "   " + I18n.tr("Vol.") + " " + compact(shown.v) else ""),
                    style = MaterialTheme.typography.labelSmall, color = cs.onSurfaceVariant,
                )
            }
            // Période réellement affichée
            RawText(
                I18n.tr("Affiché") + " : " + fullTime(tf, view.first().t) + "  →  " + fullTime(tf, view.last().t),
                style = MaterialTheme.typography.labelSmall, color = cs.onSurfaceVariant,
            )
            CandleCanvas(
                view = view, tf = tf, candlesMode = candlesMode,
                ma = ma20.subList(start, all.size), lo = bl.subList(start, all.size), hi = bh.subList(start, all.size),
                lastPrice = s.price, selected = sel,
                onSelect = { selected = it },
            )
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = { candlesMode = !candlesMode }) {
                    Icon(if (candlesMode) Icons.Filled.ShowChart else Icons.Filled.BarChart, I18n.tr(if (candlesMode) "Courbe" else "Bougies"))
                }
                IconButton(enabled = zoom < ZOOMS.size - 1 && count < all.size, onClick = { zoom++; selected = null }) { Icon(Icons.Filled.ZoomOut, I18n.tr("Voir plus de bougies")) }
                IconButton(enabled = zoom > 0, onClick = { zoom--; selected = null }) { Icon(Icons.Filled.ZoomIn, I18n.tr("Voir moins de bougies")) }
                RawText("$count " + I18n.tr("bougies"), style = MaterialTheme.typography.labelSmall, color = cs.onSurfaceVariant, modifier = Modifier.weight(1f))
                if (selected != null) androidx.compose.material3.TextButton(onClick = { selected = null }) { Text("Dernier cours") }
            }
            FlowRow(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Legend(cs.tertiary, "Moyenne 20")
                Legend(cs.outline, "Bandes de Bollinger")
                Legend(cs.primary, "Dernier cours")
            }
            Text("Touche ou fais glisser le doigt sur le graphique pour voir chaque bougie.", style = MaterialTheme.typography.labelSmall, color = cs.onSurfaceVariant)
        }
    }
}

/** Valeur et unité de chaque durée, sur deux lignes. */
private fun tfParts(t: Timeframe): Pair<String, String> = when (t) {
    Timeframe.M5 -> "5" to "min"
    Timeframe.M15 -> "15" to "min"
    Timeframe.M30 -> "30" to "min"
    Timeframe.H1 -> "1" to "heure"
    Timeframe.H4 -> "4" to "heures"
    Timeframe.D1 -> "1" to "jour"
    Timeframe.W1 -> "1" to "sem."
}

/**
 * Choix de la durée d'une bougie : une rangée de 7 cases égales (minutes et heures, puis jour et semaine),
 * la case choisie en couleur.
 */
@Composable
fun TimeframePicker(value: Timeframe, onChange: (Timeframe) -> Unit) {
    val cs = MaterialTheme.colorScheme
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Text("Une bougie =", style = MaterialTheme.typography.labelMedium, color = cs.onSurfaceVariant)
        Surface(shape = RoundedCornerShape(14.dp), color = cs.surfaceContainerHigh, modifier = Modifier.fillMaxWidth()) {
            Row(Modifier.padding(3.dp), horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                Timeframe.entries.forEach { t ->
                    val on = t == value
                    val (n, unit) = tfParts(t)
                    // Séparation discrète entre les durées « intraday » et jour / semaine
                    if (t == Timeframe.D1) Box(Modifier.width(1.dp).height(40.dp).align(Alignment.CenterVertically)) {
                        Canvas(Modifier.width(1.dp).height(40.dp)) { drawRect(cs.outlineVariant) }
                    }
                    Surface(
                        onClick = { onChange(t) },
                        shape = RoundedCornerShape(11.dp),
                        color = if (on) cs.primary else Color.Transparent,
                        modifier = Modifier.weight(1f),
                    ) {
                        Column(Modifier.padding(vertical = 6.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            RawText(n, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = if (on) cs.onPrimary else cs.onSurface, maxLines = 1)
                            Text(unit, style = MaterialTheme.typography.labelSmall, color = if (on) cs.onPrimary else cs.onSurfaceVariant, maxLines = 1)
                        }
                    }
                }
            }
        }
    }
}

private fun shortTf(t: Timeframe) = when (t) {
    Timeframe.M5 -> "5 min"
    Timeframe.M15 -> "15 min"
    Timeframe.M30 -> "30 min"
    Timeframe.H1 -> "1 h"
    Timeframe.H4 -> "4 h"
    Timeframe.D1 -> "1 jour"
    Timeframe.W1 -> "1 semaine"
}

private fun compact(v: Double): String = when {
    v >= 1e9 -> numFmt(v / 1e9, 1) + " Md"
    v >= 1e6 -> numFmt(v / 1e6, 1) + " M"
    v >= 1e3 -> numFmt(v / 1e3, 1) + " k"
    else -> numFmt(v, 0)
}

@Composable
private fun Legend(color: Color, label: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(width = 14.dp, height = 3.dp).padding(0.dp)) {
            Canvas(Modifier.size(width = 14.dp, height = 3.dp)) { drawRect(color) }
        }
        Spacer(Modifier.width(4.dp))
        Text(label, style = MaterialTheme.typography.labelSmall)
    }
}

@Composable
private fun CandleCanvas(
    view: List<Candle>,
    tf: Timeframe,
    candlesMode: Boolean,
    ma: List<Double>,
    lo: List<Double>,
    hi: List<Double>,
    lastPrice: Double,
    selected: Int?,
    onSelect: (Int?) -> Unit,
) {
    val cs = MaterialTheme.colorScheme
    val measurer = rememberTextMeasurer()
    val labelStyle = TextStyle(fontSize = 10.sp, color = cs.onSurfaceVariant)
    val grid = cs.outlineVariant.copy(alpha = 0.6f)
    val ink = cs.onSurface
    val d = decimals(view.last().c)
    // Place réservée aux prix (à droite) et aux heures (en bas)
    val sample = measurer.measure(numFmt(view.maxOf { it.h }, d), labelStyle)
    val n = view.size
    fun indexAt(x: Float, plotW: Float): Int = ((x / plotW) * n).toInt().coerceIn(0, n - 1)
    Canvas(
        Modifier
            .fillMaxWidth()
            .height(280.dp)
            .pointerInput(n, tf) {
                detectTapGestures { pos ->
                    val plotW = size.width - sample.size.width - 12f
                    onSelect(if (pos.x > plotW) null else indexAt(pos.x, plotW))
                }
            }
            .pointerInput(n, tf) {
                detectHorizontalDragGestures(
                    onDragStart = { pos -> onSelect(indexAt(pos.x, size.width - sample.size.width - 12f)) },
                ) { change, _ ->
                    change.consume()
                    onSelect(indexAt(change.position.x, size.width - sample.size.width - 12f))
                }
            },
    ) {
        val gutter = sample.size.width + 12f
        val bottom = 30.dp.toPx()
        val plotW = size.width - gutter
        val plotH = size.height - bottom
        val vals = view.flatMap { listOf(it.h, it.l) } + (ma + lo + hi).filter { !it.isNaN() } + lastPrice
        var mn = vals.filter { !it.isNaN() }.min()
        var mx = vals.filter { !it.isNaN() }.max()
        if (mx - mn < 1e-9) { mx += 1; mn -= 1 }
        val pad = (mx - mn) * 0.06
        mn -= pad; mx += pad
        fun y(v: Double) = (plotH * (1 - (v - mn) / (mx - mn))).toFloat()
        val step = plotW / n
        fun xc(i: Int) = step * i + step / 2

        // Grille horizontale et prix
        for (k in 0..4) {
            val v = mn + (mx - mn) * k / 4
            val gy = y(v)
            drawLine(grid, Offset(0f, gy), Offset(plotW, gy), 1f)
            val tl = measurer.measure(numFmt(v, d), labelStyle)
            drawText(tl, topLeft = Offset(plotW + 6f, (gy - tl.size.height / 2f).coerceIn(0f, plotH - tl.size.height)))
        }
        // Grille verticale et heures
        val ticks = 4
        var prevT: Long? = null
        for (k in 0 until ticks) {
            val i = ((n - 1) * (k + 0.5) / ticks).toInt().coerceIn(0, n - 1)
            val gx = xc(i)
            drawLine(grid, Offset(gx, 0f), Offset(gx, plotH), 1f)
            val tl = measurer.measure(axisLabel(tf, view[i].t, prevT), labelStyle)
            prevT = view[i].t
            drawText(tl, topLeft = Offset((gx - tl.size.width / 2f).coerceIn(0f, plotW - tl.size.width), plotH + 4f))
        }
        // Bandes de Bollinger et moyenne 20
        fun line(values: List<Double>, color: Color, width: Float) {
            val p = Path()
            var started = false
            values.forEachIndexed { i, v ->
                if (v.isNaN()) return@forEachIndexed
                if (!started) { p.moveTo(xc(i), y(v)); started = true } else p.lineTo(xc(i), y(v))
            }
            if (started) drawPath(p, color, style = Stroke(width))
        }
        line(lo, cs.outline.copy(alpha = 0.55f), 1.2f * density)
        line(hi, cs.outline.copy(alpha = 0.55f), 1.2f * density)
        line(ma, cs.tertiary, 1.6f * density)
        if (candlesMode) {
            val bw = (step * 0.65f).coerceAtLeast(1f)
            view.forEachIndexed { i, c ->
                val col = if (c.c >= c.o) UPC else DOWNC
                val x = xc(i)
                drawLine(col, Offset(x, y(c.h)), Offset(x, y(c.l)), (1f * density).coerceAtMost(bw))
                val top = y(maxOf(c.o, c.c))
                val h = (y(minOf(c.o, c.c)) - top).coerceAtLeast(1.5f)
                drawRect(col, Offset(x - bw / 2, top), Size(bw, h))
            }
        } else {
            val first = view.first().c
            val col = if (view.last().c >= first) UPC else DOWNC
            val p = Path()
            view.forEachIndexed { i, c -> if (i == 0) p.moveTo(xc(i), y(c.c)) else p.lineTo(xc(i), y(c.c)) }
            val fill = Path().apply {
                addPath(p)
                lineTo(xc(n - 1), plotH); lineTo(xc(0), plotH); close()
            }
            drawPath(fill, Brush.verticalGradient(listOf(col.copy(alpha = 0.28f), col.copy(alpha = 0.02f)), startY = 0f, endY = plotH))
            drawPath(p, col, style = Stroke(2.2f * density))
        }
        // Dernier cours : trait pointillé et étiquette à droite
        if (!lastPrice.isNaN() && lastPrice > 0) {
            val ly = y(lastPrice)
            drawLine(cs.primary, Offset(0f, ly), Offset(plotW, ly), 1.2f * density, pathEffect = PathEffect.dashPathEffect(floatArrayOf(8f, 6f)))
            val tl = measurer.measure(numFmt(lastPrice, d), labelStyle.copy(color = cs.onPrimary, fontWeight = FontWeight.Bold))
            val top = (ly - tl.size.height / 2f - 2f).coerceIn(0f, plotH - tl.size.height - 4f)
            drawRoundRect(cs.primary, Offset(plotW + 2f, top), Size(tl.size.width + 8f, tl.size.height + 4f), CornerRadius(6f, 6f))
            drawText(tl, topLeft = Offset(plotW + 6f, top + 2f))
        }
        // Bougie touchée : réticule et valeur
        if (selected != null && selected in view.indices) {
            val c = view[selected]
            val x = xc(selected)
            val yy = y(c.c)
            drawLine(ink.copy(alpha = 0.6f), Offset(x, 0f), Offset(x, plotH), 1f * density)
            drawLine(ink.copy(alpha = 0.4f), Offset(0f, yy), Offset(plotW, yy), 1f * density)
            drawCircle(ink, 4f * density, Offset(x, yy))
            val tl = measurer.measure(fullTime(tf, c.t), labelStyle.copy(color = cs.inverseOnSurface))
            val left = (x - tl.size.width / 2f - 6f).coerceIn(0f, plotW - tl.size.width - 12f)
            drawRoundRect(cs.inverseSurface, Offset(left, plotH + 2f), Size(tl.size.width + 12f, tl.size.height + 6f), CornerRadius(6f, 6f))
            drawText(tl, topLeft = Offset(left + 6f, plotH + 5f))
        }
    }
}
