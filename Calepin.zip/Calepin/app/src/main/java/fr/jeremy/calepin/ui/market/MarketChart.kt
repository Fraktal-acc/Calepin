package fr.jeremy.calepin.ui.market

import androidx.compose.foundation.Canvas
import kotlin.math.roundToInt
import kotlinx.coroutines.delay
import androidx.compose.ui.window.DialogProperties
import androidx.compose.ui.window.Dialog
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.material3.TextButton
import androidx.compose.material.icons.filled.FullscreenExit
import androidx.compose.material.icons.filled.Fullscreen
import androidx.compose.foundation.gestures.calculateCentroid
import androidx.compose.foundation.gestures.calculatePan
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.ShowChart
import androidx.compose.material.icons.filled.ZoomIn
import androidx.compose.material.icons.filled.ZoomOut
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import fr.jeremy.calepin.i18n.I18n
import fr.jeremy.calepin.i18n.RawText
import fr.jeremy.calepin.i18n.Text
import fr.jeremy.calepin.market.Candle
import fr.jeremy.calepin.market.Indicators
import fr.jeremy.calepin.market.MarketData
import fr.jeremy.calepin.market.Series
import fr.jeremy.calepin.market.Timeframe
import fr.jeremy.calepin.ui.appBorder
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import kotlin.math.abs

private val UPC = Color(0xFF2E9E4F)
private val DOWNC = Color(0xFFE0453A)

private fun intraday(tf: Timeframe) = tf != Timeframe.D1 && tf != Timeframe.W1

private fun fmt(pattern: String, t: Long) = SimpleDateFormat(fr.jeremy.calepin.i18n.I18n.pattern(pattern), I18n.locale).format(Date(t * 1000))

/** Date et heure complètes d'une bougie (au-dessus du graphique). */
private fun fullTime(tf: Timeframe, t: Long): String = when {
    intraday(tf) -> fmt("EEE d MMM HH:mm", t)
    tf == Timeframe.D1 -> fmt("EEE d MMM yyyy", t)
    else -> I18n.tr("Semaine du") + " " + fmt("d MMM yyyy", t)
}

private fun sameDay(a: Long, b: Long): Boolean {
    val x = Calendar.getInstance().apply { timeInMillis = a * 1000 }
    val y = Calendar.getInstance().apply { timeInMillis = b * 1000 }
    return x.get(Calendar.YEAR) == y.get(Calendar.YEAR) && x.get(Calendar.DAY_OF_YEAR) == y.get(Calendar.DAY_OF_YEAR)
}

private fun sameYear(a: Long, b: Long): Boolean {
    val x = Calendar.getInstance().apply { timeInMillis = a * 1000 }
    val y = Calendar.getInstance().apply { timeInMillis = b * 1000 }
    return x.get(Calendar.YEAR) == y.get(Calendar.YEAR)
}

/** Libellé de l'axe du temps : heure en séance, date au changement de jour, mois et année sur les longues durées. */
private fun axisLabel(tf: Timeframe, t: Long, prev: Long?): String = when {
    intraday(tf) -> if (prev == null || !sameDay(prev, t)) fmt("d MMM", t) + "\n" + fmt("HH:mm", t) else fmt("HH:mm", t)
    tf == Timeframe.D1 -> if (prev == null || !sameYear(prev, t)) fmt("d MMM", t) + "\n" + fmt("yyyy", t) else fmt("d MMM", t)
    else -> fmt("MMM", t) + "\n" + fmt("yyyy", t)
}

private fun numFmt(x: Double, d: Int): String = if (x.isNaN()) "–" else String.format(Locale.FRANCE, "%,.${d}f", x).replace(' ', ' ')

private fun decimals(price: Double) = when {
    abs(price) < 2 -> 4
    abs(price) < 20 -> 3
    else -> 2
}

/** Cours déjà chargés : changer de durée ou rouvrir une fiche est immédiat, seules les dernières bougies sont rechargées. */
object ChartCache {
    private val map = HashMap<String, Series>()
    fun get(k: String): Series? = synchronized(map) { map[k] }
    fun put(k: String, s: Series) = synchronized(map) { map[k] = s }
}

private const val MIN_CANDLES = 12f

/** Fréquence d'actualisation du graphique : quelques secondes pour les bougies courtes. */
private fun refreshMs(tf: Timeframe) = when (tf) {
    Timeframe.D1 -> 10_000L
    Timeframe.W1 -> 30_000L
    else -> 5_000L
}

/**
 * Graphique d'un instrument dans une bulle : durée des bougies au choix, bougies ou courbe, prix à droite,
 * heure ou date en bas, détail de la bougie touchée. Pincer à deux doigts zoome autour des doigts ;
 * toucher le graphique l'ouvre en plein écran. Les cours se mettent à jour tout seuls.
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ChartCard(symbol: String, reload: Int) {
    var tf by rememberSaveable { mutableStateOf(Timeframe.D1) }
    var candlesMode by rememberSaveable { mutableStateOf(true) }
    var full by rememberSaveable { mutableStateOf(false) }
    var winCount by rememberSaveable { mutableFloatStateOf(90f) }
    var winRight by rememberSaveable { mutableFloatStateOf(0f) }
    var yPan by rememberSaveable { mutableFloatStateOf(0f) }
    var selected by remember(symbol, tf) { mutableStateOf<Int?>(null) }
    var updatedAt by remember { mutableLongStateOf(0L) }
    var failed by remember(symbol, tf) { mutableStateOf(false) }
    val key = "$symbol|${tf.name}"
    val series by produceState<Series?>(ChartCache.get(key), symbol, tf, reload) {
        value = ChartCache.get(key)
        failed = false
        while (true) {
            val cur = value
            if (cur == null || reload > 0 && updatedAt == 0L) {
                val s = runCatching { withContext(Dispatchers.IO) { MarketData.series(symbol, tf) } }.getOrNull()
                if (s != null) { value = s; ChartCache.put(key, s); updatedAt = System.currentTimeMillis() } else if (cur == null) failed = true
            } else {
                // Seules les dernières bougies sont rechargées (réponse légère, donc rapide)
                val fresh = runCatching { withContext(Dispatchers.IO) { MarketData.latest(symbol, tf) } }.getOrNull()
                if (fresh != null) {
                    val m = MarketData.merge(cur, fresh, tf)
                    value = m; ChartCache.put(key, m); updatedAt = System.currentTimeMillis()
                }
            }
            delay(if (value == null) 3_000L else refreshMs(tf))
        }
    }
    val cs = MaterialTheme.colorScheme
    val s = series
    val all = s?.candles.orEmpty()
    val total = all.size
    // Fenêtre regardée dans le passé : elle reste en place quand de nouvelles bougies arrivent
    var lastTotal by remember(symbol, tf) { mutableIntStateOf(0) }
    LaunchedEffect(total) {
        if (lastTotal > 0 && total > lastTotal && winRight > 0.5f) winRight += (total - lastTotal)
        lastTotal = total
    }
    fun transform(fx: Float, zoom: Float, panFrac: Float) {
        if (total < 2) return
        val count = winCount.coerceIn(MIN_CANDLES.coerceAtMost(total.toFloat()), total.toFloat())
        val start = total - winRight - count
        val anchor = start + fx * count
        val newCount = (count / zoom).coerceIn(MIN_CANDLES.coerceAtMost(total.toFloat()), total.toFloat())
        val newStart = (anchor - fx * newCount - panFrac * newCount).coerceIn(0f, total - newCount)
        winCount = newCount
        winRight = (total - newStart - newCount).let { if (it < 0.5f) 0f else it }
    }

    val body: @Composable (Modifier, Boolean) -> Unit = { chartModifier, inFull ->
        if (s == null || total < 2) {
            Box(chartModifier, contentAlignment = Alignment.Center) {
                Text(if (s == null && !failed) "Chargement des cours…" else "Graphique indisponible pour cette période.", color = cs.onSurfaceVariant)
            }
        } else {
            val count = winCount.coerceIn(2f, total.toFloat())
            val e0 = (total - winRight).roundToInt().coerceIn(2, total)
            val s0 = (e0 - count.roundToInt()).coerceIn(0, e0 - 2)
            val closesAll = all.map { it.c }
            val ma20 = Indicators.sma(closesAll, 20)
            val (bl, _, bh) = Indicators.bollinger(closesAll, 20, 2.0)
            val view = all.subList(s0, e0)
            val sel = selected?.takeIf { it in s0 until e0 }?.minus(s0)
            val shownIdx = s0 + (sel ?: (view.size - 1))
            val shown = all[shownIdx]
            val prevClose = if (sel == null && e0 == total && tf == Timeframe.D1 && s.prevClose > 0) s.prevClose
            else if (shownIdx > 0) all[shownIdx - 1].c else shown.o
            val ch = if (prevClose > 0) (shown.c - prevClose) / prevClose * 100 else 0.0
            val d = decimals(shown.c)
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                // Détail de la bougie touchée (ou de la dernière affichée)
                Row(verticalAlignment = Alignment.Bottom) {
                    Column(Modifier.weight(1f)) {
                        RawText(fullTime(tf, shown.t), style = MaterialTheme.typography.labelMedium, color = cs.onSurfaceVariant)
                        Row(verticalAlignment = Alignment.Bottom) {
                            RawText(numFmt(shown.c, d), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold)
                            Spacer(Modifier.width(8.dp))
                            RawText((if (ch >= 0) "+" else "") + numFmt(ch, 2) + " %", color = if (ch >= 0) UPC else DOWNC, style = MaterialTheme.typography.titleSmall)
                        }
                    }
                    if (updatedAt > 0) {
                        // Point vert : cours en direct
                        Box(Modifier.size(8.dp).background(if (e0 == total) UPC else cs.outline, CircleShape))
                        Spacer(Modifier.width(4.dp))
                        RawText(fmtClock(updatedAt), style = MaterialTheme.typography.labelSmall, color = cs.onSurfaceVariant)
                    }
                }
                RawText(
                    I18n.tr("Ouv.") + " " + numFmt(shown.o, d) + "   " + I18n.tr("Haut") + " " + numFmt(shown.h, d) + "   " +
                        I18n.tr("Bas") + " " + numFmt(shown.l, d) + (if (shown.v > 0) "   " + I18n.tr("Vol.") + " " + compact(shown.v) else ""),
                    style = MaterialTheme.typography.labelSmall, color = cs.onSurfaceVariant,
                )
                RawText(
                    I18n.tr("Affiché") + " : " + fullTime(tf, view.first().t) + "  →  " + fullTime(tf, view.last().t),
                    style = MaterialTheme.typography.labelSmall, color = cs.onSurfaceVariant,
                )
                CandleCanvas(
                    view = view, tf = tf, candlesMode = candlesMode,
                    ma = ma20.subList(s0, e0), lo = bl.subList(s0, e0), hi = bh.subList(s0, e0),
                    lastPrice = if (e0 == total) s.price else Double.NaN, selected = sel,
                    onSelect = { i -> selected = i?.let { s0 + it } },
                    onDoubleTap = if (inFull) null else ({ full = true }),
                    onTransform = { fx, z, pan -> transform(fx, z, pan) },
                    onPan = { dx, dy ->
                        if (dx != 0f) transform(0.5f, 1f, dx)
                        if (dy != 0f) yPan = (yPan + dy).coerceIn(-5f, 5f)
                    },
                    yPan = yPan,
                    modifier = chartModifier,
                )
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = { candlesMode = !candlesMode }) {
                        Icon(if (candlesMode) Icons.Filled.ShowChart else Icons.Filled.BarChart, I18n.tr(if (candlesMode) "Courbe" else "Bougies"))
                    }
                    IconButton(enabled = count < total, onClick = { transform(1f, 1f / 1.5f, 0f) }) { Icon(Icons.Filled.ZoomOut, I18n.tr("Voir plus de bougies")) }
                    IconButton(enabled = count > MIN_CANDLES, onClick = { transform(1f, 1.5f, 0f) }) { Icon(Icons.Filled.ZoomIn, I18n.tr("Voir moins de bougies")) }
                    RawText("${view.size} " + I18n.tr("bougies"), style = MaterialTheme.typography.labelSmall, color = cs.onSurfaceVariant, modifier = Modifier.weight(1f))
                    if (selected != null || winRight > 0f || yPan != 0f) TextButton(onClick = { selected = null; winRight = 0f; yPan = 0f }) { Text("Dernier cours") }
                    if (!inFull) IconButton(onClick = { full = true }) { Icon(Icons.Filled.Fullscreen, I18n.tr("Agrandir")) }
                }
            }
        }
    }

    Surface(shape = MaterialTheme.shapes.large, color = cs.surfaceContainerLow, border = appBorder(), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            TimeframePicker(tf) { tf = it; selected = null; winRight = 0f; yPan = 0f }
            body(Modifier.fillMaxWidth().height(280.dp), false)
            FlowRow(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Legend(cs.tertiary, "Moyenne 20")
                Legend(cs.outline, "Bandes de Bollinger")
                Legend(cs.primary, "Dernier cours")
            }
            Text(
                "Glisse un doigt pour déplacer le graphique (gauche, droite, haut, bas). Touche une bougie pour voir son détail, ou garde le doigt appuyé puis glisse pour les parcourir. Pince à deux doigts pour zoomer, touche deux fois pour agrandir.",
                style = MaterialTheme.typography.labelSmall, color = cs.onSurfaceVariant,
            )
        }
    }

    if (full) {
        Dialog(onDismissRequest = { full = false }, properties = DialogProperties(usePlatformDefaultWidth = false)) {
            Surface(Modifier.fillMaxSize(), color = cs.surface) {
                Column(Modifier.fillMaxSize().systemBarsPadding().padding(horizontal = 12.dp, vertical = 8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        RawText(s?.name ?: symbol, style = MaterialTheme.typography.titleMedium, maxLines = 1, modifier = Modifier.weight(1f))
                        IconButton(onClick = { full = false }) { Icon(Icons.Filled.FullscreenExit, I18n.tr("Réduire")) }
                    }
                    TimeframePicker(tf) { tf = it; selected = null; winRight = 0f; yPan = 0f }
                    body(Modifier.fillMaxWidth().weight(1f), true)
                }
            }
        }
    }
}

private fun fmtClock(t: Long) = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date(t))

/** Valeur et unité de chaque durée, sur deux lignes. */
private fun tfParts(t: Timeframe): Pair<String, String> = when (t) {
    Timeframe.M5 -> "5" to "min"
    Timeframe.M15 -> "15" to "min"
    Timeframe.M30 -> "30" to "min"
    Timeframe.H1 -> "1" to "heure"
    Timeframe.H4 -> "4" to "heures"
    Timeframe.D1 -> "1" to "jour"
    Timeframe.W1 -> "1" to "sem."
}

/**
 * Choix de la durée d'une bougie : une rangée de 7 cases égales (minutes et heures, puis jour et semaine),
 * la case choisie en couleur.
 */
@Composable
fun TimeframePicker(value: Timeframe, onChange: (Timeframe) -> Unit) {
    val cs = MaterialTheme.colorScheme
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Text("Une bougie =", style = MaterialTheme.typography.labelMedium, color = cs.onSurfaceVariant)
        Surface(shape = RoundedCornerShape(14.dp), color = cs.surfaceContainerHigh, modifier = Modifier.fillMaxWidth()) {
            Row(Modifier.padding(3.dp), horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                Timeframe.entries.forEach { t ->
                    val on = t == value
                    val (n, unit) = tfParts(t)
                    // Séparation discrète entre les durées « intraday » et jour / semaine
                    if (t == Timeframe.D1) Box(Modifier.width(1.dp).height(40.dp).align(Alignment.CenterVertically)) {
                        Canvas(Modifier.width(1.dp).height(40.dp)) { drawRect(cs.outlineVariant) }
                    }
                    Surface(
                        onClick = { onChange(t) },
                        shape = RoundedCornerShape(11.dp),
                        color = if (on) cs.primary else Color.Transparent,
                        modifier = Modifier.weight(1f),
                    ) {
                        Column(Modifier.padding(vertical = 6.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            RawText(n, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = if (on) cs.onPrimary else cs.onSurface, maxLines = 1)
                            Text(unit, style = MaterialTheme.typography.labelSmall, color = if (on) cs.onPrimary else cs.onSurfaceVariant, maxLines = 1)
                        }
                    }
                }
            }
        }
    }
}

private fun shortTf(t: Timeframe) = when (t) {
    Timeframe.M5 -> "5 min"
    Timeframe.M15 -> "15 min"
    Timeframe.M30 -> "30 min"
    Timeframe.H1 -> "1 h"
    Timeframe.H4 -> "4 h"
    Timeframe.D1 -> "1 jour"
    Timeframe.W1 -> "1 semaine"
}

private fun compact(v: Double): String = when {
    v >= 1e9 -> numFmt(v / 1e9, 1) + " Md"
    v >= 1e6 -> numFmt(v / 1e6, 1) + " M"
    v >= 1e3 -> numFmt(v / 1e3, 1) + " k"
    else -> numFmt(v, 0)
}

@Composable
private fun Legend(color: Color, label: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(width = 14.dp, height = 3.dp).padding(0.dp)) {
            Canvas(Modifier.size(width = 14.dp, height = 3.dp)) { drawRect(color) }
        }
        Spacer(Modifier.width(4.dp))
        Text(label, style = MaterialTheme.typography.labelSmall)
    }
}

@Composable
private fun CandleCanvas(
    view: List<Candle>,
    tf: Timeframe,
    candlesMode: Boolean,
    ma: List<Double>,
    lo: List<Double>,
    hi: List<Double>,
    lastPrice: Double,
    selected: Int?,
    onSelect: (Int?) -> Unit,
    /** Double toucher (agrandir), null : rien. */
    onDoubleTap: (() -> Unit)?,
    /** Pincement à deux doigts : (position du centre de 0 à 1, facteur de zoom, déplacement en fraction de largeur). */
    onTransform: (Float, Float, Float) -> Unit,
    /** Doigt qui glisse : déplacement horizontal et vertical, en fraction de la largeur et de la hauteur du graphique. */
    onPan: (Float, Float) -> Unit,
    /** Décalage vertical des prix (fraction de l'écart affiché). */
    yPan: Float,
    modifier: Modifier,
) {
    val cs = MaterialTheme.colorScheme
    val measurer = rememberTextMeasurer()
    val labelStyle = TextStyle(fontSize = 10.sp, color = cs.onSurfaceVariant)
    val grid = cs.outlineVariant.copy(alpha = 0.6f)
    val ink = cs.onSurface
    val d = decimals(view.last().c)
    // Place réservée aux prix (à droite) et aux heures (en bas)
    val sample = measurer.measure(numFmt(view.maxOf { it.h }, d), labelStyle)
    val n = view.size
    val latestSelect by androidx.compose.runtime.rememberUpdatedState(onSelect)
    val latestDouble by androidx.compose.runtime.rememberUpdatedState(onDoubleTap)
    val latestPan by androidx.compose.runtime.rememberUpdatedState(onPan)
    val lastTapAt = remember { longArrayOf(0L) }
    val bottomPx = with(androidx.compose.ui.platform.LocalDensity.current) { 30.dp.toPx() }
    val latestTransform by androidx.compose.runtime.rememberUpdatedState(onTransform)
    val latestN by androidx.compose.runtime.rememberUpdatedState(n)
    val latestGutter by androidx.compose.runtime.rememberUpdatedState(sample.size.width + 12f)
    Canvas(
        modifier
            .pointerInput(Unit) {
                awaitEachGesture {
                    val down = awaitFirstDown(requireUnconsumed = false)
                    val plotW = (size.width - latestGutter).coerceAtLeast(1f)
                    val plotH = (size.height - bottomPx).coerceAtLeast(1f)
                    fun indexAt(x: Float): Int = ((x / plotW) * latestN).toInt().coerceIn(0, latestN - 1)
                    val slop = viewConfiguration.touchSlop
                    val longPress = viewConfiguration.longPressTimeoutMillis
                    var panning = false
                    var scrubbing = false
                    var multi = false
                    var last = down.position
                    while (true) {
                        val ev = awaitPointerEvent()
                        val pressed = ev.changes.filter { it.pressed }
                        if (pressed.isEmpty()) break
                        if (pressed.size >= 2) {
                            // Deux doigts : zoom autour du point pincé, et déplacement
                            multi = true
                            val zoom = ev.calculateZoom()
                            val pan = ev.calculatePan()
                            val c = ev.calculateCentroid(useCurrent = true)
                            if (zoom != 1f || pan.x != 0f) latestTransform((c.x / plotW).coerceIn(0f, 1f), zoom, pan.x / plotW)
                            if (pan.y != 0f) latestPan(0f, pan.y / plotH)
                            ev.changes.forEach { it.consume() }
                        } else if (!multi) {
                            val p = pressed[0]
                            val moved = (p.position - down.position).getDistance() > slop
                            // Doigt gardé appuyé sans bouger : on parcourt les bougies en glissant
                            if (!panning && !scrubbing && p.uptimeMillis - down.uptimeMillis > longPress) {
                                scrubbing = true
                                latestSelect(indexAt(p.position.x))
                            }
                            if (scrubbing) {
                                latestSelect(indexAt(p.position.x))
                                p.consume()
                            } else {
                                if (!panning && moved) { panning = true; last = p.position }
                                if (panning) {
                                    // Doigt qui glisse : le graphique suit (gauche/droite = temps, haut/bas = prix)
                                    val dx = p.position.x - last.x
                                    val dy = p.position.y - last.y
                                    last = p.position
                                    if (dx != 0f || dy != 0f) latestPan(dx / plotW, dy / plotH)
                                    p.consume()
                                }
                            }
                        }
                    }
                    if (!panning && !scrubbing && !multi) {
                        // Appui simple : la bougie touchée (ou de nouveau : plus de sélection) ; double appui : agrandir
                        val now = System.currentTimeMillis()
                        val dbl = latestDouble
                        if (dbl != null && now - lastTapAt[0] < 320L) { lastTapAt[0] = 0L; dbl() }
                        else {
                            lastTapAt[0] = now
                            latestSelect(if (down.position.x > plotW) null else indexAt(down.position.x))
                        }
                    }
                }
            },
    ) {
        val gutter = sample.size.width + 12f
        val bottom = 30.dp.toPx()
        val plotW = size.width - gutter
        val plotH = size.height - bottom
        val vals = view.flatMap { listOf(it.h, it.l) } + (ma + lo + hi).filter { !it.isNaN() } + (if (lastPrice.isNaN()) emptyList() else listOf(lastPrice))
        var mn = vals.filter { !it.isNaN() }.min()
        var mx = vals.filter { !it.isNaN() }.max()
        if (mx - mn < 1e-9) { mx += 1; mn -= 1 }
        val pad = (mx - mn) * 0.06
        mn -= pad; mx += pad
        // Décalage vertical choisi au doigt
        val shift = (mx - mn) * yPan
        mn += shift; mx += shift
        fun y(v: Double) = (plotH * (1 - (v - mn) / (mx - mn))).toFloat()
        val step = plotW / n
        fun xc(i: Int) = step * i + step / 2

        // Grille horizontale et prix
        for (k in 0..4) {
            val v = mn + (mx - mn) * k / 4
            val gy = y(v)
            drawLine(grid, Offset(0f, gy), Offset(plotW, gy), 1f)
            val tl = measurer.measure(numFmt(v, d), labelStyle)
            drawText(tl, topLeft = Offset(plotW + 6f, (gy - tl.size.height / 2f).coerceIn(0f, plotH - tl.size.height)))
        }
        // Grille verticale et heures
        val ticks = 4
        var prevT: Long? = null
        for (k in 0 until ticks) {
            val i = ((n - 1) * (k + 0.5) / ticks).toInt().coerceIn(0, n - 1)
            val gx = xc(i)
            drawLine(grid, Offset(gx, 0f), Offset(gx, plotH), 1f)
            val tl = measurer.measure(axisLabel(tf, view[i].t, prevT), labelStyle)
            prevT = view[i].t
            drawText(tl, topLeft = Offset((gx - tl.size.width / 2f).coerceIn(0f, plotW - tl.size.width), plotH + 4f))
        }
        // Bandes de Bollinger et moyenne 20
        fun line(values: List<Double>, color: Color, width: Float) {
            val p = Path()
            var started = false
            values.forEachIndexed { i, v ->
                if (v.isNaN()) return@forEachIndexed
                if (!started) { p.moveTo(xc(i), y(v)); started = true } else p.lineTo(xc(i), y(v))
            }
            if (started) drawPath(p, color, style = Stroke(width))
        }
        line(lo, cs.outline.copy(alpha = 0.55f), 1.2f * density)
        line(hi, cs.outline.copy(alpha = 0.55f), 1.2f * density)
        line(ma, cs.tertiary, 1.6f * density)
        if (candlesMode) {
            val bw = (step * 0.65f).coerceAtLeast(1f)
            view.forEachIndexed { i, c ->
                val col = if (c.c >= c.o) UPC else DOWNC
                val x = xc(i)
                drawLine(col, Offset(x, y(c.h)), Offset(x, y(c.l)), (1f * density).coerceAtMost(bw))
                val top = y(maxOf(c.o, c.c))
                val h = (y(minOf(c.o, c.c)) - top).coerceAtLeast(1.5f)
                drawRect(col, Offset(x - bw / 2, top), Size(bw, h))
            }
        } else {
            val first = view.first().c
            val col = if (view.last().c >= first) UPC else DOWNC
            val p = Path()
            view.forEachIndexed { i, c -> if (i == 0) p.moveTo(xc(i), y(c.c)) else p.lineTo(xc(i), y(c.c)) }
            val fill = Path().apply {
                addPath(p)
                lineTo(xc(n - 1), plotH); lineTo(xc(0), plotH); close()
            }
            drawPath(fill, Brush.verticalGradient(listOf(col.copy(alpha = 0.28f), col.copy(alpha = 0.02f)), startY = 0f, endY = plotH))
            drawPath(p, col, style = Stroke(2.2f * density))
        }
        // Dernier cours : trait pointillé et étiquette à droite
        if (!lastPrice.isNaN() && lastPrice > 0) {
            val ly = y(lastPrice)
            drawLine(cs.primary, Offset(0f, ly), Offset(plotW, ly), 1.2f * density, pathEffect = PathEffect.dashPathEffect(floatArrayOf(8f, 6f)))
            val tl = measurer.measure(numFmt(lastPrice, d), labelStyle.copy(color = cs.onPrimary, fontWeight = FontWeight.Bold))
            val top = (ly - tl.size.height / 2f - 2f).coerceIn(0f, plotH - tl.size.height - 4f)
            drawRoundRect(cs.primary, Offset(plotW + 2f, top), Size(tl.size.width + 8f, tl.size.height + 4f), CornerRadius(6f, 6f))
            drawText(tl, topLeft = Offset(plotW + 6f, top + 2f))
        }
        // Bougie touchée : réticule et valeur
        if (selected != null && selected in view.indices) {
            val c = view[selected]
            val x = xc(selected)
            val yy = y(c.c)
            drawLine(ink.copy(alpha = 0.6f), Offset(x, 0f), Offset(x, plotH), 1f * density)
            drawLine(ink.copy(alpha = 0.4f), Offset(0f, yy), Offset(plotW, yy), 1f * density)
            drawCircle(ink, 4f * density, Offset(x, yy))
            val tl = measurer.measure(fullTime(tf, c.t), labelStyle.copy(color = cs.inverseOnSurface))
            val left = (x - tl.size.width / 2f - 6f).coerceIn(0f, plotW - tl.size.width - 12f)
            drawRoundRect(cs.inverseSurface, Offset(left, plotH + 2f), Size(tl.size.width + 12f, tl.size.height + 6f), CornerRadius(6f, 6f))
            drawText(tl, topLeft = Offset(left + 6f, plotH + 5f))
        }
    }
}
