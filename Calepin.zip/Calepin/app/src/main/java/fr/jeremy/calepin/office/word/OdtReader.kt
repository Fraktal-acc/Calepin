package fr.jeremy.calepin.office.word

import org.w3c.dom.Element
import org.w3c.dom.Node
import java.io.ByteArrayInputStream
import java.util.zip.ZipInputStream
import javax.xml.parsers.DocumentBuilderFactory

/**
 * Lecture simplifiée d'un document OpenDocument (.odt, LibreOffice) : titres, paragraphes, listes,
 * gras, italique, souligné, barré, couleurs, alignement, tableaux et images. Converti ensuite en .docx.
 */
object OdtReader {
    private const val TEXT = "urn:oasis:names:tc:opendocument:xmlns:text:1.0"
    private const val TABLE = "urn:oasis:names:tc:opendocument:xmlns:table:1.0"
    private const val DRAW = "urn:oasis:names:tc:opendocument:xmlns:drawing:1.0"
    private const val STYLE = "urn:oasis:names:tc:opendocument:xmlns:style:1.0"
    private const val FO = "urn:oasis:names:tc:opendocument:xmlns:xsl-fo-compatible:1.0"
    private const val XLINK = "http://www.w3.org/1999/xlink"
    private const val OFFICE = "urn:oasis:names:tc:opendocument:xmlns:office:1.0"

    private class TStyle(val bold: Boolean, val italic: Boolean, val underline: Boolean, val strike: Boolean, val color: String?, val bg: String?, val align: String?, val parent: String?)

    fun read(bytes: ByteArray): DocxRead {
        val parts = HashMap<String, ByteArray>()
        ZipInputStream(ByteArrayInputStream(bytes)).use { z ->
            var e = z.nextEntry
            while (e != null) { if (!e.isDirectory) parts[e.name] = z.readBytes(); e = z.nextEntry }
        }
        val content = parts["content.xml"] ?: error("Ce fichier n'est pas un document OpenDocument (.odt).")
        val f = DocumentBuilderFactory.newInstance().apply { isNamespaceAware = true }
        runCatching { f.setFeature("http://apache.org/xml/features/disallow-doctype-decl", true) }
        val root = f.newDocumentBuilder().parse(ByteArrayInputStream(content)).documentElement

        // Styles automatiques (gras, italique… choisis dans le texte)
        val styles = HashMap<String, TStyle>()
        val numberedLists = HashSet<String>()
        fun collect(container: Element?) {
            container ?: return
            kids(container).forEach { s ->
                if (s.localName == "style" && s.namespaceURI == STYLE) {
                    val name = s.getAttributeNS(STYLE, "name")
                    val tp = kids(s).firstOrNull { it.localName == "text-properties" }
                    val pp = kids(s).firstOrNull { it.localName == "paragraph-properties" }
                    fun a(e: Element?, ns: String, n: String) = e?.getAttributeNS(ns, n)?.takeIf { it.isNotEmpty() }
                    styles[name] = TStyle(
                        bold = a(tp, FO, "font-weight") == "bold",
                        italic = a(tp, FO, "font-style") == "italic",
                        underline = a(tp, STYLE, "text-underline-style")?.let { it != "none" } == true,
                        strike = a(tp, STYLE, "text-line-through-style")?.let { it != "none" } == true,
                        color = a(tp, FO, "color")?.takeIf { it.length == 7 && !it.equals("#000000", true) }?.uppercase(),
                        bg = a(tp, FO, "background-color")?.takeIf { it.length == 7 && !it.equals("#ffffff", true) }?.uppercase(),
                        align = when (a(pp, FO, "text-align")) { "center" -> "center"; "end", "right" -> "right"; else -> null },
                        parent = a(s, STYLE, "parent-style-name"),
                    )
                } else if (s.localName == "list-style") {
                    if (kids(s).firstOrNull()?.localName == "list-level-style-number") numberedLists += s.getAttributeNS(STYLE, "name")
                }
            }
        }
        collect(kids(root).firstOrNull { it.localName == "automatic-styles" })
        parts["styles.xml"]?.let { sx ->
            runCatching { f.newDocumentBuilder().parse(ByteArrayInputStream(sx)).documentElement }.getOrNull()?.let { sr ->
                kids(sr).filter { it.localName == "styles" || it.localName == "automatic-styles" }.forEach { collect(it) }
            }
        }

        val blocks = ArrayList<DocBlock>()
        val lines = ArrayList<String>()
        val images = LinkedHashMap<String, ByteArray>()
        fun flush() { if (lines.isNotEmpty()) { blocks += DocBlock.Text(text = lines.joinToString("\n")); lines.clear() } }

        fun inline(e: Element, base: WordMarkup.Run, out: MutableList<WordMarkup.Run>, onImage: (String) -> Unit) {
            var n: Node? = e.firstChild
            while (n != null) {
                when (n.nodeType) {
                    Node.TEXT_NODE -> out += base.copy(text = n.nodeValue)
                    Node.ELEMENT_NODE -> {
                        val c = n as Element
                        when (c.localName) {
                            "span" -> {
                                val st = styles[c.getAttributeNS(TEXT, "style-name")]
                                val r = if (st == null) base else base.copy(
                                    bold = base.bold || st.bold, italic = base.italic || st.italic, underline = base.underline || st.underline,
                                    strike = base.strike || st.strike, color = st.color ?: base.color, highlight = st.bg ?: base.highlight,
                                )
                                inline(c, r, out, onImage)
                            }
                            "a" -> inline(c, base.copy(link = c.getAttributeNS(XLINK, "href").takeIf { it.startsWith("http") || it.startsWith("mailto:") }), out, onImage)
                            "s" -> out += base.copy(text = " ".repeat(c.getAttributeNS(TEXT, "c").toIntOrNull() ?: 1))
                            "tab" -> out += base.copy(text = "\t")
                            "line-break" -> out += base.copy(text = "\n")
                            "frame" -> kids(c).firstOrNull { it.localName == "image" }?.getAttributeNS(XLINK, "href")?.let(onImage)
                            "note", "annotation", "bookmark", "bookmark-start", "bookmark-end", "soft-page-break" -> {}
                            else -> inline(c, base, out, onImage)
                        }
                    }
                }
                n = n.nextSibling
            }
        }

        fun addImage(href: String) {
            val b = parts[href.removePrefix("./")] ?: return
            val ext = href.substringAfterLast('.', "png").lowercase().let { if (it == "jpeg") "jpg" else it }
            if (ext !in setOf("png", "jpg", "gif", "bmp", "webp")) return
            val name = "img_${images.size + 1}.$ext"
            images[name] = b
            flush(); blocks += DocBlock.Image(file = name)
        }

        fun paragraphText(p: Element): String {
            val runs = ArrayList<WordMarkup.Run>()
            inline(p, WordMarkup.Run(""), runs) { addImage(it) }
            return WordMarkup.markup(runs).replace('\n', ' ')
        }

        fun alignOf(p: Element): String {
            var st = styles[p.getAttributeNS(TEXT, "style-name")]
            var guard = 0
            while (st != null && st.align == null && guard++ < 5) st = st.parent?.let { styles[it] }
            return st?.align?.let { "[$it]" } ?: ""
        }

        fun list(l: Element, level: Int, numbered: Boolean) {
            var n = 0
            kids(l).filter { it.localName == "list-item" || it.localName == "list-header" }.forEach { item ->
                kids(item).forEach { c ->
                    when (c.localName) {
                        "p", "h" -> { n++; val t = paragraphText(c); lines += "  ".repeat(level) + (if (numbered) "$n. " else "- ") + t }
                        "list" -> list(c, (level + 1).coerceAtMost(8), numbered || c.getAttributeNS(TEXT, "style-name") in numberedLists)
                    }
                }
            }
        }

        fun body(container: Element) {
            kids(container).forEach { e ->
                when (e.localName) {
                    "h" -> {
                        val lvl = e.getAttributeNS(TEXT, "outline-level").toIntOrNull() ?: 1
                        val t = paragraphText(e)
                        lines += (if (t.isBlank()) "" else "#".repeat(lvl.coerceIn(1, 3)) + " " + t)
                    }
                    "p" -> {
                        val t = paragraphText(e)
                        // Style de paragraphe « Titre », « Heading 1 »… (et ses parents)
                        var name: String? = e.getAttributeNS(TEXT, "style-name")
                        var prefix = ""
                        var guard = 0
                        while (name != null && guard++ < 6) {
                            val lvl = Regex("^Heading_20_(\\d)$").find(name)?.groupValues?.get(1)?.toInt()
                            prefix = when {
                                lvl != null -> "#".repeat(lvl.coerceIn(1, 3)) + " "
                                name == "Title" -> "# "
                                name == "Subtitle" -> "### "
                                name == "Quotations" -> "> "
                                else -> ""
                            }
                            if (prefix.isNotEmpty()) break
                            name = styles[name]?.parent
                        }
                        lines += if (t.isBlank()) "" else prefix + t + alignOf(e)
                    }
                    "list" -> list(e, 0, e.getAttributeNS(TEXT, "style-name") in numberedLists)
                    "table" -> {
                        flush()
                        val rows = ArrayList<List<String>>()
                        e.getElementsByTagNameNS(TABLE, "table-row").let { rl ->
                            for (i in 0 until rl.length) {
                                val r = rl.item(i) as Element
                                val cells = kids(r).filter { it.localName == "table-cell" }.flatMap { c ->
                                    val txt = kids(c).filter { it.localName == "p" || it.localName == "h" }.joinToString("\n") { paragraphText(it) }
                                    val rep = c.getAttributeNS(TABLE, "number-columns-repeated").toIntOrNull()?.coerceIn(1, 20) ?: 1
                                    List(rep) { txt }
                                }
                                rows += cells
                            }
                        }
                        if (rows.isNotEmpty()) {
                            val cols = rows.maxOf { it.size }
                            blocks += DocBlock.Table(rows = rows.map { it + List(cols - it.size) { "" } }, header = e.getElementsByTagNameNS(TABLE, "table-header-rows").length > 0)
                        }
                    }
                    "section", "index-body", "table-of-content" -> body(e)
                }
            }
        }

        val text = root.getElementsByTagNameNS(OFFICE, "text").item(0) as? Element ?: error("Document vide")
        body(text)
        flush()
        return DocxRead(WordDoc(blocks.ifEmpty { listOf(DocBlock.Text()) }).normalized(), images, listOf("Document OpenDocument (.odt) converti : mise en forme simplifiée."), null)
    }

    private fun kids(e: Element): List<Element> {
        val out = ArrayList<Element>()
        var n = e.firstChild
        while (n != null) { if (n.nodeType == Node.ELEMENT_NODE) out += n as Element; n = n.nextSibling }
        return out
    }
}
