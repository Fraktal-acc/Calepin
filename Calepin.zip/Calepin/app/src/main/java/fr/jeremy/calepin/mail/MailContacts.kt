package fr.jeremy.calepin.mail

import android.content.Context
import fr.jeremy.calepin.search.TextNorm
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import org.json.JSONArray
import org.json.JSONObject

/** Contact mail enregistré dans Calepin (rubrique Mails → Contacts). */
data class MailContact(val email: String, val name: String = "", val added: Long = System.currentTimeMillis()) {
    /** « Marc Dupont <marc@exemple.fr> », ou l'adresse seule. */
    val display: String get() = if (name.isBlank() || name.equals(email, true)) email else "$name <$email>"

    fun toJson(): JSONObject = JSONObject().put("e", email).put("n", name).put("a", added)

    companion object {
        fun fromJson(o: JSONObject) = MailContact(o.optString("e"), o.optString("n"), o.optLong("a"))
    }
}

/**
 * Carnet d'adresses mail de Calepin : contacts ajoutés à la main ou avec le « + » à côté de l'expéditeur
 * d'un mail. Gardés sur le téléphone seulement (et dans la sauvegarde des réglages d'Android).
 */
object MailContacts {
    private const val PREFS = "calepin_mail_contacts"
    private val _list = MutableStateFlow<List<MailContact>>(emptyList())
    val list: StateFlow<List<MailContact>> = _list
    @Volatile private var loaded = false

    fun init(ctx: Context) {
        if (loaded) return
        synchronized(this) {
            if (loaded) return
            val raw = ctx.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString("list", "[]")
            _list.value = runCatching {
                val a = JSONArray(raw)
                (0 until a.length()).map { MailContact.fromJson(a.getJSONObject(it)) }.filter { it.email.contains('@') }
            }.getOrDefault(emptyList()).sortedWith(ORDER)
            loaded = true
        }
    }

    private val ORDER = compareBy<MailContact> { TextNorm.norm(it.name.ifBlank { it.email }).lowercase() }

    private fun save(ctx: Context) {
        val a = JSONArray().apply { _list.value.forEach { put(it.toJson()) } }
        ctx.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString("list", a.toString()).apply()
    }

    fun has(ctx: Context, email: String): Boolean { init(ctx); return _list.value.any { it.email.equals(email.trim(), true) } }

    /** Ajoute ou met à jour (même adresse = même contact ; un nom vide ne remplace pas un nom connu). */
    fun put(ctx: Context, email: String, name: String) {
        init(ctx)
        val e = email.trim().trim('<', '>').lowercase()
        if (!valid(e)) return
        val old = _list.value.firstOrNull { it.email.equals(e, true) }
        val c = MailContact(e, name.trim().trim('"').ifBlank { old?.name ?: "" }, old?.added ?: System.currentTimeMillis())
        _list.value = (_list.value.filterNot { it.email.equals(e, true) } + c).sortedWith(ORDER)
        save(ctx)
    }

    fun remove(ctx: Context, email: String) {
        init(ctx)
        _list.value = _list.value.filterNot { it.email.equals(email, true) }
        save(ctx)
    }

    fun valid(email: String) = Regex("^[^@\\s<>,;]+@[^@\\s<>,;]+\\.[^@\\s<>,;]{2,}$").matches(email.trim())

    /** Contacts dont le nom ou l'adresse contient tous les mots tapés (sans accents ni majuscules). */
    fun search(ctx: Context, query: String): List<MailContact> {
        init(ctx)
        val words = TextNorm.norm(query).lowercase().split(Regex("[\\s,;]+")).filter { it.isNotEmpty() }
        if (words.isEmpty()) return _list.value
        return _list.value.filter { c -> val t = TextNorm.norm(c.name + " " + c.email).lowercase(); words.all { it in t } }
    }

    /** Dernier destinataire en cours de frappe dans « a@x.fr, Mar » → « Mar ». */
    fun lastToken(field: String): String = field.substringAfterLast(',').substringAfterLast(';').trim()

    /** Remplace le destinataire en cours de frappe par l'adresse choisie, et prépare le suivant. */
    fun complete(field: String, email: String): String {
        val cut = maxOf(field.lastIndexOf(','), field.lastIndexOf(';'))
        val head = if (cut >= 0) field.substring(0, cut + 1).trimEnd() + " " else ""
        return "$head$email, "
    }

    /** Ajoute des adresses à un champ de destinataires, sans doublon. */
    fun append(field: String, emails: List<String>): String {
        val existing = field.split(',', ';').map { it.trim() }.filter { it.isNotEmpty() }
        val all = existing + emails.filter { e -> existing.none { it.equals(e, true) || it.contains("<$e>", true) } }
        return if (all.isEmpty()) "" else all.joinToString(", ") + ", "
    }
}
