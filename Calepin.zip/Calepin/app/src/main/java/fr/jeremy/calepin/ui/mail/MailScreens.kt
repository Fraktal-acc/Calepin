package fr.jeremy.calepin.ui.mail

import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Forward
import androidx.compose.material.icons.automirrored.filled.Reply
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AttachFile
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Inbox
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import fr.jeremy.calepin.Files
import fr.jeremy.calepin.LockGuard
import fr.jeremy.calepin.i18n.I18n
import fr.jeremy.calepin.i18n.RawText
import fr.jeremy.calepin.i18n.Text
import fr.jeremy.calepin.mail.MailAccount
import fr.jeremy.calepin.mail.MailAccounts
import fr.jeremy.calepin.mail.MailBody
import fr.jeremy.calepin.mail.MailClient
import fr.jeremy.calepin.mail.MailHeader
import fr.jeremy.calepin.mail.MailPreset
import fr.jeremy.calepin.mail.MailPresets
import fr.jeremy.calepin.mail.Outgoing
import fr.jeremy.calepin.mail.Security
import fr.jeremy.calepin.ui.FitText
import fr.jeremy.calepin.ui.appBorder
import kotlinx.coroutines.launch
import java.io.File
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/** Mail en préparation (nouveau, réponse, transfert, PDF à envoyer…). */
data class MailDraft(
    val accountId: String? = null,
    val to: String = "",
    val cc: String = "",
    val subject: String = "",
    val body: String = "",
    val attachments: List<Outgoing> = emptyList(),
    val reply: MailBody? = null,
)

private fun whenText(t: Long): String {
    if (t <= 0) return ""
    val c = Calendar.getInstance().apply { timeInMillis = t }
    val now = Calendar.getInstance()
    val sameDay = c.get(Calendar.YEAR) == now.get(Calendar.YEAR) && c.get(Calendar.DAY_OF_YEAR) == now.get(Calendar.DAY_OF_YEAR)
    return SimpleDateFormat(if (sameDay) "HH:mm" else "dd/MM/yy HH:mm", Locale.getDefault()).format(Date(t))
}

private fun sizeText(b: Long): String = when {
    b < 0 -> ""
    b < 1024 -> "$b o"
    b < 1024 * 1024 -> "${b / 1024} Ko"
    else -> String.format(Locale.getDefault(), "%.1f Mo", b / 1048576.0)
}

private fun toast(ctx: android.content.Context, t: String) = I18n.toast(ctx, t, Toast.LENGTH_LONG).show()

// ------------------------------------------------------------------ Carte « Mes adresses mail »

@Composable
fun MailAccountsCard(onInbox: (MailAccount) -> Unit, onCompose: () -> Unit) {
    val ctx = LocalContext.current
    remember { MailAccounts.init(ctx) }
    val accounts by MailAccounts.accounts.collectAsStateWithLifecycle()
    val inbox by MailClient.inbox.collectAsStateWithLifecycle()
    var editing by remember { mutableStateOf<MailAccount?>(null) }
    var adding by remember { mutableStateOf(false) }
    Surface(shape = MaterialTheme.shapes.large, color = MaterialTheme.colorScheme.surfaceContainerLow, border = appBorder(), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("Mes adresses mail", style = MaterialTheme.typography.titleMedium)
            if (accounts.isEmpty()) Text(
                "Ajoute ton adresse (Gmail, Orange, Free, SFR, Outlook, ton nom de domaine…) pour recevoir et envoyer tes mails directement dans Calepin.",
                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            accounts.forEach { a ->
                val unread = inbox[a.id]?.count { !it.seen }
                Surface(onClick = { onInbox(a) }, shape = MaterialTheme.shapes.medium, color = MaterialTheme.colorScheme.surfaceContainerHigh, modifier = Modifier.fillMaxWidth()) {
                    Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Filled.Inbox, null, tint = MaterialTheme.colorScheme.primary)
                        Spacer(Modifier.width(10.dp))
                        Column(Modifier.weight(1f)) {
                            RawText(a.email, style = MaterialTheme.typography.titleSmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            RawText(
                                if (unread != null && unread > 0) I18n.trf("{0} non lu(s)", unread.toString()) else I18n.tr("Boîte de réception"),
                                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                        IconButton(onClick = { editing = a }) { Icon(Icons.Filled.Edit, "Modifier l'adresse") }
                    }
                }
            }
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { adding = true }, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Filled.Add, null); Spacer(Modifier.width(6.dp)); Text("Ajouter une adresse") }
                if (accounts.isNotEmpty()) Button(onClick = onCompose, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Filled.Edit, null); Spacer(Modifier.width(6.dp)); Text("Nouveau mail") }
            }
        }
    }
    if (adding) AccountDialog(null) { adding = false }
    editing?.let { a -> AccountDialog(a) { editing = null } }
}

// ------------------------------------------------------------------ Ajout / modification d'une adresse

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun AccountDialog(existing: MailAccount?, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var email by remember { mutableStateOf(existing?.email ?: "") }
    var name by remember { mutableStateOf(existing?.name ?: "") }
    var password by remember { mutableStateOf("") }
    var preset by remember { mutableStateOf<MailPreset?>(existing?.let { e -> MailPresets.ALL.firstOrNull { it.imap == e.imapHost } }) }
    var advanced by remember { mutableStateOf(existing != null && preset == null) }
    var user by remember { mutableStateOf(existing?.user ?: "") }
    var imapHost by remember { mutableStateOf(existing?.imapHost ?: "") }
    var imapPort by remember { mutableStateOf(existing?.imapPort?.toString() ?: "993") }
    var imapSec by remember { mutableStateOf(existing?.imapSec ?: Security.SSL) }
    var smtpHost by remember { mutableStateOf(existing?.smtpHost ?: "") }
    var smtpPort by remember { mutableStateOf(existing?.smtpPort?.toString() ?: "465") }
    var smtpSec by remember { mutableStateOf(existing?.smtpSec ?: Security.SSL) }
    var busy by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var confirmRemove by remember { mutableStateOf(false) }

    fun applyPreset(p: MailPreset) {
        preset = p
        imapHost = p.imap; imapPort = p.imapPort.toString(); imapSec = p.imapSec
        smtpHost = p.smtp; smtpPort = p.smtpPort.toString(); smtpSec = p.smtpSec
    }
    // Fournisseur reconnu d'après l'adresse
    LaunchedEffect(email) {
        if (existing == null) MailPresets.forEmail(email)?.let { if (preset != it) applyPreset(it) }
    }

    AlertDialog(
        onDismissRequest = { if (!busy) onDismiss() },
        title = { Text(if (existing == null) "Ajouter une adresse mail" else "Modifier l'adresse mail") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(email, { email = it.trim(); error = null }, label = { Text("Adresse mail") }, singleLine = true, modifier = Modifier.fillMaxWidth(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email))
                OutlinedTextField(name, { name = it }, label = { Text("Nom affiché (facultatif)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(
                    password, { password = it; error = null },
                    label = { Text(if (existing == null) "Mot de passe" else "Mot de passe (vide = inchangé)") },
                    singleLine = true, visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                )
                Text("Fournisseur", style = MaterialTheme.typography.labelLarge)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    MailPresets.ALL.forEach { p -> FilterChip(selected = preset == p, onClick = { applyPreset(p) }, label = { Text(p.label) }) }
                    FilterChip(selected = preset == null && advanced, onClick = { preset = null; advanced = true }, label = { Text("Autre") })
                }
                preset?.note?.takeIf { it.isNotBlank() }?.let { Text(it, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.tertiary) }
                // Liens directs vers les bonnes pages du fournisseur (le menu est souvent caché)
                preset?.let { p ->
                    fun open(url: String) {
                        LockGuard.external()
                        runCatching { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
                    }
                    if (p.twoStepLink.isNotEmpty()) OutlinedButton(onClick = { open(p.twoStepLink) }, modifier = Modifier.fillMaxWidth()) { Text("1. Activer la validation en deux étapes") }
                    if (p.appPwdLink.isNotEmpty()) Button(onClick = { open(p.appPwdLink) }, modifier = Modifier.fillMaxWidth()) {
                        Text(if (p.twoStepLink.isNotEmpty()) "2. Créer le mot de passe d'application" else "Créer le mot de passe d'application")
                    }
                }
                TextButton(onClick = { advanced = !advanced }) { Text(if (advanced) "Masquer les réglages des serveurs" else "Réglages des serveurs") }
                if (advanced) {
                    OutlinedTextField(user, { user = it.trim() }, label = { Text("Identifiant (vide = adresse mail)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    Text("Réception (IMAP)", style = MaterialTheme.typography.labelLarge)
                    OutlinedTextField(imapHost, { imapHost = it.trim() }, label = { Text("Serveur") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        OutlinedTextField(imapPort, { imapPort = it.filter(Char::isDigit) }, label = { Text("Port") }, singleLine = true, modifier = Modifier.width(90.dp),
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
                        Security.entries.forEach { s -> FilterChip(selected = imapSec == s, onClick = { imapSec = s }, label = { RawText(if (s == Security.SSL) "SSL" else "STARTTLS") }) }
                    }
                    Text("Envoi (SMTP)", style = MaterialTheme.typography.labelLarge)
                    OutlinedTextField(smtpHost, { smtpHost = it.trim() }, label = { Text("Serveur") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        OutlinedTextField(smtpPort, { smtpPort = it.filter(Char::isDigit) }, label = { Text("Port") }, singleLine = true, modifier = Modifier.width(90.dp),
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
                        Security.entries.forEach { s -> FilterChip(selected = smtpSec == s, onClick = { smtpSec = s }, label = { RawText(if (s == Security.SSL) "SSL" else "STARTTLS") }) }
                    }
                }
                Text(
                    "Le mot de passe est chiffré sur le téléphone. Calepin se connecte directement au serveur de ton fournisseur, sans passer par un autre service.",
                    style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                if (busy) LinearProgressIndicator(Modifier.fillMaxWidth())
                error?.let { RawText(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall) }
                if (existing != null) TextButton(onClick = { confirmRemove = true }) { Text("Retirer cette adresse", color = MaterialTheme.colorScheme.error) }
            }
        },
        confirmButton = {
            TextButton(enabled = !busy && email.contains('@') && imapHost.isNotBlank() && smtpHost.isNotBlank() && (existing != null || password.isNotEmpty()), onClick = {
                val acc = MailAccount(
                    id = existing?.id ?: java.util.UUID.randomUUID().toString(),
                    email = email, name = name.trim(), user = user.ifBlank { email },
                    imapHost = imapHost, imapPort = imapPort.toIntOrNull() ?: 993, imapSec = imapSec,
                    smtpHost = smtpHost, smtpPort = smtpPort.toIntOrNull() ?: 465, smtpSec = smtpSec,
                )
                // Mot de passe d'application : affiché par groupes de 4 lettres, les espaces ne comptent pas
                val typed = if (preset?.needsAppPwd == true) password.filterNot { it.isWhitespace() } else password
                val pwd = typed.ifEmpty { existing?.let { MailAccounts.password(ctx, it) } ?: "" }
                busy = true; error = null
                scope.launch {
                    runCatching { MailClient.test(acc, pwd) }
                        .onSuccess {
                            MailClient.forget(acc.id)
                            MailAccounts.put(ctx, acc, pwd)
                            busy = false
                            toast(ctx, I18n.tr("Adresse vérifiée et enregistrée."))
                            onDismiss()
                        }
                        .onFailure { busy = false; error = it.message }
                }
            }) { Text("Vérifier et enregistrer") }
        },
        dismissButton = { TextButton(enabled = !busy, onClick = onDismiss) { Text("Annuler") } },
    )
    if (confirmRemove && existing != null) AlertDialog(
        onDismissRequest = { confirmRemove = false },
        title = { Text("Retirer cette adresse ?") },
        text = { Text("Calepin oublie l'adresse et son mot de passe. Tes mails restent sur le serveur.") },
        confirmButton = { TextButton(onClick = { MailAccounts.remove(ctx, existing); confirmRemove = false; onDismiss() }) { Text("Retirer") } },
        dismissButton = { TextButton(onClick = { confirmRemove = false }) { Text("Annuler") } },
    )
}

// ------------------------------------------------------------------ Boîte de réception

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MailInboxScreen(account: MailAccount, onBack: () -> Unit, onOpen: (Long) -> Unit, onCompose: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    BackHandler { onBack() }
    val inbox by MailClient.inbox.collectAsStateWithLifecycle()
    val list = inbox[account.id]
    var busy by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    fun refresh() {
        busy = true; error = null
        scope.launch {
            runCatching { MailClient.refresh(ctx, account) }.onFailure { error = it.message }
            busy = false
        }
    }
    LaunchedEffect(account.id) { refresh() }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        FitText("Boîte de réception")
                        RawText(account.email, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Retour") } },
                actions = { IconButton(enabled = !busy, onClick = { refresh() }) { Icon(Icons.Filled.Refresh, "Actualiser") } },
            )
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(onClick = onCompose, icon = { Icon(Icons.Filled.Edit, null) }, text = { Text("Nouveau mail") })
        },
    ) { pad ->
        Column(Modifier.fillMaxSize().padding(pad)) {
            if (busy) LinearProgressIndicator(Modifier.fillMaxWidth())
            error?.let {
                Surface(color = MaterialTheme.colorScheme.errorContainer, modifier = Modifier.fillMaxWidth()) {
                    RawText(it, color = MaterialTheme.colorScheme.onErrorContainer, style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(12.dp))
                }
            }
            if (list != null && list.isEmpty() && !busy) {
                Box(Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
                    Text("Aucun mail dans la boîte de réception.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
            LazyColumn(contentPadding = PaddingValues(start = 12.dp, end = 12.dp, top = 8.dp, bottom = 90.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                items(list.orEmpty(), key = { it.uid }) { h -> MailRow(h) { onOpen(h.uid) } }
            }
        }
    }
}

@Composable
private fun MailRow(h: MailHeader, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    Surface(onClick = onClick, shape = MaterialTheme.shapes.large, color = if (h.seen) cs.surfaceContainerLow else cs.secondaryContainer, border = appBorder(), modifier = Modifier.fillMaxWidth()) {
        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(38.dp).clip(CircleShape).background(cs.primary), contentAlignment = Alignment.Center) {
                RawText(h.from.trim().take(1).uppercase().ifBlank { "?" }, color = cs.onPrimary, fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    RawText(h.from, style = MaterialTheme.typography.titleSmall, fontWeight = if (h.seen) FontWeight.Normal else FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
                    if (h.attach) Icon(Icons.Filled.AttachFile, "Pièce jointe", Modifier.size(16.dp), tint = cs.onSurfaceVariant)
                    RawText(whenText(h.date), style = MaterialTheme.typography.labelSmall, color = cs.onSurfaceVariant)
                }
                RawText(h.subject.ifBlank { I18n.tr("(sans objet)") }, style = MaterialTheme.typography.bodyMedium, fontWeight = if (h.seen) FontWeight.Normal else FontWeight.SemiBold, maxLines = 2, overflow = TextOverflow.Ellipsis)
            }
        }
    }
}

// ------------------------------------------------------------------ Lecture d'un mail

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MailReadScreen(account: MailAccount, uid: Long, onBack: () -> Unit, onCompose: (MailDraft) -> Unit, folder: String = "INBOX") {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    BackHandler { onBack() }
    var body by remember { mutableStateOf<MailBody?>(null) }
    var error by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf<String?>(null) }
    var confirmDelete by remember { mutableStateOf(false) }
    LaunchedEffect(uid) {
        runCatching { MailClient.open(ctx, account, uid, folder) }.onSuccess { body = it }.onFailure { error = it.message }
    }

    fun openFile(f: File, mime: String) {
        LockGuard.external()
        val i = Intent(Intent.ACTION_VIEW).setDataAndType(Files.uriFor(ctx, f), mime).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        runCatching { ctx.startActivity(Intent.createChooser(i, f.name).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
            .onFailure { toast(ctx, I18n.tr("Aucune application pour ouvrir ce fichier")) }
    }

    fun quote(b: MailBody): String {
        val head = I18n.trf("Le {0}, {1} a écrit :", whenText(b.header.date), b.header.from)
        return "\n\n" + head + "\n" + b.text.lines().joinToString("\n") { "> $it" }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { FitText(body?.header?.subject?.ifBlank { I18n.tr("(sans objet)") } ?: I18n.tr("Mail"), translate = false) },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Retour") } },
                actions = {
                    val b = body
                    if (b != null) {
                        IconButton(onClick = {
                            onCompose(MailDraft(account.id, to = b.replyTo, subject = (if (b.header.subject.startsWith("Re:", true)) "" else "Re: ") + b.header.subject, body = quote(b), reply = b))
                        }) { Icon(Icons.AutoMirrored.Filled.Reply, "Répondre") }
                        IconButton(onClick = {
                            // Transfert : les pièces jointes sont téléchargées puis jointes
                            busy = I18n.tr("Préparation du transfert…")
                            scope.launch {
                                val files = b.attachments.mapNotNull { at ->
                                    runCatching { Outgoing(MailClient.saveAttachment(ctx, account, uid, at.index, folder), at.name, at.mime) }.getOrNull()
                                }
                                busy = null
                                val head = "\n\n---------- " + I18n.tr("Message transféré") + " ----------\n" +
                                    I18n.tr("De :") + " " + b.header.from + " <" + b.header.fromAddr + ">\n" +
                                    I18n.tr("Date :") + " " + whenText(b.header.date) + "\n" +
                                    I18n.tr("Objet :") + " " + b.header.subject + "\n\n"
                                onCompose(MailDraft(account.id, subject = (if (b.header.subject.startsWith("Fwd:", true) || b.header.subject.startsWith("Tr:", true)) "" else "Tr: ") + b.header.subject, body = head + b.text, attachments = files))
                            }
                        }) { Icon(Icons.AutoMirrored.Filled.Forward, "Transférer") }
                        IconButton(onClick = { confirmDelete = true }) { Icon(Icons.Filled.Delete, "Supprimer") }
                    }
                },
            )
        },
    ) { pad ->
        Column(Modifier.fillMaxSize().padding(pad).verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            busy?.let { Column { RawText(it); LinearProgressIndicator(Modifier.fillMaxWidth()) } }
            error?.let { RawText(it, color = MaterialTheme.colorScheme.error) }
            val b = body
            if (b == null && error == null) LinearProgressIndicator(Modifier.fillMaxWidth())
            if (b != null) {
                RawText(b.header.subject.ifBlank { I18n.tr("(sans objet)") }, style = MaterialTheme.typography.titleLarge)
                RawText(b.header.from + if (b.header.fromAddr.isNotBlank() && b.header.fromAddr != b.header.from) " <${b.header.fromAddr}>" else "", style = MaterialTheme.typography.titleSmall)
                RawText(I18n.tr("À :") + " " + b.to + (if (b.cc.isNotBlank()) "\n" + I18n.tr("Cc :") + " " + b.cc else ""), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                RawText(whenText(b.header.date), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                if (b.attachments.isNotEmpty()) {
                    HorizontalDivider()
                    b.attachments.forEach { at ->
                        Surface(onClick = {
                            busy = I18n.tr("Téléchargement…")
                            scope.launch {
                                runCatching { MailClient.saveAttachment(ctx, account, uid, at.index, folder) }
                                    .onSuccess { f -> busy = null; openFile(f, at.mime) }
                                    .onFailure { busy = null; toast(ctx, it.message ?: "") }
                            }
                        }, shape = MaterialTheme.shapes.medium, color = MaterialTheme.colorScheme.surfaceContainerHigh, modifier = Modifier.fillMaxWidth()) {
                            Row(Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Filled.AttachFile, null)
                                Spacer(Modifier.width(8.dp))
                                RawText(at.name, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
                                RawText(sizeText(at.size.toLong()), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }
                }
                HorizontalDivider()
                SelectionContainer { RawText(b.text.ifBlank { I18n.tr("(mail vide)") }, style = MaterialTheme.typography.bodyLarge) }
            }
        }
    }
    if (confirmDelete) AlertDialog(
        onDismissRequest = { confirmDelete = false },
        title = { Text("Supprimer ce mail ?") },
        text = { Text("Le mail est retiré de la boîte de réception sur le serveur (il va dans la corbeille, ou dans les archives avec Gmail).") },
        confirmButton = {
            TextButton(onClick = {
                confirmDelete = false
                scope.launch {
                    runCatching { MailClient.delete(ctx, account, uid, folder) }
                        .onSuccess { onBack() }
                        .onFailure { toast(ctx, it.message ?: "") }
                }
            }) { Text("Supprimer") }
        },
        dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text("Annuler") } },
    )
}

// ------------------------------------------------------------------ Écrire un mail

/** Écran d'envoi (nouveau mail, réponse, transfert, document à envoyer). Utilisable depuis n'importe quel écran. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MailComposeScreen(draft: MailDraft, onClose: () -> Unit, onSent: () -> Unit = onClose) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    remember { MailAccounts.init(ctx) }
    val accounts by MailAccounts.accounts.collectAsStateWithLifecycle()
    var accountId by remember { mutableStateOf(draft.accountId ?: accounts.firstOrNull()?.id) }
    val account = accounts.firstOrNull { it.id == accountId } ?: accounts.firstOrNull()
    var to by remember { mutableStateOf(draft.to) }
    var cc by remember { mutableStateOf(draft.cc) }
    var showCc by remember { mutableStateOf(draft.cc.isNotBlank()) }
    var subject by remember { mutableStateOf(draft.subject) }
    var body by remember { mutableStateOf(draft.body) }
    val attachments = remember { mutableStateListOf<Outgoing>().apply { addAll(draft.attachments) } }
    var sending by remember { mutableStateOf(false) }
    var fromMenu by remember { mutableStateOf(false) }
    var confirmQuit by remember { mutableStateOf(false) }
    val dirty = to.isNotBlank() || subject != draft.subject || body != draft.body

    BackHandler { if (dirty && !sending) confirmQuit = true else onClose() }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris: List<Uri> ->
        uris.forEach { u ->
            runCatching {
                val name = fr.jeremy.calepin.office.PdfLibrary.get(ctx).displayName(u)
                val dir = File(ctx.cacheDir, "mail/out").apply { mkdirs() }
                val f = File(dir, System.currentTimeMillis().toString() + "_" + name.replace(Regex("[\\\\/:*?\"<>|]"), "_"))
                ctx.contentResolver.openInputStream(u)!!.use { input -> f.outputStream().use { input.copyTo(it) } }
                attachments.add(Outgoing(f, name, ctx.contentResolver.getType(u) ?: "application/octet-stream"))
            }
        }
    }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.surface,
        topBar = {
            TopAppBar(
                title = { FitText(if (draft.reply != null) "Répondre" else "Nouveau mail") },
                navigationIcon = { IconButton(onClick = { if (dirty && !sending) confirmQuit = true else onClose() }) { Icon(Icons.Filled.Close, "Fermer") } },
                actions = {
                    IconButton(onClick = { LockGuard.external(); picker.launch(arrayOf("*/*")) }) { Icon(Icons.Filled.AttachFile, "Joindre un fichier") }
                    IconButton(enabled = !sending && account != null && to.contains('@'), onClick = {
                        val a = account ?: return@IconButton
                        sending = true
                        scope.launch {
                            runCatching { MailClient.send(ctx, a, to, if (showCc) cc else "", subject, body, attachments.toList(), draft.reply) }
                                .onSuccess { sending = false; toast(ctx, I18n.tr("Mail envoyé.")); onSent() }
                                .onFailure { sending = false; toast(ctx, I18n.tr("Échec de l'envoi :") + " " + (it.message ?: "")) }
                        }
                    }) { Icon(Icons.AutoMirrored.Filled.Send, "Envoyer") }
                },
            )
        },
    ) { pad ->
        Column(Modifier.fillMaxSize().padding(pad).imePadding().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            if (sending) LinearProgressIndicator(Modifier.fillMaxWidth())
            if (accounts.isEmpty()) {
                Text("Ajoute d'abord ton adresse mail dans Messages → Mails → Mes adresses mail.", color = MaterialTheme.colorScheme.error)
            } else Box {
                Surface(onClick = { fromMenu = true }, shape = MaterialTheme.shapes.medium, color = MaterialTheme.colorScheme.surfaceContainerHigh, modifier = Modifier.fillMaxWidth()) {
                    Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text("De :", style = MaterialTheme.typography.labelLarge)
                        Spacer(Modifier.width(8.dp))
                        RawText(account?.email.orEmpty(), maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                }
                DropdownMenu(expanded = fromMenu, onDismissRequest = { fromMenu = false }) {
                    accounts.forEach { a -> DropdownMenuItem(text = { RawText(a.email) }, onClick = { accountId = a.id; fromMenu = false }) }
                }
            }
            OutlinedTextField(to, { to = it }, label = { Text("Destinataires") }, placeholder = { Text("adresse@exemple.fr, autre@exemple.fr") }, modifier = Modifier.fillMaxWidth(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
                trailingIcon = { if (!showCc) TextButton(onClick = { showCc = true }) { Text("Cc") } })
            if (showCc) OutlinedTextField(cc, { cc = it }, label = { Text("Cc") }, modifier = Modifier.fillMaxWidth(), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email))
            OutlinedTextField(subject, { subject = it }, label = { Text("Objet") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            if (attachments.isNotEmpty()) attachments.toList().forEach { o ->
                Surface(shape = MaterialTheme.shapes.medium, color = MaterialTheme.colorScheme.secondaryContainer, modifier = Modifier.fillMaxWidth()) {
                    Row(Modifier.padding(start = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Filled.AttachFile, null, Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        RawText(o.name, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
                        RawText(sizeText(o.file.length()), style = MaterialTheme.typography.labelSmall)
                        IconButton(onClick = { attachments.remove(o) }) { Icon(Icons.Filled.Close, "Retirer") }
                    }
                }
            }
            OutlinedTextField(body, { body = it }, label = { Text("Message") }, modifier = Modifier.fillMaxWidth(), minLines = 8)
        }
    }
    if (confirmQuit) AlertDialog(
        onDismissRequest = { confirmQuit = false },
        title = { Text("Abandonner ce mail ?") },
        text = { Text("Le mail n'est pas envoyé et ce que tu as écrit sera perdu.") },
        confirmButton = { TextButton(onClick = { confirmQuit = false; onClose() }) { Text("Abandonner") } },
        dismissButton = { TextButton(onClick = { confirmQuit = false }) { Text("Continuer") } },
    )
}

/**
 * Envoyer un fichier par mail : avec une adresse configurée dans Calepin (écran d'envoi), ou avec
 * l'appli de mail du téléphone. [onCalepin] ouvre l'écran d'envoi de Calepin.
 */
@Composable
fun SendByMailDialog(file: File, name: String, mime: String, onDismiss: () -> Unit, onCalepin: (MailDraft) -> Unit) {
    val ctx = LocalContext.current
    remember { MailAccounts.init(ctx) }
    val accounts by MailAccounts.accounts.collectAsStateWithLifecycle()
    AlertDialog(
        onDismissRequest = onDismiss,
        icon = { Icon(Icons.Filled.Email, null) },
        title = { Text("Envoyer par mail") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                RawText(name, style = MaterialTheme.typography.titleSmall)
                if (accounts.isNotEmpty()) Button(onClick = {
                    onDismiss()
                    onCalepin(MailDraft(accounts.first().id, subject = name.substringBeforeLast('.'), attachments = listOf(Outgoing(file, name, mime))))
                }, modifier = Modifier.fillMaxWidth()) { Text("Avec mon adresse (dans Calepin)") }
                OutlinedButton(onClick = {
                    onDismiss()
                    openMailApp(ctx, file, name, mime)
                }, modifier = Modifier.fillMaxWidth()) { Text("Avec l'appli de mail du téléphone") }
                if (accounts.isEmpty()) Text(
                    "Astuce : ajoute ton adresse dans Messages → Mails pour envoyer directement depuis Calepin.",
                    style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        },
        confirmButton = {},
        dismissButton = { TextButton(onClick = onDismiss) { Text("Annuler") } },
    )
}

/** Ouvre l'appli de mail du téléphone avec le fichier en pièce jointe (seules les applis de mail sont proposées). */
fun openMailApp(ctx: android.content.Context, file: File, name: String, mime: String) {
    LockGuard.external()
    val uri = Files.uriFor(ctx, file)
    val send = Intent(Intent.ACTION_SEND).apply {
        type = mime
        putExtra(Intent.EXTRA_SUBJECT, name.substringBeforeLast('.'))
        putExtra(Intent.EXTRA_STREAM, uri)
        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        // Seules les applis qui savent écrire un mail
        selector = Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:"))
    }
    runCatching { ctx.startActivity(Intent.createChooser(send, I18n.tr("Envoyer par mail")).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)) }
        .onFailure {
            // Sans sélecteur (certains téléphones) : partage classique
            runCatching { ctx.startActivity(Intent.createChooser(send.apply { selector = null }, I18n.tr("Envoyer par mail")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
                .onFailure { toast(ctx, I18n.tr("Aucune application de mail sur le téléphone")) }
        }
}

/** Écran plein, au-dessus de l'écran en cours (pour envoyer un document sans quitter ce qu'on fait). */
@Composable
fun MailComposeDialog(draft: MailDraft, onClose: () -> Unit) {
    androidx.compose.ui.window.Dialog(
        onDismissRequest = onClose,
        properties = androidx.compose.ui.window.DialogProperties(usePlatformDefaultWidth = false, decorFitsSystemWindows = false),
    ) {
        MailComposeScreen(draft, onClose)
    }
}

// ------------------------------------------------------------------ Recherche dans les mails

private object SearchMemo {
    val query = mutableStateOf("")
    val chosen = mutableStateOf(setOf<String>())
    val results = mutableStateOf<List<MailHeader>?>(null)
}

/**
 * Recherche dans une, plusieurs ou toutes les boîtes mail (expéditeur, objet, texte ; sans tenir compte
 * des accents ni des majuscules ; tous les mots doivent y être, comme les autres recherches de Calepin).
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun MailSearchCard(onOpen: (MailHeader) -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    remember { MailAccounts.init(ctx) }
    val accounts by MailAccounts.accounts.collectAsStateWithLifecycle()
    if (accounts.isEmpty()) return
    // Gardés en mémoire : la recherche est toujours là au retour d'un mail ouvert
    var query by SearchMemo.query
    // Boîtes choisies (vide = toutes)
    var chosen by SearchMemo.chosen
    var results by SearchMemo.results
    var busy by remember { mutableStateOf(false) }
    var errors by remember { mutableStateOf<List<String>>(emptyList()) }
    fun go() {
        val q = query.trim()
        if (q.length < 2) return
        val targets = accounts.filter { chosen.isEmpty() || it.id in chosen }
        busy = true; errors = emptyList()
        scope.launch {
            val all = mutableListOf<MailHeader>()
            val errs = mutableListOf<String>()
            targets.forEach { a ->
                runCatching { MailClient.search(ctx, a, q) }.onSuccess { all += it }.onFailure { errs += a.email + " : " + (it.message ?: "") }
            }
            results = all.sortedByDescending { it.date }
            errors = errs
            busy = false
        }
    }
    Surface(shape = MaterialTheme.shapes.large, color = MaterialTheme.colorScheme.surfaceContainerLow, border = appBorder(), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Rechercher dans mes mails", style = MaterialTheme.typography.titleMedium)
            OutlinedTextField(
                query, { query = it }, singleLine = true, modifier = Modifier.fillMaxWidth(),
                placeholder = { Text("Expéditeur, objet, mot du message…") },
                leadingIcon = { Icon(Icons.Filled.Search, null) },
                trailingIcon = { if (query.isNotEmpty()) IconButton(onClick = { query = ""; results = null }) { Icon(Icons.Filled.Close, "Effacer") } },
                keyboardOptions = KeyboardOptions(imeAction = androidx.compose.ui.text.input.ImeAction.Search),
                keyboardActions = androidx.compose.foundation.text.KeyboardActions(onSearch = { go() }),
            )
            if (accounts.size > 1) FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                FilterChip(selected = chosen.isEmpty(), onClick = { chosen = emptySet() }, label = { Text("Toutes les boîtes") })
                accounts.forEach { a ->
                    FilterChip(selected = a.id in chosen, onClick = { chosen = if (a.id in chosen) chosen - a.id else chosen + a.id }, label = { RawText(a.email, maxLines = 1) })
                }
            }
            Button(enabled = !busy && query.trim().length >= 2, onClick = { go() }, modifier = Modifier.fillMaxWidth()) {
                Icon(Icons.Filled.Search, null); Spacer(Modifier.width(6.dp)); Text("Rechercher")
            }
            if (busy) LinearProgressIndicator(Modifier.fillMaxWidth())
            errors.forEach { RawText(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall) }
            results?.let { r ->
                RawText(
                    if (r.isEmpty()) I18n.tr("Aucun mail trouvé.") else I18n.trf("{0} mail(s) trouvé(s)", r.size.toString()),
                    style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                r.take(60).forEach { h ->
                    val acc = accounts.firstOrNull { it.id == h.accountId }
                    Column {
                        if (accounts.size > 1 && acc != null) RawText(
                            acc.email + if (h.folder != "INBOX") " · " + I18n.tr("Envoyés") else "",
                            style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary,
                        ) else if (h.folder != "INBOX") RawText(I18n.tr("Envoyés"), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                        MailRow(h) { onOpen(h) }
                    }
                }
            }
        }
    }
}
