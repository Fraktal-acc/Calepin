package fr.jeremy.calepin.widgets

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.view.View
import android.widget.RemoteViews
import android.widget.Toast
import fr.jeremy.calepin.MainActivity
import fr.jeremy.calepin.R
import fr.jeremy.calepin.data.NoteDb
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/** Widgets de l'écran d'accueil du téléphone. */
object Widgets {
    /** Écran à ouvrir dans Calepin : « new_note », « new_list », « scan », « assistant », « agenda », « notes », « remote ». */
    const val EXTRA_OPEN = "calepin_open"

    fun open(ctx: Context, what: String, code: Int, noteId: Long = 0L): PendingIntent {
        val i = Intent(ctx, MainActivity::class.java)
            .setAction("fr.jeremy.calepin.OPEN.$what.$noteId")
            .putExtra(EXTRA_OPEN, what)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
        if (noteId > 0) i.putExtra(fr.jeremy.calepin.reminders.Reminders.EXTRA_NOTE, noteId)
        return PendingIntent.getActivity(ctx, code, i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
    }

    /** Met à jour les widgets « notes » et « agenda » après un changement. */
    fun refresh(ctx: Context) {
        val app = ctx.applicationContext
        val mgr = AppWidgetManager.getInstance(app)
        listOf(NotesWidget::class.java, AgendaWidget::class.java).forEach { cls ->
            val ids = runCatching { mgr.getAppWidgetIds(ComponentName(app, cls)) }.getOrNull() ?: return@forEach
            if (ids.isEmpty()) return@forEach
            app.sendBroadcast(Intent(app, cls).setAction(AppWidgetManager.ACTION_APPWIDGET_UPDATE).putExtra(AppWidgetManager.EXTRA_APPWIDGET_IDS, ids))
        }
    }

    private val ROWS = listOf(
        Triple(R.id.w_row0, R.id.w_title0, R.id.w_sub0),
        Triple(R.id.w_row1, R.id.w_title1, R.id.w_sub1),
        Triple(R.id.w_row2, R.id.w_title2, R.id.w_sub2),
        Triple(R.id.w_row3, R.id.w_title3, R.id.w_sub3),
    )

    internal fun fillRows(v: RemoteViews, rows: List<Triple<String, String, PendingIntent?>>, empty: String) {
        v.setViewVisibility(R.id.w_empty, if (rows.isEmpty()) View.VISIBLE else View.GONE)
        v.setTextViewText(R.id.w_empty, empty)
        ROWS.forEachIndexed { i, (row, title, sub) ->
            val r = rows.getOrNull(i)
            v.setViewVisibility(row, if (r == null) View.GONE else View.VISIBLE)
            if (r != null) {
                v.setTextViewText(title, r.first)
                v.setTextViewText(sub, r.second)
                v.setViewVisibility(sub, if (r.second.isBlank()) View.GONE else View.VISIBLE)
                r.third?.let { v.setOnClickPendingIntent(row, it) }
            }
        }
    }
}

/** Raccourcis : nouvelle note, liste à cocher, scanner, assistant. */
class QuickWidget : AppWidgetProvider() {
    override fun onUpdate(ctx: Context, mgr: AppWidgetManager, ids: IntArray) {
        val v = RemoteViews(ctx.packageName, R.layout.widget_quick)
        v.setOnClickPendingIntent(R.id.w_new, Widgets.open(ctx, "new_note", 101))
        v.setOnClickPendingIntent(R.id.w_list, Widgets.open(ctx, "new_list", 102))
        v.setOnClickPendingIntent(R.id.w_scan, Widgets.open(ctx, "scan", 103))
        v.setOnClickPendingIntent(R.id.w_voice, Widgets.open(ctx, "assistant", 104))
        ids.forEach { mgr.updateAppWidget(it, v) }
    }
}

/** Dernières notes (épinglées d'abord). */
class NotesWidget : AppWidgetProvider() {
    override fun onUpdate(ctx: Context, mgr: AppWidgetManager, ids: IntArray) {
        val pending = goAsync()
        Thread {
            try {
                val all = runCatching { NoteDb(ctx).all() }.getOrDefault(emptyList())
                val notes = (all.filter { it.pinned } + all.filter { !it.pinned }).take(4)
                val v = RemoteViews(ctx.packageName, R.layout.widget_notes)
                v.setTextViewText(R.id.w_heading, "Notes")
                v.setOnClickPendingIntent(R.id.w_add, Widgets.open(ctx, "new_note", 201))
                v.setOnClickPendingIntent(R.id.w_header, Widgets.open(ctx, "notes", 202))
                Widgets.fillRows(
                    v,
                    notes.mapIndexed { i, n ->
                        val first = n.content.lineSequence().firstOrNull { it.isNotBlank() }.orEmpty()
                        Triple((if (n.pinned) "📌 " else "") + n.title.ifBlank { first.ifBlank { "Sans titre" } }, if (n.title.isBlank()) "" else first, Widgets.open(ctx, "note", 210 + i, n.id))
                    },
                    "Aucune note pour l'instant. Touche + pour en créer une.",
                )
                ids.forEach { mgr.updateAppWidget(it, v) }
            } finally {
                pending.finish()
            }
        }.start()
    }
}

/** Rendez-vous d'aujourd'hui et de demain. */
class AgendaWidget : AppWidgetProvider() {
    override fun onUpdate(ctx: Context, mgr: AppWidgetManager, ids: IntArray) {
        val pending = goAsync()
        Thread {
            try {
                val now = System.currentTimeMillis()
                val end = Calendar.getInstance().apply {
                    add(Calendar.DAY_OF_YEAR, 1); set(Calendar.HOUR_OF_DAY, 23); set(Calendar.MINUTE, 59)
                }.timeInMillis
                val today = Calendar.getInstance().get(Calendar.DAY_OF_YEAR)
                val events = runCatching { NoteDb(ctx).events() }.getOrDefault(emptyList())
                    .filter { e -> (if (e.end > 0) e.end else e.start + 3_600_000) >= now && e.start <= end }
                    .sortedBy { it.start }
                    .take(4)
                val v = RemoteViews(ctx.packageName, R.layout.widget_agenda)
                v.setTextViewText(R.id.w_heading, SimpleDateFormat("EEEE d MMMM", Locale.FRANCE).format(Date()).replaceFirstChar { it.uppercase() })
                v.setOnClickPendingIntent(R.id.w_add, Widgets.open(ctx, "agenda", 301))
                v.setOnClickPendingIntent(R.id.w_header, Widgets.open(ctx, "agenda", 302))
                Widgets.fillRows(
                    v,
                    events.mapIndexed { i, e ->
                        val c = Calendar.getInstance().apply { timeInMillis = e.start }
                        val day = if (c.get(Calendar.DAY_OF_YEAR) == today || e.start < now) "Aujourd'hui" else "Demain"
                        val time = if (e.allDay) "toute la journée" else SimpleDateFormat("HH'h'mm", Locale.FRANCE).format(Date(e.start))
                        Triple(e.title, "$day · $time", if (e.noteId > 0) Widgets.open(ctx, "note", 310 + i, e.noteId) else Widgets.open(ctx, "agenda", 310 + i))
                    },
                    "Rien de prévu aujourd'hui ni demain.",
                )
                ids.forEach { mgr.updateAppWidget(it, v) }
            } finally {
                pending.finish()
            }
        }.start()
    }
}

/** Mini-télécommande (Calepin IA) : marche/arrêt, son, chaînes, sur la télé ou le décodeur par défaut. */
class RemoteWidget : AppWidgetProvider() {
    override fun onUpdate(ctx: Context, mgr: AppWidgetManager, ids: IntArray) {
        val v = RemoteViews(ctx.packageName, R.layout.widget_remote)
        listOf(
            R.id.w_power to "POWER", R.id.w_mute to "MUTE", R.id.w_volm to "VOL_DOWN",
            R.id.w_volp to "VOL_UP", R.id.w_chm to "CH_DOWN", R.id.w_chp to "CH_UP",
        ).forEachIndexed { i, (view, key) ->
            val intent = Intent(ctx, RemoteWidget::class.java).setAction(ACTION_KEY).putExtra("key", key)
            v.setOnClickPendingIntent(view, PendingIntent.getBroadcast(ctx, 400 + i, intent, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT))
        }
        v.setOnClickPendingIntent(R.id.w_open, Widgets.open(ctx, "remote", 420))
        v.setOnClickPendingIntent(R.id.w_mic, Widgets.open(ctx, "assistant", 421))
        ids.forEach { mgr.updateAppWidget(it, v) }
    }

    override fun onReceive(ctx: Context, intent: Intent) {
        if (intent.action != ACTION_KEY) { super.onReceive(ctx, intent); return }
        val key = runCatching { fr.jeremy.calepin.control.RemoteKey.valueOf(intent.getStringExtra("key") ?: "") }.getOrNull() ?: return
        val pending = goAsync()
        Thread {
            try {
                val ok = fr.jeremy.calepin.control.QuickRemote.press(ctx, key)
                if (!ok) android.os.Handler(android.os.Looper.getMainLooper()).post {
                    Toast.makeText(ctx, "Télé ou décodeur injoignable (même Wi-Fi ?)", Toast.LENGTH_SHORT).show()
                }
            } finally {
                pending.finish()
            }
        }.start()
    }

    companion object {
        const val ACTION_KEY = "fr.jeremy.calepin.REMOTE_KEY"
    }
}
