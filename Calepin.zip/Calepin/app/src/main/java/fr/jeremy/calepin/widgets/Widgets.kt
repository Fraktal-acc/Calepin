package fr.jeremy.calepin.widgets

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.view.View
import android.widget.RemoteViews
import android.widget.Toast
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.graphics.toArgb
import fr.jeremy.calepin.MainActivity
import fr.jeremy.calepin.R
import fr.jeremy.calepin.data.NoteDb
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/** Widgets de l'écran d'accueil du téléphone. */
object Widgets {
    /** Écran à ouvrir dans Calepin : « new_note », « new_list », « scan », « assistant », « agenda », « notes », « remote ». */
    const val EXTRA_OPEN = "calepin_open"

    fun open(ctx: Context, what: String, code: Int, noteId: Long = 0L): PendingIntent {
        val i = Intent(ctx, MainActivity::class.java)
            .setAction("fr.jeremy.calepin.OPEN.$what.$noteId")
            .putExtra(EXTRA_OPEN, what)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
        if (noteId > 0) i.putExtra(fr.jeremy.calepin.reminders.Reminders.EXTRA_NOTE, noteId)
        return PendingIntent.getActivity(ctx, code, i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
    }

    /** Met à jour les widgets « notes » et « agenda » après un changement. */
    fun refresh(ctx: Context) = update(ctx, listOf(NotesWidget::class.java, AgendaWidget::class.java, ShiftWidget::class.java))

    /** Redessine tous les widgets (changement de style). */
    fun refreshAll(ctx: Context) = update(ctx, listOf(QuickWidget::class.java, NotesWidget::class.java, AgendaWidget::class.java, RemoteWidget::class.java, WeatherWidget::class.java, ShiftWidget::class.java))

    private fun update(ctx: Context, classes: List<Class<out AppWidgetProvider>>) {
        val app = ctx.applicationContext
        val mgr = AppWidgetManager.getInstance(app)
        classes.forEach { cls ->
            val ids = runCatching { mgr.getAppWidgetIds(ComponentName(app, cls)) }.getOrNull() ?: return@forEach
            if (ids.isEmpty()) return@forEach
            app.sendBroadcast(Intent(app, cls).setAction(AppWidgetManager.ACTION_APPWIDGET_UPDATE).putExtra(AppWidgetManager.EXTRA_APPWIDGET_IDS, ids))
        }
    }

    /** Couleurs et fonds d'un style de widget. [tint] : teinte appliquée au fond blanc (style « thème »). */
    class WStyle(val bg: Int, val chip: Int, val text: Int, val sub: Int, val icon: Int, val tint: Int? = null, val chipTint: Int? = null)

    fun style(ctx: Context): WStyle {
        val a = fr.jeremy.calepin.ui.Appearance.get(ctx)
        val night = (ctx.resources.configuration.uiMode and android.content.res.Configuration.UI_MODE_NIGHT_MASK) == android.content.res.Configuration.UI_MODE_NIGHT_YES
        return when (a.widgetStyle.value) {
            fr.jeremy.calepin.ui.WidgetStyle.AUTO -> WStyle(
                R.drawable.widget_bg, R.drawable.widget_chip,
                ctx.getColor(R.color.widget_text), ctx.getColor(R.color.widget_sub), ctx.getColor(R.color.widget_fg),
            )
            fr.jeremy.calepin.ui.WidgetStyle.CLAIR -> WStyle(R.drawable.widget_bg_light, R.drawable.widget_chip_light, 0xFF1B1C1E.toInt(), 0xFF5A6066.toInt(), 0xFF1F5F7A.toInt())
            fr.jeremy.calepin.ui.WidgetStyle.SOMBRE -> WStyle(R.drawable.widget_bg_dark, R.drawable.widget_chip_dark, 0xFFE4E3E0.toInt(), 0xFFA9B0B5.toInt(), 0xFF9FD3EA.toInt())
            fr.jeremy.calepin.ui.WidgetStyle.VERRE -> WStyle(R.drawable.widget_bg_glass, R.drawable.widget_chip_glass, 0xFFFFFFFF.toInt(), 0xDDFFFFFF.toInt(), 0xFFFFFFFF.toInt())
            fr.jeremy.calepin.ui.WidgetStyle.NEON -> WStyle(R.drawable.widget_bg_neon, R.drawable.widget_chip_neon, 0xFFFFFFFF.toInt(), 0xFFB8F7FF.toInt(), 0xFF00F0FF.toInt())
            fr.jeremy.calepin.ui.WidgetStyle.THEME -> {
                val sp = a.spec()
                val dark = sp.forceDark ?: night
                val bg = if (dark) sp.neutral.takeIf { it.luminance() < 0.3f } ?: androidx.compose.ui.graphics.Color(0xFF15181B) else sp.neutral
                val chip = androidx.compose.ui.graphics.lerp(bg, sp.primary, if (dark) 0.25f else 0.15f)
                WStyle(
                    R.drawable.widget_bg_white, R.drawable.widget_chip_white,
                    if (dark) 0xFFF1F1F1.toInt() else 0xFF1B1C1E.toInt(), if (dark) 0xFFB9BEC3.toInt() else 0xFF5A6066.toInt(),
                    (if (dark) androidx.compose.ui.graphics.lerp(sp.primary, androidx.compose.ui.graphics.Color.White, 0.2f) else sp.primary).toArgb(),
                    tint = bg.copy(alpha = 0.95f).toArgb(), chipTint = chip.toArgb(),
                )
            }
        }
    }

    internal fun applyStyle(ctx: Context, v: RemoteViews, chips: List<Int>, texts: List<Int>, subs: List<Int>, icons: List<Int>) {
        val st = style(ctx)
        v.setInt(R.id.w_root, "setBackgroundResource", st.bg)
        if (st.tint != null && android.os.Build.VERSION.SDK_INT >= 31) v.setColorStateList(R.id.w_root, "setBackgroundTintList", android.content.res.ColorStateList.valueOf(st.tint))
        chips.forEach { id ->
            v.setInt(id, "setBackgroundResource", st.chip)
            if (st.chipTint != null && android.os.Build.VERSION.SDK_INT >= 31) v.setColorStateList(id, "setBackgroundTintList", android.content.res.ColorStateList.valueOf(st.chipTint))
        }
        // Couleur du texte choisie dans Apparence (sinon celle du style)
        val a = fr.jeremy.calepin.ui.Appearance.get(ctx)
        val customText = fr.jeremy.calepin.ui.ColorPref.color(a.widgetText.value)?.toArgb()
        texts.forEach { v.setTextColor(it, customText ?: st.text) }
        subs.forEach { v.setTextColor(it, customText?.let { c -> (c and 0x00FFFFFF) or (0xCC shl 24) } ?: st.sub) }
        icons.forEach { v.setInt(it, "setColorFilter", st.icon) }
        // Bordure : couleur choisie, aucune, ou rien de plus que le style (automatique)
        val border = fr.jeremy.calepin.ui.ColorPref.color(a.widgetBorder.value)
        if (border != null) {
            v.setViewVisibility(R.id.w_border, View.VISIBLE)
            v.setInt(R.id.w_border, "setColorFilter", border.toArgb())
        } else {
            v.setViewVisibility(R.id.w_border, View.GONE)
        }
    }

    /** Style des widgets « liste » (notes, agenda). */
    internal fun applyListStyle(ctx: Context, v: RemoteViews) {
        val st = style(ctx)
        applyStyle(
            ctx, v, chips = emptyList(),
            texts = listOf(R.id.w_title0, R.id.w_title1, R.id.w_title2, R.id.w_title3),
            subs = listOf(R.id.w_sub0, R.id.w_sub1, R.id.w_sub2, R.id.w_sub3, R.id.w_empty),
            icons = listOf(R.id.w_hicon, R.id.w_add),
        )
        v.setTextColor(R.id.w_heading, fr.jeremy.calepin.ui.ColorPref.color(fr.jeremy.calepin.ui.Appearance.get(ctx).widgetText.value)?.toArgb() ?: st.icon)
    }

    private val ROWS = listOf(
        Triple(R.id.w_row0, R.id.w_title0, R.id.w_sub0),
        Triple(R.id.w_row1, R.id.w_title1, R.id.w_sub1),
        Triple(R.id.w_row2, R.id.w_title2, R.id.w_sub2),
        Triple(R.id.w_row3, R.id.w_title3, R.id.w_sub3),
    )

    internal fun fillRows(v: RemoteViews, rows: List<Triple<String, String, PendingIntent?>>, empty: String) {
        v.setViewVisibility(R.id.w_empty, if (rows.isEmpty()) View.VISIBLE else View.GONE)
        v.setTextViewText(R.id.w_empty, empty)
        ROWS.forEachIndexed { i, (row, title, sub) ->
            val r = rows.getOrNull(i)
            v.setViewVisibility(row, if (r == null) View.GONE else View.VISIBLE)
            if (r != null) {
                v.setTextViewText(title, r.first)
                v.setTextViewText(sub, r.second)
                v.setViewVisibility(sub, if (r.second.isBlank()) View.GONE else View.VISIBLE)
                r.third?.let { v.setOnClickPendingIntent(row, it) }
            }
        }
    }
}

/** Raccourcis : nouvelle note, liste à cocher, scanner, assistant. */
class QuickWidget : AppWidgetProvider() {
    override fun onUpdate(ctx: Context, mgr: AppWidgetManager, ids: IntArray) {
        fr.jeremy.calepin.i18n.I18n.init(ctx)
        val v = RemoteViews(ctx.packageName, R.layout.widget_quick)
        listOf(R.id.w_t0 to "Note", R.id.w_t1 to "Liste", R.id.w_t2 to "Scanner", R.id.w_t3 to "Assistant")
            .forEach { (id, label) -> v.setTextViewText(id, fr.jeremy.calepin.i18n.I18n.tr(label)) }
        v.setOnClickPendingIntent(R.id.w_new, Widgets.open(ctx, "new_note", 101))
        v.setOnClickPendingIntent(R.id.w_list, Widgets.open(ctx, "new_list", 102))
        v.setOnClickPendingIntent(R.id.w_scan, Widgets.open(ctx, "scan", 103))
        v.setOnClickPendingIntent(R.id.w_voice, Widgets.open(ctx, "assistant", 104))
        Widgets.applyStyle(
            ctx, v, chips = listOf(R.id.w_new, R.id.w_list, R.id.w_scan, R.id.w_voice),
            texts = listOf(R.id.w_t0, R.id.w_t1, R.id.w_t2, R.id.w_t3), subs = emptyList(),
            icons = listOf(R.id.w_i0, R.id.w_i1, R.id.w_i2, R.id.w_i3),
        )
        ids.forEach { mgr.updateAppWidget(it, v) }
    }
}

/** Dernières notes (épinglées d'abord). */
class NotesWidget : AppWidgetProvider() {
    override fun onUpdate(ctx: Context, mgr: AppWidgetManager, ids: IntArray) {
        fr.jeremy.calepin.i18n.I18n.init(ctx)
        val pending = goAsync()
        Thread {
            try {
                fr.jeremy.calepin.SectionLock.init(ctx)
                // Notes protégées par code : jamais affichées sur l'écran d'accueil du téléphone
                val all = if (fr.jeremy.calepin.SectionLock.isGuarded(fr.jeremy.calepin.SectionLock.NOTES)) emptyList()
                else runCatching { NoteDb(ctx).all() }.getOrDefault(emptyList())
                    .filter { !(fr.jeremy.calepin.SectionLock.isPrivate(it.id) && fr.jeremy.calepin.SectionLock.isGuarded(fr.jeremy.calepin.SectionLock.PRIVATE)) }
                val notes = (all.filter { it.pinned } + all.filter { !it.pinned }).take(4)
                val v = RemoteViews(ctx.packageName, R.layout.widget_notes)
                Widgets.applyListStyle(ctx, v)
                v.setTextViewText(R.id.w_heading, fr.jeremy.calepin.i18n.I18n.tr("Notes"))
                v.setOnClickPendingIntent(R.id.w_add, Widgets.open(ctx, "new_note", 201))
                v.setOnClickPendingIntent(R.id.w_header, Widgets.open(ctx, "notes", 202))
                Widgets.fillRows(
                    v,
                    notes.mapIndexed { i, n ->
                        val first = n.content.lineSequence().firstOrNull { it.isNotBlank() }.orEmpty()
                        Triple((if (n.pinned) "📌 " else "") + n.title.ifBlank { first.ifBlank { fr.jeremy.calepin.i18n.I18n.tr("Sans titre") } }, if (n.title.isBlank()) "" else first, Widgets.open(ctx, "note", 210 + i, n.id))
                    },
                    fr.jeremy.calepin.i18n.I18n.tr("Aucune note pour l'instant. Touche + pour en créer une."),
                )
                ids.forEach { mgr.updateAppWidget(it, v) }
            } finally {
                pending.finish()
            }
        }.start()
    }
}

/** Rendez-vous d'aujourd'hui et de demain. */
class AgendaWidget : AppWidgetProvider() {
    override fun onUpdate(ctx: Context, mgr: AppWidgetManager, ids: IntArray) {
        fr.jeremy.calepin.i18n.I18n.init(ctx)
        val pending = goAsync()
        Thread {
            try {
                val now = System.currentTimeMillis()
                val end = Calendar.getInstance().apply {
                    add(Calendar.DAY_OF_YEAR, 1); set(Calendar.HOUR_OF_DAY, 23); set(Calendar.MINUTE, 59)
                }.timeInMillis
                val today = Calendar.getInstance().get(Calendar.DAY_OF_YEAR)
                val events = runCatching { NoteDb(ctx).events() }.getOrDefault(emptyList())
                    .filter { e -> (if (e.end > 0) e.end else e.start + 3_600_000) >= now && e.start <= end }
                    .sortedBy { it.start }
                    .take(4)
                val v = RemoteViews(ctx.packageName, R.layout.widget_agenda)
                Widgets.applyListStyle(ctx, v)
                v.setTextViewText(R.id.w_heading, SimpleDateFormat(fr.jeremy.calepin.i18n.I18n.pattern("EEEE d MMMM"), fr.jeremy.calepin.i18n.I18n.locale).format(Date()).replaceFirstChar { it.uppercase() })
                v.setOnClickPendingIntent(R.id.w_add, Widgets.open(ctx, "agenda", 301))
                v.setOnClickPendingIntent(R.id.w_header, Widgets.open(ctx, "agenda", 302))
                Widgets.fillRows(
                    v,
                    events.mapIndexed { i, e ->
                        val c = Calendar.getInstance().apply { timeInMillis = e.start }
                        val day = if (c.get(Calendar.DAY_OF_YEAR) == today || e.start < now) fr.jeremy.calepin.i18n.I18n.tr("Aujourd'hui") else fr.jeremy.calepin.i18n.I18n.tr("Demain")
                        val time = if (e.allDay) fr.jeremy.calepin.i18n.I18n.tr("toute la journée") else SimpleDateFormat(fr.jeremy.calepin.i18n.I18n.pattern("HH'h'mm"), fr.jeremy.calepin.i18n.I18n.locale).format(Date(e.start))
                        Triple(e.title, "$day · $time", if (e.noteId > 0) Widgets.open(ctx, "note", 310 + i, e.noteId) else Widgets.open(ctx, "agenda", 310 + i))
                    },
                    fr.jeremy.calepin.i18n.I18n.tr("Rien de prévu aujourd'hui ni demain."),
                )
                ids.forEach { mgr.updateAppWidget(it, v) }
            } finally {
                pending.finish()
            }
        }.start()
    }
}

/** Mini-télécommande (Calepin IA) : marche/arrêt, son, chaînes, sur la télé ou le décodeur par défaut. */
class RemoteWidget : AppWidgetProvider() {
    override fun onUpdate(ctx: Context, mgr: AppWidgetManager, ids: IntArray) {
        val v = RemoteViews(ctx.packageName, R.layout.widget_remote)
        listOf(
            R.id.w_power to "POWER", R.id.w_mute to "MUTE", R.id.w_volm to "VOL_DOWN",
            R.id.w_volp to "VOL_UP", R.id.w_chm to "CH_DOWN", R.id.w_chp to "CH_UP",
        ).forEachIndexed { i, (view, key) ->
            val intent = Intent(ctx, RemoteWidget::class.java).setAction(ACTION_KEY).putExtra("key", key)
            v.setOnClickPendingIntent(view, PendingIntent.getBroadcast(ctx, 400 + i, intent, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT))
        }
        v.setOnClickPendingIntent(R.id.w_open, Widgets.open(ctx, "remote", 420))
        v.setOnClickPendingIntent(R.id.w_mic, Widgets.open(ctx, "assistant", 421))
        val buttons = listOf(R.id.w_power, R.id.w_mute, R.id.w_volm, R.id.w_volp, R.id.w_open, R.id.w_chm, R.id.w_chp, R.id.w_mic)
        Widgets.applyStyle(ctx, v, chips = buttons, texts = emptyList(), subs = emptyList(), icons = buttons)
        ids.forEach { mgr.updateAppWidget(it, v) }
    }

    override fun onReceive(ctx: Context, intent: Intent) {
        if (intent.action != ACTION_KEY) { super.onReceive(ctx, intent); return }
        val key = runCatching { fr.jeremy.calepin.control.RemoteKey.valueOf(intent.getStringExtra("key") ?: "") }.getOrNull() ?: return
        fr.jeremy.calepin.i18n.I18n.init(ctx)
        val pending = goAsync()
        Thread {
            try {
                val ok = fr.jeremy.calepin.control.QuickRemote.press(ctx, key)
                if (!ok) android.os.Handler(android.os.Looper.getMainLooper()).post {
                    fr.jeremy.calepin.i18n.I18n.toast(ctx, "Télé ou décodeur injoignable (même Wi-Fi ?)", Toast.LENGTH_SHORT).show()
                }
            } finally {
                pending.finish()
            }
        }.start()
    }

    companion object {
        const val ACTION_KEY = "fr.jeremy.calepin.REMOTE_KEY"
    }
}
