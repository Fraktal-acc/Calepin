package fr.jeremy.calepin.control

import android.content.Context
import fr.jeremy.calepin.search.TextNorm
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

/** Rôle d'un appareil dans la maison : sert à choisir la « télé » ou le « décodeur » par défaut. */
enum class Role(val label: String) {
    TV("Télévision"), DECODER("Décodeur / box TV"), LIGHT("Lumière"), PLUG("Prise / interrupteur"), HUB("Centrale"), OTHER("Autre")
}

/** Familles d'appareils que Calepin IA sait piloter sur le réseau local. */
enum class Kind(val label: String, val role: Role, val help: String) {
    ORANGE("Décodeur TV d'Orange", Role.DECODER, "Rien à régler : il suffit d'être sur le même Wi-Fi."),
    FREEBOX_PLAYER(
        "Freebox Player (Révolution, mini 4K…)", Role.DECODER,
        "Sur la télé : Réglages du Freebox Player → Système → Informations générales → « Code télécommande réseau » (8 chiffres). " +
            "La Freebox Pop et la Delta se pilotent plutôt comme « Android TV / Google TV ».",
    ),
    ANDROID_TV(
        "Android TV / Google TV", Role.TV,
        "Téléviseurs Sony, Philips, TCL, Xiaomi, Hisense…, boîtiers Freebox Pop, Bbox 4K, SFR, Chromecast, Nvidia Shield. " +
            "Touche « Afficher le code » : un code à 6 caractères apparaît sur la télé, recopie-le.",
    ),
    BRAVIA(
        "Sony Bravia (contrôle IP)", Role.TV,
        "Sur la télé : Paramètres → Réseau et Internet → Configuration du réseau domestique → Contrôle IP → " +
            "Authentification « Normal et clé pré-partagée », choisis une clé et recopie-la. Active aussi « Démarrage à distance ».",
    ),
    SAMSUNG("Téléviseur Samsung (Tizen)", Role.TV, "Touche « Connecter » puis accepte la demande qui s'affiche sur la télé."),
    LG("Téléviseur LG (webOS)", Role.TV, "Touche « Connecter » puis accepte la demande qui s'affiche sur la télé."),
    ROKU("Roku", Role.TV, "Rien à régler. Sur certains modèles : Paramètres → Système → Réglages avancés → Contrôle par applis mobiles → Activé."),
    HUE("Pont Philips Hue", Role.HUB, "Appuie sur le gros bouton du pont Hue, puis touche « Connecter » dans les 30 secondes."),
    SHELLY("Shelly", Role.PLUG, "Rien à régler (sans mot de passe sur l'appareil)."),
    TASMOTA("Tasmota", Role.PLUG, "Rien à régler (sans mot de passe sur l'appareil)."),
    WLED("WLED", Role.LIGHT, "Rien à régler."),
    YEELIGHT("Ampoule Yeelight", Role.LIGHT, "Dans l'appli Yeelight, active « Contrôle LAN » pour cette ampoule."),
    HOME_ASSISTANT(
        "Home Assistant", Role.HUB,
        "Adresse du type http://192.168.1.10:8123. Jeton : dans Home Assistant, Profil → Sécurité → Jetons d'accès longue durée → Créer. " +
            "Tous les appareils de Home Assistant (Tuya, Google, Alexa, Zigbee, Matter…) deviennent pilotables.",
    ),
    INFRAROUGE(
        "Infrarouge du téléphone (Samsung, LG, Sony, Philips)", Role.TV,
        "Pour les téléphones équipés d'un émetteur infrarouge (beaucoup de Xiaomi, Redmi, Poco, Honor…). " +
            "Choisis la marque de la télé, puis vise-la avec le haut du téléphone. Fonctionne même avec une télé ancienne, sans Wi-Fi.",
    ),
    WEBHOOK(
        "Commande web (adresse URL)", Role.OTHER,
        "Pour tout appareil ou service qui se commande par une adresse web (Jeedom, Domoticz, IFTTT, Freebox, scénario…).",
    ),
}

/** Un appareil enregistré. [secret] : clé, jeton ou code ; [extra] : réglages propres à la famille (JSON). */
data class HomeDevice(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val kind: Kind,
    val host: String,
    val role: Role = kind.role,
    val secret: String = "",
    val extra: String = "{}",
    val isDefault: Boolean = false,
) {
    val extraJson: JSONObject get() = runCatching { JSONObject(extra) }.getOrDefault(JSONObject())

    fun toJson(): JSONObject = JSONObject()
        .put("id", id).put("name", name).put("kind", kind.name).put("host", host)
        .put("role", role.name).put("secret", secret).put("extra", extra).put("default", isDefault)

    companion object {
        fun fromJson(o: JSONObject): HomeDevice? = runCatching {
            HomeDevice(
                id = o.getString("id"),
                name = o.getString("name"),
                kind = Kind.valueOf(o.getString("kind")),
                host = o.getString("host"),
                role = Role.valueOf(o.optString("role", Kind.valueOf(o.getString("kind")).role.name)),
                secret = o.optString("secret"),
                extra = o.optString("extra", "{}"),
                isDefault = o.optBoolean("default"),
            )
        }.getOrNull()
    }
}

/**
 * Ce que l'on peut nommer dans une phrase : un appareil, ou un élément d'une centrale
 * (lampe Hue, pièce Hue, entité Home Assistant…).
 */
data class Target(val device: HomeDevice, val subId: String?, val name: String, val type: String) {
    val normName: String = TextNorm.norm(name).replace(Regex("[^a-z0-9 ]"), " ").replace(Regex("\\s+"), " ").trim()
}

/** Enregistrement des appareils sur le téléphone. */
class DeviceStore(ctx: Context) {
    val context: Context = ctx.applicationContext
    private val p = ctx.getSharedPreferences("calepin_home", Context.MODE_PRIVATE)

    init {
        migrate()
    }

    fun all(): List<HomeDevice> {
        val arr = runCatching { JSONArray(p.getString("devices", "[]")) }.getOrDefault(JSONArray())
        return (0 until arr.length()).mapNotNull { arr.optJSONObject(it)?.let(HomeDevice::fromJson) }
    }

    private fun saveAll(list: List<HomeDevice>) {
        p.edit().putString("devices", JSONArray().apply { list.forEach { put(it.toJson()) } }.toString()).apply()
    }

    fun upsert(d: HomeDevice) {
        val list = all().toMutableList()
        val i = list.indexOfFirst { it.id == d.id }
        if (i >= 0) list[i] = d else list += d
        saveAll(list)
    }

    fun delete(id: String) = saveAll(all().filter { it.id != id })

    /** Change un réglage propre à un appareil (ex. le jeton d'accès d'une télé Sony). */
    fun setExtra(id: String, key: String, value: String) {
        val d = all().firstOrNull { it.id == id } ?: return
        upsert(d.copy(extra = d.extraJson.put(key, value).toString()))
    }

    fun setDefault(d: HomeDevice) = saveAll(all().map {
        when {
            it.id == d.id -> it.copy(isDefault = true)
            it.role == d.role -> it.copy(isDefault = false)
            else -> it
        }
    })

    /** Appareil par défaut pour un rôle (celui marqué, sinon le premier). */
    fun defaultFor(role: Role): HomeDevice? = all().filter { it.role == role }.let { l -> l.firstOrNull { it.isDefault } ?: l.firstOrNull() }

    /** Identité du téléphone pour les télés Android TV (créée une fois, partagée par toutes). */
    fun androidTvIdentity(): AndroidTvRemote.Identity {
        val pk = p.getString("atv_pk", null)
        val cert = p.getString("atv_cert", null)
        if (pk != null && cert != null) return AndroidTvRemote.Identity(pk, cert)
        val id = AndroidTvRemote.newIdentity("Calepin IA")
        p.edit().putString("atv_pk", id.privateKey).putString("atv_cert", id.certificate).apply()
        return id
    }

    /** Tout ce qu'on peut nommer : appareils et éléments des centrales. */
    fun targets(): List<Target> = all().flatMap { d ->
        when (d.kind) {
            Kind.HUE, Kind.HOME_ASSISTANT -> {
                val subs = d.extraJson.optJSONArray("targets") ?: JSONArray()
                (0 until subs.length()).mapNotNull { i ->
                    subs.optJSONObject(i)?.let { Target(d, it.optString("id"), it.optString("name"), it.optString("type")) }
                }
            }
            else -> listOf(Target(d, null, d.name, d.role.name.lowercase()))
        }
    }

    /** Reprend les réglages de la version précédente (décodeur Orange et Sony saisis à la main). */
    private fun migrate() {
        if (p.getBoolean("migrated_v2", false)) return
        val list = mutableListOf<HomeDevice>()
        p.getString("decoder_ip", "")?.takeIf { it.isNotBlank() }?.let {
            list += HomeDevice(name = "Décodeur Orange", kind = Kind.ORANGE, host = it, isDefault = true)
        }
        p.getString("bravia_ip", "")?.takeIf { it.isNotBlank() }?.let {
            list += HomeDevice(
                name = "Télé Sony", kind = Kind.BRAVIA, host = it, secret = p.getString("bravia_psk", "") ?: "",
                extra = JSONObject().put("mac", p.getString("bravia_mac", "")).toString(), isDefault = true,
            )
        }
        if (list.isNotEmpty()) saveAll(all() + list)
        p.edit().putBoolean("migrated_v2", true).apply()
    }
}
