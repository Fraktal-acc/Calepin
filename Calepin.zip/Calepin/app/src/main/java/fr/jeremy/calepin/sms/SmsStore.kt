package fr.jeremy.calepin.sms

import android.Manifest
import android.app.PendingIntent
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.ContactsContract
import android.provider.Telephony
import android.telephony.PhoneNumberUtils
import android.telephony.SmsManager
import androidx.core.content.ContextCompat

/** Conversation SMS/MMS du téléphone. */
data class SmsThread(
    val id: Long,
    val addresses: List<String>,
    val snippet: String,
    val date: Long,
    val unread: Boolean,
    val count: Int,
)

/** Message d'une conversation. [images] : photos d'un MMS. */
data class SmsMessage(
    val id: Long,
    val mms: Boolean,
    val address: String,
    val body: String,
    val date: Long,
    /** Reçu (true) ou envoyé par moi. */
    val incoming: Boolean,
    /** Envoi en cours ou échoué (messages envoyés). */
    val pending: Boolean,
    val failed: Boolean,
    val read: Boolean,
    val images: List<Uri> = emptyList(),
)

/** Contact trouvé pour un numéro. */
data class SmsContact(val name: String, val id: Long, val lookup: String?, val photo: Uri?)

/**
 * Lecture et envoi des SMS du téléphone (fournisseur de messages d'Android).
 * Calepin n'est pas l'appli SMS par défaut : lecture de tout, envoi de SMS ; les messages envoyés sont
 * enregistrés par Android dans les conversations, comme depuis l'appli Messages.
 */
object SmsStore {
    val PERMISSIONS = arrayOf(Manifest.permission.READ_SMS, Manifest.permission.SEND_SMS, Manifest.permission.READ_CONTACTS)

    fun canRead(ctx: Context) = granted(ctx, Manifest.permission.READ_SMS)
    fun canSend(ctx: Context) = granted(ctx, Manifest.permission.SEND_SMS)
    private fun granted(ctx: Context, p: String) = ContextCompat.checkSelfPermission(ctx, p) == PackageManager.PERMISSION_GRANTED

    /** Calepin est-il l'appli SMS par défaut (seule à pouvoir supprimer ou marquer comme lu) ? */
    fun isDefault(ctx: Context) = try { Telephony.Sms.getDefaultSmsPackage(ctx) == ctx.packageName } catch (_: Exception) { false }

    /** Appli SMS par défaut du téléphone (pour y ouvrir une conversation). */
    fun defaultApp(ctx: Context): String? = try { Telephony.Sms.getDefaultSmsPackage(ctx) } catch (_: Exception) { null }

    // ------------------------------------------------------------------ Conversations

    fun threads(ctx: Context): List<SmsThread> {
        if (!canRead(ctx)) return emptyList()
        return try { threadsFromConversations(ctx) } catch (_: Exception) { null }
            ?.takeIf { it.isNotEmpty() }
            ?: try { threadsFromSms(ctx) } catch (_: Exception) { emptyList() }
    }

    private fun threadsFromConversations(ctx: Context): List<SmsThread> {
        val cr = ctx.contentResolver
        val canon = HashMap<Long, String>()
        cr.query(Uri.parse("content://mms-sms/canonical-addresses"), null, null, null, null)?.use { c ->
            val iId = c.getColumnIndex("_id")
            val iAd = c.getColumnIndex("address")
            if (iId >= 0 && iAd >= 0) while (c.moveToNext()) canon[c.getLong(iId)] = c.getString(iAd) ?: ""
        }
        val out = ArrayList<SmsThread>()
        cr.query(
            Uri.parse("content://mms-sms/conversations?simple=true"),
            arrayOf("_id", "date", "message_count", "recipient_ids", "snippet", "read"),
            null, null, "date DESC",
        )?.use { c ->
            while (c.moveToNext()) {
                val count = c.getInt(2)
                if (count <= 0) continue
                val ids = (c.getString(3) ?: "").split(' ').mapNotNull { it.trim().toLongOrNull() }
                val addrs = ids.mapNotNull { canon[it] }.filter { it.isNotBlank() }
                out += SmsThread(
                    id = c.getLong(0),
                    addresses = addrs,
                    snippet = fixSnippet(c.getString(4) ?: ""),
                    date = c.getLong(1),
                    unread = c.getInt(5) == 0,
                    count = count,
                )
            }
        }
        return out
    }

    /** Certains téléphones renvoient l'aperçu d'un MMS mal décodé : on le laisse vide plutôt qu'illisible. */
    private fun fixSnippet(s: String) = if (s.count { it == '�' } > 2) "" else s

    /** Repli : conversations reconstituées à partir des seuls SMS. */
    private fun threadsFromSms(ctx: Context): List<SmsThread> {
        val byThread = LinkedHashMap<Long, SmsThread>()
        ctx.contentResolver.query(
            Telephony.Sms.CONTENT_URI,
            arrayOf(Telephony.Sms.THREAD_ID, Telephony.Sms.ADDRESS, Telephony.Sms.BODY, Telephony.Sms.DATE, Telephony.Sms.READ, Telephony.Sms.TYPE),
            null, null, Telephony.Sms.DATE + " DESC",
        )?.use { c ->
            while (c.moveToNext()) {
                val tid = c.getLong(0)
                val unread = c.getInt(4) == 0 && c.getInt(5) == Telephony.Sms.MESSAGE_TYPE_INBOX
                val prev = byThread[tid]
                byThread[tid] = prev?.copy(count = prev.count + 1, unread = prev.unread || unread)
                    ?: SmsThread(tid, listOfNotNull(c.getString(1)), c.getString(2) ?: "", c.getLong(3), unread, 1)
            }
        }
        return byThread.values.toList()
    }

    /** Conversation d'un numéro (null s'il n'y en a pas encore). */
    fun threadIdFor(ctx: Context, address: String): Long? {
        if (!canRead(ctx)) return null
        val digits = address.filter { it.isDigit() }.takeLast(8)
        return threads(ctx).firstOrNull { t -> t.addresses.size == 1 && sameNumber(t.addresses[0], address, digits) }?.id
    }

    fun sameNumber(a: String, b: String, bDigits: String = b.filter { it.isDigit() }.takeLast(8)): Boolean {
        if (a.equals(b, ignoreCase = true)) return true
        val ad = a.filter { it.isDigit() }.takeLast(8)
        return ad.length >= 6 && ad == bDigits || try { PhoneNumberUtils.compare(a, b) } catch (_: Exception) { false }
    }

    // ------------------------------------------------------------------ Messages

    /** Derniers messages d'une conversation (SMS et MMS), du plus ancien au plus récent. */
    fun messages(ctx: Context, threadId: Long, limit: Int = 400): List<SmsMessage> {
        if (!canRead(ctx)) return emptyList()
        val out = ArrayList<SmsMessage>()
        val cr = ctx.contentResolver
        try {
            cr.query(
                Telephony.Sms.CONTENT_URI,
                arrayOf(Telephony.Sms._ID, Telephony.Sms.ADDRESS, Telephony.Sms.BODY, Telephony.Sms.DATE, Telephony.Sms.TYPE, Telephony.Sms.READ),
                Telephony.Sms.THREAD_ID + "=?", arrayOf(threadId.toString()),
                Telephony.Sms.DATE + " DESC LIMIT " + limit,
            )?.use { c ->
                while (c.moveToNext()) {
                    val type = c.getInt(4)
                    out += SmsMessage(
                        id = c.getLong(0), mms = false,
                        address = c.getString(1) ?: "",
                        body = c.getString(2) ?: "",
                        date = c.getLong(3),
                        incoming = type == Telephony.Sms.MESSAGE_TYPE_INBOX,
                        pending = type == Telephony.Sms.MESSAGE_TYPE_OUTBOX || type == Telephony.Sms.MESSAGE_TYPE_QUEUED,
                        failed = type == Telephony.Sms.MESSAGE_TYPE_FAILED,
                        read = c.getInt(5) != 0,
                    )
                }
            }
        } catch (_: Exception) { }
        try {
            cr.query(
                Telephony.Mms.CONTENT_URI,
                arrayOf(Telephony.Mms._ID, Telephony.Mms.DATE, Telephony.Mms.MESSAGE_BOX, Telephony.Mms.READ),
                Telephony.Mms.THREAD_ID + "=?", arrayOf(threadId.toString()),
                Telephony.Mms.DATE + " DESC LIMIT " + (limit / 2),
            )?.use { c ->
                while (c.moveToNext()) {
                    val id = c.getLong(0)
                    val box = c.getInt(2)
                    val (text, images) = mmsParts(ctx, id)
                    out += SmsMessage(
                        id = id, mms = true,
                        address = mmsFrom(ctx, id),
                        body = text,
                        date = c.getLong(1) * 1000L,
                        incoming = box == Telephony.Mms.MESSAGE_BOX_INBOX,
                        pending = box == Telephony.Mms.MESSAGE_BOX_OUTBOX,
                        failed = box == Telephony.Mms.MESSAGE_BOX_FAILED,
                        read = c.getInt(3) != 0,
                        images = images,
                    )
                }
            }
        } catch (_: Exception) { }
        return out.sortedBy { it.date }.takeLast(limit)
    }

    private fun mmsParts(ctx: Context, id: Long): Pair<String, List<Uri>> {
        val text = StringBuilder()
        val images = ArrayList<Uri>()
        try {
            ctx.contentResolver.query(Uri.parse("content://mms/part"), arrayOf("_id", "ct", "text"), "mid=?", arrayOf(id.toString()), null)?.use { c ->
                while (c.moveToNext()) {
                    val ct = c.getString(1) ?: ""
                    when {
                        ct == "text/plain" -> c.getString(2)?.let { if (text.isNotEmpty()) text.append('\n'); text.append(it) }
                        ct.startsWith("image/") -> images += Uri.parse("content://mms/part/" + c.getLong(0))
                    }
                }
            }
        } catch (_: Exception) { }
        return text.toString() to images
    }

    private fun mmsFrom(ctx: Context, id: Long): String {
        try {
            ctx.contentResolver.query(Uri.parse("content://mms/$id/addr"), arrayOf("address", "type"), "type=137", null, null)?.use { c ->
                if (c.moveToFirst()) return c.getString(0) ?: ""
            }
        } catch (_: Exception) { }
        return ""
    }

    /** Recherche dans tous les SMS : (conversation, message). */
    fun search(ctx: Context, query: String, limit: Int = 60): List<Pair<Long, SmsMessage>> {
        if (!canRead(ctx) || query.isBlank()) return emptyList()
        val out = ArrayList<Pair<Long, SmsMessage>>()
        try {
            ctx.contentResolver.query(
                Telephony.Sms.CONTENT_URI,
                arrayOf(Telephony.Sms._ID, Telephony.Sms.ADDRESS, Telephony.Sms.BODY, Telephony.Sms.DATE, Telephony.Sms.TYPE, Telephony.Sms.READ, Telephony.Sms.THREAD_ID),
                Telephony.Sms.BODY + " LIKE ?", arrayOf("%" + query.trim() + "%"),
                Telephony.Sms.DATE + " DESC LIMIT " + limit,
            )?.use { c ->
                while (c.moveToNext()) {
                    out += c.getLong(6) to SmsMessage(
                        id = c.getLong(0), mms = false, address = c.getString(1) ?: "", body = c.getString(2) ?: "",
                        date = c.getLong(3), incoming = c.getInt(4) == Telephony.Sms.MESSAGE_TYPE_INBOX,
                        pending = false, failed = c.getInt(4) == Telephony.Sms.MESSAGE_TYPE_FAILED, read = c.getInt(5) != 0,
                    )
                }
            }
        } catch (_: Exception) { }
        return out
    }

    /** Marque la conversation comme lue (accepté par Android seulement si Calepin est l'appli SMS par défaut). */
    fun markRead(ctx: Context, threadId: Long) {
        if (!isDefault(ctx)) return
        try {
            val v = ContentValues().apply { put("read", 1); put("seen", 1) }
            ctx.contentResolver.update(Telephony.Sms.CONTENT_URI, v, "thread_id=? AND read=0", arrayOf(threadId.toString()))
        } catch (_: Exception) { }
    }

    /** Supprime un message ou une conversation (seulement si Calepin est l'appli SMS par défaut). */
    fun delete(ctx: Context, message: SmsMessage): Boolean {
        if (!isDefault(ctx)) return false
        return try {
            val uri = if (message.mms) Uri.parse("content://mms/" + message.id) else Uri.parse("content://sms/" + message.id)
            ctx.contentResolver.delete(uri, null, null) > 0
        } catch (_: Exception) { false }
    }

    fun deleteThread(ctx: Context, threadId: Long): Boolean {
        if (!isDefault(ctx)) return false
        return try {
            ctx.contentResolver.delete(Uri.parse("content://mms-sms/conversations/$threadId"), null, null) > 0
        } catch (_: Exception) { false }
    }

    // ------------------------------------------------------------------ Envoi

    const val ACTION_SENT = "fr.jeremy.calepin.SMS_SENT"

    /** Nombre de SMS nécessaires pour ce texte (affiché sous la zone d'écriture). */
    fun parts(ctx: Context, text: String): Int = try { manager(ctx).divideMessage(text).size } catch (_: Exception) { 1 }

    @Suppress("DEPRECATION")
    private fun manager(ctx: Context): SmsManager =
        if (Build.VERSION.SDK_INT >= 31) ctx.getSystemService(SmsManager::class.java) ?: SmsManager.getDefault() else SmsManager.getDefault()

    /** Envoie un SMS (découpé en plusieurs si long). Résultat annoncé par la diffusion [ACTION_SENT]. */
    fun send(ctx: Context, address: String, text: String): Boolean {
        if (!canSend(ctx) || address.isBlank() || text.isBlank()) return false
        return try {
            val sm = manager(ctx)
            val parts = sm.divideMessage(text)
            val sent = ArrayList<PendingIntent>()
            for (i in parts.indices) {
                sent += PendingIntent.getBroadcast(
                    ctx, (System.currentTimeMillis() % 100000).toInt() * 10 + i,
                    Intent(ACTION_SENT).setPackage(ctx.packageName).putExtra("last", i == parts.size - 1),
                    PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
                )
            }
            if (parts.size <= 1) sm.sendTextMessage(address, null, text, sent.firstOrNull(), null)
            else sm.sendMultipartTextMessage(address, null, parts, sent, null)
            true
        } catch (_: Exception) { false }
    }

    // ------------------------------------------------------------------ Contacts

    private val contactCache = HashMap<String, SmsContact?>()

    fun contact(ctx: Context, address: String): SmsContact? {
        if (address.isBlank() || address.none { it.isDigit() }) return null
        synchronized(contactCache) { if (contactCache.containsKey(address)) return contactCache[address] }
        val found = try {
            if (!granted(ctx, Manifest.permission.READ_CONTACTS)) null
            else ctx.contentResolver.query(
                Uri.withAppendedPath(ContactsContract.PhoneLookup.CONTENT_FILTER_URI, Uri.encode(address)),
                arrayOf(ContactsContract.PhoneLookup.DISPLAY_NAME, ContactsContract.PhoneLookup._ID, ContactsContract.PhoneLookup.LOOKUP_KEY, ContactsContract.PhoneLookup.PHOTO_THUMBNAIL_URI),
                null, null, null,
            )?.use { c ->
                if (c.moveToFirst()) SmsContact(c.getString(0) ?: address, c.getLong(1), c.getString(2), c.getString(3)?.let { Uri.parse(it) }) else null
            }
        } catch (_: Exception) { null }
        synchronized(contactCache) { contactCache[address] = found }
        return found
    }

    fun clearCache() = synchronized(contactCache) { contactCache.clear() }

    /** Contacts avec numéro dont le nom ou le numéro contient [q] (nouveau message). */
    fun findContacts(ctx: Context, q: String, limit: Int = 20): List<Pair<String, String>> {
        if (q.isBlank() || !granted(ctx, Manifest.permission.READ_CONTACTS)) return emptyList()
        val out = ArrayList<Pair<String, String>>()
        try {
            ctx.contentResolver.query(
                Uri.withAppendedPath(ContactsContract.CommonDataKinds.Phone.CONTENT_FILTER_URI, Uri.encode(q.trim())),
                arrayOf(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME, ContactsContract.CommonDataKinds.Phone.NUMBER),
                null, null, null,
            )?.use { c ->
                while (c.moveToNext() && out.size < limit) {
                    val n = c.getString(1) ?: continue
                    val name = c.getString(0) ?: n
                    if (out.none { it.second.filter { ch -> ch.isDigit() } == n.filter { ch -> ch.isDigit() } }) out += name to n
                }
            }
        } catch (_: Exception) { }
        return out
    }
}
