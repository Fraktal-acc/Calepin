package fr.jeremy.calepin.ui.market

import android.Manifest
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.OpenInNew
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.SmartToy
import androidx.compose.material.icons.filled.WarningAmber
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import fr.jeremy.calepin.i18n.I18n
import fr.jeremy.calepin.i18n.RawText
import fr.jeremy.calepin.i18n.Text
import fr.jeremy.calepin.market.Action
import fr.jeremy.calepin.market.CondType
import fr.jeremy.calepin.market.Condition
import fr.jeremy.calepin.market.Indicators
import fr.jeremy.calepin.market.Instrument
import fr.jeremy.calepin.market.Market
import fr.jeremy.calepin.market.MarketData
import fr.jeremy.calepin.market.Rule
import fr.jeremy.calepin.market.Series
import fr.jeremy.calepin.market.Strategy
import fr.jeremy.calepin.market.Timeframe
import fr.jeremy.calepin.ui.FitText
import fr.jeremy.calepin.ui.appBorder
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs

// ------------------------------------------------------------------ Outils

private val UP = Color(0xFF2E9E4F)
private val DOWN = Color(0xFFE0453A)

private fun num(x: Double, d: Int = 2): String = if (x.isNaN()) "–" else String.format(Locale.FRANCE, "%,.${d}f", x).replace(' ', ' ')

/** Nombre de décimales adapté au prix (devises : 4, petits prix : 4, sinon 2). */
private fun digits(price: Double) = when {
    abs(price) < 2 -> 4
    abs(price) < 20 -> 3
    else -> 2
}

private fun price(x: Double, cur: String): String = (num(x, digits(x)) + " " + curLabel(cur)).trim()
private fun curLabel(cur: String) = when (cur.uppercase()) { "EUR" -> "€"; "USD" -> "$"; "GBP" -> "£"; "JPY" -> "¥"; "CHF" -> "CHF"; else -> cur }
private fun pct(x: Double): String = if (x.isNaN()) "–" else (if (x >= 0) "+" else "") + num(x) + " %"
private fun euros(x: Double): String = num(x) + " €"
private fun signedEuros(x: Double): String = (if (x >= 0) "+" else "") + num(x) + " €"
private fun whenText(t: Long): String = if (t <= 0) "–" else SimpleDateFormat("dd/MM HH:mm", Locale.getDefault()).format(Date(t))

/** Cours des instruments affichés : gardés le temps de la visite, rafraîchis chaque minute. */
private object Quotes {
    val cache = mutableStateMapOf<String, Series>()
    val errors = mutableStateMapOf<String, String>()

    suspend fun load(symbol: String, force: Boolean = false) {
        val cur = cache[symbol]
        if (!force && cur != null) return
        try {
            // Déjà chargé : seulement les derniers jours (réponse légère)
            val s = withContext(Dispatchers.IO) {
                if (cur != null) MarketData.merge(cur, MarketData.latest(symbol, Timeframe.D1), Timeframe.D1)
                else MarketData.series(symbol, "1d", "3mo")
            }
            cache[symbol] = s
            errors.remove(symbol)
        } catch (e: Exception) {
            errors[symbol] = e.message ?: "erreur"
        }
    }
}

/** Ouvre l'appli XTB si elle est installée, sinon le site xStation. */
private fun openXtb(ctx: Context) {
    val pm = ctx.packageManager
    val launcher = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
    val found = runCatching {
        pm.queryIntentActivities(launcher, 0).firstOrNull { ri ->
            val label = ri.loadLabel(pm).toString().lowercase()
            val pkg = ri.activityInfo.packageName.lowercase()
            "xtb" in label || "xstation" in label || "xtb" in pkg || "xstation" in pkg
        }
    }.getOrNull()
    fr.jeremy.calepin.LockGuard.external()
    try {
        if (found != null) ctx.startActivity(pm.getLaunchIntentForPackage(found.activityInfo.packageName)!!.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        else ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://xstation5.xtb.com")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    } catch (_: Exception) {
        I18n.toast(ctx, "Impossible d'ouvrir XTB", Toast.LENGTH_SHORT).show()
    }
}

@Composable
private fun Card(content: @Composable () -> Unit) {
    Surface(shape = MaterialTheme.shapes.large, color = MaterialTheme.colorScheme.surfaceContainerLow, border = appBorder(), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) { content() }
    }
}

/** Petite courbe des cours. */
@Composable
private fun Sparkline(values: List<Double>, color: Color, modifier: Modifier) {
    Canvas(modifier) {
        val v = values.filter { !it.isNaN() }
        if (v.size < 2) return@Canvas
        val mn = v.min(); val mx = v.max()
        val span = (mx - mn).takeIf { it > 0 } ?: 1.0
        val path = Path()
        v.forEachIndexed { i, x ->
            val px = size.width * i / (v.size - 1)
            val py = size.height * (1 - ((x - mn) / span).toFloat())
            if (i == 0) path.moveTo(px, py) else path.lineTo(px, py)
        }
        drawPath(path, color, style = Stroke(width = 2.dp.toPx()))
    }
}

/** Graphique : cours, moyennes mobiles et bandes de Bollinger. */
@Composable
private fun PriceChart(closes: List<Double>, color: Color, modifier: Modifier, overlays: List<Pair<List<Double>, Color>> = emptyList()) {
    val grid = MaterialTheme.colorScheme.outlineVariant
    Canvas(modifier) {
        if (closes.size < 2) return@Canvas
        val all = (closes + overlays.flatMap { it.first }).filter { !it.isNaN() }
        val mn = all.min(); val mx = all.max()
        val span = (mx - mn).takeIf { it > 0 } ?: 1.0
        fun y(x: Double) = size.height * (1 - ((x - mn) / span).toFloat())
        fun xAt(i: Int) = size.width * i / (closes.size - 1)
        for (k in 0..3) {
            val gy = size.height * k / 3
            drawLine(grid, Offset(0f, gy), Offset(size.width, gy), 1f)
        }
        overlays.forEach { (line, c) ->
            val p = Path()
            var started = false
            line.forEachIndexed { i, x ->
                if (x.isNaN()) return@forEachIndexed
                if (!started) { p.moveTo(xAt(i), y(x)); started = true } else p.lineTo(xAt(i), y(x))
            }
            drawPath(p, c, style = Stroke(width = 1.5.dp.toPx()))
        }
        val path = Path()
        closes.forEachIndexed { i, x -> if (i == 0) path.moveTo(xAt(i), y(x)) else path.lineTo(xAt(i), y(x)) }
        drawPath(path, color, style = Stroke(width = 2.5.dp.toPx()))
    }
}

// ------------------------------------------------------------------ Écran principal

/**
 * Bourse : instruments suivis, fiche détaillée avec indicateurs, robot à règles (alertes et simulation),
 * portefeuille de simulation et journal des signaux.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MarketScreen(onClose: () -> Unit) {
    val ctx = LocalContext.current
    remember { Market.init(ctx); true }
    var tab by rememberSaveable { mutableStateOf("watch") }
    var detail by rememberSaveable { mutableStateOf<String?>(null) }
    var editing by remember { mutableStateOf<Rule?>(null) }

    editing?.let { r ->
        RuleEditor(r, onDone = { editing = null })
        return
    }
    detail?.let { sym ->
        InstrumentScreen(sym, onBack = { detail = null }, onRule = { editing = Rule("", "", listOf(sym), conditions = listOf(Condition(CondType.RSI_BELOW))); detail = null; tab = "robot" })
        return
    }
    BackHandler { onClose() }
    Scaffold(
        topBar = {
            TopAppBar(
                title = { FitText("Bourse") },
                navigationIcon = { IconButton(onClick = onClose) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Retour") } },
                actions = { IconButton(onClick = { openXtb(ctx) }) { Icon(Icons.AutoMirrored.Filled.OpenInNew, "Ouvrir XTB") } },
            )
        },
    ) { pad ->
        Column(Modifier.fillMaxSize().padding(pad)) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf("watch" to "Suivi", "robot" to "Robot", "sim" to "Simulation", "signals" to "Signaux").forEach { (k, label) ->
                    FilterChip(selected = tab == k, onClick = { tab = k }, label = { Text(label, maxLines = 1) })
                }
            }
            when (tab) {
                "robot" -> RobotTab(onEdit = { editing = it })
                "sim" -> SimulationTab(onOpen = { detail = it })
                "signals" -> SignalsTab(onOpen = { detail = it })
                else -> WatchTab(onOpen = { detail = it })
            }
        }
    }
}

// ------------------------------------------------------------------ Suivi

@Composable
private fun WatchTab(onOpen: (String) -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val watch by Market.watch.collectAsStateWithLifecycle()
    var query by rememberSaveable { mutableStateOf("") }
    var results by remember { mutableStateOf<List<Instrument>?>(null) }
    var searching by remember { mutableStateOf(false) }
    var refresh by remember { mutableIntStateOf(0) }
    // Tous les cours en même temps (pas l'un après l'autre), actualisés toutes les 15 secondes
    LaunchedEffect(watch, refresh) {
        var first = true
        while (true) {
            kotlinx.coroutines.coroutineScope {
                watch.forEach { w -> launch { Quotes.load(w.symbol, force = !first || refresh > 0) } }
            }
            first = false
            delay(15_000L)
        }
    }
    fun search() {
        val q = query.trim()
        if (q.isEmpty()) return
        scope.launch {
            searching = true
            results = runCatching { withContext(Dispatchers.IO) { MarketData.search(q) } }.getOrElse {
                I18n.toast(ctx, "Recherche impossible : vérifie la connexion", Toast.LENGTH_SHORT).show(); emptyList()
            }
            searching = false
        }
    }
    LazyColumn(
        Modifier.fillMaxSize().imePadding(),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 40.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        item {
            OutlinedTextField(
                query, { query = it; if (it.isBlank()) results = null },
                placeholder = { Text("Ajouter : nom ou symbole (Apple, CAC 40, bitcoin…)") },
                leadingIcon = { Icon(Icons.Filled.Search, null) },
                trailingIcon = { if (query.isNotEmpty()) IconButton(onClick = { query = ""; results = null }) { Icon(Icons.Filled.Close, "Effacer") } },
                singleLine = true,
                shape = RoundedCornerShape(28.dp),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                keyboardActions = KeyboardActions(onSearch = { search() }),
                modifier = Modifier.fillMaxWidth(),
            )
        }
        val res = results
        if (searching) item { Text("Recherche…", color = MaterialTheme.colorScheme.onSurfaceVariant) }
        if (res != null && !searching) {
            if (res.isEmpty()) item { Text("Aucun instrument trouvé.", color = MaterialTheme.colorScheme.onSurfaceVariant) }
            items(res) { i ->
                val inWatch = watch.any { it.symbol == i.symbol }
                Surface(
                    onClick = { if (!inWatch) Market.addWatch(ctx, i); query = ""; results = null },
                    shape = MaterialTheme.shapes.medium,
                    color = MaterialTheme.colorScheme.secondaryContainer,
                    modifier = Modifier.fillMaxWidth(),
                ) {
                    Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            RawText(i.name, style = MaterialTheme.typography.titleSmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            RawText(listOf(i.symbol, I18n.tr(i.type), i.exchange).filter { it.isNotBlank() }.joinToString(" · "), style = MaterialTheme.typography.bodySmall)
                        }
                        Icon(if (inWatch) Icons.Filled.Refresh else Icons.Filled.Add, null)
                    }
                }
            }
            item { HorizontalDivider() }
        }
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Mes instruments", style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.weight(1f))
                IconButton(onClick = { refresh++ }) { Icon(Icons.Filled.Refresh, "Actualiser") }
            }
        }
        if (watch.isEmpty()) item { Text("Cherche un instrument ci-dessus pour le suivre.", color = MaterialTheme.colorScheme.onSurfaceVariant) }
        items(watch, key = { it.symbol }) { i -> WatchRow(i, onOpen = { onOpen(i.symbol) }) }
        item {
            Text(
                "Cours fournis gratuitement par Yahoo Finance, parfois avec quelques minutes de retard. Les symboles peuvent différer de ceux d'XTB.",
                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}

@Composable
private fun WatchRow(i: Instrument, onOpen: () -> Unit) {
    val ctx = LocalContext.current
    val s = Quotes.cache[i.symbol]
    val err = Quotes.errors[i.symbol]
    var menu by remember { mutableStateOf(false) }
    Surface(onClick = onOpen, shape = MaterialTheme.shapes.large, color = MaterialTheme.colorScheme.surfaceContainerLow, border = appBorder(), modifier = Modifier.fillMaxWidth()) {
        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                RawText(i.name, style = MaterialTheme.typography.titleSmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
                RawText(i.symbol, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            if (s != null) {
                val col = if (s.change >= 0) UP else DOWN
                Sparkline(s.candles.takeLast(30).map { it.c }, col, Modifier.width(64.dp).height(28.dp))
                Spacer(Modifier.width(10.dp))
                Column(horizontalAlignment = Alignment.End) {
                    RawText(price(s.price, s.currency), style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                    RawText(pct(s.change), style = MaterialTheme.typography.labelMedium, color = col, fontWeight = FontWeight.SemiBold)
                }
            } else if (err != null) {
                Icon(Icons.Filled.WarningAmber, I18n.tr("Cours indisponible"), tint = MaterialTheme.colorScheme.error)
            } else {
                Text("…", color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Box {
                IconButton(onClick = { menu = true }) { Icon(Icons.Filled.KeyboardArrowDown, "Plus") }
                DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                    DropdownMenuItem(text = { Text("Monter") }, leadingIcon = { Icon(Icons.Filled.KeyboardArrowUp, null) }, onClick = { menu = false; Market.moveWatch(ctx, i.symbol, -1) })
                    DropdownMenuItem(text = { Text("Descendre") }, leadingIcon = { Icon(Icons.Filled.KeyboardArrowDown, null) }, onClick = { menu = false; Market.moveWatch(ctx, i.symbol, 1) })
                    DropdownMenuItem(text = { Text("Ne plus suivre") }, leadingIcon = { Icon(Icons.Filled.Delete, null) }, onClick = { menu = false; Market.removeWatch(ctx, i.symbol) })
                }
            }
        }
    }
}

// ------------------------------------------------------------------ Fiche d'un instrument


@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
private fun InstrumentScreen(symbol: String, onBack: () -> Unit, onRule: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var reload by remember { mutableIntStateOf(0) }
    // Indicateurs calculés sur un an de cours quotidiens
    // Cours du jour : historique chargé une fois (ou repris du graphique), puis seulement les derniers jours
    val daily by produceState<Series?>(ChartCache.get("$symbol|D1"), symbol, reload) {
        if (value == null || reload > 0) {
            value = runCatching { withContext(Dispatchers.IO) { MarketData.series(symbol, Timeframe.D1) } }.getOrNull() ?: value
        }
        while (true) {
            delay(10_000L)
            val cur = value
            value = if (cur == null) runCatching { withContext(Dispatchers.IO) { MarketData.series(symbol, Timeframe.D1) } }.getOrNull()
            else runCatching { withContext(Dispatchers.IO) { MarketData.merge(cur, MarketData.latest(symbol, Timeframe.D1), Timeframe.D1) } }.getOrNull() ?: cur
        }
    }
    val pf by Market.portfolio.collectAsStateWithLifecycle()
    var tradeDialog by remember { mutableStateOf(false) }
    BackHandler { onBack() }
    val s = daily
    Scaffold(
        topBar = {
            TopAppBar(
                title = { FitText(s?.name ?: symbol, translate = false) },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Retour") } },
                actions = {
                    IconButton(onClick = { reload++ }) { Icon(Icons.Filled.Refresh, "Actualiser") }
                    IconButton(onClick = { openXtb(ctx) }) { Icon(Icons.AutoMirrored.Filled.OpenInNew, "Ouvrir XTB") }
                },
            )
        },
    ) { pad ->
        Column(
            Modifier.fillMaxSize().padding(pad).verticalScroll(rememberScrollState()).padding(horizontal = 16.dp).padding(bottom = 40.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            if (s == null) {
                Text("Chargement des cours…", color = MaterialTheme.colorScheme.onSurfaceVariant)
                return@Column
            }
            val dayChange = daily?.change ?: s.change
            val col = if (dayChange >= 0) UP else DOWN
            Row(verticalAlignment = Alignment.Bottom) {
                RawText(price(s.price, s.currency), style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.width(10.dp))
                RawText(pct(dayChange) + " " + I18n.tr("aujourd'hui"), color = col, style = MaterialTheme.typography.titleSmall)
            }
            RawText(symbol + " · " + I18n.tr("mis à jour") + " " + whenText(s.time), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            ChartCard(symbol, reload)
            AnalysisCard(symbol, reload)
            NewsCard(symbol, Market.watch.value.firstOrNull { it.symbol == symbol }?.name ?: s.name, reload)
            daily?.let { d -> IndicatorsCard(d) }
            // Simulation et robot
            val held = pf.positions.firstOrNull { it.symbol == symbol }
            Card {
                Text("Simulation", style = MaterialTheme.typography.titleMedium)
                if (held != null) {
                    val fx = remember(held.currency) { mutableStateOf(0.0) }
                    LaunchedEffect(held.currency) { fx.value = withContext(Dispatchers.IO) { MarketData.fx(held.currency) } }
                    val valueEur = if (fx.value > 0) held.qty * s.price * fx.value else Double.NaN
                    val pnl = valueEur - held.costEur
                    RawText(I18n.tr("En portefeuille") + " : " + num(held.qty, 4) + " × " + price(held.avg, held.currency), style = MaterialTheme.typography.bodyMedium)
                    if (!pnl.isNaN()) RawText(I18n.tr("Plus ou moins-value") + " : " + signedEuros(pnl) + " (" + pct(pnl / held.costEur * 100) + ")", color = if (pnl >= 0) UP else DOWN)
                }
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (held == null) Button(onClick = { tradeDialog = true }) { Text("Acheter (simulation)") }
                    else OutlinedButton(onClick = {
                        scope.launch {
                            val msg = withContext(Dispatchers.IO) { Market.manualTrade(ctx, s, buy = false, amountEur = 0.0) }
                            I18n.toast(ctx, msg, Toast.LENGTH_SHORT).show()
                        }
                    }) { Text("Vendre (simulation)") }
                    OutlinedButton(onClick = onRule) { Icon(Icons.Filled.SmartToy, null, Modifier.size(18.dp)); Spacer(Modifier.width(6.dp)); Text("Créer une règle") }
                }
            }
        }
    }
    if (tradeDialog) {
        val ser = s
        var amount by remember { mutableStateOf("1000") }
        AlertDialog(
            onDismissRequest = { tradeDialog = false },
            title = { Text("Acheter en simulation") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    RawText(I18n.tr("Liquidités disponibles") + " : " + euros(pf.cash))
                    OutlinedTextField(amount, { amount = it }, label = { Text("Montant en euros") }, singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal))
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    tradeDialog = false
                    val a = amount.replace(',', '.').toDoubleOrNull() ?: 0.0
                    if (ser != null) scope.launch {
                        val msg = withContext(Dispatchers.IO) { Market.manualTrade(ctx, ser, buy = true, amountEur = a) }
                        I18n.toast(ctx, msg, Toast.LENGTH_SHORT).show()
                    }
                }) { Text("Acheter") }
            },
            dismissButton = { TextButton(onClick = { tradeDialog = false }) { Text("Annuler") } },
        )
    }
}

/** Indicateurs du jour avec une lecture simple. */
@Composable
private fun IndicatorsCard(d: Series) {
    val closes = d.candles.map { it.c }
    val n = closes.size
    val last = closes.lastOrNull() ?: return
    val rsi = Indicators.rsi(closes).lastOrNull() ?: Double.NaN
    val (macd, sig, _) = Indicators.macd(closes)
    val sto = Indicators.stochastic(d.candles).lastOrNull() ?: Double.NaN
    val ma50 = Indicators.sma(closes, 50).lastOrNull() ?: Double.NaN
    val ma200 = Indicators.sma(closes, 200).lastOrNull() ?: Double.NaN
    val (bl, _, bh) = Indicators.bollinger(closes)
    val atr = Indicators.atr(d.candles).lastOrNull() ?: Double.NaN
    fun change(back: Int) = if (n > back) (last - closes[n - 1 - back]) / closes[n - 1 - back] * 100 else Double.NaN
    Card {
        Text("Indicateurs (jour)", style = MaterialTheme.typography.titleMedium)
        @Composable
        fun line(label: String, value: String, reading: String = "", color: Color = Color.Unspecified) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(label, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
                Column(horizontalAlignment = Alignment.End) {
                    RawText(value, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold, color = color)
                    if (reading.isNotBlank()) Text(reading, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
        line("Variation 1 semaine", pct(change(5)), color = if (change(5) >= 0) UP else DOWN)
        line("Variation 1 mois", pct(change(21)), color = if (change(21) >= 0) UP else DOWN)
        line("Variation 1 an", pct(change(252)), color = if (change(252) >= 0) UP else DOWN)
        HorizontalDivider()
        line("RSI 14", num(rsi, 1), when { rsi.isNaN() -> ""; rsi >= 70 -> "Suracheté"; rsi <= 30 -> "Survendu"; else -> "Neutre" })
        val mLast = macd.lastOrNull() ?: Double.NaN
        val sLast = sig.lastOrNull() ?: Double.NaN
        line("MACD", num(mLast, 3) + " / " + num(sLast, 3), if (mLast.isNaN() || sLast.isNaN()) "" else if (mLast > sLast) "Au-dessus du signal (haussier)" else "Sous le signal (baissier)")
        line("Stochastique 14", num(sto, 1), when { sto.isNaN() -> ""; sto >= 80 -> "Suracheté"; sto <= 20 -> "Survendu"; else -> "Neutre" })
        line("Moyenne mobile 50", price(ma50, d.currency), if (ma50.isNaN()) "" else if (last > ma50) "Cours au-dessus" else "Cours en dessous")
        line("Moyenne mobile 200", price(ma200, d.currency), when {
            ma200.isNaN() -> ""
            !ma50.isNaN() && ma50 > ma200 -> "Tendance de fond haussière (MM 50 > MM 200)"
            !ma50.isNaN() -> "Tendance de fond baissière (MM 50 < MM 200)"
            else -> ""
        })
        val lo = bl.lastOrNull() ?: Double.NaN
        val hi = bh.lastOrNull() ?: Double.NaN
        line("Bollinger 20", num(lo, digits(last)) + " – " + num(hi, digits(last)), when { lo.isNaN() -> ""; last > hi -> "Au-dessus de la bande haute"; last < lo -> "Sous la bande basse"; else -> "Dans les bandes" })
        line("Volatilité (ATR 14)", price(atr, d.currency), if (atr.isNaN()) "" else I18n.tr("soit") + " " + pct(atr / last * 100).removePrefix("+") + " " + I18n.tr("par jour"))
        Text("Ces indicateurs décrivent le passé ; ils ne garantissent rien sur la suite.", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

// ------------------------------------------------------------------ Robot

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun RobotTab(onEdit: (Rule) -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val on by Market.robotOn.collectAsStateWithLifecycle()
    val every by Market.every.collectAsStateWithLifecycle()
    val rules by Market.rules.collectAsStateWithLifecycle()
    val last by Market.lastCheck.collectAsStateWithLifecycle()
    val lastError by Market.lastError.collectAsStateWithLifecycle()
    var checking by remember { mutableStateOf(false) }
    var templates by remember { mutableStateOf(false) }
    val notifPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 40.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        item {
            Surface(shape = MaterialTheme.shapes.large, color = MaterialTheme.colorScheme.tertiaryContainer, modifier = Modifier.fillMaxWidth()) {
                Row(Modifier.padding(12.dp)) {
                    Icon(Icons.Filled.WarningAmber, null, tint = MaterialTheme.colorScheme.onTertiaryContainer)
                    Spacer(Modifier.width(10.dp))
                    Text(
                        "Le robot n'envoie aucun ordre réel : XTB ne permet plus aux applis de se connecter à un compte. Il te prévient quand tes règles se déclenchent et achète ou vend en simulation. C'est à toi de passer l'ordre sur XTB si tu le décides.",
                        style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onTertiaryContainer,
                    )
                }
            }
        }
        item {
            Card {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Robot actif", style = MaterialTheme.typography.titleMedium)
                        Text("Vérifie tes règles en arrière-plan, même appli fermée", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    Switch(checked = on, onCheckedChange = {
                        Market.setRobot(ctx, it)
                        if (it && Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
                            fr.jeremy.calepin.LockGuard.external()
                            notifPerm.launch(Manifest.permission.POST_NOTIFICATIONS)
                        }
                    })
                }
                Text("Vérification toutes les :", style = MaterialTheme.typography.bodyMedium)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf(5 to "5 min", 15 to "15 min", 30 to "30 min", 60 to "1 h", 240 to "4 h", 1440 to "1 jour").forEach { (m, label) ->
                        FilterChip(selected = every == m, onClick = { Market.setEvery(ctx, m) }, label = { Text(label) })
                    }
                }
                Text("Android peut décaler un peu les vérifications pour économiser la batterie.", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    RawText(I18n.tr("Dernière vérification") + " : " + whenText(last), style = MaterialTheme.typography.bodySmall, modifier = Modifier.weight(1f))
                    OutlinedButton(enabled = !checking, onClick = {
                        checking = true
                        scope.launch {
                            val n = withContext(Dispatchers.IO) { runCatching { Market.runChecks(ctx) }.getOrDefault(0) }
                            checking = false
                            I18n.toast(ctx, if (n == 0) I18n.tr("Aucun nouveau signal") else I18n.tr("Nouveaux signaux") + " : $n", Toast.LENGTH_SHORT).show()
                        }
                    }) { Text(if (checking) "Vérification…" else "Vérifier maintenant") }
                }
                if (lastError.isNotBlank()) RawText(lastError, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.error)
            }
        }
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Mes règles", style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.weight(1f))
                Button(onClick = { templates = true }) { Icon(Icons.Filled.Add, null); Spacer(Modifier.width(4.dp)); Text("Nouvelle règle") }
            }
        }
        if (rules.isEmpty()) item {
            Text(
                "Une règle dit au robot quoi étudier (un ou plusieurs instruments), avec quels indicateurs, et quoi faire quand les conditions sont réunies : acheter, vendre ou seulement te prévenir.",
                style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
        items(rules, key = { it.id }) { r ->
            Surface(onClick = { onEdit(r) }, shape = MaterialTheme.shapes.large, color = MaterialTheme.colorScheme.surfaceContainerLow, border = appBorder(), modifier = Modifier.fillMaxWidth()) {
                Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        RawText(r.name.ifBlank { I18n.tr("Sans nom") }, style = MaterialTheme.typography.titleSmall)
                        RawText(
                            I18n.tr(r.action.label) + " · " + I18n.tr(r.timeframe.label) + " · " + (if (r.simulate && r.action != Action.ALERT) I18n.tr("simulation") else I18n.tr("alerte")),
                            style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary,
                        )
                        RawText(r.symbols.joinToString(", ").ifBlank { I18n.tr("Aucun instrument") }, style = MaterialTheme.typography.bodySmall, maxLines = 2, overflow = TextOverflow.Ellipsis)
                        RawText(
                            r.conditions.joinToString(if (r.all) " " + I18n.tr("ET") + " " else " " + I18n.tr("OU") + " ") { Strategy.describe(it) },
                            style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 3, overflow = TextOverflow.Ellipsis,
                        )
                    }
                    Switch(checked = r.enabled, onCheckedChange = { Market.setRuleEnabled(ctx, r.id, it) })
                }
            }
        }
    }
    if (templates) {
        AlertDialog(
            onDismissRequest = { templates = false },
            title = { Text("Nouvelle règle") },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState())) {
                    Text("Pars d'un modèle, tu pourras tout modifier :", style = MaterialTheme.typography.bodySmall)
                    (listOf("Règle vide" to Rule("", "", emptyList(), conditions = listOf(Condition(CondType.RSI_BELOW)))) + Strategy.templates()).forEach { (label, r) ->
                        Text(
                            label,
                            style = MaterialTheme.typography.bodyLarge,
                            modifier = Modifier.fillMaxWidth().clickable {
                                templates = false
                                onEdit(r.copy(name = I18n.tr(r.name)))
                            }.padding(vertical = 12.dp),
                        )
                    }
                }
            },
            confirmButton = { TextButton(onClick = { templates = false }) { Text("Annuler") } },
        )
    }
}

// ------------------------------------------------------------------ Éditeur de règle

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
private fun RuleEditor(initial: Rule, onDone: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val watch by Market.watch.collectAsStateWithLifecycle()
    var name by remember { mutableStateOf(initial.name) }
    var symbols by remember { mutableStateOf(initial.symbols) }
    var tf by remember { mutableStateOf(initial.timeframe) }
    var action by remember { mutableStateOf(initial.action) }
    var all by remember { mutableStateOf(initial.all) }
    var conds by remember { mutableStateOf(initial.conditions) }
    var simulate by remember { mutableStateOf(initial.simulate) }
    var smart by remember { mutableStateOf(initial.smartExit) }
    fun plain(x: Double) = if (x == kotlin.math.floor(x)) x.toLong().toString() else x.toString().replace('.', ',')
    var amount by remember { mutableStateOf(plain(initial.amount)) }
    var sl by remember { mutableStateOf(plain(initial.stopLoss)) }
    var tp by remember { mutableStateOf(plain(initial.takeProfit)) }
    var addMenu by remember { mutableStateOf(false) }
    var confirmDelete by remember { mutableStateOf(false) }
    var testing by remember { mutableStateOf<List<Market.Check>?>(null) }
    var testRunning by remember { mutableStateOf(false) }
    fun d(s: String, def: Double) = s.replace(',', '.').filter { it.isDigit() || it == '.' || it == '-' }.toDoubleOrNull() ?: def
    fun build() = initial.copy(
        name = name.trim().ifBlank { I18n.tr("Règle") },
        symbols = symbols, timeframe = tf, action = action, all = all, conditions = conds,
        simulate = simulate, smartExit = smart, amount = d(amount, 1000.0), stopLoss = d(sl, 0.0), takeProfit = d(tp, 0.0),
    )
    BackHandler { onDone() }
    Scaffold(
        topBar = {
            TopAppBar(
                title = { FitText(if (initial.id.isBlank()) "Nouvelle règle" else "Modifier la règle") },
                navigationIcon = { IconButton(onClick = onDone) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Retour") } },
                actions = {
                    if (initial.id.isNotBlank()) IconButton(onClick = { confirmDelete = true }) { Icon(Icons.Filled.Delete, "Supprimer") }
                },
            )
        },
    ) { pad ->
        Column(
            Modifier.fillMaxSize().padding(pad).imePadding().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp).padding(bottom = 40.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            OutlinedTextField(name, { name = it }, label = { Text("Nom de la règle") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            Card {
                Text("Instruments étudiés", style = MaterialTheme.typography.titleSmall)
                val choices = (watch.map { it.symbol to it.name } + symbols.filter { s -> watch.none { it.symbol == s } }.map { it to it })
                if (choices.isEmpty()) Text("Ajoute d'abord des instruments dans l'onglet Suivi.", style = MaterialTheme.typography.bodySmall)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    choices.forEach { (sym, nm) ->
                        FilterChip(
                            selected = sym in symbols,
                            onClick = { symbols = if (sym in symbols) symbols - sym else symbols + sym },
                            label = { RawText(nm, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                        )
                    }
                }
            }
            Card {
                Text("Durée des bougies étudiées", style = MaterialTheme.typography.titleSmall)
                TimeframePicker(tf) { tf = it }
                RawText(I18n.tr("Choisi") + " : " + I18n.tr(tf.label), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                val every by Market.every.collectAsStateWithLifecycle()
                val tfMinutes = when (tf) { Timeframe.M5 -> 5; Timeframe.M15 -> 15; Timeframe.M30 -> 30; Timeframe.H1 -> 60; Timeframe.H4 -> 240; else -> Int.MAX_VALUE }
                if (every > tfMinutes) Text(
                    "Le robot vérifie moins souvent que la durée des bougies : règle « Vérification toutes les » de l'onglet Robot sur cette durée ou moins pour ne rien manquer.",
                    style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.error,
                )
                Text("Action quand les conditions sont réunies", style = MaterialTheme.typography.titleSmall)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Action.entries.forEach { a -> FilterChip(selected = action == a, onClick = { action = a }, label = { Text(a.label) }) }
                }
            }
            Card {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Conditions", style = MaterialTheme.typography.titleSmall, modifier = Modifier.weight(1f))
                    FilterChip(selected = all, onClick = { all = true }, label = { Text("Toutes") })
                    Spacer(Modifier.width(6.dp))
                    FilterChip(selected = !all, onClick = { all = false }, label = { Text("Une seule") })
                }
                conds.forEachIndexed { idx, c ->
                    Surface(shape = MaterialTheme.shapes.medium, color = MaterialTheme.colorScheme.surfaceContainerHigh, modifier = Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(c.type.label, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                                IconButton(onClick = { conds = conds.filterIndexed { k, _ -> k != idx } }) { Icon(Icons.Filled.Close, "Retirer") }
                            }
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                c.type.pa?.let { label ->
                                    NumField(label, c.a, Modifier.weight(1f)) { v -> conds = conds.mapIndexed { k, x -> if (k == idx) x.copy(a = v) else x } }
                                }
                                c.type.pb?.let { label ->
                                    NumField(label, c.b, Modifier.weight(1f)) { v -> conds = conds.mapIndexed { k, x -> if (k == idx) x.copy(b = v) else x } }
                                }
                            }
                        }
                    }
                }
                Box {
                    OutlinedButton(onClick = { addMenu = true }) { Icon(Icons.Filled.Add, null); Spacer(Modifier.width(4.dp)); Text("Ajouter une condition") }
                    DropdownMenu(expanded = addMenu, onDismissRequest = { addMenu = false }, modifier = Modifier.heightIn(max = 420.dp)) {
                        CondType.entries.forEach { t ->
                            DropdownMenuItem(text = { Text(t.label) }, onClick = { addMenu = false; conds = conds + Condition(t) })
                        }
                    }
                }
                Text("Le signal part quand les conditions deviennent vraies, pas à chaque vérification tant qu'elles le restent.", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            if (action != Action.ALERT) Card {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Jouer en simulation", style = MaterialTheme.typography.titleSmall)
                        Text("Le robot achète ou vend dans le portefeuille fictif", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    Switch(checked = simulate, onCheckedChange = { simulate = it })
                }
                if (simulate && action == Action.BUY) {
                    OutlinedTextField(amount, { amount = it }, label = { Text("Montant de chaque achat (€)") }, singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), modifier = Modifier.fillMaxWidth())
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("Stop et objectif calculés par l'analyse", style = MaterialTheme.typography.bodyMedium)
                            Text("Placés sous le support le plus proche et sur la résistance ou le niveau de Fibonacci suivant, selon la volatilité (ATR)", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Switch(checked = smart, onCheckedChange = { smart = it })
                    }
                    if (!smart) Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(sl, { sl = it }, label = { Text("Stop de perte (%)") }, singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), modifier = Modifier.weight(1f))
                        OutlinedTextField(tp, { tp = it }, label = { Text("Objectif de gain (%)") }, singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), modifier = Modifier.weight(1f))
                    }
                    Text("0 = pas de stop ou pas d'objectif. La position est revendue automatiquement quand le cours les atteint.", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(enabled = !testRunning && symbols.isNotEmpty() && conds.isNotEmpty(), onClick = {
                    testRunning = true
                    val r = build()
                    scope.launch {
                        testing = withContext(Dispatchers.IO) { Market.test(r) }
                        testRunning = false
                    }
                }) { Text(if (testRunning) "Test…" else "Tester maintenant") }
                Button(enabled = symbols.isNotEmpty() && conds.isNotEmpty(), onClick = {
                    Market.saveRule(ctx, build())
                    onDone()
                }, modifier = Modifier.weight(1f)) { Text("Enregistrer") }
            }
        }
    }
    testing?.let { checks ->
        AlertDialog(
            onDismissRequest = { testing = null },
            title = { Text("Résultat du test") },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    checks.forEach { c ->
                        Column {
                            RawText(
                                c.symbol + " — " + when {
                                    c.error.isNotBlank() -> I18n.tr("erreur") + " : " + c.error
                                    c.ok -> I18n.tr("conditions réunies")
                                    else -> I18n.tr("conditions non réunies")
                                },
                                fontWeight = FontWeight.SemiBold,
                                color = if (c.ok) UP else MaterialTheme.colorScheme.onSurface,
                            )
                            if (c.price > 0) RawText(price(c.price, c.currency), style = MaterialTheme.typography.bodySmall)
                            c.results.forEachIndexed { k, r ->
                                RawText(
                                    (if (r.ok) "✓ " else "✗ ") + Strategy.describe(conds.getOrNull(k) ?: return@forEachIndexed) + " : " + r.detail,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = if (r.ok) UP else MaterialTheme.colorScheme.onSurfaceVariant,
                                )
                            }
                        }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { testing = null }) { Text("OK") } },
        )
    }
    if (confirmDelete) {
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            title = { Text("Supprimer cette règle ?") },
            confirmButton = { TextButton(onClick = { confirmDelete = false; Market.deleteRule(ctx, initial.id); onDone() }) { Text("Supprimer") } },
            dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text("Annuler") } },
        )
    }
}

@Composable
private fun NumField(label: String, value: Double, modifier: Modifier, onChange: (Double) -> Unit) {
    var text by remember(value) { mutableStateOf(if (value == kotlin.math.floor(value)) value.toLong().toString() else value.toString().replace('.', ',')) }
    OutlinedTextField(
        text,
        { t -> text = t; t.replace(',', '.').toDoubleOrNull()?.let(onChange) },
        label = { Text(label) },
        singleLine = true,
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
        modifier = modifier,
    )
}

// ------------------------------------------------------------------ Simulation

@Composable
private fun SimulationTab(onOpen: (String) -> Unit) {
    val ctx = LocalContext.current
    val pf by Market.portfolio.collectAsStateWithLifecycle()
    var reset by remember { mutableStateOf(false) }
    // Valeur actuelle de chaque position, en euros
    val values by produceState<Map<String, Double>>(emptyMap(), pf.positions) {
        while (true) {
            value = withContext(Dispatchers.IO) {
                pf.positions.associate { p ->
                    p.symbol to runCatching {
                        val s = MarketData.series(p.symbol, "1d", "5d")
                        val fx = MarketData.fx(s.currency)
                        if (fx > 0) s.price * fx else Double.NaN
                    }.getOrDefault(Double.NaN)
                }.filterValues { !it.isNaN() }
            }
            delay(60_000L)
        }
    }
    val total = pf.value(values)
    val perf = if (pf.start > 0) (total - pf.start) / pf.start * 100 else 0.0
    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 40.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        item {
            Card {
                Text("Portefeuille fictif", style = MaterialTheme.typography.titleMedium)
                RawText(euros(total), style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.SemiBold)
                RawText(pct(perf) + " " + I18n.tr("depuis le départ") + " (" + euros(pf.start) + ")", color = if (perf >= 0) UP else DOWN)
                RawText(I18n.tr("Liquidités") + " : " + euros(pf.cash), style = MaterialTheme.typography.bodyMedium)
                RawText(I18n.tr("Gains et pertes réalisés") + " : " + signedEuros(pf.realized), style = MaterialTheme.typography.bodyMedium, color = if (pf.realized >= 0) UP else DOWN)
                val closed = pf.trades.filter { !it.buy }
                if (closed.isNotEmpty()) {
                    val wins = closed.count { it.pnl > 0 }
                    RawText(I18n.tr("Ventes gagnantes") + " : $wins / ${closed.size} (" + num(wins * 100.0 / closed.size, 0) + " %)", style = MaterialTheme.typography.bodySmall)
                }
                TextButton(onClick = { reset = true }) { Text("Recommencer à zéro") }
            }
        }
        item { Text("Positions", style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.onSurfaceVariant) }
        if (pf.positions.isEmpty()) item { Text("Aucune position. Le robot (ou toi, depuis la fiche d'un instrument) en ouvrira ici.", color = MaterialTheme.colorScheme.onSurfaceVariant) }
        items(pf.positions, key = { "p" + it.symbol }) { p ->
            val cur = values[p.symbol]
            val v = cur?.let { it * p.qty }
            val pnl = v?.minus(p.costEur)
            Surface(onClick = { onOpen(p.symbol) }, shape = MaterialTheme.shapes.large, color = MaterialTheme.colorScheme.surfaceContainerLow, border = appBorder(), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    Row {
                        RawText(p.name, style = MaterialTheme.typography.titleSmall, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
                        if (pnl != null) RawText(signedEuros(pnl) + " (" + pct(pnl / p.costEur * 100) + ")", color = if (pnl >= 0) UP else DOWN, fontWeight = FontWeight.SemiBold)
                    }
                    RawText(num(p.qty, 4) + " × " + price(p.avg, p.currency) + " · " + I18n.tr("investi") + " " + euros(p.costEur), style = MaterialTheme.typography.bodySmall)
                    if (p.stop > 0 || p.take > 0) RawText(
                        listOfNotNull(
                            p.stop.takeIf { it > 0 }?.let { I18n.tr("stop") + " " + price(it, p.currency) },
                            p.take.takeIf { it > 0 }?.let { I18n.tr("objectif") + " " + price(it, p.currency) },
                        ).joinToString(" · "),
                        style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
        }
        if (pf.trades.isNotEmpty()) {
            item { Text("Historique des opérations", style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.onSurfaceVariant) }
            items(pf.trades.take(100)) { t ->
                Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(10.dp).background(if (t.buy) UP else DOWN, RoundedCornerShape(3.dp)))
                    Spacer(Modifier.width(10.dp))
                    Column(Modifier.weight(1f)) {
                        RawText((if (t.buy) I18n.tr("Achat") else I18n.tr("Vente")) + " · " + t.name, style = MaterialTheme.typography.bodyMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        RawText(whenText(t.t) + " · " + num(t.qty, 4) + " × " + price(t.price, t.currency) + " · " + I18n.tr(t.reason), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    RawText(if (t.buy) euros(t.eur) else signedEuros(t.pnl), color = if (t.buy) MaterialTheme.colorScheme.onSurface else if (t.pnl >= 0) UP else DOWN, style = MaterialTheme.typography.bodySmall)
                }
            }
        }
    }
    if (reset) {
        var capital by remember { mutableStateOf("10000") }
        AlertDialog(
            onDismissRequest = { reset = false },
            title = { Text("Recommencer la simulation ?") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Les positions et l'historique fictifs sont effacés.")
                    OutlinedTextField(capital, { capital = it }, label = { Text("Capital de départ (€)") }, singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal))
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    Market.resetPortfolio(ctx, capital.replace(',', '.').replace(" ", "").toDoubleOrNull()?.takeIf { it > 0 } ?: 10_000.0)
                    reset = false
                }) { Text("Recommencer") }
            },
            dismissButton = { TextButton(onClick = { reset = false }) { Text("Annuler") } },
        )
    }
}

// ------------------------------------------------------------------ Signaux

@Composable
private fun SignalsTab(onOpen: (String) -> Unit) {
    val ctx = LocalContext.current
    val signals by Market.signals.collectAsStateWithLifecycle()
    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 40.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Signaux du robot", style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.weight(1f))
                if (signals.isNotEmpty()) TextButton(onClick = { Market.clearSignals(ctx) }) { Text("Effacer") }
            }
        }
        if (signals.isEmpty()) item { Text("Aucun signal pour le moment.", color = MaterialTheme.colorScheme.onSurfaceVariant) }
        items(signals) { s ->
            val col = when (s.action) { Action.BUY -> UP; Action.SELL -> DOWN; Action.ALERT -> MaterialTheme.colorScheme.primary }
            Surface(onClick = { onOpen(s.symbol) }, shape = MaterialTheme.shapes.large, color = MaterialTheme.colorScheme.surfaceContainerLow, border = appBorder(), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        RawText(
                            when (s.action) { Action.BUY -> I18n.tr("Achat"); Action.SELL -> I18n.tr("Vente"); Action.ALERT -> I18n.tr("Alerte") } + " · " + s.name,
                            style = MaterialTheme.typography.titleSmall, color = col, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f),
                        )
                        RawText(whenText(s.t), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    RawText(price(s.price, s.currency) + " · " + I18n.tr(s.ruleName), style = MaterialTheme.typography.bodySmall)
                    if (s.detail.isNotBlank()) RawText(s.detail, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    if (s.done.isNotBlank()) RawText(I18n.tr(s.done), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                }
            }
        }
    }
}
