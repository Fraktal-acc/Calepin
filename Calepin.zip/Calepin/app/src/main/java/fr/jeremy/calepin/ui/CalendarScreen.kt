package fr.jeremy.calepin.ui

import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import android.net.Uri
import androidx.compose.material.icons.filled.UploadFile
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Work
import androidx.compose.ui.platform.LocalContext
import fr.jeremy.calepin.LockGuard
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Alarm
import androidx.compose.material.icons.filled.ChevronLeft
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Today
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import fr.jeremy.calepin.i18n.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import fr.jeremy.calepin.NotesViewModel
import fr.jeremy.calepin.data.Event
import java.time.Instant
import java.time.LocalDate
import java.time.YearMonth
import java.time.ZoneId
import java.time.format.TextStyle
import java.util.Locale

private val zone: ZoneId get() = ZoneId.systemDefault()
private fun Long.toDate(): LocalDate = Instant.ofEpochMilli(this).atZone(zone).toLocalDate()
private fun hhmm(t: Long): String = Instant.ofEpochMilli(t).atZone(zone).toLocalTime().let { "%02d:%02d".format(it.hour, it.minute) }

/** Agenda : mois en grille, rendez-vous Calepin et dates repérées automatiquement dans les notes. */
@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun CalendarScreen(vm: NotesViewModel, onOpenNote: (Long) -> Unit, onClose: () -> Unit, initialEvent: Event? = null, onWorkHours: () -> Unit = {}) {
    val events by vm.events.collectAsStateWithLifecycle()
    val defaultRingtone by vm.settings.ringtone.collectAsStateWithLifecycle()
    // Recalculé quand les notes changent (les rendez-vous suivent le même rafraîchissement)
    val notesVersion by vm.results.collectAsStateWithLifecycle()
    val detected = remember(notesVersion, events) { vm.detectedDates() }
    val today = LocalDate.now()
    // Ouvert depuis la recherche : le jour du rendez-vous et sa fiche
    val startDay = initialEvent?.let { java.time.Instant.ofEpochMilli(it.start).atZone(java.time.ZoneId.systemDefault()).toLocalDate() } ?: today
    var month by remember { mutableStateOf(YearMonth.from(startDay)) }
    var day by remember { mutableStateOf(startDay) }
    var editing by remember { mutableStateOf<Event?>(initialEvent) }
    var importing by remember { mutableStateOf<Pair<Uri, String>?>(null) }
    val ctx = LocalContext.current

    BackHandler { onClose() }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) importing = uri to (ctx.contentResolver.getType(uri) ?: "application/pdf")
    }

    // Une période apparaît sur chacun de ses jours (au plus 366)
    fun days(start: Long, end: Long?, allDay: Boolean): List<LocalDate> {
        val a = start.toDate()
        val b = end?.takeIf { it > start && (allDay || it - start >= 86_400_000L) }?.toDate() ?: return listOf(a)
        return generateSequence(a) { it.plusDays(1) }.takeWhile { !it.isAfter(b) }.take(366).toList()
    }
    val eventsByDay = remember(events) {
        events.flatMap { e -> days(e.start, e.end.takeIf { it > 0 }, e.allDay).map { it to e } }
            .groupBy({ it.first }, { it.second })
    }
    val detectedByDay = remember(detected) {
        detected.flatMap { d -> days(d.time, d.end, !d.hasTime).map { it to d } }.groupBy({ it.first }, { it.second })
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { fr.jeremy.calepin.ui.FitText("Agenda") },
                navigationIcon = { IconButton(onClick = onClose) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Retour") } },
                actions = {
                    ReadDayButton()
                    IconButton(onClick = onWorkHours) { Icon(Icons.Filled.Schedule, "Heures de travail") }
                    IconButton(onClick = {
                        LockGuard.external()
                        picker.launch(arrayOf("application/pdf", "image/*"))
                    }) { Icon(Icons.Filled.UploadFile, "Importer un planning (PDF ou photo)") }
                    TextButton(onClick = { month = YearMonth.from(today); day = today }) { Text("Aujourd'hui") }
                },
            )
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = {
                    val start = day.atTime(9, 0).atZone(zone).toInstant().toEpochMilli()
                    editing = Event(title = "", start = start, remindMinutes = 15)
                },
                icon = { Icon(Icons.Filled.Add, null) },
                text = { Text("Rendez-vous") },
            )
        },
    ) { pad ->
        Column(
            Modifier
                .fillMaxSize()
                .padding(pad)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 12.dp)
                .padding(bottom = 96.dp),
        ) {
            // En-tête du mois
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = { month = month.minusMonths(1) }) { Icon(Icons.Filled.ChevronLeft, "Mois précédent") }
                Text(
                    month.month.getDisplayName(TextStyle.FULL_STANDALONE, fr.jeremy.calepin.i18n.I18n.locale).replaceFirstChar { it.uppercase() } + " " + month.year,
                    style = MaterialTheme.typography.titleLarge,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.weight(1f),
                )
                IconButton(onClick = { month = month.plusMonths(1) }) { Icon(Icons.Filled.ChevronRight, "Mois suivant") }
            }
            Row(Modifier.fillMaxWidth()) {
                java.time.DayOfWeek.values().map { it.getDisplayName(TextStyle.NARROW, fr.jeremy.calepin.i18n.I18n.locale).uppercase() }.forEach {
                    Text(
                        it, Modifier.weight(1f), textAlign = TextAlign.Center,
                        style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
            Spacer(Modifier.height(4.dp))
            val first = month.atDay(1)
            val offset = first.dayOfWeek.value - 1 // lundi = 0
            val cells = offset + month.lengthOfMonth()
            val rows = (cells + 6) / 7
            // Cases plus hautes quand le texte est agrandi, pour que le numéro du jour tienne
            val cellRatio = 1f / textGrowth()
            // Apparence de l'agenda : quadrillage, bulles colorées selon ce qui est prévu (réglables dans Apparence)
            val ap = remember { Appearance.get(ctx) }
            val gridPref by ap.agendaGrid.collectAsStateWithLifecycle()
            val bubbles by ap.agendaBubbles.collectAsStateWithLifecycle()
            val kindColors by ap.agendaColors.collectAsStateWithLifecycle()
            val cs = MaterialTheme.colorScheme
            fun kindColor(k: String, def: Color) = ColorPref.color(kindColors[k] ?: ColorPref.AUTO) ?: def
            val cEvent = kindColor("event", cs.primary)
            val cWork = kindColor("work", cs.tertiary)
            val cAbsence = kindColor("absence", Color(0xFF8E8E93))
            val cNote = kindColor("note", cs.secondary)
            val gridColor: Color? = when (gridPref) {
                ColorPref.AUTO -> cs.outlineVariant
                ColorPref.NONE -> null
                else -> Color(gridPref.toInt())
            }
            Column(
                Modifier
                    .fillMaxWidth()
                    .drawBehind {
                        gridColor?.let { g ->
                            val w = 1.dp.toPx()
                            drawLine(g, androidx.compose.ui.geometry.Offset(0f, w / 2), androidx.compose.ui.geometry.Offset(size.width, w / 2), w)
                            drawLine(g, androidx.compose.ui.geometry.Offset(w / 2, 0f), androidx.compose.ui.geometry.Offset(w / 2, size.height), w)
                        }
                    },
            ) {
                for (r in 0 until rows) {
                    Row(Modifier.fillMaxWidth()) {
                        for (c in 0 until 7) {
                            val index = r * 7 + c - offset
                            Box(
                                Modifier
                                    .weight(1f)
                                    .aspectRatio(cellRatio)
                                    .drawBehind {
                                        // Quadrillage : trait à droite et en bas de chaque case
                                        gridColor?.let { g ->
                                            val w = 1.dp.toPx()
                                            drawLine(g, androidx.compose.ui.geometry.Offset(size.width - w / 2, 0f), androidx.compose.ui.geometry.Offset(size.width - w / 2, size.height), w)
                                            drawLine(g, androidx.compose.ui.geometry.Offset(0f, size.height - w / 2), androidx.compose.ui.geometry.Offset(size.width, size.height - w / 2), w)
                                        }
                                    }
                                    .padding(4.dp),
                            ) {
                                if (index in 0 until month.lengthOfMonth()) {
                                    val d = month.atDay(index + 1)
                                    val isSel = d == day
                                    val isToday = d == today
                                    val evs = eventsByDay[d].orEmpty()
                                    val hasDetected = detectedByDay[d].orEmpty().isNotEmpty()
                                    // Couleurs du jour : travail (planning), absence, rendez-vous, dates des notes
                                    val kinds = buildList {
                                        if (evs.any { it.isWork }) add(cWork)
                                        if (evs.any { it.isAbsence }) add(cAbsence)
                                        if (evs.any { !it.isWork && !it.isAbsence }) add(cEvent)
                                        if (hasDetected) add(cNote)
                                    }
                                    val bubbleShape = RoundedCornerShape(10.dp)
                                    val colored = bubbles && kinds.isNotEmpty()
                                    val brush: Brush = when {
                                        !colored -> SolidColor(cs.surfaceContainerLow)
                                        kinds.size == 1 -> SolidColor(kinds[0])
                                        else -> Brush.horizontalGradient(
                                            *kinds.flatMapIndexed { i, k ->
                                                listOf(i.toFloat() / kinds.size to k, ((i + 1).toFloat() / kinds.size - 0.001f) to k)
                                            }.toTypedArray(),
                                        )
                                    }
                                    val ink = if (colored) {
                                        if (kinds.map { it.luminance() }.average() > 0.5) Color(0xFF1B1C1E) else Color.White
                                    } else cs.onSurface
                                    Column(
                                        Modifier
                                            .fillMaxSize()
                                            .clip(bubbleShape)
                                            .background(brush)
                                            .then(
                                                when {
                                                    isSel -> Modifier.border(3.dp, cs.primary, bubbleShape)
                                                    isToday -> Modifier.border(1.5.dp, cs.onSurface.copy(alpha = 0.7f), bubbleShape)
                                                    else -> Modifier
                                                }
                                            )
                                            .clickable { day = d },
                                        horizontalAlignment = Alignment.CenterHorizontally,
                                        verticalArrangement = Arrangement.Center,
                                    ) {
                                        Text(
                                            "${d.dayOfMonth}",
                                            color = ink,
                                            fontWeight = if (isToday || isSel) FontWeight.Bold else FontWeight.Normal,
                                        )
                                        // Sans bulles de couleur : des points sous le numéro
                                        if (!bubbles && kinds.isNotEmpty()) {
                                            Row(horizontalArrangement = Arrangement.spacedBy(3.dp), modifier = Modifier.height(6.dp)) {
                                                kinds.forEach { k -> Box(Modifier.size(5.dp).background(k, CircleShape)) }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            androidx.compose.foundation.layout.FlowRow(
                Modifier.padding(top = 8.dp, start = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp),
            ) {
                listOf(cEvent to "Rendez-vous", cWork to "Travail", cAbsence to "Absence", cNote to "Note").forEach { (col, label) ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(10.dp).background(col, if (bubbles) RoundedCornerShape(3.dp) else CircleShape))
                        Text("  $label", style = MaterialTheme.typography.labelSmall)
                    }
                }
            }

            // Détail du jour
            Spacer(Modifier.height(16.dp))
            Text(
                day.format(java.time.format.DateTimeFormatter.ofPattern(fr.jeremy.calepin.i18n.I18n.pattern("EEEE d MMMM"), fr.jeremy.calepin.i18n.I18n.locale)).replaceFirstChar { it.uppercase() },
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.primary,
                modifier = Modifier.padding(start = 4.dp, bottom = 8.dp),
            )
            val dayEvents = eventsByDay[day].orEmpty()
            val dayDetected = detectedByDay[day].orEmpty()
                // Une date déjà ajoutée à l'agenda pour la même note n'est pas répétée
                .filter { dd -> events.none { it.noteId == dd.note.id && it.start == dd.time } }
            if (dayEvents.isEmpty() && dayDetected.isEmpty()) {
                Text(
                    "Rien de prévu. Touchez « Rendez-vous » pour en ajouter un, ou l'icône d'import pour charger un planning de travail (PDF ou photo).",
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(start = 4.dp),
                )
            }
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                dayEvents.forEach { e ->
                    ItemRow(
                        icon = if (e.isWork) Icons.Filled.Work else Icons.Filled.Today,
                        time = when {
                            e.isPeriod && e.allDay -> "Période"
                            e.allDay -> "Journée"
                            e.end > e.start -> hhmm(e.start) + "\n" + hhmm(e.end)
                            else -> hhmm(e.start)
                        },
                        title = e.title,
                        subtitle = listOfNotNull(
                            if (e.isPeriod) periodText(e.start, e.end) else null,
                            when {
                                e.remindMinutes < 0 -> null
                                e.alarm -> "Alarme"
                                else -> "Rappel"
                            },
                        ).joinToString(" · ").ifBlank { null },
                        badge = if (e.remindMinutes < 0) null else if (e.alarm) Icons.Filled.Alarm else Icons.Filled.NotificationsActive,
                        onClick = { editing = e },
                        actionLabel = if (e.noteId != 0L) "Note" else null,
                        onAction = { onOpenNote(e.noteId) },
                    )
                }
                dayDetected.forEach { dd ->
                    ItemRow(
                        icon = Icons.Filled.Description,
                        time = when {
                            dd.end != null && !dd.hasTime -> "Période"
                            dd.hasTime -> hhmm(dd.time)
                            else -> "Journée"
                        },
                        title = dd.note.title.ifBlank { "Sans titre" },
                        subtitle = "Écrit « ${dd.text} » dans la note",
                        badge = null,
                        onClick = { onOpenNote(dd.note.id) },
                        actionLabel = "+ Agenda",
                        onAction = {
                            editing = Event(
                                noteId = dd.note.id, title = dd.note.title.ifBlank { "Rendez-vous" },
                                start = dd.time, allDay = !dd.hasTime, end = dd.end ?: 0L,
                                remindMinutes = if (dd.hasTime) 15 else -540,
                            )
                        },
                    )
                }
            }
        }
    }

    importing?.let { (uri, mime) ->
        PlanningImport(vm, uri, mime) { first ->
            importing = null
            if (first != null) {
                val d = first.toDate()
                month = YearMonth.from(d); day = d
            }
        }
    }

    editing?.let { e ->
        EventDialog(
            initial = e,
            defaultRingtone = defaultRingtone,
            onDismiss = { editing = null },
            onSave = { vm.saveEvent(it); editing = null },
            onDelete = if (e.id != 0L) ({ vm.deleteEvent(e); editing = null }) else null,
        )
    }
}

private fun periodText(s: Long, e: Long): String {
    val f = java.time.format.DateTimeFormatter.ofPattern(fr.jeremy.calepin.i18n.I18n.pattern("d MMM"), fr.jeremy.calepin.i18n.I18n.locale)
    return fr.jeremy.calepin.i18n.I18n.trf("du {0} au {1}", s.toDate().format(f), e.toDate().format(f))
}

@Composable
private fun ItemRow(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    time: String,
    title: String,
    subtitle: String?,
    badge: androidx.compose.ui.graphics.vector.ImageVector?,
    onClick: () -> Unit,
    actionLabel: String?,
    onAction: () -> Unit,
) {
    Surface(
        shape = RoundedCornerShape(12.dp),
        color = MaterialTheme.colorScheme.surfaceContainerLow,
        border = appBorder(),
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick),
    ) {
        Row(Modifier.padding(horizontal = 12.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(20.dp))
            Spacer(Modifier.width(10.dp))
            Text(time, style = MaterialTheme.typography.labelLarge, modifier = Modifier.width(56.dp.grow()))
            Column(Modifier.weight(1f)) {
                Text(title, style = MaterialTheme.typography.bodyLarge, maxLines = 1, overflow = TextOverflow.Ellipsis)
                if (subtitle != null) {
                    Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 2)
                }
            }
            if (badge != null) Icon(badge, null, tint = MaterialTheme.colorScheme.secondary, modifier = Modifier.size(18.dp))
            if (actionLabel != null) TextButton(onClick = onAction) { Text(actionLabel) }
        }
    }
}
