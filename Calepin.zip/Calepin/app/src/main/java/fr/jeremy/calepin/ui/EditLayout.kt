package fr.jeremy.calepin.ui

import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.ParagraphStyle
import androidx.compose.ui.text.TextMeasurer
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.style.TextIndent
import androidx.compose.ui.unit.Constraints
import androidx.compose.ui.unit.Density
import fr.jeremy.calepin.text.DisplayMap
import fr.jeremy.calepin.text.NoteLayout
import fr.jeremy.calepin.text.RichText
import kotlin.math.ceil
import kotlin.math.roundToInt

/**
 * Mise en page de la zone d'écriture : les photos s'affichent à leur place pendant l'écriture et le texte
 * s'adapte à elles (à côté d'une photo à gauche ou à droite, sous une photo en pleine largeur ou une rangée de vignettes).
 * Le texte enregistré ne change pas : seuls l'affichage et la position du curseur sont adaptés.
 */
class EditLayoutPlanner(
    private val measurer: TextMeasurer,
    private val style: TextStyle,
    private val density: Density,
    /** Largeur de la zone de texte (en pixels). */
    private val width: Int,
    /** Rapport largeur / hauteur des photos, par fichier. */
    private val aspects: Map<String, Float>,
) {
    /** Photo (ou rangée de vignettes) à dessiner : en haut de la ligne affichée [anchor]. */
    data class Photo(val files: List<String>, val spec: NoteLayout.Spec?, val anchor: Int, val x: Int, val w: Int, val h: Int)

    /** Plan d'affichage d'un texte. */
    class Plan(val text: String, val map: DisplayMap, val photos: List<Photo>, val indents: List<Triple<Int, Int, Float>>) {
        /** Lignes à ne pas aligner (à côté d'une photo à gauche) : positions affichées. */
        fun indented(s: Int, e: Int) = indents.any { (a, b, _) -> s < b && e > a }
    }

    private var lastText: String? = null
    private var last: Plan? = null

    private val thumb = with(density) { THUMB.dpToPx() }
    private val gap = with(density) { GAP.dpToPx() }
    private val minText = with(density) { MIN_TEXT.dpToPx() }
    private val lineH: Float by lazy {
        val l = measurer.measure(AnnotatedString("Ag"), style)
        (l.getLineBottom(0) - l.getLineTop(0)).coerceAtLeast(1f)
    }

    private fun Float.dpToPx(): Int = (this * density.density).roundToInt()

    private fun lines(px: Float) = ceil(px / lineH).toInt().coerceIn(1, 400)

    fun plan(text: String): Plan {
        if (text == lastText) last?.let { return it }
        val p = compute(text)
        lastText = text
        last = p
        return p
    }

    private fun compute(text: String): Plan {
        val n = text.length
        val hidden = ArrayList<DisplayMap.Hidden>()
        hidden += hiddenSigns(text)
        val markers = NoteLayout.markerAlone.findAll(text).toList()
        if (markers.isEmpty() || width <= 0) {
            return Plan(text, DisplayMap(text, hidden, emptyList()), emptyList(), emptyList())
        }
        // Repère de photo : caché avec son retour à la ligne
        markers.forEach { m ->
            val e = m.range.last + 1
            hidden += DisplayMap.Hidden(m.range.first, if (e < n && text[e] == '\n') e + 1 else e, true)
        }
        val inserts = ArrayList<DisplayMap.Insert>()
        // (photo, insertion de la place réservée ou position du début du texte d'à côté)
        val pending = ArrayList<Pair<Photo, DisplayMap.Insert?>>()
        val pendingAt = ArrayList<Int>()
        val indentsOrig = ArrayList<Triple<Int, Int, Float>>()
        for (seg in NoteLayout.segments(text)) {
            val f = seg.float
            if (seg.files != null) {
                val p = if (seg.start < n && text[seg.start] == '\n') seg.start + 1 else seg.start
                val ins = DisplayMap.Insert(p, "\n".repeat(lines((thumb + gap / 2).toFloat())), true)
                inserts += ins
                pending += Photo(seg.files, null, 0, 0, thumb, thumb) to ins
                pendingAt += -1
                continue
            }
            if (f == null) continue
            val aspect = aspects[f.file] ?: (4f / 3f)
            val pw = (width * f.width / 100f).roundToInt().coerceIn(1, width)
            val ph = (pw / aspect).roundToInt().coerceAtLeast(1)
            val side = f.side
            if (side == null || side == NoteLayout.Side.FULL || width - pw - gap < minText) {
                val ins = DisplayMap.Insert(seg.start, "\n".repeat(lines((ph + gap / 2).toFloat())), true)
                inserts += ins
                val x = when (side) {
                    NoteLayout.Side.LEFT -> 0
                    NoteLayout.Side.RIGHT -> width - pw
                    else -> (width - pw) / 2
                }
                pending += Photo(listOf(f.file), f, 0, x, pw, ph) to ins
                pendingAt += -1
                continue
            }
            // Photo à gauche ou à droite : les lignes qui commencent à côté d'elle s'arrêtent avant elle
            val segText = text.substring(seg.start, seg.end)
            val sm = DisplayMap(segText, hiddenSigns(segText), emptyList())
            val vis = sm.visible
            val tw = width - pw - gap
            var besideBottom = 0f
            var lastEnd = seg.end
            if (vis.isNotEmpty()) {
                val l = measurer.measure(AnnotatedString(vis), style, constraints = Constraints(maxWidth = tw))
                var last = -1
                for (i in 0 until l.lineCount) { if (l.getLineTop(i) < ph) last = i else break }
                if (last >= 0) {
                    besideBottom = l.getLineBottom(last)
                    for (i in 0..last) {
                        if (i == l.lineCount - 1) break
                        val endV = l.getLineEnd(i)
                        if (endV <= 0 || endV >= vis.length || vis[endV - 1] == '\n') continue
                        inserts += DisplayMap.Insert(seg.start + sm.toOriginal(endV), "\n", true)
                    }
                    val endLast = l.getLineEnd(last).let { if (it > 0 && vis[it - 1] == '\n') it - 1 else it }
                    lastEnd = seg.start + sm.toOriginal(endLast)
                }
            }
            // Texte plus court que la photo : place réservée sous le texte
            if (besideBottom < ph) {
                inserts += DisplayMap.Insert(seg.end, "\n".repeat(lines(ph + gap / 2 - besideBottom)), false)
            }
            if (side == NoteLayout.Side.LEFT && vis.isNotEmpty()) {
                indentsOrig += Triple(seg.start, lastEnd, with(density) { (pw + gap).toFloat().toSp().value })
            }
            pending += Photo(listOf(f.file), f, 0, if (side == NoteLayout.Side.LEFT) 0 else width - pw, pw, ph) to null
            pendingAt += seg.start
        }
        val map = DisplayMap(text, hidden, inserts)
        val photos = pending.mapIndexed { i, (ph, ins) ->
            val anchor = if (ins != null) map.toVisible(ins.pos) - ins.text.length else map.toVisible(pendingAt[i])
            ph.copy(anchor = anchor.coerceIn(0, map.visible.length))
        }
        val indents = indentsOrig.mapNotNull { (s, e, sp) ->
            val vs = map.toVisible(s)
            // Fin : avant le retour à la ligne ajouté après la dernière ligne d'à côté
            var ve = map.toVisible(e)
            while (ve > vs && map.visible[ve - 1] == '\n') ve--
            if (ve > vs) Triple(vs, ve, sp) else null
        }
        return Plan(text, map, photos, indents)
    }

    companion object {
        /** Repères cachés à l'écran : couleurs, alignement, et signes de gras, italique, barré, titres, liens. */
        fun hiddenSigns(text: String): List<DisplayMap.Hidden> =
            (if ('[' in text) RichText.tokens(text).map { DisplayMap.Hidden(it.start, it.end, false) } else emptyList()) +
                fr.jeremy.calepin.text.MarkdownSigns.hidden(text)

        /** Sans mise en page des photos (largeur pas encore connue) : seuls les repères de couleur sont cachés. */
        fun simple(text: String): Plan {
            val hidden = hiddenSigns(text)
            return Plan(text, DisplayMap(text, hidden, emptyList()), emptyList(), emptyList())
        }

        const val THUMB = 104f
        const val GAP = 12f
        const val MIN_TEXT = 96f

        /** Retrait des lignes à côté d'une photo à gauche. */
        fun indentStyle(sp: Float) = ParagraphStyle(textIndent = TextIndent(firstLine = androidx.compose.ui.unit.TextUnit(sp, androidx.compose.ui.unit.TextUnitType.Sp)))
    }
}
