package fr.jeremy.calepin.search

import android.content.Context

/**
 * Ordre des notes choisi au glisser-déposer (liste des notes, sans recherche). Les notes qui n'y sont pas
 * (nouvelles) passent devant, des plus récentes aux plus anciennes ; les notes épinglées restent en tête.
 */
object NoteOrder {
    private const val PREFS = "calepin_note_order"
    @Volatile var ids: List<Long> = emptyList()
        private set
    @Volatile private var loaded = false

    fun init(ctx: Context) {
        if (loaded) return
        loaded = true
        ids = ctx.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString("ids", "").orEmpty()
            .split(',').mapNotNull { it.toLongOrNull() }
    }

    fun set(ctx: Context, list: List<Long>) {
        ids = list.distinct()
        ctx.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString("ids", ids.joinToString(",")).apply()
    }

    fun clear(ctx: Context) = set(ctx, emptyList())

    /**
     * Nouvel ordre complet après avoir déplacé [from] à la place de [to] dans la liste affichée [shown]
     * (qui peut n'être qu'une partie des notes : un dossier). Les autres notes gardent leur place.
     */
    fun reorder(current: List<Long>, shown: List<Long>, from: Long, to: Long): List<Long> {
        val i = shown.indexOf(from)
        val j = shown.indexOf(to)
        if (i < 0 || j < 0 || i == j) return current
        val newShown = shown.toMutableList().apply { add(j, removeAt(i)) }
        val g = (shown.filter { it !in current } + current).toMutableList()
        val slots = g.indices.filter { g[it] in shown.toSet() }
        slots.forEachIndexed { k, slot -> g[slot] = newShown[k] }
        return g
    }
}
