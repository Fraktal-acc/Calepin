package fr.jeremy.calepin.search

/**
 * Recherche « par le sens » sans Internet : chaque mot cherché retrouve aussi les mots de la même famille
 * (« voiture » → garage, contrôle technique, assurance auto…). Les correspondances comptent moins
 * que le mot exact, pour que celui-ci reste en tête.
 */
object Synonyms {

    private val GROUPS: List<List<String>> = listOf(
        listOf("voiture", "auto", "automobile", "vehicule", "garage", "garagiste", "controle technique", "pneu", "vidange", "carrosserie", "parking", "permis", "carte grise"),
        listOf("medecin", "docteur", "generaliste", "rdv medical", "ordonnance", "pharmacie", "medicament", "sante", "hopital", "clinique", "dentiste", "kine", "specialiste", "analyse", "vaccin"),
        listOf("argent", "banque", "virement", "compte", "budget", "depense", "paiement", "facture", "prix", "tarif", "devis", "euro", "euros", "rembourse", "credit", "pret"),
        listOf("facture", "devis", "paiement", "reglement", "acompte", "tva", "montant", "avoir", "relance"),
        listOf("maison", "appartement", "logement", "villa", "domicile", "loyer", "proprietaire", "locataire", "bail", "syndic", "copropriete"),
        listOf("plombier", "plomberie", "fuite", "robinet", "chauffe-eau", "ballon", "evier", "canalisation", "degat des eaux"),
        listOf("electricien", "electricite", "courant", "disjoncteur", "prise", "ampoule", "tableau electrique", "panne"),
        listOf("travaux", "chantier", "renovation", "artisan", "peinture", "macon", "carrelage", "menuisier", "devis"),
        listOf("jardin", "jardinier", "pelouse", "tonte", "arrosage", "plantes", "haie", "taille", "piscine", "pisciniste"),
        listOf("menage", "nettoyage", "aspirateur", "repassage", "linge", "lessive", "pressing", "vitres", "entretien"),
        listOf("courses", "supermarche", "marche", "epicerie", "liste de courses", "acheter", "magasin", "boulangerie"),
        listOf("repas", "diner", "dejeuner", "restaurant", "resto", "cuisine", "recette", "manger", "menu"),
        listOf("travail", "boulot", "bureau", "reunion", "collegue", "patron", "client", "projet", "mission", "planning"),
        listOf("client", "clients", "prospect", "contact", "proprietaire", "devis", "rendez-vous"),
        listOf("rendez-vous", "rdv", "reunion", "rencontre", "visite", "entretien", "agenda", "rencontrer"),
        listOf("voyage", "vacances", "avion", "vol", "billet", "train", "hotel", "reservation", "valise", "passeport", "aeroport", "gare"),
        listOf("ecole", "college", "lycee", "classe", "professeur", "prof", "devoirs", "cantine", "rentree", "inscription"),
        listOf("anniversaire", "fete", "cadeau", "soiree", "invitation", "noel", "mariage", "bapteme"),
        listOf("telephone", "portable", "numero", "appeler", "appel", "tel", "mobile", "sms", "message"),
        listOf("internet", "box", "wifi", "fibre", "operateur", "orange", "free", "sfr", "bouygues", "abonnement"),
        listOf("impots", "impot", "declaration", "taxe", "urssaf", "administration", "caf", "securite sociale", "ameli", "mutuelle", "papiers"),
        listOf("assurance", "contrat", "sinistre", "mutuelle", "franchise", "declaration de sinistre", "expert"),
        listOf("animal", "chien", "chat", "veterinaire", "veto", "croquettes", "toilettage"),
        listOf("sport", "salle", "musculation", "footing", "course a pied", "velo", "natation", "match", "entrainement"),
        listOf("cles", "clef", "cle", "badge", "bip", "code", "digicode", "portail", "alarme"),
        listOf("code", "mot de passe", "identifiant", "login", "pin", "digicode"),
        listOf("idee", "projet", "brainstorming", "a faire", "todo", "plan"),
        listOf("urgent", "important", "prioritaire", "asap", "vite", "rapidement"),
        listOf("bateau", "port", "ponton", "amarrage", "capitainerie", "yacht", "voilier"),
        listOf("intervention", "passage", "mission", "prestation", "visite", "tournee"),
    )

    private val index: Map<String, Set<String>> by lazy {
        val m = HashMap<String, MutableSet<String>>()
        GROUPS.forEach { g -> g.forEach { w -> m.getOrPut(w) { mutableSetOf() }.addAll(g) } }
        m.mapValues { (k, v) -> v - k }
    }

    /** Mots de la même famille que [word] (déjà normalisé : minuscules sans accents). */
    fun related(word: String): Set<String> {
        if (word.length < 3) return emptySet()
        index[word]?.let { return it }
        // Pluriels et féminins simples : « factures », « clientes »
        for (cut in listOf("s", "x", "es", "e")) {
            if (word.endsWith(cut)) index[word.dropLast(cut.length)]?.let { return it }
        }
        return emptySet()
    }
}
