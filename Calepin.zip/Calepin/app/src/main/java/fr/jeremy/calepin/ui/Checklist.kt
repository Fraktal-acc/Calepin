package fr.jeremy.calepin.ui

import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.input.TextFieldValue

/**
 * Listes à cocher dans le texte des notes : une ligne « ☐ … » est à faire, « ☑ … » est faite.
 * Le texte reste lisible partout (export, partage, autres applis).
 */
object Checklist {
    const val OPEN = "☐ "
    const val DONE = "☑ "

    fun isItem(line: String) = line.startsWith("☐") || line.startsWith("☑")
    fun isDone(line: String) = line.startsWith("☑")

    /** Début de la ligne qui contient [offset]. */
    fun lineStart(text: String, offset: Int): Int = text.lastIndexOf('\n', (offset - 1).coerceAtLeast(-1)).let { if (offset == 0) 0 else it + 1 }

    private fun lineEnd(text: String, start: Int): Int = text.indexOf('\n', start).let { if (it < 0) text.length else it }

    /** Coche ou décoche la ligne qui commence en [start] ; les éléments cochés descendent en bas de leur liste. */
    fun toggleAt(text: String, start: Int): String {
        val lines = text.split('\n').toMutableList()
        var idx = 0
        var pos = 0
        while (idx < lines.size && pos + lines[idx].length < start) { pos += lines[idx].length + 1; idx++ }
        if (idx >= lines.size || !isItem(lines[idx])) return text
        val l = lines[idx]
        val body = l.drop(1).trimStart()
        lines[idx] = (if (isDone(l)) OPEN else DONE) + body
        // Bloc de lignes à cocher contiguës autour de l'élément
        var a = idx
        while (a > 0 && isItem(lines[a - 1])) a--
        var b = idx
        while (b < lines.size - 1 && isItem(lines[b + 1])) b++
        val block = lines.subList(a, b + 1).toList()
        val sorted = block.filter { !isDone(it) } + block.filter { isDone(it) }
        for (i in sorted.indices) lines[a + i] = sorted[i]
        return lines.joinToString("\n")
    }

    /** Transforme la ou les lignes sélectionnées en liste à cocher (ou retire les cases si elles y sont déjà). */
    fun toggleLines(v: TextFieldValue): TextFieldValue {
        val text = v.text
        val s = lineStart(text, v.selection.min.coerceIn(0, text.length))
        val e = lineEnd(text, v.selection.max.coerceIn(0, text.length))
        val segment = text.substring(s, e)
        val lines = segment.split('\n')
        val allItems = lines.all { isItem(it) || it.isBlank() } && lines.any { isItem(it) }
        val changed = lines.joinToString("\n") { l ->
            when {
                allItems && isItem(l) -> l.drop(1).trimStart()
                !allItems && !isItem(l) && (l.isNotBlank() || lines.size == 1) -> OPEN + l
                else -> l
            }
        }
        val newText = text.substring(0, s) + changed + text.substring(e)
        val cursor = (s + changed.length).coerceIn(0, newText.length)
        return TextFieldValue(newText, TextRange(cursor))
    }

    /**
     * Après une frappe : un retour à la ligne sous un élément crée la case suivante ;
     * sur un élément vide, il termine la liste.
     */
    fun afterEdit(old: TextFieldValue, new: TextFieldValue): TextFieldValue {
        if (new.text.length != old.text.length + 1 || !new.selection.collapsed) return new
        val at = new.selection.start - 1
        if (at < 0 || new.text[at] != '\n') return new
        val prevStart = lineStart(new.text, at)
        val prev = new.text.substring(prevStart, at)
        if (!isItem(prev)) return new
        return if (prev.drop(1).isBlank()) {
            // Case vide + Entrée : fin de la liste
            val t = new.text.substring(0, prevStart) + new.text.substring(at + 1)
            TextFieldValue(t, TextRange(prevStart))
        } else {
            val t = new.text.substring(0, at + 1) + OPEN + new.text.substring(at + 1)
            TextFieldValue(t, TextRange(at + 1 + OPEN.length))
        }
    }

    /** Plages de texte des éléments cochés (pour les barrer) et positions des cases. */
    fun doneRanges(text: String): List<IntRange> {
        val out = mutableListOf<IntRange>()
        var pos = 0
        text.split('\n').forEach { l ->
            if (isDone(l) && l.length > 1) out += (pos + 1) until (pos + l.length)
            pos += l.length + 1
        }
        return out
    }

    fun boxPositions(text: String): List<Int> {
        val out = mutableListOf<Int>()
        var pos = 0
        text.split('\n').forEach { l ->
            if (isItem(l)) out += pos
            pos += l.length + 1
        }
        return out
    }

    /** « 3/5 » pour l'aperçu dans la liste des notes, ou null s'il n'y a pas de liste. */
    fun progress(text: String): Pair<Int, Int>? {
        val items = text.split('\n').filter { isItem(it) }
        if (items.isEmpty()) return null
        return items.count { isDone(it) } to items.size
    }
}
