package fr.jeremy.calepin.ui

import android.net.Uri
import android.widget.Toast
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import fr.jeremy.calepin.i18n.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import fr.jeremy.calepin.NotesViewModel
import fr.jeremy.calepin.data.Event
import fr.jeremy.calepin.detect.GridPlanningParser
import fr.jeremy.calepin.detect.PlanningParser
import fr.jeremy.calepin.detect.Shift
import fr.jeremy.calepin.media.PdfText
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Import d'un planning de travail (PDF ou photo) : lecture, aperçu des créneaux repérés,
 * choix du titre et du rappel, puis ajout à l'agenda.
 */
@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun PlanningImport(vm: NotesViewModel, uri: Uri, mime: String, onDone: (firstShift: Long?) -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val defaultRingtone by vm.settings.ringtone.collectAsStateWithLifecycle()
    var status by remember { mutableStateOf<String?>("Lecture du document…") }
    var rawText by remember { mutableStateOf("") }
    var usedOcr by remember { mutableStateOf(false) }
    var shifts by remember { mutableStateOf<List<Shift>>(emptyList()) }
    var keep by remember { mutableStateOf<Set<Int>>(emptySet()) }
    var title by remember { mutableStateOf("Travail") }
    var withLabel by remember { mutableStateOf(true) }
    var remind by remember { mutableIntStateOf(60) }
    var alarm by remember { mutableStateOf(false) }
    var showText by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    // Comparaison avec les créneaux de travail déjà dans l'agenda (planning modifié)
    val existing by vm.events.collectAsStateWithLifecycle()
    fun titleOf(sh: Shift) = if (withLabel && sh.label.isNotBlank()) "$title · ${sh.label}" else title
    val diff = remember(shifts, existing, title, withLabel) { planningDiff(shifts, existing.filter { it.isWork }, ::titleOf) }
    // Créneaux retirés du planning : cochés = supprimés de l'agenda
    var removeIds by remember(diff) { mutableStateOf(diff.removed.map { it.id }.toSet()) }

    LaunchedEffect(uri) {
        try {
            val r = if (mime.startsWith("image/")) PdfText.extractImage(ctx, uri) else PdfText.extract(ctx, uri) { status = it }
            usedOcr = r.usedOcr
            rawText = r.text
            status = "Recherche des horaires…"
            // Planning en grille (une colonne par jour) d'abord, sinon lecture ligne par ligne
            val grid = GridPlanningParser.parse(r.glyphs)
            val lines = PlanningParser.parse(r.text)
            shifts = if (grid.isNotEmpty() && grid.size >= lines.size) grid else lines
            // Déjà dans l'agenda à l'identique : décoché (rien à faire)
            val d0 = planningDiff(shifts, vm.events.value.filter { it.isWork }) { titleOf(it) }
            keep = shifts.indices.filter { d0.status[it] != ShiftStatus.SAME }.toSet()
        } catch (e: Throwable) {
            error = "Impossible de lire ce fichier : ${e.message ?: "format non reconnu"}"
        }
        status = null
    }

    val day = SimpleDateFormat(fr.jeremy.calepin.i18n.I18n.pattern("EEE d MMM"), fr.jeremy.calepin.i18n.I18n.locale)
    val hm = SimpleDateFormat(fr.jeremy.calepin.i18n.I18n.pattern("HH:mm"), fr.jeremy.calepin.i18n.I18n.locale)

    Dialog(onDismissRequest = { onDone(null) }, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text("Importer un planning") },
                    navigationIcon = { IconButton(onClick = { onDone(null) }) { Icon(Icons.Filled.Close, "Fermer") } },
                )
            },
            bottomBar = {
                if (status == null && shifts.isNotEmpty()) {
                    Surface(tonalElevation = 3.dp) {
                        Button(
                            onClick = {
                                val chosen = shifts.indices.filter { it in keep }
                                scope.launch {
                                    fun eventOf(sh: Shift) = Event(
                                        title = titleOf(sh),
                                        start = sh.start, end = sh.end,
                                        remindMinutes = remind, alarm = alarm && remind >= 0,
                                        ringtone = defaultRingtone, category = Event.CATEGORY_WORK,
                                    )
                                    val add = mutableListOf<Event>()
                                    val replace = mutableListOf<Pair<Event, Event>>()
                                    chosen.forEach { i ->
                                        val old = diff.replaces[i]
                                        when {
                                            old != null -> replace += old to eventOf(shifts[i])
                                            diff.status[i] == ShiftStatus.SAME -> Unit // déjà là, à l'identique
                                            else -> add += eventOf(shifts[i])
                                        }
                                    }
                                    val delete = diff.removed.filter { it.id in removeIds }
                                    vm.applyPlanning(add, replace, delete)
                                    fr.jeremy.calepin.i18n.I18n.toast(
                                        ctx,
                                        fr.jeremy.calepin.i18n.I18n.trf(
                                            "Agenda mis à jour : {0} ajouté(s), {1} modifié(s), {2} supprimé(s).",
                                            add.size, replace.size, delete.size,
                                        ),
                                        Toast.LENGTH_LONG,
                                    ).show()
                                    onDone(chosen.firstOrNull()?.let { shifts[it].start })
                                }
                            },
                            enabled = keep.isNotEmpty() || removeIds.isNotEmpty(),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                        ) {
                            val changes = keep.count { diff.replaces[it] != null } + removeIds.size
                            if (changes > 0) Text("Mettre à jour l'agenda")
                            else Text("Ajouter ${keep.size} créneau${if (keep.size > 1) "x" else ""} à l'agenda")
                        }
                    }
                }
            },
        ) { pad ->
            when {
                status != null -> Column(
                    Modifier
                        .fillMaxSize()
                        .padding(pad),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center,
                ) {
                    CircularProgressIndicator()
                    Spacer(Modifier.height(12.dp))
                    Text(status ?: "")
                }
                else -> LazyColumn(
                    Modifier
                        .fillMaxSize()
                        .padding(pad),
                    contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    item {
                        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
                            if (error == null && shifts.isEmpty()) {
                                Text(
                                    "Aucun horaire n'a été reconnu dans ce document. Calepin cherche des dates " +
                                        "(12/10, lundi 12…) et des horaires (08:00 - 16:00, 8h-12h). " +
                                        "Vérifiez le texte lu ci-dessous, ou ajoutez les créneaux à la main dans l'agenda.",
                                )
                            }
                            if (shifts.isNotEmpty()) {
                                Text(
                                    "${shifts.size} créneau${if (shifts.size > 1) "x" else ""} trouvé${if (shifts.size > 1) "s" else ""}" +
                                        if (usedOcr) " (document scanné : vérifiez bien les horaires)" else "",
                                    style = MaterialTheme.typography.titleMedium,
                                )
                                // Ce qui change par rapport à l'agenda
                                val nNew = diff.status.values.count { it == ShiftStatus.NEW }
                                val nChanged = diff.status.values.count { it == ShiftStatus.CHANGED }
                                val nSame = diff.status.values.count { it == ShiftStatus.SAME }
                                if (nChanged + nSame + diff.removed.size > 0) {
                                    Text(
                                        fr.jeremy.calepin.i18n.I18n.trf(
                                            "Par rapport à l'agenda : {0} nouveau(x), {1} modifié(s), {2} identique(s), {3} retiré(s) du planning.",
                                            nNew, nChanged, nSame, diff.removed.size,
                                        ),
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = MaterialTheme.colorScheme.primary,
                                    )
                                }
                                OutlinedTextField(
                                    value = title, onValueChange = { title = it },
                                    label = { Text("Titre dans l'agenda") }, singleLine = true,
                                    modifier = Modifier.fillMaxWidth(),
                                )
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text("Ajouter le site / poste lu dans le planning", Modifier.weight(1f))
                                    Switch(checked = withLabel, onCheckedChange = { withLabel = it })
                                }
                                Text("Rappel avant chaque prise de poste", style = MaterialTheme.typography.labelLarge)
                                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    listOf(-1 to "Aucun", 30 to "30 min", 60 to "1 h", 120 to "2 h", 720 to "12 h").forEach { (m, l) ->
                                        FilterChip(selected = remind == m, onClick = { remind = m }, label = { Text(l) })
                                    }
                                }
                                if (remind >= 0) {
                                    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                        FilterChip(selected = !alarm, onClick = { alarm = false }, label = { Text("Notification") })
                                        FilterChip(selected = alarm, onClick = { alarm = true }, label = { Text("Alarme qui sonne") })
                                    }
                                }
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text("Créneaux à ajouter", style = MaterialTheme.typography.labelLarge, modifier = Modifier.weight(1f))
                                    TextButton(onClick = {
                                        keep = if (keep.size == shifts.size) emptySet() else shifts.indices.toSet()
                                    }) { Text(if (keep.size == shifts.size) "Tout décocher" else "Tout cocher") }
                                }
                            }
                        }
                    }
                    itemsIndexed(shifts) { i, sh ->
                        val checked = i in keep
                        val nextDay = day.format(Date(sh.end)) != day.format(Date(sh.start))
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = if (checked) MaterialTheme.colorScheme.surfaceContainer else MaterialTheme.colorScheme.surface,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { keep = if (checked) keep - i else keep + i },
                        ) {
                            Row(Modifier.padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                                Checkbox(checked = checked, onCheckedChange = { keep = if (it) keep + i else keep - i })
                                Column(Modifier.weight(1f)) {
                                    Text(
                                        day.format(Date(sh.start)).replaceFirstChar { it.uppercase() } + " · " +
                                            hm.format(Date(sh.start)) + " → " + hm.format(Date(sh.end)) +
                                            if (nextDay) " (lendemain)" else "",
                                        style = MaterialTheme.typography.bodyLarge,
                                    )
                                    if (sh.label.isNotBlank()) {
                                        Text(sh.label, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }
                                    when (diff.status[i]) {
                                        ShiftStatus.NEW -> Text("Nouveau", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
                                        ShiftStatus.SAME -> Text("Déjà dans l'agenda", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                        ShiftStatus.CHANGED -> diff.replaces[i]?.let { old ->
                                            Text(
                                                fr.jeremy.calepin.i18n.tr("Modifié — avant :") + " " + day.format(Date(old.start)).replaceFirstChar { it.uppercase() } +
                                                    " · " + hm.format(Date(old.start)) + (if (old.end > old.start) " → " + hm.format(Date(old.end)) else ""),
                                                style = MaterialTheme.typography.labelMedium,
                                                color = MaterialTheme.colorScheme.tertiary,
                                            )
                                        }
                                        null -> Unit
                                    }
                                }
                            }
                        }
                    }
                    if (diff.removed.isNotEmpty()) {
                        item {
                            Text(
                                "Retirés du planning (cochés = supprimés de l'agenda)",
                                style = MaterialTheme.typography.labelLarge,
                                modifier = Modifier.padding(top = 8.dp),
                            )
                        }
                        items(diff.removed.size) { k ->
                            val e = diff.removed[k]
                            val on = e.id in removeIds
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = if (on) MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.5f) else MaterialTheme.colorScheme.surface,
                                modifier = Modifier.fillMaxWidth().clickable { removeIds = if (on) removeIds - e.id else removeIds + e.id },
                            ) {
                                Row(Modifier.padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Checkbox(checked = on, onCheckedChange = { removeIds = if (it) removeIds + e.id else removeIds - e.id })
                                    Column(Modifier.weight(1f)) {
                                        Text(
                                            day.format(Date(e.start)).replaceFirstChar { it.uppercase() } + " · " + hm.format(Date(e.start)) +
                                                (if (e.end > e.start) " → " + hm.format(Date(e.end)) else ""),
                                            style = MaterialTheme.typography.bodyLarge,
                                        )
                                        fr.jeremy.calepin.i18n.RawText(e.title, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }
                                }
                            }
                        }
                    }
                    item {
                        HorizontalDivider()
                        TextButton(onClick = { showText = !showText }) {
                            Text(if (showText) "Masquer le texte lu" else "Voir le texte lu dans le document")
                        }
                        if (showText) {
                            Text(
                                rawText.ifBlank { "(aucun texte)" },
                                fontFamily = FontFamily.Monospace,
                                style = MaterialTheme.typography.bodySmall,
                            )
                        }
                        Spacer(Modifier.size(80.dp))
                    }
                }
            }
        }
    }
}

// ------------------------------------------------------------------ Comparaison avec l'agenda

/** Ce que devient chaque créneau du planning par rapport à l'agenda. */
enum class ShiftStatus { NEW, CHANGED, SAME }

/**
 * [status] : nouveau / modifié / identique pour chaque créneau (par indice) ;
 * [replaces] : pour un créneau modifié, le rendez-vous de l'agenda qu'il remplace ;
 * [removed] : créneaux de travail de l'agenda, dans la période du planning, qui n'y figurent plus.
 */
class PlanningDiff(val status: Map<Int, ShiftStatus>, val replaces: Map<Int, Event>, val removed: List<Event>)

private fun dayOf(t: Long): Long = java.util.Calendar.getInstance().apply {
    timeInMillis = t
    set(java.util.Calendar.HOUR_OF_DAY, 0); set(java.util.Calendar.MINUTE, 0); set(java.util.Calendar.SECOND, 0); set(java.util.Calendar.MILLISECOND, 0)
}.timeInMillis

/**
 * Compare un planning lu (créneaux) avec les créneaux de travail déjà dans l'agenda.
 * Seuls les jours couverts par le planning (du premier au dernier) sont concernés.
 */
fun planningDiff(shifts: List<Shift>, work: List<Event>, titleOf: (Shift) -> String): PlanningDiff {
    if (shifts.isEmpty()) return PlanningDiff(emptyMap(), emptyMap(), emptyList())
    val first = dayOf(shifts.minOf { it.start })
    val last = dayOf(shifts.maxOf { it.start })
    val candidates = work.filter { dayOf(it.start) in first..last }.toMutableList()
    val status = HashMap<Int, ShiftStatus>()
    val replaces = HashMap<Int, Event>()
    // 1. Mêmes horaires : identique (ou modifié si le titre / le poste a changé)
    shifts.forEachIndexed { i, sh ->
        val e = candidates.firstOrNull { it.start == sh.start && it.end == sh.end } ?: return@forEachIndexed
        candidates.remove(e)
        if (e.title == titleOf(sh)) status[i] = ShiftStatus.SAME else { status[i] = ShiftStatus.CHANGED; replaces[i] = e }
    }
    // 2. Même jour, horaires différents : modifié (remplace l'ancien créneau)
    shifts.forEachIndexed { i, sh ->
        if (i in status) return@forEachIndexed
        val d = dayOf(sh.start)
        val e = candidates.filter { dayOf(it.start) == d }
            .minByOrNull { kotlin.math.abs(it.start - sh.start) } ?: return@forEachIndexed
        candidates.remove(e)
        status[i] = ShiftStatus.CHANGED; replaces[i] = e
    }
    // 3. Le reste est nouveau
    shifts.indices.forEach { i -> if (i !in status) status[i] = ShiftStatus.NEW }
    return PlanningDiff(status, replaces, candidates.sortedBy { it.start })
}
