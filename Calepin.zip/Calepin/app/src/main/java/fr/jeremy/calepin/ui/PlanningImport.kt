package fr.jeremy.calepin.ui

import android.net.Uri
import android.widget.Toast
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import fr.jeremy.calepin.NotesViewModel
import fr.jeremy.calepin.data.Event
import fr.jeremy.calepin.detect.GridPlanningParser
import fr.jeremy.calepin.detect.PlanningParser
import fr.jeremy.calepin.detect.Shift
import fr.jeremy.calepin.media.PdfText
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Import d'un planning de travail (PDF ou photo) : lecture, aperçu des créneaux repérés,
 * choix du titre et du rappel, puis ajout à l'agenda.
 */
@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun PlanningImport(vm: NotesViewModel, uri: Uri, mime: String, onDone: (firstShift: Long?) -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val defaultRingtone by vm.settings.ringtone.collectAsStateWithLifecycle()
    var status by remember { mutableStateOf<String?>("Lecture du document…") }
    var rawText by remember { mutableStateOf("") }
    var usedOcr by remember { mutableStateOf(false) }
    var shifts by remember { mutableStateOf<List<Shift>>(emptyList()) }
    var keep by remember { mutableStateOf<Set<Int>>(emptySet()) }
    var title by remember { mutableStateOf("Travail") }
    var withLabel by remember { mutableStateOf(true) }
    var remind by remember { mutableIntStateOf(60) }
    var alarm by remember { mutableStateOf(false) }
    var showText by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(uri) {
        try {
            val r = if (mime.startsWith("image/")) PdfText.extractImage(ctx, uri) else PdfText.extract(ctx, uri) { status = it }
            usedOcr = r.usedOcr
            rawText = r.text
            status = "Recherche des horaires…"
            // Planning en grille (une colonne par jour) d'abord, sinon lecture ligne par ligne
            val grid = GridPlanningParser.parse(r.glyphs)
            val lines = PlanningParser.parse(r.text)
            shifts = if (grid.isNotEmpty() && grid.size >= lines.size) grid else lines
            keep = shifts.indices.toSet()
        } catch (e: Throwable) {
            error = "Impossible de lire ce fichier : ${e.message ?: "format non reconnu"}"
        }
        status = null
    }

    val day = SimpleDateFormat("EEE d MMM", Locale.FRANCE)
    val hm = SimpleDateFormat("HH:mm", Locale.FRANCE)

    Dialog(onDismissRequest = { onDone(null) }, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text("Importer un planning") },
                    navigationIcon = { IconButton(onClick = { onDone(null) }) { Icon(Icons.Filled.Close, "Fermer") } },
                )
            },
            bottomBar = {
                if (status == null && shifts.isNotEmpty()) {
                    Surface(tonalElevation = 3.dp) {
                        Button(
                            onClick = {
                                val chosen = shifts.filterIndexed { i, _ -> i in keep }
                                scope.launch {
                                    val events = chosen.map { sh ->
                                        Event(
                                            title = if (withLabel && sh.label.isNotBlank()) "$title · ${sh.label}" else title,
                                            start = sh.start, end = sh.end,
                                            remindMinutes = remind, alarm = alarm && remind >= 0,
                                            ringtone = defaultRingtone, category = Event.CATEGORY_WORK,
                                        )
                                    }
                                    val n = vm.saveEvents(events)
                                    val skipped = events.size - n
                                    Toast.makeText(
                                        ctx,
                                        "$n créneau${if (n > 1) "x" else ""} ajouté${if (n > 1) "s" else ""}" +
                                            if (skipped > 0) " ($skipped déjà dans l'agenda)" else "",
                                        Toast.LENGTH_LONG,
                                    ).show()
                                    onDone(chosen.firstOrNull()?.start)
                                }
                            },
                            enabled = keep.isNotEmpty(),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                        ) { Text("Ajouter ${keep.size} créneau${if (keep.size > 1) "x" else ""} à l'agenda") }
                    }
                }
            },
        ) { pad ->
            when {
                status != null -> Column(
                    Modifier
                        .fillMaxSize()
                        .padding(pad),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center,
                ) {
                    CircularProgressIndicator()
                    Spacer(Modifier.height(12.dp))
                    Text(status ?: "")
                }
                else -> LazyColumn(
                    Modifier
                        .fillMaxSize()
                        .padding(pad),
                    contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    item {
                        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
                            if (error == null && shifts.isEmpty()) {
                                Text(
                                    "Aucun horaire n'a été reconnu dans ce document. Calepin cherche des dates " +
                                        "(12/10, lundi 12…) et des horaires (08:00 - 16:00, 8h-12h). " +
                                        "Vérifiez le texte lu ci-dessous, ou ajoutez les créneaux à la main dans l'agenda.",
                                )
                            }
                            if (shifts.isNotEmpty()) {
                                Text(
                                    "${shifts.size} créneau${if (shifts.size > 1) "x" else ""} trouvé${if (shifts.size > 1) "s" else ""}" +
                                        if (usedOcr) " (document scanné : vérifiez bien les horaires)" else "",
                                    style = MaterialTheme.typography.titleMedium,
                                )
                                OutlinedTextField(
                                    value = title, onValueChange = { title = it },
                                    label = { Text("Titre dans l'agenda") }, singleLine = true,
                                    modifier = Modifier.fillMaxWidth(),
                                )
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text("Ajouter le site / poste lu dans le planning", Modifier.weight(1f))
                                    Switch(checked = withLabel, onCheckedChange = { withLabel = it })
                                }
                                Text("Rappel avant chaque prise de poste", style = MaterialTheme.typography.labelLarge)
                                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    listOf(-1 to "Aucun", 30 to "30 min", 60 to "1 h", 120 to "2 h", 720 to "12 h").forEach { (m, l) ->
                                        FilterChip(selected = remind == m, onClick = { remind = m }, label = { Text(l) })
                                    }
                                }
                                if (remind >= 0) {
                                    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                        FilterChip(selected = !alarm, onClick = { alarm = false }, label = { Text("Notification") })
                                        FilterChip(selected = alarm, onClick = { alarm = true }, label = { Text("Alarme qui sonne") })
                                    }
                                }
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text("Créneaux à ajouter", style = MaterialTheme.typography.labelLarge, modifier = Modifier.weight(1f))
                                    TextButton(onClick = {
                                        keep = if (keep.size == shifts.size) emptySet() else shifts.indices.toSet()
                                    }) { Text(if (keep.size == shifts.size) "Tout décocher" else "Tout cocher") }
                                }
                            }
                        }
                    }
                    itemsIndexed(shifts) { i, sh ->
                        val checked = i in keep
                        val nextDay = day.format(Date(sh.end)) != day.format(Date(sh.start))
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = if (checked) MaterialTheme.colorScheme.surfaceContainer else MaterialTheme.colorScheme.surface,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { keep = if (checked) keep - i else keep + i },
                        ) {
                            Row(Modifier.padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                                Checkbox(checked = checked, onCheckedChange = { keep = if (it) keep + i else keep - i })
                                Column(Modifier.weight(1f)) {
                                    Text(
                                        day.format(Date(sh.start)).replaceFirstChar { it.uppercase() } + " · " +
                                            hm.format(Date(sh.start)) + " → " + hm.format(Date(sh.end)) +
                                            if (nextDay) " (lendemain)" else "",
                                        style = MaterialTheme.typography.bodyLarge,
                                    )
                                    if (sh.label.isNotBlank()) {
                                        Text(sh.label, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }
                                }
                            }
                        }
                    }
                    item {
                        HorizontalDivider()
                        TextButton(onClick = { showText = !showText }) {
                            Text(if (showText) "Masquer le texte lu" else "Voir le texte lu dans le document")
                        }
                        if (showText) {
                            Text(
                                rawText.ifBlank { "(aucun texte)" },
                                fontFamily = FontFamily.Monospace,
                                style = MaterialTheme.typography.bodySmall,
                            )
                        }
                        Spacer(Modifier.size(80.dp))
                    }
                }
            }
        }
    }
}
