package fr.jeremy.calepin.text

/**
 * Signes de mise en forme des notes (gras, italique, barré, titres, liens) : où ils sont, pour les cacher
 * à l'écran (en lecture comme en écriture) tout en les gardant dans le texte enregistré.
 */
object MarkdownSigns {
    val headings = Regex("(?m)^(#{1,3}) (.+)$")
    val bold = Regex("\\*\\*(?!\\s)(.+?)(?<!\\s)\\*\\*")
    val italic = Regex("(?<![*\\w])\\*(?![*\\s])(.+?)(?<![*\\s])\\*(?![*\\w])")
    val strike = Regex("~~(?!\\s)(.+?)(?<!\\s)~~")
    val bullets = Regex("(?m)^\\s*[-•] ")
    /** Lien vers une autre note : [[Titre]]. */
    val links = Regex("\\[\\[([^\\[\\]\\n]{1,80})\\]\\]")
    /** Lien vers un site, une adresse mail ou un numéro : [texte](adresse). */
    val webLinks = Regex("(?<!\\[)\\[([^\\[\\]\\n]{1,200})\\]\\(((?:https?://|mailto:|tel:)[^\\s()]+)\\)")

    /**
     * Signes à cacher : (début, fin, après). [after] vrai : un curseur posé devant va après le signe
     * (début de titre), sinon il reste avant (on écrit avec la mise en forme d'avant).
     */
    fun hidden(text: String): List<DisplayMap.Hidden> {
        if (text.none { it == '*' || it == '~' || it == '#' || it == '[' }) return emptyList()
        val out = ArrayList<DisplayMap.Hidden>()
        headings.findAll(text).forEach { m ->
            val n = m.groupValues[1].length
            out += DisplayMap.Hidden(m.range.first, m.range.first + n + 1, true)
        }
        fun wrapped(rx: Regex, n: Int) = rx.findAll(text).forEach { m ->
            out += DisplayMap.Hidden(m.range.first, m.range.first + n, false)
            out += DisplayMap.Hidden(m.range.last + 1 - n, m.range.last + 1, false)
        }
        wrapped(bold, 2)
        wrapped(italic, 1)
        wrapped(strike, 2)
        links.findAll(text).forEach { m ->
            out += DisplayMap.Hidden(m.range.first, m.range.first + 2, false)
            out += DisplayMap.Hidden(m.range.last - 1, m.range.last + 1, false)
        }
        webLinks.findAll(text).forEach { m ->
            val labelEnd = m.groups[1]!!.range.last + 1
            out += DisplayMap.Hidden(m.range.first, m.range.first + 1, false)
            out += DisplayMap.Hidden(labelEnd, m.range.last + 1, false)
        }
        return out
    }

    /** Texte sans signes (partage, export) : les liens vers un site gardent leur adresse entre parenthèses. */
    fun plain(text: String): String {
        if (text.none { it == '*' || it == '~' || it == '#' || it == '[' }) return text
        var t = webLinks.replace(text) { m -> m.groupValues[1] + " (" + m.groupValues[2].removePrefix("mailto:").removePrefix("tel:") + ")" }
        t = links.replace(t) { it.groupValues[1] }
        t = bold.replace(t) { it.groupValues[1] }
        t = strike.replace(t) { it.groupValues[1] }
        t = italic.replace(t) { it.groupValues[1] }
        t = headings.replace(t) { it.groupValues[2] }
        return t
    }
}
