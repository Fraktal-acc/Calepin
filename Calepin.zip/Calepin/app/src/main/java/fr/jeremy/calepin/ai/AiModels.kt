package fr.jeremy.calepin.ai

import android.app.ActivityManager
import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL

/** Un modèle d'IA téléchargeable (format .litertlm de LiteRT-LM, libre d'accès sur Hugging Face). */
data class AiModel(
    val id: String,
    val label: String,
    val description: String,
    val url: String,
    val bytes: Long,
    /** Mémoire du téléphone conseillée, en Go. */
    val minRamGb: Int,
) {
    val sizeLabel: String get() = "%.1f Go".format(bytes / 1_000_000_000.0).replace('.', ',')
}

/** Catalogue, emplacement et téléchargement des modèles (avec reprise si la connexion coupe). */
object AiModels {
    val QWEN = AiModel(
        id = "qwen25-1.5b",
        label = "Qwen 2.5 · 1,5 milliard de paramètres",
        description = "Le plus rapide. Répond correctement en français aux questions simples sur tes notes.",
        url = "https://huggingface.co/litert-community/Qwen2.5-1.5B-Instruct/resolve/main/" +
            "Qwen2.5-1.5B-Instruct_multi-prefill-seq_q8_ekv4096.litertlm",
        bytes = 1_597_931_520L,
        minRamGb = 6,
    )
    val GEMMA = AiModel(
        id = "gemma4-e2b",
        label = "Gemma 4 E2B (Google)",
        description = "Plus intelligent et meilleur en français, mais plus lourd et un peu plus lent.",
        url = "https://huggingface.co/litert-community/gemma-4-E2B-it-litert-lm/resolve/main/gemma-4-E2B-it.litertlm",
        bytes = 2_588_147_712L,
        minRamGb = 8,
    )
    val all = listOf(QWEN, GEMMA)

    private fun prefs(ctx: Context) = ctx.getSharedPreferences("calepin_ai", Context.MODE_PRIVATE)

    fun dir(ctx: Context) = File(ctx.filesDir, "ia").apply { mkdirs() }
    fun file(ctx: Context, m: AiModel) = File(dir(ctx), m.id + ".litertlm")
    private fun part(ctx: Context, m: AiModel) = File(dir(ctx), m.id + ".part")
    private fun ready(ctx: Context, m: AiModel) = File(dir(ctx), m.id + ".ready")

    fun isInstalled(ctx: Context, m: AiModel) = ready(ctx, m).exists() && file(ctx, m).exists()

    /** Octets déjà téléchargés d'un téléchargement interrompu (0 si aucun). */
    fun partialBytes(ctx: Context, m: AiModel) = part(ctx, m).takeIf { it.exists() }?.length() ?: 0L

    /** Modèle utilisé par l'assistant : celui choisi s'il est installé, sinon le premier installé. */
    fun active(ctx: Context): AiModel? {
        val chosen = all.firstOrNull { it.id == prefs(ctx).getString("model", null) }
        return chosen?.takeIf { isInstalled(ctx, it) } ?: all.firstOrNull { isInstalled(ctx, it) }
    }

    fun select(ctx: Context, m: AiModel) { prefs(ctx).edit().putString("model", m.id).apply() }

    fun delete(ctx: Context, m: AiModel) {
        ready(ctx, m).delete(); file(ctx, m).delete(); part(ctx, m).delete()
    }

    /** Mémoire vive totale du téléphone, en Go. */
    fun totalRamGb(ctx: Context): Double {
        val mi = ActivityManager.MemoryInfo()
        (ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager).getMemoryInfo(mi)
        return mi.totalMem / 1_073_741_824.0
    }

    /** Espace libre pour les modèles, en octets. */
    fun freeBytes(ctx: Context) = dir(ctx).usableSpace

    /**
     * Télécharge (ou reprend) le modèle. [onProgress] reçoit (octets reçus, total).
     * Annulable : la partie déjà reçue est gardée pour reprendre plus tard.
     */
    suspend fun download(ctx: Context, m: AiModel, onProgress: (Long, Long) -> Unit) = withContext(Dispatchers.IO) {
        val partFile = part(ctx, m)
        val needed = m.bytes - partialBytes(ctx, m) + 50_000_000L
        if (freeBytes(ctx) < needed) {
            throw IllegalStateException("Pas assez de place : il faut environ ${"%.1f".format(needed / 1e9)} Go libres")
        }
        var done = partialBytes(ctx, m)
        val conn = open(m.url, done)
        try {
            val code = conn.responseCode
            when {
                code == 416 && done > 0 -> Unit // déjà entièrement reçu
                code == HttpURLConnection.HTTP_PARTIAL -> Unit
                code == HttpURLConnection.HTTP_OK -> { done = 0L; partFile.delete() } // le serveur ignore la reprise
                else -> throw IllegalStateException("Le serveur a répondu $code")
            }
            val total = if (code == HttpURLConnection.HTTP_PARTIAL || code == HttpURLConnection.HTTP_OK) {
                (conn.contentLengthLong.takeIf { it > 0 }?.plus(done)) ?: m.bytes
            } else done
            if (code != 416) {
                conn.inputStream.use { input ->
                    FileOutputStream(partFile, done > 0).use { out ->
                        val buf = ByteArray(256 * 1024)
                        var last = 0L
                        while (true) {
                            ensureActive()
                            val n = input.read(buf)
                            if (n < 0) break
                            out.write(buf, 0, n)
                            done += n
                            if (done - last > 2_000_000L) { last = done; onProgress(done, total) }
                        }
                    }
                }
            }
            onProgress(done, total)
            if (done < total) throw IllegalStateException("Téléchargement incomplet, réessayez pour le reprendre")
        } finally {
            conn.disconnect()
        }
        val target = file(ctx, m)
        target.delete()
        if (!partFile.renameTo(target)) throw IllegalStateException("Impossible d'enregistrer le modèle")
        ready(ctx, m).writeText("ok")
        select(ctx, m)
    }

    /** Ouvre la connexion en suivant les redirections (Hugging Face renvoie vers son CDN) et en gardant la reprise. */
    private fun open(url: String, from: Long): HttpURLConnection {
        var current = URL(url)
        repeat(6) {
            val c = (current.openConnection() as HttpURLConnection).apply {
                connectTimeout = 20_000
                readTimeout = 60_000
                instanceFollowRedirects = false
                setRequestProperty("User-Agent", "Calepin-IA/1.0 (Android)")
                if (from > 0) setRequestProperty("Range", "bytes=$from-")
            }
            val code = c.responseCode
            if (code in 300..399) {
                val loc = c.getHeaderField("Location") ?: throw IllegalStateException("Redirection sans adresse")
                c.disconnect()
                current = URL(current, loc)
            } else {
                return c
            }
        }
        throw IllegalStateException("Trop de redirections")
    }
}
