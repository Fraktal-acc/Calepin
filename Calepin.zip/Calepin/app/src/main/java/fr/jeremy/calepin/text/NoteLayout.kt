package fr.jeremy.calepin.text

/**
 * Mise en page des photos et vidéos dans le texte d'une note. Une ligne « {{photo:fichier.jpg}} » place
 * une vignette ; avec une position, « {{photo:fichier.jpg|right|40}} », la photo se met à droite (ou à
 * gauche) sur 40 % de la largeur et le texte qui suit passe à côté, puis dessous. « full » : pleine largeur.
 */
object NoteLayout {
    enum class Side(val code: String) { LEFT("left"), RIGHT("right"), FULL("full") }

    /** Photo placée : fichier, côté (null : vignette) et largeur en % de la page. */
    data class Spec(val video: Boolean, val file: String, val side: Side?, val width: Int) {
        val marker: String get() = "{{" + (if (video) "video" else "photo") + ":" + file +
            (if (side == null) "" else "|" + side.code + "|" + width) + "}}"
    }

    /** Repère n'importe où dans le texte (groupe 2 : le fichier, groupe 3 : les réglages). */
    val marker = Regex("\\{\\{(photo|video):([^}|\\n]+)(?:\\|([^}\\n]*))?\\}\\}")
    /** Repère seul sur sa ligne. */
    val markerAlone = Regex("(?m)^[ \\t]*\\{\\{(photo|video):([^}|\\n]+)(?:\\|([^}\\n]*))?\\}\\}[ \\t]*$")

    const val DEFAULT_WIDTH = 40

    fun specOf(m: MatchResult): Spec {
        val opts = m.groupValues[3].split('|').map { it.trim().lowercase() }
        val side = Side.entries.firstOrNull { it.code == opts.getOrNull(0) }
        val w = opts.getOrNull(1)?.toIntOrNull()?.coerceIn(20, 100) ?: if (side == Side.FULL) 100 else DEFAULT_WIDTH
        return Spec(m.groupValues[1] == "video", m.groupValues[2].trim(), side, w)
    }

    /** Photos seules sur leur ligne (celles qui s'affichent). */
    fun aloneFiles(text: String): Set<String> =
        if ("{{" !in text) emptySet() else markerAlone.findAll(text).map { it.groupValues[2].trim() }.toSet()

    /** Réglages de la photo [file] dans le texte (null : pas placée). */
    fun specFor(text: String, file: String): Spec? = marker.findAll(text).firstOrNull { it.groupValues[2].trim() == file }?.let { specOf(it) }

    /**
     * Morceau de la note en lecture : texte ([start], [end]), rangée de vignettes ([files]),
     * ou photo placée ([float]) avec le texte qui l'entoure ([start], [end]).
     */
    data class Segment(val start: Int, val end: Int, val files: List<String>?, val float: Spec? = null)

    fun segments(text: String): List<Segment> {
        val out = ArrayList<Segment>()
        var pos = 0
        var group: MutableList<String>? = null
        var float: Spec? = null
        fun skipNl() { if (pos < text.length && text[pos] == '\n') pos++ }
        fun close(e0: Int, last: Boolean) {
            group?.let { g ->
                out += Segment(pos, pos, g)
                group = null
                skipNl()
            }
            var e = e0
            if (!last && e > pos && text[e - 1] == '\n') e--
            val f = float
            if (f != null) {
                out += Segment(pos, maxOf(e, pos), null, f)
                float = null
            } else if (e > pos || (last && out.isEmpty())) {
                out += Segment(pos, maxOf(e, pos), null)
            }
            pos = maxOf(pos, e)
        }
        for (m in markerAlone.findAll(text)) {
            val spec = specOf(m)
            val g = group
            if (spec.side == null && g != null && text.substring(pos, m.range.first).isBlank()) {
                g += spec.file
                pos = m.range.last + 1
                continue
            }
            close(m.range.first, false)
            pos = m.range.last + 1
            if (spec.side == null) group = mutableListOf(spec.file)
            else { float = spec; skipNl() }
        }
        close(text.length, true)
        return out
    }

    /** Ligne entière du repère de [file] (avec son retour à la ligne), ou le repère seul s'il est dans une phrase. */
    private fun markerRange(text: String, file: String): IntRange? {
        markerAlone.findAll(text).firstOrNull { it.groupValues[2].trim() == file }?.let { m ->
            val s = m.range.first
            val e = m.range.last + 1
            return when {
                e < text.length && text[e] == '\n' -> s until e + 1
                s > 0 && text[s - 1] == '\n' -> (s - 1) until e
                else -> s until e
            }
        }
        return marker.findAll(text).firstOrNull { it.groupValues[2].trim() == file }?.range
    }

    /** Change la mise en page de [file] sur place. */
    fun setSpec(text: String, file: String, side: Side?, width: Int): String {
        val m = marker.findAll(text).firstOrNull { it.groupValues[2].trim() == file } ?: return text
        val s = specOf(m)
        val w = when {
            side == null -> s.width
            side == Side.FULL && s.side != Side.FULL -> 100
            side != Side.FULL && (s.side == null || s.side == Side.FULL) -> DEFAULT_WIDTH
            else -> width
        }
        return text.replaceRange(m.range, s.copy(side = side, width = w).marker)
    }

    /** Change seulement la taille (en % de la largeur). */
    fun setWidth(text: String, file: String, width: Int): String {
        val m = marker.findAll(text).firstOrNull { it.groupValues[2].trim() == file } ?: return text
        val s = specOf(m)
        if (s.side == null) return text
        return text.replaceRange(m.range, s.copy(width = width.coerceIn(20, 100)).marker)
    }

    /**
     * Déplace la photo [file] au début de la ligne qui commence en [target] (position dans le texte actuel),
     * avec ses nouveaux réglages. Le texte qui suit l'entoure.
     */
    fun move(text: String, file: String, side: Side?, width: Int, target: Int, video: Boolean = false): String {
        val old = specFor(text, file)
        val spec = Spec(old?.video ?: video, file, side, width.coerceIn(20, 100))
        val r = markerRange(text, file)
        var t = text
        var tgt = target.coerceIn(0, text.length)
        if (r != null) {
            t = text.removeRange(r)
            tgt = when {
                tgt >= r.last + 1 -> tgt - (r.last + 1 - r.first)
                tgt > r.first -> r.first
                else -> tgt
            }
        }
        tgt = tgt.coerceIn(0, t.length)
        // Toujours au début d'une ligne
        if (tgt > 0 && t[tgt - 1] != '\n') tgt = t.indexOf('\n', tgt).let { if (it < 0) t.length else it + 1 }
        if (tgt >= t.length) {
            val base = t
            return base + (if (base.isEmpty() || base.endsWith("\n")) "" else "\n") + spec.marker
        }
        return t.substring(0, tgt) + spec.marker + "\n" + t.substring(tgt)
    }
}
