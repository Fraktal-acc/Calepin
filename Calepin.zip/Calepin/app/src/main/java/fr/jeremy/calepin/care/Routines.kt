package fr.jeremy.calepin.care

import android.app.job.JobInfo
import android.app.job.JobParameters
import android.app.job.JobScheduler
import android.app.job.JobService
import android.content.ComponentName
import android.content.Context
import fr.jeremy.calepin.control.Scenario
import fr.jeremy.calepin.control.Scenarios
import fr.jeremy.calepin.i18n.I18n
import kotlinx.coroutines.runBlocking
import org.json.JSONArray
import org.json.JSONObject
import java.util.Calendar
import kotlin.math.abs

/** Déclenchement automatique d'un scénario. */
data class RoutineTrigger(
    /** "none", "time" (à heure fixe) ou "charger" (en branchant le chargeur). */
    val type: String = "none",
    /** Heure (minutes depuis minuit) pour « time » ; début de la plage horaire pour « charger ». */
    val minutes: Int = 22 * 60,
    /** Fin de la plage horaire pour « charger » (minutes) ; même valeur que [minutes] = toute la journée. */
    val until: Int = 22 * 60,
    /** Jours (bit 0 = lundi … bit 6 = dimanche). */
    val days: Int = 0b1111111,
) {
    fun toJson(): JSONObject = JSONObject().put("type", type).put("minutes", minutes).put("until", until).put("days", days)

    companion object {
        fun fromJson(o: JSONObject?) = if (o == null) RoutineTrigger() else RoutineTrigger(
            o.optString("type", "none"), o.optInt("minutes", 22 * 60), o.optInt("until", 22 * 60), o.optInt("days", 0b1111111),
        )
    }
}

/**
 * Routines : les scénarios peuvent se lancer seuls (à une heure donnée, ou en branchant le chargeur
 * dans une plage horaire), et « comme d'habitude » relance le scénario le plus utilisé à ce moment de la journée.
 */
object Routines {
    private fun p(ctx: Context) = ctx.applicationContext.getSharedPreferences("calepin_routines", Context.MODE_PRIVATE)

    fun trigger(ctx: Context, id: String): RoutineTrigger =
        RoutineTrigger.fromJson(runCatching { JSONObject(p(ctx).getString("t_$id", "") ?: "") }.getOrNull())

    fun setTrigger(ctx: Context, id: String, t: RoutineTrigger) {
        p(ctx).edit().putString("t_$id", t.toJson().toString()).apply()
        schedule(ctx)
    }

    private fun dayBit(c: Calendar) = 1 shl ((c.get(Calendar.DAY_OF_WEEK) + 5) % 7)
    private fun minutesOf(c: Calendar) = c.get(Calendar.HOUR_OF_DAY) * 60 + c.get(Calendar.MINUTE)

    fun schedule(ctx: Context) {
        val all = Scenarios.all(ctx)
        all.forEach { s ->
            val pi = Care.pending(ctx, Care.ACTION_ROUTINE, 7100 + (s.id.hashCode() and 0x3FF), s.id)
            Care.cancel(ctx, pi)
            val t = trigger(ctx, s.id)
            if (t.type == "time" && t.days != 0) {
                var at = Care.nextAt(t.minutes)
                for (k in 0 until 8) {
                    val c = Calendar.getInstance().apply { timeInMillis = at }
                    if (t.days and dayBit(c) != 0) break
                    at += 86_400_000L
                }
                Care.at(ctx, at, pi)
            }
        }
        // Chargeur : une tâche Android qui se réveille quand le téléphone se met à charger
        val js = ctx.getSystemService(JobScheduler::class.java) ?: return
        val anyCharger = all.any { trigger(ctx, it.id).type == "charger" }
        if (!anyCharger) { js.cancel(JOB_ID); return }
        if (js.allPendingJobs.none { it.id == JOB_ID }) {
            runCatching {
                js.schedule(
                    JobInfo.Builder(JOB_ID, ComponentName(ctx, ChargerJob::class.java))
                        .setRequiresCharging(true)
                        .setMinimumLatency(10 * 60_000L)
                        .setPersisted(true)
                        .build()
                )
            }
        }
    }

    const val JOB_ID = 7200

    fun runById(ctx: Context, id: String) {
        val s = Scenarios.all(ctx).firstOrNull { it.id == id } ?: return
        val t = trigger(ctx, id)
        if (t.days and dayBit(Calendar.getInstance()) == 0) return
        runNow(ctx, s)
    }

    private fun runNow(ctx: Context, s: Scenario) {
        val report = runBlocking { Scenarios.run(ctx, s) }
        p(ctx).edit().putLong("last_${s.id}", System.currentTimeMillis()).apply()
        Care.notify(ctx, 7300 + (s.id.hashCode() and 0xFF), I18n.trf("Routine « {0} »", s.name), report.lines().drop(1).joinToString("\n").ifBlank { report })
    }

    /** Chargeur branché : lance les routines « chargeur » de la plage horaire (une fois toutes les 6 heures au plus). */
    fun onCharger(ctx: Context, connected: Boolean) {
        if (!connected) return
        val now = Calendar.getInstance()
        val m = minutesOf(now)
        Scenarios.all(ctx).forEach { s ->
            val t = trigger(ctx, s.id)
            if (t.type != "charger" || t.days and dayBit(now) == 0) return@forEach
            val inWindow = if (t.minutes == t.until) true else if (t.minutes < t.until) m in t.minutes..t.until else (m >= t.minutes || m <= t.until)
            val last = p(ctx).getLong("last_${s.id}", 0L)
            if (inWindow && System.currentTimeMillis() - last > 6 * 3_600_000L) runNow(ctx, s)
        }
    }

    // ------------------------------------------------------------ « Comme d'habitude »

    /** Mémorise chaque scénario lancé (pour « comme d'habitude »). */
    fun recordRun(ctx: Context, id: String) {
        val a = runCatching { JSONArray(p(ctx).getString("history", "[]")) }.getOrDefault(JSONArray())
        val c = Calendar.getInstance()
        a.put(JSONObject().put("id", id).put("m", minutesOf(c)))
        val trimmed = JSONArray()
        for (i in maxOf(0, a.length() - 120) until a.length()) trimmed.put(a.get(i))
        p(ctx).edit().putString("history", trimmed.toString()).apply()
    }

    /** Le scénario le plus souvent lancé à ce moment de la journée (à 1 h 30 près). */
    fun usual(ctx: Context): Scenario? {
        val a = runCatching { JSONArray(p(ctx).getString("history", "[]")) }.getOrDefault(JSONArray())
        val m = minutesOf(Calendar.getInstance())
        val counts = HashMap<String, Int>()
        for (i in 0 until a.length()) {
            val o = a.getJSONObject(i)
            val d = abs(o.optInt("m") - m).let { minOf(it, 1440 - it) }
            if (d <= 90) counts[o.optString("id")] = (counts[o.optString("id")] ?: 0) + 1
        }
        val best = counts.maxByOrNull { it.value }?.key ?: return null
        return Scenarios.all(ctx).firstOrNull { it.id == best }
    }

    fun describe(t: RoutineTrigger): String {
        fun hm(v: Int) = "%d:%02d".format(v / 60, v % 60).let { if (I18n.language.value.code == "fr") it.replace(":", "h") else it }
        return when (t.type) {
            "time" -> I18n.trf("Tous les jours choisis à {0}", hm(t.minutes))
            "charger" -> if (t.minutes == t.until) I18n.tr("En branchant le chargeur") else I18n.trf("En branchant le chargeur entre {0} et {1}", hm(t.minutes), hm(t.until))
            else -> I18n.tr("À la demande seulement")
        }
    }
}

/** Réveillée par Android quand le téléphone se met à charger. */
class ChargerJob : JobService() {
    override fun onStartJob(params: JobParameters): Boolean {
        Thread {
            runCatching { Routines.onCharger(applicationContext, true) }
            jobFinished(params, false)
            // Reprogrammée pour la prochaine charge
            runCatching { applicationContext.getSystemService(JobScheduler::class.java)?.cancel(Routines.JOB_ID) }
            Routines.schedule(applicationContext)
        }.start()
        return true
    }

    override fun onStopJob(params: JobParameters): Boolean = false
}
