package fr.jeremy.calepin.control

import android.app.Notification
import android.app.PendingIntent
import android.app.RemoteInput
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import fr.jeremy.calepin.search.TextNorm
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.concurrent.ConcurrentHashMap

/**
 * Conversation WhatsApp ou Telegram suivie dans Calepin. [name] : nom affiché dans les notifications.
 * [me] : mon nom tel qu'il apparaît dans les historiques exportés (pour reconnaître mes messages).
 */
data class Conv(val app: String, val name: String, val phone: String = "", val user: String = "", val me: String = "") {
    val key get() = "$app|$name"
    fun toJson(): JSONObject = JSONObject().put("app", app).put("name", name).put("phone", phone).put("user", user).put("me", me)

    companion object {
        const val WHATSAPP = "whatsapp"
        const val TELEGRAM = "telegram"
        fun fromJson(o: JSONObject) = Conv(o.optString("app"), o.optString("name"), o.optString("phone"), o.optString("user"), o.optString("me"))
    }
}

/** Message d'une conversation. [media] : chemin du fichier (photo, vidéo, vocal, document) quand Calepin l'a retrouvé. */
data class Msg(val time: Long, val from: String, val text: String, val mine: Boolean = false, val media: String = "", val mime: String = "") {
    fun toJson(): JSONObject = JSONObject().put("t", time).put("f", from).put("x", text).put("m", mine).put("md", media).put("mt", mime)

    companion object {
        fun fromJson(o: JSONObject) = Msg(o.optLong("t"), o.optString("f"), o.optString("x"), o.optBoolean("m"), o.optString("md"), o.optString("mt"))
    }
}

/** Mail repéré dans les notifications de l'appli de messagerie (Gmail, Samsung Email, Outlook…). */
data class Mail(val id: String, val time: Long, val from: String, val subject: String, val body: String, val pkg: String, val account: String) {
    fun toJson(): JSONObject = JSONObject().put("id", id).put("t", time).put("f", from).put("s", subject).put("b", body).put("p", pkg).put("a", account)

    companion object {
        fun fromJson(o: JSONObject) = Mail(o.optString("id"), o.optLong("t"), o.optString("f"), o.optString("s"), o.optString("b"), o.optString("p"), o.optString("a"))
    }
}

/**
 * Messagerie de Calepin : lit les notifications de WhatsApp, Telegram et des applis de mail (avec l'accord
 * de l'utilisateur) pour les conversations et expéditeurs choisis seulement, et répond directement depuis
 * la notification quand l'appli le permet. Rien n'est envoyé ailleurs : tout reste sur le téléphone.
 */
object MessageHub {
    val WHATSAPP_PKGS = setOf("com.whatsapp", "com.whatsapp.w4b")
    val TELEGRAM_PKGS = setOf("org.telegram.messenger", "org.telegram.messenger.web", "org.telegram.plus", "org.thunderdog.challegram")
    val MAIL_PKGS = setOf(
        "com.google.android.gm", "com.samsung.android.email.provider", "com.microsoft.office.outlook", "com.yahoo.mobile.client.android.mail",
        "ch.protonmail.android", "com.fsck.k9", "net.thunderbird.android", "com.orange.mail.fr", "fr.laposte.lapostemail", "com.free.mail",
    )

    private val _convs = MutableStateFlow<List<Conv>>(emptyList())
    val convs: StateFlow<List<Conv>> = _convs
    private val _messages = MutableStateFlow<Map<String, List<Msg>>>(emptyMap())
    val messages: StateFlow<Map<String, List<Msg>>> = _messages
    private val _mailRules = MutableStateFlow<List<String>>(emptyList())
    val mailRules: StateFlow<List<String>> = _mailRules
    private val _mails = MutableStateFlow<List<Mail>>(emptyList())
    val mails: StateFlow<List<Mail>> = _mails
    /** Noms vus récemment dans les notifications (pour ajouter une conversation sans se tromper d'orthographe). */
    private val _recent = MutableStateFlow<List<Pair<String, String>>>(emptyList())
    val recent: StateFlow<List<Pair<String, String>>> = _recent

    /** Réponses possibles depuis la notification (tant qu'elle est affichée) : clé de conversation → action. */
    private val replies = ConcurrentHashMap<String, Notification.Action>()
    private val opens = ConcurrentHashMap<String, PendingIntent>()

    @Volatile private var loaded = false
    private lateinit var app: Context

    private fun prefs() = app.getSharedPreferences("calepin_messages", Context.MODE_PRIVATE)
    private fun file() = File(app.filesDir, "messages.json")

    fun init(ctx: Context) {
        if (loaded) return
        synchronized(this) {
            if (loaded) return
            app = ctx.applicationContext
            runCatching {
                val a = JSONArray(prefs().getString("convs", "[]"))
                _convs.value = (0 until a.length()).map { Conv.fromJson(a.getJSONObject(it)) }
                val r = JSONArray(prefs().getString("mail_rules", "[]"))
                _mailRules.value = (0 until r.length()).map { r.getString(it) }
                val rc = JSONArray(prefs().getString("recent", "[]"))
                _recent.value = (0 until rc.length()).map { rc.getJSONArray(it).let { p -> p.getString(0) to p.getString(1) } }
            }
            runCatching {
                val o = JSONObject(file().readText())
                val c = o.optJSONObject("conv") ?: JSONObject()
                _messages.value = c.keys().asSequence().associateWith { k ->
                    val a = c.getJSONArray(k)
                    (0 until a.length()).map { Msg.fromJson(a.getJSONObject(it)) }
                }
                val m = o.optJSONArray("mail") ?: JSONArray()
                _mails.value = (0 until m.length()).map { Mail.fromJson(m.getJSONObject(it)) }
            }
            loaded = true
        }
    }

    private fun saveConfig() {
        prefs().edit()
            .putString("convs", JSONArray().apply { _convs.value.forEach { put(it.toJson()) } }.toString())
            .putString("mail_rules", JSONArray(_mailRules.value).toString())
            .putString("recent", JSONArray().apply { _recent.value.forEach { (a, n) -> put(JSONArray(listOf(a, n))) } }.toString())
            .apply()
    }

    /** Messages gardés par conversation (les historiques importés peuvent être longs). */
    const val MAX_PER_CONV = 20_000

    /** Écriture sur un fil à part : l'arrivée d'une notification ne bloque jamais, même avec un long historique. */
    private val writer = java.util.concurrent.Executors.newSingleThreadExecutor()

    private fun saveData() {
        val msgs = _messages.value
        val mails = _mails.value
        writer.execute {
            runCatching {
                val c = JSONObject()
                msgs.forEach { (k, l) -> c.put(k, JSONArray().apply { l.forEach { put(it.toJson()) } }) }
                // Fichier temporaire puis renommage : jamais de fichier à moitié écrit
                val tmp = File(file().path + ".tmp")
                tmp.writeText(JSONObject().put("conv", c).put("mail", JSONArray().apply { mails.forEach { put(it.toJson()) } }).toString())
                if (!tmp.renameTo(file())) { file().delete(); tmp.renameTo(file()) }
            }
        }
    }

    /** Remplace les messages d'une conversation (import d'historique). */
    fun setMessages(ctx: Context, key: String, list: List<Msg>) {
        init(ctx)
        _messages.value = _messages.value + (key to list.sortedBy { it.time }.takeLast(MAX_PER_CONV))
        saveData()
    }

    /** Dossier des fichiers des messages (photos, vocaux…). */
    fun mediaFolder(ctx: Context): File = mediaDir(ctx)

    // ------------------------------------------------------------------ Réglages

    fun addConv(ctx: Context, c: Conv) {
        init(ctx)
        _convs.value = _convs.value.filter { it.key != c.key } + c
        saveConfig()
    }

    fun removeConv(ctx: Context, c: Conv) {
        init(ctx)
        _convs.value = _convs.value.filter { it.key != c.key }
        _messages.value = _messages.value - c.key
        saveConfig(); saveData()
    }

    fun clearConv(ctx: Context, c: Conv) {
        init(ctx)
        _messages.value = _messages.value - c.key
        saveData()
    }

    fun addMailRule(ctx: Context, rule: String) {
        init(ctx)
        val r = rule.trim()
        if (r.isNotEmpty() && _mailRules.value.none { it.equals(r, true) }) { _mailRules.value = _mailRules.value + r; saveConfig() }
    }

    fun removeMailRule(ctx: Context, rule: String) {
        init(ctx)
        _mailRules.value = _mailRules.value - rule
        saveConfig()
    }

    fun deleteMail(ctx: Context, id: String) {
        init(ctx)
        _mails.value = _mails.value.filter { it.id != id }
        saveData()
    }

    fun hasAccess(ctx: Context) = NotificationManagerCompat.getEnabledListenerPackages(ctx).contains(ctx.packageName)

    fun openAccessSettings(ctx: Context) {
        fr.jeremy.calepin.LockGuard.external()
        val i = if (android.os.Build.VERSION.SDK_INT >= 30) {
            Intent(Settings.ACTION_NOTIFICATION_LISTENER_DETAIL_SETTINGS)
                .putExtra(Settings.EXTRA_NOTIFICATION_LISTENER_COMPONENT_NAME, ComponentName(ctx, MessagesListener::class.java).flattenToString())
        } else Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS")
        runCatching { ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
            .onFailure { runCatching { ctx.startActivity(Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } }
    }

    // ------------------------------------------------------------------ Lecture des notifications

    private fun appOf(pkg: String) = when (pkg) {
        in WHATSAPP_PKGS -> Conv.WHATSAPP
        in TELEGRAM_PKGS -> Conv.TELEGRAM
        in MAIL_PKGS -> "mail"
        else -> null
    }

    /** « Famille (3 messages) », « Marc: » … → nom de la conversation. */
    private fun cleanName(s: String) = s.replace(Regex("\\s*\\(\\d+[^)]*\\)\\s*$"), "").trim().trimEnd(':').trim()

    fun onPosted(ctx: Context, sbn: StatusBarNotification) {
        init(ctx)
        val n = sbn.notification ?: return
        if (n.flags and Notification.FLAG_GROUP_SUMMARY != 0) return
        val kind = appOf(sbn.packageName) ?: return
        val ex = n.extras ?: return
        if (kind == "mail") { onMail(sbn, n, ex); return }

        val style = NotificationCompat.MessagingStyle.extractMessagingStyleFromNotification(n)
        val rawTitle = (style?.conversationTitle ?: ex.getCharSequence(Notification.EXTRA_TITLE))?.toString() ?: return
        // WhatsApp de groupe : « Marc @ Famille »
        val name = cleanName(rawTitle.substringAfter(" @ ", rawTitle))
        if (name.isBlank() || name.equals("WhatsApp", true) || name.equals("Telegram", true)) return
        remember(kind, name)

        val key = "$kind|$name"
        n.actions?.firstOrNull { a -> a.remoteInputs?.any { it.allowFreeFormInput } == true }?.let { replies[key] = it }
        n.contentIntent?.let { opens[key] = it }

        val conv = _convs.value.firstOrNull { it.app == kind && TextNorm.norm(it.name) == TextNorm.norm(name) } ?: return
        if (conv.key != key) {
            replies[conv.key]?.let { } ?: replies[key]?.let { replies[conv.key] = it }
            opens[key]?.let { opens[conv.key] = it }
        }
        val incoming0 = style?.messages?.mapNotNull { m ->
            val t = m.text?.toString() ?: return@mapNotNull null
            // Image jointe à la notification (quand l'appli la partage) : copiée dans Calepin
            val (path, mime) = copyData(ctx, m.dataUri, m.dataMimeType, m.timestamp)
            // Sans expéditeur : message envoyé depuis ce téléphone
            Msg(m.timestamp, m.person?.name?.toString() ?: "", t, mine = m.person == null, media = path, mime = mime)
        } ?: listOfNotNull(ex.getCharSequence(Notification.EXTRA_TEXT)?.toString()?.let { Msg(sbn.postTime, name, it) })
        // Grande image de la notification : pour le dernier message reçu sans fichier
        @Suppress("DEPRECATION") val picture = runCatching { ex.get(Notification.EXTRA_PICTURE) as? android.graphics.Bitmap }.getOrNull()
        val incoming = if (picture != null && incoming0.isNotEmpty() && incoming0.last().media.isEmpty() && !incoming0.last().mine) {
            val last = incoming0.last()
            val saved = saveBitmap(ctx, picture, last.time)
            if (saved != null) incoming0.dropLast(1) + last.copy(media = saved, mime = "image/jpeg") else incoming0
        } else incoming0
        if (incoming.isEmpty()) return
        val old = _messages.value[conv.key].orEmpty()
        val recentOld = old.takeLast(300)
        // Même message déjà là (reçu plus tôt, ou importé d'un historique où l'heure est à la minute près)
        val added = incoming.filter { m ->
            recentOld.none { (it.time == m.time && it.text == m.text) || (kotlin.math.abs(it.time - m.time) <= 90_000 && ChatParsers.sameText(it.text, m.text)) }
        }
        if (added.isEmpty()) return
        _messages.value = _messages.value + (conv.key to (old + added).sortedBy { it.time }.takeLast(MAX_PER_CONV))
        saveData()
    }

    // ------------------------------------------------------------------ Photos, vidéos, vocaux, documents

    private fun mediaDir(ctx: Context) = File(ctx.filesDir, "msg_media").apply { mkdirs() }

    private fun copyData(ctx: Context, uri: Uri?, mime: String?, time: Long): Pair<String, String> {
        if (uri == null) return "" to ""
        return runCatching {
            val m = mime ?: ctx.contentResolver.getType(uri) ?: "application/octet-stream"
            val ext = android.webkit.MimeTypeMap.getSingleton().getExtensionFromMimeType(m) ?: "bin"
            val f = File(mediaDir(ctx), "${time}_${uri.hashCode().toUInt()}.$ext")
            if (!f.exists()) ctx.contentResolver.openInputStream(uri)!!.use { input -> f.outputStream().use { input.copyTo(it) } }
            if (f.length() == 0L) { f.delete(); "" to "" } else f.path to m
        }.getOrDefault("" to "")
    }

    private fun saveBitmap(ctx: Context, b: android.graphics.Bitmap, time: Long): String? = runCatching {
        val f = File(mediaDir(ctx), "${time}_pic.jpg")
        if (!f.exists()) f.outputStream().use { b.compress(android.graphics.Bitmap.CompressFormat.JPEG, 90, it) }
        f.path
    }.getOrNull()

    /** Type de contenu d'après le libellé de la notification (« 🎤 Message vocal (0:12) », « 📷 Photo »…). */
    fun kindOf(text: String): String? {
        val t = text.lowercase()
        return when {
            "🎤" in text || "🎙" in text || Regex("message vocal|voice message|messaggio vocale|mensaje de voz|sprachnachricht|nota vocale|^audio").containsMatchIn(t) -> "voice"
            "📷" in text || "🖼" in text || Regex("^(photo|image|foto|bild)\\b").containsMatchIn(t) -> "image"
            "🎥" in text || "📹" in text || "🎬" in text || Regex("^(vid[ée]o|video|gif)\\b").containsMatchIn(t) -> "video"
            "📄" in text || "📎" in text || Regex("^(document|fichier|file|datei)\\b").containsMatchIn(t) -> "file"
            else -> null
        }
    }

    /** Dossiers publics où WhatsApp (et Telegram, avec « Enregistrer dans la galerie ») range les fichiers reçus. */
    private fun mediaFolders(app: String, kind: String): List<File> {
        val root = android.os.Environment.getExternalStorageDirectory()
        val suffixes = when (kind) {
            "voice" -> listOf("Voice Notes", "Audio")
            "image" -> listOf("Images")
            "video" -> listOf("Video", "Animated Gifs")
            else -> listOf("Documents")
        }
        if (app == Conv.TELEGRAM) {
            // Telegram ne range ses fichiers en public qu'avec « Enregistrer dans la galerie / les téléchargements »
            val direct = when (kind) {
                "image" -> "Pictures/Telegram"
                "video" -> "Movies/Telegram"
                "voice" -> "Music/Telegram"
                else -> "Download/Telegram"
            }
            val old = File(root, "Telegram").listFiles()?.filter { d -> d.isDirectory && suffixes.any { d.name.endsWith(it, ignoreCase = true) } }.orEmpty()
            return listOf(File(root, direct)).filter { it.isDirectory } + old
        }
        val bases = listOf(
            "Android/media/com.whatsapp/WhatsApp/Media", "WhatsApp/Media",
            "Android/media/com.whatsapp.w4b/WhatsApp Business/Media", "WhatsApp Business/Media",
        )
        return bases.map { File(root, it) }.filter { it.isDirectory }.flatMap { b ->
            b.listFiles()?.filter { d -> d.isDirectory && suffixes.any { d.name.endsWith(it, ignoreCase = true) } }.orEmpty()
        }
    }

    private fun filesIn(dir: File, depth: Int = 2): List<File> =
        dir.listFiles()?.flatMap { f ->
            when {
                f.isDirectory && depth > 0 && !f.name.equals("Sent", true) && !f.name.equals("Private", true) && !f.name.startsWith(".") -> filesIn(f, depth - 1)
                f.isFile && !f.name.startsWith(".") && f.name != ".nomedia" -> listOf(f)
                else -> emptyList()
            }
        }.orEmpty()

    /**
     * Retrouve les fichiers des messages reçus (photos, vidéos, vocaux, documents) dans les dossiers de l'appli,
     * d'après l'heure d'arrivée (avec l'accès à tous les fichiers). Renvoie vrai si de nouveaux fichiers ont été trouvés.
     */
    suspend fun resolveMedia(ctx: Context, conv: Conv): Boolean = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
        init(ctx)
        if (!fr.jeremy.calepin.tools.StorageAccess.granted(ctx)) return@withContext false
        val list = _messages.value[conv.key].orEmpty()
        val todo = list.filter { it.media.isEmpty() && !it.mine && kindOf(it.text) != null }
        if (todo.isEmpty()) return@withContext false
        val used = _messages.value.values.flatten().map { it.media }.filter { it.isNotEmpty() }.toMutableSet()
        val cache = HashMap<String, List<File>>()
        var changed = false
        val updated = list.map { m ->
            if (m.media.isNotEmpty() || m.mine) return@map m
            val kind = kindOf(m.text) ?: return@map m
            val files = cache.getOrPut(kind) { mediaFolders(conv.app, kind).flatMap { filesIn(it) } }
            // Fichier écrit entre 2 minutes avant et 30 minutes après le message (téléchargement)
            val best = files.filter { it.path !in used && it.lastModified() in (m.time - 120_000)..(m.time + 1_800_000) }
                .minByOrNull { kotlin.math.abs(it.lastModified() - m.time) } ?: return@map m
            used += best.path
            changed = true
            val mime = android.webkit.MimeTypeMap.getSingleton().getMimeTypeFromExtension(best.extension.lowercase())
                ?: when (kind) { "voice" -> "audio/ogg"; "image" -> "image/jpeg"; "video" -> "video/mp4"; else -> "application/octet-stream" }
            m.copy(media = best.path, mime = mime)
        }
        if (changed) {
            _messages.value = _messages.value + (conv.key to updated)
            saveData()
        }
        changed
    }

    private fun remember(kind: String, name: String) {
        val p = kind to name
        if (_recent.value.firstOrNull() == p) return
        _recent.value = (listOf(p) + _recent.value.filter { it != p }).take(40)
        saveConfig()
    }

    private fun onMail(sbn: StatusBarNotification, n: Notification, ex: Bundle) {
        val from = ex.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty()
        val subject = ex.getCharSequence(Notification.EXTRA_TEXT)?.toString().orEmpty()
        val body = ex.getCharSequence(Notification.EXTRA_BIG_TEXT)?.toString().orEmpty()
        val account = (ex.getCharSequence(Notification.EXTRA_SUB_TEXT) ?: ex.getCharSequence(Notification.EXTRA_SUMMARY_TEXT))?.toString().orEmpty()
        if (from.isBlank()) return
        remember("mail", from)
        val hay = "$from\n$subject\n$body\n$account".lowercase()
        if (_mailRules.value.none { hay.contains(it.lowercase()) }) return
        val id = sbn.key + "|" + sbn.postTime
        if (_mails.value.any { it.from == from && it.subject == subject && kotlin.math.abs(it.time - sbn.postTime) < 120_000 }) return
        n.contentIntent?.let { opens["mail|$id"] = it }
        _mails.value = (listOf(Mail(id, sbn.postTime, from, subject, body, sbn.packageName, account)) + _mails.value).take(300)
        saveData()
    }

    // ------------------------------------------------------------------ Envoi

    fun canReplyDirectly(key: String) = replies.containsKey(key)

    /** Cherche une conversation par nom (suivie, ou vue récemment) pour une appli. */
    fun findByName(ctx: Context, app: String, who: String): Conv? {
        init(ctx)
        val w = TextNorm.norm(who)
        _convs.value.filter { it.app == app }.firstOrNull { TextNorm.norm(it.name) == w }?.let { return it }
        _convs.value.filter { it.app == app }.firstOrNull { TextNorm.norm(it.name).contains(w) }?.let { return it }
        _recent.value.firstOrNull { it.first == app && TextNorm.norm(it.second) == w }?.let { return Conv(app, it.second) }
        _recent.value.firstOrNull { it.first == app && TextNorm.norm(it.second).contains(w) }?.let { return Conv(app, it.second) }
        return null
    }

    /**
     * Envoie [text] : directement par la notification si possible (le message part vraiment),
     * sinon en ouvrant l'appli avec le message prêt. Renvoie vrai si le message est parti.
     */
    fun send(ctx: Context, conv: Conv, text: String): Boolean {
        if (replyDirect(ctx, conv, text)) return true
        openApp(ctx, conv, text)
        return false
    }

    /** Réponse directe par la notification (le message part sans ouvrir l'appli). */
    fun replyDirect(ctx: Context, conv: Conv, text: String): Boolean {
        init(ctx)
        val action = replies[conv.key]
        if (action != null) {
            val ok = runCatching {
                val inputs = action.remoteInputs.filter { it.allowFreeFormInput }.toTypedArray()
                val intent = Intent()
                val b = Bundle()
                inputs.forEach { b.putCharSequence(it.resultKey, text) }
                RemoteInput.addResultsToIntent(inputs, intent, b)
                action.actionIntent.send(ctx, 0, intent)
            }.isSuccess
            if (ok) {
                replies.remove(conv.key) // une réponse par notification ; la suivante arrivera avec le prochain message
                addMine(conv, text)
                return true
            }
        }
        return false
    }

    private fun addMine(conv: Conv, text: String) {
        if (_convs.value.none { it.key == conv.key }) return
        val old = _messages.value[conv.key].orEmpty()
        _messages.value = _messages.value + (conv.key to (old + Msg(System.currentTimeMillis(), "", text, mine = true)).takeLast(MAX_PER_CONV))
        saveData()
    }

    /** Numéro au format international sans « + » (06… → 336…). */
    private fun digitsOf(phone: String) = phone.filter { it.isDigit() || it == '+' }.let { d ->
        when {
            d.startsWith("+") -> d.drop(1)
            d.startsWith("00") -> d.drop(2)
            d.startsWith("0") && d.length == 10 -> "33" + d.drop(1)
            else -> d
        }
    }.filter { it.isDigit() }

    private fun installed(ctx: Context, pkgs: Collection<String>) =
        pkgs.firstOrNull { p -> runCatching { ctx.packageManager.getPackageInfo(p, 0) }.isSuccess }

    /** Comment l'appli a été ouverte : directement sur la conversation, ou sur la liste de partage. */
    enum class Opened { CHAT, SHARE, NONE }

    /** Ouvre la conversation dans WhatsApp ou Telegram (avec le message prêt quand c'est possible). */
    fun openApp(ctx: Context, conv: Conv, text: String = ""): Opened {
        fr.jeremy.calepin.LockGuard.external()
        val digits = digitsOf(conv.phone)
        val user = conv.user.trim().removePrefix("@").removePrefix("https://t.me/").trim('/')
        val enc = Uri.encode(text)
        val (i, how) = when (conv.app) {
            Conv.WHATSAPP -> when {
                digits.isNotEmpty() -> Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/$digits" + if (text.isNotEmpty()) "?text=$enc" else "")) to Opened.CHAT
                text.isNotEmpty() -> Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, text)
                    .setPackage(installed(ctx, WHATSAPP_PKGS) ?: "com.whatsapp") to Opened.SHARE
                else -> null to Opened.NONE
            }
            else -> when {
                user.isNotEmpty() -> Intent(Intent.ACTION_VIEW, Uri.parse("tg://resolve?domain=$user" + if (text.isNotEmpty()) "&text=$enc" else "")) to Opened.CHAT
                digits.isNotEmpty() -> Intent(Intent.ACTION_VIEW, Uri.parse("tg://resolve?phone=$digits" + if (text.isNotEmpty()) "&text=$enc" else "")) to Opened.CHAT
                text.isNotEmpty() -> Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, text)
                    .setPackage(installed(ctx, TELEGRAM_PKGS) ?: "org.telegram.messenger") to Opened.SHARE
                else -> null to Opened.NONE
            }
        }
        // Sans numéro ni texte : la notification de la conversation l'ouvre directement
        if (i == null || (text.isEmpty() && opens[conv.key] != null)) {
            opens[conv.key]?.let { if (runCatching { it.send() }.isSuccess) return Opened.CHAT }
        }
        val target = i ?: ctx.packageManager.getLaunchIntentForPackage(
            (if (conv.app == Conv.WHATSAPP) installed(ctx, WHATSAPP_PKGS) else installed(ctx, TELEGRAM_PKGS)) ?: "com.whatsapp",
        )
        val ok = target?.let { runCatching { ctx.startActivity(it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }.isSuccess } == true
        return if (ok) how else Opened.NONE
    }

    /** Résultat d'un envoi : parti tout seul, envoyé automatiquement par Calepin IA, ou prêt dans l'appli. */
    enum class Delivery { SENT, AUTO, READY, FAILED }

    /**
     * Envoie un texte au mieux : réponse directe (notification), sinon l'appli s'ouvre avec le message prêt
     * et l'envoi automatique (Calepin IA, si activé) touche « Envoyer ».
     */
    fun deliver(ctx: Context, conv: Conv, text: String): Delivery {
        init(ctx)
        if (replyDirect(ctx, conv, text)) return Delivery.SENT
        val auto = WhatsAppSender.autoFor(ctx, conv.app)
        val digits = digitsOf(conv.phone)
        val share = if (conv.app == Conv.WHATSAPP) digits.isEmpty() else conv.user.isBlank() && digits.isEmpty()
        if (auto) WhatsAppSender.armText(conv.app, text, shareTarget = if (share) conv.name else null)
        val how = openApp(ctx, conv, text)
        if (how == Opened.NONE) { WhatsAppSender.disarm(); return Delivery.FAILED }
        addMine(conv, text)
        return if (auto) Delivery.AUTO else Delivery.READY
    }

    /**
     * Envoie des fichiers (photos, vidéos, PDF, message vocal…) dans la conversation. WhatsApp avec numéro :
     * la conversation s'ouvre directement ; sinon la liste de partage de l'appli (choix automatique de la
     * conversation avec l'envoi automatique de Calepin IA).
     */
    fun sendFiles(ctx: Context, conv: Conv, files: List<Pair<java.io.File, String>>, caption: String = ""): Delivery {
        init(ctx)
        if (files.isEmpty()) return Delivery.FAILED
        fr.jeremy.calepin.LockGuard.external()
        val pkg = (if (conv.app == Conv.WHATSAPP) installed(ctx, WHATSAPP_PKGS) else installed(ctx, TELEGRAM_PKGS)) ?: return Delivery.FAILED
        val uris = ArrayList(files.map { fr.jeremy.calepin.Files.uriFor(ctx, it.first) })
        val types = files.map { it.second }.distinct()
        val mime = types.singleOrNull() ?: types.map { it.substringBefore('/') }.distinct().singleOrNull()?.let { "$it/*" } ?: "*/*"
        val i = if (uris.size == 1) Intent(Intent.ACTION_SEND).putExtra(Intent.EXTRA_STREAM, uris[0])
        else Intent(Intent.ACTION_SEND_MULTIPLE).putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris)
        i.type = mime
        i.setPackage(pkg)
        if (caption.isNotBlank()) i.putExtra(Intent.EXTRA_TEXT, caption)
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        val digits = digitsOf(conv.phone)
        // WhatsApp : ouverture directe de la conversation avec le numéro
        if (conv.app == Conv.WHATSAPP && digits.isNotEmpty()) i.putExtra("jid", "$digits@s.whatsapp.net")
        val direct = conv.app == Conv.WHATSAPP && digits.isNotEmpty()
        val auto = WhatsAppSender.autoFor(ctx, conv.app)
        if (auto) WhatsAppSender.armMedia(conv.app, shareTarget = if (direct) null else conv.name)
        val ok = runCatching { ctx.startActivity(i) }.isSuccess
        if (!ok) { WhatsAppSender.disarm(); return Delivery.FAILED }
        val label = files.joinToString(", ") { f ->
            when {
                f.second.startsWith("audio") -> "🎤 " + fr.jeremy.calepin.i18n.I18n.tr("Message vocal")
                f.second.startsWith("image") -> "📷 " + f.first.name
                f.second.startsWith("video") -> "🎥 " + f.first.name
                else -> "📄 " + f.first.name
            }
        }
        addMine(conv, label)
        return if (auto) Delivery.AUTO else Delivery.READY
    }

    /** Ouvre le mail dans son appli (tant que la notification existe), sinon l'appli de mail. */
    fun openMail(ctx: Context, m: Mail) {
        fr.jeremy.calepin.LockGuard.external()
        opens["mail|${m.id}"]?.let { if (runCatching { it.send() }.isSuccess) return }
        ctx.packageManager.getLaunchIntentForPackage(m.pkg)?.let { runCatching { ctx.startActivity(it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } }
    }
}

/** Reçoit les notifications (après accord de l'utilisateur dans les réglages d'Android). */
class MessagesListener : NotificationListenerService() {
    override fun onListenerConnected() {
        runCatching { activeNotifications?.forEach { MessageHub.onPosted(this, it) } }
    }

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        if (sbn == null) return
        runCatching { MessageHub.onPosted(this, sbn) }
            .onFailure { fr.jeremy.calepin.care.CrashLog.note(this, "lecture des notifications", it) }
    }
}
