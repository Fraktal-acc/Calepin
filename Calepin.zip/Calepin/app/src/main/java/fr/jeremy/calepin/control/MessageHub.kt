package fr.jeremy.calepin.control

import android.app.Notification
import android.app.PendingIntent
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import androidx.core.app.NotificationManagerCompat
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.concurrent.ConcurrentHashMap

/** Mail repéré dans les notifications de l'appli de messagerie (Gmail, Samsung Email, Outlook…). */
data class Mail(val id: String, val time: Long, val from: String, val subject: String, val body: String, val pkg: String, val account: String) {
    fun toJson(): JSONObject = JSONObject().put("id", id).put("t", time).put("f", from).put("s", subject).put("b", body).put("p", pkg).put("a", account)

    companion object {
        fun fromJson(o: JSONObject) = Mail(o.optString("id"), o.optLong("t"), o.optString("f"), o.optString("s"), o.optString("b"), o.optString("p"), o.optString("a"))
    }
}

/**
 * Mails de Calepin vus par les notifications : lit les notifications des applis de mail (avec l'accord
 * de l'utilisateur) pour les expéditeurs choisis seulement. Rien n'est envoyé ailleurs : tout reste sur le téléphone.
 */
object MessageHub {
    val MAIL_PKGS = setOf(
        "com.google.android.gm", "com.samsung.android.email.provider", "com.microsoft.office.outlook", "com.yahoo.mobile.client.android.mail",
        "ch.protonmail.android", "com.fsck.k9", "net.thunderbird.android", "com.orange.mail.fr", "fr.laposte.lapostemail", "com.free.mail",
    )

    private val _mailRules = MutableStateFlow<List<String>>(emptyList())
    val mailRules: StateFlow<List<String>> = _mailRules
    private val _mails = MutableStateFlow<List<Mail>>(emptyList())
    val mails: StateFlow<List<Mail>> = _mails
    /** Expéditeurs vus récemment dans les notifications (pour suivre une adresse sans se tromper d'orthographe). */
    private val _recent = MutableStateFlow<List<String>>(emptyList())
    val recent: StateFlow<List<String>> = _recent

    private val opens = ConcurrentHashMap<String, PendingIntent>()

    @Volatile private var loaded = false
    private lateinit var app: Context

    private fun prefs() = app.getSharedPreferences("calepin_messages", Context.MODE_PRIVATE)
    private fun file() = File(app.filesDir, "messages.json")

    fun init(ctx: Context) {
        if (loaded) return
        synchronized(this) {
            if (loaded) return
            app = ctx.applicationContext
            runCatching {
                val r = JSONArray(prefs().getString("mail_rules", "[]"))
                _mailRules.value = (0 until r.length()).map { r.getString(it) }
                // Ancien format : paires [appli, nom] ; on ne garde que les expéditeurs de mails
                val rc = JSONArray(prefs().getString("recent", "[]"))
                _recent.value = (0 until rc.length()).mapNotNull { i ->
                    val p = rc.optJSONArray(i)
                    if (p != null) p.optString(1).takeIf { p.optString(0) == "mail" && it.isNotBlank() } else rc.optString(i).takeIf { it.isNotBlank() }
                }
            }
            runCatching {
                val o = JSONObject(file().readText())
                val m = o.optJSONArray("mail") ?: JSONArray()
                _mails.value = (0 until m.length()).map { Mail.fromJson(m.getJSONObject(it)) }
            }
            loaded = true
            cleanupChats()
        }
    }

    /** Une seule fois : efface ce qui restait de WhatsApp et Telegram (conversations, fichiers, réglages). */
    private fun cleanupChats() {
        val p = prefs()
        if (p.getBoolean("chats_removed", false)) return
        runCatching { File(app.filesDir, "msg_media").deleteRecursively() }
        runCatching { File(app.cacheDir, "chat_import").deleteRecursively() }
        runCatching { app.getSharedPreferences("calepin_chat_sync", Context.MODE_PRIVATE).edit().clear().apply() }
        p.edit().remove("convs").putBoolean("chats_removed", true).apply()
        saveConfig()
        saveData()
    }

    private fun saveConfig() {
        prefs().edit()
            .putString("mail_rules", JSONArray(_mailRules.value).toString())
            .putString("recent", JSONArray(_recent.value).toString())
            .apply()
    }

    /** Écriture sur un fil à part : l'arrivée d'une notification ne bloque jamais. */
    private val writer = java.util.concurrent.Executors.newSingleThreadExecutor()

    private fun saveData() {
        val mails = _mails.value
        writer.execute {
            runCatching {
                // Fichier temporaire puis renommage : jamais de fichier à moitié écrit
                val tmp = File(file().path + ".tmp")
                tmp.writeText(JSONObject().put("mail", JSONArray().apply { mails.forEach { put(it.toJson()) } }).toString())
                if (!tmp.renameTo(file())) { file().delete(); tmp.renameTo(file()) }
            }
        }
    }

    // ------------------------------------------------------------------ Réglages

    fun addMailRule(ctx: Context, rule: String) {
        init(ctx)
        val r = rule.trim()
        if (r.isNotEmpty() && _mailRules.value.none { it.equals(r, true) }) { _mailRules.value = _mailRules.value + r; saveConfig() }
    }

    fun removeMailRule(ctx: Context, rule: String) {
        init(ctx)
        _mailRules.value = _mailRules.value - rule
        saveConfig()
    }

    fun deleteMail(ctx: Context, id: String) {
        init(ctx)
        _mails.value = _mails.value.filter { it.id != id }
        saveData()
    }

    fun hasAccess(ctx: Context) = NotificationManagerCompat.getEnabledListenerPackages(ctx).contains(ctx.packageName)

    fun openAccessSettings(ctx: Context) {
        fr.jeremy.calepin.LockGuard.external()
        val i = if (android.os.Build.VERSION.SDK_INT >= 30) {
            Intent(Settings.ACTION_NOTIFICATION_LISTENER_DETAIL_SETTINGS)
                .putExtra(Settings.EXTRA_NOTIFICATION_LISTENER_COMPONENT_NAME, ComponentName(ctx, MessagesListener::class.java).flattenToString())
        } else Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS")
        runCatching { ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
            .onFailure { runCatching { ctx.startActivity(Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } }
    }

    // ------------------------------------------------------------------ Lecture des notifications

    fun onPosted(ctx: Context, sbn: StatusBarNotification) {
        init(ctx)
        if (sbn.packageName !in MAIL_PKGS) return
        val n = sbn.notification ?: return
        if (n.flags and Notification.FLAG_GROUP_SUMMARY != 0) return
        val ex = n.extras ?: return
        onMail(sbn, n, ex)
    }

    private fun remember(name: String) {
        if (_recent.value.firstOrNull() == name) return
        _recent.value = (listOf(name) + _recent.value.filter { it != name }).take(40)
        saveConfig()
    }

    private fun onMail(sbn: StatusBarNotification, n: Notification, ex: Bundle) {
        val from = ex.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty()
        val subject = ex.getCharSequence(Notification.EXTRA_TEXT)?.toString().orEmpty()
        val body = ex.getCharSequence(Notification.EXTRA_BIG_TEXT)?.toString().orEmpty()
        val account = (ex.getCharSequence(Notification.EXTRA_SUB_TEXT) ?: ex.getCharSequence(Notification.EXTRA_SUMMARY_TEXT))?.toString().orEmpty()
        if (from.isBlank()) return
        remember(from)
        val hay = "$from\n$subject\n$body\n$account".lowercase()
        if (_mailRules.value.none { hay.contains(it.lowercase()) }) return
        val id = sbn.key + "|" + sbn.postTime
        if (_mails.value.any { it.from == from && it.subject == subject && kotlin.math.abs(it.time - sbn.postTime) < 120_000 }) return
        n.contentIntent?.let { opens["mail|$id"] = it }
        _mails.value = (listOf(Mail(id, sbn.postTime, from, subject, body, sbn.packageName, account)) + _mails.value).take(300)
        saveData()
    }

    /** Ouvre le mail dans son appli (tant que la notification existe), sinon l'appli de mail. */
    fun openMail(ctx: Context, m: Mail) {
        fr.jeremy.calepin.LockGuard.external()
        opens["mail|${m.id}"]?.let { if (runCatching { it.send() }.isSuccess) return }
        ctx.packageManager.getLaunchIntentForPackage(m.pkg)?.let { runCatching { ctx.startActivity(it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } }
    }
}

/** Reçoit les notifications des applis de mail (après accord de l'utilisateur dans les réglages d'Android). */
class MessagesListener : NotificationListenerService() {
    override fun onListenerConnected() {
        runCatching { activeNotifications?.forEach { MessageHub.onPosted(this, it) } }
    }

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        if (sbn == null) return
        runCatching { MessageHub.onPosted(this, sbn) }
            .onFailure { fr.jeremy.calepin.care.CrashLog.note(this, "lecture des notifications", it) }
    }
}
