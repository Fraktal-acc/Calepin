package fr.jeremy.calepin.control

import android.app.Notification
import android.app.PendingIntent
import android.app.RemoteInput
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import fr.jeremy.calepin.search.TextNorm
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.concurrent.ConcurrentHashMap

/** Conversation WhatsApp ou Telegram suivie dans Calepin. [name] : nom affiché dans les notifications. */
data class Conv(val app: String, val name: String, val phone: String = "") {
    val key get() = "$app|$name"
    fun toJson(): JSONObject = JSONObject().put("app", app).put("name", name).put("phone", phone)

    companion object {
        const val WHATSAPP = "whatsapp"
        const val TELEGRAM = "telegram"
        fun fromJson(o: JSONObject) = Conv(o.optString("app"), o.optString("name"), o.optString("phone"))
    }
}

data class Msg(val time: Long, val from: String, val text: String, val mine: Boolean = false) {
    fun toJson(): JSONObject = JSONObject().put("t", time).put("f", from).put("x", text).put("m", mine)

    companion object {
        fun fromJson(o: JSONObject) = Msg(o.optLong("t"), o.optString("f"), o.optString("x"), o.optBoolean("m"))
    }
}

/** Mail repéré dans les notifications de l'appli de messagerie (Gmail, Samsung Email, Outlook…). */
data class Mail(val id: String, val time: Long, val from: String, val subject: String, val body: String, val pkg: String, val account: String) {
    fun toJson(): JSONObject = JSONObject().put("id", id).put("t", time).put("f", from).put("s", subject).put("b", body).put("p", pkg).put("a", account)

    companion object {
        fun fromJson(o: JSONObject) = Mail(o.optString("id"), o.optLong("t"), o.optString("f"), o.optString("s"), o.optString("b"), o.optString("p"), o.optString("a"))
    }
}

/**
 * Messagerie de Calepin : lit les notifications de WhatsApp, Telegram et des applis de mail (avec l'accord
 * de l'utilisateur) pour les conversations et expéditeurs choisis seulement, et répond directement depuis
 * la notification quand l'appli le permet. Rien n'est envoyé ailleurs : tout reste sur le téléphone.
 */
object MessageHub {
    val WHATSAPP_PKGS = setOf("com.whatsapp", "com.whatsapp.w4b")
    val TELEGRAM_PKGS = setOf("org.telegram.messenger", "org.telegram.messenger.web", "org.telegram.plus", "org.thunderdog.challegram")
    val MAIL_PKGS = setOf(
        "com.google.android.gm", "com.samsung.android.email.provider", "com.microsoft.office.outlook", "com.yahoo.mobile.client.android.mail",
        "ch.protonmail.android", "com.fsck.k9", "net.thunderbird.android", "com.orange.mail.fr", "fr.laposte.lapostemail", "com.free.mail",
    )

    private val _convs = MutableStateFlow<List<Conv>>(emptyList())
    val convs: StateFlow<List<Conv>> = _convs
    private val _messages = MutableStateFlow<Map<String, List<Msg>>>(emptyMap())
    val messages: StateFlow<Map<String, List<Msg>>> = _messages
    private val _mailRules = MutableStateFlow<List<String>>(emptyList())
    val mailRules: StateFlow<List<String>> = _mailRules
    private val _mails = MutableStateFlow<List<Mail>>(emptyList())
    val mails: StateFlow<List<Mail>> = _mails
    /** Noms vus récemment dans les notifications (pour ajouter une conversation sans se tromper d'orthographe). */
    private val _recent = MutableStateFlow<List<Pair<String, String>>>(emptyList())
    val recent: StateFlow<List<Pair<String, String>>> = _recent

    /** Réponses possibles depuis la notification (tant qu'elle est affichée) : clé de conversation → action. */
    private val replies = ConcurrentHashMap<String, Notification.Action>()
    private val opens = ConcurrentHashMap<String, PendingIntent>()

    @Volatile private var loaded = false
    private lateinit var app: Context

    private fun prefs() = app.getSharedPreferences("calepin_messages", Context.MODE_PRIVATE)
    private fun file() = File(app.filesDir, "messages.json")

    fun init(ctx: Context) {
        if (loaded) return
        synchronized(this) {
            if (loaded) return
            app = ctx.applicationContext
            runCatching {
                val a = JSONArray(prefs().getString("convs", "[]"))
                _convs.value = (0 until a.length()).map { Conv.fromJson(a.getJSONObject(it)) }
                val r = JSONArray(prefs().getString("mail_rules", "[]"))
                _mailRules.value = (0 until r.length()).map { r.getString(it) }
                val rc = JSONArray(prefs().getString("recent", "[]"))
                _recent.value = (0 until rc.length()).map { rc.getJSONArray(it).let { p -> p.getString(0) to p.getString(1) } }
            }
            runCatching {
                val o = JSONObject(file().readText())
                val c = o.optJSONObject("conv") ?: JSONObject()
                _messages.value = c.keys().asSequence().associateWith { k ->
                    val a = c.getJSONArray(k)
                    (0 until a.length()).map { Msg.fromJson(a.getJSONObject(it)) }
                }
                val m = o.optJSONArray("mail") ?: JSONArray()
                _mails.value = (0 until m.length()).map { Mail.fromJson(m.getJSONObject(it)) }
            }
            loaded = true
        }
    }

    private fun saveConfig() {
        prefs().edit()
            .putString("convs", JSONArray().apply { _convs.value.forEach { put(it.toJson()) } }.toString())
            .putString("mail_rules", JSONArray(_mailRules.value).toString())
            .putString("recent", JSONArray().apply { _recent.value.forEach { (a, n) -> put(JSONArray(listOf(a, n))) } }.toString())
            .apply()
    }

    private fun saveData() {
        runCatching {
            val c = JSONObject()
            _messages.value.forEach { (k, l) -> c.put(k, JSONArray().apply { l.forEach { put(it.toJson()) } }) }
            file().writeText(JSONObject().put("conv", c).put("mail", JSONArray().apply { _mails.value.forEach { put(it.toJson()) } }).toString())
        }
    }

    // ------------------------------------------------------------------ Réglages

    fun addConv(ctx: Context, c: Conv) {
        init(ctx)
        _convs.value = _convs.value.filter { it.key != c.key } + c
        saveConfig()
    }

    fun removeConv(ctx: Context, c: Conv) {
        init(ctx)
        _convs.value = _convs.value.filter { it.key != c.key }
        _messages.value = _messages.value - c.key
        saveConfig(); saveData()
    }

    fun clearConv(ctx: Context, c: Conv) {
        init(ctx)
        _messages.value = _messages.value - c.key
        saveData()
    }

    fun addMailRule(ctx: Context, rule: String) {
        init(ctx)
        val r = rule.trim()
        if (r.isNotEmpty() && _mailRules.value.none { it.equals(r, true) }) { _mailRules.value = _mailRules.value + r; saveConfig() }
    }

    fun removeMailRule(ctx: Context, rule: String) {
        init(ctx)
        _mailRules.value = _mailRules.value - rule
        saveConfig()
    }

    fun deleteMail(ctx: Context, id: String) {
        init(ctx)
        _mails.value = _mails.value.filter { it.id != id }
        saveData()
    }

    fun hasAccess(ctx: Context) = NotificationManagerCompat.getEnabledListenerPackages(ctx).contains(ctx.packageName)

    fun openAccessSettings(ctx: Context) {
        fr.jeremy.calepin.LockGuard.external()
        val i = if (android.os.Build.VERSION.SDK_INT >= 30) {
            Intent(Settings.ACTION_NOTIFICATION_LISTENER_DETAIL_SETTINGS)
                .putExtra(Settings.EXTRA_NOTIFICATION_LISTENER_COMPONENT_NAME, ComponentName(ctx, MessagesListener::class.java).flattenToString())
        } else Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS")
        runCatching { ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
            .onFailure { runCatching { ctx.startActivity(Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } }
    }

    // ------------------------------------------------------------------ Lecture des notifications

    private fun appOf(pkg: String) = when (pkg) {
        in WHATSAPP_PKGS -> Conv.WHATSAPP
        in TELEGRAM_PKGS -> Conv.TELEGRAM
        in MAIL_PKGS -> "mail"
        else -> null
    }

    /** « Famille (3 messages) », « Marc: » … → nom de la conversation. */
    private fun cleanName(s: String) = s.replace(Regex("\\s*\\(\\d+[^)]*\\)\\s*$"), "").trim().trimEnd(':').trim()

    fun onPosted(ctx: Context, sbn: StatusBarNotification) {
        init(ctx)
        val n = sbn.notification ?: return
        if (n.flags and Notification.FLAG_GROUP_SUMMARY != 0) return
        val kind = appOf(sbn.packageName) ?: return
        val ex = n.extras ?: return
        if (kind == "mail") { onMail(sbn, n, ex); return }

        val style = NotificationCompat.MessagingStyle.extractMessagingStyleFromNotification(n)
        val rawTitle = (style?.conversationTitle ?: ex.getCharSequence(Notification.EXTRA_TITLE))?.toString() ?: return
        // WhatsApp de groupe : « Marc @ Famille »
        val name = cleanName(rawTitle.substringAfter(" @ ", rawTitle))
        if (name.isBlank() || name.equals("WhatsApp", true) || name.equals("Telegram", true)) return
        remember(kind, name)

        val key = "$kind|$name"
        n.actions?.firstOrNull { a -> a.remoteInputs?.any { it.allowFreeFormInput } == true }?.let { replies[key] = it }
        n.contentIntent?.let { opens[key] = it }

        val conv = _convs.value.firstOrNull { it.app == kind && TextNorm.norm(it.name) == TextNorm.norm(name) } ?: return
        if (conv.key != key) {
            replies[conv.key]?.let { } ?: replies[key]?.let { replies[conv.key] = it }
            opens[key]?.let { opens[conv.key] = it }
        }
        val incoming = style?.messages?.mapNotNull { m ->
            val t = m.text?.toString() ?: return@mapNotNull null
            // Sans expéditeur : message envoyé depuis ce téléphone
            Msg(m.timestamp, m.person?.name?.toString() ?: "", t, mine = m.person == null)
        } ?: listOfNotNull(ex.getCharSequence(Notification.EXTRA_TEXT)?.toString()?.let { Msg(sbn.postTime, name, it) })
        if (incoming.isEmpty()) return
        val old = _messages.value[conv.key].orEmpty()
        val added = incoming.filter { m -> old.none { it.time == m.time && it.text == m.text } }
        if (added.isEmpty()) return
        _messages.value = _messages.value + (conv.key to (old + added).sortedBy { it.time }.takeLast(400))
        saveData()
    }

    private fun remember(kind: String, name: String) {
        val p = kind to name
        if (_recent.value.firstOrNull() == p) return
        _recent.value = (listOf(p) + _recent.value.filter { it != p }).take(40)
        saveConfig()
    }

    private fun onMail(sbn: StatusBarNotification, n: Notification, ex: Bundle) {
        val from = ex.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty()
        val subject = ex.getCharSequence(Notification.EXTRA_TEXT)?.toString().orEmpty()
        val body = ex.getCharSequence(Notification.EXTRA_BIG_TEXT)?.toString().orEmpty()
        val account = (ex.getCharSequence(Notification.EXTRA_SUB_TEXT) ?: ex.getCharSequence(Notification.EXTRA_SUMMARY_TEXT))?.toString().orEmpty()
        if (from.isBlank()) return
        remember("mail", from)
        val hay = "$from\n$subject\n$body\n$account".lowercase()
        if (_mailRules.value.none { hay.contains(it.lowercase()) }) return
        val id = sbn.key + "|" + sbn.postTime
        if (_mails.value.any { it.from == from && it.subject == subject && kotlin.math.abs(it.time - sbn.postTime) < 120_000 }) return
        n.contentIntent?.let { opens["mail|$id"] = it }
        _mails.value = (listOf(Mail(id, sbn.postTime, from, subject, body, sbn.packageName, account)) + _mails.value).take(300)
        saveData()
    }

    // ------------------------------------------------------------------ Envoi

    fun canReplyDirectly(key: String) = replies.containsKey(key)

    /** Cherche une conversation par nom (suivie, ou vue récemment) pour une appli. */
    fun findByName(ctx: Context, app: String, who: String): Conv? {
        init(ctx)
        val w = TextNorm.norm(who)
        _convs.value.filter { it.app == app }.firstOrNull { TextNorm.norm(it.name) == w }?.let { return it }
        _convs.value.filter { it.app == app }.firstOrNull { TextNorm.norm(it.name).contains(w) }?.let { return it }
        _recent.value.firstOrNull { it.first == app && TextNorm.norm(it.second) == w }?.let { return Conv(app, it.second) }
        _recent.value.firstOrNull { it.first == app && TextNorm.norm(it.second).contains(w) }?.let { return Conv(app, it.second) }
        return null
    }

    /**
     * Envoie [text] : directement par la notification si possible (le message part vraiment),
     * sinon en ouvrant l'appli avec le message prêt. Renvoie vrai si le message est parti.
     */
    fun send(ctx: Context, conv: Conv, text: String): Boolean {
        init(ctx)
        val action = replies[conv.key]
        if (action != null) {
            val ok = runCatching {
                val inputs = action.remoteInputs.filter { it.allowFreeFormInput }.toTypedArray()
                val intent = Intent()
                val b = Bundle()
                inputs.forEach { b.putCharSequence(it.resultKey, text) }
                RemoteInput.addResultsToIntent(inputs, intent, b)
                action.actionIntent.send(ctx, 0, intent)
            }.isSuccess
            if (ok) {
                replies.remove(conv.key) // une réponse par notification ; la suivante arrivera avec le prochain message
                addMine(conv, text)
                return true
            }
        }
        openApp(ctx, conv, text)
        return false
    }

    private fun addMine(conv: Conv, text: String) {
        if (_convs.value.none { it.key == conv.key }) return
        val old = _messages.value[conv.key].orEmpty()
        _messages.value = _messages.value + (conv.key to (old + Msg(System.currentTimeMillis(), "", text, mine = true)).takeLast(400))
        saveData()
    }

    /** Ouvre la conversation dans WhatsApp ou Telegram (avec le message prêt quand c'est possible). */
    fun openApp(ctx: Context, conv: Conv, text: String = "") {
        fr.jeremy.calepin.LockGuard.external()
        val digits = conv.phone.filter { it.isDigit() || it == '+' }.let { d ->
            when {
                d.startsWith("+") -> d.drop(1)
                d.startsWith("00") -> d.drop(2)
                d.startsWith("0") && d.length == 10 -> "33" + d.drop(1)
                else -> d
            }
        }.filter { it.isDigit() }
        val i: Intent? = when (conv.app) {
            Conv.WHATSAPP -> when {
                digits.isNotEmpty() -> Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/$digits" + if (text.isNotEmpty()) "?text=" + Uri.encode(text) else ""))
                text.isNotEmpty() -> Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, text).setPackage("com.whatsapp")
                else -> null
            }
            else -> when {
                text.isNotEmpty() -> Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, text).setPackage("org.telegram.messenger")
                digits.isNotEmpty() -> Intent(Intent.ACTION_VIEW, Uri.parse("tg://resolve?phone=$digits"))
                else -> null
            }
        }
        // Sans numéro ni texte : la notification de la conversation l'ouvre directement
        if (i == null || (text.isEmpty() && opens[conv.key] != null)) {
            opens[conv.key]?.let { if (runCatching { it.send() }.isSuccess) return }
        }
        val target = i ?: ctx.packageManager.getLaunchIntentForPackage(if (conv.app == Conv.WHATSAPP) "com.whatsapp" else "org.telegram.messenger")
        target?.let { runCatching { ctx.startActivity(it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } }
    }

    /** Ouvre le mail dans son appli (tant que la notification existe), sinon l'appli de mail. */
    fun openMail(ctx: Context, m: Mail) {
        fr.jeremy.calepin.LockGuard.external()
        opens["mail|${m.id}"]?.let { if (runCatching { it.send() }.isSuccess) return }
        ctx.packageManager.getLaunchIntentForPackage(m.pkg)?.let { runCatching { ctx.startActivity(it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } }
    }
}

/** Reçoit les notifications (après accord de l'utilisateur dans les réglages d'Android). */
class MessagesListener : NotificationListenerService() {
    override fun onListenerConnected() {
        runCatching { activeNotifications?.forEach { MessageHub.onPosted(this, it) } }
    }

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        if (sbn == null) return
        runCatching { MessageHub.onPosted(this, sbn) }
            .onFailure { fr.jeremy.calepin.care.CrashLog.note(this, "lecture des notifications", it) }
    }
}
