package fr.jeremy.calepin.ui

import android.graphics.Bitmap
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.DirectionsCar
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.PhotoCamera
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.TextFields
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.listSaver
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.toMutableStateList
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import fr.jeremy.calepin.BuildConfig
import fr.jeremy.calepin.Files
import fr.jeremy.calepin.LockGuard
import fr.jeremy.calepin.NotesViewModel
import fr.jeremy.calepin.i18n.RawText
import fr.jeremy.calepin.i18n.Text
import fr.jeremy.calepin.media.Media
import fr.jeremy.calepin.vehicle.AiFinding
import fr.jeremy.calepin.vehicle.Check
import fr.jeremy.calepin.vehicle.Part
import fr.jeremy.calepin.vehicle.Vehicle
import fr.jeremy.calepin.vehicle.VehicleKind
import fr.jeremy.calepin.vehicle.VehicleStore
import fr.jeremy.calepin.vehicle.Verdict
import fr.jeremy.calepin.vehicle.WearRules
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

private fun day(t: Long) = SimpleDateFormat("d MMM yyyy", Locale.FRANCE).format(Date(t))
private fun kmText(km: Int) = if (km <= 0) "" else "%,d km".format(Locale.FRANCE, km).replace(',', ' ')

/** Couleur d'un verdict (lisible en clair comme en sombre). */
private fun verdictColor(v: Verdict) = when (v) {
    Verdict.BON -> Color(0xFF2E7D32)
    Verdict.SURVEILLER -> Color(0xFFE08A00)
    Verdict.REMPLACER -> Color(0xFFC62828)
    Verdict.INCONNU -> Color(0xFF78858F)
}

@Composable
private fun VerdictChip(v: Verdict, small: Boolean = false) {
    val c = verdictColor(v)
    Surface(shape = RoundedCornerShape(50), color = c.copy(alpha = 0.16f)) {
        Row(Modifier.padding(horizontal = if (small) 8.dp else 10.dp, vertical = if (small) 2.dp else 4.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(if (small) 7.dp else 9.dp).clip(CircleShape).background(c))
            Spacer(Modifier.width(6.dp))
            Text(v.label, style = if (small) MaterialTheme.typography.labelSmall else MaterialTheme.typography.labelLarge, color = c, fontWeight = FontWeight.SemiBold)
        }
    }
}

/** Avertissement affiché avec chaque résultat. */
private const val SAFETY =
    "Indication donnée à partir des photos et de tes réponses : elle ne remplace pas l'avis d'un garagiste. " +
        "Pneus et freins : au moindre doute, fais vérifier avant de rouler."

/**
 * Menu Véhicule : tes véhicules, et un assistant qui repère l'usure (pneus, freins, pare-brise, essuie-glaces,
 * éclairage, chaîne, carrosserie) à partir de photos. Dans Calepin IA avec Gemma 4, l'IA regarde les photos ;
 * partout, un contrôle guidé, la profondeur des pneus et leur date de fabrication (code DOT lu sur la photo).
 */
@Composable
fun VehicleScreen(vm: NotesViewModel, onClose: () -> Unit) {
    val ctx = LocalContext.current
    val store = remember { VehicleStore.get(ctx) }
    val vehicles by store.vehicles.collectAsStateWithLifecycle()
    var openId by rememberSaveable { mutableStateOf<String?>(null) }
    var autoOpened by rememberSaveable { mutableStateOf(false) }
    // Pièce en cours de contrôle (« PNEU|Avant gauche ») : gardée si Android ferme l'appli pendant la photo
    var targetKey by rememberSaveable { mutableStateOf<String?>(null) }
    val target = targetKey?.let { k -> runCatching { Part.valueOf(k.substringBefore('|')) }.getOrNull()?.let { it to k.substringAfter('|', "") } }
    fun setTarget(p: Pair<Part, String>?) { targetKey = p?.let { it.first.name + "|" + it.second } }
    var viewing by rememberSaveable { mutableStateOf<String?>(null) }
    LaunchedEffect(vehicles.size) {
        if (!autoOpened && vehicles.size == 1) { openId = vehicles[0].id }
        autoOpened = true
    }
    val v = vehicles.firstOrNull { it.id == openId }
    val viewed = store.checks.collectAsStateWithLifecycle().value.firstOrNull { it.id == viewing }
    when {
        v != null && target != null -> CheckScreen(vm, store, v, target.first, target.second, onDone = { setTarget(null) })
        v != null && viewed != null -> CheckView(store, viewed, onBack = { viewing = null }, onRedo = { setTarget(viewed.part to viewed.position); viewing = null })
        v != null -> VehicleDetail(vm, store, v, onBack = { openId = null }, onCheck = { p, pos -> setTarget(p to pos) }, onView = { viewing = it.id })
        else -> VehicleList(store, vehicles, onOpen = { openId = it.id }, onClose = onClose)
    }
}

// ------------------------------------------------------------------ Liste des véhicules

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun VehicleList(store: VehicleStore, vehicles: List<Vehicle>, onOpen: (Vehicle) -> Unit, onClose: () -> Unit) {
    BackHandler { onClose() }
    var adding by remember { mutableStateOf(false) }
    val checks by store.checks.collectAsStateWithLifecycle()
    Scaffold(
        topBar = {
            TopAppBar(
                title = { FitText("Véhicule") },
                navigationIcon = { IconButton(onClick = onClose) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Retour") } },
            )
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(onClick = { adding = true }, icon = { Icon(Icons.Filled.Add, null) }, text = { Text("Ajouter un véhicule") })
        },
    ) { pad ->
        Column(
            Modifier.fillMaxSize().padding(pad).verticalScroll(rememberScrollState()).padding(horizontal = 16.dp).padding(bottom = 96.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            if (vehicles.isEmpty()) {
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.bubble()), modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Filled.AutoAwesome, null, tint = MaterialTheme.colorScheme.primary)
                            Text("  Assistant d'usure", style = MaterialTheme.typography.titleMedium)
                        }
                        Text(
                            "Prends en photo les pneus, les freins, le pare-brise… L'assistant t'aide à repérer l'usure, " +
                                "lit la date de fabrication des pneus et garde l'historique de chaque contrôle.",
                            style = MaterialTheme.typography.bodyMedium,
                        )
                        Button(onClick = { adding = true }) { Text("Ajouter mon véhicule") }
                    }
                }
            }
            vehicles.sortedBy { it.created }.forEach { v ->
                val latest = remember(checks, v.id) { store.latest(v.id) }
                val worst = if (latest.isEmpty()) null else Verdict.worst(latest.map { it.verdict })
                Card(onClick = { onOpen(v) }, colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer.bubble()), border = appBorder(), modifier = Modifier.fillMaxWidth()) {
                    Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Filled.DirectionsCar, null, Modifier.size(34.dp), tint = MaterialTheme.colorScheme.primary)
                        Spacer(Modifier.width(14.dp))
                        Column(Modifier.weight(1f)) {
                            RawText(v.name, style = MaterialTheme.typography.titleMedium)
                            RawText(listOf(v.kind.label, v.plate, kmText(v.km)).filter { it.isNotBlank() }.joinToString(" · "), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            val alerts = latest.count { it.verdict == Verdict.REMPLACER || it.verdict == Verdict.SURVEILLER }
                            if (alerts > 0) Text("$alerts point${if (alerts > 1) "s" else ""} à suivre", style = MaterialTheme.typography.bodySmall, color = verdictColor(worst ?: Verdict.INCONNU))
                        }
                        worst?.let { VerdictChip(it, small = true) }
                    }
                }
            }
        }
    }
    if (adding) VehicleDialog(null, onDismiss = { adding = false }) { store.upsert(it); adding = false; onOpen(it) }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun VehicleDialog(initial: Vehicle?, onDismiss: () -> Unit, onSave: (Vehicle) -> Unit) {
    var name by remember { mutableStateOf(initial?.name ?: "") }
    var kind by remember { mutableStateOf(initial?.kind ?: VehicleKind.VOITURE) }
    var plate by remember { mutableStateOf(initial?.plate ?: "") }
    var km by remember { mutableStateOf(initial?.km?.takeIf { it > 0 }?.toString() ?: "") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (initial == null) "Nouveau véhicule" else "Modifier le véhicule") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(name, { name = it }, label = { Text("Nom (ex. Clio, Vespa)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    VehicleKind.entries.forEach { k -> FilterChip(selected = kind == k, onClick = { kind = k }, label = { Text(k.label) }) }
                }
                OutlinedTextField(plate, { plate = it.uppercase() }, label = { Text("Immatriculation (facultatif)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(km, { km = it.filter { c -> c.isDigit() }.take(7) }, label = { Text("Kilométrage") }, singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.fillMaxWidth())
            }
        },
        confirmButton = {
            TextButton(enabled = name.isNotBlank(), onClick = {
                val base = initial ?: Vehicle(name = name.trim())
                onSave(base.copy(name = name.trim(), kind = kind, plate = plate.trim(), km = km.toIntOrNull() ?: 0))
            }) { Text("Enregistrer") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Annuler") } },
    )
}

// ------------------------------------------------------------------ Fiche du véhicule

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
private fun VehicleDetail(vm: NotesViewModel, store: VehicleStore, v: Vehicle, onBack: () -> Unit, onCheck: (Part, String) -> Unit, onView: (Check) -> Unit) {
    BackHandler { onBack() }
    val checks by store.checks.collectAsStateWithLifecycle()
    val mine = remember(checks, v.id) { checks.filter { it.vehicleId == v.id }.sortedByDescending { it.date } }
    val latest = remember(checks, v.id) { store.latest(v.id) }
    var editing by remember { mutableStateOf(false) }
    var confirmDelete by remember { mutableStateOf(false) }
    var choosing by remember { mutableStateOf<Part?>(null) }
    val vision = remember { vm.aiVisionReady() }
    Scaffold(
        topBar = {
            TopAppBar(
                title = { FitText(v.name, translate = false) },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Retour") } },
                actions = {
                    IconButton(onClick = { editing = true }) { Icon(Icons.Filled.Edit, "Modifier") }
                    IconButton(onClick = { confirmDelete = true }) { Icon(Icons.Filled.Delete, "Supprimer le véhicule") }
                },
            )
        },
    ) { pad ->
        Column(
            Modifier.fillMaxSize().padding(pad).verticalScroll(rememberScrollState()).padding(horizontal = 16.dp).padding(bottom = 40.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            RawText(listOf(v.kind.label, v.plate, kmText(v.km)).filter { it.isNotBlank() }.joinToString(" · "), style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)

            // Bilan : la pire pièce d'abord
            val alerts = latest.filter { it.verdict != Verdict.BON }.sortedByDescending { it.verdict.rank }
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer.bubble()), border = appBorder(), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Bilan", style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
                        if (latest.isNotEmpty()) VerdictChip(Verdict.worst(latest.map { it.verdict }))
                    }
                    when {
                        latest.isEmpty() -> Text("Aucun contrôle pour l'instant. Commence par les pneus : c'est le plus important pour la sécurité.", style = MaterialTheme.typography.bodyMedium)
                        alerts.isEmpty() -> Text("Tout ce qui a été contrôlé est en bon état.", style = MaterialTheme.typography.bodyMedium)
                        else -> alerts.forEach { c ->
                            Row(Modifier.fillMaxWidth().clickable { onView(c) }.padding(vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
                                RawText(c.label, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
                                VerdictChip(c.verdict, small = true)
                            }
                        }
                    }
                    Text(
                        when {
                            vision -> "L'IA (Gemma 4) regarde tes photos, en plus du contrôle guidé."
                            BuildConfig.AI -> "Pour que l'IA regarde les photos, choisis Gemma 4 dans Paramètres → Intelligence artificielle. En attendant : contrôle guidé."
                            else -> "Contrôle guidé avec tes photos, la profondeur et la date des pneus. Calepin IA sait aussi analyser les photos."
                        },
                        style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }

            SubTitle("Contrôler")
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Part.forVehicle(v.kind).forEach { p ->
                    val last = latest.filter { it.part == p }.maxByOrNull { it.verdict.rank }
                    Card(
                        onClick = { if (p.positions.isEmpty()) onCheck(p, "") else choosing = p },
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer.bubble()),
                        border = appBorder(),
                        modifier = Modifier.width(160.dp),
                    ) {
                        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text(p.label, style = MaterialTheme.typography.titleSmall)
                            if (last != null) VerdictChip(last.verdict, small = true)
                            else Text("Pas encore contrôlé", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }

            if (mine.isNotEmpty()) {
                SubTitle("Historique")
                mine.forEach { c ->
                    Row(
                        Modifier.fillMaxWidth().clip(MaterialTheme.shapes.medium).clickable { onView(c) }.padding(vertical = 8.dp, horizontal = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        c.photos.firstOrNull()?.let { NotePhoto(store.photo(it), false, Modifier.size(52.dp), maxSide = 200) }
                            ?: Box(Modifier.size(52.dp).clip(RoundedCornerShape(10.dp)).background(MaterialTheme.colorScheme.surfaceContainer))
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            RawText(c.label, style = MaterialTheme.typography.bodyLarge)
                            RawText(listOf(day(c.date), kmText(c.km)).filter { it.isNotBlank() }.joinToString(" · "), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        VerdictChip(c.verdict, small = true)
                    }
                    HorizontalDivider()
                }
            }
        }
    }
    choosing?.let { p ->
        AlertDialog(
            onDismissRequest = { choosing = null },
            title = { Text(p.label) },
            text = {
                Column {
                    p.positions.forEach { pos ->
                        val last = latest.firstOrNull { it.part == p && it.position == pos }
                        Row(Modifier.fillMaxWidth().clickable { choosing = null; onCheck(p, pos) }.padding(vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text(pos, style = MaterialTheme.typography.bodyLarge, modifier = Modifier.weight(1f))
                            last?.let { VerdictChip(it.verdict, small = true) }
                        }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { choosing = null }) { Text("Fermer") } },
        )
    }
    if (editing) VehicleDialog(v, onDismiss = { editing = false }) { store.upsert(it); editing = false }
    if (confirmDelete) {
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            title = { Text("Supprimer « ${v.name} » ?") },
            text = { Text("Le véhicule et tous ses contrôles seront supprimés.") },
            confirmButton = {
                TextButton(onClick = {
                    confirmDelete = false
                    val removed = store.removeVehicle(v.id)
                    onBack()
                    if (removed != null) Undo.offer(
                        "Véhicule « ${v.name} » supprimé",
                        commit = { store.dropPhotos(removed.second.flatMap { it.photos }) },
                    ) { store.restore(removed.first, removed.second) }
                }) { Text("Supprimer", color = MaterialTheme.colorScheme.error) }
            },
            dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text("Annuler") } },
        )
    }
}

// ------------------------------------------------------------------ Contrôle d'une pièce

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
private fun CheckScreen(vm: NotesViewModel, store: VehicleStore, v: Vehicle, part: Part, position0: String, onDone: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    // Gardés si Android ferme l'appli pendant que l'appareil photo est ouvert
    val photos = rememberSaveable(saver = listSaver<androidx.compose.runtime.snapshots.SnapshotStateList<String>, String>(save = { it.toList() }, restore = { it.toMutableStateList() })) { mutableStateListOf<String>() }
    var position by rememberSaveable { mutableStateOf(position0) }
    var km by rememberSaveable { mutableStateOf(v.km.takeIf { it > 0 }?.toString() ?: "") }
    val yes = rememberSaveable(saver = listSaver<androidx.compose.runtime.snapshots.SnapshotStateList<String>, String>(save = { it.toList() }, restore = { it.toMutableStateList() })) { mutableStateListOf<String>() }
    var guidedDone by rememberSaveable { mutableStateOf(false) }
    var tread by rememberSaveable { mutableStateOf("") }
    var dot by rememberSaveable { mutableStateOf("") }
    var note by rememberSaveable { mutableStateOf("") }
    var ai by remember { mutableStateOf<AiFinding?>(null) }
    var aiText by remember { mutableStateOf("") }
    var aiBusy by remember { mutableStateOf(false) }
    var aiLive by remember { mutableStateOf("") }
    var ocrBusy by remember { mutableStateOf(false) }
    val vision = remember { vm.aiVisionReady() }
    val tyre = part == Part.PNEU || part == Part.PNEU_2R
    var pendingName by rememberSaveable { mutableStateOf<String?>(null) }

    fun discard() {
        photos.forEach { runCatching { store.photo(it).delete() } }
        onDone()
    }
    BackHandler { discard() }

    val take = rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()) { ok ->
        val f = pendingName?.let { store.photo(it) }; pendingName = null
        if (f != null) { if (ok && f.exists() && f.length() > 0) photos += f.name else f.delete() }
    }
    val pick = rememberLauncherForActivityResult(ActivityResultContracts.PickMultipleVisualMedia(6)) { uris ->
        uris.forEach { u ->
            runCatching {
                val f = File(store.photoDir, UUID.randomUUID().toString() + ".jpg")
                ctx.contentResolver.openInputStream(u)?.use { input -> f.outputStream().use { input.copyTo(it) } }
                photos += f.name
            }
        }
    }
    fun shoot() {
        val f = File(store.photoDir, UUID.randomUUID().toString() + ".jpg")
        pendingName = f.name
        LockGuard.external()
        runCatching { take.launch(Files.uriFor(ctx, f)) }.onFailure { pendingName = null; fr.jeremy.calepin.i18n.I18n.toast(ctx, "Aucun appareil photo disponible", Toast.LENGTH_SHORT).show() }
    }

    fun analyze() {
        if (photos.isEmpty()) return
        scope.launch {
            aiBusy = true
            val results = ArrayList<AiFinding>()
            val texts = ArrayList<String>()
            try {
                photos.toList().forEachIndexed { i, name ->
                    aiLive = if (photos.size > 1) "Photo ${i + 1} sur ${photos.size}…" else "L'IA regarde la photo… (le premier passage charge le modèle)"
                    val t = vm.analyzeWear(part, position.ifBlank { null }, v.name, store.photo(name)) { aiLive = it }
                    texts += t
                    results += WearRules.parseAi(t)
                }
                val sure = results.filter { it.verdict != Verdict.INCONNU }
                ai = AiFinding(
                    verdict = if (sure.isEmpty()) Verdict.INCONNU else Verdict.worst(sure.map { it.verdict }),
                    findings = results.flatMap { it.findings }.distinct(),
                    advice = results.map { it.advice }.filter { it.isNotBlank() }.distinct().joinToString(" "),
                    confident = sure.isNotEmpty() && sure.all { it.confident },
                    treadMm = results.mapNotNull { it.treadMm }.minOrNull(),
                )
                aiText = texts.joinToString("\n\n—\n\n")
                ai?.treadMm?.let { mm -> if (tread.isBlank()) tread = "%.1f".format(Locale.FRANCE, mm) }
            } catch (e: Throwable) {
                if (e is kotlinx.coroutines.CancellationException) throw e
                fr.jeremy.calepin.i18n.I18n.toast(ctx, "L'IA n'a pas pu analyser : " + (e.message ?: e.javaClass.simpleName), Toast.LENGTH_LONG).show()
            } finally {
                aiBusy = false
            }
        }
    }

    fun readDot() {
        if (photos.isEmpty()) return
        scope.launch {
            ocrBusy = true
            var found: Pair<Int, Int>? = null
            for (name in photos.reversed()) {
                val text = withContext(Dispatchers.IO) {
                    runCatching { fr.jeremy.calepin.media.PdfText.extractImage(ctx, Files.uriFor(ctx, store.photo(name))).text }.getOrDefault("")
                }
                found = WearRules.dot(text)
                if (found != null) break
            }
            ocrBusy = false
            if (found != null) dot = "%02d%02d".format(found.first, found.second % 100)
            else fr.jeremy.calepin.i18n.I18n.toast(ctx, "Date introuvable sur les photos : photographie le flanc de près, en lumière rasante, ou tape les 4 chiffres.", Toast.LENGTH_LONG).show()
        }
    }

    // Résultat en direct
    val treadMm = tread.replace(',', '.').toFloatOrNull()?.takeIf { it in 0f..20f }
    val treadRes = if (tyre && treadMm != null) WearRules.tread(treadMm, part == Part.PNEU_2R) else null
    val dotParsed = if (tyre && dot.length == 4) WearRules.dot(dot) else null
    val ageRes = dotParsed?.let { WearRules.age(it.first, it.second) }
    val guided = if (guidedDone || yes.isNotEmpty()) WearRules.guided(part, yes.toSet()) else null
    val others = listOfNotNull(treadRes?.first, ageRes?.first, guided?.first)
    val verdict = WearRules.combine(ai, others)
    val reasons = buildList {
        ai?.findings?.forEach { add(it) }
        treadRes?.let { add(it.second) }
        ageRes?.let { add(it.second) }
        guided?.second?.forEach { add(it) }
    }.distinct()
    val advice = ai?.advice?.takeIf { it.isNotBlank() && verdict == ai?.verdict } ?: verdict.advice

    Scaffold(
        topBar = {
            TopAppBar(
                title = { FitText(part.label) },
                navigationIcon = { IconButton(onClick = { discard() }) { Icon(Icons.Filled.Close, "Annuler") } },
                actions = {
                    TextButton(enabled = !aiBusy, onClick = {
                        store.upsert(
                            Check(
                                vehicleId = v.id, part = part, position = position, km = km.toIntOrNull() ?: 0,
                                photos = photos.toList(), verdict = verdict, findings = reasons, advice = advice, aiText = aiText,
                                treadMm = treadMm, dotWeek = dotParsed?.first ?: 0, dotYear = dotParsed?.second ?: 0, note = note.trim(),
                            )
                        )
                        fr.jeremy.calepin.i18n.I18n.toast(ctx, "Contrôle enregistré", Toast.LENGTH_SHORT).show()
                        onDone()
                    }) { Text("Enregistrer") }
                },
            )
        },
    ) { pad ->
        Column(
            Modifier.fillMaxSize().padding(pad).verticalScroll(rememberScrollState()).padding(horizontal = 16.dp).padding(bottom = 40.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            if (part.positions.isNotEmpty()) {
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    part.positions.forEach { p -> FilterChip(selected = position == p, onClick = { position = p }, label = { Text(p) }) }
                }
            }

            // Photos
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer.bubble()), border = appBorder(), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Photos", style = MaterialTheme.typography.titleSmall, modifier = Modifier.weight(1f))
                        IconButton(onClick = { shoot() }) { Icon(Icons.Filled.PhotoCamera, "Prendre une photo") }
                        IconButton(onClick = { LockGuard.external(); pick.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) }) { Icon(Icons.Filled.PhotoLibrary, "Depuis la galerie") }
                    }
                    Text(part.photoTip, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    if (photos.isNotEmpty()) {
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            items(photos.toList(), key = { it }) { n ->
                                Box {
                                    NotePhoto(store.photo(n), false, Modifier.size(96.dp), maxSide = 300)
                                    Surface(shape = CircleShape, color = Color.Black.copy(alpha = 0.55f), modifier = Modifier.align(Alignment.TopEnd).padding(4.dp).size(26.dp)) {
                                        IconButton(onClick = { photos.remove(n); runCatching { store.photo(n).delete() } }) {
                                            Icon(Icons.Filled.Close, "Retirer la photo", tint = Color.White, modifier = Modifier.size(16.dp))
                                        }
                                    }
                                }
                            }
                        }
                    }
                    if (vision) {
                        Button(onClick = { analyze() }, enabled = photos.isNotEmpty() && !aiBusy, modifier = Modifier.fillMaxWidth()) {
                            if (aiBusy) CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp) else Icon(Icons.Filled.AutoAwesome, null, Modifier.size(18.dp))
                            Text(if (ai == null) "  Analyser avec l'IA" else "  Analyser à nouveau")
                        }
                        if (aiBusy && aiLive.isNotBlank()) RawText(aiLive.takeLast(600), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }

            // Pneus : profondeur et date
            if (tyre) {
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer.bubble()), border = appBorder(), modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Profondeur et âge", style = MaterialTheme.typography.titleSmall)
                        OutlinedTextField(tread, { tread = it.filter { c -> c.isDigit() || c == ',' || c == '.' }.take(4) }, label = { Text("Profondeur des sculptures (mm)") },
                            singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), modifier = Modifier.fillMaxWidth())
                        Text(WearRules.COIN_TIP, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            OutlinedTextField(dot, { dot = it.filter { c -> c.isDigit() }.take(4) }, label = { Text("Date du pneu (4 chiffres)") },
                                singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.weight(1f))
                            Spacer(Modifier.width(8.dp))
                            OutlinedButton(onClick = { readDot() }, enabled = photos.isNotEmpty() && !ocrBusy) {
                                if (ocrBusy) CircularProgressIndicator(Modifier.size(16.dp), strokeWidth = 2.dp) else Icon(Icons.Filled.TextFields, null, Modifier.size(16.dp))
                                Text(" Lire")
                            }
                        }
                        Text("Sur le flanc, après « DOT » : les 4 derniers chiffres (ex. 2319 = semaine 23 de 2019).", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        if (dot.length == 4 && dotParsed == null) Text("Date impossible : semaine de 01 à 53, année passée.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error)
                    }
                }
            }

            // Contrôle guidé
            if (part.questions.isNotEmpty()) {
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer.bubble()), border = appBorder(), modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(14.dp)) {
                        Text("Contrôle guidé", style = MaterialTheme.typography.titleSmall)
                        Text("Coche ce que tu constates (sur place ou sur les photos).", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        part.questions.forEach { q ->
                            val on = q.id in yes
                            Row(Modifier.fillMaxWidth().clickable { if (on) yes.remove(q.id) else yes += q.id }, verticalAlignment = Alignment.CenterVertically) {
                                Checkbox(checked = on, onCheckedChange = { if (it) yes += q.id else yes.remove(q.id) })
                                Text(q.text, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
                            }
                        }
                        Row(Modifier.fillMaxWidth().clickable { guidedDone = !guidedDone }, verticalAlignment = Alignment.CenterVertically) {
                            Checkbox(checked = guidedDone || yes.isNotEmpty(), onCheckedChange = { guidedDone = it }, enabled = yes.isEmpty())
                            Text("J'ai vérifié tous ces points", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
                        }
                    }
                }
            }

            OutlinedTextField(km, { km = it.filter { c -> c.isDigit() }.take(7) }, label = { Text("Kilométrage") }, singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.fillMaxWidth())
            OutlinedTextField(note, { note = it }, label = { Text("Remarque (facultatif)") }, modifier = Modifier.fillMaxWidth())

            ResultCard(verdict, reasons, advice, ai?.confident == false && ai?.verdict != Verdict.INCONNU)
        }
    }
}

@Composable
private fun ResultCard(verdict: Verdict, reasons: List<String>, advice: String, lowConfidence: Boolean) {
    val c = verdictColor(verdict)
    Card(colors = CardDefaults.cardColors(containerColor = c.copy(alpha = 0.10f)), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Résultat", style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
                VerdictChip(verdict)
            }
            if (reasons.isEmpty()) Text("Ajoute des photos, coche le contrôle guidé" + " ou indique la profondeur pour obtenir un résultat.", style = MaterialTheme.typography.bodyMedium)
            reasons.forEach { RawText("• $it", style = MaterialTheme.typography.bodyMedium) }
            RawText(advice, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
            if (lowConfidence) Text("L'IA n'est pas sûre d'elle sur ces photos : vérifie toi-même ou refais une photo plus nette.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text(SAFETY, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

// ------------------------------------------------------------------ Contrôle enregistré

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun CheckView(store: VehicleStore, c: Check, onBack: () -> Unit, onRedo: () -> Unit) {
    BackHandler { onBack() }
    var big by remember { mutableStateOf<String?>(null) }
    var showAi by remember { mutableStateOf(false) }
    Scaffold(
        topBar = {
            TopAppBar(
                title = { FitText(c.label, translate = false) },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Retour") } },
                actions = {
                    IconButton(onClick = {
                        val removed = store.removeCheck(c.id)
                        onBack()
                        if (removed != null) Undo.offer("Contrôle supprimé", commit = { store.dropPhotos(removed.photos) }) { store.restoreCheck(removed) }
                    }) { Icon(Icons.Filled.Delete, "Supprimer le contrôle") }
                },
            )
        },
    ) { pad ->
        Column(
            Modifier.fillMaxSize().padding(pad).verticalScroll(rememberScrollState()).padding(horizontal = 16.dp).padding(bottom = 40.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            RawText(listOf(day(c.date), kmText(c.km)).filter { it.isNotBlank() }.joinToString(" · "), style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            if (c.photos.isNotEmpty()) {
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(c.photos, key = { it }) { n -> NotePhoto(store.photo(n), false, Modifier.size(120.dp).clickable { big = n }, maxSide = 400) }
                }
            }
            ResultCard(c.verdict, c.findings, c.advice, false)
            if (c.note.isNotBlank()) RawText(c.note, style = MaterialTheme.typography.bodyMedium)
            if (c.aiText.isNotBlank()) {
                TextButton(onClick = { showAi = !showAi }) { Text(if (showAi) "Masquer la réponse de l'IA" else "Voir la réponse complète de l'IA") }
                if (showAi) RawText(c.aiText, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            FilledTonalButton(onClick = onRedo, modifier = Modifier.fillMaxWidth()) { Text("Refaire ce contrôle") }
        }
    }
    big?.let { n ->
        val f = store.photo(n)
        val bmp by produceState<Bitmap?>(null, n) { value = withContext(Dispatchers.IO) { Media.thumbnail(f, false, 1600) } }
        AlertDialog(
            onDismissRequest = { big = null },
            text = { bmp?.let { Image(it.asImageBitmap(), null, Modifier.fillMaxWidth().height(400.dp), contentScale = ContentScale.Fit) } },
            confirmButton = { TextButton(onClick = { big = null }) { Text("Fermer") } },
        )
    }
}
