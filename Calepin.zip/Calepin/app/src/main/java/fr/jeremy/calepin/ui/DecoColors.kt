package fr.jeremy.calepin.ui

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb

/**
 * Couleurs des fonds animés choisies à la main : jusqu'à quatre par décor, chacune liée à des éléments
 * précis (étoiles, vagues, soleil, flocons…). [ColorPref.AUTO] = couleur d'origine.
 */
object DecoColors {
    const val SLOTS = 4

    /** Ce que règle chaque couleur, décor par décor (null = pas de réglage à cette place). */
    fun labels(deco: Deco): List<String?> = when (deco) {
        Deco.NONE -> listOf(null, null, null, null)
        Deco.PAPER -> listOf("Lignes", null, null, "Marge")
        Deco.NEON -> listOf("Grille et lueur", "Étoiles et halo", null, null)
        Deco.SUNSET -> listOf("Grille et bas du soleil", "Haut du soleil", null, "Étoiles")
        Deco.GRIMOIRE -> listOf("Lueur", "Braises", null, "Dorures")
        Deco.TERMINAL -> listOf("Pluie de code", null, null, null)
        Deco.AURORA -> listOf("Aurore : 1re couleur", "Aurore : 2e couleur", "Aurore : 3e couleur", "Étoiles")
        Deco.STARS -> listOf("Lueur et étoiles colorées", "2e lueur", null, "Étoiles")
        Deco.SNOW -> listOf("Ciel (haut)", "Ciel (bas) et braises", null, "Flocons")
        Deco.FOG -> listOf("Brume", "Taches", null, null)
        Deco.BLOOD -> listOf("Gouttes et éclaboussures", null, null, null)
        Deco.RAIN, Deco.STORM -> listOf("Lueur", "Pluie", null, "Éclairs")
        Deco.LEAVES -> listOf("Feuilles : 1re couleur", null, "Feuilles : 2e couleur", "Feuilles : 3e couleur")
        Deco.SAKURA -> listOf(null, null, null, "Pétales")
        Deco.ENERGY -> listOf("Aura", "Flammes de l'aura", null, null)
        Deco.SHADOWS -> listOf("Écriture", "Lueur froide", null, "Bougie")
        Deco.FIREFLIES -> listOf("Halo des lucioles", "Sol", null, "Cœur des lucioles")
        Deco.WAVES -> listOf("Ciel et vagues du fond", "Soleil", "Vagues de devant", "Reflets")
        Deco.LAVA -> listOf("Gouttes : 1re couleur", "Gouttes : 2e couleur", "Gouttes : 3e couleur", null)
        Deco.BOKEH -> listOf("Lumières : 1re couleur", "Lumières : 2e couleur", "Lumières : 3e couleur", "Lumières : 4e couleur")
        Deco.CONFETTI -> listOf("Confettis : 1re couleur", "Confettis : 2e couleur", "Confettis : 3e couleur", "Confettis : 4e couleur")
        Deco.DUNES -> listOf("Sable", "Soleil", null, null)
        Deco.NEBULA -> listOf("Nuages : 1re couleur", "Nuages : 2e couleur", "Nuages : 3e couleur", "Étoiles")
        Deco.FLAMES -> listOf("Flammes : 1re couleur", "Flammes : 2e couleur", null, "Étincelles")
        Deco.HEARTS -> listOf("Cœurs : 1re couleur", "Cœurs : 2e couleur", "Cœurs : 3e couleur", null)
        Deco.CIRCUIT -> listOf("Pistes", "Pistes (2e couleur)", null, null)
        Deco.GEARS -> listOf("Roues", "Roues (2e couleur) et braises", null, "Étincelles")
        Deco.BUBBLES -> listOf("Lumière", null, null, "Bulles")
        Deco.SUNNY -> listOf(null, "Soleil et rayons", null, null)
        Deco.CLOUDS -> listOf(null, null, null, "Nuages")
        Deco.MOUNTAINS, Deco.FOREST, Deco.STARRY_DESERT, Deco.SAVANNA ->
            listOf("Ciel et brume", "Soleil, lune et lumières", "Relief et silhouettes", null)
        Deco.SEASCAPE, Deco.TROPICAL, Deco.RIVIERA ->
            listOf("Ciel", "Soleil et reflets", "Relief et silhouettes", "Mer")
        Deco.CITY -> listOf("Ciel", "Lune et fenêtres", "Immeubles", "Eau")
        Deco.LAKE_AURORA -> listOf("Ciel", "Aurore et reflets", "Montagnes et sapins", "Lac")
        Deco.LAVENDER -> listOf("Ciel", "Soleil et lucioles", "Collines et arbre", "Champs de lavande")
        Deco.SEIGAIHA -> listOf("Vagues", "Vagues (2e couleur)", null, "Pétales")
        Deco.LANTERNS -> listOf("Lanternes", "Lueur", null, "Dorures")
        Deco.MANDALA -> listOf("Mandala : 1re couleur", "Mandala : 2e couleur", "Mandala : 3e couleur", "Lumières")
        Deco.ZELLIGE -> listOf("Étoiles : 1re couleur", "Étoiles : 2e couleur", "Étoiles : 3e couleur", "Reflet")
        Deco.PAPEL -> listOf("Fanions : 1re couleur", "Fanions : 2e couleur", "Fanions : 3e couleur", "Pétales")
        Deco.MEANDER -> listOf("Frises et mer", "Soleil", null, null)
    }

    fun encode(m: Map<String, List<Long>>): String = org.json.JSONObject().apply {
        m.forEach { (k, v) -> put(k, org.json.JSONArray(v)) }
    }.toString()

    fun decode(s: String?): Map<String, List<Long>> = runCatching {
        if (s.isNullOrBlank()) return emptyMap()
        val o = org.json.JSONObject(s)
        o.keys().asSequence().associateWith { k ->
            val a = o.getJSONArray(k)
            (0 until SLOTS).map { a.optLong(it, ColorPref.AUTO) }
        }
    }.getOrDefault(emptyMap())
}

/**
 * Couleurs du décor en cours de dessin (le dessin se fait toujours sur le même fil, image par image).
 * [exact] : la couleur choisie telle quelle (en gardant la transparence prévue par le décor) ;
 * [retint] : pour les paysages peints, la teinte choisie en gardant la lumière d'origine (ombres, dégradés).
 */
object DecoTint {
    private val slots = arrayOfNulls<Color>(DecoColors.SLOTS)
    var landscape = false

    fun set(values: List<Long>) {
        for (i in 0 until DecoColors.SLOTS) slots[i] = values.getOrNull(i)?.let { ColorPref.color(it) }
    }

    fun has(i: Int) = slots.getOrNull(i) != null

    fun exact(i: Int, def: Color): Color = slots.getOrNull(i)?.let { it.copy(alpha = def.alpha * it.alpha) } ?: def

    fun retint(i: Int, def: Color): Color {
        val target = slots.getOrNull(i) ?: return def
        val d = FloatArray(3)
        val tg = FloatArray(3)
        android.graphics.Color.colorToHSV(def.copy(alpha = 1f).toArgb(), d)
        android.graphics.Color.colorToHSV(target.copy(alpha = 1f).toArgb(), tg)
        // Teinte et intensité choisies, luminosité d'origine un peu rapprochée de celle choisie
        val v = d[2] * 0.8f + tg[2] * 0.2f
        val hsv = floatArrayOf(tg[0], (tg[1] * 0.85f + d[1] * 0.15f).coerceIn(0f, 1f), v.coerceIn(0f, 1f))
        return Color(android.graphics.Color.HSVToColor(hsv)).copy(alpha = def.alpha)
    }

    /** Dans les paysages : teinte choisie ; ailleurs, couleur inchangée. */
    fun l(i: Int, def: Color): Color = if (landscape) retint(i, def) else def
}
