package fr.jeremy.calepin.ui

import android.Manifest
import android.app.Activity
import android.content.pm.PackageManager
import android.media.MediaPlayer
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.SaveAlt
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilledTonalIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import fr.jeremy.calepin.Actions
import fr.jeremy.calepin.Files
import fr.jeremy.calepin.audio.Transcriber
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material.icons.filled.Subject
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.text.font.FontStyle
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import fr.jeremy.calepin.LockGuard
import fr.jeremy.calepin.NotesViewModel
import fr.jeremy.calepin.audio.VoiceRecorder
import fr.jeremy.calepin.data.Recording
import kotlinx.coroutines.delay
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

fun formatDuration(ms: Long): String {
    val s = ms / 1000
    return if (s >= 3600) "%d:%02d:%02d".format(s / 3600, (s / 60) % 60, s % 60) else "%d:%02d".format(s / 60, s % 60)
}

/**
 * Mémos vocaux d'une note : liste, lecture, partage, enregistrement sous, suppression,
 * et bouton pour en enregistrer un nouveau. [ensureNote] enregistre la note si besoin et renvoie son id.
 */
@Composable
fun RecordingsSection(
    vm: NotesViewModel,
    noteId: Long,
    noteTitle: String,
    ensureNote: () -> Long,
    onInsertText: (String) -> Unit,
) {
    val ctx = LocalContext.current
    var version by remember { mutableIntStateOf(0) }
    val recordings = remember(noteId, version) { vm.recordingsOf(noteId) }
    var recording by remember { mutableStateOf(false) }
    var toDelete by remember { mutableStateOf<Recording?>(null) }
    var pendingSave by remember { mutableStateOf<File?>(null) }
    val scope = rememberCoroutineScope()
    var askModel by remember { mutableStateOf<Recording?>(null) }
    var work by remember { mutableStateOf<String?>(null) }   // libellé de la tâche en cours
    var workProgress by remember { mutableFloatStateOf(0f) }
    var job by remember { mutableStateOf<Job?>(null) }

    fun transcribe(r: Recording) {
        job = scope.launch {
            try {
                work = "Transcription du mémo…"
                workProgress = 0f
                val text = Transcriber.transcribe(ctx, vm.fileOf(r)) { p -> workProgress = p }
                if (text.isBlank()) {
                    Toast.makeText(ctx, "Aucune parole reconnue dans ce mémo", Toast.LENGTH_LONG).show()
                } else {
                    vm.setTranscript(r, text)
                    version++
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Throwable) {
                Toast.makeText(ctx, "La transcription a échoué : ${e.message}", Toast.LENGTH_LONG).show()
            } finally {
                work = null
            }
        }
    }

    fun downloadThenTranscribe(r: Recording) {
        job = scope.launch {
            try {
                work = "Téléchargement du module de transcription…"
                workProgress = 0f
                Transcriber.download(ctx) { p -> workProgress = p }
            } catch (e: CancellationException) {
                work = null
                throw e
            } catch (e: Throwable) {
                work = null
                Toast.makeText(ctx, "Téléchargement impossible. Vérifiez la connexion Internet.", Toast.LENGTH_LONG).show()
                return@launch
            }
            work = null
            transcribe(r)
        }
    }

    // Lecture
    val player = remember { mutableStateOf<MediaPlayer?>(null) }
    var playingId by remember { mutableLongStateOf(-1L) }
    var paused by remember { mutableStateOf(false) }
    var progress by remember { mutableFloatStateOf(0f) }
    DisposableEffect(Unit) {
        onDispose { player.value?.release(); player.value = null }
    }
    LaunchedEffect(playingId, paused) {
        while (playingId >= 0 && !paused) {
            player.value?.let { p ->
                runCatching { if (p.duration > 0) progress = p.currentPosition / p.duration.toFloat() }
            }
            delay(200)
        }
    }

    fun stopPlayback() {
        player.value?.release(); player.value = null
        playingId = -1; paused = false; progress = 0f
    }

    fun toggle(r: Recording) {
        val p = player.value
        if (playingId == r.id && p != null) {
            if (paused) { p.start(); paused = false } else { p.pause(); paused = true }
            return
        }
        stopPlayback()
        try {
            val mp = MediaPlayer().apply {
                setDataSource(vm.fileOf(r).absolutePath)
                setOnCompletionListener { stopPlayback() }
                prepare()
                start()
            }
            player.value = mp
            playingId = r.id
        } catch (e: Exception) {
            Toast.makeText(ctx, "Lecture impossible", Toast.LENGTH_SHORT).show()
        }
    }

    val permission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) recording = true
        else Toast.makeText(ctx, "Autorisez le micro dans les paramètres Android pour enregistrer", Toast.LENGTH_LONG).show()
    }

    val saver = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { res ->
        val uri = res.data?.data
        val f = pendingSave
        pendingSave = null
        if (res.resultCode == Activity.RESULT_OK && uri != null && f != null) {
            val ok = Files.write(ctx, uri, f.readBytes())
            Toast.makeText(ctx, if (ok) "Enregistrement copié" else "Impossible d'écrire le fichier", Toast.LENGTH_SHORT).show()
        }
    }

    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        if (recordings.isNotEmpty()) {
            Text(
                "Mémos vocaux",
                style = MaterialTheme.typography.labelLarge,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
        recordings.forEachIndexed { i, r -> key(r.id) {
            val label = "Mémo ${i + 1}"
            val shareName = "${noteTitle.ifBlank { "Calepin" }} - $label.${r.extension}"
            Surface(shape = RoundedCornerShape(12.dp), color = MaterialTheme.colorScheme.surfaceContainer) {
                Column(Modifier.padding(start = 4.dp, end = 4.dp, top = 4.dp, bottom = 8.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        FilledTonalIconButton(onClick = { toggle(r) }) {
                            Icon(
                                if (playingId == r.id && !paused) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                                contentDescription = if (playingId == r.id && !paused) "Pause" else "Écouter",
                            )
                        }
                        Column(
                            Modifier
                                .weight(1f)
                                .padding(start = 8.dp),
                        ) {
                            Text(label, style = MaterialTheme.typography.bodyLarge)
                            Text(
                                "${formatDuration(r.durationMs)} · ${r.extension.uppercase()} · " +
                                    SimpleDateFormat("d MMM HH:mm", Locale.FRANCE).format(Date(r.createdAt)),
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                        var menu by remember { mutableStateOf(false) }
                        Box {
                            IconButton(onClick = { menu = true }) {
                                Icon(Icons.Filled.MoreVert, contentDescription = "Options du mémo")
                            }
                            DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                                DropdownMenuItem(
                                    text = { Text(if (r.transcript.isBlank()) "Transcrire en texte" else "Transcrire à nouveau") },
                                    leadingIcon = { Icon(Icons.Filled.Subject, null) },
                                    onClick = {
                                        menu = false
                                        if (Transcriber.isInstalled(ctx)) transcribe(r) else askModel = r
                                    },
                                )
                                DropdownMenuItem(
                                    text = { Text("Partager") },
                                    leadingIcon = { Icon(Icons.Filled.Share, null) },
                                    onClick = { menu = false; Files.shareFile(ctx, vm.fileOf(r), r.mime, shareName) },
                                )
                                DropdownMenuItem(
                                    text = { Text("Enregistrer sous…") },
                                    leadingIcon = { Icon(Icons.Filled.SaveAlt, null) },
                                    onClick = {
                                        menu = false
                                        pendingSave = vm.fileOf(r)
                                        LockGuard.external()
                                        saver.launch(Files.createDocumentIntent(shareName, r.mime))
                                    },
                                )
                                DropdownMenuItem(
                                    text = { Text("Supprimer", color = MaterialTheme.colorScheme.error) },
                                    leadingIcon = { Icon(Icons.Filled.Delete, null, tint = MaterialTheme.colorScheme.error) },
                                    onClick = { menu = false; toDelete = r },
                                )
                            }
                        }
                    }
                    if (playingId == r.id) {
                        LinearProgressIndicator(
                            progress = { progress },
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 12.dp),
                        )
                    }
                    if (r.transcript.isNotBlank()) {
                        Column(Modifier.padding(start = 12.dp, end = 12.dp, top = 6.dp)) {
                            SelectionContainer {
                                Text(
                                    r.transcript,
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontStyle = FontStyle.Italic,
                                )
                            }
                            Row {
                                TextButton(onClick = { onInsertText(r.transcript) }) { Text("Insérer dans la note") }
                                TextButton(onClick = { Actions.copy(ctx, r.transcript) }) { Text("Copier") }
                            }
                        }
                    }
                }
            }
        } }
        OutlinedButton(onClick = {
            val granted = ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
            if (granted) {
                recording = true
            } else {
                LockGuard.external()
                permission.launch(Manifest.permission.RECORD_AUDIO)
            }
        }) {
            Icon(Icons.Filled.Mic, contentDescription = null, modifier = Modifier.size(18.dp))
            Text("  Enregistrer un mémo vocal")
        }
    }

    askModel?.let { r ->
        AlertDialog(
            onDismissRequest = { askModel = null },
            title = { Text("Module de transcription") },
            text = {
                Text(
                    "Pour transcrire, Calepin a besoin du module de reconnaissance vocale française " +
                        "(${Transcriber.MODEL_SIZE_MB} Mo, téléchargé une seule fois, de préférence en Wi-Fi). " +
                        "Ensuite, la transcription se fait entièrement sur le téléphone, sans connexion."
                )
            },
            confirmButton = { TextButton(onClick = { askModel = null; downloadThenTranscribe(r) }) { Text("Télécharger") } },
            dismissButton = { TextButton(onClick = { askModel = null }) { Text("Annuler") } },
        )
    }

    work?.let { label ->
        AlertDialog(
            onDismissRequest = {},
            title = { Text(label) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    LinearProgressIndicator(progress = { workProgress }, modifier = Modifier.fillMaxWidth())
                    Text("${(workProgress * 100).toInt()} %", style = MaterialTheme.typography.bodySmall)
                }
            },
            confirmButton = { TextButton(onClick = { job?.cancel(); work = null }) { Text("Annuler") } },
        )
    }

    if (recording) {
        RecordDialog(
            vm = vm,
            ensureNote = ensureNote,
            onDone = { recording = false; version++ },
        )
    }

    toDelete?.let { r ->
        AlertDialog(
            onDismissRequest = { toDelete = null },
            title = { Text("Supprimer ce mémo vocal ?") },
            text = { Text("Le fichier audio sera définitivement effacé.") },
            confirmButton = {
                TextButton(onClick = {
                    if (playingId == r.id) stopPlayback()
                    vm.deleteRecording(r)
                    toDelete = null
                    version++
                }) { Text("Supprimer", color = MaterialTheme.colorScheme.error) }
            },
            dismissButton = { TextButton(onClick = { toDelete = null }) { Text("Annuler") } },
        )
    }
}

@Composable
private fun RecordDialog(vm: NotesViewModel, ensureNote: () -> Long, onDone: () -> Unit) {
    val ctx = LocalContext.current
    val view = LocalView.current
    val format by vm.settings.audioFormat.collectAsStateWithLifecycle()
    val bitrate by vm.settings.audioBitrate.collectAsStateWithLifecycle()
    val recorder = remember { VoiceRecorder(ctx.applicationContext) }
    var file by remember { mutableStateOf<File?>(null) }
    var elapsed by remember { mutableLongStateOf(0L) }
    var level by remember { mutableFloatStateOf(0f) }
    var failed by remember { mutableStateOf<String?>(null) }
    var noteId by remember { mutableLongStateOf(0L) }

    LaunchedEffect(Unit) {
        try {
            noteId = ensureNote()
            val f = vm.newRecordingFile(noteId, format)
            file = f
            recorder.start(f, format, bitrate)
            while (true) {
                elapsed = recorder.elapsedMs()
                level = level * 0.6f + recorder.level() * 0.4f
                delay(100)
            }
        } catch (e: kotlinx.coroutines.CancellationException) {
            throw e
        } catch (e: Throwable) {
            failed = e.message ?: "Le micro n'a pas pu démarrer"
        }
    }
    DisposableEffect(Unit) {
        view.keepScreenOn = true
        onDispose {
            view.keepScreenOn = false
            // Fermeture inattendue (retour, rotation…) : on garde ce qui a été enregistré.
            val f = file
            if (f != null) {
                runCatching {
                    val d = recorder.stop()
                    if (f.exists() && f.length() > 0) vm.addRecording(noteId, f, format, d) else f.delete()
                }
                file = null
            }
        }
    }

    fun finish(keep: Boolean) {
        val f = file
        file = null
        if (f != null) {
            if (keep) {
                try {
                    val d = recorder.stop()
                    vm.addRecording(noteId, f, format, d)
                } catch (e: Throwable) {
                    f.delete()
                    Toast.makeText(ctx, "L'enregistrement a échoué : ${e.message}", Toast.LENGTH_LONG).show()
                }
            } else {
                recorder.cancel(f)
            }
        }
        onDone()
    }

    AlertDialog(
        onDismissRequest = {},
        title = { Text(if (failed == null) "Enregistrement en cours" else "Enregistrement impossible") },
        text = {
            Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
                if (failed != null) {
                    Text(failed!!)
                } else {
                    Text(
                        formatDuration(elapsed),
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 44.sp,
                        color = MaterialTheme.colorScheme.primary,
                    )
                    LinearProgressIndicator(
                        progress = { level },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(8.dp)
                            .padding(vertical = 0.dp),
                        color = MaterialTheme.colorScheme.secondary,
                    )
                    Text(
                        "Format ${format.ext.uppercase()} · $bitrate kb/s",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(top = 10.dp),
                    )
                }
            }
        },
        confirmButton = {
            if (failed == null) {
                Button(
                    onClick = { finish(keep = true) },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                ) {
                    Icon(Icons.Filled.Stop, contentDescription = null, modifier = Modifier.size(18.dp))
                    Text("  Arrêter et garder")
                }
            } else {
                TextButton(onClick = { finish(keep = false) }) { Text("Fermer") }
            }
        },
        dismissButton = {
            if (failed == null) TextButton(onClick = { finish(keep = false) }) { Text("Annuler") }
        },
    )
}
