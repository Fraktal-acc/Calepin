package fr.jeremy.calepin.assistant

import android.content.Context
import fr.jeremy.calepin.data.Event
import fr.jeremy.calepin.data.Note
import fr.jeremy.calepin.data.NoteDb
import fr.jeremy.calepin.detect.Entity
import fr.jeremy.calepin.detect.EntityDetector
import fr.jeremy.calepin.reminders.Reminders

/** Données réelles de Calepin pour l'assistant (base SQLite du téléphone). */
class DbAssistantData(context: Context) : AssistantData {
    private val ctx = context.applicationContext
    private val db = NoteDb(ctx)

    override val notes: List<Note> get() = db.all()
    override val events: List<Event> get() = db.events()
    override fun entities(n: Note): List<Entity> = EntityDetector.detect(n.content)

    override fun createNote(title: String, content: String): Long =
        db.upsert(Note(title = title, content = content, tag = "Assistant"))

    override fun updateNote(n: Note) { db.upsert(n) }

    override val contacts: List<AssistantContact>
        get() = runCatching {
            fr.jeremy.calepin.contacts.PhoneContacts.load(ctx).map { c ->
                AssistantContact(c.name, c.phones.map { it.value to it.label }, c.addresses.map { it.value })
            }
        }.getOrDefault(emptyList())

    override val contactsAllowed: Boolean
        get() = fr.jeremy.calepin.contacts.PhoneContacts.hasPermission(ctx)

    override fun createEvent(e: Event): Event {
        val saved = e.copy(id = db.upsertEvent(e))
        Reminders.schedule(ctx, saved)
        return saved
    }
}
