package fr.jeremy.calepin.control

import android.content.Context
import fr.jeremy.calepin.contacts.PhoneContacts
import fr.jeremy.calepin.search.TextNorm
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Commandes de la maison et du téléphone en français courant (Calepin IA).
 * Renvoie la réponse à afficher, ou null si la phrase n'est pas une commande d'appareil
 * (l'assistant habituel prend alors le relais).
 */
class DeviceCommands(context: Context) {
    private val ctx = context.applicationContext
    private val phone = PhoneControl(ctx)
    private val home = HomeConfig(ctx)

    data class Done(val text: String)

    private fun done(t: String) = Done(t)

    suspend fun handle(raw: String): Done? = withContext(Dispatchers.IO) {
        val text = raw.trim().trimEnd('.', '!', '?', ' ')
        val n = TextNorm.norm(text).replace(Regex("\\s+"), " ")
        if (n.isBlank()) return@withContext null
        tv(n) ?: youtube(text, n) ?: whatsapp(text, n) ?: phoneSettings(n) ?: openApp(text, n)
    }

    // ------------------------------------------------------------ Télévision

    private val tvWord = Regex("\\b(tele|tv|television|televiseur|decodeur|box|bravia|sony)\\b")
    private val on = Regex("\\b(allume|allumer|demarre|demarrer|active)\\b")
    private val off = Regex("\\b(eteins|eteindre|eteint|arrete|arreter|desactive)\\b|\\ben veille\\b")

    private suspend fun tv(n: String): Done? {
        val channel = OrangeDecoder.findChannel(n)
        val zap = Regex("\\b(mets|met|passe|zappe|change|regarder|regarde|chaine|programme)\\b").containsMatchIn(n)
        val number = Regex("\\b(?:chaine|numero|la)\\s*(?:numero\\s*)?(\\d{1,3})\\b").find(n)?.groupValues?.get(1)?.toIntOrNull()
        val hasTv = tvWord.containsMatchIn(n)
        if (!hasTv && !(zap && (channel != null || (number != null && "chaine" in n)))) return null

        val dec = home.decoder()
        val tv = home.bravia()
        if (dec == null && tv == null) {
            return done("La télé et le décodeur ne sont pas encore configurés : va dans Paramètres → Maison, puis touche « Rechercher sur le Wi-Fi ».")
        }
        val decoderOnly = Regex("\\b(decodeur|box)\\b").containsMatchIn(n)
        val sound = Regex("\\b(son|volume)\\b").containsMatchIn(n) || "plus fort" in n || "moins fort" in n

        // Volume
        if (sound) {
            val steps = Regex("\\b(?:de|a) (\\d{1,2})\\b").find(n)?.groupValues?.get(1)?.toIntOrNull()
            val mute = Regex("\\b(coupe|mute|silence)\\b").containsMatchIn(n)
            val unmute = Regex("\\b(remets|retablis|reactive)\\b").containsMatchIn(n)
            val up = Regex("\\b(monte|augmente|plus fort|hausse)\\b").containsMatchIn(n)
            val down = Regex("\\b(baisse|diminue|moins fort)\\b").containsMatchIn(n)
            val absolute = Regex("\\bvolume (?:a|au) (\\d{1,3})\\b").find(n)?.groupValues?.get(1)?.toIntOrNull()
            if (tv != null && !decoderOnly) {
                val ok = when {
                    mute -> tv.mute(true)
                    unmute -> tv.mute(false)
                    absolute != null -> tv.volume(absolute.coerceIn(0, 100).toString())
                    up -> tv.volume("+${steps ?: 3}")
                    down -> tv.volume("-${steps ?: 3}")
                    else -> return null
                }
                return done(if (ok) "C'est fait." else "Le téléviseur ne répond pas : ${tv.lastProblem() ?: "vérifie qu'il est allumé"}.")
            }
            if (dec != null) {
                val code = when {
                    mute || unmute -> OrangeDecoder.MUTE
                    up -> OrangeDecoder.VOL_UP
                    down -> OrangeDecoder.VOL_DOWN
                    else -> return null
                }
                val times = if (mute || unmute) 1 else (steps ?: 3).coerceIn(1, 20)
                var ok = true
                repeat(times) { ok = ok && dec.key(code) }
                return done(if (ok) "C'est fait." else "Le décodeur ne répond pas sur le Wi-Fi.")
            }
            return null
        }

        // Allumer / éteindre
        if (off.containsMatchIn(n) && channel == null && number == null) {
            val parts = mutableListOf<String>()
            if (dec != null) parts += if (dec.powerOff()) "décodeur en veille" else "décodeur injoignable"
            if (tv != null && !decoderOnly) parts += if (tv.powerOff()) "télé éteinte" else "télé injoignable"
            return done(parts.joinToString(", ").replaceFirstChar { it.uppercase() } + ".")
        }
        if (on.containsMatchIn(n) && channel == null && number == null) {
            val parts = mutableListOf<String>()
            if (tv != null && !decoderOnly) parts += if (tv.powerOn()) "télé allumée" else "télé injoignable (active « Démarrage à distance » sur le téléviseur)"
            if (dec != null) parts += if (dec.powerOn()) "décodeur allumé" else "décodeur injoignable"
            return done(parts.joinToString(", ").replaceFirstChar { it.uppercase() } + ".")
        }

        // Entrée HDMI du téléviseur
        Regex("\\bhdmi ?(\\d)\\b").find(n)?.let { m ->
            val t = tv ?: return done("Configure d'abord le téléviseur Sony dans Paramètres → Maison.")
            val port = m.groupValues[1].toInt()
            return done(if (t.hdmi(port)) "Télé sur HDMI $port." else "Impossible de changer d'entrée : ${t.lastProblem() ?: "le téléviseur ne répond pas"}.")
        }

        // Chaîne suivante / précédente
        if (Regex("\\bchaine (suivante|d'apres)\\b").containsMatchIn(n) || "zappe" in n && channel == null && number == null) {
            val d = dec ?: return done("Configure d'abord le décodeur dans Paramètres → Maison.")
            return done(if (d.key(OrangeDecoder.CH_UP)) "Chaîne suivante." else "Le décodeur ne répond pas.")
        }
        if (Regex("\\bchaine (precedente|d'avant)\\b").containsMatchIn(n)) {
            val d = dec ?: return done("Configure d'abord le décodeur dans Paramètres → Maison.")
            return done(if (d.key(OrangeDecoder.CH_DOWN)) "Chaîne précédente." else "Le décodeur ne répond pas.")
        }

        // Pause / lecture
        if (Regex("\\b(pause|reprends|reprendre|lecture)\\b").containsMatchIn(n)) {
            val d = dec ?: return null
            return done(if (d.key(OrangeDecoder.PLAY_PAUSE)) "C'est fait." else "Le décodeur ne répond pas.")
        }

        // Changer de chaîne
        if (channel != null || number != null) {
            val d = dec ?: return done("Configure d'abord le décodeur Orange dans Paramètres → Maison.")
            if (d.isOn() == false) d.powerOn()
            val ok = if (channel != null) d.channel(channel) || d.channelNumber(channel.number) else d.channelNumber(number!!)
            val label = channel?.names?.first()?.uppercase() ?: "la chaîne $number"
            return done(if (ok) "Je mets $label." else "Le décodeur ne répond pas sur le Wi-Fi.")
        }

        // Application sur le téléviseur : « mets Netflix sur la télé »
        Regex("^(?:mets|met|lance|ouvre|demarre)\\s+(.+?)\\s+sur\\s+(?:la|le)\\s+(?:tele|tv|television|televiseur)$").find(n)?.let { m ->
            val t = tv ?: return done("Configure d'abord le téléviseur Sony dans Paramètres → Maison.")
            val want = m.groupValues[1]
            val apps = t.apps()
            if (apps.isEmpty()) return done("Je n'ai pas pu lire la liste des applis du téléviseur : ${t.lastProblem() ?: "est-il allumé ?"}")
            val app = apps.firstOrNull { TextNorm.norm(it.title) == want }
                ?: apps.firstOrNull { TextNorm.norm(it.title).contains(want) || want.contains(TextNorm.norm(it.title)) }
                ?: return done("Je ne trouve pas « $want » sur le téléviseur.")
            if (t.isOn() == false) t.powerOn()
            return done(if (t.openApp(app)) "J'ouvre ${app.title} sur la télé." else "Le téléviseur n'a pas pu ouvrir ${app.title}.")
        }

        return null
    }

    // ------------------------------------------------------------ YouTube

    private fun youtube(text: String, n: String): Done? {
        if ("youtube" !in n) return null
        val m = Regex("^(?:cherche|recherche|mets|met|lance|regarde|joue|trouve)(?:[ -]moi)?\\s+(.+?)\\s+sur youtube$").find(n)
            ?: Regex("^youtube\\s*:?\\s+(.+)$").find(n)
        if (m == null) return null
        // On reprend la recherche dans le texte d'origine (accents compris)
        val start = m.groups[1]!!.range.first
        val end = m.groups[1]!!.range.last + 1
        val query = text.substring(start.coerceAtMost(text.length), end.coerceAtMost(text.length)).ifBlank { m.groupValues[1] }
        return done(if (phone.youtubeSearch(query)) "Je cherche « $query » sur YouTube." else "YouTube n'a pas pu s'ouvrir.")
    }

    // ------------------------------------------------------------ WhatsApp

    private fun whatsapp(text: String, n: String): Done? {
        if ("whatsapp" !in n) return null
        val m = Regex("^(?:envoie|envoyer|ecris|ecrire|message)(?: un)?(?: message)?(?: whatsapp)?(?: par| sur)?(?: whatsapp)? a (.+?)\\s*:\\s*(.+)$").find(n)
            ?: Regex("^whatsapp a (.+?)\\s*:\\s*(.+)$").find(n)
            ?: return null
        val who = m.groupValues[1].trim()
        val colon = text.indexOf(':')
        val message = if (colon >= 0) text.substring(colon + 1).trim() else m.groupValues[2]
        if (!PhoneContacts.hasPermission(ctx)) return done("Autorise l'accès aux contacts (écran Contacts de Calepin IA) pour que je trouve « $who ».")
        val found = PhoneContacts.filter(PhoneContacts.load(ctx), who).filter { it.phones.isNotEmpty() }
        val c = found.firstOrNull { TextNorm.norm(it.name) == who } ?: found.firstOrNull()
            ?: return done("Je ne trouve pas « $who » dans tes contacts.")
        val number = (c.phones.firstOrNull { it.label.contains("mobile", true) || it.value.filter(Char::isDigit).let { d -> d.startsWith("06") || d.startsWith("07") || d.startsWith("336") || d.startsWith("337") } } ?: c.phones.first()).value
        return done(
            if (phone.whatsapp(number, message)) "Message prêt pour ${c.name} dans WhatsApp : touche Envoyer pour l'envoyer."
            else "WhatsApp n'a pas pu s'ouvrir."
        )
    }

    // ------------------------------------------------------------ Réglages du téléphone

    private fun phoneSettings(n: String): Done? {
        val wantsOff = off.containsMatchIn(n) || Regex("\\b(coupe|desactive)\\b").containsMatchIn(n)

        if (Regex("\\bbatterie\\b").containsMatchIn(n) && Regex("\\b(niveau|combien|reste|etat|pourcentage|charge|batterie)\\b").containsMatchIn(n) &&
            !Regex("\\b(economi|mode)\\b").containsMatchIn(n)
        ) return done(phone.battery())

        if (Regex("\\b(lampe|torche|flash)\\b").containsMatchIn(n)) {
            val ok = phone.torch(!wantsOff)
            return done(if (!ok) "Je n'ai pas pu commander la lampe." else if (wantsOff) "Lampe éteinte." else "Lampe allumée.")
        }

        if (Regex("\\bne pas deranger\\b").containsMatchIn(n)) {
            if (!phone.canControlDnd()) {
                phone.askDndAccess()
                return done("Autorise d'abord Calepin IA dans la liste « Ne pas déranger » qui vient de s'ouvrir, puis redemande-moi.")
            }
            val ok = phone.doNotDisturb(!wantsOff)
            return done(if (!ok) "Je n'ai pas pu changer le mode Ne pas déranger." else if (wantsOff) "Ne pas déranger désactivé." else "Ne pas déranger activé.")
        }

        val ringer = when {
            Regex("\\b(mode )?silencieux\\b").containsMatchIn(n) && !wantsOff -> "silent"
            Regex("\\b(mode )?vibreur\\b").containsMatchIn(n) && !wantsOff -> "vibrate"
            Regex("\\b(sonnerie normale|mode normal|remets la sonnerie|active la sonnerie)\\b").containsMatchIn(n) ||
                (Regex("\\b(silencieux|vibreur)\\b").containsMatchIn(n) && wantsOff) -> "normal"
            else -> null
        }
        if (ringer != null) {
            if (ringer == "silent" && !phone.canControlDnd()) {
                phone.askDndAccess()
                return done("Pour passer en silencieux, autorise d'abord Calepin IA dans la liste « Ne pas déranger », puis redemande-moi.")
            }
            val ok = phone.ringer(ringer)
            return done(
                if (!ok) "Je n'ai pas pu changer la sonnerie."
                else when (ringer) { "silent" -> "Téléphone en silencieux."; "vibrate" -> "Téléphone en vibreur."; else -> "Sonnerie rétablie." }
            )
        }

        if (Regex("\\bluminosite\\b").containsMatchIn(n)) {
            if (!phone.canWriteSettings()) {
                phone.askWriteSettings()
                return done("Autorise Calepin IA à « modifier les paramètres système » dans l'écran qui vient de s'ouvrir, puis redemande-moi.")
            }
            val pct = Regex("(\\d{1,3}) ?(%|pour ?cent)").find(n)?.groupValues?.get(1)?.toIntOrNull()
            val ok = when {
                Regex("\\bauto(matique)?\\b").containsMatchIn(n) -> phone.autoBrightness()
                pct != null -> phone.brightness(pct.coerceIn(1, 100) * 255 / 100, relative = false)
                Regex("\\b(max|maximum|a fond|plein)\\b").containsMatchIn(n) -> phone.brightness(255, false)
                Regex("\\b(min|minimum|au plus bas)\\b").containsMatchIn(n) -> phone.brightness(5, false)
                Regex("\\b(augmente|monte|plus)\\b").containsMatchIn(n) -> phone.brightness(50, true)
                Regex("\\b(baisse|diminue|moins)\\b").containsMatchIn(n) -> phone.brightness(-50, true)
                else -> return null
            }
            return done(if (ok) "Luminosité réglée." else "Je n'ai pas pu régler la luminosité.")
        }

        if (Regex("\\brotation\\b").containsMatchIn(n)) {
            if (!phone.canWriteSettings()) {
                phone.askWriteSettings()
                return done("Autorise Calepin IA à « modifier les paramètres système » dans l'écran qui vient de s'ouvrir, puis redemande-moi.")
            }
            val ok = phone.autoRotate(!wantsOff && !Regex("\\b(bloque|verrouille)\\b").containsMatchIn(n))
            return done(if (ok) "C'est fait." else "Je n'ai pas pu changer la rotation.")
        }

        // Volume du téléphone (sans mention de la télé, déjà traitée plus haut)
        if (Regex("\\b(son|volume)\\b").containsMatchIn(n) && Regex("\\b(monte|augmente|baisse|diminue|coupe|plus fort|moins fort)\\b").containsMatchIn(n)) {
            val steps = Regex("\\b(?:de|a) (\\d{1,2})\\b").find(n)?.groupValues?.get(1)?.toIntOrNull() ?: 2
            val s = when {
                Regex("\\bcoupe\\b").containsMatchIn(n) -> 0
                Regex("\\b(baisse|diminue|moins fort)\\b").containsMatchIn(n) -> -steps
                else -> steps
            }
            return done(if (phone.mediaVolume(s)) "Volume du téléphone réglé." else "Je n'ai pas pu régler le volume.")
        }

        // Réglages qu'Android réserve à l'utilisateur : on ouvre le bon écran
        val panel: Pair<() -> Boolean, String>? = when {
            Regex("\\bbluetooth\\b").containsMatchIn(n) -> phone::openBluetooth to "le Bluetooth"
            Regex("\\b(wifi|wi fi|wi-fi)\\b").containsMatchIn(n) -> phone::openWifi to "le Wi-Fi"
            Regex("\\b(donnees mobiles|4g|5g|internet mobile)\\b").containsMatchIn(n) -> phone::openMobileData to "les données mobiles"
            Regex("\\bnfc\\b").containsMatchIn(n) -> phone::openNfc to "le NFC"
            Regex("\\b(mode avion)\\b").containsMatchIn(n) -> phone::openAirplane to "le mode avion"
            Regex("\\b(economi\\w* d.?energie|economiseur|economie de batterie|mode eco)\\b").containsMatchIn(n) -> phone::openBatterySaver to "l'économie d'énergie"
            Regex("\\b(localisation|gps)\\b").containsMatchIn(n) -> phone::openLocation to "la localisation"
            Regex("\\b(point d.?acces|partage de connexion)\\b").containsMatchIn(n) -> phone::openHotspot to "le partage de connexion"
            else -> null
        }
        if (panel != null && Regex("\\b(active|desactive|allume|eteins|coupe|ouvre|mets|enleve|arrete)\\b").containsMatchIn(n)) {
            val (open, what) = panel
            return done(
                if (open()) "J'ouvre le réglage pour $what : touche l'interrupteur (Android ne laisse aucune appli le faire seule)."
                else "Je n'ai pas pu ouvrir le réglage pour $what."
            )
        }
        return null
    }

    // ------------------------------------------------------------ Ouvrir une appli

    private fun openApp(text: String, n: String): Done? {
        val m = Regex("^(?:ouvre|ouvrir|lance|lancer|demarre|demarrer)(?:[ -]moi)?(?: l'appli(?:cation)?| l'app| l'application)?\\s+(.+)$").find(n) ?: return null
        val target = m.groupValues[1].removePrefix("le ").removePrefix("la ").removePrefix("les ").trim()
        // « ouvre la note… », « ouvre l'agenda » : laissés à l'assistant de Calepin
        if (Regex("\\b(note|notes|liste|agenda|calendrier calepin|rappel|memo)\\b").containsMatchIn(target)) return null
        val app = phone.findApp(target) ?: return null
        return done(if (phone.openApp(app)) "J'ouvre ${app.label}." else "${app.label} n'a pas pu s'ouvrir.")
    }

    /** Résumé des commandes, affiché dans les réglages et donné à l'IA. */
    companion object {
        val EXAMPLES = listOf(
            "allume la télé", "éteins la télé", "mets France 2", "mets la chaîne 6", "chaîne suivante",
            "monte le son de la télé", "coupe le son de la télé", "mets Netflix sur la télé", "mets la télé sur HDMI 2",
            "ouvre WhatsApp", "cherche recette de tiramisu sur YouTube", "envoie un WhatsApp à Marc : j'arrive",
            "allume la lampe", "active le Bluetooth", "active le Wi-Fi", "active l'économie d'énergie",
            "mode silencieux", "active ne pas déranger", "luminosité à 50 %", "baisse le son", "niveau de batterie",
        )
    }
}
