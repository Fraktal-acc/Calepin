package fr.jeremy.calepin.control

import android.content.Context
import fr.jeremy.calepin.contacts.PhoneContacts
import fr.jeremy.calepin.search.TextNorm
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Commandes de la maison et du téléphone en français courant (Calepin IA).
 * Renvoie la réponse à afficher, ou null si la phrase n'est pas une commande d'appareil
 * (l'assistant habituel prend alors le relais).
 */
class DeviceCommands(context: Context) {
    private val ctx = context.applicationContext
    private val phone = PhoneControl(ctx)
    private val store = DeviceStore(ctx)

    data class Done(val text: String)

    private data class PendingWa(val name: String, val number: String, val message: String, val at: Long)

    @Volatile private var pendingWa: PendingWa? = null

    /** Réponse dans la langue de l'appli (textes écrits en français, traduits ici). */
    private fun done(t: String) = Done(fr.jeremy.calepin.i18n.I18n.tr(t))

    suspend fun handle(raw: String): Done? = withContext(Dispatchers.IO) {
        val text = raw.trim().trimEnd('.', '!', '?', ' ')
        val n = TextNorm.norm(text).replace(Regex("\\s+"), " ")
        if (n.isBlank()) return@withContext null
        scenario(n) ?: confirmWhatsapp(n) ?: allLights(n) ?: named(n) ?: guide(n) ?: tv(n, null) ?: youtube(text, n) ?: whatsapp(text, n) ?: phoneSettings(n) ?: openApp(text, n)
    }

    /** « Lance soirée film » : enchaîne les commandes du scénario. */
    private suspend fun scenario(n: String): Done? {
        if (Scenarios.running) return null // une étape ne relance pas de scénario
        // « Comme d'habitude » : le scénario le plus souvent lancé à cette heure-ci
        if (Regex("^(fais |lance |mets )?(comme d'habitude|comme d habitude|comme dhabitude|la routine habituelle)$").matches(n)) {
            val usual = fr.jeremy.calepin.care.Routines.usual(ctx) ?: return done("Je ne connais pas encore tes habitudes à cette heure-ci : lance un scénario quelques fois et je m'en souviendrai.")
            return done(Scenarios.run(ctx, usual))
        }
        val sc = Scenarios.find(ctx, n) ?: return null
        return done(Scenarios.run(ctx, sc))
    }

    // ------------------------------------------------------------ Verbes

    private val on = Regex("\\b(allume|allumer|demarre|demarrer|active|activer|mets en marche|lance|lancer)\\b")
    private val off = Regex("\\b(eteins|eteindre|eteint|arrete|arreter|desactive|desactiver|coupe|couper)\\b|\\ben veille\\b")
    private val pctRx = Regex("(\\d{1,3}) ?(%|pour ?cent|pourcent)")

    private fun pct(n: String): Int? = pctRx.find(n)?.groupValues?.get(1)?.toIntOrNull()
        ?: when {
            Regex("\\b(a fond|au max|maximum)\\b").containsMatchIn(n) -> 100
            Regex("\\b(au minimum|tamise|tamisee)\\b").containsMatchIn(n) -> 10
            Regex("\\b(a moitie|a mi)\\b").containsMatchIn(n) -> 50
            else -> null
        }

    // ------------------------------------------------------------ Appareils nommés

    /** Cherche le nom d'un appareil (ou d'une lampe, pièce, entité) dans la phrase ; le nom le plus long l'emporte. */
    private fun findTarget(n: String): Target? {
        val clean = " " + n.replace(Regex("[^a-z0-9 ]"), " ").replace(Regex("\\s+"), " ") + " "
        return store.targets().filter { it.normName.length >= 2 && clean.contains(" ${it.normName} ") }.maxByOrNull { it.normName.length }
    }

    private fun named(n: String): Done? {
        val t = findTarget(n) ?: return null
        val d = t.device
        if (d.role == Role.TV || d.role == Role.DECODER) return null // traité par tv(), qui sait viser cet appareil
        val label = t.name.replaceFirstChar { it.uppercase() }
        val p = pct(n)
        val isOff = off.containsMatchIn(n)
        val ok: Boolean
        val what: String
        when {
            Regex("\\b(ouvre|ouvrir|monte)\\b").containsMatchIn(n) && t.type == "cover" -> { ok = SmartHome.activate(t, "open"); what = "$label : ouverture." }
            Regex("\\b(ferme|fermer|baisse|descends)\\b").containsMatchIn(n) && t.type == "cover" -> { ok = SmartHome.activate(t, "close"); what = "$label : fermeture." }
            t.type == "scene" || t.type == "script" -> { ok = SmartHome.activate(t); what = "$label lancé." }
            isOff -> { ok = SmartHome.power(t, false); what = "$label éteint." }
            p != null -> { ok = SmartHome.brightness(t, p); what = "$label à $p %." }
            on.containsMatchIn(n) || Regex("\\b(mets|met)\\b").containsMatchIn(n) -> { ok = SmartHome.power(t, true); what = "$label allumé." }
            else -> return null
        }
        return done(if (ok) what else "$label ne répond pas. Vérifie qu'il est branché et sur le même Wi-Fi.")
    }

    /** « éteins toutes les lumières », « allume tout ». */
    private fun allLights(n: String): Done? {
        val everything = Regex("^(allume|allumer|eteins|eteindre|eteint|coupe) tout$|^tout (eteindre|allumer)$").containsMatchIn(n)
        if (!everything && !Regex("\\btoutes les (lumieres|lampes)\\b").containsMatchIn(n)) return null
        val isOff = off.containsMatchIn(n)
        if (!isOff && !on.containsMatchIn(n)) return null
        val lights = store.targets().filter {
            it.type == "light" || it.type == "room" || it.device.role == Role.LIGHT ||
                (everything && (it.type == "switch" || it.device.role == Role.PLUG))
        }.filter { it.type != "room" || lightsAreOnlyRooms() }
        if (lights.isEmpty()) return null
        val ok = lights.count { SmartHome.power(it, !isOff) }
        return done(if (ok == 0) "Aucune lumière n'a répondu." else if (isOff) "$ok éteinte(s)." else "$ok allumée(s).")
    }

    /** Évite d'allumer deux fois les mêmes lampes Hue (lampe + pièce) : on garde les pièces seulement si aucune lampe n'est connue. */
    private fun lightsAreOnlyRooms() = store.targets().none { it.type == "light" }

    // ------------------------------------------------------------ Télévision et décodeur

    /** « Qu'est-ce qu'il y a à la télé ce soir ? », « mets le film de ce soir ». */
    private suspend fun guide(n: String): Done? {
        val film = Regex("\\b(mets|met|lance|regarde|regarder|passe|allume)\\b.*\\bfilm\\b").containsMatchIn(n) &&
            (Regex("\\bce soir\\b").containsMatchIn(n) || Regex("^(mets|met|lance) (le|un) film$").matches(n))
        val what = !film && (
            Regex("\\bce soir\\b.*\\b(tele|tv)\\b|\\b(tele|tv)\\b.*\\bce soir\\b").containsMatchIn(n) ||
                Regex("\\b(programme|guide) (tele|tv)\\b|\\bfilm (de )?ce soir\\b|\\bqu.?est.?ce qu.?il y a a la (tele|tv)\\b").containsMatchIn(n)
            )
        if (!film && !what) return null
        val list = TvGuide.load(ctx).getOrNull() ?: return done("Je n'arrive pas à charger le programme télé (pas de connexion ?).")
        val hm = java.text.SimpleDateFormat(fr.jeremy.calepin.i18n.I18n.pattern("H'h'mm"), fr.jeremy.calepin.i18n.I18n.locale)
        val tonight = TvGuide.tonight(list)
        if (film || Regex("\\bfilm\\b").containsMatchIn(n)) {
            val f = TvGuide.tonightFilm(list) ?: return done("Je ne trouve pas de film ce soir sur les chaînes de la TNT.")
            val intro = fr.jeremy.calepin.i18n.I18n.trf("Ce soir : « {0} » sur {1} à {2}.", f.title, f.channel, hm.format(java.util.Date(f.start)))
            if (!film) return Done(intro)
            val num = f.number ?: return Done(intro)
            val r = tv("mets la chaine $num", null)
            return Done(intro + (r?.text?.let { " $it" } ?: ""))
        }
        if (tonight.isEmpty()) return done("Le programme de ce soir n'est pas encore disponible.")
        val lines = tonight.filter { (it.number ?: 99) <= 14 }.take(10).joinToString("\n") { p ->
            "${p.number ?: ""} ${p.channel} · ${hm.format(java.util.Date(p.start))} · ${p.title}" + (if (p.category.isNotBlank()) " (${p.category.substringBefore(",")})" else "")
        }
        return Done(fr.jeremy.calepin.i18n.I18n.tr("Ce soir à la télé :") + "\n" + lines)
    }

    private val tvWord = Regex("\\b(tele|tv|television|televiseur|decodeur|box|bravia|sony|samsung|lg|freebox|bbox|chromecast|roku|shield)\\b")

    private suspend fun tv(n: String, unused: HomeDevice?): Done? {
        val channel = OrangeDecoder.findChannel(n)
        val zap = Regex("\\b(mets|met|passe|zappe|change|regarder|regarde|chaine|programme)\\b").containsMatchIn(n)
        val number = Regex("\\b(?:chaine|numero|la)\\s*(?:numero\\s*)?(\\d{1,3})\\b").find(n)?.groupValues?.get(1)?.toIntOrNull()
        val namedDevice = findTarget(n)?.device?.takeIf { it.role == Role.TV || it.role == Role.DECODER }
        val hasTv = tvWord.containsMatchIn(n) || namedDevice != null
        if (!hasTv && !(zap && (channel != null || (number != null && "chaine" in n)))) return null

        val decDev = namedDevice?.takeIf { it.role == Role.DECODER } ?: store.defaultFor(Role.DECODER)
        val tvDev = namedDevice?.takeIf { it.role == Role.TV } ?: store.defaultFor(Role.TV)
        val onlyOne = namedDevice != null
        val dec = (if (onlyOne && namedDevice?.role != Role.DECODER) null else decDev)?.let { TvDrivers.forDevice(it, store) }
        val tv = (if (onlyOne && namedDevice?.role != Role.TV) null else tvDev)?.let { TvDrivers.forDevice(it, store) }
        if (dec == null && tv == null) {
            return done("Aucune télé ni décodeur enregistré : va dans Paramètres → Maison et téléphone → Appareils de la maison, puis « Rechercher ».")
        }
        val decoderOnly = Regex("\\b(decodeur|box)\\b").containsMatchIn(n) && !Regex("\\b(tele|tv|television|televiseur)\\b").containsMatchIn(n)
        val sound = Regex("\\b(son|volume)\\b").containsMatchIn(n) || "plus fort" in n || "moins fort" in n

        // Volume
        if (sound) {
            val steps = Regex("\\b(?:de|a) (\\d{1,2})\\b").find(n)?.groupValues?.get(1)?.toIntOrNull() ?: 3
            val s = when {
                Regex("\\b(coupe|mute|silence|remets|retablis|reactive)\\b").containsMatchIn(n) -> 0
                Regex("\\b(monte|augmente|plus fort|hausse)\\b").containsMatchIn(n) -> steps
                Regex("\\b(baisse|diminue|moins fort)\\b").containsMatchIn(n) -> -steps
                else -> return null
            }
            val target = if (decoderOnly) dec ?: tv else tv ?: dec
            return done(if (target!!.volume(s)) "C'est fait." else "L'appareil ne répond pas sur le Wi-Fi.")
        }

        // Allumer / éteindre
        if (off.containsMatchIn(n) && channel == null && number == null) {
            val parts = mutableListOf<String>()
            if (dec != null) parts += if (dec.power(false)) fr.jeremy.calepin.i18n.I18n.trf("{0} en veille", decDev!!.name) else fr.jeremy.calepin.i18n.I18n.trf("{0} injoignable", decDev!!.name)
            if (tv != null && !decoderOnly) parts += if (tv.power(false)) fr.jeremy.calepin.i18n.I18n.trf("{0} éteinte", tvDev!!.name) else fr.jeremy.calepin.i18n.I18n.trf("{0} injoignable", tvDev!!.name)
            return done(parts.joinToString(", ").replaceFirstChar { it.uppercase() } + ".")
        }
        if (on.containsMatchIn(n) && channel == null && number == null && !Regex("\\bsur (la|le) ").containsMatchIn(n)) {
            val parts = mutableListOf<String>()
            if (tv != null && !decoderOnly) parts += if (tv.power(true)) fr.jeremy.calepin.i18n.I18n.trf("{0} allumée", tvDev!!.name) else fr.jeremy.calepin.i18n.I18n.trf("{0} injoignable", tvDev!!.name)
            if (dec != null) parts += if (dec.power(true)) fr.jeremy.calepin.i18n.I18n.trf("{0} allumé", decDev!!.name) else fr.jeremy.calepin.i18n.I18n.trf("{0} injoignable", decDev!!.name)
            return done(parts.joinToString(", ").replaceFirstChar { it.uppercase() } + ".")
        }

        // Entrée HDMI
        Regex("\\bhdmi ?(\\d)\\b").find(n)?.let { m ->
            val t = tv ?: return done("Aucun téléviseur enregistré.")
            val port = m.groupValues[1].toInt()
            return done(if (t.hdmi(port)) "Télé sur HDMI $port." else "Ce téléviseur ne permet pas de changer d'entrée depuis le téléphone.")
        }

        // Chaîne suivante / précédente
        val zapper = dec ?: tv!!
        if (Regex("\\bchaine (suivante|d'apres)\\b").containsMatchIn(n) || ("zappe" in n && channel == null && number == null)) {
            return done(if (zapper.channelStep(true)) "Chaîne suivante." else "L'appareil ne répond pas.")
        }
        if (Regex("\\bchaine (precedente|d'avant)\\b").containsMatchIn(n)) {
            return done(if (zapper.channelStep(false)) "Chaîne précédente." else "L'appareil ne répond pas.")
        }

        // Pause / lecture
        if (Regex("\\b(pause|reprends|reprendre|lecture)\\b").containsMatchIn(n)) {
            return done(if (zapper.playPause()) "C'est fait." else "L'appareil ne répond pas.")
        }

        // Changer de chaîne
        if (channel != null || number != null) {
            val zapDev = if (dec != null) decDev!! else tvDev!!
            if (channel != null && channel.number > 27 && zapDev.kind != Kind.ORANGE) {
                return done("Je ne connais pas le numéro de ${channel.names.first().uppercase()} chez ton opérateur : dis « mets la chaîne » suivi du numéro.")
            }
            val num = channel?.number ?: number!!
            val label = channel?.names?.first()?.uppercase() ?: "la chaîne $num"
            return done(if (zapper.channel(num, channel)) "Je mets $label." else "L'appareil ne répond pas sur le Wi-Fi.")
        }

        // Appli sur la télé : « mets Netflix sur la télé »
        Regex("^(?:mets|met|lance|ouvre|demarre)\\s+(.+?)\\s+sur\\s+(?:la|le|ma|mon)\\s+(?:tele|tv|television|televiseur|box|decodeur)\\b").find(n)?.let { m ->
            val want = m.groupValues[1]
            val opened = tv?.openApp(want) ?: dec?.openApp(want)
            return done(if (opened != null) "J'ouvre $opened sur la télé." else "Je n'ai pas pu ouvrir « $want » sur la télé (appli absente, ou télé éteinte ?).")
        }

        return null
    }

    // ------------------------------------------------------------ YouTube

    private fun youtube(text: String, n: String): Done? {
        if ("youtube" !in n) return null
        val m = Regex("^(?:cherche|recherche|mets|met|lance|regarde|joue|trouve)(?:[ -]moi)?\\s+(.+?)\\s+sur youtube$").find(n)
            ?: Regex("^youtube\\s*:?\\s+(.+)$").find(n)
        if (m == null) return null
        // On reprend la recherche dans le texte d'origine (accents compris)
        val start = m.groups[1]!!.range.first
        val end = m.groups[1]!!.range.last + 1
        val query = text.substring(start.coerceAtMost(text.length), end.coerceAtMost(text.length)).ifBlank { m.groupValues[1] }
        return done(if (phone.youtubeSearch(query)) "Je cherche « $query » sur YouTube." else "YouTube n'a pas pu s'ouvrir.")
    }

    // ------------------------------------------------------------ WhatsApp

    private fun whatsapp(text: String, n: String): Done? {
        if ("whatsapp" !in n) return null
        val m = Regex("^(?:envoie|envoyer|ecris|ecrire|message)(?: un)?(?: message)?(?: whatsapp)?(?: par| sur)?(?: whatsapp)? a (.+?)\\s*:\\s*(.+)$").find(n)
            ?: Regex("^whatsapp a (.+?)\\s*:\\s*(.+)$").find(n)
            ?: Regex("^(?:envoie|envoyer|ecris|ecrire|dis)(?: un)?(?: message)?(?: whatsapp)? a (.+?) (?:sur|par) whatsapp\\s*:\\s*(.+)$").find(n)
            ?: return null
        val who = m.groupValues[1].trim()
        val colon = text.indexOf(':')
        val message = if (colon >= 0) text.substring(colon + 1).trim() else m.groupValues[2]
        if (message.isBlank()) return done("Quel message dois-je envoyer à $who ? Dis par exemple « envoie un WhatsApp à $who : j'arrive ».")
        if (!PhoneContacts.hasPermission(ctx)) return done("Autorise l'accès aux contacts (écran Contacts de Calepin IA) pour que je trouve « $who ».")
        val found = PhoneContacts.filter(PhoneContacts.load(ctx), who).filter { it.phones.isNotEmpty() }
        if (found.size > 1 && found.none { TextNorm.norm(it.name) == who }) {
            return Done(fr.jeremy.calepin.i18n.I18n.trf("Plusieurs contacts correspondent à « {0} » : {1}. Précise le nom.", who, found.take(4).joinToString(", ") { it.name }))
        }
        val c = found.firstOrNull { TextNorm.norm(it.name) == who } ?: found.firstOrNull()
            ?: return done("Je ne trouve pas « $who » dans tes contacts.")
        val number = (c.phones.firstOrNull { it.label.contains("mobile", true) || it.value.filter(Char::isDigit).let { d -> d.startsWith("06") || d.startsWith("07") || d.startsWith("336") || d.startsWith("337") } } ?: c.phones.first()).value
        pendingWa = PendingWa(c.name, number, message, System.currentTimeMillis())
        return done("J'envoie « $message » à ${c.name} sur WhatsApp ? Dis « oui » pour confirmer ou « non » pour annuler.")
    }

    /** Vrai pendant qu'un message WhatsApp attend « oui » ou « non ». */
    val awaitingConfirmation: Boolean get() = pendingWa?.let { System.currentTimeMillis() - it.at <= 3 * 60_000 } == true

    /** Réponse à la question de confirmation d'un message WhatsApp. */
    private fun confirmWhatsapp(n: String): Done? {
        val p = pendingWa ?: return null
        if (System.currentTimeMillis() - p.at > 3 * 60_000) { pendingWa = null; return null }
        // Oui / non dans les cinq langues de l'appli
        val yes = Regex("^(oui|ouais|yes|yeah|yep|sure|confirme|confirmer|confirm|envoie|envoie le|envoie-le|send it|send|vas y|vas-y|ok|okay|d'accord|c'est bon|go|si|certo|va bene|invia|claro|vale|envia|ja|jawohl|klar|genau|senden|schick)\\b").containsMatchIn(n)
        val no = Regex("^(non|no|nope|annule|annuler|cancel|laisse tomber|stop|pas maintenant|not now|annulla|cancela|nein|abbrechen|nicht)\\b").containsMatchIn(n)
        pendingWa = null
        if (no) return done("Message annulé.")
        if (!yes) return null
        val auto = WhatsAppSender.isEnabled(ctx)
        if (auto) WhatsAppSender.arm(p.message)
        val opened = phone.whatsapp(p.number, p.message)
        if (!opened) { WhatsAppSender.disarm(); return done("WhatsApp n'a pas pu s'ouvrir.") }
        return done(
            if (auto) "J'envoie le message à ${p.name}…"
            else "Message prêt pour ${p.name} dans WhatsApp : touche Envoyer. Pour que je l'envoie moi-même, active « Envoi automatique WhatsApp » dans Paramètres → Maison et téléphone."
        )
    }

    // ------------------------------------------------------------ Réglages du téléphone

    private fun phoneSettings(n: String): Done? {
        val wantsOff = off.containsMatchIn(n) || Regex("\\b(coupe|desactive)\\b").containsMatchIn(n)

        if (Regex("\\bbatterie\\b").containsMatchIn(n) && Regex("\\b(niveau|combien|reste|etat|pourcentage|charge|batterie)\\b").containsMatchIn(n) &&
            !Regex("\\b(economi|mode)\\b").containsMatchIn(n)
        ) return done(phone.battery())

        if (Regex("\\b(lampe de poche|lampe torche|torche|flash|lampe du telephone|lampe)\\b").containsMatchIn(n)) {
            val ok = phone.torch(!wantsOff)
            return done(if (!ok) "Je n'ai pas pu commander la lampe." else if (wantsOff) "Lampe éteinte." else "Lampe allumée.")
        }

        if (Regex("\\bne pas deranger\\b").containsMatchIn(n)) {
            if (!phone.canControlDnd()) {
                phone.askDndAccess()
                return done("Autorise d'abord Calepin IA dans la liste « Ne pas déranger » qui vient de s'ouvrir, puis redemande-moi.")
            }
            val ok = phone.doNotDisturb(!wantsOff)
            return done(if (!ok) "Je n'ai pas pu changer le mode Ne pas déranger." else if (wantsOff) "Ne pas déranger désactivé." else "Ne pas déranger activé.")
        }

        val ringer = when {
            Regex("\\b(mode )?silencieux\\b").containsMatchIn(n) && !wantsOff -> "silent"
            Regex("\\b(mode )?vibreur\\b").containsMatchIn(n) && !wantsOff -> "vibrate"
            Regex("\\b(sonnerie normale|mode normal|remets la sonnerie|active la sonnerie)\\b").containsMatchIn(n) ||
                (Regex("\\b(silencieux|vibreur)\\b").containsMatchIn(n) && wantsOff) -> "normal"
            else -> null
        }
        if (ringer != null) {
            if (ringer == "silent" && !phone.canControlDnd()) {
                phone.askDndAccess()
                return done("Pour passer en silencieux, autorise d'abord Calepin IA dans la liste « Ne pas déranger », puis redemande-moi.")
            }
            val ok = phone.ringer(ringer)
            return done(
                if (!ok) "Je n'ai pas pu changer la sonnerie."
                else when (ringer) { "silent" -> "Téléphone en silencieux."; "vibrate" -> "Téléphone en vibreur."; else -> "Sonnerie rétablie." }
            )
        }

        if (Regex("\\bluminosite\\b").containsMatchIn(n)) {
            if (!phone.canWriteSettings()) {
                phone.askWriteSettings()
                return done("Autorise Calepin IA à « modifier les paramètres système » dans l'écran qui vient de s'ouvrir, puis redemande-moi.")
            }
            val pct = Regex("(\\d{1,3}) ?(%|pour ?cent)").find(n)?.groupValues?.get(1)?.toIntOrNull()
            val ok = when {
                Regex("\\bauto(matique)?\\b").containsMatchIn(n) -> phone.autoBrightness()
                pct != null -> phone.brightness(pct.coerceIn(1, 100) * 255 / 100, relative = false)
                Regex("\\b(max|maximum|a fond|plein)\\b").containsMatchIn(n) -> phone.brightness(255, false)
                Regex("\\b(min|minimum|au plus bas)\\b").containsMatchIn(n) -> phone.brightness(5, false)
                Regex("\\b(augmente|monte|plus)\\b").containsMatchIn(n) -> phone.brightness(50, true)
                Regex("\\b(baisse|diminue|moins)\\b").containsMatchIn(n) -> phone.brightness(-50, true)
                else -> return null
            }
            return done(if (ok) "Luminosité réglée." else "Je n'ai pas pu régler la luminosité.")
        }

        if (Regex("\\brotation\\b").containsMatchIn(n)) {
            if (!phone.canWriteSettings()) {
                phone.askWriteSettings()
                return done("Autorise Calepin IA à « modifier les paramètres système » dans l'écran qui vient de s'ouvrir, puis redemande-moi.")
            }
            val ok = phone.autoRotate(!wantsOff && !Regex("\\b(bloque|verrouille)\\b").containsMatchIn(n))
            return done(if (ok) "C'est fait." else "Je n'ai pas pu changer la rotation.")
        }

        // Volume du téléphone (sans mention de la télé, déjà traitée plus haut)
        if (Regex("\\b(son|volume)\\b").containsMatchIn(n) && Regex("\\b(monte|augmente|baisse|diminue|coupe|plus fort|moins fort)\\b").containsMatchIn(n)) {
            val steps = Regex("\\b(?:de|a) (\\d{1,2})\\b").find(n)?.groupValues?.get(1)?.toIntOrNull() ?: 2
            val s = when {
                Regex("\\bcoupe\\b").containsMatchIn(n) -> 0
                Regex("\\b(baisse|diminue|moins fort)\\b").containsMatchIn(n) -> -steps
                else -> steps
            }
            return done(if (phone.mediaVolume(s)) "Volume du téléphone réglé." else "Je n'ai pas pu régler le volume.")
        }

        // Réglages qu'Android réserve à l'utilisateur : on ouvre le bon écran
        val panel: Pair<() -> Boolean, String>? = when {
            Regex("\\bbluetooth\\b").containsMatchIn(n) -> phone::openBluetooth to "le Bluetooth"
            Regex("\\b(wifi|wi fi|wi-fi)\\b").containsMatchIn(n) -> phone::openWifi to "le Wi-Fi"
            Regex("\\b(donnees mobiles|4g|5g|internet mobile)\\b").containsMatchIn(n) -> phone::openMobileData to "les données mobiles"
            Regex("\\bnfc\\b").containsMatchIn(n) -> phone::openNfc to "le NFC"
            Regex("\\b(mode avion)\\b").containsMatchIn(n) -> phone::openAirplane to "le mode avion"
            Regex("\\b(economi\\w* d.?energie|economiseur|economie de batterie|mode eco)\\b").containsMatchIn(n) -> phone::openBatterySaver to "l'économie d'énergie"
            Regex("\\b(localisation|gps)\\b").containsMatchIn(n) -> phone::openLocation to "la localisation"
            Regex("\\b(point d.?acces|partage de connexion)\\b").containsMatchIn(n) -> phone::openHotspot to "le partage de connexion"
            else -> null
        }
        if (panel != null && Regex("\\b(active|desactive|allume|eteins|coupe|ouvre|mets|enleve|arrete)\\b").containsMatchIn(n)) {
            val (open, what) = panel
            return done(
                if (open()) "J'ouvre le réglage pour $what : touche l'interrupteur (Android ne laisse aucune appli le faire seule)."
                else "Je n'ai pas pu ouvrir le réglage pour $what."
            )
        }
        return null
    }

    // ------------------------------------------------------------ Ouvrir une appli

    private fun openApp(text: String, n: String): Done? {
        val m = Regex("^(?:ouvre|ouvrir|lance|lancer|demarre|demarrer)(?:[ -]moi)?(?: l'appli(?:cation)?| l'app| l'application)?\\s+(.+)$").find(n) ?: return null
        val target = m.groupValues[1].removePrefix("le ").removePrefix("la ").removePrefix("les ").trim()
        // « ouvre la note… », « ouvre l'agenda » : laissés à l'assistant de Calepin
        if (Regex("\\b(note|notes|liste|agenda|calendrier calepin|rappel|memo)\\b").containsMatchIn(target)) return null
        val app = phone.findApp(target) ?: return null
        return done(if (phone.openApp(app)) "J'ouvre ${app.label}." else "${app.label} n'a pas pu s'ouvrir.")
    }

    /** Résumé des commandes, affiché dans les réglages et donné à l'IA. */
    companion object {
        val EXAMPLES = listOf(
            "allume la télé", "éteins la télé", "qu'est-ce qu'il y a à la télé ce soir", "mets le film de ce soir", "mets France 2", "mets la chaîne 6", "chaîne suivante",
            "monte le son de la télé", "coupe le son de la télé", "mets Netflix sur la télé", "mets la télé sur HDMI 2",
            "allume la lampe du salon", "éteins toutes les lumières", "lampe du salon à 30 %", "ferme le volet de la chambre",
            "lance la scène cinéma", "ouvre WhatsApp", "cherche recette de tiramisu sur YouTube",
            "envoie un WhatsApp à Marc : j'arrive", "allume la lampe de poche", "active le Bluetooth",
            "active l'économie d'énergie", "mode silencieux", "active ne pas déranger", "luminosité à 50 %", "niveau de batterie",
        )
    }
}
