package fr.jeremy.calepin.care

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

/** Mode nuit au travail : écran rouge très sombre (ne fatigue pas les yeux, ne réveille personne) et gros boutons. */
object NightWork {
    private val _on = MutableStateFlow(false)
    val on: StateFlow<Boolean> = _on
    private var loaded = false

    private fun p(ctx: Context) = ctx.applicationContext.getSharedPreferences("calepin_care", Context.MODE_PRIVATE)

    fun init(ctx: Context) {
        if (loaded) return
        loaded = true
        _on.value = p(ctx).getBoolean("night_work", false)
    }

    fun set(ctx: Context, value: Boolean) {
        loaded = true
        _on.value = value
        p(ctx).edit().putBoolean("night_work", value).apply()
    }
}
