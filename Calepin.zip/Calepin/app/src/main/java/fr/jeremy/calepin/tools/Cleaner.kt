package fr.jeremy.calepin.tools

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileInputStream
import java.security.MessageDigest
import kotlin.coroutines.coroutineContext

/** Catégories du nettoyeur. [preselected] : coché d'office (sans risque de perdre quelque chose d'utile). */
enum class JunkKind(val label: String, val desc: String, val preselected: Boolean) {
    APP_CACHE("Cache de Calepin", "Fichiers temporaires de Calepin (exports déjà partagés, aperçus…)", true),
    TEMP("Fichiers temporaires et journaux", "Fichiers .tmp, .log et restes d'installations laissés par les applis", true),
    THUMBS("Miniatures", "Aperçus des photos recréés automatiquement par la galerie", true),
    EMPTY("Dossiers vides", "Dossiers qui ne contiennent plus rien", true),
    APK("Fichiers d'installation (APK)", "Programmes d'installation déjà téléchargés : l'appli reste installée", true),
    DUPLICATES("Doublons", "Fichiers identiques présents plusieurs fois : un exemplaire est gardé", false),
    BIG("Gros fichiers (plus de 50 Mo)", "Vidéos, archives, sauvegardes… À vérifier avant de supprimer", false),
}

data class JunkFile(val file: File, val size: Long, val kind: JunkKind, val group: Int = 0, val keep: Boolean = false)

data class ScanResult(val items: Map<JunkKind, List<JunkFile>>) {
    fun size(kind: JunkKind) = items[kind].orEmpty().sumOf { it.size }
}

/**
 * Analyse du stockage du téléphone : cherche ce qui peut être supprimé sans risque
 * (Android ne laisse pas une appli vider le cache des autres applis : seul leur propre réglage le peut).
 */
object Cleaner {
    private const val BIG = 50L * 1024 * 1024
    private const val DUP_MIN = 200L * 1024
    private val TEMP_EXT = setOf("tmp", "temp", "log", "trace", "bak~", "part", "crdownload", "dmp")
    // Dossiers à ne jamais toucher (données privées des applis, inaccessibles ou sensibles)
    private val SKIP = setOf("android/data", "android/obb")

    suspend fun scan(ctx: Context, progress: (Int, String) -> Unit): ScanResult = withContext(Dispatchers.IO) {
        val out = HashMap<JunkKind, MutableList<JunkFile>>()
        fun add(j: JunkFile) { out.getOrPut(j.kind) { ArrayList() } += j }

        // Cache de Calepin
        listOfNotNull(ctx.cacheDir, ctx.externalCacheDir).forEach { dir ->
            dir.listFiles()?.forEach { f -> add(JunkFile(f, PhoneInfo.dirSize(f), JunkKind.APP_CACHE)) }
        }

        val root = StorageAccess.root
        val bySize = HashMap<Long, MutableList<File>>()
        var count = 0
        val empties = ArrayList<File>()

        suspend fun walk(dir: File, depth: Int, inThumbs: Boolean): Boolean {
            coroutineContext.ensureActive()
            val rel = dir.absolutePath.removePrefix(root.absolutePath).trim('/').lowercase()
            if (rel in SKIP || depth > 24) return false
            val children = dir.listFiles() ?: return false
            var hasContent = false
            for (f in children) {
                if (f.isDirectory) {
                    if (java.nio.file.Files.isSymbolicLink(f.toPath())) { hasContent = true; continue }
                    val thumbs = inThumbs || f.name.equals(".thumbnails", ignoreCase = true)
                    val sub = walk(f, depth + 1, thumbs)
                    if (sub) hasContent = true
                } else {
                    hasContent = true
                    count++
                    if (count % 200 == 0) progress(count, f.parentFile?.name.orEmpty())
                    val len = f.length()
                    val ext = f.extension.lowercase()
                    when {
                        inThumbs -> add(JunkFile(f, len, JunkKind.THUMBS))
                        ext in TEMP_EXT || f.name.startsWith(".pending-") -> add(JunkFile(f, len, JunkKind.TEMP))
                        ext == "apk" || ext == "xapk" || ext == "apks" -> add(JunkFile(f, len, JunkKind.APK))
                        else -> {
                            if (len >= BIG) add(JunkFile(f, len, JunkKind.BIG))
                            if (len >= DUP_MIN && !f.name.startsWith(".")) bySize.getOrPut(len) { ArrayList() } += f
                        }
                    }
                }
            }
            // Les dossiers principaux (Musique, Films, Sonneries…) restent, même vides
            if (!hasContent && depth > 1 && !dir.name.startsWith(".")) empties += dir
            return hasContent
        }
        if (StorageAccess.granted(ctx)) walk(root, 0, false)
        // Un dossier vide dont le parent devient vide : on ne garde que le plus haut (évite les doublons)
        empties.filter { e -> empties.none { other -> other != e && e.absolutePath.startsWith(other.absolutePath + "/") } }
            .forEach { add(JunkFile(it, 0L, JunkKind.EMPTY)) }

        // Doublons : même taille, puis même empreinte
        progress(count, "doublons")
        var group = 0
        bySize.values.filter { it.size > 1 }.forEach { same ->
            coroutineContext.ensureActive()
            same.groupBy { hash(it) }.filterKeys { it != null }.values.filter { it.size > 1 }.forEach { copies ->
                group++
                // On garde le plus ancien (souvent l'original)
                val sorted = copies.sortedBy { it.lastModified() }
                sorted.forEachIndexed { i, f -> add(JunkFile(f, f.length(), JunkKind.DUPLICATES, group, keep = i == 0)) }
            }
        }
        ScanResult(out.mapValues { (_, v) -> v.sortedByDescending { it.size } })
    }

    private fun hash(f: File): String? = runCatching {
        if (f.length() > 512L * 1024 * 1024) return@runCatching null
        val md = MessageDigest.getInstance("MD5")
        FileInputStream(f).use { input ->
            val buf = ByteArray(64 * 1024)
            while (true) {
                val n = input.read(buf)
                if (n <= 0) break
                md.update(buf, 0, n)
            }
        }
        md.digest().joinToString("") { "%02x".format(it) }
    }.getOrNull()

    /** Supprime les fichiers choisis ; renvoie la place libérée. */
    suspend fun delete(files: List<JunkFile>): Long = withContext(Dispatchers.IO) {
        var freed = 0L
        files.forEach { j ->
            val ok = if (j.file.isDirectory) j.file.deleteRecursively() else j.file.delete()
            if (ok) freed += j.size
        }
        freed
    }
}
