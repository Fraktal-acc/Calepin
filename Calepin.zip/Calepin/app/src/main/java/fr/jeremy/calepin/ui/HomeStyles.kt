package fr.jeremy.calepin.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp

/**
 * Choix de la présentation des rubriques de l'accueil : chaque style est montré par un petit croquis.
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun HomeStylePicker(selected: HomeStyle, onPick: (HomeStyle) -> Unit) {
    val cs = MaterialTheme.colorScheme
    FlowRow(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        HomeStyle.entries.forEach { h ->
            val sel = h == selected
            Surface(
                onClick = { onPick(h) },
                shape = MaterialTheme.shapes.medium,
                color = if (sel) cs.primaryContainer else cs.surfaceContainerLow,
                border = BorderStroke(if (sel) 2.dp else 1.dp, if (sel) cs.primary else cs.outlineVariant),
                modifier = Modifier.width(96.dp.grow()),
            ) {
                Column(Modifier.padding(8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    HomeStyleSketch(h, Modifier.fillMaxWidth().height(60.dp))
                    FitText(
                        h.label,
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = if (sel) FontWeight.SemiBold else FontWeight.Normal,
                        textAlign = TextAlign.Center,
                        maxLines = 2,
                        modifier = Modifier.padding(top = 6.dp),
                    )
                }
            }
        }
    }
}

/** Petit croquis d'une présentation de l'accueil. */
@Composable
fun HomeStyleSketch(h: HomeStyle, modifier: Modifier) {
    val a = MaterialTheme.colorScheme.primary
    val b = MaterialTheme.colorScheme.secondary
    val c = MaterialTheme.colorScheme.tertiary
    val line = MaterialTheme.colorScheme.outline
    Canvas(modifier) {
        val w = size.width
        val ht = size.height
        val g = w * 0.06f
        val colors = listOf(a, b, c)
        fun box(x: Float, y: Float, bw: Float, bh: Float, i: Int, alpha: Float = 0.75f) =
            drawRoundRect(colors[i % 3].copy(alpha = alpha), Offset(x, y), Size(bw, bh), CornerRadius(w * 0.05f))
        when (h) {
            HomeStyle.GRID -> grid(2, 3, g, ::box)
            HomeStyle.GRID3 -> grid(3, 3, g, ::box)
            HomeStyle.MOSAIC -> {
                val rh = (ht - 2 * g) / 3
                box(0f, 0f, w, rh, 0)
                val cw = (w - g) / 2
                box(0f, rh + g, cw, rh, 1); box(cw + g, rh + g, cw, rh, 2)
                box(0f, 2 * (rh + g), cw, rh, 0); box(cw + g, 2 * (rh + g), cw, rh, 1)
            }
            HomeStyle.CARDS -> {
                val rh = (ht - 2 * g) / 3
                repeat(3) { i -> box(0f, i * (rh + g), w, rh, i, 0.85f) }
            }
            HomeStyle.CAROUSEL -> {
                val cw = w * 0.36f
                val rh = (ht - g) / 2
                repeat(2) { r -> repeat(3) { i -> box(i * (cw + g), r * (rh + g), cw, rh, i + r) } }
            }
            HomeStyle.LIST -> {
                val rh = ht / 4
                repeat(4) { i ->
                    val y = i * rh + rh * 0.2f
                    drawCircle(colors[i % 3].copy(alpha = 0.8f), rh * 0.3f, Offset(rh * 0.35f, y + rh * 0.3f))
                    drawRoundRect(line.copy(alpha = 0.6f), Offset(rh * 0.9f, y + rh * 0.18f), Size(w - rh * 1.1f, rh * 0.24f), CornerRadius(rh * 0.12f))
                }
            }
            HomeStyle.COMPACT -> {
                val cols = 4
                val cw = w / cols
                repeat(2) { r ->
                    repeat(cols) { i ->
                        val cx = i * cw + cw / 2
                        val cy = r * ht / 2 + ht * 0.2f
                        drawCircle(colors[(i + r) % 3].copy(alpha = 0.8f), cw * 0.28f, Offset(cx, cy))
                        drawRoundRect(line.copy(alpha = 0.6f), Offset(cx - cw * 0.3f, cy + cw * 0.36f), Size(cw * 0.6f, ht * 0.05f), CornerRadius(ht * 0.03f))
                    }
                }
            }
        }
    }
}

private fun DrawScope.grid(cols: Int, rows: Int, g: Float, box: (Float, Float, Float, Float, Int, Float) -> Unit) {
    val cw = (size.width - g * (cols - 1)) / cols
    val rh = (size.height - g * (rows - 1)) / rows
    var n = 0
    repeat(rows) { r -> repeat(cols) { c -> box(c * (cw + g), r * (rh + g), cw, rh, n++, 0.75f) } }
}
