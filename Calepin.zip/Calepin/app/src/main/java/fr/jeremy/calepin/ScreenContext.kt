package fr.jeremy.calepin

/**
 * Ce qui est affiché en ce moment, pour que l'assistant comprenne « ce PDF », « cette note »,
 * « ce mail » selon le menu où l'on se trouve.
 */
object ScreenContext {
    /** Nom de l'écran (« notes », « agenda », « pdf », « messages »…). */
    @Volatile var screen: String = "home"
    @Volatile var pdfId: String? = null
    @Volatile var noteId: Long? = null
}
