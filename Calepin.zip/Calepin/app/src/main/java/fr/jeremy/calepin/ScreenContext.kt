package fr.jeremy.calepin

import fr.jeremy.calepin.control.Conv

/**
 * Ce qui est affiché en ce moment, pour que l'assistant comprenne « ce PDF », « cette note »,
 * « réponds-lui que… » selon le menu où l'on se trouve.
 */
object ScreenContext {
    /** Nom de l'écran (« notes », « agenda », « pdf », « messages »…). */
    @Volatile var screen: String = "home"
    @Volatile var pdfId: String? = null
    @Volatile var noteId: Long? = null
    @Volatile var conv: Conv? = null
}
