package fr.jeremy.calepin.control

import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.InetSocketAddress
import java.net.Socket

/**
 * Lumières, prises et centrales domotiques pilotées sur le réseau local.
 * Toutes les fonctions sont bloquantes : à appeler hors du fil principal.
 */
object SmartHome {

    /** Allume ou éteint. */
    fun power(t: Target, on: Boolean): Boolean = when (t.device.kind) {
        Kind.HUE -> hue(t, JSONObject().put("on", on))
        Kind.SHELLY -> shelly(t.device.host, on, null)
        Kind.TASMOTA -> Http.get("http://${t.device.host}/cm?cmnd=Power%20${if (on) "On" else "Off"}", 4000) != null
        Kind.WLED -> wled(t.device.host, JSONObject().put("on", on))
        Kind.YEELIGHT -> yeelight(t.device.host, "set_power", JSONArray().put(if (on) "on" else "off").put("smooth").put(400))
        Kind.HOME_ASSISTANT -> haPower(t, on)
        Kind.WEBHOOK -> webhook(t.device, on)
        else -> false
    }

    /** Luminosité en pourcentage (allume aussi). */
    fun brightness(t: Target, pct: Int): Boolean {
        val p = pct.coerceIn(1, 100)
        return when (t.device.kind) {
            Kind.HUE -> hue(t, JSONObject().put("on", true).put("bri", (p * 254 / 100).coerceIn(1, 254)))
            Kind.SHELLY -> shelly(t.device.host, true, p)
            Kind.TASMOTA -> Http.get("http://${t.device.host}/cm?cmnd=Dimmer%20$p", 4000) != null
            Kind.WLED -> wled(t.device.host, JSONObject().put("on", true).put("bri", (p * 255 / 100).coerceIn(1, 255)))
            Kind.YEELIGHT -> yeelight(t.device.host, "set_bright", JSONArray().put(p).put("smooth").put(400))
            Kind.HOME_ASSISTANT -> haCall(t, "light", "turn_on", JSONObject().put("brightness_pct", p))
            else -> false
        }
    }

    /** Scène, script, volet : « lance », « ouvre », « ferme ». */
    fun activate(t: Target, action: String = "on"): Boolean = when (t.device.kind) {
        Kind.HOME_ASSISTANT -> {
            val domain = t.subId?.substringBefore('.') ?: ""
            when {
                domain == "cover" && action == "open" -> haCall(t, "cover", "open_cover")
                domain == "cover" && action == "close" -> haCall(t, "cover", "close_cover")
                domain == "scene" || domain == "script" -> haCall(t, domain, "turn_on")
                else -> haPower(t, action != "off" && action != "close")
            }
        }
        else -> power(t, action != "off" && action != "close")
    }

    // ------------------------------------------------------------------ Philips Hue

    private fun hue(t: Target, state: JSONObject): Boolean {
        val d = t.device
        val sub = t.subId ?: return false
        val path = if (sub.startsWith("g")) "groups/${sub.drop(1)}/action" else "lights/$sub/state"
        val r = put("http://${d.host}/api/${d.secret}/$path", state.toString()) ?: return false
        return "success" in r
    }

    /** Après appui sur le bouton du pont : crée l'accès et renvoie le nom d'utilisateur. */
    fun hueLink(host: String): Result<String> = runCatching {
        val r = Http.post("http://$host/api", """{"devicetype":"calepin_ia#android"}""", mapOf("Content-Type" to "application/json"), 5000)
            ?: error("le pont Hue ne répond pas")
        val o = JSONArray(r).optJSONObject(0) ?: error("réponse inattendue")
        o.optJSONObject("success")?.optString("username")?.takeIf { it.isNotBlank() }
            ?: error(if (o.optJSONObject("error")?.optInt("type") == 101) "appuie d'abord sur le bouton du pont" else "accès refusé")
    }

    /** Lampes et pièces du pont, pour pouvoir les nommer (« allume la lampe du salon »). */
    fun hueTargets(host: String, user: String): JSONArray {
        val out = JSONArray()
        Http.get("http://$host/api/$user/lights", 5000)?.let { r ->
            val o = runCatching { JSONObject(r) }.getOrNull() ?: return@let
            o.keys().forEach { id -> out.put(JSONObject().put("id", id).put("name", o.optJSONObject(id)?.optString("name")).put("type", "light")) }
        }
        Http.get("http://$host/api/$user/groups", 5000)?.let { r ->
            val o = runCatching { JSONObject(r) }.getOrNull() ?: return@let
            o.keys().forEach { id -> out.put(JSONObject().put("id", "g$id").put("name", o.optJSONObject(id)?.optString("name")).put("type", "room")) }
        }
        return out
    }

    fun hueProbe(host: String) = (Http.get("http://$host/api/config", 1500, 400) ?: "").contains("bridgeid")

    // ------------------------------------------------------------------ Shelly

    /** Shelly 1re génération (/relay, /light) ou suivantes (/rpc). */
    private fun shelly(host: String, on: Boolean, pct: Int?): Boolean {
        val info = Http.get("http://$host/shelly", 3000) ?: return false
        val gen2 = runCatching { JSONObject(info).optInt("gen", 1) >= 2 }.getOrDefault(false)
        return if (gen2) {
            if (pct != null) Http.get("http://$host/rpc/Light.Set?id=0&on=true&brightness=$pct", 4000)?.contains("error") == false
            else (Http.get("http://$host/rpc/Switch.Set?id=0&on=$on", 4000)?.let { "error" !in it } == true) ||
                (Http.get("http://$host/rpc/Light.Set?id=0&on=$on", 4000)?.let { "error" !in it } == true)
        } else {
            val turn = if (on) "on" else "off"
            if (pct != null) Http.get("http://$host/light/0?turn=on&brightness=$pct", 4000) != null
            else (Http.get("http://$host/relay/0?turn=$turn", 4000)?.contains("ison") == true) ||
                (Http.get("http://$host/light/0?turn=$turn", 4000)?.contains("ison") == true)
        }
    }

    fun shellyProbe(host: String): Boolean = (Http.get("http://$host/shelly", 1500, 400) ?: "").let { "\"type\"" in it || "\"gen\"" in it }

    // ------------------------------------------------------------------ Tasmota, WLED, Yeelight

    fun tasmotaProbe(host: String) = (Http.get("http://$host/cm?cmnd=Status", 1500, 400) ?: "").contains("\"Status\"")

    private fun wled(host: String, state: JSONObject) =
        Http.post("http://$host/json/state", state.toString(), mapOf("Content-Type" to "application/json"), 4000)?.contains("success") == true

    fun wledProbe(host: String) = (Http.get("http://$host/json/info", 1500, 400) ?: "").contains("WLED")

    private fun yeelight(host: String, method: String, params: JSONArray): Boolean = try {
        Socket().use { s ->
            s.connect(InetSocketAddress(host, 55443), 3000)
            s.soTimeout = 3000
            s.getOutputStream().write((JSONObject().put("id", 1).put("method", method).put("params", params).toString() + "\r\n").toByteArray())
            val line = BufferedReader(InputStreamReader(s.getInputStream())).readLine() ?: ""
            "\"ok\"" in line
        }
    } catch (e: Exception) {
        false
    }

    // ------------------------------------------------------------------ Home Assistant

    private fun haHeaders(token: String) = mapOf("Authorization" to "Bearer $token", "Content-Type" to "application/json")

    private fun haCall(t: Target, domain: String, service: String, data: JSONObject = JSONObject()): Boolean {
        val d = t.device
        val body = data.put("entity_id", t.subId).toString()
        val r = Http.post("${d.host.trimEnd('/')}/api/services/$domain/$service", body, haHeaders(d.secret), 6000) ?: return false
        return r.trimStart().startsWith("[")
    }

    private fun haPower(t: Target, on: Boolean): Boolean {
        val domain = t.subId?.substringBefore('.') ?: return false
        return when (domain) {
            "cover" -> haCall(t, "cover", if (on) "open_cover" else "close_cover")
            "scene", "script" -> if (on) haCall(t, domain, "turn_on") else false
            "lock" -> false // jamais d'ouverture de serrure à la voix
            else -> haCall(t, domain, if (on) "turn_on" else "turn_off")
        }
    }

    /** Liste des entités pilotables (lumières, prises, volets, scènes…), pour pouvoir les nommer. */
    fun haTargets(baseUrl: String, token: String): Result<JSONArray> = runCatching {
        val r = Http.get2("${baseUrl.trimEnd('/')}/api/states", haHeaders(token), 8000) ?: error("Home Assistant ne répond pas (adresse ou jeton ?)")
        val arr = runCatching { JSONArray(r) }.getOrNull() ?: error("jeton refusé")
        val keep = setOf("light", "switch", "fan", "cover", "scene", "script", "input_boolean", "media_player", "climate", "humidifier", "vacuum")
        val out = JSONArray()
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            val id = o.optString("entity_id")
            val domain = id.substringBefore('.')
            if (domain !in keep) continue
            val name = o.optJSONObject("attributes")?.optString("friendly_name")?.takeIf { it.isNotBlank() } ?: id.substringAfter('.').replace('_', ' ')
            out.put(JSONObject().put("id", id).put("name", name).put("type", domain))
        }
        out
    }

    fun haProbe(host: String) = (Http.get("http://$host:8123/manifest.json", 1500, 400) ?: "").contains("Home Assistant")

    // ------------------------------------------------------------------ Commande web

    private fun webhook(d: HomeDevice, on: Boolean): Boolean {
        val e = d.extraJson
        val url = if (on) e.optString("on_url", d.host) else e.optString("off_url")
        if (url.isBlank()) return false
        return if (e.optString("method") == "POST") Http.post(url, e.optString("body"), mapOf("Content-Type" to "application/json"), 6000) != null
        else Http.get(url, 6000) != null
    }

    private fun put(url: String, body: String): String? = try {
        val c = (java.net.URL(url).openConnection() as java.net.HttpURLConnection).apply {
            requestMethod = "PUT"
            doOutput = true
            connectTimeout = 4000
            readTimeout = 4000
            setRequestProperty("Content-Type", "application/json")
        }
        try {
            c.outputStream.use { it.write(body.toByteArray()) }
            (if (c.responseCode in 200..299) c.inputStream else c.errorStream)?.use { it.readBytes().toString(Charsets.UTF_8) }
        } finally {
            c.disconnect()
        }
    } catch (e: Exception) {
        null
    }
}
