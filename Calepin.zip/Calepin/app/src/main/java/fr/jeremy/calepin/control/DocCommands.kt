package fr.jeremy.calepin.control

import android.content.Context
import android.net.Uri
import fr.jeremy.calepin.assistant.Assistant
import fr.jeremy.calepin.assistant.Reply
import fr.jeremy.calepin.i18n.I18n
import fr.jeremy.calepin.office.PdfEntry
import fr.jeremy.calepin.office.PdfLibrary
import fr.jeremy.calepin.search.TextNorm
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Commandes sur les PDF de la bibliothèque (Bureau) :
 * « importe le PDF planning dans l'agenda », « ajoute les dates du PDF facture à l'agenda »,
 * « reporte ce PDF dans l'agenda » (depuis un PDF ouvert), « ouvre le PDF contrat ».
 */
class DocCommands(context: Context, private val planning: PlanningCommands? = null) {
    private val ctx = context.applicationContext
    private val lib get() = PdfLibrary.get(ctx)

    data class Result(val reply: Reply, val navigate: String? = null)

    private val agendaWords = "(?:l'agenda|l agenda|agenda|mon agenda|le calendrier|calendrier|mon calendrier|le planning|planning|mon planning)"
    private val docWords = "(?:pdf|document|fichier|doc)"

    suspend fun handle(raw0: String, assistant: Assistant): Result? {
        var raw = raw0.trim().trimEnd('.', '!', '?')
        var n = TextNorm.norm(raw).lowercase().replace(Regex("\\s+"), " ").trim()
        if (!Regex("\\b$docWords\\b").containsMatchIn(n)) return null
        // « le dernier PDF téléchargé » : le plus récent du dossier Download
        Regex("\\b(?:le |mon )?dernier $docWords(?: (?:telecharge|recu|ajoute|enregistre))?\\b").find(n)?.let { m ->
            n = n.replaceRange(m.range, "le pdf __dernier__")
            raw = n
        }
        return toAgenda(raw, n, assistant) ?: open(raw, n) ?: importOnly(raw, n)
    }

    /** PDF du Bureau, sinon du dossier « Download » du téléphone (ajouté alors au Bureau). */
    private suspend fun resolve(name: String): PdfEntry? {
        if (name != "__dernier__") find(name)?.let { return it }
        if (!fr.jeremy.calepin.tools.StorageAccess.granted(ctx)) return if (name == "__dernier__") lib.items.value.maxByOrNull { it.added } else null
        val f = fr.jeremy.calepin.office.PdfDownloads.find(name) ?: return if (name == "__dernier__") lib.items.value.maxByOrNull { it.added } else null
        return runCatching { fr.jeremy.calepin.office.PdfDownloads.import(ctx, f) }.getOrNull()
    }

    private fun notFound(name: String): Result {
        val access = fr.jeremy.calepin.tools.StorageAccess.granted(ctx)
        return Result(
            Reply(
                if (access) I18n.trf("Je ne trouve pas de PDF « {0} » dans le Bureau ni dans Téléchargements.", name)
                else I18n.trf("Je ne trouve pas de PDF « {0} » dans le Bureau. Pour que je cherche aussi dans Téléchargements, autorise l'accès aux fichiers (Téléphone → Fichiers).", name),
            ),
            "pdf",
        )
    }

    /** « Importe le PDF facture », « ajoute le dernier PDF téléchargé au Bureau ». */
    private suspend fun importOnly(raw: String, n: String): Result? {
        val m = Regex("^(?:importe|importer|ajoute|ajouter|recupere|recuperer|prends|mets|range|copie)(?: moi)?(?: le| mon| ce)? $docWords (?:nomme |appele |intitule )?(.+?)(?: (?:dans|au|sur|vers) (?:le |mon )?(?:bureau|bibliotheque|mes pdf|pdf))?(?: depuis (?:les |mes )?(?:telechargements|download))?$").find(n) ?: return null
        val g = m.groups[1] ?: return null
        val name = nameAt(raw, n, g.range)
        val e = resolve(name) ?: return notFound(name)
        return Result(Reply(I18n.trf("« {0} » est dans le Bureau.", e.name)), "pdf:" + e.id)
    }

    /** Nom du PDF dans la phrase d'origine (accents gardés), à partir de sa position dans la phrase normalisée. */
    private fun nameAt(raw: String, n: String, range: IntRange): String {
        // La normalisation garde presque toujours la longueur ; sinon on reprend la version normalisée
        val s = if (raw.length == n.length) raw.substring(range.first, range.last + 1) else n.substring(range.first, range.last + 1)
        return s.trim().trim('«', '»', '"', '\'', ' ').trim()
    }

    private fun find(name: String): PdfEntry? {
        val items = lib.items.value
        val w = TextNorm.norm(name).lowercase().trim()
        if (w.isEmpty()) return null
        return items.firstOrNull { TextNorm.norm(it.name).lowercase() == w }
            ?: items.firstOrNull { TextNorm.norm(it.name).lowercase().contains(w) }
            ?: items.firstOrNull { e -> w.split(' ').filter { it.length > 2 }.let { ws -> ws.isNotEmpty() && ws.all { TextNorm.norm(e.name).lowercase().contains(it) } } }
    }

    private suspend fun toAgenda(raw: String, n: String, assistant: Assistant): Result? {
        val m = Regex("^(?:ajoute|ajouter|mets|mettre|importe|importer|reporte|reporter|copie|copier|transfere|transferer|integre|integrer|enregistre|place|range)(?: moi)?(?: toutes| tous)?(?: les| la| le)?(?: dates?| rendez-vous| evenements?| echeances?| horaires?)?(?: du| de| des| d'| dans le| depuis le| contenus? dans le)?(?: le| mon| ce)? $docWords (?:nomme |appele |intitule )?(.+?) (?:dans|a|sur|vers|en|au) $agendaWords(?: du telephone)?(?: automatiquement)?(?: depuis (?:les |mes )?(?:telechargements|download))?$")
            .find(n) ?: return null
        val g = m.groups[1] ?: return null
        val name = nameAt(raw, n, g.range)
        val phone = Regex("du telephone").containsMatchIn(n)
        val e = resolve(name) ?: return notFound(name)
        val text = withContext(Dispatchers.IO) {
            val direct = runCatching { lib.pageTexts(e.id).joinToString("\n") }.getOrDefault("")
            // PDF scanné : lecture des caractères sur l'image des pages
            if (direct.count { it.isLetterOrDigit() } >= 20) direct
            else runCatching { fr.jeremy.calepin.media.PdfText.extract(ctx, Uri.fromFile(lib.file(e.id))).text }.getOrDefault(direct)
        }
        // Planning de travail : lecture de la grille (vacations, absences) plutôt que des dates éparses
        planning?.importEntry(e)?.let { return Result(it.reply, it.navigate) }
        if (text.isBlank()) return Result(Reply(I18n.trf("Je n'arrive pas à lire le texte du PDF « {0} ».", e.name)))
        val r = withContext(Dispatchers.IO) { assistant.datesFromDocument(e.name, text, phone) }
        return Result(r)
    }

    private suspend fun open(raw: String, n: String): Result? {
        val m = Regex("^(?:ouvre|ouvrir|affiche|montre|lis|lire)(?: moi)?(?: le| mon| ce)? $docWords (?:nomme |appele |intitule )?(.+)$").find(n) ?: return null
        val g = m.groups[1] ?: return null
        val name = nameAt(raw, n, g.range)
        val e = resolve(name) ?: return notFound(name)
        return Result(Reply(I18n.trf("J'ouvre « {0} ».", e.name)), "pdf:" + e.id)
    }
}
