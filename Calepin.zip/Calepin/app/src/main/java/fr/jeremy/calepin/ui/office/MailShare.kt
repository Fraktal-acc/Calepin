package fr.jeremy.calepin.ui.office

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import fr.jeremy.calepin.Files
import fr.jeremy.calepin.LockGuard
import fr.jeremy.calepin.i18n.I18n
import java.io.File

/** Ouvre l'appli de mail du téléphone avec le fichier en pièce jointe (seules les applis de mail sont proposées). */
fun openMailApp(ctx: Context, file: File, name: String, mime: String) {
    LockGuard.external()
    val uri = Files.uriFor(ctx, file)
    val send = Intent(Intent.ACTION_SEND).apply {
        type = mime
        putExtra(Intent.EXTRA_SUBJECT, name.substringBeforeLast('.'))
        putExtra(Intent.EXTRA_STREAM, uri)
        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        // Seules les applis qui savent écrire un mail
        selector = Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:"))
    }
    runCatching { ctx.startActivity(Intent.createChooser(send, I18n.tr("Envoyer par mail")).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)) }
        .onFailure {
            // Sans sélecteur (certains téléphones) : partage classique
            runCatching { ctx.startActivity(Intent.createChooser(send.apply { selector = null }, I18n.tr("Envoyer par mail")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
                .onFailure { I18n.toast(ctx, I18n.tr("Aucune application de mail sur le téléphone"), Toast.LENGTH_LONG).show() }
        }
}

/** Ouvre un lien (site, adresse mail, numéro) dans l'appli du téléphone qui sait le faire. */
fun openExternal(ctx: Context, url: String) {
    LockGuard.external()
    val uri = Uri.parse(url)
    val i = if (uri.scheme.equals("tel", true)) Intent(Intent.ACTION_DIAL, uri) else Intent(Intent.ACTION_VIEW, uri)
    runCatching { ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
        .onFailure { I18n.toast(ctx, I18n.tr("Aucune application pour ouvrir ce lien"), Toast.LENGTH_LONG).show() }
}
