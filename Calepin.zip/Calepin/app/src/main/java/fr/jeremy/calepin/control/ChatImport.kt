package fr.jeremy.calepin.control

import android.content.Context
import android.net.Uri
import fr.jeremy.calepin.search.TextNorm
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.withContext
import java.io.File
import java.util.zip.ZipInputStream

/** Historique partagé vers Calepin (depuis WhatsApp « Exporter la discussion », ou un fichier choisi). */
object ChatImportTarget {
    data class Request(val uris: List<Uri>, val subject: String? = null, val convKey: String? = null)
    val pending = MutableStateFlow<Request?>(null)
}

/**
 * Import et synchronisation des historiques WhatsApp et Telegram dans les conversations suivies.
 * Les messages déjà présents (reçus par les notifications ou importés avant) ne sont pas doublés ;
 * les photos, vocaux et documents de l'export (.zip) sont rattachés à leurs messages.
 */
object ChatImport {

    /** Export lu : discussions trouvées, dossier où sont rangés les fichiers joints, nom du fichier d'origine. */
    class Loaded(val chats: List<ChatParsers.Chat>, val dir: File, val source: String)

    /** Bilan d'un import. */
    data class Result(val added: Int, val already: Int, val withFiles: Int)

    private const val MAX_ENTRY = 200L * 1024 * 1024
    private const val MAX_TOTAL = 1500L * 1024 * 1024

    private fun workDir(ctx: Context) = File(ctx.cacheDir, "chat_import/" + System.currentTimeMillis()).apply { mkdirs() }

    private fun displayName(ctx: Context, u: Uri): String =
        if (u.scheme == "file") File(u.path ?: "").name
        else runCatching { fr.jeremy.calepin.office.PdfLibrary.get(ctx).displayName(u) }.getOrDefault("fichier")

    /** Décompresse sans jamais écrire en dehors de [dir] (noms d'entrées piégés « ../ » refusés). */
    private fun unzip(input: java.io.InputStream, dir: File) {
        val root = dir.canonicalPath + File.separator
        var total = 0L
        ZipInputStream(input.buffered()).use { z ->
            while (true) {
                val e = z.nextEntry ?: break
                if (e.isDirectory) continue
                val f = File(dir, e.name.replace('\\', '/').trimStart('/'))
                if (!f.canonicalPath.startsWith(root)) continue
                f.parentFile?.mkdirs()
                var n = 0L
                f.outputStream().use { out ->
                    val buf = ByteArray(64 * 1024)
                    while (true) {
                        val r = z.read(buf)
                        if (r < 0) break
                        n += r; total += r
                        if (n > MAX_ENTRY || total > MAX_TOTAL) break
                        out.write(buf, 0, r)
                    }
                }
                if (n > MAX_ENTRY) f.delete()
                if (total > MAX_TOTAL) break
            }
        }
    }

    /**
     * Copie les fichiers reçus (un .txt, un .zip, result.json, messages.html, ou plusieurs fichiers d'un
     * coup) et lit les discussions qu'ils contiennent. Null si rien n'est reconnu.
     */
    suspend fun load(ctx: Context, uris: List<Uri>, subject: String? = null): Loaded? = withContext(Dispatchers.IO) {
        val dir = workDir(ctx)
        var source = ""
        for (u in uris) {
            val name = displayName(ctx, u).replace(Regex("[\\\\/:*?\"<>|]"), "_").ifBlank { "fichier" }
            if (source.isEmpty() || name.endsWith(".txt", true) || name.endsWith(".zip", true)) source = name
            runCatching {
                ctx.contentResolver.openInputStream(u)!!.use { input ->
                    if (name.endsWith(".zip", true)) unzip(input, dir)
                    else File(dir, name).outputStream().use { input.copyTo(it) }
                }
            }
        }
        val loaded = readDir(dir, source, subject)
        if (loaded == null) dir.deleteRecursively()
        loaded
    }

    /** Lit un dossier d'export (fichiers déjà en place). */
    private fun readDir(dir: File, source: String, subject: String?): Loaded? {
        val files = dir.walkTopDown().filter { it.isFile }.toList()
        val chats = mutableListOf<ChatParsers.Chat>()
        // Telegram : result.json, sinon messages.html (+ messages2.html…)
        files.firstOrNull { it.name.equals("result.json", true) }?.let { f ->
            runCatching { chats += ChatParsers.parseTelegramJson(f.readText()) }
        }
        if (chats.isEmpty()) {
            val pages = files.filter { Regex("(?i)^messages\\d*\\.html$").matches(it.name) }
                .sortedBy { Regex("\\d+").find(it.name)?.value?.toIntOrNull() ?: 1 }
            if (pages.isNotEmpty()) {
                val parts = pages.mapNotNull { runCatching { ChatParsers.parseTelegramHtml(it.readText()) }.getOrNull() }
                val msgs = parts.flatMap { it.messages }.sortedBy { it.time }
                if (msgs.isNotEmpty()) chats += ChatParsers.Chat(Conv.TELEGRAM, parts.firstOrNull { it.title.isNotBlank() }?.title ?: "", msgs)
            }
        }
        // WhatsApp : le .txt de la discussion (le plus gros s'il y en a plusieurs)
        if (chats.isEmpty()) {
            files.filter { it.name.endsWith(".txt", true) }.sortedByDescending { it.length() }.forEach { f ->
                if (chats.isNotEmpty()) return@forEach
                val msgs = runCatching { ChatParsers.parseWhatsApp(f.readText()) }.getOrDefault(emptyList())
                if (msgs.size >= 1) {
                    val title = ChatParsers.whatsAppTitle(subject) ?: ChatParsers.whatsAppTitle(f.name) ?: ChatParsers.whatsAppTitle(source) ?: ""
                    chats += ChatParsers.Chat(Conv.WHATSAPP, title, msgs)
                }
            }
        }
        return if (chats.isEmpty()) null else Loaded(chats, dir, source)
    }

    /** Fichier joint d'un message, dans le dossier d'export (chemin donné, sinon recherche par nom). */
    private fun mediaFile(dir: File, name: String, index: Map<String, File>): File? {
        if (name.isBlank()) return null
        File(dir, name).takeIf { it.isFile }?.let { return it }
        return index[name.substringAfterLast('/').lowercase()]
    }

    private fun norm(s: String) = TextNorm.norm(s).lowercase().trim()

    /** Mon nom dans l'export : celui enregistré pour la conversation, ou l'autre participant d'une discussion à deux. */
    fun guessMe(chat: ChatParsers.Chat, conv: Conv?): String? {
        val senders = chat.senders.map { it.first }
        conv?.me?.takeIf { it.isNotBlank() }?.let { me -> senders.firstOrNull { norm(it) == norm(me) }?.let { return it } }
        val other = conv?.name ?: chat.title
        if (senders.size == 2 && other.isNotBlank()) senders.firstOrNull { norm(it) != norm(other) && senders.any { s -> norm(s) == norm(other) } }?.let { return it }
        return null
    }

    /**
     * Ajoute les messages de [chat] à la conversation [conv]. [me] : mon nom dans l'export (mes messages
     * s'affichent à droite). Les messages déjà là (même texte, à 90 secondes près) ne sont pas doublés.
     */
    suspend fun merge(ctx: Context, conv: Conv, chat: ChatParsers.Chat, me: String?, dir: File): Result = withContext(Dispatchers.IO) {
        MessageHub.init(ctx)
        val existing = MessageHub.messages.value[conv.key].orEmpty().sortedBy { it.time }.toMutableList()
        val times = existing.map { it.time }.toLongArray()
        val index = dir.walkTopDown().filter { it.isFile }.associateBy { it.name.lowercase() }
        val mediaDir = MessageHub.mediaFolder(ctx)
        val tol = 90_000L
        val added = mutableListOf<Msg>()
        var already = 0
        var withFiles = 0
        for (r in chat.messages) {
            val mine = me != null && norm(r.from) == norm(me)
            val src = mediaFile(dir, r.media, index)
            fun keep(): Pair<String, String> {
                if (src == null) return "" to ""
                val f = File(mediaDir, "imp_${r.time}_" + src.name.replace(Regex("[\\\\/:*?\"<>|]"), "_"))
                if (!f.exists()) runCatching { src.copyTo(f) }
                val mime = android.webkit.MimeTypeMap.getSingleton().getMimeTypeFromExtension(src.extension.lowercase()) ?: when {
                    r.text.startsWith("🎤") -> "audio/ogg"
                    r.text.startsWith("📷") -> "image/jpeg"
                    r.text.startsWith("🎥") -> "video/mp4"
                    else -> "application/octet-stream"
                }
                return if (f.exists()) f.path to mime else "" to ""
            }
            // Recherche des doublons dans la fenêtre de temps (messages triés : recherche dichotomique)
            var i = java.util.Arrays.binarySearch(times, r.time - tol).let { if (it < 0) -it - 1 else it }
            var dup = -1
            while (i < existing.size && existing[i].time <= r.time + tol) {
                val e = existing[i]
                if (ChatParsers.sameText(e.text, r.text) || (ChatParsers.isMedia(e.text) && ChatParsers.isMedia(r.text) && e.mine == mine)) { dup = i; break }
                i++
            }
            if (dup >= 0) {
                already++
                // Photo ou vocal reçu par notification sans son fichier : on le rattache
                if (existing[dup].media.isEmpty() && src != null) {
                    val (p, m) = keep()
                    if (p.isNotEmpty()) { existing[dup] = existing[dup].copy(media = p, mime = m); withFiles++ }
                }
                continue
            }
            val (p, m) = keep()
            if (p.isNotEmpty()) withFiles++
            added += Msg(r.time, if (mine) "" else r.from, r.text, mine = mine, media = p, mime = m)
        }
        if (added.isNotEmpty() || withFiles > 0) MessageHub.setMessages(ctx, conv.key, existing + added)
        Result(added.size, already, withFiles)
    }

    /** Range l'import dans une conversation (créée si besoin) et retient mon nom pour les prochaines fois. */
    suspend fun importInto(ctx: Context, target: Conv, chat: ChatParsers.Chat, me: String?, dir: File): Result {
        MessageHub.init(ctx)
        val conv = target.copy(me = me ?: target.me)
        MessageHub.addConv(ctx, conv)
        val r = merge(ctx, conv, chat, me, dir)
        markDone(ctx, chat, conv)
        return r
    }

    // ------------------------------------------------------------------ Synchronisation automatique

    private fun prefs(ctx: Context) = ctx.applicationContext.getSharedPreferences("calepin_chat_sync", Context.MODE_PRIVATE)
    private fun sig(f: File) = f.path + "|" + f.length() + "|" + f.lastModified()

    private fun markDone(ctx: Context, chat: ChatParsers.Chat, conv: Conv) {
        // Rien de spécial : la synchronisation compare les messages (pas de doublon même si le fichier revient)
        prefs(ctx).edit().putLong("last_" + conv.key, System.currentTimeMillis()).apply()
    }

    /** Export trouvé dans le téléphone, pas encore rattaché à une conversation suivie. */
    data class Found(val file: File, val app: String, val title: String)

    /** Fichiers d'export présents dans Téléchargements / Documents (WhatsApp .txt/.zip, Telegram result.json/messages.html). */
    private fun candidates(): List<File> {
        val root = android.os.Environment.getExternalStorageDirectory()
        val bases = listOf("Download", "Documents", "Download/Telegram Desktop", "Telegram Desktop", "WhatsApp/Exports").map { File(root, it) }.filter { it.isDirectory }
        return bases.flatMap { b -> b.walkTopDown().maxDepth(4).filter { it.isFile }.toList() }.filter { f ->
            ChatParsers.whatsAppTitle(f.name) != null && (f.name.endsWith(".txt", true) || f.name.endsWith(".zip", true)) ||
                (f.name.equals("result.json", true) || f.name.equals("messages.html", true)) && f.parentFile?.name?.startsWith("ChatExport", true) == true
        }.distinctBy { it.canonicalPath }
    }

    /** Dossier d'export Telegram : le dossier ChatExport entier (photos, vocaux…). */
    private suspend fun loadFile(ctx: Context, f: File): Loaded? = withContext(Dispatchers.IO) {
        if (f.name.endsWith(".zip", true) || f.name.endsWith(".txt", true)) load(ctx, listOf(Uri.fromFile(f)))
        else readDir(f.parentFile ?: return@withContext null, f.parentFile?.name ?: "", null)
    }

    /** Résultat d'une synchronisation : messages ajoutés par conversation, et exports à rattacher à la main. */
    data class SyncReport(val added: Map<String, Int>, val unmatched: List<Found>)

    /**
     * Synchronise les historiques exportés présents dans le téléphone (accès aux fichiers nécessaire) :
     * chaque export dont la discussion correspond à une conversation suivie y est ajouté, sans doublon.
     * Un fichier déjà traité n'est relu que s'il a changé (nouvel export au même nom).
     */
    suspend fun sync(ctx: Context): SyncReport = withContext(Dispatchers.IO) {
        if (!fr.jeremy.calepin.tools.StorageAccess.granted(ctx)) return@withContext SyncReport(emptyMap(), emptyList())
        MessageHub.init(ctx)
        val p = prefs(ctx)
        val done = p.getStringSet("done", emptySet()).orEmpty().toMutableSet()
        val dismissed = p.getStringSet("dismissed", emptySet()).orEmpty()
        val added = linkedMapOf<String, Int>()
        val unmatched = mutableListOf<Found>()
        for (f in candidates()) {
            val s = sig(f)
            if (s in dismissed || s in done) continue
            val l = runCatching { loadFile(ctx, f) }.getOrNull() ?: continue
            try {
                for (chat in l.chats) {
                    val conv = MessageHub.convs.value.firstOrNull { it.app == chat.app && chat.title.isNotBlank() && norm(it.name) == norm(chat.title) }
                    val me = guessMe(chat, conv)
                    if (conv == null || (me == null && chat.senders.size > 1)) {
                        unmatched += Found(f, chat.app, chat.title)
                        continue
                    }
                    val r = merge(ctx, conv, chat, me, l.dir)
                    if (r.added > 0) added[conv.name] = (added[conv.name] ?: 0) + r.added
                    if (conv.me.isBlank() && me != null) MessageHub.addConv(ctx, conv.copy(me = me))
                    done += s
                }
            } finally {
                if (l.dir.path.contains("chat_import")) l.dir.deleteRecursively()
            }
        }
        p.edit().putStringSet("done", done).apply()
        SyncReport(added, unmatched.distinctBy { it.file.path + it.title })
    }

    /** Ne plus proposer cet export. */
    fun dismiss(ctx: Context, f: File) {
        val p = prefs(ctx)
        p.edit().putStringSet("dismissed", p.getStringSet("dismissed", emptySet()).orEmpty() + sig(f)).apply()
    }

    /** Export choisi dans la liste « trouvés » : lu comme un fichier partagé. */
    suspend fun loadFound(ctx: Context, f: Found): Loaded? = loadFile(ctx, f.file)

    /** Après un import manuel d'un export trouvé : il ne sera plus proposé. */
    fun markFile(ctx: Context, f: File) {
        val p = prefs(ctx)
        p.edit().putStringSet("done", p.getStringSet("done", emptySet()).orEmpty() + sig(f)).apply()
    }

    /** Nettoie les fichiers temporaires d'un import. */
    fun cleanup(l: Loaded) { if (l.dir.path.contains("chat_import")) runCatching { l.dir.deleteRecursively() } }
}
