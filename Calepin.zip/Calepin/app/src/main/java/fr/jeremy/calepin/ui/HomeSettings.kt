package fr.jeremy.calepin.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import fr.jeremy.calepin.control.BraviaTv
import fr.jeremy.calepin.control.DeviceCommands
import fr.jeremy.calepin.control.HomeConfig
import fr.jeremy.calepin.control.LanScanner
import fr.jeremy.calepin.control.OrangeDecoder
import fr.jeremy.calepin.control.PhoneControl
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** Réglages « Maison » de Calepin IA : décodeur Orange, téléviseur Sony, autorisations du téléphone. */
@Composable
fun HomeSettings() {
    val ctx = LocalContext.current
    val cfg = remember { HomeConfig(ctx) }
    val phone = remember { PhoneControl(ctx) }
    val scope = rememberCoroutineScope()
    var decoderIp by remember { mutableStateOf(cfg.decoderIp) }
    var braviaIp by remember { mutableStateOf(cfg.braviaIp) }
    var psk by remember { mutableStateOf(cfg.braviaPsk) }
    var scanning by remember { mutableStateOf<Int?>(null) }
    var status by remember { mutableStateOf<String?>(null) }

    fun saveAll() {
        cfg.decoderIp = decoderIp
        cfg.braviaIp = braviaIp
        cfg.braviaPsk = psk
    }

    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Hint2(
            "Commande la télé et le téléphone en parlant à l'assistant : « allume la télé », « mets France 2 », " +
                "« ouvre WhatsApp »… Le téléphone doit être sur le Wi-Fi de la maison pour la télé et le décodeur."
        )

        if (scanning != null) {
            LinearProgressIndicator(progress = { (scanning ?: 0) / 100f }, modifier = Modifier.fillMaxWidth())
            Hint2("Recherche sur le Wi-Fi… ${scanning ?: 0} %")
        } else {
            OutlinedButton(
                onClick = {
                    scanning = 0
                    status = null
                    scope.launch {
                        if (LanScanner.localIp() == null) {
                            status = "Le téléphone n'est pas connecté à un réseau Wi-Fi."
                            scanning = null
                            return@launch
                        }
                        val found = LanScanner.scan { p -> scanning = p }
                        found.decoders.firstOrNull()?.let { decoderIp = it }
                        found.bravias.firstOrNull()?.let { braviaIp = it }
                        saveAll()
                        status = buildString {
                            append(if (found.decoders.isEmpty()) "Décodeur Orange non trouvé (allumé ?)." else "Décodeur Orange trouvé : ${found.decoders.first()}.")
                            append('\n')
                            append(if (found.bravias.isEmpty()) "Téléviseur Sony non trouvé (allumé, contrôle IP activé ?)." else "Téléviseur Sony trouvé : ${found.bravias.first()}.")
                        }
                        scanning = null
                    }
                },
                modifier = Modifier.fillMaxWidth(),
            ) { Text("Rechercher sur le Wi-Fi") }
        }
        status?.let { Text(it, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary) }

        Text("Décodeur TV d'Orange", style = MaterialTheme.typography.titleSmall)
        OutlinedTextField(
            value = decoderIp,
            onValueChange = { decoderIp = it; cfg.decoderIp = it },
            label = { Text("Adresse sur le Wi-Fi (ex. 192.168.1.20)") },
            singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri),
            modifier = Modifier.fillMaxWidth(),
        )
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            TextButton(onClick = {
                scope.launch {
                    val on = withContext(Dispatchers.IO) { OrangeDecoder(decoderIp.trim()).isOn() }
                    status = when (on) {
                        null -> "Le décodeur ne répond pas à cette adresse."
                        true -> "Décodeur joignable : allumé."
                        false -> "Décodeur joignable : en veille."
                    }
                }
            }, enabled = decoderIp.isNotBlank()) { Text("Tester") }
            TextButton(onClick = {
                scope.launch {
                    val ok = withContext(Dispatchers.IO) { OrangeDecoder(decoderIp.trim()).key(OrangeDecoder.CH_UP) }
                    status = if (ok) "Chaîne suivante envoyée au décodeur." else "Le décodeur ne répond pas."
                }
            }, enabled = decoderIp.isNotBlank()) { Text("Chaîne +") }
        }

        Text("Téléviseur Sony Bravia", style = MaterialTheme.typography.titleSmall)
        Hint2(
            "Une fois sur le téléviseur : Paramètres → Réseau et Internet → Configuration du réseau domestique → Contrôle IP. " +
                "Mets « Authentification » sur « Normal et clé pré-partagée », choisis une clé (par exemple 1234) et recopie-la ci-dessous. " +
                "Active aussi « Démarrage à distance » pour pouvoir l'allumer depuis le téléphone. Les libellés varient un peu selon le modèle."
        )
        OutlinedTextField(
            value = braviaIp,
            onValueChange = { braviaIp = it; cfg.braviaIp = it },
            label = { Text("Adresse du téléviseur") },
            singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri),
            modifier = Modifier.fillMaxWidth(),
        )
        OutlinedTextField(
            value = psk,
            onValueChange = { psk = it; cfg.braviaPsk = it },
            label = { Text("Clé pré-partagée") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth(),
        )
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            TextButton(onClick = {
                scope.launch {
                    status = withContext(Dispatchers.IO) {
                        val tv = BraviaTv(braviaIp.trim(), psk.trim())
                        val problem = tv.lastProblem()
                        if (problem != null) "Téléviseur : $problem."
                        else {
                            tv.macAddress()?.let { cfg.braviaMac = it }
                            "Téléviseur ${tv.model() ?: ""} joignable : ${if (tv.isOn() == true) "allumé" else "en veille"}."
                        }
                    }
                }
            }, enabled = braviaIp.isNotBlank()) { Text("Tester") }
            TextButton(onClick = {
                scope.launch {
                    val ok = withContext(Dispatchers.IO) { BraviaTv(braviaIp.trim(), psk.trim()).volume("+1") }
                    status = if (ok) "Volume du téléviseur monté d'un cran." else "Le téléviseur refuse la commande (clé, contrôle IP ?)."
                }
            }, enabled = braviaIp.isNotBlank()) { Text("Volume +") }
        }

        Text("Téléphone", style = MaterialTheme.typography.titleSmall)
        Hint2(
            "Ouvrir des applis, la lampe, le volume et la batterie marchent tout de suite. La luminosité, la rotation et le mode " +
                "Ne pas déranger demandent une autorisation à donner une fois. Le Wi-Fi, le Bluetooth et l'économie d'énergie ne " +
                "peuvent pas être changés par une appli : l'assistant ouvre le bon réglage et tu touches l'interrupteur."
        )
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            TextButton(onClick = { phone.askWriteSettings() }, enabled = !phone.canWriteSettings()) {
                Text(if (phone.canWriteSettings()) "Luminosité : autorisé" else "Autoriser luminosité/rotation")
            }
            TextButton(onClick = { phone.askDndAccess() }, enabled = !phone.canControlDnd()) {
                Text(if (phone.canControlDnd()) "Ne pas déranger : autorisé" else "Autoriser Ne pas déranger")
            }
        }

        Text("Exemples à dire ou écrire à l'assistant", style = MaterialTheme.typography.titleSmall)
        Hint2(DeviceCommands.EXAMPLES.joinToString(" · ") { "« $it »" })
    }
}

@Composable
private fun Hint2(text: String) {
    Text(text, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
}
