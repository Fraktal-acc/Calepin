package fr.jeremy.calepin.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import fr.jeremy.calepin.i18n.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.compose.ui.unit.dp
import fr.jeremy.calepin.LockGuard
import fr.jeremy.calepin.control.DeviceCommands
import fr.jeremy.calepin.control.DeviceStore
import fr.jeremy.calepin.control.PhoneControl
import fr.jeremy.calepin.control.WhatsAppSender

/** Réglages « Maison et téléphone » de Calepin IA. */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun HomeSettings(onDevices: () -> Unit) {
    val ctx = LocalContext.current
    val phone = remember { PhoneControl(ctx) }
    // Relire les autorisations au retour des écrans de réglages d'Android
    var refresh by remember { mutableIntStateOf(0) }
    val owner = LocalLifecycleOwner.current
    DisposableEffect(owner) {
        val obs = LifecycleEventObserver { _, e -> if (e == Lifecycle.Event.ON_RESUME) refresh++ }
        owner.lifecycle.addObserver(obs)
        onDispose { owner.lifecycle.removeObserver(obs) }
    }
    val count = remember(refresh) { DeviceStore(ctx).all().size }
    val waAuto = remember(refresh) { WhatsAppSender.isEnabled(ctx) }
    val canWrite = remember(refresh) { phone.canWriteSettings() }
    val canDnd = remember(refresh) { phone.canControlDnd() }

    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Hint3(
            "Commande la maison et le téléphone en parlant à l'assistant. Télés, décodeurs de tous les opérateurs, lumières, " +
                "prises et centrales domotiques se pilotent quand le téléphone est sur le même Wi-Fi."
        )
        Button(onClick = onDevices, modifier = Modifier.fillMaxWidth()) {
            Text(if (count == 0) "Appareils de la maison : rechercher" else "Appareils de la maison ($count)")
        }

        Text("Messages WhatsApp", style = MaterialTheme.typography.titleSmall)
        Hint3(
            "« Envoie un WhatsApp à Marc : j'arrive » : l'assistant te demande de confirmer, puis prépare le message. " +
                "Avec l'envoi automatique activé, il touche Envoyer à ta place (un message à la fois, toujours après ton « oui »)."
        )
        if (waAuto) {
            Text("Envoi automatique : activé", color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.bodyMedium)
            TextButton(onClick = { LockGuard.external(); WhatsAppSender.openSettings(ctx) }) { Text("Désactiver dans Accessibilité") }
        } else {
            OutlinedButton(onClick = { LockGuard.external(); WhatsAppSender.openSettings(ctx) }, modifier = Modifier.fillMaxWidth()) {
                Text("Activer l'envoi automatique")
            }
            Hint3(
                "Dans la liste, touche « Applications installées » → « Calepin IA – envoi WhatsApp » → Activer. " +
                    "Si l'option est grisée : Paramètres du téléphone → Applications → Calepin IA → ⋮ (en haut à droite) → " +
                    "« Autoriser les paramètres restreints », puis recommence."
            )
        }

        Text("Téléphone", style = MaterialTheme.typography.titleSmall)
        Hint3(
            "Ouvrir des applis, la lampe de poche, le volume et la batterie marchent tout de suite. La luminosité, la rotation " +
                "et Ne pas déranger demandent une autorisation à donner une fois. Le Wi-Fi, le Bluetooth et l'économie d'énergie " +
                "ne peuvent pas être changés par une appli : l'assistant ouvre le bon réglage et tu touches l'interrupteur."
        )
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            TextButton(onClick = { phone.askWriteSettings() }, enabled = !canWrite) {
                Text(if (canWrite) "Luminosité : autorisée" else "Autoriser luminosité/rotation")
            }
            TextButton(onClick = { phone.askDndAccess() }, enabled = !canDnd) {
                Text(if (canDnd) "Ne pas déranger : autorisé" else "Autoriser Ne pas déranger")
            }
        }

        Text("Exemples à dire ou écrire à l'assistant", style = MaterialTheme.typography.titleSmall)
        Hint3(DeviceCommands.EXAMPLES.joinToString(" · ") { "« ${fr.jeremy.calepin.i18n.I18n.tr(it)} »" })
    }
}

@Composable
private fun Hint3(text: String) {
    Text(text, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
}
