package fr.jeremy.calepin.office

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.graphics.pdf.PdfRenderer
import android.media.ExifInterface
import android.net.Uri
import android.os.ParcelFileDescriptor
import android.provider.OpenableColumns
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.pdmodel.PDPage
import com.tom_roush.pdfbox.pdmodel.PDPageContentStream
import com.tom_roush.pdfbox.pdmodel.common.PDRectangle
import com.tom_roush.pdfbox.pdmodel.font.PDFont
import com.tom_roush.pdfbox.pdmodel.font.PDType0Font
import com.tom_roush.pdfbox.pdmodel.font.PDType1Font
import com.tom_roush.pdfbox.pdmodel.graphics.image.JPEGFactory
import com.tom_roush.pdfbox.pdmodel.graphics.state.PDExtendedGraphicsState
import com.tom_roush.pdfbox.pdmodel.interactive.form.PDCheckBox
import com.tom_roush.pdfbox.pdmodel.interactive.form.PDField
import com.tom_roush.pdfbox.pdmodel.interactive.form.PDTextField
import com.tom_roush.pdfbox.text.PDFTextStripper
import com.tom_roush.pdfbox.util.Matrix as PdfMatrix
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.UUID

/** Un PDF de la bibliothèque de Calepin (copié dans le dossier privé de l'appli). */
data class PdfEntry(
    val id: String,
    val name: String,
    val added: Long,
    val opened: Long,
    val page: Int = 0,
    val pages: Int = 0,
    /** Dossier du bureau PDF ("" = aucun). */
    val folder: String = "",
) {
    fun toJson(): JSONObject = JSONObject().put("id", id).put("name", name).put("added", added).put("opened", opened).put("page", page).put("pages", pages).put("folder", folder)

    companion object {
        fun fromJson(o: JSONObject) = PdfEntry(o.optString("id"), o.optString("name"), o.optLong("added"), o.optLong("opened"), o.optInt("page"), o.optInt("pages"), o.optString("folder"))
    }
}

/** Le PDF est protégé par un mot de passe. */
class PdfLocked : Exception("PDF protégé par un mot de passe")

/**
 * Bibliothèque de PDF : import, liste, et toutes les opérations (pages, fusion, photos → PDF,
 * annotations, signature, formulaires, mot de passe). Une copie de sécurité est gardée avant chaque
 * modification (« Annuler la dernière modification »).
 */
class PdfLibrary private constructor(private val ctx: Context) {
    val dir = File(ctx.filesDir, "documents").apply { mkdirs() }
    private val index = File(dir, "pdf-index.json")
    private val _folders = MutableStateFlow(loadFolders())
    /** Dossiers créés (même vides), triés par nom. */
    val folders: StateFlow<List<String>> = _folders
    private val _items = MutableStateFlow(load())
    val items: StateFlow<List<PdfEntry>> = _items

    /** Index : ancien format (liste) ou { items, folders }. */
    private fun readIndex(): JSONObject = runCatching {
        val t = index.readText().trim()
        if (t.startsWith("[")) JSONObject().put("items", JSONArray(t)) else JSONObject(t)
    }.getOrDefault(JSONObject())

    private fun load(): List<PdfEntry> = runCatching {
        val a = readIndex().optJSONArray("items") ?: JSONArray()
        (0 until a.length()).map { PdfEntry.fromJson(a.getJSONObject(it)) }
    }.getOrDefault(emptyList()).filter { File(dir, it.id + ".pdf").exists() }

    private fun loadFolders(): List<String> = runCatching {
        val a = readIndex().optJSONArray("folders") ?: JSONArray()
        (0 until a.length()).map { a.getString(it) }
    }.getOrDefault(emptyList())

    private fun persist(l: List<PdfEntry>, folders: List<String> = _folders.value) {
        _items.value = l.sortedByDescending { it.opened }
        _folders.value = (folders + l.map { it.folder }).filter { it.isNotBlank() }.distinct().sortedBy { it.lowercase() }
        index.writeText(
            JSONObject()
                .put("items", JSONArray().apply { _items.value.forEach { put(it.toJson()) } })
                .put("folders", JSONArray(_folders.value))
                .toString(),
        )
    }

    fun addFolder(name: String) {
        val n = name.trim().replace("/", "-")
        if (n.isNotEmpty()) persist(_items.value, _folders.value + n)
    }

    fun renameFolder(old: String, new: String) {
        val n = new.trim().replace("/", "-")
        if (n.isEmpty()) return
        persist(_items.value.map { if (it.folder == old) it.copy(folder = n) else it }, _folders.value.map { if (it == old) n else it })
    }

    /** Supprime le dossier : ses PDF reviennent à l'accueil du bureau (rien n'est effacé). */
    fun deleteFolder(name: String) = persist(_items.value.map { if (it.folder == name) it.copy(folder = "") else it }, _folders.value - name)

    fun move(id: String, folder: String) = update(id) { it.copy(folder = folder) }

    /** Dossier où ranger les nouveaux PDF (celui qu'on regarde). */
    @Volatile var currentFolder: String = ""

    fun refresh() { _items.value = load().sortedByDescending { it.opened } }

    fun file(id: String) = File(dir, "$id.pdf")
    private fun backup(id: String) = File(dir, "$id.bak")
    fun get(id: String) = _items.value.firstOrNull { it.id == id }
    fun canUndo(id: String) = backup(id).exists()

    private fun update(id: String, f: (PdfEntry) -> PdfEntry) = persist(_items.value.map { if (it.id == id) f(it) else it })

    fun touch(id: String, page: Int) = update(id) { it.copy(opened = System.currentTimeMillis(), page = page) }
    fun rename(id: String, name: String) = update(id) { it.copy(name = name.trim().ifBlank { it.name }) }

    /** Copie à partager ou à joindre à un mail, sous le nom du document (« Facture mars.pdf »). */
    suspend fun exportCopy(id: String): File = withContext(Dispatchers.IO) {
        val name = (get(id)?.name ?: "Document").replace(Regex("[\\\\/:*?\"<>|]"), "_").take(80).ifBlank { "Document" }
        val out = File(File(ctx.cacheDir, "exports").apply { mkdirs() }, "$name.pdf")
        lock.withLock { file(id).copyTo(out, overwrite = true) }
        out
    }

    /** Copie du PDF dans la bibliothèque (même dossier), annotations modifiables comprises. */
    suspend fun duplicate(id: String, name: String): PdfEntry = withContext(Dispatchers.IO) {
        lock.withLock {
            val src = get(id)
            val f = newFile()
            file(id).copyTo(f)
            val nid = f.nameWithoutExtension
            if (baseFile(id).exists()) baseFile(id).copyTo(baseFile(nid))
            if (layerFile(id).exists()) layerFile(id).copyTo(layerFile(nid))
            val saved = currentFolder
            currentFolder = src?.folder ?: saved
            try { add(f, name) } finally { currentFolder = saved }
        }
    }

    fun delete(id: String) {
        file(id).delete(); backup(id).delete(); dropLayer(id)
        persist(_items.value.filter { it.id != id })
    }

    private fun pageCount(f: File): Int = runCatching {
        ParcelFileDescriptor.open(f, ParcelFileDescriptor.MODE_READ_ONLY).use { PdfRenderer(it).use { r -> r.pageCount } }
    }.getOrDefault(0)

    private fun add(f: File, name: String): PdfEntry {
        val id = f.nameWithoutExtension
        val e = PdfEntry(id, name.removeSuffix(".pdf").removeSuffix(".PDF").ifBlank { "Document" }, System.currentTimeMillis(), System.currentTimeMillis(), 0, pageCount(f), currentFolder)
        persist(_items.value + e)
        return e
    }

    private fun newFile() = File(dir, UUID.randomUUID().toString() + ".pdf")

    /** Nom du fichier choisi (Téléchargements, Drive…). */
    fun displayName(uri: Uri): String = runCatching {
        ctx.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst()) c.getString(0) else null
        }
    }.getOrNull() ?: uri.lastPathSegment?.substringAfterLast('/') ?: "Document.pdf"

    /** Copie un PDF dans la bibliothèque. S'il est protégé, [PdfLocked] : redemander avec le mot de passe. */
    suspend fun import(uri: Uri, password: String? = null): PdfEntry = withContext(Dispatchers.IO) {
        val f = newFile()
        ctx.contentResolver.openInputStream(uri)!!.use { input -> f.outputStream().use { input.copyTo(it) } }
        try {
            ensureReadable(f, password)
        } catch (e: Throwable) {
            f.delete(); throw e
        }
        add(f, displayName(uri))
    }

    /** PdfRenderer ne lit pas les PDF chiffrés : on retire la protection (avec le mot de passe) dans la copie. */
    private fun ensureReadable(f: File, password: String?) {
        val ok = runCatching { ParcelFileDescriptor.open(f, ParcelFileDescriptor.MODE_READ_ONLY).use { PdfRenderer(it).close() } }.isSuccess
        if (ok) return
        PDFBoxResourceLoader.init(ctx)
        val doc = try {
            PDDocument.load(f, password ?: "")
        } catch (e: com.tom_roush.pdfbox.pdmodel.encryption.InvalidPasswordException) {
            throw PdfLocked()
        }
        doc.use {
            it.isAllSecurityToBeRemoved = true
            val tmp = File(dir, f.name + ".tmp")
            it.save(tmp)
            tmp.renameTo(f)
        }
    }

    // ------------------------------------------------------------------ Modifications (avec copie de sécurité)

    private suspend fun <T> edit(id: String, block: (PDDocument) -> T): T = withContext(Dispatchers.IO) {
        lock.withLock {
            PDFBoxResourceLoader.init(ctx)
            val f = file(id)
            f.copyTo(backup(id), overwrite = true)
            // Pages modifiées : les annotations deviennent définitives (plus modifiables)
            dropLayer(id)
            val tmp = File(dir, "$id.tmp")
            val r = PDDocument.load(f).use { doc ->
                val r = block(doc)
                doc.save(tmp)
                r
            }
            tmp.renameTo(f)
            update(id) { it.copy(pages = pageCount(f), opened = System.currentTimeMillis()) }
            r
        }
    }

    /** Remet le PDF tel qu'il était avant la dernière modification. */
    suspend fun undo(id: String) = withContext(Dispatchers.IO) {
        val b = backup(id)
        if (b.exists()) {
            b.copyTo(file(id), overwrite = true); b.delete()
            // Annotations : on revient à l'état d'avant le dernier enregistrement
            val lb = layerBackup(id)
            if (lb.exists()) { lb.copyTo(layerFile(id), overwrite = true); lb.delete() } else layerFile(id).delete()
            update(id) { it.copy(pages = pageCount(file(id))) }
        }
    }

    suspend fun rotate(id: String, pages: Collection<Int>, degrees: Int) = edit(id) { doc ->
        pages.forEach { i -> doc.getPage(i).let { p -> p.rotation = ((p.rotation + degrees) % 360 + 360) % 360 } }
    }

    suspend fun deletePages(id: String, pages: Collection<Int>) = edit(id) { doc ->
        pages.sortedDescending().forEach { if (doc.numberOfPages > 1) doc.removePage(it) }
    }

    /** Nouvel ordre des pages ([order] : anciens numéros, dans l'ordre voulu). */
    suspend fun reorder(id: String, order: List<Int>) = edit(id) { doc ->
        val pages = (0 until doc.numberOfPages).map { doc.getPage(it) }
        val tree = doc.pages
        pages.forEach { tree.remove(it) }
        order.forEach { tree.add(pages[it]) }
    }

    /** Ajoute à la fin les pages d'autres PDF de la bibliothèque. */
    suspend fun appendFrom(id: String, others: List<String>) = withContext(Dispatchers.IO) {
        PDFBoxResourceLoader.init(ctx)
        val opened = others.map { PDDocument.load(file(it)) }
        try {
            edit(id) { doc -> opened.forEach { o -> (0 until o.numberOfPages).forEach { doc.importPage(o.getPage(it)) } } }
        } finally {
            opened.forEach { runCatching { it.close() } }
        }
    }

    /** Copie des pages choisies dans un nouveau PDF. */
    suspend fun extract(id: String, pages: List<Int>, name: String): PdfEntry = withContext(Dispatchers.IO) {
        PDFBoxResourceLoader.init(ctx)
        val f = newFile()
        PDDocument.load(file(id)).use { src ->
            PDDocument().use { out ->
                pages.sorted().forEach { out.importPage(src.getPage(it)) }
                out.save(f)
            }
        }
        add(f, name)
    }

    /** Fusionne plusieurs PDF de la bibliothèque dans un nouveau. */
    suspend fun merge(ids: List<String>, name: String): PdfEntry = withContext(Dispatchers.IO) {
        PDFBoxResourceLoader.init(ctx)
        val f = newFile()
        val docs = ids.map { PDDocument.load(file(it)) }
        try {
            PDDocument().use { out ->
                docs.forEach { d -> (0 until d.numberOfPages).forEach { out.importPage(d.getPage(it)) } }
                out.save(f)
            }
        } finally {
            docs.forEach { runCatching { it.close() } }
        }
        add(f, name)
    }

    /** Photos (appareil ou galerie) → un PDF A4, une photo par page. */
    suspend fun fromImages(uris: List<Uri>, name: String): PdfEntry = withContext(Dispatchers.IO) {
        PDFBoxResourceLoader.init(ctx)
        val f = newFile()
        PDDocument().use { doc ->
            uris.forEach { u ->
                val bmp = loadBitmap(u, 2200) ?: return@forEach
                val a4 = PDRectangle.A4
                val landscape = bmp.width > bmp.height
                val box = if (landscape) PDRectangle(a4.height, a4.width) else a4
                val page = PDPage(box)
                doc.addPage(page)
                val img = JPEGFactory.createFromImage(doc, bmp, 0.85f)
                val m = 18f
                val k = minOf((box.width - 2 * m) / bmp.width, (box.height - 2 * m) / bmp.height)
                val w = bmp.width * k
                val h = bmp.height * k
                PDPageContentStream(doc, page).use { cs -> cs.drawImage(img, (box.width - w) / 2, (box.height - h) / 2, w, h) }
                bmp.recycle()
            }
            if (doc.numberOfPages == 0) error("Aucune image lisible")
            doc.save(f)
        }
        add(f, name)
    }

    private fun loadBitmap(u: Uri, maxSide: Int): Bitmap? = runCatching {
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        ctx.contentResolver.openInputStream(u)!!.use { BitmapFactory.decodeStream(it, null, o) }
        var s = 1
        while (maxOf(o.outWidth, o.outHeight) / (s * 2) >= maxSide) s *= 2
        var b = ctx.contentResolver.openInputStream(u)!!.use { BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = s }) }!!
        val deg = runCatching {
            ctx.contentResolver.openInputStream(u)!!.use { ExifInterface(it) }
                .getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL).let {
                    when (it) { ExifInterface.ORIENTATION_ROTATE_90 -> 90f; ExifInterface.ORIENTATION_ROTATE_180 -> 180f; ExifInterface.ORIENTATION_ROTATE_270 -> 270f; else -> 0f }
                }
        }.getOrDefault(0f)
        if (deg != 0f) b = Bitmap.createBitmap(b, 0, 0, b.width, b.height, Matrix().apply { postRotate(deg) }, true)
        b
    }.getOrNull()

    /** Copie du PDF protégée par un mot de passe (AES 128 bits), à partager. */
    suspend fun protect(id: String, password: String, name: String): File = withContext(Dispatchers.IO) {
        PDFBoxResourceLoader.init(ctx)
        val f = newFile()
        PDDocument.load(file(id)).use { doc ->
            val ap = com.tom_roush.pdfbox.pdmodel.encryption.AccessPermission()
            val policy = com.tom_roush.pdfbox.pdmodel.encryption.StandardProtectionPolicy(password, password, ap).apply { encryptionKeyLength = 128 }
            doc.protect(policy)
            doc.save(f)
        }
        // Le fichier protégé est fait pour être partagé : il ne va pas dans la bibliothèque (illisible par l'aperçu)
        val out = File(File(ctx.cacheDir, "exports").apply { mkdirs() }, "$name.pdf")
        out.delete()
        f.copyTo(out); f.delete()
        out
    }

    // ------------------------------------------------------------------ Texte

    /** Texte de chaque page (pour la recherche et la lecture à voix haute). */
    suspend fun pageTexts(id: String): List<String> = withContext(Dispatchers.IO) {
        PDFBoxResourceLoader.init(ctx)
        runCatching {
            PDDocument.load(file(id)).use { doc ->
                val s = PDFTextStripper().apply { sortByPosition = true }
                (1..doc.numberOfPages).map { p -> s.startPage = p; s.endPage = p; s.getText(doc) }
            }
        }.getOrDefault(emptyList())
    }

    // ------------------------------------------------------------------ Formulaires

    data class FormField(val name: String, val label: String, val checkbox: Boolean, val value: String)

    suspend fun formFields(id: String): List<FormField> = withContext(Dispatchers.IO) {
        PDFBoxResourceLoader.init(ctx)
        runCatching {
            PDDocument.load(file(id)).use { doc ->
                val form = doc.documentCatalog.acroForm ?: return@use emptyList()
                form.fieldTree.mapNotNull { f: PDField ->
                    when (f) {
                        is PDCheckBox -> FormField(f.fullyQualifiedName, f.alternateFieldName ?: f.partialName, true, if (f.isChecked) "1" else "")
                        is PDTextField -> FormField(f.fullyQualifiedName, f.alternateFieldName ?: f.partialName, false, f.value.orEmpty())
                        else -> null
                    }
                }
            }
        }.getOrDefault(emptyList())
    }

    suspend fun fillForm(id: String, values: Map<String, String>, flatten: Boolean) = edit(id) { doc ->
        val form = doc.documentCatalog.acroForm ?: return@edit
        form.needAppearances = true
        values.forEach { (k, v) ->
            when (val f = form.getField(k)) {
                is PDCheckBox -> if (v.isNotEmpty()) f.check() else f.unCheck()
                is PDTextField -> runCatching { f.value = v }
                else -> Unit
            }
        }
        if (flatten) runCatching { form.flatten() }
    }

    // ------------------------------------------------------------------ Annotations (dessinées dans la page)

    /** Point en coordonnées de l'image affichée, de 0 à 1 (x vers la droite, y vers le bas). */
    data class P(val x: Float, val y: Float)

    sealed interface Mark {
        /** Trait de stylo, surligneur ou signature. */
        data class Ink(val points: List<P>, val color: Int, val width: Float, val highlight: Boolean = false) : Mark
        /** Texte posé sur la page ; [size] en fraction de la largeur affichée. */
        data class Text(val at: P, val text: String, val color: Int, val size: Float) : Mark
        /** Rectangle plein (cache blanc pour masquer, ou couleur). */
        data class Box(val a: P, val b: P, val color: Int) : Mark
    }

    private fun fontFor(doc: PDDocument): PDFont {
        // Police du téléphone (accents, €…) ; sinon Helvetica
        val candidates = listOf("/system/fonts/Roboto-Regular.ttf", "/system/fonts/NotoSans-Regular.ttf", "/system/fonts/DroidSans.ttf")
        for (p in candidates) {
            val f = File(p)
            if (f.exists()) runCatching { return PDType0Font.load(doc, f) }
        }
        return PDType1Font.HELVETICA
    }

    /** Dessine les annotations dans la page [index] (définitivement, visibles par toutes les applis). */
    suspend fun applyMarks(id: String, index: Int, marks: List<Mark>) = edit(id) { doc -> drawMarks(doc, index, marks) }

    private fun drawMarks(doc: PDDocument, index: Int, marks: List<Mark>) {
        if (marks.isEmpty() || index !in 0 until doc.numberOfPages) return
        val page = doc.getPage(index)
        val box = page.cropBox ?: page.mediaBox
        val rot = ((page.rotation % 360) + 360) % 360
        val x0 = box.lowerLeftX; val y0 = box.lowerLeftY; val w = box.width; val h = box.height
        // Largeur affichée en points (pour convertir les épaisseurs)
        val shownW = if (rot == 90 || rot == 270) h else w
        fun map(p: P): Pair<Float, Float> = when (rot) {
            90 -> (x0 + p.y * w) to (y0 + p.x * h)
            180 -> (x0 + (1 - p.x) * w) to (y0 + p.y * h)
            270 -> (x0 + (1 - p.y) * w) to (y0 + (1 - p.x) * h)
            else -> (x0 + p.x * w) to (y0 + (1 - p.y) * h)
        }
        val font: PDFont by lazy { fontFor(doc) }
        fun rgb(c: Int) = floatArrayOf(((c shr 16) and 0xFF) / 255f, ((c shr 8) and 0xFF) / 255f, (c and 0xFF) / 255f)
        PDPageContentStream(doc, page, PDPageContentStream.AppendMode.APPEND, true, true).use { cs ->
            marks.forEach { m ->
                when (m) {
                    is Mark.Ink -> if (m.points.size >= 1) {
                        cs.saveGraphicsState()
                        if (m.highlight) {
                            val gs = PDExtendedGraphicsState().apply { strokingAlphaConstant = 0.35f; nonStrokingAlphaConstant = 0.35f }
                            cs.setGraphicsStateParameters(gs)
                        }
                        val c = rgb(m.color)
                        cs.setStrokingColor(c[0], c[1], c[2])
                        cs.setLineWidth(m.width * shownW)
                        cs.setLineCapStyle(1); cs.setLineJoinStyle(1)
                        val (sx, sy) = map(m.points.first())
                        cs.moveTo(sx, sy)
                        if (m.points.size == 1) cs.lineTo(sx + 0.1f, sy)
                        m.points.drop(1).forEach { p -> val (x, y) = map(p); cs.lineTo(x, y) }
                        cs.stroke()
                        cs.restoreGraphicsState()
                    }
                    is Mark.Text -> {
                        val f = font
                        val size = m.size * shownW
                        val c = rgb(m.color)
                        cs.beginText()
                        cs.setNonStrokingColor(c[0], c[1], c[2])
                        cs.setFont(f, size)
                        val (x, y) = map(m.at)
                        // Le point touché est le haut de la première ligne
                        m.text.lines().forEachIndexed { i, line ->
                            val off = size * (0.85f + i * 1.25f)
                            val (lx, ly) = when (rot) {
                                90 -> (x + off) to y
                                180 -> x to (y + off)
                                270 -> (x - off) to y
                                else -> x to (y - off)
                            }
                            cs.setTextMatrix(PdfMatrix.getRotateInstance(Math.toRadians(rot.toDouble()), lx, ly))
                            runCatching { cs.showText(line) }.onFailure { cs.showText(line.filter { it.code < 256 }) }
                        }
                        cs.endText()
                    }
                    is Mark.Box -> {
                        val (ax, ay) = map(m.a)
                        val (bx, by) = map(m.b)
                        val c = rgb(m.color)
                        cs.setNonStrokingColor(c[0], c[1], c[2])
                        cs.addRect(minOf(ax, bx), minOf(ay, by), kotlin.math.abs(bx - ax), kotlin.math.abs(by - ay))
                        cs.fill()
                    }
                }
            }
        }
    }

    // ------------------------------------------------------------------ Annotations modifiables

    /**
     * Les annotations sont gardées à part ([layerFile]) avec le PDF d'origine ([baseFile]) : on peut les rouvrir
     * pour corriger le texte, effacer un trait… Le PDF de la bibliothèque est recalculé à chaque enregistrement
     * (base + annotations), donc il reste lisible partout. Une modification des pages (rotation, suppression,
     * ordre, ajout, formulaire) rend les annotations définitives.
     */
    data class WriteData(val at: P, val color: Int, val size: Float, val text: String)

    data class PageLayer(val marks: List<Mark> = emptyList(), val writes: List<WriteData> = emptyList(), val flat: List<Mark> = emptyList()) {
        val isEmpty get() = marks.isEmpty() && writes.all { it.text.isBlank() }
    }

    private fun baseFile(id: String) = File(dir, "$id.base")
    private fun layerFile(id: String) = File(dir, "$id.layer.json")
    private fun layerBackup(id: String) = File(dir, "$id.layer.bak")

    private fun dropLayer(id: String) {
        baseFile(id).delete(); layerFile(id).delete(); layerBackup(id).delete()
    }

    private fun markJson(m: Mark): JSONObject = when (m) {
        is Mark.Ink -> JSONObject().put("t", "i").put("c", m.color).put("w", m.width.toDouble()).put("h", m.highlight)
            .put("p", JSONArray().apply { m.points.forEach { put(it.x.toDouble()); put(it.y.toDouble()) } })
        is Mark.Text -> JSONObject().put("t", "t").put("x", m.at.x.toDouble()).put("y", m.at.y.toDouble()).put("s", m.text).put("c", m.color).put("z", m.size.toDouble())
        is Mark.Box -> JSONObject().put("t", "b").put("ax", m.a.x.toDouble()).put("ay", m.a.y.toDouble()).put("bx", m.b.x.toDouble()).put("by", m.b.y.toDouble()).put("c", m.color)
    }

    private fun markOf(o: JSONObject): Mark? = when (o.optString("t")) {
        "i" -> {
            val a = o.optJSONArray("p") ?: JSONArray()
            Mark.Ink((0 until a.length() / 2).map { P(a.optDouble(it * 2).toFloat(), a.optDouble(it * 2 + 1).toFloat()) }, o.optInt("c"), o.optDouble("w").toFloat(), o.optBoolean("h"))
        }
        "t" -> Mark.Text(P(o.optDouble("x").toFloat(), o.optDouble("y").toFloat()), o.optString("s"), o.optInt("c"), o.optDouble("z").toFloat())
        "b" -> Mark.Box(P(o.optDouble("ax").toFloat(), o.optDouble("ay").toFloat()), P(o.optDouble("bx").toFloat(), o.optDouble("by").toFloat()), o.optInt("c"))
        else -> null
    }

    private fun marksJson(l: List<Mark>) = JSONArray().apply { l.forEach { put(markJson(it)) } }
    private fun marksOf(a: JSONArray?) = if (a == null) emptyList() else (0 until a.length()).mapNotNull { a.optJSONObject(it)?.let(::markOf) }

    private fun readLayers(id: String): MutableMap<Int, PageLayer> = runCatching {
        val o = JSONObject(layerFile(id).readText())
        o.keys().asSequence().associate { k ->
            val p = o.getJSONObject(k)
            val w = p.optJSONArray("writes") ?: JSONArray()
            k.toInt() to PageLayer(
                marksOf(p.optJSONArray("marks")),
                (0 until w.length()).map { i ->
                    val x = w.getJSONObject(i)
                    WriteData(P(x.optDouble("x").toFloat(), x.optDouble("y").toFloat()), x.optInt("c"), x.optDouble("z").toFloat(), x.optString("s"))
                },
                marksOf(p.optJSONArray("flat")),
            )
        }.toMutableMap()
    }.getOrDefault(mutableMapOf())

    /** Annotations modifiables d'une page (vide si aucune ou devenues définitives). */
    suspend fun layer(id: String, page: Int): PageLayer = withContext(Dispatchers.IO) {
        if (!baseFile(id).exists()) PageLayer() else readLayers(id)[page] ?: PageLayer()
    }

    fun hasLayer(id: String) = baseFile(id).exists() && layerFile(id).exists()

    /** Enregistre les annotations de la page [page] et recalcule le PDF (base + toutes les annotations). */
    suspend fun saveLayer(id: String, page: Int, layer: PageLayer) = withContext(Dispatchers.IO) {
        lock.withLock {
            PDFBoxResourceLoader.init(ctx)
            val f = file(id)
            val base = baseFile(id)
            if (!base.exists() || !layerFile(id).exists()) { f.copyTo(base, overwrite = true); layerFile(id).delete() }
            // Pour « Annuler la dernière modification »
            f.copyTo(backup(id), overwrite = true)
            if (layerFile(id).exists()) layerFile(id).copyTo(layerBackup(id), overwrite = true) else layerBackup(id).delete()

            val all = readLayers(id)
            if (layer.isEmpty) all.remove(page) else all[page] = layer
            val o = JSONObject()
            all.forEach { (k, l) ->
                o.put(k.toString(), JSONObject()
                    .put("marks", marksJson(l.marks))
                    .put("flat", marksJson(l.flat))
                    .put("writes", JSONArray().apply {
                        l.writes.filter { it.text.isNotBlank() }.forEach { w ->
                            put(JSONObject().put("x", w.at.x.toDouble()).put("y", w.at.y.toDouble()).put("c", w.color).put("z", w.size.toDouble()).put("s", w.text))
                        }
                    }))
            }
            layerFile(id).writeText(o.toString())

            val tmp = File(dir, "$id.tmp")
            PDDocument.load(base).use { doc ->
                all.forEach { (k, l) -> drawMarks(doc, k, l.marks + l.flat) }
                doc.save(tmp)
            }
            tmp.renameTo(f)
            update(id) { it.copy(pages = pageCount(f), opened = System.currentTimeMillis()) }
        }
    }

    // ------------------------------------------------------------------ Aperçu des pages

    private val lock = Mutex()

    /** Rend une page en image ([width] en pixels). Un seul rendu à la fois (PdfRenderer n'est pas partageable). */
    suspend fun render(id: String, index: Int, width: Int): Bitmap? = renderFile(file(id), index, width)

    /** Page sans les annotations modifiables (pour les retoucher par-dessus). */
    suspend fun renderEditable(id: String, index: Int, width: Int): Bitmap? =
        renderFile(baseFile(id).takeIf { it.exists() && layerFile(id).exists() } ?: file(id), index, width)

    private suspend fun renderFile(src: File, index: Int, width: Int): Bitmap? = withContext(Dispatchers.IO) {
        lock.withLock {
            runCatching {
                ParcelFileDescriptor.open(src, ParcelFileDescriptor.MODE_READ_ONLY).use { pfd ->
                    PdfRenderer(pfd).use { r ->
                        if (index !in 0 until r.pageCount) return@use null
                        r.openPage(index).use { p ->
                            val ww = width.coerceIn(64, 3000)
                            val hh = (ww.toFloat() * p.height / p.width).toInt().coerceAtLeast(1)
                            val bmp = Bitmap.createBitmap(ww, hh, Bitmap.Config.ARGB_8888)
                            bmp.eraseColor(android.graphics.Color.WHITE)
                            p.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                            bmp
                        }
                    }
                }
            }.getOrNull()
        }
    }

    /** Taille de chaque page (largeur / hauteur), pour réserver la place avant le rendu. */
    suspend fun ratios(id: String): List<Float> = withContext(Dispatchers.IO) {
        lock.withLock {
            runCatching {
                ParcelFileDescriptor.open(file(id), ParcelFileDescriptor.MODE_READ_ONLY).use { pfd ->
                    PdfRenderer(pfd).use { r -> (0 until r.pageCount).map { i -> r.openPage(i).use { it.height.toFloat() / it.width } } }
                }
            }.getOrDefault(emptyList())
        }
    }

    companion object {
        @Volatile private var instance: PdfLibrary? = null
        fun get(ctx: Context): PdfLibrary = instance ?: synchronized(this) { instance ?: PdfLibrary(ctx.applicationContext).also { instance = it } }
    }
}
