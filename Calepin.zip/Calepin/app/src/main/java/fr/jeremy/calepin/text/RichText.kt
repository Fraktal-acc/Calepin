package fr.jeremy.calepin.text

/**
 * Texte enrichi des notes, gardé dans le texte lui-même avec des repères invisibles à l'écran :
 * couleur « [c=#RRGGBB]…[/c] », surlignage « [bg=#RRGGBB]…[/bg] », souligné « [u]…[/u] »,
 * alignement « [center] » ou « [right] » en fin de ligne.
 *
 * Les couleurs sont enregistrées telles quelles : elles ne changent pas avec le thème de l'appli.
 */
object RichText {
    val TOKEN = Regex("\\[(?:c|bg)=#[0-9A-Fa-f]{6}\\]|\\[/(?:c|bg|u)\\]|\\[u\\]|\\[(?:center|right)\\](?=\\n|$)")
    private val ALIGN = Regex("\\[(center|right)\\](?=\\n|$)")

    const val CENTER = "center"
    const val RIGHT = "right"

    /** Repère trouvé dans le texte ([kind] : « c », « bg », « u » ou « align »). */
    data class Tok(val start: Int, val end: Int, val kind: String, val open: Boolean, val value: String?)

    /** Partie mise en forme : de [start] à [end] (texte entre les repères). */
    data class Span(val kind: String, val value: String, val start: Int, val end: Int)

    fun tokens(text: String): List<Tok> = TOKEN.findAll(text).map { m ->
        val v = m.value
        val s = m.range.first
        val e = m.range.last + 1
        when {
            v.startsWith("[/") -> Tok(s, e, v.substring(2, v.length - 1), false, null)
            v.startsWith("[c=") -> Tok(s, e, "c", true, v.substring(3, 10).uppercase())
            v.startsWith("[bg=") -> Tok(s, e, "bg", true, v.substring(4, 11).uppercase())
            v == "[u]" -> Tok(s, e, "u", true, "")
            else -> Tok(s, e, "align", true, v.substring(1, v.length - 1))
        }
    }.toList()

    /** Parties en couleur, surlignées et soulignées (les repères sans fin sont ignorés). */
    fun spans(text: String): List<Span> {
        val out = ArrayList<Span>()
        val open = HashMap<String, Tok>()
        for (t in tokens(text)) {
            if (t.kind == "align") continue
            if (t.open) {
                open[t.kind]?.let { o -> if (t.start > o.end) out += Span(t.kind, o.value.orEmpty(), o.end, t.start) }
                open[t.kind] = t
            } else {
                open.remove(t.kind)?.let { o -> if (t.start > o.end) out += Span(t.kind, o.value.orEmpty(), o.end, t.start) }
            }
        }
        return out
    }

    /** Lignes alignées : (début de la ligne, fin de la ligne, « center » ou « right »). */
    fun aligns(text: String): List<Triple<Int, Int, String>> = ALIGN.findAll(text).map { m ->
        val ls = text.lastIndexOf('\n', m.range.first - 1) + 1
        Triple(ls, m.range.last + 1, m.groupValues[1])
    }.toList()

    /** Texte sans les repères (partage, export, lecture à voix haute, aperçus). */
    fun strip(text: String): String = if ('[' !in text) text else TOKEN.replace(text, "")

    /**
     * Correspondance entre le texte enregistré et le texte affiché (sans repères). Une position affichée
     * correspond à la première position possible du texte enregistré : ce qu'on écrit prend la mise en
     * forme du caractère d'avant.
     */
    class Mapping(val text: String) {
        private val hidden: List<IntArray> = if ('[' !in text) emptyList() else TOKEN.findAll(text).map { intArrayOf(it.range.first, it.range.last + 1) }.toList()
        val visible: String = if (hidden.isEmpty()) text else buildString {
            var p = 0
            hidden.forEach { r -> append(text, p, r[0]); p = r[1] }
            append(text, p, text.length)
        }
        val isIdentity get() = hidden.isEmpty()

        fun toVisible(offset: Int): Int {
            val o = offset.coerceIn(0, text.length)
            var h = 0
            for (r in hidden) {
                if (o >= r[1]) h += r[1] - r[0]
                else { if (o > r[0]) h += o - r[0]; break }
            }
            return o - h
        }

        fun toOriginal(offset: Int): Int {
            val t = offset.coerceIn(0, visible.length)
            var acc = 0
            for (r in hidden) {
                if (t + acc <= r[0]) return t + acc
                acc += r[1] - r[0]
            }
            return (t + acc).coerceAtMost(text.length)
        }

        /** Positions des repères (pour les masquer). */
        fun hiddenRanges(): List<IntRange> = hidden.map { it[0] until it[1] }
    }

    /** Valeur de [kind] en vigueur à la position [pos] (null : aucune). */
    fun activeAt(text: String, pos: Int, kind: String): String? {
        var v: String? = null
        for (t in tokens(text)) {
            if (t.start >= pos) break
            if (t.kind != kind) continue
            v = if (t.open) t.value else null
        }
        return v
    }

    /** Position hors d'un repère (jamais au milieu de « [c=#…] »). */
    private fun outside(text: String, p0: Int): Int {
        val p = p0.coerceIn(0, text.length)
        return tokens(text).firstOrNull { p > it.start && p < it.end }?.start ?: p
    }

    private const val S1 = '\uE000'
    private const val S2 = '\uE001'

    /** Résultat d'une mise en forme : nouveau texte et nouvelle sélection. */
    data class Edit(val text: String, val start: Int, val end: Int)

    private fun extract(s: String): Edit {
        val a = s.indexOf(S1)
        val t1 = if (a >= 0) s.removeRange(a, a + 1) else s
        val b = t1.indexOf(S2)
        val t2 = if (b >= 0) t1.removeRange(b, b + 1) else t1
        val aa = if (a >= 0) a else 0
        val bb = if (b >= 0) b else aa
        return Edit(t2, minOf(aa, bb), maxOf(aa, bb))
    }

    private fun open(kind: String, value: String) = if (kind == "u") "[u]" else "[$kind=$value]"

    /**
     * Met en forme le texte entre [a] et [b] : couleur (« c »), surlignage (« bg ») ou souligné (« u », valeur « »).
     * [value] null : retire cette mise en forme. Sans sélection, les repères entourent le curseur (pour ce qu'on va écrire).
     */
    fun apply(text: String, a0: Int, b0: Int, kind: String, value: String?): Edit {
        val a = outside(text, minOf(a0, b0))
        val b = outside(text, maxOf(a0, b0))
        val before = activeAt(text, a, kind)
        val after = activeAt(text, b, kind)
        val mid = text.substring(a, b).let { m ->
            tokens(m).filter { it.kind == kind }.reversed().fold(m) { acc, t -> acc.removeRange(t.start, t.end) }
        }
        val v = value?.uppercase()
        val sb = StringBuilder()
        sb.append(text, 0, a)
        if (before != null) sb.append("[/$kind]")
        if (v != null) sb.append(open(kind, v))
        sb.append(S1).append(mid).append(S2)
        if (v != null) sb.append("[/$kind]")
        if (after != null) sb.append(open(kind, after))
        sb.append(text, b, text.length)
        return extract(cleanup(sb.toString()))
    }

    /** Souligné : retiré si toute la sélection l'est déjà, sinon ajouté. */
    fun toggleUnderline(text: String, a0: Int, b0: Int): Edit {
        val a = outside(text, minOf(a0, b0))
        val b = outside(text, maxOf(a0, b0))
        val on = if (a == b) activeAt(text, a, "u") != null else {
            val sp = spans(text).filter { it.kind == "u" }
            val hiddenAt = Mapping(text).hiddenRanges()
            (a until b).all { p -> hiddenAt.any { p in it } || sp.any { p >= it.start && p < it.end } }
        }
        return apply(text, a, b, "u", if (on) null else "")
    }

    /** Une seule couleur sur toute la sélection : laquelle (sinon null). */
    fun valueOver(text: String, a: Int, b: Int, kind: String): String? {
        if (a >= b) return activeAt(text, a, kind)
        val sp = spans(text).filter { it.kind == kind }
        val hiddenAt = Mapping(text).hiddenRanges()
        val values = (a until b).filter { p -> hiddenAt.none { p in it } }.map { p -> sp.firstOrNull { p >= it.start && p < it.end }?.value }.distinct()
        return values.singleOrNull()
    }

    /** Alignement de la ligne qui contient [pos] (null : à gauche). */
    fun alignAt(text: String, pos: Int): String? {
        val p = pos.coerceIn(0, text.length)
        val ls = text.lastIndexOf('\n', p - 1) + 1
        val le = text.indexOf('\n', p).let { if (it < 0) text.length else it }
        val line = text.substring(ls, le)
        return ALIGN.find(line)?.takeIf { it.range.last + 1 == line.length }?.groupValues?.get(1)
    }

    /** Aligne les lignes de la sélection : [align] « center », « right » ou null (à gauche). */
    fun setAlign(text: String, a0: Int, b0: Int, align: String?): Edit {
        val a = outside(text, minOf(a0, b0))
        val b = outside(text, maxOf(a0, b0))
        val s = StringBuilder(text).insert(b, S2).insert(a, S1).toString()
        val lines = s.split('\n')
        val first = text.substring(0, a).count { it == '\n' }
        val last = text.substring(0, b).count { it == '\n' }
        val out = lines.mapIndexed { i, l ->
            if (i !in first..last) l
            else {
                // Le repère est en fin de ligne (le curseur peut être juste avant)
                val clean = l.replace(Regex("\\[(?:center|right)\\]([$S1$S2]*)$"), "$1")
                if (align == null) clean else "$clean[$align]"
            }
        }.joinToString("\n")
        // Curseur juste avant le repère, jamais après
        return extract(out.replace(Regex("\\[(center|right)\\]([$S1$S2]+)(?=\\n|$)"), "$2[$1]"))
    }

    /**
     * Entrée en fin de ligne alignée : la nouvelle ligne garde l'alignement (le repère resterait sinon
     * sur la nouvelle ligne seulement). Renvoie le texte corrigé et le curseur, ou null.
     */
    fun afterEdit(old: String, new: String, cursor: Int): Pair<String, Int>? {
        if (new.length <= old.length) return null
        var p = 0
        while (p < old.length && old[p] == new[p]) p++
        val insLen = new.length - old.length
        if (new.substring(p + insLen) != old.substring(p)) return null
        val ins = new.substring(p, p + insLen)
        if ('\n' !in ins) return null
        val m = Regex("^\\[(center|right)\\](?=\\n|$)").find(old.substring(p)) ?: return null
        val tok = m.value
        val firstNl = ins.indexOf('\n')
        val fixed = old.substring(0, p) + ins.substring(0, firstNl) + tok + ins.substring(firstNl) + old.substring(p)
        return fixed to (cursor + tok.length).coerceIn(0, fixed.length)
    }

    /** Range le texte : retire les mises en forme vides, les repères sans fin ou sans début, et fusionne les voisines. */
    fun clean(text: String): String = if ('[' !in text) text else cleanup(text)

    private fun cleanup(s0: String): String {
        var s = s0
        var guard = 0
        while (guard++ < 50) {
            val before = s
            s = s.replace(Regex("\\[(c|bg)=#[0-9A-Fa-f]{6}\\]\\[/\\1\\]"), "").replace("[u][/u]", "")
            // Repères orphelins et voisines identiques
            val toks = tokens(s)
            val drop = ArrayList<Tok>()
            val open = HashMap<String, Tok>()
            var i = 0
            while (i < toks.size) {
                val t = toks[i]
                if (t.kind == "align") { i++; continue }
                if (!t.open) {
                    val o = open.remove(t.kind)
                    if (o == null) drop += t
                    else {
                        // « [/c][c=même couleur] » : on fusionne
                        val n = toks.getOrNull(i + 1)
                        if (n != null && n.open && n.kind == t.kind && n.start == t.end && n.value == o.value) {
                            drop += t; drop += n; open[t.kind] = o; i += 2; continue
                        }
                    }
                } else {
                    // Une couleur ouverte dans une autre : la première se termine là
                    val o = open[t.kind]
                    if (o != null && o.value == t.value) { drop += t; i++; continue }
                    open[t.kind] = t
                }
                i++
            }
            drop += open.values
            if (drop.isNotEmpty()) {
                val sb = StringBuilder(s)
                drop.distinct().sortedByDescending { it.start }.forEach { sb.delete(it.start, it.end) }
                s = sb.toString()
            }
            if (s == before) break
        }
        return s
    }
}
