package fr.jeremy.calepin.assistant

import fr.jeremy.calepin.data.Event
import fr.jeremy.calepin.data.Note
import fr.jeremy.calepin.detect.Entity
import fr.jeremy.calepin.detect.EntityDetector
import fr.jeremy.calepin.detect.EntityType
import java.text.Normalizer
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/** Ce que l'interface doit faire après une réponse (ouvrir une note, appeler, guider…). */
sealed interface AssistantAction {
    data class OpenNote(val id: Long) : AssistantAction
    data class Dial(val number: String) : AssistantAction
    data class Sms(val number: String) : AssistantAction
    data class Directions(val address: String) : AssistantAction
    data class Search(val query: String) : AssistantAction
    data object OpenCalendar : AssistantAction
    /** L'assistant attend une suite (contenu d'une note, heure d'un rappel…) : réécouter. */
    data object ListenAgain : AssistantAction
}

data class Reply(val text: String, val actions: List<AssistantAction> = emptyList())

/** Accès aux données de Calepin (fourni par l'appli, ou simulé dans les tests). */
interface AssistantData {
    val notes: List<Note>
    val events: List<Event>
    fun entities(n: Note): List<Entity>
    fun createNote(title: String, content: String): Long
    fun updateNote(n: Note)
    fun createEvent(e: Event): Event
    fun now(): Long = System.currentTimeMillis()
}

/**
 * Assistant hors ligne : comprend des demandes en français courant et agit dans Calepin.
 * Tout se fait sur le téléphone, instantanément, sans connexion.
 */
class Assistant(private val data: AssistantData) {

    private sealed interface Pending {
        data object NoteContent : Pending
        data class ReminderWhen(val title: String) : Pending
        data class AlarmWhen(val title: String) : Pending
    }

    private var pending: Pending? = null

    // ------------------------------------------------------------ Entrée

    fun handle(raw: String): Reply {
        val input = raw.trim().trimEnd('.', '!', '?', ' ')
        if (input.isEmpty()) return Reply("Je t'écoute.")
        val n = norm(input)

        if (Regex("""^(annule|laisse tomber|rien|stop|non merci|oublie)\b""").containsMatchIn(n)) {
            pending = null
            return Reply("D'accord, j'annule.")
        }

        // Suite d'une question précédente
        when (val p = pending) {
            Pending.NoteContent -> { pending = null; return newNote(input) }
            is Pending.ReminderWhen -> { pending = null; return reminder("${p.title} $input", forceTitle = p.title) }
            is Pending.AlarmWhen -> { pending = null; return alarm(input, p.title) }
            null -> Unit
        }

        fun m(rx: String) = Regex(rx).find(n)
        fun rest(mr: MatchResult, group: Int = mr.groupValues.lastIndex): String {
            val g = mr.groups[group] ?: return ""
            return input.substring(g.range.first, g.range.last + 1).trim()
        }

        m("""^(aide|help|que sais[ -]tu faire|tu sais faire quoi|qu'?est[ -]ce que tu sais faire|quelles commandes|commandes)\b""")?.let { return help() }
        m("""^(bonjour|salut|hello|coucou|bonsoir|hey)\b""")?.let { return Reply(greeting() + " " + briefing().text) }
        m("""^(merci|super|parfait|top|genial)\b""")?.let { return Reply("Avec plaisir !") }
        m("""\b(quelle heure|l'heure|il est quelle heure)\b""")?.let { return Reply("Il est ${hm(data.now())}.") }
        m("""\b(quel jour|quelle date|on est le combien|date d'aujourd'hui)\b""")?.let {
            return Reply("Nous sommes ${dayName(data.now(), withYear = true)}.")
        }
        m("""\b(resume|briefing|ma journee|programme du jour|bilan du jour)\b""")?.let { return briefing() }

        // Travail
        m("""\b(combien d'?heures|nombre d'heures|mes heures|total d'heures|heures de travail)\b""")?.let { return workHours(n) }
        m("""\b(prochaine? (poste|vacation|service|journee de travail|travail)|quand (est[ -]ce que )?je (travaille|bosse|reprends)|je (travaille|bosse|reprends) quand)\b""")
            ?.let { return nextShift() }
        m("""^(est[ -]ce que )?je (travaille|bosse)\b(.*)$""")?.let { return worksOn(n) }

        // Agenda
        m("""^(ouvre|affiche|montre)( moi)? (l'|le |mon )?(agenda|calendrier|planning)$""")?.let {
            return Reply("J'ouvre l'agenda.", listOf(AssistantAction.OpenCalendar))
        }
        m("""(qu'?est[ -]ce que j'?ai|j'?ai quoi|mon agenda|mon planning|mes rendez[ -]vous|mon emploi du temps|qu'?ai[ -]je|quoi de prevu|qu'?est[ -]ce qui est prevu|qu'?est[ -]ce que je fais|j'?ai des rendez[ -]vous|ai[ -]je des rendez[ -]vous)""")
            ?.let { return agenda(n) }

        // Rappels, alarmes, rendez-vous
        m("""^(rappelle[ -]moi|rappelles[ -]moi|fais[ -]moi penser|pense a me rappeler|n'?oublie pas de me rappeler|rappel)\s*(.*)$""")
            ?.let { return reminder(rest(it)) }
        m("""^(reveille[ -]moi|(mets|met|regle|programme|ajoute)( moi)?( une| un| l'| le)? ?(alarme|reveil))\s*(.*)$""")
            ?.let { return alarm(rest(it)) }
        m("""^((ajoute|cree|programme|planifie|note|mets|prends|fixe)( moi)?( un| une)? )?(rendez[ -]vous|rdv|reunion|evenement|rencard)\s*(.*)$""")
            ?.let { return newEvent(rest(it)) }

        // Communication et déplacements
        m("""^(envoie|envoies|ecris|envoyer|ecrire)( un| une)? (sms|texto|message) (a |au |aux )?(.+)$""")?.let { return sms(rest(it)) }
        m("""^(sms|texto|message)\s+(a |au |aux |pour )?(.+)$""")?.let { return sms(rest(it)) }
        m("""^(appelle|appelles|appeler|telephone a|telephoner a|telephone au|compose le numero de)\s+(.+)$""")?.let { return call(rest(it)) }
        m("""^(emmene[ -]moi|guide[ -]moi|conduis[ -]moi|itineraire|route|aller|je veux aller|je vais|navigation|direction)\s*(a |au |aux |vers |jusqu'?a |chez |pour |a la |a l')?(.+)$""")
            ?.let { return directions(rest(it)) }

        // Notes
        m("""^ajoute (.+?) (a|dans) (la |ma |mes )?(note|liste|notes) (de |des |du |d')?(.+)$""")?.let {
            return appendTo(rest(it, 6), rest(it, 1))
        }
        m("""^ajoute (a|dans) (la |ma )?(note|liste) (de |des |du |d')?(.+?)\s*:\s*(.+)$""")?.let {
            return appendTo(rest(it, 5), rest(it, 6))
        }
        m("""^(lis|lire|relis|lit)([ -]moi)?\s+(la note |ma note |la liste |ma liste |les notes |le contenu de )?(.+)$""")?.let { return readNote(rest(it)) }
        m("""^(ouvre|affiche|montre)([ -]moi)?\s+(la note |ma note |la liste |ma liste )?(.+)$""")?.let { return openNote(rest(it)) }
        m("""^(nouvelle note|cree une note|creer une note|prends note|prend note|note|ecris une note|ecris|dicte une note|dicter une note|memo)\s*(que |de |d'|: |, )?(.*)$""")
            ?.let { return newNote(rest(it)) }
        m("""^(cherche|recherche|trouve|retrouve)([ -]moi)?\s+(.+)$""")?.let { return search(rest(it)) }

        // Rien de reconnu : on tente une recherche dans les notes
        val hits = find(input)
        return if (hits.isNotEmpty()) {
            Reply(
                "Je n'ai pas compris la demande, mais j'ai trouvé ${plural(hits.size, "note")} qui en parle : " +
                    hits.take(3).joinToString(", ") { "« ${it.title.ifBlank { "Sans titre" }} »" } + ".",
                listOf(AssistantAction.Search(input)),
            )
        } else {
            Reply("Je n'ai pas compris. Dis « aide » pour voir ce que je sais faire.")
        }
    }

    // ------------------------------------------------------------ Réponses

    private fun help() = Reply(
        """Voici ce que je sais faire, à l'écrit ou à la voix :
• « Note : acheter du pain » ou « nouvelle note » puis dicte le contenu
• « Ajoute du lait à la liste de courses »
• « Rendez-vous chez le dentiste jeudi à 14h30 »
• « Rappelle-moi d'appeler le plombier dans 20 minutes »
• « Réveille-moi demain à 6h »
• « Qu'est-ce que j'ai demain ? », « Mon planning cette semaine »
• « Quand est-ce que je travaille ? », « Combien d'heures ce mois-ci ? »
• « Appelle Rossi », « SMS à Rossi », « Emmène-moi au Consulat d'Italie »
• « Cherche plombier », « Lis la note courses »
• « Résumé de ma journée », « Quelle heure est-il ? »""",
    )

    private fun greeting(): String {
        val h = Calendar.getInstance().apply { timeInMillis = data.now() }.get(Calendar.HOUR_OF_DAY)
        return if (h < 18) "Bonjour !" else "Bonsoir !"
    }

    /** Résumé : rendez-vous du jour, prochaine vacation, rappels. */
    fun briefing(): Reply {
        val (s, e) = dayRange(data.now(), 0)
        val today = eventsIn(s, e)
        val sb = StringBuilder()
        if (today.isEmpty()) sb.append("Rien de prévu aujourd'hui.")
        else sb.append("Aujourd'hui : ").append(today.joinToString(" ; ") { describe(it, withDay = false) }).append('.')
        val next = data.events.filter { it.isWork && it.start > data.now() && it.start >= e }.minByOrNull { it.start }
        if (next != null) sb.append(" Prochaine vacation : ").append(describe(next, withDay = true)).append('.')
        val (tS, tE) = dayRange(data.now(), 1)
        val tomorrow = eventsIn(tS, tE)
        if (tomorrow.isNotEmpty()) sb.append(" Demain : ").append(tomorrow.joinToString(" ; ") { describe(it, withDay = false) }).append('.')
        return Reply(sb.toString())
    }

    private fun agenda(n: String): Reply {
        val r = rangeFrom(n, default = Unit.let { dayRange(data.now(), 0) + "aujourd'hui" })
        val list = eventsIn(r.first, r.second)
        if (list.isEmpty()) return Reply("Rien de prévu ${r.third}.", listOf(AssistantAction.OpenCalendar))
        val multiDay = r.second - r.first > 86_400_000L
        return Reply(
            "${r.third.replaceFirstChar { it.uppercase() }}, ${plural(list.size, "élément")} : " +
                list.joinToString(" ; ") { describe(it, withDay = multiDay) } + ".",
            listOf(AssistantAction.OpenCalendar),
        )
    }

    private fun worksOn(n: String): Reply {
        val r = rangeFrom(n, default = dayRange(data.now(), 0) + "aujourd'hui")
        val list = eventsIn(r.first, r.second).filter { it.isWork }
        if (list.isEmpty()) return Reply("Non, tu ne travailles pas ${r.third}.")
        return Reply("Oui, ${r.third} : " + list.joinToString(" ; ") { describe(it, withDay = r.second - r.first > 86_400_000L) } + ".")
    }

    private fun nextShift(): Reply {
        val now = data.now()
        val current = data.events.firstOrNull { it.isWork && it.start <= now && it.end > now }
        val next = data.events.filter { it.isWork && it.start > now }.minByOrNull { it.start }
        return when {
            current != null && next != null ->
                Reply("Tu es en poste jusqu'à ${hm(current.end)}. Ensuite : ${describe(next, withDay = true)}.")
            current != null -> Reply("Tu es en poste jusqu'à ${hm(current.end)}.")
            next != null -> Reply("Ta prochaine vacation : ${describe(next, withDay = true)}.")
            else -> Reply("Je ne trouve aucune vacation à venir. Importe ton planning depuis l'agenda.", listOf(AssistantAction.OpenCalendar))
        }
    }

    private fun workHours(n: String): Reply {
        val r = rangeFrom(n, default = monthRange(data.now(), 0) + "ce mois-ci")
        val list = data.events.filter { it.isWork && it.end > it.start && it.start >= r.first && it.start < r.second }
        if (list.isEmpty()) return Reply("Aucune vacation ${r.third}.")
        val minutes = list.sumOf { (it.end - it.start) / 60_000L }
        val h = minutes / 60; val mn = minutes % 60
        return Reply(
            "${r.third.replaceFirstChar { it.uppercase() }} : $h h" + (if (mn > 0) " ${"%02d".format(mn)}" else "") +
                " de travail, en ${plural(list.size, "vacation")}.",
        )
    }

    private fun newNote(text: String): Reply {
        if (text.isBlank()) {
            pending = Pending.NoteContent
            return Reply("Je t'écoute : que dois-je noter ?", listOf(AssistantAction.ListenAgain))
        }
        val clean = text.trim().replaceFirstChar { it.uppercase() }
        val title = clean.split(Regex("""\s+""")).take(6).joinToString(" ").trimEnd(',', '.', ':', ';').take(50)
        val id = data.createNote(title, clean)
        return Reply("C'est noté : « $title ».", listOf(AssistantAction.OpenNote(id)))
    }

    private fun appendTo(target: String, what: String): Reply {
        val note = bestNote(target)
        val item = what.trim().replaceFirstChar { it.uppercase() }
        if (note == null) {
            val title = target.trim().replaceFirstChar { it.uppercase() }
            val id = data.createNote(title, "- $item")
            return Reply("J'ai créé la note « $title » avec « $item ».", listOf(AssistantAction.OpenNote(id)))
        }
        val sep = if (note.content.isEmpty() || note.content.endsWith("\n")) "" else "\n"
        data.updateNote(note.copy(content = note.content + sep + "- " + item, updatedAt = data.now()))
        return Reply("Ajouté à « ${note.title.ifBlank { "Sans titre" }} » : $item.")
    }

    private fun readNote(target: String): Reply {
        val note = bestNote(target) ?: return Reply("Je ne trouve pas de note « $target ».", listOf(AssistantAction.Search(target)))
        val body = note.content.ifBlank { "La note est vide." }
        return Reply("${note.title.ifBlank { "Sans titre" }}. $body", listOf(AssistantAction.OpenNote(note.id)))
    }

    private fun openNote(target: String): Reply {
        val note = bestNote(target) ?: return Reply("Je ne trouve pas de note « $target ».", listOf(AssistantAction.Search(target)))
        return Reply("J'ouvre « ${note.title.ifBlank { "Sans titre" }} ».", listOf(AssistantAction.OpenNote(note.id)))
    }

    private fun search(q: String): Reply {
        val hits = find(q)
        if (hits.isEmpty()) return Reply("Aucune note ne parle de « $q ».")
        return Reply(
            "${plural(hits.size, "note")} pour « $q » : " + hits.take(5).joinToString(", ") { "« ${it.title.ifBlank { "Sans titre" }} »" } + ".",
            listOf(AssistantAction.Search(q)),
        )
    }

    private fun call(who: String): Reply {
        val (num, label) = findEntity(who, EntityType.PHONE) ?: return Reply("Je n'ai pas trouvé de numéro pour « $who » dans tes notes.")
        return Reply("J'appelle $label.", listOf(AssistantAction.Dial(num)))
    }

    private fun sms(who: String): Reply {
        val (num, label) = findEntity(who, EntityType.PHONE) ?: return Reply("Je n'ai pas trouvé de numéro pour « $who » dans tes notes.")
        return Reply("J'ouvre un SMS pour $label.", listOf(AssistantAction.Sms(num)))
    }

    private fun directions(where: String): Reply {
        findEntity(where, EntityType.ADDRESS)?.let { (addr, label) ->
            return Reply("C'est parti pour $label.", listOf(AssistantAction.Directions(addr)))
        }
        // Pas dans les notes : on prend ce qui a été dit comme adresse
        return Reply("Je lance l'itinéraire vers « $where ».", listOf(AssistantAction.Directions(where)))
    }

    // --------------------------------------------- Rendez-vous, rappels

    private data class When(val start: Long, val hasTime: Boolean, val consumed: List<IntRange>)

    /** Cherche une date/heure dans un texte : « demain à 14h », « jeudi 15 octobre », « dans 20 minutes », « à 18h », « ce soir ». */
    private fun parseWhen(text: String): When? {
        val n = norm(text)
        val now = data.now()
        Regex("""\bdans (\d+|un|une|deux|trois|quatre|cinq|dix|quinze|vingt|trente) ?(minutes?|mn|min|heures?|h|jours?)\b""").find(n)?.let { m ->
            val k = when (val w = m.groupValues[1]) {
                "un", "une" -> 1; "deux" -> 2; "trois" -> 3; "quatre" -> 4; "cinq" -> 5; "dix" -> 10
                "quinze" -> 15; "vingt" -> 20; "trente" -> 30; else -> w.toInt()
            }
            val unit = m.groupValues[2]
            val ms = when {
                unit.startsWith("j") -> k * 86_400_000L
                unit.startsWith("h") -> k * 3_600_000L
                else -> k * 60_000L
            }
            return When(now + ms, true, listOf(m.range))
        }
        val consumed = mutableListOf<IntRange>()
        var date: Entity? = EntityDetector.detect(text).firstOrNull { it.type == EntityType.DATE && it.timeMillis != null }
        date?.let { consumed += it.start until it.end }
        var hour: Int? = null; var minute = 0
        if (date == null || !date.hasTime) {
            Regex("""\b(a|vers|pour|des)? ?(\d{1,2}) ?(h|heures?|:) ?(\d{2})?\b""").findAll(n).firstOrNull { mm ->
                consumed.none { r -> mm.range.first in r } && mm.groupValues[2].toInt() in 0..23
            }?.let { mm ->
                hour = mm.groupValues[2].toInt(); minute = mm.groupValues[4].toIntOrNull() ?: 0
                consumed += mm.range
            }
            if (hour == null) {
                Regex("""\b(ce |demain |le |dans la )?(matin|midi|apres[ -]midi|aprem|soir|soiree)\b""").find(n)?.let { mm ->
                    hour = when (mm.groupValues[2]) {
                        "matin" -> 9; "midi" -> 12; "soir", "soiree" -> 19; else -> 14
                    }
                    consumed += mm.range
                    if (mm.groupValues[1].trim() == "demain" && date == null) {
                        date = Entity(EntityType.DATE, mm.range.first, mm.range.last, "demain", "", dayRange(now, 1).first, false)
                    }
                }
            }
        }
        val d = date
        if (d == null && hour == null) return null
        val c = Calendar.getInstance().apply { timeInMillis = d?.timeMillis ?: now }
        if (hour != null) {
            c.set(Calendar.HOUR_OF_DAY, hour!!); c.set(Calendar.MINUTE, minute); c.set(Calendar.SECOND, 0); c.set(Calendar.MILLISECOND, 0)
            if (d == null && c.timeInMillis <= now) c.add(Calendar.DAY_OF_YEAR, 1) // « à 7h » déjà passé : demain
        }
        return When(c.timeInMillis, d?.hasTime == true || hour != null, consumed)
    }

    /** Texte restant une fois la date/heure retirée, nettoyé pour servir de titre. */
    private fun titleFrom(text: String, w: When?): String {
        var t = text
        w?.consumed?.sortedByDescending { it.first }?.forEach { r ->
            if (r.first < t.length) t = t.removeRange(r.first, minOf(r.last + 1, t.length))
        }
        t = t.replace(Regex("""\s+"""), " ").trim().trim(',', '.', ':', ';', '-').trim()
        // Mots de liaison en début / fin : « d'appeler », « de payer », « que », « pour »
        repeat(3) {
            t = t.replace(Regex("""^(?i)(de |d'|d’|que |qu'|pour |le |la |les |à |a |au |un |une |:)\s*"""), "")
            t = t.replace(Regex("""(?i)\s+(le|la|à|a|au|de|pour|ce|cet|cette|et|dans|demain)$"""), "")
        }
        return t.trim().replaceFirstChar { it.uppercase() }
    }

    private fun reminder(text: String, forceTitle: String? = null): Reply {
        val w = parseWhen(text)
        val title = forceTitle ?: titleFrom(text, w).ifBlank { "Rappel" }
        if (w == null) {
            pending = Pending.ReminderWhen(title)
            return Reply("Quand dois-je te rappeler « $title » ?", listOf(AssistantAction.ListenAgain))
        }
        val start = if (w.hasTime) w.start else Calendar.getInstance().apply {
            timeInMillis = w.start; set(Calendar.HOUR_OF_DAY, 9); set(Calendar.MINUTE, 0)
        }.timeInMillis
        val e = data.createEvent(Event(title = title, start = start, remindMinutes = 0, alarm = false))
        return Reply("D'accord, je te rappelle « ${e.title} » ${whenText(e.start)}.")
    }

    private fun alarm(text: String, forceTitle: String? = null): Reply {
        val w = parseWhen(text)
        val title = forceTitle ?: titleFrom(text, w).ifBlank { "Réveil" }
        if (w == null || !w.hasTime) {
            pending = Pending.AlarmWhen(title)
            return Reply("À quelle heure ?", listOf(AssistantAction.ListenAgain))
        }
        val e = data.createEvent(Event(title = title, start = w.start, remindMinutes = 0, alarm = true))
        return Reply("Alarme réglée ${whenText(e.start)}.")
    }

    private fun newEvent(text: String): Reply {
        val w = parseWhen(text)
        val t0 = titleFrom(text, w)
        // « chez le dentiste », « avec Rossi » → « Rendez-vous chez le dentiste »
        val title = when {
            t0.isBlank() -> "Rendez-vous"
            Regex("""^(?i)(chez|avec|au|à la|a la)\b""").containsMatchIn(t0) -> "Rendez-vous " + t0.replaceFirstChar { it.lowercase() }
            else -> t0
        }
        if (w == null) {
            val e = data.createEvent(Event(title = title, start = dayRange(data.now(), 1).first, allDay = true))
            return Reply("J'ai ajouté « ${e.title} » demain dans l'agenda. Précise la date si besoin.", listOf(AssistantAction.OpenCalendar))
        }
        val e = data.createEvent(
            Event(title = title, start = w.start, allDay = !w.hasTime, remindMinutes = if (w.hasTime) 15 else -540)
        )
        return Reply(
            "« ${e.title} » ajouté à l'agenda ${whenText(e.start, e.allDay)}, avec un rappel" +
                (if (w.hasTime) " 15 minutes avant." else " le matin même."),
        )
    }

    // -------------------------------------------------------------- Outils

    private fun eventsIn(s: Long, e: Long): List<Event> = data.events.filter { ev ->
        val end = if (ev.end > ev.start) ev.end else ev.start + 1
        ev.start < e && end > s
    }.sortedBy { it.start }

    private fun describe(e: Event, withDay: Boolean): String {
        val day = if (withDay) dayName(e.start) + " " else ""
        val time = when {
            e.allDay && e.isPeriod -> "du ${dayName(e.start)} au ${dayName(e.end)}"
            e.allDay -> "toute la journée"
            e.end > e.start -> "de ${hm(e.start)} à ${hm(e.end)}"
            else -> "à ${hm(e.start)}"
        }
        return (if (e.allDay && e.isPeriod) "" else day) + time + " : " + e.title
    }

    private fun whenText(t: Long, allDay: Boolean = false): String {
        val (s, _) = dayRange(data.now(), 0)
        val day = when ((t - s).floorDiv(86_400_000L)) {
            0L -> "aujourd'hui"; 1L -> "demain"; 2L -> "après-demain"; else -> dayName(t)
        }
        return if (allDay) day else "$day à ${hm(t)}"
    }

    /** « 6 h 30 », « 14 h » : se lit bien à voix haute. */
    private fun hm(t: Long): String {
        val c = Calendar.getInstance().apply { timeInMillis = t }
        val h = c.get(Calendar.HOUR_OF_DAY); val m = c.get(Calendar.MINUTE)
        return when {
            h == 0 && m == 0 -> "minuit"
            h == 12 && m == 0 -> "midi"
            m == 0 -> "$h h"
            else -> "$h h ${"%02d".format(m)}"
        }
    }

    private fun dayName(t: Long, withYear: Boolean = false): String =
        SimpleDateFormat(if (withYear) "EEEE d MMMM yyyy" else "EEEE d MMMM", Locale.FRANCE).format(Date(t))

    private fun dayRange(now: Long, plusDays: Int): Pair<Long, Long> {
        val c = Calendar.getInstance().apply {
            timeInMillis = now; add(Calendar.DAY_OF_YEAR, plusDays)
            set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
        }
        val s = c.timeInMillis
        c.add(Calendar.DAY_OF_YEAR, 1)
        return s to c.timeInMillis
    }

    private fun monthRange(now: Long, plusMonths: Int, month: Int? = null): Pair<Long, Long> {
        val c = Calendar.getInstance().apply {
            timeInMillis = now
            if (month != null) { if (month < get(Calendar.MONTH) - 2) add(Calendar.YEAR, 1); set(Calendar.MONTH, month) }
            add(Calendar.MONTH, plusMonths)
            set(Calendar.DAY_OF_MONTH, 1)
            set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
        }
        val s = c.timeInMillis
        c.add(Calendar.MONTH, 1)
        return s to c.timeInMillis
    }

    private operator fun Pair<Long, Long>.plus(label: String) = Triple(first, second, label)

    private val MONTHS = listOf("janvier", "fevrier", "mars", "avril", "mai", "juin", "juillet", "aout", "septembre", "octobre", "novembre", "decembre")
    private val WEEKDAYS = listOf("dimanche", "lundi", "mardi", "mercredi", "jeudi", "vendredi", "samedi")

    /** Période évoquée dans la phrase (aujourd'hui, demain, cette semaine, en octobre, jeudi, le 14 octobre…). */
    private fun rangeFrom(n: String, default: Triple<Long, Long, String>): Triple<Long, Long, String> {
        val now = data.now()
        when {
            Regex("""\bapres[ -]demain\b""").containsMatchIn(n) -> return dayRange(now, 2) + "après-demain"
            Regex("""\bdemain\b""").containsMatchIn(n) -> return dayRange(now, 1) + "demain"
            Regex("""\b(aujourd'hui|ce jour|ce matin|ce soir|cet apres[ -]midi)\b""").containsMatchIn(n) -> return dayRange(now, 0) + "aujourd'hui"
            Regex("""\bsemaine prochaine\b""").containsMatchIn(n) -> {
                val (s, _) = weekRange(now, 1); return s + "la semaine prochaine"
            }
            Regex("""\b(cette semaine|la semaine)\b""").containsMatchIn(n) -> {
                val (s, _) = weekRange(now, 0); return s + "cette semaine"
            }
            Regex("""\bmois prochain\b""").containsMatchIn(n) -> return monthRange(now, 1) + "le mois prochain"
            Regex("""\b(ce mois|du mois|le mois)\b""").containsMatchIn(n) -> return monthRange(now, 0) + "ce mois-ci"
        }
        Regex("""\b(en |au mois d'|au mois de |pour |de )?(""" + MONTHS.joinToString("|") + """)\b(?! *\d)""").find(n)?.let { mm ->
            if (!Regex("""\d+ +${mm.groupValues[2]}""").containsMatchIn(n)) {
                val idx = MONTHS.indexOf(mm.groupValues[2])
                return monthRange(now, 0, idx) + "en ${mm.groupValues[2]}"
            }
        }
        EntityDetector.detect(n).firstOrNull { it.type == EntityType.DATE && it.timeMillis != null }?.let { d ->
            val (s, _) = dayRange(d.timeMillis!!, 0)
            val e = d.endMillis?.let { dayRange(it, 1).first } ?: dayRange(d.timeMillis, 1).first
            return Triple(s, e, if (d.endMillis != null) d.value.replaceFirstChar { it.lowercase() } else "le " + dayName(d.timeMillis))
        }
        Regex("""\b(""" + WEEKDAYS.joinToString("|") + """)\b""").find(n)?.let { mm ->
            val target = WEEKDAYS.indexOf(mm.value) + 1 // Calendar.SUNDAY = 1
            val c = Calendar.getInstance().apply { timeInMillis = now }
            val diff = (target - c.get(Calendar.DAY_OF_WEEK) + 7) % 7
            return dayRange(now, diff) + (if (diff == 0) "aujourd'hui" else mm.value)
        }
        return default
    }

    /** Du lundi au dimanche (semaine courante ou suivante) ; la semaine courante démarre aujourd'hui. */
    private fun weekRange(now: Long, plusWeeks: Int): Pair<Pair<Long, Long>, Unit> {
        val c = Calendar.getInstance().apply {
            timeInMillis = now
            set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
        }
        val dow = (c.get(Calendar.DAY_OF_WEEK) + 5) % 7 // lundi = 0
        val monday = (c.clone() as Calendar).apply { add(Calendar.DAY_OF_YEAR, -dow + 7 * plusWeeks) }
        val start = if (plusWeeks == 0) c.timeInMillis else monday.timeInMillis
        val end = (monday.clone() as Calendar).apply { add(Calendar.DAY_OF_YEAR, 7) }.timeInMillis
        return (start to end) to Unit
    }

    private fun plural(n: Int, word: String) = "$n $word" + if (n > 1) "s" else ""

    /** Notes qui contiennent tous les mots importants de la requête. */
    private fun find(q: String): List<Note> {
        val words = keywords(q)
        if (words.isEmpty()) return emptyList()
        return data.notes.filter { n ->
            val hay = norm(n.title + " " + n.content + " " + n.tag)
            words.all { hay.contains(it) }
        }.sortedByDescending { n -> words.count { norm(n.title).contains(it) } }
    }

    /** Note dont le titre correspond le mieux (« courses » → « Liste de courses »). */
    private fun bestNote(q: String): Note? {
        val words = keywords(q)
        if (words.isEmpty()) return null
        return data.notes.map { n ->
            val t = norm(n.title)
            val score = words.count { t.contains(it) } * 3 + words.count { norm(n.content).contains(it) }
            n to score
        }.filter { it.second > 0 }.maxByOrNull { it.second }?.first
    }

    /**
     * Numéro ou adresse associé à un nom : d'abord sur la même ligne que le nom,
     * puis dans une note dont le titre contient le nom.
     */
    private fun findEntity(who: String, type: EntityType): Pair<String, String>? {
        val words = keywords(who)
        if (words.isEmpty()) return null
        for (n in data.notes) {
            val ents = data.entities(n).filter { it.type == type }
            if (ents.isEmpty()) continue
            var lineStart = 0
            for (line in n.content.split('\n')) {
                val lineEnd = lineStart + line.length
                if (words.all { norm(line).contains(it) }) {
                    ents.firstOrNull { it.start >= lineStart && it.start <= lineEnd }?.let { e ->
                        return (if (type == EntityType.PHONE) e.value else e.value) to who.trim()
                    }
                }
                lineStart = lineEnd + 1
            }
        }
        val byTitle = data.notes.filter { n -> words.all { norm(n.title).contains(it) } }
        for (n in byTitle) {
            data.entities(n).firstOrNull { it.type == type }?.let { return it.value to who.trim() }
        }
        // Le nom n'est que dans le texte : premier élément de la note
        for (n in data.notes.filter { n -> words.all { norm(n.content).contains(it) } }) {
            data.entities(n).firstOrNull { it.type == type }?.let { return it.value to who.trim() }
        }
        return null
    }

    private val STOP = setOf(
        "le", "la", "les", "l", "un", "une", "des", "de", "du", "d", "a", "au", "aux", "et", "ou", "en", "mon", "ma", "mes",
        "monsieur", "madame", "m", "mme", "mr", "note", "notes", "liste", "chez", "pour", "sur", "dans", "moi", "the",
    )

    private fun keywords(q: String): List<String> =
        norm(q).split(Regex("""[^a-z0-9]+""")).filter { it.length >= 2 && it !in STOP }

    companion object {
        /** Minuscules sans accents, de même longueur que le texte d'origine (les positions correspondent). */
        fun norm(s: String): String = buildString(s.length) {
            for (ch in s) {
                val c = when (ch) {
                    'œ', 'Œ' -> 'o'; 'æ', 'Æ' -> 'a'; '’', '‘', '`' -> '\''; ' ' -> ' '
                    else -> Normalizer.normalize(ch.toString(), Normalizer.Form.NFD).firstOrNull() ?: ch
                }
                append(c.lowercaseChar())
            }
        }
    }
}
