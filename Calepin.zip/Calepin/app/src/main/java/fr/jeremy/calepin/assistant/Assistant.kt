package fr.jeremy.calepin.assistant

import fr.jeremy.calepin.data.Event
import fr.jeremy.calepin.data.Note
import fr.jeremy.calepin.detect.Entity
import fr.jeremy.calepin.detect.EntityDetector
import fr.jeremy.calepin.detect.EntityType
import java.text.Normalizer
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import fr.jeremy.calepin.i18n.AppLanguage
import fr.jeremy.calepin.i18n.I18n

/** Texte de réponse dans la langue de l'appli (le français reste la langue de référence). */
private fun T(s: String) = I18n.tr(s)
private fun F(key: String, vararg a: Any?) = I18n.trf(key, *a)

/** Ce que l'interface doit faire après une réponse (ouvrir une note, appeler, guider…). */
sealed interface AssistantAction {
    data class OpenNote(val id: Long) : AssistantAction
    data class Dial(val number: String) : AssistantAction
    data class Sms(val number: String) : AssistantAction
    data class Directions(val address: String) : AssistantAction
    data class Search(val query: String) : AssistantAction
    data object OpenCalendar : AssistantAction
    /** Ajout à l'agenda du téléphone (Google Agenda…) : tout de suite si [auto], sinon proposé en bouton. */
    data class PhoneCalendar(val title: String, val start: Long, val end: Long, val allDay: Boolean, val auto: Boolean) : AssistantAction
    /** L'assistant attend une suite (contenu d'une note, heure d'un rappel…) : réécouter. */
    data object ListenAgain : AssistantAction
}

/** [understood] = faux quand aucune commande n'a été reconnue (Calepin IA passe alors la main au modèle). */
data class Reply(val text: String, val actions: List<AssistantAction> = emptyList(), val understood: Boolean = true)

/** Un contact du téléphone : nom, numéros (numéro, étiquette « Mobile »…) et adresses. */
data class AssistantContact(
    val name: String,
    val phones: List<Pair<String, String>>,
    val addresses: List<String> = emptyList(),
)

/** Accès aux données de Calepin (fourni par l'appli, ou simulé dans les tests). */
interface AssistantData {
    val notes: List<Note>
    val events: List<Event>
    fun entities(n: Note): List<Entity>
    fun createNote(title: String, content: String): Long
    fun updateNote(n: Note)
    fun createEvent(e: Event): Event
    fun now(): Long = System.currentTimeMillis()
    /** Contacts du téléphone (vide si l'accès n'est pas autorisé). */
    val contacts: List<AssistantContact> get() = emptyList()
    val contactsAllowed: Boolean get() = true
}

/**
 * Assistant hors ligne : comprend des demandes en français courant et agit dans Calepin.
 * Tout se fait sur le téléphone, instantanément, sans connexion.
 */
class Assistant(private val data: AssistantData) {

    private sealed interface Pending {
        data object NoteContent : Pending
        data class ReminderWhen(val title: String) : Pending
        data class AlarmWhen(val title: String) : Pending
        data class EventWhen(val title: String, val askWhat: Boolean = false) : Pending
        data class ChooseContact(val kind: Kind, val candidates: List<AssistantContact>, val pref: PhonePref?) : Pending
    }

    private enum class Kind { CALL, SMS, ROUTE }
    private enum class PhonePref { MOBILE, HOME, WORK }

    private var pending: Pending? = null

    /** Vrai quand l'assistant attend une suite (contenu d'une note, heure d'un rappel…). */
    val isWaiting: Boolean get() = pending != null

    /** Vrai quand la suite attendue est un texte libre (contenu d'une note), à garder tel quel dans toutes les langues. */
    val waitingForText: Boolean get() = pending == Pending.NoteContent

    // ------------------------------------------------------------ Entrée

    fun handle(raw: String): Reply {
        val input = raw.trim().trimEnd('.', '!', '?', ' ')
        if (input.isEmpty()) return Reply(T("Je t'écoute."))
        val n = norm(input)

        if (Regex("""^(annule|laisse tomber|rien|stop|non merci|oublie)\b""").containsMatchIn(n)) {
            pending = null
            return Reply(T("D'accord, j'annule."))
        }

        // Suite d'une question précédente
        when (val p = pending) {
            Pending.NoteContent -> { pending = null; return newNote(input) }
            is Pending.ReminderWhen -> { pending = null; return reminder("${p.title} $input", forceTitle = p.title) }
            is Pending.AlarmWhen -> { pending = null; return alarm(input, p.title) }
            is Pending.EventWhen -> {
                pending = null
                // Sinon : nouvelle demande, traitée normalement
                if (parseWhen(input) != null) {
                    return if (p.askWhat) newEvent(input) else newEvent("${p.title} $input", forceTitle = p.title)
                }
            }
            is Pending.ChooseContact -> {
                pending = null
                pickCandidate(input, p.candidates)?.let { return contactAction(p.kind, it, p.pref) }
            }
            null -> Unit
        }

        fun m(rx: String) = Regex(rx).find(n)
        fun rest(mr: MatchResult, group: Int = mr.groupValues.lastIndex): String {
            val g = mr.groups[group] ?: return ""
            return input.substring(g.range.first, g.range.last + 1).trim()
        }

        m("""^(aide|help|que sais[ -]tu faire|tu sais faire quoi|qu'?est[ -]ce que tu sais faire|quelles commandes|commandes)\b""")?.let { return help() }
        m("""^(bonjour|salut|hello|coucou|bonsoir|hey)\b""")?.let { return Reply(greeting() + " " + briefing().text) }
        m("""^(merci|super|parfait|top|genial)\b""")?.let { return Reply(T("Avec plaisir !")) }
        m("""\b(quelle heure|l'heure|il est quelle heure)\b""")?.let { return Reply(F("Il est {0}.", hm(data.now()))) }
        m("""\b(quel jour|quelle date|on est le combien|date d'aujourd'hui)\b""")?.let {
            return Reply(F("Nous sommes {0}.", dayName(data.now(), withYear = true)))
        }
        m("""\b(resume|briefing|ma journee|programme du jour|bilan du jour)\b""")?.let { return briefing() }

        // Travail
        m("""\b(combien d'?heures|nombre d'heures|mes heures|total d'heures|heures de travail)\b""")?.let { return workHours(n) }
        m("""\b(prochaine? (poste|vacation|service|journee de travail|travail)|quand (est[ -]ce que )?je (travaille|bosse|reprends)|je (travaille|bosse|reprends) quand)\b""")
            ?.let { return nextShift() }
        m("""^(est[ -]ce que )?je (travaille|bosse)\b(.*)$""")?.let { return worksOn(n) }

        // Ajouts à l'agenda : « Ajoute au calendrier… », « J'ai rendez-vous… », « Je suis en congés du… »
        calendarRequest(input, n)?.let { return it }
        m("""^j'?ai (un |une )?(rendez[ -]vous|rdv|reunion|rencard|entretien|visite|consultation)\b\s*(.*)$""")?.let {
            return newEvent(rest(it, 3), prefix = eventWord(rest(it, 2)))
        }
        m("""^(je suis |je serai |je vais etre |je pars |je prends |je pose |pose |poser )?(en )?(mes |des |un |une )?(conges?|vacances|repos|arret maladie|arret|formation|deplacement|recup|rtt|seminaire)\b""")?.let { mm ->
            val w = parseWhen(input)
            if (w != null) {
                val word = input.substring(mm.groups[4]!!.range.first, mm.groups[4]!!.range.last + 1)
                return newEvent(input, forceTitle = word.replaceFirstChar { it.uppercase() })
            }
        }

        // Agenda
        m("""^(ouvre|affiche|montre)( moi)? (l'|le |mon )?(agenda|calendrier|planning)$""")?.let {
            return Reply(T("J'ouvre l'agenda."), listOf(AssistantAction.OpenCalendar))
        }
        m("""(qu'?est[ -]ce que j'?ai|j'?ai quoi|mon agenda|mon planning|mes rendez[ -]vous|mon emploi du temps|qu'?ai[ -]je|quoi de prevu|qu'?est[ -]ce qui est prevu|qu'?est[ -]ce que je fais|j'?ai des rendez[ -]vous|ai[ -]je des rendez[ -]vous)""")
            ?.let { return agenda(n) }

        // Rappels, alarmes, rendez-vous
        m("""^(rappelle[ -]moi|rappelles[ -]moi|fais[ -]moi penser|pense a me rappeler|n'?oublie pas de me rappeler|rappel)\s*(.*)$""")
            ?.let { return reminder(rest(it)) }
        m("""^(reveille[ -]moi|(mets|met|regle|programme|ajoute)( moi)?( une| un| l'| le)? ?(alarme|reveil))\s*(.*)$""")
            ?.let { return alarm(rest(it)) }
        m("""^((ajoute|cree|programme|planifie|note|mets|prends|fixe)( moi)?( un| une)? )?(rendez[ -]vous|rdv|reunion|evenement|rencard)\s*(.*)$""")
            ?.let { return newEvent(rest(it, 6), prefix = eventWord(rest(it, 5))) }

        // Communication et déplacements
        m("""^(envoie|envoies|ecris|envoyer|ecrire)( un| une)? (sms|texto|message) (a |au |aux )?(.+)$""")?.let { return sms(rest(it)) }
        m("""^(sms|texto|message)\s+(a |au |aux |pour )?(.+)$""")?.let { return sms(rest(it)) }
        m("""^(appelle|appelles|appeler|appel|telephone a|telephoner a|telephone au|telephone|compose le numero de|compose le|compose|joins|joindre|passe[ -]moi|passe un coup de fil a|fais un appel a)\s+(.+)$""")?.let { return call(rest(it)) }
        m("""^(emmene[ -]moi|guide[ -]moi|conduis[ -]moi|itineraire|route|aller|je veux aller|je vais|navigation|direction)\s*(a |au |aux |vers |jusqu'?a |chez |pour |a la |a l')?(.+)$""")
            ?.let { return directions(rest(it)) }

        // Notes
        m("""^ajoute (.+?) (a|dans) (la |ma |mes )?(note|liste|notes) (de |des |du |d')?(.+)$""")?.let {
            return appendTo(rest(it, 6), rest(it, 1))
        }
        m("""^ajoute (a|dans) (la |ma )?(note|liste) (de |des |du |d')?(.+?)\s*:\s*(.+)$""")?.let {
            return appendTo(rest(it, 5), rest(it, 6))
        }
        m("""^(lis|lire|relis|lit)([ -]moi)?\s+(la note |ma note |la liste |ma liste |les notes |le contenu de )?(.+)$""")?.let { return readNote(rest(it)) }
        m("""^(ouvre|affiche|montre)([ -]moi)?\s+(la note |ma note |la liste |ma liste )?(.+)$""")?.let { return openNote(rest(it)) }
        m("""^(nouvelle note|cree une note|creer une note|prends note|prend note|note|ecris une note|ecris|dicte une note|dicter une note|memo)\s*(que |de |d'|: |, )?(.*)$""")
            ?.let { return newNote(rest(it)) }
        m("""^(cherche|recherche|trouve|retrouve)([ -]moi)?\s+(.+)$""")?.let { return search(rest(it)) }

        // Rien de reconnu : on tente une recherche dans les notes
        val hits = find(input)
        return if (hits.isNotEmpty()) {
            Reply(
                F(
                    "Je n'ai pas compris la demande, mais j'ai trouvé {0} qui en parle : {1}.",
                    plural(hits.size, "note"), hits.take(3).joinToString(", ") { "« ${it.title.ifBlank { T("Sans titre") }} »" },
                ),
                listOf(AssistantAction.Search(input)),
                understood = false,
            )
        } else {
            Reply(T("Je n'ai pas compris. Dis « aide » pour voir ce que je sais faire."), understood = false)
        }
    }

    // ------------------------------------------------------------ Réponses

    private fun help() = Reply(
        T("""Voici ce que je sais faire, à l'écrit ou à la voix :
• « Note : acheter du pain » ou « nouvelle note » puis dicte le contenu
• « Ajoute du lait à la liste de courses »
• « Rendez-vous chez le dentiste jeudi à 14h30 », « Ajoute au calendrier réunion lundi de 9h à 11h »
• « Je suis en congés du 10 au 16 octobre », « Ajoute les dates de la note chantier à l'agenda »
• « Mets dans l'agenda du téléphone… » pour l'ajouter aussi à Google Agenda
• « Rappelle-moi d'appeler le plombier dans 20 minutes »
• « Réveille-moi demain à 6h »
• « Qu'est-ce que j'ai demain ? », « Mon planning cette semaine »
• « Quand est-ce que je travaille ? », « Combien d'heures ce mois-ci ? »
• « Appelle Marc », « Appelle Marc sur son portable », « Appelle le 06 12 34 56 78 »
• « SMS à Marc », « Emmène-moi chez Marc », « Emmène-moi au Consulat d'Italie »
• « Cherche plombier », « Lis la note courses »
• « Résumé de ma journée », « Quelle heure est-il ? »"""),
    )

    private fun greeting(): String {
        val h = Calendar.getInstance().apply { timeInMillis = data.now() }.get(Calendar.HOUR_OF_DAY)
        return if (h < 18) T("Bonjour !") else T("Bonsoir !")
    }

    /** Résumé : rendez-vous du jour, prochaine vacation, rappels. */
    fun briefing(): Reply {
        val (s, e) = dayRange(data.now(), 0)
        val today = eventsIn(s, e)
        val sb = StringBuilder()
        if (today.isEmpty()) sb.append(T("Rien de prévu aujourd'hui."))
        else sb.append(F("Aujourd'hui : {0}.", today.joinToString(" ; ") { describe(it, withDay = false) }))
        val next = data.events.filter { it.isWork && it.start > data.now() && it.start >= e }.minByOrNull { it.start }
        if (next != null) sb.append(" ").append(F("Prochaine vacation : {0}.", describe(next, withDay = true)))
        val (tS, tE) = dayRange(data.now(), 1)
        val tomorrow = eventsIn(tS, tE)
        if (tomorrow.isNotEmpty()) sb.append(" ").append(F("Demain : {0}.", tomorrow.joinToString(" ; ") { describe(it, withDay = false) }))
        return Reply(sb.toString())
    }

    private fun agenda(n: String): Reply {
        val r = rangeFrom(n, default = Unit.let { dayRange(data.now(), 0) + T("aujourd'hui") })
        val list = eventsIn(r.first, r.second)
        if (list.isEmpty()) return Reply(F("Rien de prévu {0}.", r.third), listOf(AssistantAction.OpenCalendar))
        val multiDay = r.second - r.first > 86_400_000L
        return Reply(
            F(
                "{0}, {1} : {2}.", r.third.replaceFirstChar { it.uppercase() }, plural(list.size, "élément"),
                list.joinToString(" ; ") { describe(it, withDay = multiDay) },
            ),
            listOf(AssistantAction.OpenCalendar),
        )
    }

    private fun worksOn(n: String): Reply {
        val r = rangeFrom(n, default = dayRange(data.now(), 0) + T("aujourd'hui"))
        val list = eventsIn(r.first, r.second).filter { it.isWork }
        if (list.isEmpty()) return Reply(F("Non, tu ne travailles pas {0}.", r.third))
        return Reply(F("Oui, {0} : {1}.", r.third, list.joinToString(" ; ") { describe(it, withDay = r.second - r.first > 86_400_000L) }))
    }

    private fun nextShift(): Reply {
        val now = data.now()
        val current = data.events.firstOrNull { it.isWork && it.start <= now && it.end > now }
        val next = data.events.filter { it.isWork && it.start > now }.minByOrNull { it.start }
        return when {
            current != null && next != null ->
                Reply(F("Tu es en poste jusqu'à {0}. Ensuite : {1}.", hm(current.end), describe(next, withDay = true)))
            current != null -> Reply(F("Tu es en poste jusqu'à {0}.", hm(current.end)))
            next != null -> Reply(F("Ta prochaine vacation : {0}.", describe(next, withDay = true)))
            else -> Reply(T("Je ne trouve aucune vacation à venir. Importe ton planning depuis l'agenda."), listOf(AssistantAction.OpenCalendar))
        }
    }

    private fun workHours(n: String): Reply {
        val r = rangeFrom(n, default = monthRange(data.now(), 0) + T("ce mois-ci"))
        val list = data.events.filter { it.isWork && it.end > it.start && it.start >= r.first && it.start < r.second }
        if (list.isEmpty()) return Reply(F("Aucune vacation {0}.", r.third))
        val minutes = list.sumOf { (it.end - it.start) / 60_000L }
        val h = minutes / 60; val mn = minutes % 60
        return Reply(
            F(
                "{0} : {1} de travail, en {2}.", r.third.replaceFirstChar { it.uppercase() },
                "$h h" + (if (mn > 0) " ${"%02d".format(mn)}" else ""), plural(list.size, "vacation"),
            ),
        )
    }

    private fun newNote(text: String): Reply {
        if (text.isBlank()) {
            pending = Pending.NoteContent
            return Reply(T("Je t'écoute : que dois-je noter ?"), listOf(AssistantAction.ListenAgain))
        }
        val clean = text.trim().replaceFirstChar { it.uppercase() }
        val title = clean.split(Regex("""\s+""")).take(6).joinToString(" ").trimEnd(',', '.', ':', ';').take(50)
        val id = data.createNote(title, clean)
        return Reply(F("C'est noté : « {0} ».", title), listOf(AssistantAction.OpenNote(id)))
    }

    private fun appendTo(target: String, what: String): Reply {
        val note = bestNote(target)
        val item = what.trim().replaceFirstChar { it.uppercase() }
        if (note == null) {
            val title = target.trim().replaceFirstChar { it.uppercase() }
            val id = data.createNote(title, "- $item")
            return Reply(F("J'ai créé la note « {0} » avec « {1} ».", title, item), listOf(AssistantAction.OpenNote(id)))
        }
        val sep = if (note.content.isEmpty() || note.content.endsWith("\n")) "" else "\n"
        data.updateNote(note.copy(content = note.content + sep + "- " + item, updatedAt = data.now()))
        return Reply(F("Ajouté à « {0} » : {1}.", note.title.ifBlank { T("Sans titre") }, item))
    }

    private fun readNote(target: String): Reply {
        val note = bestNote(target) ?: return Reply(F("Je ne trouve pas de note « {0} ».", target), listOf(AssistantAction.Search(target)))
        val body = note.content.ifBlank { T("La note est vide.") }
        return Reply("${note.title.ifBlank { T("Sans titre") }}. $body", listOf(AssistantAction.OpenNote(note.id)))
    }

    private fun openNote(target: String): Reply {
        val note = bestNote(target) ?: return Reply(F("Je ne trouve pas de note « {0} ».", target), listOf(AssistantAction.Search(target)))
        return Reply(F("J'ouvre « {0} ».", note.title.ifBlank { T("Sans titre") }), listOf(AssistantAction.OpenNote(note.id)))
    }

    private fun search(q: String): Reply {
        val hits = find(q)
        if (hits.isEmpty()) return Reply(F("Aucune note ne parle de « {0} ».", q))
        return Reply(
            F("{0} pour « {1} » : {2}.", plural(hits.size, "note"), q, hits.take(5).joinToString(", ") { "« ${it.title.ifBlank { T("Sans titre") }} »" }),
            listOf(AssistantAction.Search(q)),
        )
    }

    private fun call(who: String): Reply = reach(Kind.CALL, who)
    private fun sms(who: String): Reply = reach(Kind.SMS, who)

    private fun directions(where: String): Reply {
        // Contact du téléphone qui a une adresse (« emmène-moi chez Marc »)
        val found = matchContacts(where, data.contacts.filter { it.addresses.isNotEmpty() }, strict = true)
        if (found.size == 1) return contactAction(Kind.ROUTE, found[0], null)
        if (found.size in 2..6) return askWhich(Kind.ROUTE, found, null)
        findEntity(where, EntityType.ADDRESS)?.let { (addr, label) ->
            return Reply(F("C'est parti pour {0}.", label), listOf(AssistantAction.Directions(addr)))
        }
        // Ni contact ni note : on prend ce qui a été dit comme adresse
        return Reply(F("Je lance l'itinéraire vers « {0} ».", where), listOf(AssistantAction.Directions(where)))
    }

    // ---------------------------------------------------- Contacts

    /** Appel ou SMS : numéro dicté, contact du téléphone, puis numéro trouvé dans les notes. */
    private fun reach(kind: Kind, whoRaw: String): Reply {
        val raw = whoRaw.trim()
        val digits = raw.filter { it.isDigit() }
        if (digits.length >= 6 && raw.count { it.isLetter() } <= 3) {
            val num = raw.replace(Regex("""^(?i)(le|au)\s+"""), "").trim()
            return if (kind == Kind.CALL) Reply(F("J'appelle le {0}.", num), listOf(AssistantAction.Dial(num)))
            else Reply(F("J'ouvre un SMS pour le {0}.", num), listOf(AssistantAction.Sms(num)))
        }
        val n = norm(raw)
        val pref = when {
            Regex("""\b(portable|mobile|perso|personnel|cellulaire)\b""").containsMatchIn(n) -> PhonePref.MOBILE
            Regex("""\b(fixe|domicile|maison)\b""").containsMatchIn(n) -> PhonePref.HOME
            Regex("""\b(bureau|travail|boulot|pro|professionnel)\b""").containsMatchIn(n) -> PhonePref.WORK
            else -> null
        }
        // « Marc sur son portable » → « Marc »
        val who = Regex("""\s+(sur|a|au|en)\s+(son|sa|le|la)?\s*(portable|mobile|fixe|domicile|maison|bureau|travail|boulot|pro|professionnel|perso|personnel|numero|telephone).*$""")
            .find(n)?.let { raw.substring(0, it.range.first) } ?: raw

        val found = matchContacts(who, data.contacts.filter { it.phones.isNotEmpty() })
        when {
            found.size == 1 -> return contactAction(kind, found[0], pref)
            found.size in 2..6 -> return askWhich(kind, found, pref)
            found.size > 6 -> return Reply(F("{0} contacts correspondent à « {1} ». Dis aussi le nom de famille.", found.size, who), listOf(AssistantAction.ListenAgain))
        }
        findEntity(who, EntityType.PHONE)?.let { (num, label) ->
            return if (kind == Kind.CALL) Reply(F("J'appelle {0}.", label), listOf(AssistantAction.Dial(num)))
            else Reply(F("J'ouvre un SMS pour {0}.", label), listOf(AssistantAction.Sms(num)))
        }
        val hint = if (data.contactsAllowed) "" else
            " " + T("Autorise l'accès aux contacts (icône Contacts de l'accueil) pour que je puisse les chercher.")
        return Reply(F("Je n'ai trouvé « {0} » ni dans tes contacts ni dans tes notes.", who) + hint)
    }

    private fun askWhich(kind: Kind, found: List<AssistantContact>, pref: PhonePref?): Reply {
        pending = Pending.ChooseContact(kind, found, pref)
        return Reply(
            F("J'ai {0} contacts : {1}. Lequel ?", found.size, found.mapIndexed { i, c -> "${i + 1}. ${c.name}" }.joinToString(", ")),
            listOf(AssistantAction.ListenAgain),
        )
    }

    private fun contactAction(kind: Kind, c: AssistantContact, pref: PhonePref?): Reply {
        if (kind == Kind.ROUTE) {
            val addr = c.addresses.firstOrNull() ?: return Reply(F("{0} n'a pas d'adresse enregistrée.", c.name))
            return Reply(F("C'est parti pour chez {0}.", c.name), listOf(AssistantAction.Directions(addr)))
        }
        val (num, label) = pickPhone(c, pref) ?: return Reply(F("{0} n'a pas de numéro enregistré.", c.name))
        val which = if (c.phones.size > 1 && label.isNotBlank()) " (${label.lowercase(Locale.FRANCE)})" else ""
        return if (kind == Kind.CALL) Reply(F("J'appelle {0}.", c.name + which), listOf(AssistantAction.Dial(num)))
        else Reply(F("J'ouvre un SMS pour {0}.", c.name + which), listOf(AssistantAction.Sms(num)))
    }

    /** Numéro à utiliser : celui demandé (portable, fixe, bureau), sinon le portable, sinon le premier. */
    private fun pickPhone(c: AssistantContact, pref: PhonePref?): Pair<String, String>? {
        fun kindOf(label: String): PhonePref? {
            val l = norm(label)
            return when {
                Regex("""mobile|portable|cell""").containsMatchIn(l) -> PhonePref.MOBILE
                Regex("""domicile|maison|fixe|home""").containsMatchIn(l) -> PhonePref.HOME
                Regex("""bureau|travail|pro|work""").containsMatchIn(l) -> PhonePref.WORK
                else -> null
            }
        }
        return c.phones.firstOrNull { pref != null && kindOf(it.second) == pref }
            ?: c.phones.firstOrNull { kindOf(it.second) == PhonePref.MOBILE }
            ?: c.phones.firstOrNull()
    }

    private val QUALIFIERS = setOf(
        "sur", "son", "sa", "portable", "mobile", "fixe", "domicile", "maison", "bureau", "travail", "boulot", "pro",
        "professionnel", "perso", "personnel", "numero", "telephone", "tel", "contact", "whatsapp",
    )

    /**
     * Contacts dont le nom contient tous les mots dits, avec tolérance aux erreurs de la reconnaissance vocale
     * (« Marco » trouve « Marc », « Dupond » trouve « Dupont »). Seuls les meilleurs sont gardés.
     */
    private fun matchContacts(who: String, pool: List<AssistantContact>, strict: Boolean = false): List<AssistantContact> {
        val words = keywords(who).filter { it !in QUALIFIERS }
        if (words.isEmpty() || pool.isEmpty()) return emptyList()
        val query = words.joinToString(" ")
        val scored = pool.mapNotNull { c ->
            val toks = norm(c.name).split(Regex("""[^a-z0-9]+""")).filter { it.isNotEmpty() }
            if (toks.isEmpty()) return@mapNotNull null
            if (!words.all { w -> toks.any { t -> close(w, t, strict) } }) return@mapNotNull null
            val exact = words.count { it in toks }
            val whole = if (toks.joinToString(" ") == query) 10 else 0
            c to (exact * 3 + whole - (toks.size - words.size).coerceAtLeast(0))
        }
        val best = scored.maxOfOrNull { it.second } ?: return emptyList()
        return scored.filter { it.second == best }.map { it.first }.distinctBy { norm(it.name) }
    }

    private fun close(w: String, t: String, strict: Boolean): Boolean = when {
        w == t -> true
        strict -> false
        w.length >= 3 && t.startsWith(w) -> true
        w.length >= 4 && t.length >= 4 && editDistance(w, t) <= 1 -> true
        w.length >= 7 && editDistance(w, t) <= 2 -> true
        else -> false
    }

    private fun editDistance(a: String, b: String): Int {
        var prev = IntArray(b.length + 1) { it }
        for (i in 1..a.length) {
            val cur = IntArray(b.length + 1)
            cur[0] = i
            for (j in 1..b.length) {
                cur[j] = minOf(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + if (a[i - 1] == b[j - 1]) 0 else 1)
            }
            prev = cur
        }
        return prev[b.length]
    }

    /** Réponse à « Lequel ? » : un nom, ou « le premier », « deux », « le dernier »… */
    private fun pickCandidate(answer: String, candidates: List<AssistantContact>): AssistantContact? {
        matchContacts(answer, candidates).singleOrNull()?.let { return it }
        val toks = norm(answer).split(Regex("""[^a-z0-9]+"""))
        val ordinals = listOf(
            setOf("1", "un", "une", "premier", "premiere"),
            setOf("2", "deux", "deuxieme", "second", "seconde"),
            setOf("3", "trois", "troisieme"),
            setOf("4", "quatre", "quatrieme"),
            setOf("5", "cinq", "cinquieme"),
            setOf("6", "six", "sixieme"),
        )
        if (toks.any { it == "dernier" || it == "derniere" }) return candidates.lastOrNull()
        ordinals.forEachIndexed { i, set ->
            if (i < candidates.size && toks.any { it in set }) return candidates[i]
        }
        return null
    }

    // --------------------------------------------- Rendez-vous, rappels

    /** [end] : fin (0 = aucune) — dernier jour d'une période, ou heure de fin (« de 14h à 16h »). */
    private data class When(val start: Long, val hasTime: Boolean, val consumed: List<IntRange>, val end: Long = 0)

    /** Cherche une date/heure dans un texte : « demain à 14h », « jeudi 15 octobre », « dans 20 minutes », « à 18h », « ce soir ». */
    private fun parseWhen(text: String): When? {
        val n = norm(text)
        val now = data.now()
        Regex("""\bdans (\d+|un|une|deux|trois|quatre|cinq|dix|quinze|vingt|trente) ?(minutes?|mn|min|heures?|h|jours?)\b""").find(n)?.let { m ->
            val k = when (val w = m.groupValues[1]) {
                "un", "une" -> 1; "deux" -> 2; "trois" -> 3; "quatre" -> 4; "cinq" -> 5; "dix" -> 10
                "quinze" -> 15; "vingt" -> 20; "trente" -> 30; else -> w.toInt()
            }
            val unit = m.groupValues[2]
            val ms = when {
                unit.startsWith("j") -> k * 86_400_000L
                unit.startsWith("h") -> k * 3_600_000L
                else -> k * 60_000L
            }
            return When(now + ms, true, listOf(m.range))
        }
        val consumed = mutableListOf<IntRange>()
        var date: Entity? = EntityDetector.detect(text).firstOrNull { it.type == EntityType.DATE && it.timeMillis != null }
        date?.let { consumed += it.start until it.end }
        var hour: Int? = null; var minute = 0
        var endHour: Int? = null; var endMinute = 0
        // « de 14h à 16h », « entre 9h et 12h30 », « 14h-16h »
        Regex("""\b(de |entre )?(\d{1,2}) ?(h|heures?|:) ?(\d{2})? ?(a|et|jusqu'a|-) ?(\d{1,2}) ?(h|heures?|:)? ?(\d{2})?\b""").findAll(n).firstOrNull { mm ->
            mm.groupValues[2].toInt() in 0..23 && mm.groupValues[6].toInt() in 0..24 &&
                (mm.groupValues[1].isNotEmpty() || mm.groupValues[7].isNotEmpty() || mm.groupValues[5] == "-")
        }?.let { mm ->
            hour = mm.groupValues[2].toInt(); minute = mm.groupValues[4].toIntOrNull() ?: 0
            endHour = mm.groupValues[6].toInt(); endMinute = mm.groupValues[8].toIntOrNull() ?: 0
            consumed += mm.range
        }
        if ((date == null || !date.hasTime) && hour == null) {
            Regex("""\b(a|vers|pour|des)? ?(\d{1,2}) ?(h|heures?|:) ?(\d{2})?\b""").findAll(n).firstOrNull { mm ->
                consumed.none { r -> mm.range.first in r } && mm.groupValues[2].toInt() in 0..23
            }?.let { mm ->
                hour = mm.groupValues[2].toInt(); minute = mm.groupValues[4].toIntOrNull() ?: 0
                consumed += mm.range
            }
            if (hour == null) {
                Regex("""\b(ce |demain |le |dans la )?(matin|midi|apres[ -]midi|aprem|soir|soiree)\b""").find(n)?.let { mm ->
                    hour = when (mm.groupValues[2]) {
                        "matin" -> 9; "midi" -> 12; "soir", "soiree" -> 19; else -> 14
                    }
                    consumed += mm.range
                    if (mm.groupValues[1].trim() == "demain" && date == null) {
                        date = Entity(EntityType.DATE, mm.range.first, mm.range.last, "demain", "", dayRange(now, 1).first, false)
                    }
                }
            }
        }
        val d = date
        if (d == null && hour == null) return null
        val c = Calendar.getInstance().apply { timeInMillis = d?.timeMillis ?: now }
        if (hour != null) {
            c.set(Calendar.HOUR_OF_DAY, hour!!); c.set(Calendar.MINUTE, minute); c.set(Calendar.SECOND, 0); c.set(Calendar.MILLISECOND, 0)
            if (d == null && c.timeInMillis <= now) c.add(Calendar.DAY_OF_YEAR, 1) // « à 7h » déjà passé : demain
        }
        var end = 0L
        val eh = endHour
        if (eh != null) {
            val e = (c.clone() as Calendar).apply {
                if (eh == 24) { set(Calendar.HOUR_OF_DAY, 0); add(Calendar.DAY_OF_YEAR, 1) } else set(Calendar.HOUR_OF_DAY, eh)
                set(Calendar.MINUTE, endMinute)
            }
            if (e.timeInMillis <= c.timeInMillis) e.add(Calendar.DAY_OF_YEAR, 1) // poste de nuit : 21h à 7h
            end = e.timeInMillis
        } else if (d?.endMillis != null) {
            end = d.endMillis
        }
        return When(c.timeInMillis, d?.hasTime == true || hour != null, consumed, end)
    }

    /** Texte restant une fois la date/heure retirée, nettoyé pour servir de titre. */
    private fun titleFrom(text: String, w: When?): String {
        var t = text
        // Zones qui se chevauchent (date « lundi de 9h » et horaire « de 9h à 11h ») : fusionnées avant retrait
        val merged = mutableListOf<IntRange>()
        w?.consumed?.sortedBy { it.first }?.forEach { r ->
            val last = merged.lastOrNull()
            if (last != null && r.first <= last.last + 1) merged[merged.lastIndex] = last.first..maxOf(last.last, r.last) else merged += r
        }
        merged.sortedByDescending { it.first }.forEach { r ->
            if (r.first < t.length) t = t.removeRange(r.first, minOf(r.last + 1, t.length))
        }
        t = t.replace(Regex("""\s+"""), " ").trim().trim(',', '.', ':', ';', '-').trim()
        // Mots de liaison en début / fin : « d'appeler », « de payer », « que », « pour »
        repeat(3) {
            t = t.replace(Regex("""^(?i)(de |d'|d’|que |qu'|pour |le |la |les |à |a |au |un |une |:)\s*"""), "")
            t = t.replace(Regex("""(?i)\s+(le|la|à|a|au|de|pour|ce|cet|cette|et|dans|demain)$"""), "")
        }
        return t.trim().replaceFirstChar { it.uppercase() }
    }

    private fun reminder(text: String, forceTitle: String? = null): Reply {
        val w = parseWhen(text)
        val title = forceTitle ?: titleFrom(text, w).ifBlank { T("Rappel") }
        if (w == null) {
            pending = Pending.ReminderWhen(title)
            return Reply(F("Quand dois-je te rappeler « {0} » ?", title), listOf(AssistantAction.ListenAgain))
        }
        val start = if (w.hasTime) w.start else Calendar.getInstance().apply {
            timeInMillis = w.start; set(Calendar.HOUR_OF_DAY, 9); set(Calendar.MINUTE, 0)
        }.timeInMillis
        val e = data.createEvent(Event(title = title, start = start, remindMinutes = 0, alarm = false))
        return Reply(F("D'accord, je te rappelle « {0} » {1}.", e.title, whenText(e.start)))
    }

    private fun alarm(text: String, forceTitle: String? = null): Reply {
        val w = parseWhen(text)
        val title = forceTitle ?: titleFrom(text, w).ifBlank { T("Réveil") }
        if (w == null || !w.hasTime) {
            pending = Pending.AlarmWhen(title)
            return Reply(T("À quelle heure ?"), listOf(AssistantAction.ListenAgain))
        }
        val e = data.createEvent(Event(title = title, start = w.start, remindMinutes = 0, alarm = true))
        return Reply(F("Alarme réglée {0}.", whenText(e.start)))
    }

    private fun eventWord(w: String): String {
        val n = norm(w)
        return when {
            n.startsWith("rendez") || n == "rdv" || n == "rencard" -> "Rendez-vous"
            else -> w.trim().replaceFirstChar { it.uppercase() }
        }
    }

    /**
     * Ajoute un rendez-vous ou une période à l'agenda Calepin.
     * [forceTitle] : titre imposé ; [prefix] : « Rendez-vous », « Réunion »… devant « chez… », « avec… » ;
     * [phone] : l'ajouter aussi tout de suite à l'agenda du téléphone.
     */
    private fun newEvent(text: String, forceTitle: String? = null, prefix: String = "Rendez-vous", phone: Boolean = false): Reply {
        val w = parseWhen(text)
        val t0 = forceTitle ?: titleFrom(text, w)
        val title = when {
            t0.isBlank() -> prefix
            forceTitle != null -> t0
            Regex("""^(?i)(chez|avec|au|aux|à la|a la|à l'|a l'|pour)\b""").containsMatchIn(t0) -> prefix + " " + t0.replaceFirstChar { it.lowercase() }
            prefix != "Rendez-vous" && !norm(t0).startsWith(norm(prefix)) -> prefix + " " + t0.replaceFirstChar { it.lowercase() }
            else -> t0
        }
        if (w == null) {
            pending = Pending.EventWhen(title)
            return Reply(F("Pour quand, « {0} » ?", title), listOf(AssistantAction.ListenAgain))
        }
        val dayStart = { t: Long -> dayRange(t, 0).first }
        val ev = when {
            w.end > 0 && !w.hasTime -> Event(title = title, start = dayStart(w.start), end = dayStart(w.end), allDay = true, remindMinutes = -540)
            w.hasTime -> Event(title = title, start = w.start, end = w.end, remindMinutes = 15)
            else -> Event(title = title, start = dayStart(w.start), allDay = true, remindMinutes = -540)
        }
        val e = data.createEvent(ev)
        val reminder = if (e.allDay) T("rappel le matin même") else T("rappel 15 minutes avant")
        val sb = StringBuilder(T("Ajouté à l'agenda :") + " ")
        sb.append(
            when {
                e.allDay && e.isPeriod -> "« ${e.title} » " + F("du {0} au {1}", dayName(e.start), dayName(e.end))
                e.allDay -> "« ${e.title} » ${whenText(e.start, true)}"
                e.end > e.start -> "« ${e.title} » ${whenText(e.start, true)} " + F("de {0} à {1}", hm(e.start), hm(e.end))
                else -> "« ${e.title} » ${whenText(e.start)}"
            },
        )
        sb.append(F(", avec {0}.", reminder))
        if (phone) sb.append(" ").append(T("Je l'ajoute aussi à l'agenda du téléphone."))
        return Reply(
            sb.toString(),
            listOf(
                AssistantAction.PhoneCalendar(e.title, e.start, if (e.end > e.start) e.end else 0L, e.allDay, auto = phone),
                AssistantAction.OpenCalendar,
            ),
        )
    }

    private val CAL_VERB = Regex("""^(ajoute|ajouter|rajoute|mets|met|mettre|inscris|inscrire|note|noter|enregistre|programme|planifie|cale|bloque|reserve|place|marque|reporte|reporter)( moi| nous)?( ca| cela| le| la| les)?\b""")
    private val CAL_PLACE = Regex("""\b(au|a l'|a mon|a ma|dans l'|dans le|dans mon|dans ma|dans|sur l'|sur le|sur mon|sur ma|sur|en)\s*(agenda|calendrier|planning)\b( (du|de mon|de ma|sur le|sur mon) (telephone|portable|mobile|tel)| (de )?google| android| du phone)?""")

    /** « Ajoute au calendrier dentiste jeudi 14h », « Mets dans l'agenda du téléphone… », « Ajoute les dates de la note X à l'agenda ». */
    private fun calendarRequest(input: String, n: String): Reply? {
        val verb = CAL_VERB.find(n) ?: return null
        val place = CAL_PLACE.findAll(n).firstOrNull { it.range.first >= verb.range.last } ?: return null
        val phone = place.groupValues[3].isNotEmpty()
        val cut = listOf(verb.range, place.range).sortedByDescending { it.first }
        var text = input
        cut.forEach { r -> text = text.removeRange(r.first, minOf(r.last + 1, text.length)) }
        text = text.replace(Regex("""\s+"""), " ").trim().trim(',', ':', ';', '-').trim()
        Regex("""^(toutes |tous )?(les |la )?(dates?|rendez[ -]vous|evenements) (de |du |des |d'|dans |qui sont dans )(la |ma |mes |les )?(notes? |listes? )?(.+)$""")
            .find(norm(text))?.let { mm ->
                return addDatesFromNote(text.substring(mm.groups[7]!!.range.first), phone)
            }
        if (text.isBlank()) {
            pending = Pending.EventWhen("Rendez-vous", askWhat = true)
            return Reply(T("Que dois-je ajouter, et pour quand ?"), listOf(AssistantAction.ListenAgain))
        }
        val nt = norm(text)
        Regex("""^(un |une )?(rendez[ -]vous|rdv|reunion|rencard)\b\s*""").find(nt)?.let { mm ->
            return newEvent(text.substring(mm.range.last + 1), prefix = eventWord(text.substring(mm.groups[2]!!.range.first, mm.groups[2]!!.range.last + 1)), phone = phone)
        }
        return newEvent(text, phone = phone)
    }

    /** Toutes les dates repérées dans une note deviennent des rendez-vous (titre = la ligne, sans la date). */
    private fun addDatesFromNote(target: String, phone: Boolean): Reply {
        val note = bestNote(target) ?: return Reply(F("Je ne trouve pas de note « {0} ».", target), listOf(AssistantAction.Search(target)))
        val dates = data.entities(note).filter { it.type == EntityType.DATE && it.timeMillis != null }
        val noteTitle = note.title.ifBlank { T("Note") }
        if (dates.isEmpty()) return Reply(F("La note « {0} » ne contient aucune date.", noteTitle), listOf(AssistantAction.OpenNote(note.id)))
        val existing = data.events
        val added = mutableListOf<Event>()
        for (d in dates) {
            val lineStart = note.content.lastIndexOf('\n', (d.start - 1).coerceAtLeast(0)).let { if (it < 0 || d.start == 0) 0 else it + 1 }
            val lineEnd = note.content.indexOf('\n', d.end).let { if (it < 0) note.content.length else it }
            val line = note.content.substring(lineStart, lineEnd)
            val rel = (d.start - lineStart) until (d.end - lineStart)
            val t = titleFrom(line, When(d.timeMillis!!, d.hasTime, listOf(rel))).take(60).ifBlank { noteTitle }
            val title = if (t.length < 3) noteTitle else t
            val start = if (d.hasTime) d.timeMillis else dayRange(d.timeMillis, 0).first
            val end = d.endMillis?.let { if (d.hasTime) it else dayRange(it, 0).first } ?: 0L
            if (existing.any { it.start == start && norm(it.title) == norm(title) } || added.any { it.start == start && it.title == title }) continue
            added += data.createEvent(
                Event(
                    noteId = note.id, title = title, start = start, end = end, allDay = !d.hasTime,
                    remindMinutes = if (d.hasTime) 15 else -540,
                ),
            )
        }
        if (added.isEmpty()) return Reply(F("Les dates de « {0} » sont déjà dans l'agenda.", noteTitle), listOf(AssistantAction.OpenCalendar))
        val list = added.take(5).joinToString(" ; ") { describe(it, withDay = true) }
        val more = if (added.size > 5) " " + F("et {0} autres", added.size - 5) else ""
        val actions = mutableListOf<AssistantAction>(AssistantAction.OpenCalendar)
        if (phone) added.forEach { actions += AssistantAction.PhoneCalendar(it.title, it.start, it.end, it.allDay, auto = true) }
        return Reply(F("{0} de « {1} » ajoutée{2} à l'agenda : {3}.", plural(added.size, "date"), noteTitle, if (added.size > 1) "s" else "", list + more), actions)
    }

    // -------------------------------------------------------------- Outils

    private fun eventsIn(s: Long, e: Long): List<Event> = data.events.filter { ev ->
        val end = if (ev.end > ev.start) ev.end else ev.start + 1
        ev.start < e && end > s
    }.sortedBy { it.start }

    private fun describe(e: Event, withDay: Boolean): String {
        val day = if (withDay) dayName(e.start) + " " else ""
        val time = when {
            e.allDay && e.isPeriod -> F("du {0} au {1}", dayName(e.start), dayName(e.end))
            e.allDay -> T("toute la journée")
            e.end > e.start -> F("de {0} à {1}", hm(e.start), hm(e.end))
            else -> F("à {0}", hm(e.start))
        }
        return (if (e.allDay && e.isPeriod) "" else day) + time + " : " + e.title
    }

    private fun whenText(t: Long, allDay: Boolean = false): String {
        val (s, _) = dayRange(data.now(), 0)
        val day = when ((t - s).floorDiv(86_400_000L)) {
            0L -> T("aujourd'hui"); 1L -> T("demain"); 2L -> T("après-demain"); else -> dayName(t)
        }
        return if (allDay) day else F("{0} à {1}", day, hm(t))
    }

    /** « 6 h 30 », « 14 h » : se lit bien à voix haute. */
    private fun hm(t: Long): String {
        val c = Calendar.getInstance().apply { timeInMillis = t }
        val h = c.get(Calendar.HOUR_OF_DAY); val m = c.get(Calendar.MINUTE)
        if (I18n.language.value != AppLanguage.FR) return "%d:%02d".format(h, m)
        return when {
            h == 0 && m == 0 -> "minuit"
            h == 12 && m == 0 -> "midi"
            m == 0 -> "$h h"
            else -> "$h h ${"%02d".format(m)}"
        }
    }

    private fun dayName(t: Long, withYear: Boolean = false): String =
        SimpleDateFormat(I18n.pattern(if (withYear) "EEEE d MMMM yyyy" else "EEEE d MMMM"), I18n.locale).format(Date(t))

    private fun dayRange(now: Long, plusDays: Int): Pair<Long, Long> {
        val c = Calendar.getInstance().apply {
            timeInMillis = now; add(Calendar.DAY_OF_YEAR, plusDays)
            set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
        }
        val s = c.timeInMillis
        c.add(Calendar.DAY_OF_YEAR, 1)
        return s to c.timeInMillis
    }

    private fun monthRange(now: Long, plusMonths: Int, month: Int? = null): Pair<Long, Long> {
        val c = Calendar.getInstance().apply {
            timeInMillis = now
            if (month != null) { if (month < get(Calendar.MONTH) - 2) add(Calendar.YEAR, 1); set(Calendar.MONTH, month) }
            add(Calendar.MONTH, plusMonths)
            set(Calendar.DAY_OF_MONTH, 1)
            set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
        }
        val s = c.timeInMillis
        c.add(Calendar.MONTH, 1)
        return s to c.timeInMillis
    }

    private operator fun Pair<Long, Long>.plus(label: String) = Triple(first, second, label)

    private val MONTHS = listOf("janvier", "fevrier", "mars", "avril", "mai", "juin", "juillet", "aout", "septembre", "octobre", "novembre", "decembre")
    private val WEEKDAYS = listOf("dimanche", "lundi", "mardi", "mercredi", "jeudi", "vendredi", "samedi")

    /** Période évoquée dans la phrase (aujourd'hui, demain, cette semaine, en octobre, jeudi, le 14 octobre…). */
    private fun rangeFrom(n: String, default: Triple<Long, Long, String>): Triple<Long, Long, String> {
        val now = data.now()
        when {
            Regex("""\bapres[ -]demain\b""").containsMatchIn(n) -> return dayRange(now, 2) + T("après-demain")
            Regex("""\bdemain\b""").containsMatchIn(n) -> return dayRange(now, 1) + T("demain")
            Regex("""\b(aujourd'hui|ce jour|ce matin|ce soir|cet apres[ -]midi)\b""").containsMatchIn(n) -> return dayRange(now, 0) + T("aujourd'hui")
            Regex("""\bsemaine prochaine\b""").containsMatchIn(n) -> {
                val (s, _) = weekRange(now, 1); return s + T("la semaine prochaine")
            }
            Regex("""\b(cette semaine|la semaine)\b""").containsMatchIn(n) -> {
                val (s, _) = weekRange(now, 0); return s + T("cette semaine")
            }
            Regex("""\bmois prochain\b""").containsMatchIn(n) -> return monthRange(now, 1) + T("le mois prochain")
            Regex("""\b(ce mois|du mois|le mois)\b""").containsMatchIn(n) -> return monthRange(now, 0) + T("ce mois-ci")
        }
        Regex("""\b(en |au mois d'|au mois de |pour |de )?(""" + MONTHS.joinToString("|") + """)\b(?! *\d)""").find(n)?.let { mm ->
            if (!Regex("""\d+ +${mm.groupValues[2]}""").containsMatchIn(n)) {
                val idx = MONTHS.indexOf(mm.groupValues[2])
                return monthRange(now, 0, idx) + F("en {0}", java.time.Month.of(idx + 1).getDisplayName(java.time.format.TextStyle.FULL_STANDALONE, I18n.locale))
            }
        }
        EntityDetector.detect(n).firstOrNull { it.type == EntityType.DATE && it.timeMillis != null }?.let { d ->
            val (s, _) = dayRange(d.timeMillis!!, 0)
            val e = d.endMillis?.let { dayRange(it, 1).first } ?: dayRange(d.timeMillis, 1).first
            return Triple(s, e, if (d.endMillis != null) d.value.replaceFirstChar { it.lowercase() } else F("le {0}", dayName(d.timeMillis)))
        }
        Regex("""\b(""" + WEEKDAYS.joinToString("|") + """)\b""").find(n)?.let { mm ->
            val target = WEEKDAYS.indexOf(mm.value) + 1 // Calendar.SUNDAY = 1
            val c = Calendar.getInstance().apply { timeInMillis = now }
            val diff = (target - c.get(Calendar.DAY_OF_WEEK) + 7) % 7
            return dayRange(now, diff) + (if (diff == 0) T("aujourd'hui") else SimpleDateFormat("EEEE", I18n.locale).format(Date(dayRange(now, diff).first)))
        }
        return default
    }

    /** Du lundi au dimanche (semaine courante ou suivante) ; la semaine courante démarre aujourd'hui. */
    private fun weekRange(now: Long, plusWeeks: Int): Pair<Pair<Long, Long>, Unit> {
        val c = Calendar.getInstance().apply {
            timeInMillis = now
            set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
        }
        val dow = (c.get(Calendar.DAY_OF_WEEK) + 5) % 7 // lundi = 0
        val monday = (c.clone() as Calendar).apply { add(Calendar.DAY_OF_YEAR, -dow + 7 * plusWeeks) }
        val start = if (plusWeeks == 0) c.timeInMillis else monday.timeInMillis
        val end = (monday.clone() as Calendar).apply { add(Calendar.DAY_OF_YEAR, 7) }.timeInMillis
        return (start to end) to Unit
    }

    private fun plural(n: Int, word: String) = F("{0} $word{1}", n, if (n > 1) "s" else "")

    /** Notes qui contiennent tous les mots importants de la requête. */
    private fun find(q: String): List<Note> {
        val words = keywords(q)
        if (words.isEmpty()) return emptyList()
        return data.notes.filter { n ->
            val hay = norm(n.title + " " + n.content + " " + n.tag)
            words.all { hay.contains(it) }
        }.sortedByDescending { n -> words.count { norm(n.title).contains(it) } }
    }

    /** Note dont le titre correspond le mieux (« courses » → « Liste de courses »). */
    private fun bestNote(q: String): Note? {
        val words = keywords(q)
        if (words.isEmpty()) return null
        return data.notes.map { n ->
            val t = norm(n.title)
            val score = words.count { t.contains(it) } * 3 + words.count { norm(n.content).contains(it) }
            n to score
        }.filter { it.second > 0 }.maxByOrNull { it.second }?.first
    }

    /**
     * Numéro ou adresse associé à un nom : d'abord sur la même ligne que le nom,
     * puis dans une note dont le titre contient le nom.
     */
    private fun findEntity(who: String, type: EntityType): Pair<String, String>? {
        val words = keywords(who)
        if (words.isEmpty()) return null
        for (n in data.notes) {
            val ents = data.entities(n).filter { it.type == type }
            if (ents.isEmpty()) continue
            var lineStart = 0
            for (line in n.content.split('\n')) {
                val lineEnd = lineStart + line.length
                if (words.all { norm(line).contains(it) }) {
                    ents.firstOrNull { it.start >= lineStart && it.start <= lineEnd }?.let { e ->
                        return (if (type == EntityType.PHONE) e.value else e.value) to who.trim()
                    }
                }
                lineStart = lineEnd + 1
            }
        }
        val byTitle = data.notes.filter { n -> words.all { norm(n.title).contains(it) } }
        for (n in byTitle) {
            data.entities(n).firstOrNull { it.type == type }?.let { return it.value to who.trim() }
        }
        // Le nom n'est que dans le texte : premier élément de la note
        for (n in data.notes.filter { n -> words.all { norm(n.content).contains(it) } }) {
            data.entities(n).firstOrNull { it.type == type }?.let { return it.value to who.trim() }
        }
        return null
    }

    private val STOP = setOf(
        "le", "la", "les", "l", "un", "une", "des", "de", "du", "d", "a", "au", "aux", "et", "ou", "en", "mon", "ma", "mes",
        "monsieur", "madame", "m", "mme", "mr", "note", "notes", "liste", "chez", "pour", "sur", "dans", "moi", "the",
    )

    private fun keywords(q: String): List<String> =
        norm(q).split(Regex("""[^a-z0-9]+""")).filter { it.length >= 2 && it !in STOP }

    companion object {
        /** Minuscules sans accents, de même longueur que le texte d'origine (les positions correspondent). */
        fun norm(s: String): String = buildString(s.length) {
            for (ch in s) {
                val c = when (ch) {
                    'œ', 'Œ' -> 'o'; 'æ', 'Æ' -> 'a'; '’', '‘', '`' -> '\''; ' ' -> ' '
                    else -> Normalizer.normalize(ch.toString(), Normalizer.Form.NFD).firstOrNull() ?: ch
                }
                append(c.lowercaseChar())
            }
        }
    }
}
