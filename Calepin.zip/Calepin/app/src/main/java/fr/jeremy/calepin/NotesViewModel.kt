package fr.jeremy.calepin

import android.app.Application
import android.content.Context
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import fr.jeremy.calepin.data.Note
import fr.jeremy.calepin.data.NoteDb
import fr.jeremy.calepin.data.Recording
import fr.jeremy.calepin.data.Attachment
import fr.jeremy.calepin.data.Event
import fr.jeremy.calepin.detect.EntityType
import fr.jeremy.calepin.media.Media
import fr.jeremy.calepin.reminders.Reminders
import android.net.Uri
import fr.jeremy.calepin.audio.VoiceRecorder
import fr.jeremy.calepin.export.Backup
import fr.jeremy.calepin.export.ExportFormat
import fr.jeremy.calepin.export.Exporters
import fr.jeremy.calepin.export.PdfExport
import java.io.File
import fr.jeremy.calepin.detect.Entity
import fr.jeremy.calepin.detect.EntityDetector
import fr.jeremy.calepin.search.SearchEngine
import fr.jeremy.calepin.search.SearchOptions
import fr.jeremy.calepin.search.SearchResult
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.FlowPreview
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.debounce
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.concurrent.ConcurrentHashMap

@OptIn(FlowPreview::class)
class NotesViewModel(app: Application) : AndroidViewModel(app) {

    private val db = NoteDb(app)
    private val notes = MutableStateFlow<List<Note>>(emptyList())

    val settings = AppSettings(app)

    /** Identifiants des notes qui ont au moins un enregistrement vocal. */
    private val _withAudio = MutableStateFlow<Set<Long>>(emptySet())
    val withAudio: StateFlow<Set<Long>> = _withAudio

    /** Notes qui ont au moins une photo ou une vidéo. */
    private val _withMedia = MutableStateFlow<Set<Long>>(emptySet())
    val withMedia: StateFlow<Set<Long>> = _withMedia

    /** Vrai une fois les notes chargées depuis la base. */
    val loaded = MutableStateFlow(false)

    /** Rendez-vous de l'agenda Calepin. */
    private val _events = MutableStateFlow<List<Event>>(emptyList())
    val events: StateFlow<List<Event>> = _events

    val query = MutableStateFlow("")
    val options = MutableStateFlow(SearchOptions())

    private val entityCache = ConcurrentHashMap<Long, Pair<String, List<Entity>>>()

    fun entitiesOf(n: Note): List<Entity> {
        val cached = entityCache[n.id]
        if (cached != null && cached.first == n.content) return cached.second
        return EntityDetector.detect(n.content).also { entityCache[n.id] = n.content to it }
    }

    /** Dossier affiché : null = toutes les notes, "" = notes sans dossier, sinon chemin « A/B ». */
    val currentFolder = MutableStateFlow<String?>(null)

    /** Dossiers créés à la main (même vides). */
    private val createdFolders = MutableStateFlow<List<String>>(emptyList())

    /** Tous les dossiers (créés ou utilisés par une note), parents compris, triés. */
    val folders: StateFlow<List<String>> =
        combine(notes, createdFolders) { n, f ->
            (n.map { it.folder } + f).filter { it.isNotBlank() }
                .flatMap { path -> path.split('/').runningReduce { acc, part -> "$acc/$part" } }
                .distinct()
                .sortedWith(compareBy(String.CASE_INSENSITIVE_ORDER) { it })
        }.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    /** Nombre de notes par dossier, sous-dossiers compris (affiché sur les dossiers de l'écran Notes). */
    val folderCounts: StateFlow<Map<String, Int>> =
        notes.map { n ->
            val m = HashMap<String, Int>()
            n.forEach { note ->
                if (note.folder.isNotBlank()) {
                    note.folder.split('/').runningReduce { acc, part -> "$acc/$part" }.forEach { m[it] = (m[it] ?: 0) + 1 }
                } else {
                    m[""] = (m[""] ?: 0) + 1 // notes sans dossier
                }
            }
            m as Map<String, Int>
        }.stateIn(viewModelScope, SharingStarted.Eagerly, emptyMap())

    val results: StateFlow<List<SearchResult>> =
        combine(notes, query.debounce(120), options, currentFolder) { n, q, o, f ->
            // En recherche, un dossier inclut ses sous-dossiers ; en navigation, seulement ses propres notes
            val inFolder = when {
                f == null -> n
                f.isEmpty() -> n.filter { it.folder.isEmpty() }
                q.isBlank() -> n.filter { it.folder == f }
                else -> n.filter { it.folder == f || it.folder.startsWith("$f/") }
            }
            SearchEngine.search(inFolder, q, o, ::entitiesOf)
        }
            .flowOn(Dispatchers.Default)
            .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    /** Notes affichées sur l'accueil : épinglées d'abord, puis les plus récentes. */
    val recentNotes: StateFlow<List<Note>> =
        notes.map { list -> (list.filter { it.pinned } + list.filter { !it.pinned }).take(4) }
            .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    /** Demande de navigation venue de l'assistant (« ouvre la télécommande »…), consommée par l'écran principal. */
    val navigation = MutableStateFlow<String?>(null)

    val noteCount: StateFlow<Int> =
        notes.map { it.size }.stateIn(viewModelScope, SharingStarted.Eagerly, 0)

    val allTags: StateFlow<List<String>> =
        notes.map { list -> list.flatMap { it.tags }.distinctBy { it.lowercase() }.sortedBy { it.lowercase() } }
            .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    init {
        viewModelScope.launch {
            withContext(Dispatchers.IO) { seedIfFirstLaunch() }
            refresh()
        }
    }

    private suspend fun refresh() {
        withContext(Dispatchers.IO) {
            val n = db.all()
            val a = db.recordings().map { it.noteId }.toSet()
            val m = db.attachments().map { it.noteId }.toSet()
            val e = db.events()
            createdFolders.value = db.folders()
            notes.value = n
            _withAudio.value = a
            _withMedia.value = m
            _events.value = e
            loaded.value = true
            runCatching { fr.jeremy.calepin.widgets.Widgets.refresh(getApplication()) }
        }
    }

    fun allNotes(): List<Note> = notes.value
    fun notesByIds(ids: Collection<Long>): List<Note> = notes.value.filter { it.id in ids }

    fun find(id: Long): Note? = notes.value.firstOrNull { it.id == id }

    /** Notes qui citent ce contact : un de ses numéros (quel que soit le format) ou son nom complet. */
    fun notesForContact(name: String, phones: List<String>): List<Note> {
        val keys = phones.map { p -> p.filter { it.isDigit() } }.filter { it.length >= 8 }.map { it.takeLast(8) }.toSet()
        val n = fr.jeremy.calepin.search.TextNorm.norm(name).trim()
        return notes.value.filter { note ->
            (n.length >= 3 && fr.jeremy.calepin.search.TextNorm.norm(note.title + "\n" + note.content).contains(n)) ||
                (keys.isNotEmpty() && entitiesOf(note).any { e ->
                    e.type == EntityType.PHONE && e.value.filter { it.isDigit() }.takeLast(8) in keys
                })
        }
    }

    fun setQuery(q: String) { query.value = q }
    fun updateOptions(f: SearchOptions.() -> SearchOptions) { options.value = options.value.f() }

    /** Écriture immédiate (petite requête SQLite) pour obtenir l'identifiant sans risque de doublon. */
    fun saveNow(n: Note): Long {
        val id = db.upsert(n)
        viewModelScope.launch { refresh() }
        return id
    }

    fun delete(id: Long) {
        viewModelScope.launch {
            withContext(Dispatchers.IO) { deleteRecordingsOf(id); deleteExtrasOf(id); db.delete(id) }
            entityCache.remove(id)
            refresh()
        }
    }

    fun deleteMany(ids: Set<Long>) {
        if (ids.isEmpty()) return
        viewModelScope.launch {
            withContext(Dispatchers.IO) { ids.forEach { deleteRecordingsOf(it); deleteExtrasOf(it); db.delete(it) } }
            ids.forEach { entityCache.remove(it) }
            refresh()
        }
    }

    // ------------------------------------------------------------- Dossiers

    fun openFolder(path: String?) { currentFolder.value = path }

    /** Nombre de notes directement dans chaque dossier. */
    fun countIn(path: String): Int = notes.value.count { it.folder == path }

    fun createFolder(path: String) {
        viewModelScope.launch {
            withContext(Dispatchers.IO) { db.addFolder(path) }
            refresh()
        }
    }

    fun renameFolder(from: String, to: String) {
        viewModelScope.launch {
            withContext(Dispatchers.IO) { db.renameFolder(from, to) }
            val cur = currentFolder.value
            if (cur != null && (cur == from || cur.startsWith("$from/"))) currentFolder.value = to + cur.substring(from.length)
            refresh()
        }
    }

    fun deleteFolder(path: String) {
        viewModelScope.launch {
            withContext(Dispatchers.IO) { db.deleteFolder(path) }
            val cur = currentFolder.value
            if (cur != null && (cur == path || cur.startsWith("$path/"))) currentFolder.value = path.substringBeforeLast('/', "").ifEmpty { null }
            refresh()
        }
    }

    fun moveNotes(ids: Collection<Long>, folder: String) {
        if (ids.isEmpty()) return
        viewModelScope.launch {
            withContext(Dispatchers.IO) {
                if (folder.isNotEmpty()) db.addFolder(folder)
                db.moveNotes(ids, folder)
            }
            refresh()
        }
    }

    fun togglePin(n: Note) {
        viewModelScope.launch {
            withContext(Dispatchers.IO) { db.upsert(n.copy(pinned = !n.pinned)) }
            refresh()
        }
    }

    // ----------------------------------------------------- Enregistrements

    private val recDir: File get() = VoiceRecorder.dir(getApplication())

    fun recordingsOf(noteId: Long): List<Recording> = if (noteId == 0L) emptyList() else db.recordings(noteId)
    fun fileOf(r: Recording): File = File(recDir, r.fileName)

    fun newRecordingFile(noteId: Long, format: AudioFormat): File =
        File(recDir, "note${noteId}_${System.currentTimeMillis()}.${format.ext}")

    fun addRecording(noteId: Long, file: File, format: AudioFormat, durationMs: Long) {
        db.insertRecording(Recording(noteId = noteId, fileName = file.name, format = format.name, durationMs = durationMs))
        viewModelScope.launch { refresh() }
    }

    fun deleteRecording(r: Recording) {
        fileOf(r).delete()
        db.deleteRecording(r.id)
        viewModelScope.launch { refresh() }
    }

    private fun deleteRecordingsOf(noteId: Long) {
        db.recordings(noteId).forEach { File(recDir, it.fileName).delete(); db.deleteRecording(it.id) }
    }

    fun setTranscript(r: Recording, text: String) {
        db.setTranscript(r.id, text)
    }

    // ------------------------------------------------------ Photos, vidéos

    fun attachmentsOf(noteId: Long): List<Attachment> = if (noteId == 0L) emptyList() else db.attachments(noteId)
    fun fileOf(a: Attachment): File = File(Media.dir(getApplication()), a.fileName)

    suspend fun importMedia(noteId: Long, uris: List<Uri>): Int = withContext(Dispatchers.IO) {
        var n = 0
        uris.forEach { u ->
            Media.importUri(getApplication(), u)?.let { (f, video) ->
                db.insertAttachment(Attachment(noteId = noteId, fileName = f.name, isVideo = video)); n++
            }
        }
        refresh()
        n
    }

    /** Photo ou vidéo prise avec l'appareil, déjà écrite dans [f]. */
    fun addCaptured(noteId: Long, f: File, video: Boolean) {
        if (!f.exists() || f.length() == 0L) { f.delete(); return }
        db.insertAttachment(Attachment(noteId = noteId, fileName = f.name, isVideo = video))
        viewModelScope.launch { refresh() }
    }

    fun deleteAttachment(a: Attachment) {
        fileOf(a).delete()
        db.deleteAttachment(a.id)
        viewModelScope.launch { refresh() }
    }

    // ------------------------------------------------------------- Agenda

    fun saveEvent(e: Event): Event {
        val id = db.upsertEvent(e)
        val saved = e.copy(id = id)
        Reminders.schedule(getApplication(), saved)
        viewModelScope.launch { refresh() }
        return saved
    }

    fun deleteEvent(e: Event) {
        Reminders.cancel(getApplication(), e.id)
        db.deleteEvent(e.id)
        viewModelScope.launch { refresh() }
    }

    /** Dates reconnues automatiquement dans le texte des notes (pour le calendrier). */
    data class DetectedDate(val note: Note, val time: Long, val hasTime: Boolean, val text: String, val end: Long? = null)

    fun detectedDates(): List<DetectedDate> = notes.value.flatMap { n ->
        entitiesOf(n).filter { it.type == EntityType.DATE && it.timeMillis != null }
            .map { DetectedDate(n, it.timeMillis!!, it.hasTime, it.text, it.endMillis) }
    }

    /** Ajoute plusieurs rendez-vous d'un coup (planning importé) ; ignore ceux déjà présents. Renvoie le nombre ajouté. */
    suspend fun saveEvents(list: List<Event>): Int = withContext(Dispatchers.IO) {
        val existing = db.events().map { Triple(it.start, it.end, it.title) }.toSet()
        var n = 0
        list.forEach { e ->
            if (Triple(e.start, e.end, e.title) !in existing) {
                val id = db.upsertEvent(e)
                Reminders.schedule(getApplication(), e.copy(id = id))
                n++
            }
        }
        refresh()
        n
    }

    /**
     * Mise à jour de l'agenda avec un nouveau planning : ajoute les nouveaux créneaux, remplace ceux qui ont changé
     * (même rendez-vous, nouveaux horaires) et supprime ceux qui ne figurent plus dans le planning.
     */
    suspend fun applyPlanning(add: List<Event>, replace: List<Pair<Event, Event>>, delete: List<Event>) = withContext(Dispatchers.IO) {
        val app = getApplication<Application>()
        add.forEach { e ->
            val id = db.upsertEvent(e)
            Reminders.schedule(app, e.copy(id = id))
        }
        replace.forEach { (old, new) ->
            Reminders.cancel(app, old.id)
            val e = new.copy(id = old.id, noteId = old.noteId, createdAt = old.createdAt)
            db.upsertEvent(e)
            Reminders.schedule(app, e)
        }
        delete.forEach { e ->
            Reminders.cancel(app, e.id)
            db.deleteEvent(e.id)
        }
        refresh()
    }

    private fun deleteExtrasOf(noteId: Long) {
        db.attachments(noteId).forEach { File(Media.dir(getApplication()), it.fileName).delete(); db.deleteAttachment(it.id) }
        db.events().filter { it.noteId == noteId }.forEach { Reminders.cancel(getApplication(), it.id); db.deleteEvent(it.id) }
    }

    // ----------------------------------------------------------- Assistant

    data class ChatMsg(val fromUser: Boolean, val text: String)

    private val assistant = fr.jeremy.calepin.assistant.Assistant(fr.jeremy.calepin.assistant.DbAssistantData(app))
    private val _chat = MutableStateFlow(
        listOf(ChatMsg(false, "Bonjour ! Demande-moi par exemple « Qu'est-ce que j'ai demain ? » ou dis « aide »."))
    )
    val chat: StateFlow<List<ChatMsg>> = _chat

    /** Traite une demande (écrite ou dictée) ; les notes et l'agenda sont rafraîchis ensuite. */
    suspend fun ask(text: String, frenchCommand: String? = null): fr.jeremy.calepin.assistant.Reply {
        _chat.value = _chat.value + ChatMsg(true, text)
        // Autre langue que le français : la demande passe par l'IA, qui la réécrit en commande française
        if (fr.jeremy.calepin.i18n.I18n.language.value != fr.jeremy.calepin.i18n.AppLanguage.FR) {
            if (frenchCommand != null) {
                val r = runFrenchCommand(frenchCommand)
                refresh()
                _chat.value = _chat.value + ChatMsg(false, r.text)
                return r
            }
            return askOtherLanguage(text)
        }
        // Apparence et navigation : « thème océan », « mode sombre », « ouvre la télécommande »…
        if (!assistant.isWaiting) {
            fr.jeremy.calepin.ui.AppearanceCommands.handle(getApplication(), settings, text)?.let { res ->
                _chat.value = _chat.value + ChatMsg(false, res.reply)
                res.navigate?.let { navigation.value = it }
                return fr.jeremy.calepin.assistant.Reply(res.reply)
            }
        }
        // Calepin IA : commandes de la télé, du décodeur et du téléphone, reconnues directement
        if (BuildConfig.AI && !assistant.isWaiting) {
            val done = runCatching { devices.handle(text) }.getOrNull()
            if (done != null) {
                _chat.value = _chat.value + ChatMsg(false, done.text)
                return fr.jeremy.calepin.assistant.Reply(done.text)
            }
        }
        val r = withContext(Dispatchers.IO) { assistant.handle(text) }
        // Calepin IA : quand aucune commande n'est reconnue, le modèle hors ligne répond
        if (!r.understood && BuildConfig.AI) {
            val ctx = getApplication<Application>()
            val model = fr.jeremy.calepin.ai.AiModels.active(ctx)
            val engine = fr.jeremy.calepin.ai.AiEngineFactory.get(ctx)
            if (model != null && engine != null) {
                val answer = askAi(engine, fr.jeremy.calepin.ai.AiModels.file(ctx, model).path, text)
                refresh()
                return r.copy(text = answer, understood = true)
            }
            val hint = r.text + "\n\nPour que je réponde à tout, installe un modèle d'IA dans Paramètres → Intelligence artificielle."
            _chat.value = _chat.value + ChatMsg(false, hint)
            return r.copy(text = hint)
        }
        _chat.value = _chat.value + ChatMsg(false, r.text)
        refresh()
        return r
    }

    /** Commande en français passée à tous les modules (apparence, appareils, assistant), sans toucher à la discussion. */
    private suspend fun runFrenchCommand(cmd: String): fr.jeremy.calepin.assistant.Reply {
        if (!assistant.isWaiting) {
            fr.jeremy.calepin.ui.AppearanceCommands.handle(getApplication(), settings, cmd)?.let { res ->
                res.navigate?.let { navigation.value = it }
                return fr.jeremy.calepin.assistant.Reply(res.reply)
            }
            if (BuildConfig.AI) {
                runCatching { devices.handle(cmd) }.getOrNull()?.let { return fr.jeremy.calepin.assistant.Reply(it.text) }
            }
        }
        val r = withContext(Dispatchers.IO) { assistant.handle(cmd) }
        // Dans les autres langues, une réponse peut commencer par un mot en minuscule (« morgen nichts geplant »)
        return if (fr.jeremy.calepin.i18n.I18n.language.value == fr.jeremy.calepin.i18n.AppLanguage.FR) r
        else r.copy(text = r.text.replaceFirstChar { it.uppercase() })
    }

    /**
     * Assistant dans une autre langue que le français.
     * Calepin IA avec un modèle : le modèle réécrit la demande en commande française (exécutée, réponse traduite)
     * ou répond lui-même dans la langue choisie. Sans modèle : seules les commandes en français sont comprises.
     */
    private suspend fun askOtherLanguage(text: String): fr.jeremy.calepin.assistant.Reply {
        val ctx = getApplication<Application>()
        val lang = fr.jeremy.calepin.i18n.I18n.language.value
        val model = if (BuildConfig.AI) fr.jeremy.calepin.ai.AiModels.active(ctx) else null
        val engine = if (model != null) fr.jeremy.calepin.ai.AiEngineFactory.get(ctx) else null
        fun answer(r: fr.jeremy.calepin.assistant.Reply): fr.jeremy.calepin.assistant.Reply {
            _chat.value = _chat.value + ChatMsg(false, r.text)
            return r
        }

        // « Oui » / « non » à la confirmation d'un message WhatsApp (compris dans les cinq langues)
        if (BuildConfig.AI && devices.awaitingConfirmation) {
            runCatching { devices.handle(text) }.getOrNull()?.let { return answer(fr.jeremy.calepin.assistant.Reply(it.text)) }
        }
        // Suite d'une question de l'assistant : le contenu d'une note reste tel quel, le reste est traduit
        if (assistant.isWaiting) {
            val input = if (engine != null && model != null && !assistant.waitingForText) {
                toFrench(engine, fr.jeremy.calepin.ai.AiModels.file(ctx, model).path, text) ?: text
            } else text
            val r = runFrenchCommand(input)
            refresh()
            return answer(r)
        }

        if (engine == null || model == null) {
            // Une commande écrite en français marche toujours
            val r = runFrenchCommand(text)
            refresh()
            if (r.understood) return answer(r)
            val hint = fr.jeremy.calepin.i18n.I18n.tr(
                if (BuildConfig.AI) "Pour que je comprenne cette langue, installe un modèle d'IA dans Paramètres → Intelligence artificielle. Sans modèle, je ne comprends que les commandes en français."
                else "Dans cette version, l'assistant ne comprend que les commandes en français. Calepin IA les comprend dans toutes les langues de l'appli."
            )
            return answer(r.copy(text = hint, understood = false))
        }

        val path = fr.jeremy.calepin.ai.AiModels.file(ctx, model).path
        val placeholder = ChatMsg(false, "…")
        _chat.value = _chat.value + placeholder
        val pos = _chat.value.lastIndex
        fun show(t: String) {
            val list = _chat.value
            if (pos < list.size && !list[pos].fromUser) {
                _chat.value = list.mapIndexed { i, m -> if (i == pos) ChatMsg(false, t) else m }
            }
        }
        suspend fun generate(system: String, prompt: String): String {
            var partial = ""
            aiWorking.value = true
            return try {
                engine.generate(path, system, prompt) { t ->
                    partial = t
                    show(if (fr.jeremy.calepin.ai.AiLanguage.looksLikeCommand(t)) "…" else t)
                }.trim()
            } catch (e: Throwable) {
                if (e is kotlinx.coroutines.CancellationException && partial.isEmpty()) throw e
                if (partial.isNotBlank()) partial.trim() + " […]"
                else fr.jeremy.calepin.i18n.I18n.trf(
                    "L'IA n'a pas pu répondre ({0}). Le téléphone manque peut-être de mémoire : fermez d'autres applis ou choisissez le modèle Qwen, plus léger.",
                    e.message ?: e.javaClass.simpleName,
                )
            } finally {
                aiWorking.value = false
            }
        }

        show(fr.jeremy.calepin.i18n.I18n.tr("Je réfléchis… (le premier message charge le modèle, quelques secondes)"))
        val prompt = withContext(Dispatchers.Default) { aiPrompt(text, foreign = true) }
        val first = generate(fr.jeremy.calepin.ai.AiLanguage.assistantSystem(lang), prompt)
        val cmd = fr.jeremy.calepin.ai.AiLanguage.COMMAND_LINE.find(first)?.groupValues?.get(1)?.trim()?.trim('«', '»', '"', '`', ' ')
        if (cmd != null) {
            val r = runFrenchCommand(cmd)
            refresh()
            if (r.understood) {
                show(r.text)
                lastAiExchange = text to r.text
                return r
            }
            // La commande proposée n'a rien donné : réponse directe
            val second = generate(fr.jeremy.calepin.ai.AiLanguage.answerSystem(lang), prompt)
                .let { fr.jeremy.calepin.ai.AiLanguage.COMMAND_LINE.replace(it, "").trim() }
                .ifBlank { fr.jeremy.calepin.i18n.I18n.tr("Je n'ai pas de réponse à proposer.") }
            show(second)
            lastAiExchange = text to second
            return fr.jeremy.calepin.assistant.Reply(second)
        }
        val finalText = first.ifBlank { fr.jeremy.calepin.i18n.I18n.tr("Je n'ai pas de réponse à proposer.") }
        show(finalText)
        lastAiExchange = text to finalText
        refresh()
        return fr.jeremy.calepin.assistant.Reply(finalText)
    }

    /** Courte réponse (heure d'un rappel, « le deuxième »…) traduite en français pour l'assistant. */
    private suspend fun toFrench(engine: fr.jeremy.calepin.ai.AiEngine, path: String, text: String): String? {
        aiWorking.value = true
        return try {
            engine.generate(path, fr.jeremy.calepin.ai.AiLanguage.TO_FRENCH_SYSTEM, text) { }
                .lineSequence().firstOrNull { it.isNotBlank() }?.trim()?.trim('"', '«', '»', ' ')?.takeIf { it.isNotEmpty() }
        } catch (e: Throwable) {
            if (e is kotlinx.coroutines.CancellationException) throw e
            null
        } finally {
            aiWorking.value = false
        }
    }

    fun addAssistantMessage(text: String) { _chat.value = _chat.value + ChatMsg(false, text) }
    fun clearChat() { _chat.value = _chat.value.take(1); lastAiExchange = null }

    // ------------------------------------------------- IA hors ligne (Calepin IA)

    private val devices by lazy { fr.jeremy.calepin.control.DeviceCommands(getApplication()) }

    /** Vrai pendant qu'une réponse de l'IA s'écrit. */
    val aiWorking = MutableStateFlow(false)
    private var lastAiExchange: Pair<String, String>? = null

    /** Téléchargement d'un modèle en cours (ou en échec, avec [AiDownload.error]). */
    data class AiDownload(val modelId: String, val done: Long, val total: Long, val error: String? = null)

    val aiDownload = MutableStateFlow<AiDownload?>(null)
    /** Change à chaque installation ou suppression de modèle, pour rafraîchir l'écran. */
    val aiModelsVersion = MutableStateFlow(0)
    private var aiJob: kotlinx.coroutines.Job? = null

    fun startAiDownload(m: fr.jeremy.calepin.ai.AiModel) {
        if (aiJob?.isActive == true) return
        val ctx = getApplication<Application>()
        aiJob = viewModelScope.launch {
            val start = fr.jeremy.calepin.ai.AiModels.partialBytes(ctx, m)
            aiDownload.value = AiDownload(m.id, start, m.bytes)
            try {
                fr.jeremy.calepin.ai.AiModels.download(ctx, m) { d, t -> aiDownload.value = AiDownload(m.id, d, t) }
                aiDownload.value = null
            } catch (e: kotlinx.coroutines.CancellationException) {
                aiDownload.value = null
                throw e
            } catch (e: Exception) {
                aiDownload.value = AiDownload(
                    m.id, fr.jeremy.calepin.ai.AiModels.partialBytes(ctx, m), m.bytes,
                    e.message ?: fr.jeremy.calepin.i18n.I18n.tr("Connexion interrompue"),
                )
            }
            aiModelsVersion.value++
        }
    }

    /** Met le téléchargement en pause : la partie reçue est gardée pour reprendre. */
    fun pauseAiDownload() {
        aiJob?.cancel()
        aiModelsVersion.value++
    }

    fun selectAiModel(m: fr.jeremy.calepin.ai.AiModel) {
        fr.jeremy.calepin.ai.AiModels.select(getApplication(), m)
        aiModelsVersion.value++
    }

    fun deleteAiModel(m: fr.jeremy.calepin.ai.AiModel) {
        if (aiWorking.value) stopAi()
        fr.jeremy.calepin.ai.AiEngineFactory.get(getApplication())?.release()
        fr.jeremy.calepin.ai.AiModels.delete(getApplication(), m)
        aiModelsVersion.value++
    }

    fun stopAi() {
        fr.jeremy.calepin.ai.AiEngineFactory.get(getApplication())?.stop()
    }

    /** Vrai si l'IA hors ligne est prête (Calepin IA avec un modèle installé). */
    fun aiReady(): Boolean {
        if (!BuildConfig.AI) return false
        val ctx = getApplication<Application>()
        return fr.jeremy.calepin.ai.AiModels.active(ctx) != null && fr.jeremy.calepin.ai.AiEngineFactory.get(ctx) != null
    }

    /** Résumé, correction, traduction, compte rendu… d'un texte. [onText] reçoit la réponse au fil de l'eau. */
    suspend fun aiTool(tool: fr.jeremy.calepin.ai.AiTool, text: String, onText: (String) -> Unit): String {
        val ctx = getApplication<Application>()
        val model = fr.jeremy.calepin.ai.AiModels.active(ctx) ?: error(fr.jeremy.calepin.i18n.I18n.tr("Aucun modèle d'IA installé (Paramètres → Intelligence artificielle)."))
        val engine = fr.jeremy.calepin.ai.AiEngineFactory.get(ctx) ?: error(fr.jeremy.calepin.i18n.I18n.tr("IA indisponible dans cette version."))
        val input = if (text.length > 7000) text.take(7000) + " […]" else text
        aiWorking.value = true
        try {
            return engine.generate(
                fr.jeremy.calepin.ai.AiModels.file(ctx, model).path,
                fr.jeremy.calepin.ai.AiLanguage.writingSystem(),
                tool.instruction + "\n\nTexte :\n" + input,
                onText,
            ).trim()
        } finally {
            aiWorking.value = false
        }
    }

    private suspend fun askAi(engine: fr.jeremy.calepin.ai.AiEngine, modelPath: String, question: String): String {
        val placeholder = ChatMsg(false, "…")
        _chat.value = _chat.value + placeholder
        val pos = _chat.value.lastIndex
        fun show(t: String) {
            val list = _chat.value
            if (pos < list.size && !list[pos].fromUser) {
                _chat.value = list.mapIndexed { i, m -> if (i == pos) ChatMsg(false, t) else m }
            }
        }
        aiWorking.value = true
        var partial = ""
        val answer = try {
            show("Je réfléchis… (le premier message charge le modèle, quelques secondes)")
            val prompt = withContext(Dispatchers.Default) { aiPrompt(question) }
            engine.generate(modelPath, AI_SYSTEM, prompt) { t -> partial = t; show(t) }.trim()
        } catch (e: Throwable) {
            if (e is kotlinx.coroutines.CancellationException && partial.isEmpty()) throw e
            if (partial.isNotBlank()) partial.trim() + " […]"
            else "L'IA n'a pas pu répondre (${e.message ?: e.javaClass.simpleName}). Le téléphone manque peut-être de mémoire : " +
                "fermez d'autres applis ou choisissez le modèle Qwen, plus léger."
        } finally {
            aiWorking.value = false
        }
        // L'IA peut demander une commande d'appareil : « ACTION: allume la télé »
        val action = Regex("(?im)^\\s*ACTION\\s*:\\s*(.+)$").find(answer)?.groupValues?.get(1)?.trim()?.trim('«', '»', '"', ' ')
        if (action != null) {
            fr.jeremy.calepin.ui.AppearanceCommands.handle(getApplication(), settings, action)?.let { res ->
                show(res.reply)
                res.navigate?.let { navigation.value = it }
                lastAiExchange = question to res.reply
                return res.reply
            }
            val done = runCatching { devices.handle(action) }.getOrNull()
            // Sinon l'assistant de Calepin (notes, rappels, agenda, suppressions…)
            val viaAssistant = if (done == null) withContext(Dispatchers.IO) { assistant.handle(action) }.takeIf { it.understood } else null
            val t = done?.text ?: viaAssistant?.text ?: fr.jeremy.calepin.i18n.I18n.trf("Je n'ai pas su faire « {0} ».", action)
            show(t)
            lastAiExchange = question to t
            return t
        }
        val finalText = answer.ifBlank { "Je n'ai pas de réponse à proposer." }
        show(finalText)
        lastAiExchange = question to finalText
        return finalText
    }

    /** Question + contexte : date du jour, rendez-vous à venir et notes qui semblent liées. */
    private fun aiPrompt(question: String, foreign: Boolean = false): String =
        if (foreign) aiPromptForeign(question) else aiPromptFr(question)

    /** Même contexte que [aiPromptFr], avec des intitulés en anglais (langue des consignes) et les dates dans la langue choisie. */
    private fun aiPromptForeign(question: String): String = buildString {
        val now = System.currentTimeMillis()
        val loc = fr.jeremy.calepin.i18n.I18n.locale
        append("Today is ")
        append(java.text.SimpleDateFormat("EEEE d MMMM yyyy, HH:mm", loc).format(java.util.Date(now)))
        append(".\n")
        val soon = _events.value.filter { it.start >= now - 3_600_000 && it.start <= now + 14 * 86_400_000L }.take(12)
        if (soon.isNotEmpty()) {
            append("\nAppointments in the next 14 days:\n")
            soon.forEach { e ->
                val f = if (e.allDay) "EEEE d MMMM" else "EEEE d MMMM, HH:mm"
                append("- ").append(java.text.SimpleDateFormat(f, loc).format(java.util.Date(e.start))).append(": ").append(e.title).append('\n')
            }
        }
        val related = relatedNotes(question, 4)
        if (related.isNotEmpty()) {
            append("\nUser's notes that may help:\n")
            related.forEach { n ->
                append("\n### ").append(n.title.ifBlank { "Untitled" })
                if (n.folder.isNotEmpty()) append(" (folder ").append(n.folder.replace("/", " › ")).append(')')
                append('\n').append(n.content.take(1200))
                if (n.content.length > 1200) append(" […]")
                append('\n')
            }
        }
        lastAiExchange?.let { (q, a) ->
            append("\nPrevious exchange:\nUser: ").append(q).append("\nAssistant: ").append(a.take(600)).append('\n')
        }
        append("\nUser: ").append(question)
    }

    private fun aiPromptFr(question: String): String = buildString {
        val now = System.currentTimeMillis()
        val fr = java.util.Locale.FRANCE
        append("Nous sommes le ")
        append(java.text.SimpleDateFormat("EEEE d MMMM yyyy, HH'h'mm", fr).format(java.util.Date(now)))
        append(".\n")

        val soon = _events.value.filter { it.start >= now - 3_600_000 && it.start <= now + 14 * 86_400_000L }.take(12)
        if (soon.isNotEmpty()) {
            append("\nRendez-vous des 14 prochains jours :\n")
            soon.forEach { e ->
                val f = if (e.allDay) "EEEE d MMMM" else "EEEE d MMMM 'à' HH'h'mm"
                append("- ").append(java.text.SimpleDateFormat(f, fr).format(java.util.Date(e.start))).append(" : ").append(e.title).append('\n')
            }
        }

        val related = relatedNotes(question, 4)
        if (related.isNotEmpty()) {
            append("\nNotes de l'utilisateur qui peuvent servir :\n")
            related.forEach { n ->
                append("\n### ").append(n.title.ifBlank { "Sans titre" })
                if (n.folder.isNotEmpty()) append(" (dossier ").append(n.folder.replace("/", " › ")).append(')')
                append('\n').append(n.content.take(1200))
                if (n.content.length > 1200) append(" […]")
                append('\n')
            }
        }

        lastAiExchange?.let { (q, a) ->
            append("\nÉchange précédent :\nQuestion : ").append(q).append("\nRéponse : ").append(a.take(600)).append('\n')
        }
        append("\nQuestion : ").append(question)
    }

    /** Notes les plus proches de la question (mots en commun, titre compté double). */
    private fun relatedNotes(question: String, max: Int): List<Note> {
        val norm = fr.jeremy.calepin.search.TextNorm::norm
        val words = norm(question).split(Regex("[^\\p{L}\\d]+"))
            .filter { it.length >= 3 && it !in AI_STOPWORDS }
            .distinct()
        if (words.isEmpty()) return emptyList()
        return notes.value.map { n ->
            val t = norm(n.title)
            val c = norm(n.content)
            n to words.sumOf { w ->
                val direct = (if (w in t) 4 else 0) + (if (w in c) 2 else 0)
                // Mots de la même famille : « voiture » retrouve aussi la note sur le garage
                direct + if (direct == 0 && fr.jeremy.calepin.search.Synonyms.related(w).any { r -> r in t || r in c }) 1 else 0
            }
        }.filter { it.second > 0 }
            .sortedWith(compareByDescending<Pair<Note, Int>> { it.second }.thenByDescending { it.first.updatedAt })
            .take(max)
            .map { it.first }
    }

    // ------------------------------------------------- Sauvegarde complète

    /** Notes, dossiers, agenda, pièces jointes et mémos (références), pour la sauvegarde complète. */
    private fun exportData(): org.json.JSONObject {
        val o = org.json.JSONObject()
        o.put("notes", org.json.JSONArray().apply {
            db.all().forEach { n ->
                put(org.json.JSONObject().put("id", n.id).put("title", n.title).put("content", n.content).put("tag", n.tag)
                    .put("pinned", n.pinned).put("folder", n.folder).put("createdAt", n.createdAt).put("updatedAt", n.updatedAt))
            }
        })
        o.put("folders", org.json.JSONArray(db.folders()))
        o.put("attachments", org.json.JSONArray().apply {
            db.attachments().forEach { a -> put(org.json.JSONObject().put("noteId", a.noteId).put("file", a.fileName).put("video", a.isVideo).put("createdAt", a.createdAt)) }
        })
        o.put("recordings", org.json.JSONArray().apply {
            db.recordings().forEach { r ->
                put(org.json.JSONObject().put("noteId", r.noteId).put("file", r.fileName).put("format", r.format)
                    .put("duration", r.durationMs).put("createdAt", r.createdAt).put("transcript", r.transcript))
            }
        })
        o.put("events", org.json.JSONArray().apply {
            db.events().forEach { e ->
                put(org.json.JSONObject().put("noteId", e.noteId).put("title", e.title).put("start", e.start).put("allDay", e.allDay)
                    .put("remind", e.remindMinutes).put("alarm", e.alarm).put("ringtone", e.ringtone).put("createdAt", e.createdAt)
                    .put("end", e.end).put("category", e.category))
            }
        })
        return o
    }

    /** Ajoute le contenu d'une sauvegarde sans doublon ; renvoie le nombre de notes ajoutées. */
    private fun importData(o: org.json.JSONObject): Int {
        val existing = db.all().associateBy { it.title.trim() to it.content.trim() }
        val idMap = HashMap<Long, Long>()
        var added = 0
        o.optJSONArray("notes")?.let { a ->
            for (i in 0 until a.length()) {
                val n = a.getJSONObject(i)
                val key = n.optString("title").trim() to n.optString("content").trim()
                val old = n.optLong("id")
                val found = existing[key]
                if (found != null) { idMap[old] = found.id; continue }
                val id = db.upsert(
                    Note(
                        title = n.optString("title"), content = n.optString("content"), tag = n.optString("tag"),
                        pinned = n.optBoolean("pinned"), folder = n.optString("folder"),
                        createdAt = n.optLong("createdAt"), updatedAt = n.optLong("updatedAt"),
                    )
                )
                idMap[old] = id
                added++
            }
        }
        o.optJSONArray("folders")?.let { a -> for (i in 0 until a.length()) db.addFolder(a.optString(i)) }
        val haveAtt = db.attachments().map { it.fileName }.toSet()
        o.optJSONArray("attachments")?.let { a ->
            for (i in 0 until a.length()) {
                val x = a.getJSONObject(i)
                val nid = idMap[x.optLong("noteId")] ?: continue
                if (x.optString("file") in haveAtt) continue
                db.insertAttachment(Attachment(noteId = nid, fileName = x.optString("file"), isVideo = x.optBoolean("video"), createdAt = x.optLong("createdAt")))
            }
        }
        val haveRec = db.recordings().map { it.fileName }.toSet()
        o.optJSONArray("recordings")?.let { a ->
            for (i in 0 until a.length()) {
                val x = a.getJSONObject(i)
                val nid = idMap[x.optLong("noteId")] ?: continue
                if (x.optString("file") in haveRec) continue
                val rid = db.insertRecording(Recording(noteId = nid, fileName = x.optString("file"), format = x.optString("format"), durationMs = x.optLong("duration"), createdAt = x.optLong("createdAt")))
                x.optString("transcript").takeIf { it.isNotBlank() }?.let { db.setTranscript(rid, it) }
            }
        }
        val haveEv = db.events().map { Triple(it.start, it.end, it.title) }.toSet()
        o.optJSONArray("events")?.let { a ->
            for (i in 0 until a.length()) {
                val x = a.getJSONObject(i)
                val e = Event(
                    noteId = idMap[x.optLong("noteId")] ?: 0L, title = x.optString("title"), start = x.optLong("start"),
                    allDay = x.optBoolean("allDay"), remindMinutes = x.optInt("remind", -1), alarm = x.optBoolean("alarm"),
                    ringtone = x.optString("ringtone"), createdAt = x.optLong("createdAt"), end = x.optLong("end"), category = x.optString("category"),
                )
                if (Triple(e.start, e.end, e.title) in haveEv) continue
                val id = db.upsertEvent(e)
                Reminders.schedule(getApplication(), e.copy(id = id))
            }
        }
        return added
    }

    /** Sauvegarde complète vers le fichier choisi (Drive, Téléchargements…). */
    suspend fun backupTo(uri: Uri, password: String?, onProgress: (String) -> Unit): Result<Unit> = withContext(Dispatchers.IO) {
        runCatching {
            val ctx = getApplication<Application>()
            val out = ctx.contentResolver.openOutputStream(uri, "wt") ?: error("Impossible d'écrire le fichier.")
            fr.jeremy.calepin.export.FullBackup.write(ctx, out, exportData(), password, onProgress)
            ctx.getSharedPreferences("calepin", Context.MODE_PRIVATE).edit().putLong("last_backup", System.currentTimeMillis()).apply()
        }
    }

    /** Copie le fichier choisi en local et dit s'il demande un mot de passe. */
    suspend fun stageBackup(uri: Uri): Result<Pair<File, Boolean>> = withContext(Dispatchers.IO) {
        runCatching {
            val ctx = getApplication<Application>()
            val f = File(File(ctx.cacheDir, "backups").apply { mkdirs() }, "restore.calepin")
            ctx.contentResolver.openInputStream(uri)?.use { input -> f.outputStream().use { input.copyTo(it) } } ?: error("Fichier illisible.")
            f to fr.jeremy.calepin.export.FullBackup.isEncrypted(f)
        }
    }

    /** Restaure : ajoute ce qui manque (rien n'est effacé). Renvoie un résumé. */
    suspend fun restoreFrom(file: File, password: String?): Result<String> = withContext(Dispatchers.IO) {
        runCatching {
            val ctx = getApplication<Application>()
            val r = fr.jeremy.calepin.export.FullBackup.read(ctx, file, password)
            val notes = r.data?.let { importData(it) } ?: 0
            r.pro?.let { p ->
                val store = fr.jeremy.calepin.pro.ProStore.get(ctx)
                p.optJSONArray("clients")?.let { a -> for (i in 0 until a.length()) store.upsert(fr.jeremy.calepin.pro.Client.fromJson(a.getJSONObject(i))) }
                p.optJSONArray("interventions")?.let { a -> for (i in 0 until a.length()) store.upsert(fr.jeremy.calepin.pro.Intervention.fromJson(a.getJSONObject(i))) }
            }
            file.delete()
            refresh()
            "$notes note(s) ajoutée(s), ${r.files} fichier(s) récupéré(s) (photos, mémos…). Redémarre Calepin pour appliquer les réglages et le thème."
        }
    }

    fun lastBackup(): Long = getApplication<Application>().getSharedPreferences("calepin", Context.MODE_PRIVATE).getLong("last_backup", 0L)

    // ------------------------------------------------------------- Export

    suspend fun export(format: ExportFormat, list: List<Note>): ByteArray = withContext(Dispatchers.Default) {
        if (format == ExportFormat.PDF) PdfExport.build(list) else Exporters.build(format, list, ::entitiesOf)
    }

    /** Restaure une sauvegarde : ajoute les notes absentes (même titre et même texte = déjà présente). */
    suspend fun restore(text: String): Int = importNotes(Backup.parse(text))

    /** Ajoute des notes venues d'ailleurs, sans doublon (même titre et même texte = déjà présente). Renvoie le nombre ajouté. */
    suspend fun importNotes(incoming: List<Note>): Int = withContext(Dispatchers.IO) {
        val existing = db.all().map { it.title.trim() to it.content.trim() }.toMutableSet()
        var added = 0
        incoming.forEach { n ->
            if (existing.add(n.title.trim() to n.content.trim())) { db.upsert(n); added++ }
        }
        refresh()
        added
    }

    private companion object {
        const val AI_SYSTEM =
            "Tu es l'assistant de Calepin, une appli de notes personnelle, et tu fonctionnes entièrement sur le téléphone. " +
                "Réponds toujours en français, de façon brève et concrète (quelques phrases au plus), en tutoyant. " +
                "Quand des notes ou des rendez-vous sont fournis, appuie-toi d'abord sur eux. " +
                "Si l'information demandée n'y figure pas, dis-le simplement au lieu d'inventer. " +
                "Tu ne peux rien créer, modifier ni supprimer toi-même, et tu ne dois JAMAIS dire que c'est fait. " +
                "Pour une action dans l'appli (note, rappel, rendez-vous, suppression dans l'agenda, appel…), réponds uniquement par une ligne " +
                "« ACTION: » suivie de la commande, par exemple « ACTION: note que… », « ACTION: rappelle-moi demain à 9h de… », " +
                "« ACTION: supprime tout ce qui est prévu dans l'agenda », « ACTION: supprime les rendez-vous de demain », " +
                "« ACTION: annule le rendez-vous chez le dentiste » ; Calepin l'exécute et demande confirmation avant toute suppression. " +
                "Exception : si la demande consiste à commander la télévision ou le téléphone, réponds uniquement par une ligne " +
                "« ACTION: » suivie d'une seule commande simple, par exemple « ACTION: allume la télé », « ACTION: mets France 2 », " +
                "« ACTION: mets Netflix sur la télé », « ACTION: monte le son de la télé », « ACTION: ouvre YouTube », " +
                "« ACTION: cherche musique relaxante sur youtube », « ACTION: allume la lampe du salon », " +
                "« ACTION: éteins toutes les lumières », « ACTION: active ne pas déranger », " +
                "« ACTION: thème océan », « ACTION: thème cyberpunk », « ACTION: thème dark fantasy », « ACTION: thème aléatoire », « ACTION: icônes néon », « ACTION: police machine à écrire », « ACTION: mode sombre », « ACTION: texte plus grand », « ACTION: ouvre la télécommande », " +
                "« ACTION: envoie un WhatsApp à Marc : j'arrive dans 10 minutes ». Pour un message WhatsApp, rédige toi-même " +
                "le texte demandé après les deux-points ; l'utilisateur confirmera avant l'envoi."
        val AI_STOPWORDS = setOf(
            "les", "des", "une", "est", "que", "qui", "quoi", "pour", "dans", "avec", "sur", "par", "pas", "mes", "mon", "ma",
            "ton", "tes", "ses", "son", "sa", "aux", "du", "de", "la", "le", "et", "ou", "en", "au", "ce", "ces", "cette",
            "quel", "quelle", "quels", "quelles", "comment", "combien", "quand", "est-ce", "estce", "j'ai", "jai", "moi", "toi",
            "faire", "fait", "dois", "doit", "peux", "peut", "suis", "etre", "avoir", "ont", "sont", "plus", "tout", "tous",
            "ma", "note", "notes", "dis", "dit", "resume", "resumer", "explique", "prevu", "prevue",
        )
    }

    private fun seedIfFirstLaunch() {
        val prefs = getApplication<Application>().getSharedPreferences("calepin", Context.MODE_PRIVATE)
        if (prefs.getBoolean("seeded", false)) return
        val now = System.currentTimeMillis()
        listOf(
            Note(
                title = "Visite villa Cap-Martin",
                content = "Visite de la villa avec M. Rossi le 14 octobre à 10h30.\n" +
                    "Adresse : 12 avenue Winston Churchill, 06190 Roquebrune-Cap-Martin\n" +
                    "Tél : 06 12 34 56 78\nMail : rossi.exemple@gmail.com\n" +
                    "Prévoir les clés et le relevé des compteurs.",
                tag = "Exemple, Clients", pinned = true, createdAt = now - 3_600_000, updatedAt = now - 3_600_000,
            ),
            Note(
                title = "Fournisseurs Monaco",
                content = "Pressing du port : +377 93 50 12 34\nPlombier (urgence) : 07 98 76 54 32\n" +
                    "Électricien à rappeler mardi à 9h.\nSite du pressing : www.exemple-pressing.mc",
                tag = "Exemple, Fournisseurs", createdAt = now - 7_200_000, updatedAt = now - 7_200_000,
            ),
            Note(
                title = "Courses marché",
                content = "Marché demain 18h, place aux Herbes, 06500 Menton.\nŒufs, pâtes fraîches, café, citrons.",
                tag = "Exemple, Perso", createdAt = now - 10_800_000, updatedAt = now - 10_800_000,
            ),
        ).forEach { db.upsert(it) }
        prefs.edit().putBoolean("seeded", true).apply()
    }
}
