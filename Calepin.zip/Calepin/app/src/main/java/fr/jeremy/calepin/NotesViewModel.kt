package fr.jeremy.calepin

import android.app.Application
import android.content.Context
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import fr.jeremy.calepin.data.Note
import fr.jeremy.calepin.data.NoteDb
import fr.jeremy.calepin.data.Recording
import fr.jeremy.calepin.audio.VoiceRecorder
import fr.jeremy.calepin.export.Backup
import fr.jeremy.calepin.export.ExportFormat
import fr.jeremy.calepin.export.Exporters
import fr.jeremy.calepin.export.PdfExport
import java.io.File
import fr.jeremy.calepin.detect.Entity
import fr.jeremy.calepin.detect.EntityDetector
import fr.jeremy.calepin.search.SearchEngine
import fr.jeremy.calepin.search.SearchOptions
import fr.jeremy.calepin.search.SearchResult
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.FlowPreview
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.debounce
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.concurrent.ConcurrentHashMap

@OptIn(FlowPreview::class)
class NotesViewModel(app: Application) : AndroidViewModel(app) {

    private val db = NoteDb(app)
    private val notes = MutableStateFlow<List<Note>>(emptyList())

    val settings = AppSettings(app)

    /** Identifiants des notes qui ont au moins un enregistrement vocal. */
    private val _withAudio = MutableStateFlow<Set<Long>>(emptySet())
    val withAudio: StateFlow<Set<Long>> = _withAudio

    val query = MutableStateFlow("")
    val options = MutableStateFlow(SearchOptions())

    private val entityCache = ConcurrentHashMap<Long, Pair<String, List<Entity>>>()

    fun entitiesOf(n: Note): List<Entity> {
        val cached = entityCache[n.id]
        if (cached != null && cached.first == n.content) return cached.second
        return EntityDetector.detect(n.content).also { entityCache[n.id] = n.content to it }
    }

    val results: StateFlow<List<SearchResult>> =
        combine(notes, query.debounce(120), options) { n, q, o ->
            SearchEngine.search(n, q, o, ::entitiesOf)
        }
            .flowOn(Dispatchers.Default)
            .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    val noteCount: StateFlow<Int> =
        notes.map { it.size }.stateIn(viewModelScope, SharingStarted.Eagerly, 0)

    val allTags: StateFlow<List<String>> =
        notes.map { list -> list.flatMap { it.tags }.distinctBy { it.lowercase() }.sortedBy { it.lowercase() } }
            .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    init {
        viewModelScope.launch {
            withContext(Dispatchers.IO) { seedIfFirstLaunch() }
            refresh()
        }
    }

    private suspend fun refresh() {
        val (n, a) = withContext(Dispatchers.IO) { db.all() to db.recordings().map { it.noteId }.toSet() }
        notes.value = n
        _withAudio.value = a
    }

    fun allNotes(): List<Note> = notes.value
    fun notesByIds(ids: Collection<Long>): List<Note> = notes.value.filter { it.id in ids }

    fun find(id: Long): Note? = notes.value.firstOrNull { it.id == id }

    fun setQuery(q: String) { query.value = q }
    fun updateOptions(f: SearchOptions.() -> SearchOptions) { options.value = options.value.f() }

    /** Écriture immédiate (petite requête SQLite) pour obtenir l'identifiant sans risque de doublon. */
    fun saveNow(n: Note): Long {
        val id = db.upsert(n)
        viewModelScope.launch { refresh() }
        return id
    }

    fun delete(id: Long) {
        viewModelScope.launch {
            withContext(Dispatchers.IO) { deleteRecordingsOf(id); db.delete(id) }
            entityCache.remove(id)
            refresh()
        }
    }

    fun deleteMany(ids: Set<Long>) {
        if (ids.isEmpty()) return
        viewModelScope.launch {
            withContext(Dispatchers.IO) { ids.forEach { deleteRecordingsOf(it); db.delete(it) } }
            ids.forEach { entityCache.remove(it) }
            refresh()
        }
    }

    fun togglePin(n: Note) {
        viewModelScope.launch {
            withContext(Dispatchers.IO) { db.upsert(n.copy(pinned = !n.pinned)) }
            refresh()
        }
    }

    // ----------------------------------------------------- Enregistrements

    private val recDir: File get() = VoiceRecorder.dir(getApplication())

    fun recordingsOf(noteId: Long): List<Recording> = if (noteId == 0L) emptyList() else db.recordings(noteId)
    fun fileOf(r: Recording): File = File(recDir, r.fileName)

    fun newRecordingFile(noteId: Long, format: AudioFormat): File =
        File(recDir, "note${noteId}_${System.currentTimeMillis()}.${format.ext}")

    fun addRecording(noteId: Long, file: File, format: AudioFormat, durationMs: Long) {
        db.insertRecording(Recording(noteId = noteId, fileName = file.name, format = format.name, durationMs = durationMs))
        viewModelScope.launch { refresh() }
    }

    fun deleteRecording(r: Recording) {
        fileOf(r).delete()
        db.deleteRecording(r.id)
        viewModelScope.launch { refresh() }
    }

    private fun deleteRecordingsOf(noteId: Long) {
        db.recordings(noteId).forEach { File(recDir, it.fileName).delete(); db.deleteRecording(it.id) }
    }

    // ------------------------------------------------------------- Export

    suspend fun export(format: ExportFormat, list: List<Note>): ByteArray = withContext(Dispatchers.Default) {
        if (format == ExportFormat.PDF) PdfExport.build(list) else Exporters.build(format, list, ::entitiesOf)
    }

    /** Restaure une sauvegarde : ajoute les notes absentes (même titre et même texte = déjà présente). */
    suspend fun restore(text: String): Int = withContext(Dispatchers.IO) {
        val incoming = Backup.parse(text)
        val existing = db.all().map { it.title to it.content }.toSet()
        var added = 0
        incoming.forEach { n ->
            if ((n.title to n.content) !in existing) { db.upsert(n); added++ }
        }
        refresh()
        added
    }

    private fun seedIfFirstLaunch() {
        val prefs = getApplication<Application>().getSharedPreferences("calepin", Context.MODE_PRIVATE)
        if (prefs.getBoolean("seeded", false)) return
        val now = System.currentTimeMillis()
        listOf(
            Note(
                title = "Visite villa Cap-Martin",
                content = "Visite de la villa avec M. Rossi le 14 octobre à 10h30.\n" +
                    "Adresse : 12 avenue Winston Churchill, 06190 Roquebrune-Cap-Martin\n" +
                    "Tél : 06 12 34 56 78\nMail : rossi.exemple@gmail.com\n" +
                    "Prévoir les clés et le relevé des compteurs.",
                tag = "Exemple, Clients", pinned = true, createdAt = now - 3_600_000, updatedAt = now - 3_600_000,
            ),
            Note(
                title = "Fournisseurs Monaco",
                content = "Pressing du port : +377 93 50 12 34\nPlombier (urgence) : 07 98 76 54 32\n" +
                    "Électricien à rappeler mardi à 9h.\nSite du pressing : www.exemple-pressing.mc",
                tag = "Exemple, Fournisseurs", createdAt = now - 7_200_000, updatedAt = now - 7_200_000,
            ),
            Note(
                title = "Courses marché",
                content = "Marché demain 18h, place aux Herbes, 06500 Menton.\nŒufs, pâtes fraîches, café, citrons.",
                tag = "Exemple, Perso", createdAt = now - 10_800_000, updatedAt = now - 10_800_000,
            ),
        ).forEach { db.upsert(it) }
        prefs.edit().putBoolean("seeded", true).apply()
    }
}
