package fr.jeremy.calepin

import android.app.Application
import android.content.Context
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import fr.jeremy.calepin.data.Note
import fr.jeremy.calepin.data.NoteDb
import fr.jeremy.calepin.data.Recording
import fr.jeremy.calepin.data.Attachment
import fr.jeremy.calepin.data.Event
import fr.jeremy.calepin.detect.EntityType
import fr.jeremy.calepin.media.Media
import fr.jeremy.calepin.reminders.Reminders
import android.net.Uri
import fr.jeremy.calepin.audio.VoiceRecorder
import fr.jeremy.calepin.export.Backup
import fr.jeremy.calepin.export.ExportFormat
import fr.jeremy.calepin.export.Exporters
import fr.jeremy.calepin.export.PdfExport
import java.io.File
import fr.jeremy.calepin.detect.Entity
import fr.jeremy.calepin.detect.EntityDetector
import fr.jeremy.calepin.search.SearchEngine
import fr.jeremy.calepin.search.SearchOptions
import fr.jeremy.calepin.search.SearchResult
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.FlowPreview
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.debounce
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.concurrent.ConcurrentHashMap

@OptIn(FlowPreview::class)
class NotesViewModel(app: Application) : AndroidViewModel(app) {

    private val db = NoteDb(app)
    private val notes = MutableStateFlow<List<Note>>(emptyList())

    val settings = AppSettings(app)

    /** Identifiants des notes qui ont au moins un enregistrement vocal. */
    private val _withAudio = MutableStateFlow<Set<Long>>(emptySet())
    val withAudio: StateFlow<Set<Long>> = _withAudio

    /** Notes qui ont au moins une photo ou une vidéo. */
    private val _withMedia = MutableStateFlow<Set<Long>>(emptySet())
    val withMedia: StateFlow<Set<Long>> = _withMedia

    /** Vrai une fois les notes chargées depuis la base. */
    val loaded = MutableStateFlow(false)

    /** Rendez-vous de l'agenda Calepin. */
    private val _events = MutableStateFlow<List<Event>>(emptyList())
    val events: StateFlow<List<Event>> = _events

    val query = MutableStateFlow("")
    val options = MutableStateFlow(SearchOptions())

    private val entityCache = ConcurrentHashMap<Long, Pair<String, List<Entity>>>()

    fun entitiesOf(n: Note): List<Entity> {
        val cached = entityCache[n.id]
        if (cached != null && cached.first == n.content) return cached.second
        return EntityDetector.detect(n.content).also { entityCache[n.id] = n.content to it }
    }

    /** Dossier affiché : null = toutes les notes, "" = notes sans dossier, sinon chemin « A/B ». */
    val currentFolder = MutableStateFlow<String?>(null)

    /** Dossiers créés à la main (même vides). */
    private val createdFolders = MutableStateFlow<List<String>>(emptyList())

    /** Tous les dossiers (créés ou utilisés par une note), parents compris, triés. */
    val folders: StateFlow<List<String>> =
        combine(notes, createdFolders) { n, f ->
            (n.map { it.folder } + f).filter { it.isNotBlank() }
                .flatMap { path -> path.split('/').runningReduce { acc, part -> "$acc/$part" } }
                .distinct()
                .sortedWith(compareBy(String.CASE_INSENSITIVE_ORDER) { it })
        }.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    val results: StateFlow<List<SearchResult>> =
        combine(notes, query.debounce(120), options, currentFolder) { n, q, o, f ->
            // En recherche, un dossier inclut ses sous-dossiers ; en navigation, seulement ses propres notes
            val inFolder = when {
                f == null -> n
                f.isEmpty() -> n.filter { it.folder.isEmpty() }
                q.isBlank() -> n.filter { it.folder == f }
                else -> n.filter { it.folder == f || it.folder.startsWith("$f/") }
            }
            SearchEngine.search(inFolder, q, o, ::entitiesOf)
        }
            .flowOn(Dispatchers.Default)
            .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    val noteCount: StateFlow<Int> =
        notes.map { it.size }.stateIn(viewModelScope, SharingStarted.Eagerly, 0)

    val allTags: StateFlow<List<String>> =
        notes.map { list -> list.flatMap { it.tags }.distinctBy { it.lowercase() }.sortedBy { it.lowercase() } }
            .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    init {
        viewModelScope.launch {
            withContext(Dispatchers.IO) { seedIfFirstLaunch() }
            refresh()
        }
    }

    private suspend fun refresh() {
        withContext(Dispatchers.IO) {
            val n = db.all()
            val a = db.recordings().map { it.noteId }.toSet()
            val m = db.attachments().map { it.noteId }.toSet()
            val e = db.events()
            createdFolders.value = db.folders()
            notes.value = n
            _withAudio.value = a
            _withMedia.value = m
            _events.value = e
            loaded.value = true
        }
    }

    fun allNotes(): List<Note> = notes.value
    fun notesByIds(ids: Collection<Long>): List<Note> = notes.value.filter { it.id in ids }

    fun find(id: Long): Note? = notes.value.firstOrNull { it.id == id }

    /** Notes qui citent ce contact : un de ses numéros (quel que soit le format) ou son nom complet. */
    fun notesForContact(name: String, phones: List<String>): List<Note> {
        val keys = phones.map { p -> p.filter { it.isDigit() } }.filter { it.length >= 8 }.map { it.takeLast(8) }.toSet()
        val n = fr.jeremy.calepin.search.TextNorm.norm(name).trim()
        return notes.value.filter { note ->
            (n.length >= 3 && fr.jeremy.calepin.search.TextNorm.norm(note.title + "\n" + note.content).contains(n)) ||
                (keys.isNotEmpty() && entitiesOf(note).any { e ->
                    e.type == EntityType.PHONE && e.value.filter { it.isDigit() }.takeLast(8) in keys
                })
        }
    }

    fun setQuery(q: String) { query.value = q }
    fun updateOptions(f: SearchOptions.() -> SearchOptions) { options.value = options.value.f() }

    /** Écriture immédiate (petite requête SQLite) pour obtenir l'identifiant sans risque de doublon. */
    fun saveNow(n: Note): Long {
        val id = db.upsert(n)
        viewModelScope.launch { refresh() }
        return id
    }

    fun delete(id: Long) {
        viewModelScope.launch {
            withContext(Dispatchers.IO) { deleteRecordingsOf(id); deleteExtrasOf(id); db.delete(id) }
            entityCache.remove(id)
            refresh()
        }
    }

    fun deleteMany(ids: Set<Long>) {
        if (ids.isEmpty()) return
        viewModelScope.launch {
            withContext(Dispatchers.IO) { ids.forEach { deleteRecordingsOf(it); deleteExtrasOf(it); db.delete(it) } }
            ids.forEach { entityCache.remove(it) }
            refresh()
        }
    }

    // ------------------------------------------------------------- Dossiers

    fun openFolder(path: String?) { currentFolder.value = path }

    /** Nombre de notes directement dans chaque dossier. */
    fun countIn(path: String): Int = notes.value.count { it.folder == path }

    fun createFolder(path: String) {
        viewModelScope.launch {
            withContext(Dispatchers.IO) { db.addFolder(path) }
            refresh()
        }
    }

    fun renameFolder(from: String, to: String) {
        viewModelScope.launch {
            withContext(Dispatchers.IO) { db.renameFolder(from, to) }
            val cur = currentFolder.value
            if (cur != null && (cur == from || cur.startsWith("$from/"))) currentFolder.value = to + cur.substring(from.length)
            refresh()
        }
    }

    fun deleteFolder(path: String) {
        viewModelScope.launch {
            withContext(Dispatchers.IO) { db.deleteFolder(path) }
            val cur = currentFolder.value
            if (cur != null && (cur == path || cur.startsWith("$path/"))) currentFolder.value = path.substringBeforeLast('/', "").ifEmpty { null }
            refresh()
        }
    }

    fun moveNotes(ids: Collection<Long>, folder: String) {
        if (ids.isEmpty()) return
        viewModelScope.launch {
            withContext(Dispatchers.IO) {
                if (folder.isNotEmpty()) db.addFolder(folder)
                db.moveNotes(ids, folder)
            }
            refresh()
        }
    }

    fun togglePin(n: Note) {
        viewModelScope.launch {
            withContext(Dispatchers.IO) { db.upsert(n.copy(pinned = !n.pinned)) }
            refresh()
        }
    }

    // ----------------------------------------------------- Enregistrements

    private val recDir: File get() = VoiceRecorder.dir(getApplication())

    fun recordingsOf(noteId: Long): List<Recording> = if (noteId == 0L) emptyList() else db.recordings(noteId)
    fun fileOf(r: Recording): File = File(recDir, r.fileName)

    fun newRecordingFile(noteId: Long, format: AudioFormat): File =
        File(recDir, "note${noteId}_${System.currentTimeMillis()}.${format.ext}")

    fun addRecording(noteId: Long, file: File, format: AudioFormat, durationMs: Long) {
        db.insertRecording(Recording(noteId = noteId, fileName = file.name, format = format.name, durationMs = durationMs))
        viewModelScope.launch { refresh() }
    }

    fun deleteRecording(r: Recording) {
        fileOf(r).delete()
        db.deleteRecording(r.id)
        viewModelScope.launch { refresh() }
    }

    private fun deleteRecordingsOf(noteId: Long) {
        db.recordings(noteId).forEach { File(recDir, it.fileName).delete(); db.deleteRecording(it.id) }
    }

    fun setTranscript(r: Recording, text: String) {
        db.setTranscript(r.id, text)
    }

    // ------------------------------------------------------ Photos, vidéos

    fun attachmentsOf(noteId: Long): List<Attachment> = if (noteId == 0L) emptyList() else db.attachments(noteId)
    fun fileOf(a: Attachment): File = File(Media.dir(getApplication()), a.fileName)

    suspend fun importMedia(noteId: Long, uris: List<Uri>): Int = withContext(Dispatchers.IO) {
        var n = 0
        uris.forEach { u ->
            Media.importUri(getApplication(), u)?.let { (f, video) ->
                db.insertAttachment(Attachment(noteId = noteId, fileName = f.name, isVideo = video)); n++
            }
        }
        refresh()
        n
    }

    /** Photo ou vidéo prise avec l'appareil, déjà écrite dans [f]. */
    fun addCaptured(noteId: Long, f: File, video: Boolean) {
        if (!f.exists() || f.length() == 0L) { f.delete(); return }
        db.insertAttachment(Attachment(noteId = noteId, fileName = f.name, isVideo = video))
        viewModelScope.launch { refresh() }
    }

    fun deleteAttachment(a: Attachment) {
        fileOf(a).delete()
        db.deleteAttachment(a.id)
        viewModelScope.launch { refresh() }
    }

    // ------------------------------------------------------------- Agenda

    fun saveEvent(e: Event): Event {
        val id = db.upsertEvent(e)
        val saved = e.copy(id = id)
        Reminders.schedule(getApplication(), saved)
        viewModelScope.launch { refresh() }
        return saved
    }

    fun deleteEvent(e: Event) {
        Reminders.cancel(getApplication(), e.id)
        db.deleteEvent(e.id)
        viewModelScope.launch { refresh() }
    }

    /** Dates reconnues automatiquement dans le texte des notes (pour le calendrier). */
    data class DetectedDate(val note: Note, val time: Long, val hasTime: Boolean, val text: String, val end: Long? = null)

    fun detectedDates(): List<DetectedDate> = notes.value.flatMap { n ->
        entitiesOf(n).filter { it.type == EntityType.DATE && it.timeMillis != null }
            .map { DetectedDate(n, it.timeMillis!!, it.hasTime, it.text, it.endMillis) }
    }

    /** Ajoute plusieurs rendez-vous d'un coup (planning importé) ; ignore ceux déjà présents. Renvoie le nombre ajouté. */
    suspend fun saveEvents(list: List<Event>): Int = withContext(Dispatchers.IO) {
        val existing = db.events().map { Triple(it.start, it.end, it.title) }.toSet()
        var n = 0
        list.forEach { e ->
            if (Triple(e.start, e.end, e.title) !in existing) {
                val id = db.upsertEvent(e)
                Reminders.schedule(getApplication(), e.copy(id = id))
                n++
            }
        }
        refresh()
        n
    }

    private fun deleteExtrasOf(noteId: Long) {
        db.attachments(noteId).forEach { File(Media.dir(getApplication()), it.fileName).delete(); db.deleteAttachment(it.id) }
        db.events().filter { it.noteId == noteId }.forEach { Reminders.cancel(getApplication(), it.id); db.deleteEvent(it.id) }
    }

    // ----------------------------------------------------------- Assistant

    data class ChatMsg(val fromUser: Boolean, val text: String)

    private val assistant = fr.jeremy.calepin.assistant.Assistant(fr.jeremy.calepin.assistant.DbAssistantData(app))
    private val _chat = MutableStateFlow(
        listOf(ChatMsg(false, "Bonjour ! Demande-moi par exemple « Qu'est-ce que j'ai demain ? » ou dis « aide »."))
    )
    val chat: StateFlow<List<ChatMsg>> = _chat

    /** Traite une demande (écrite ou dictée) ; les notes et l'agenda sont rafraîchis ensuite. */
    suspend fun ask(text: String): fr.jeremy.calepin.assistant.Reply {
        _chat.value = _chat.value + ChatMsg(true, text)
        // Calepin IA : commandes de la télé, du décodeur et du téléphone, reconnues directement
        if (BuildConfig.AI && !assistant.isWaiting) {
            val done = runCatching { devices.handle(text) }.getOrNull()
            if (done != null) {
                _chat.value = _chat.value + ChatMsg(false, done.text)
                return fr.jeremy.calepin.assistant.Reply(done.text)
            }
        }
        val r = withContext(Dispatchers.IO) { assistant.handle(text) }
        // Calepin IA : quand aucune commande n'est reconnue, le modèle hors ligne répond
        if (!r.understood && BuildConfig.AI) {
            val ctx = getApplication<Application>()
            val model = fr.jeremy.calepin.ai.AiModels.active(ctx)
            val engine = fr.jeremy.calepin.ai.AiEngineFactory.get(ctx)
            if (model != null && engine != null) {
                val answer = askAi(engine, fr.jeremy.calepin.ai.AiModels.file(ctx, model).path, text)
                refresh()
                return r.copy(text = answer, understood = true)
            }
            val hint = r.text + "\n\nPour que je réponde à tout, installe un modèle d'IA dans Paramètres → Intelligence artificielle."
            _chat.value = _chat.value + ChatMsg(false, hint)
            return r.copy(text = hint)
        }
        _chat.value = _chat.value + ChatMsg(false, r.text)
        refresh()
        return r
    }

    fun addAssistantMessage(text: String) { _chat.value = _chat.value + ChatMsg(false, text) }
    fun clearChat() { _chat.value = _chat.value.take(1); lastAiExchange = null }

    // ------------------------------------------------- IA hors ligne (Calepin IA)

    private val devices by lazy { fr.jeremy.calepin.control.DeviceCommands(getApplication()) }

    /** Vrai pendant qu'une réponse de l'IA s'écrit. */
    val aiWorking = MutableStateFlow(false)
    private var lastAiExchange: Pair<String, String>? = null

    /** Téléchargement d'un modèle en cours (ou en échec, avec [AiDownload.error]). */
    data class AiDownload(val modelId: String, val done: Long, val total: Long, val error: String? = null)

    val aiDownload = MutableStateFlow<AiDownload?>(null)
    /** Change à chaque installation ou suppression de modèle, pour rafraîchir l'écran. */
    val aiModelsVersion = MutableStateFlow(0)
    private var aiJob: kotlinx.coroutines.Job? = null

    fun startAiDownload(m: fr.jeremy.calepin.ai.AiModel) {
        if (aiJob?.isActive == true) return
        val ctx = getApplication<Application>()
        aiJob = viewModelScope.launch {
            val start = fr.jeremy.calepin.ai.AiModels.partialBytes(ctx, m)
            aiDownload.value = AiDownload(m.id, start, m.bytes)
            try {
                fr.jeremy.calepin.ai.AiModels.download(ctx, m) { d, t -> aiDownload.value = AiDownload(m.id, d, t) }
                aiDownload.value = null
            } catch (e: kotlinx.coroutines.CancellationException) {
                aiDownload.value = null
                throw e
            } catch (e: Exception) {
                aiDownload.value = AiDownload(
                    m.id, fr.jeremy.calepin.ai.AiModels.partialBytes(ctx, m), m.bytes,
                    e.message ?: "Connexion interrompue",
                )
            }
            aiModelsVersion.value++
        }
    }

    /** Met le téléchargement en pause : la partie reçue est gardée pour reprendre. */
    fun pauseAiDownload() {
        aiJob?.cancel()
        aiModelsVersion.value++
    }

    fun selectAiModel(m: fr.jeremy.calepin.ai.AiModel) {
        fr.jeremy.calepin.ai.AiModels.select(getApplication(), m)
        aiModelsVersion.value++
    }

    fun deleteAiModel(m: fr.jeremy.calepin.ai.AiModel) {
        if (aiWorking.value) stopAi()
        fr.jeremy.calepin.ai.AiEngineFactory.get(getApplication())?.release()
        fr.jeremy.calepin.ai.AiModels.delete(getApplication(), m)
        aiModelsVersion.value++
    }

    fun stopAi() {
        fr.jeremy.calepin.ai.AiEngineFactory.get(getApplication())?.stop()
    }

    private suspend fun askAi(engine: fr.jeremy.calepin.ai.AiEngine, modelPath: String, question: String): String {
        val placeholder = ChatMsg(false, "…")
        _chat.value = _chat.value + placeholder
        val pos = _chat.value.lastIndex
        fun show(t: String) {
            val list = _chat.value
            if (pos < list.size && !list[pos].fromUser) {
                _chat.value = list.mapIndexed { i, m -> if (i == pos) ChatMsg(false, t) else m }
            }
        }
        aiWorking.value = true
        var partial = ""
        val answer = try {
            show("Je réfléchis… (le premier message charge le modèle, quelques secondes)")
            val prompt = withContext(Dispatchers.Default) { aiPrompt(question) }
            engine.generate(modelPath, AI_SYSTEM, prompt) { t -> partial = t; show(t) }.trim()
        } catch (e: Throwable) {
            if (e is kotlinx.coroutines.CancellationException && partial.isEmpty()) throw e
            if (partial.isNotBlank()) partial.trim() + " […]"
            else "L'IA n'a pas pu répondre (${e.message ?: e.javaClass.simpleName}). Le téléphone manque peut-être de mémoire : " +
                "fermez d'autres applis ou choisissez le modèle Qwen, plus léger."
        } finally {
            aiWorking.value = false
        }
        // L'IA peut demander une commande d'appareil : « ACTION: allume la télé »
        val action = Regex("(?im)^\\s*ACTION\\s*:\\s*(.+)$").find(answer)?.groupValues?.get(1)?.trim()?.trim('«', '»', '"', ' ')
        if (action != null) {
            val done = runCatching { devices.handle(action) }.getOrNull()
            val t = done?.text ?: "Je n'ai pas su faire « $action »."
            show(t)
            lastAiExchange = question to t
            return t
        }
        val finalText = answer.ifBlank { "Je n'ai pas de réponse à proposer." }
        show(finalText)
        lastAiExchange = question to finalText
        return finalText
    }

    /** Question + contexte : date du jour, rendez-vous à venir et notes qui semblent liées. */
    private fun aiPrompt(question: String): String = buildString {
        val now = System.currentTimeMillis()
        val fr = java.util.Locale.FRANCE
        append("Nous sommes le ")
        append(java.text.SimpleDateFormat("EEEE d MMMM yyyy, HH'h'mm", fr).format(java.util.Date(now)))
        append(".\n")

        val soon = _events.value.filter { it.start >= now - 3_600_000 && it.start <= now + 14 * 86_400_000L }.take(12)
        if (soon.isNotEmpty()) {
            append("\nRendez-vous des 14 prochains jours :\n")
            soon.forEach { e ->
                val f = if (e.allDay) "EEEE d MMMM" else "EEEE d MMMM 'à' HH'h'mm"
                append("- ").append(java.text.SimpleDateFormat(f, fr).format(java.util.Date(e.start))).append(" : ").append(e.title).append('\n')
            }
        }

        val related = relatedNotes(question, 3)
        if (related.isNotEmpty()) {
            append("\nNotes de l'utilisateur qui peuvent servir :\n")
            related.forEach { n ->
                append("\n### ").append(n.title.ifBlank { "Sans titre" })
                if (n.folder.isNotEmpty()) append(" (dossier ").append(n.folder.replace("/", " › ")).append(')')
                append('\n').append(n.content.take(1200))
                if (n.content.length > 1200) append(" […]")
                append('\n')
            }
        }

        lastAiExchange?.let { (q, a) ->
            append("\nÉchange précédent :\nQuestion : ").append(q).append("\nRéponse : ").append(a.take(600)).append('\n')
        }
        append("\nQuestion : ").append(question)
    }

    /** Notes les plus proches de la question (mots en commun, titre compté double). */
    private fun relatedNotes(question: String, max: Int): List<Note> {
        val norm = fr.jeremy.calepin.search.TextNorm::norm
        val words = norm(question).split(Regex("[^\\p{L}\\d]+"))
            .filter { it.length >= 3 && it !in AI_STOPWORDS }
            .distinct()
        if (words.isEmpty()) return emptyList()
        return notes.value.map { n ->
            val t = norm(n.title)
            val c = norm(n.content)
            n to words.sumOf { w -> (if (w in t) 2 else 0) + (if (w in c) 1 else 0) }
        }.filter { it.second > 0 }
            .sortedWith(compareByDescending<Pair<Note, Int>> { it.second }.thenByDescending { it.first.updatedAt })
            .take(max)
            .map { it.first }
    }

    // ------------------------------------------------------------- Export

    suspend fun export(format: ExportFormat, list: List<Note>): ByteArray = withContext(Dispatchers.Default) {
        if (format == ExportFormat.PDF) PdfExport.build(list) else Exporters.build(format, list, ::entitiesOf)
    }

    /** Restaure une sauvegarde : ajoute les notes absentes (même titre et même texte = déjà présente). */
    suspend fun restore(text: String): Int = importNotes(Backup.parse(text))

    /** Ajoute des notes venues d'ailleurs, sans doublon (même titre et même texte = déjà présente). Renvoie le nombre ajouté. */
    suspend fun importNotes(incoming: List<Note>): Int = withContext(Dispatchers.IO) {
        val existing = db.all().map { it.title.trim() to it.content.trim() }.toMutableSet()
        var added = 0
        incoming.forEach { n ->
            if (existing.add(n.title.trim() to n.content.trim())) { db.upsert(n); added++ }
        }
        refresh()
        added
    }

    private companion object {
        const val AI_SYSTEM =
            "Tu es l'assistant de Calepin, une appli de notes personnelle, et tu fonctionnes entièrement sur le téléphone. " +
                "Réponds toujours en français, de façon brève et concrète (quelques phrases au plus), en tutoyant. " +
                "Quand des notes ou des rendez-vous sont fournis, appuie-toi d'abord sur eux. " +
                "Si l'information demandée n'y figure pas, dis-le simplement au lieu d'inventer. " +
                "Tu ne peux pas agir dans l'appli : pour créer une note, un rappel ou appeler quelqu'un, " +
                "propose la commande à dire, par exemple « note que… » ou « rappelle-moi demain à 9h de… ». " +
                "Exception : si la demande consiste à commander la télévision ou le téléphone, réponds uniquement par une ligne " +
                "« ACTION: » suivie d'une seule commande simple, par exemple « ACTION: allume la télé », « ACTION: mets France 2 », " +
                "« ACTION: mets Netflix sur la télé », « ACTION: monte le son de la télé », « ACTION: ouvre YouTube », " +
                "« ACTION: cherche musique relaxante sur youtube », « ACTION: allume la lampe du salon », " +
                "« ACTION: éteins toutes les lumières », « ACTION: active ne pas déranger », " +
                "« ACTION: envoie un WhatsApp à Marc : j'arrive dans 10 minutes ». Pour un message WhatsApp, rédige toi-même " +
                "le texte demandé après les deux-points ; l'utilisateur confirmera avant l'envoi."
        val AI_STOPWORDS = setOf(
            "les", "des", "une", "est", "que", "qui", "quoi", "pour", "dans", "avec", "sur", "par", "pas", "mes", "mon", "ma",
            "ton", "tes", "ses", "son", "sa", "aux", "du", "de", "la", "le", "et", "ou", "en", "au", "ce", "ces", "cette",
            "quel", "quelle", "quels", "quelles", "comment", "combien", "quand", "est-ce", "estce", "j'ai", "jai", "moi", "toi",
            "faire", "fait", "dois", "doit", "peux", "peut", "suis", "etre", "avoir", "ont", "sont", "plus", "tout", "tous",
            "ma", "note", "notes", "dis", "dit", "resume", "resumer", "explique", "prevu", "prevue",
        )
    }

    private fun seedIfFirstLaunch() {
        val prefs = getApplication<Application>().getSharedPreferences("calepin", Context.MODE_PRIVATE)
        if (prefs.getBoolean("seeded", false)) return
        val now = System.currentTimeMillis()
        listOf(
            Note(
                title = "Visite villa Cap-Martin",
                content = "Visite de la villa avec M. Rossi le 14 octobre à 10h30.\n" +
                    "Adresse : 12 avenue Winston Churchill, 06190 Roquebrune-Cap-Martin\n" +
                    "Tél : 06 12 34 56 78\nMail : rossi.exemple@gmail.com\n" +
                    "Prévoir les clés et le relevé des compteurs.",
                tag = "Exemple, Clients", pinned = true, createdAt = now - 3_600_000, updatedAt = now - 3_600_000,
            ),
            Note(
                title = "Fournisseurs Monaco",
                content = "Pressing du port : +377 93 50 12 34\nPlombier (urgence) : 07 98 76 54 32\n" +
                    "Électricien à rappeler mardi à 9h.\nSite du pressing : www.exemple-pressing.mc",
                tag = "Exemple, Fournisseurs", createdAt = now - 7_200_000, updatedAt = now - 7_200_000,
            ),
            Note(
                title = "Courses marché",
                content = "Marché demain 18h, place aux Herbes, 06500 Menton.\nŒufs, pâtes fraîches, café, citrons.",
                tag = "Exemple, Perso", createdAt = now - 10_800_000, updatedAt = now - 10_800_000,
            ),
        ).forEach { db.upsert(it) }
        prefs.edit().putBoolean("seeded", true).apply()
    }
}
