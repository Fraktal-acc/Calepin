package fr.jeremy.calepin

import android.app.Application
import android.content.Context
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import fr.jeremy.calepin.data.Note
import fr.jeremy.calepin.data.NoteDb
import fr.jeremy.calepin.data.Recording
import fr.jeremy.calepin.data.Attachment
import fr.jeremy.calepin.data.Event
import fr.jeremy.calepin.detect.EntityType
import fr.jeremy.calepin.media.Media
import fr.jeremy.calepin.reminders.Reminders
import android.net.Uri
import fr.jeremy.calepin.audio.VoiceRecorder
import fr.jeremy.calepin.export.Backup
import fr.jeremy.calepin.export.ExportFormat
import fr.jeremy.calepin.export.Exporters
import fr.jeremy.calepin.export.PdfExport
import java.io.File
import fr.jeremy.calepin.detect.Entity
import fr.jeremy.calepin.detect.EntityDetector
import fr.jeremy.calepin.search.SearchEngine
import fr.jeremy.calepin.search.SearchOptions
import fr.jeremy.calepin.search.SearchResult
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.FlowPreview
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.debounce
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.concurrent.ConcurrentHashMap

@OptIn(FlowPreview::class)
class NotesViewModel(app: Application) : AndroidViewModel(app) {

    private val db = NoteDb(app)
    private val notes = MutableStateFlow<List<Note>>(emptyList())

    val settings = AppSettings(app)

    /** Identifiants des notes qui ont au moins un enregistrement vocal. */
    private val _withAudio = MutableStateFlow<Set<Long>>(emptySet())
    val withAudio: StateFlow<Set<Long>> = _withAudio

    /** Notes qui ont au moins une photo ou une vidéo. */
    private val _withMedia = MutableStateFlow<Set<Long>>(emptySet())
    val withMedia: StateFlow<Set<Long>> = _withMedia

    /** Vrai une fois les notes chargées depuis la base. */
    val loaded = MutableStateFlow(false)

    /** Rendez-vous de l'agenda Calepin. */
    private val _events = MutableStateFlow<List<Event>>(emptyList())
    val events: StateFlow<List<Event>> = _events

    val query = MutableStateFlow("")
    val options = MutableStateFlow(SearchOptions())

    private val entityCache = ConcurrentHashMap<Long, Pair<String, List<Entity>>>()

    fun entitiesOf(n: Note): List<Entity> {
        val cached = entityCache[n.id]
        if (cached != null && cached.first == n.content) return cached.second
        return EntityDetector.detect(n.content).also { entityCache[n.id] = n.content to it }
    }

    val results: StateFlow<List<SearchResult>> =
        combine(notes, query.debounce(120), options) { n, q, o ->
            SearchEngine.search(n, q, o, ::entitiesOf)
        }
            .flowOn(Dispatchers.Default)
            .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    val noteCount: StateFlow<Int> =
        notes.map { it.size }.stateIn(viewModelScope, SharingStarted.Eagerly, 0)

    val allTags: StateFlow<List<String>> =
        notes.map { list -> list.flatMap { it.tags }.distinctBy { it.lowercase() }.sortedBy { it.lowercase() } }
            .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    init {
        viewModelScope.launch {
            withContext(Dispatchers.IO) { seedIfFirstLaunch() }
            refresh()
        }
    }

    private suspend fun refresh() {
        withContext(Dispatchers.IO) {
            val n = db.all()
            val a = db.recordings().map { it.noteId }.toSet()
            val m = db.attachments().map { it.noteId }.toSet()
            val e = db.events()
            notes.value = n
            _withAudio.value = a
            _withMedia.value = m
            _events.value = e
            loaded.value = true
        }
    }

    fun allNotes(): List<Note> = notes.value
    fun notesByIds(ids: Collection<Long>): List<Note> = notes.value.filter { it.id in ids }

    fun find(id: Long): Note? = notes.value.firstOrNull { it.id == id }

    /** Notes qui citent ce contact : un de ses numéros (quel que soit le format) ou son nom complet. */
    fun notesForContact(name: String, phones: List<String>): List<Note> {
        val keys = phones.map { p -> p.filter { it.isDigit() } }.filter { it.length >= 8 }.map { it.takeLast(8) }.toSet()
        val n = fr.jeremy.calepin.search.TextNorm.norm(name).trim()
        return notes.value.filter { note ->
            (n.length >= 3 && fr.jeremy.calepin.search.TextNorm.norm(note.title + "\n" + note.content).contains(n)) ||
                (keys.isNotEmpty() && entitiesOf(note).any { e ->
                    e.type == EntityType.PHONE && e.value.filter { it.isDigit() }.takeLast(8) in keys
                })
        }
    }

    fun setQuery(q: String) { query.value = q }
    fun updateOptions(f: SearchOptions.() -> SearchOptions) { options.value = options.value.f() }

    /** Écriture immédiate (petite requête SQLite) pour obtenir l'identifiant sans risque de doublon. */
    fun saveNow(n: Note): Long {
        val id = db.upsert(n)
        viewModelScope.launch { refresh() }
        return id
    }

    fun delete(id: Long) {
        viewModelScope.launch {
            withContext(Dispatchers.IO) { deleteRecordingsOf(id); deleteExtrasOf(id); db.delete(id) }
            entityCache.remove(id)
            refresh()
        }
    }

    fun deleteMany(ids: Set<Long>) {
        if (ids.isEmpty()) return
        viewModelScope.launch {
            withContext(Dispatchers.IO) { ids.forEach { deleteRecordingsOf(it); deleteExtrasOf(it); db.delete(it) } }
            ids.forEach { entityCache.remove(it) }
            refresh()
        }
    }

    fun togglePin(n: Note) {
        viewModelScope.launch {
            withContext(Dispatchers.IO) { db.upsert(n.copy(pinned = !n.pinned)) }
            refresh()
        }
    }

    // ----------------------------------------------------- Enregistrements

    private val recDir: File get() = VoiceRecorder.dir(getApplication())

    fun recordingsOf(noteId: Long): List<Recording> = if (noteId == 0L) emptyList() else db.recordings(noteId)
    fun fileOf(r: Recording): File = File(recDir, r.fileName)

    fun newRecordingFile(noteId: Long, format: AudioFormat): File =
        File(recDir, "note${noteId}_${System.currentTimeMillis()}.${format.ext}")

    fun addRecording(noteId: Long, file: File, format: AudioFormat, durationMs: Long) {
        db.insertRecording(Recording(noteId = noteId, fileName = file.name, format = format.name, durationMs = durationMs))
        viewModelScope.launch { refresh() }
    }

    fun deleteRecording(r: Recording) {
        fileOf(r).delete()
        db.deleteRecording(r.id)
        viewModelScope.launch { refresh() }
    }

    private fun deleteRecordingsOf(noteId: Long) {
        db.recordings(noteId).forEach { File(recDir, it.fileName).delete(); db.deleteRecording(it.id) }
    }

    fun setTranscript(r: Recording, text: String) {
        db.setTranscript(r.id, text)
    }

    // ------------------------------------------------------ Photos, vidéos

    fun attachmentsOf(noteId: Long): List<Attachment> = if (noteId == 0L) emptyList() else db.attachments(noteId)
    fun fileOf(a: Attachment): File = File(Media.dir(getApplication()), a.fileName)

    suspend fun importMedia(noteId: Long, uris: List<Uri>): Int = withContext(Dispatchers.IO) {
        var n = 0
        uris.forEach { u ->
            Media.importUri(getApplication(), u)?.let { (f, video) ->
                db.insertAttachment(Attachment(noteId = noteId, fileName = f.name, isVideo = video)); n++
            }
        }
        refresh()
        n
    }

    /** Photo ou vidéo prise avec l'appareil, déjà écrite dans [f]. */
    fun addCaptured(noteId: Long, f: File, video: Boolean) {
        if (!f.exists() || f.length() == 0L) { f.delete(); return }
        db.insertAttachment(Attachment(noteId = noteId, fileName = f.name, isVideo = video))
        viewModelScope.launch { refresh() }
    }

    fun deleteAttachment(a: Attachment) {
        fileOf(a).delete()
        db.deleteAttachment(a.id)
        viewModelScope.launch { refresh() }
    }

    // ------------------------------------------------------------- Agenda

    fun saveEvent(e: Event): Event {
        val id = db.upsertEvent(e)
        val saved = e.copy(id = id)
        Reminders.schedule(getApplication(), saved)
        viewModelScope.launch { refresh() }
        return saved
    }

    fun deleteEvent(e: Event) {
        Reminders.cancel(getApplication(), e.id)
        db.deleteEvent(e.id)
        viewModelScope.launch { refresh() }
    }

    /** Dates reconnues automatiquement dans le texte des notes (pour le calendrier). */
    data class DetectedDate(val note: Note, val time: Long, val hasTime: Boolean, val text: String, val end: Long? = null)

    fun detectedDates(): List<DetectedDate> = notes.value.flatMap { n ->
        entitiesOf(n).filter { it.type == EntityType.DATE && it.timeMillis != null }
            .map { DetectedDate(n, it.timeMillis!!, it.hasTime, it.text, it.endMillis) }
    }

    /** Ajoute plusieurs rendez-vous d'un coup (planning importé) ; ignore ceux déjà présents. Renvoie le nombre ajouté. */
    suspend fun saveEvents(list: List<Event>): Int = withContext(Dispatchers.IO) {
        val existing = db.events().map { Triple(it.start, it.end, it.title) }.toSet()
        var n = 0
        list.forEach { e ->
            if (Triple(e.start, e.end, e.title) !in existing) {
                val id = db.upsertEvent(e)
                Reminders.schedule(getApplication(), e.copy(id = id))
                n++
            }
        }
        refresh()
        n
    }

    private fun deleteExtrasOf(noteId: Long) {
        db.attachments(noteId).forEach { File(Media.dir(getApplication()), it.fileName).delete(); db.deleteAttachment(it.id) }
        db.events().filter { it.noteId == noteId }.forEach { Reminders.cancel(getApplication(), it.id); db.deleteEvent(it.id) }
    }

    // ----------------------------------------------------------- Assistant

    data class ChatMsg(val fromUser: Boolean, val text: String)

    private val assistant = fr.jeremy.calepin.assistant.Assistant(fr.jeremy.calepin.assistant.DbAssistantData(app))
    private val _chat = MutableStateFlow(
        listOf(ChatMsg(false, "Bonjour ! Demande-moi par exemple « Qu'est-ce que j'ai demain ? » ou dis « aide »."))
    )
    val chat: StateFlow<List<ChatMsg>> = _chat

    /** Traite une demande (écrite ou dictée) ; les notes et l'agenda sont rafraîchis ensuite. */
    suspend fun ask(text: String): fr.jeremy.calepin.assistant.Reply {
        _chat.value = _chat.value + ChatMsg(true, text)
        val r = withContext(Dispatchers.IO) { assistant.handle(text) }
        _chat.value = _chat.value + ChatMsg(false, r.text)
        refresh()
        return r
    }

    fun addAssistantMessage(text: String) { _chat.value = _chat.value + ChatMsg(false, text) }
    fun clearChat() { _chat.value = _chat.value.take(1) }

    // ------------------------------------------------------------- Export

    suspend fun export(format: ExportFormat, list: List<Note>): ByteArray = withContext(Dispatchers.Default) {
        if (format == ExportFormat.PDF) PdfExport.build(list) else Exporters.build(format, list, ::entitiesOf)
    }

    /** Restaure une sauvegarde : ajoute les notes absentes (même titre et même texte = déjà présente). */
    suspend fun restore(text: String): Int = withContext(Dispatchers.IO) {
        val incoming = Backup.parse(text)
        val existing = db.all().map { it.title to it.content }.toSet()
        var added = 0
        incoming.forEach { n ->
            if ((n.title to n.content) !in existing) { db.upsert(n); added++ }
        }
        refresh()
        added
    }

    private fun seedIfFirstLaunch() {
        val prefs = getApplication<Application>().getSharedPreferences("calepin", Context.MODE_PRIVATE)
        if (prefs.getBoolean("seeded", false)) return
        val now = System.currentTimeMillis()
        listOf(
            Note(
                title = "Visite villa Cap-Martin",
                content = "Visite de la villa avec M. Rossi le 14 octobre à 10h30.\n" +
                    "Adresse : 12 avenue Winston Churchill, 06190 Roquebrune-Cap-Martin\n" +
                    "Tél : 06 12 34 56 78\nMail : rossi.exemple@gmail.com\n" +
                    "Prévoir les clés et le relevé des compteurs.",
                tag = "Exemple, Clients", pinned = true, createdAt = now - 3_600_000, updatedAt = now - 3_600_000,
            ),
            Note(
                title = "Fournisseurs Monaco",
                content = "Pressing du port : +377 93 50 12 34\nPlombier (urgence) : 07 98 76 54 32\n" +
                    "Électricien à rappeler mardi à 9h.\nSite du pressing : www.exemple-pressing.mc",
                tag = "Exemple, Fournisseurs", createdAt = now - 7_200_000, updatedAt = now - 7_200_000,
            ),
            Note(
                title = "Courses marché",
                content = "Marché demain 18h, place aux Herbes, 06500 Menton.\nŒufs, pâtes fraîches, café, citrons.",
                tag = "Exemple, Perso", createdAt = now - 10_800_000, updatedAt = now - 10_800_000,
            ),
        ).forEach { db.upsert(it) }
        prefs.edit().putBoolean("seeded", true).apply()
    }
}
