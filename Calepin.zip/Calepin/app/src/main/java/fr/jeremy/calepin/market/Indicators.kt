package fr.jeremy.calepin.market

/** Une bougie : ouverture, plus haut, plus bas, clôture, volume ([t] en secondes). */
data class Candle(val t: Long, val o: Double, val h: Double, val l: Double, val c: Double, val v: Double)

/**
 * Indicateurs techniques classiques, calculés sur une suite de bougies (la plus ancienne en premier).
 * Chaque fonction renvoie une liste de même longueur ; NaN tant qu'il n'y a pas assez de données.
 */
object Indicators {
    fun sma(x: List<Double>, n: Int): List<Double> {
        val out = MutableList(x.size) { Double.NaN }
        if (n <= 0) return out
        var sum = 0.0
        for (i in x.indices) {
            sum += x[i]
            if (i >= n) sum -= x[i - n]
            if (i >= n - 1) out[i] = sum / n
        }
        return out
    }

    fun ema(x: List<Double>, n: Int): List<Double> {
        val out = MutableList(x.size) { Double.NaN }
        if (n <= 0 || x.size < n) return out
        val k = 2.0 / (n + 1)
        var e = x.subList(0, n).average()
        out[n - 1] = e
        for (i in n until x.size) {
            e = x[i] * k + e * (1 - k)
            out[i] = e
        }
        return out
    }

    /** RSI de Wilder. */
    fun rsi(x: List<Double>, n: Int = 14): List<Double> {
        val out = MutableList(x.size) { Double.NaN }
        if (n <= 0 || x.size <= n) return out
        var gain = 0.0
        var loss = 0.0
        for (i in 1..n) {
            val d = x[i] - x[i - 1]
            if (d > 0) gain += d else loss -= d
        }
        gain /= n; loss /= n
        out[n] = if (loss == 0.0) 100.0 else 100 - 100 / (1 + gain / loss)
        for (i in n + 1 until x.size) {
            val d = x[i] - x[i - 1]
            gain = (gain * (n - 1) + maxOf(d, 0.0)) / n
            loss = (loss * (n - 1) + maxOf(-d, 0.0)) / n
            out[i] = if (loss == 0.0) 100.0 else 100 - 100 / (1 + gain / loss)
        }
        return out
    }

    /** MACD : (ligne, signal, histogramme). */
    fun macd(x: List<Double>, fast: Int = 12, slow: Int = 26, signal: Int = 9): Triple<List<Double>, List<Double>, List<Double>> {
        val f = ema(x, fast)
        val s = ema(x, slow)
        val line = x.indices.map { f[it] - s[it] }
        val firstValid = line.indexOfFirst { !it.isNaN() }
        val sig = MutableList(x.size) { Double.NaN }
        if (firstValid >= 0) {
            val e = ema(line.subList(firstValid, line.size), signal)
            for (i in e.indices) sig[firstValid + i] = e[i]
        }
        val hist = x.indices.map { line[it] - sig[it] }
        return Triple(line, sig, hist)
    }

    /** Bandes de Bollinger : (basse, moyenne, haute). */
    fun bollinger(x: List<Double>, n: Int = 20, k: Double = 2.0): Triple<List<Double>, List<Double>, List<Double>> {
        val mid = sma(x, n)
        val lo = MutableList(x.size) { Double.NaN }
        val hi = MutableList(x.size) { Double.NaN }
        for (i in x.indices) {
            if (i < n - 1) continue
            val m = mid[i]
            var v = 0.0
            for (j in i - n + 1..i) v += (x[j] - m) * (x[j] - m)
            val sd = kotlin.math.sqrt(v / n)
            lo[i] = m - k * sd
            hi[i] = m + k * sd
        }
        return Triple(lo, mid, hi)
    }

    /** Stochastique %K (sur [n] bougies). */
    fun stochastic(c: List<Candle>, n: Int = 14): List<Double> {
        val out = MutableList(c.size) { Double.NaN }
        for (i in c.indices) {
            if (i < n - 1) continue
            var hh = Double.NEGATIVE_INFINITY
            var ll = Double.POSITIVE_INFINITY
            for (j in i - n + 1..i) { hh = maxOf(hh, c[j].h); ll = minOf(ll, c[j].l) }
            out[i] = if (hh == ll) 50.0 else (c[i].c - ll) / (hh - ll) * 100
        }
        return out
    }

    /** Regroupe des bougies par tranches de [seconds] (ex. 4 heures) : ouverture de la première, clôture de la dernière. */
    fun aggregate(c: List<Candle>, seconds: Long): List<Candle> {
        if (seconds <= 0 || c.isEmpty()) return c
        val out = ArrayList<Candle>()
        var cur: Candle? = null
        var key = Long.MIN_VALUE
        for (x in c) {
            val k = Math.floorDiv(x.t, seconds)
            val p = cur
            if (p == null || k != key) {
                if (p != null) out += p
                cur = x.copy(t = k * seconds)
                key = k
            } else {
                cur = p.copy(h = maxOf(p.h, x.h), l = minOf(p.l, x.l), c = x.c, v = p.v + x.v)
            }
        }
        cur?.let { out += it }
        return out
    }

    /** ATR : amplitude moyenne des bougies (volatilité). */
    fun atr(c: List<Candle>, n: Int = 14): List<Double> {
        val tr = c.indices.map { i ->
            if (i == 0) c[i].h - c[i].l
            else maxOf(c[i].h - c[i].l, kotlin.math.abs(c[i].h - c[i - 1].c), kotlin.math.abs(c[i].l - c[i - 1].c))
        }
        return sma(tr, n)
    }

    /** ADX de Wilder : force de la tendance (au-dessus de 25 : tendance nette ; sous 20 : marché sans direction). */
    fun adx(c: List<Candle>, n: Int = 14): List<Double> {
        val out = MutableList(c.size) { Double.NaN }
        if (c.size < 2 * n + 1) return out
        var trS = 0.0; var pS = 0.0; var mS = 0.0
        val dx = MutableList(c.size) { Double.NaN }
        for (i in 1 until c.size) {
            val up = c[i].h - c[i - 1].h
            val dn = c[i - 1].l - c[i].l
            val pdm = if (up > dn && up > 0) up else 0.0
            val mdm = if (dn > up && dn > 0) dn else 0.0
            val tr = maxOf(c[i].h - c[i].l, kotlin.math.abs(c[i].h - c[i - 1].c), kotlin.math.abs(c[i].l - c[i - 1].c))
            if (i <= n) {
                trS += tr; pS += pdm; mS += mdm
                if (i < n) continue
            } else {
                trS = trS - trS / n + tr
                pS = pS - pS / n + pdm
                mS = mS - mS / n + mdm
            }
            if (trS <= 0) { dx[i] = 0.0; continue }
            val pdi = 100 * pS / trS
            val mdi = 100 * mS / trS
            dx[i] = if (pdi + mdi == 0.0) 0.0 else 100 * kotlin.math.abs(pdi - mdi) / (pdi + mdi)
        }
        // Moyenne de Wilder des DX
        var a = Double.NaN
        var count = 0; var sum = 0.0
        for (i in c.indices) {
            val d = dx[i]
            if (d.isNaN()) continue
            if (a.isNaN()) {
                sum += d; count++
                if (count == n) { a = sum / n; out[i] = a }
            } else {
                a = (a * (n - 1) + d) / n
                out[i] = a
            }
        }
        return out
    }

    /** OBV : volume cumulé, ajouté les jours de hausse, retiré les jours de baisse. */
    fun obv(c: List<Candle>): List<Double> {
        val out = MutableList(c.size) { 0.0 }
        for (i in 1 until c.size) {
            out[i] = out[i - 1] + when {
                c[i].c > c[i - 1].c -> c[i].v
                c[i].c < c[i - 1].c -> -c[i].v
                else -> 0.0
            }
        }
        return out
    }
}
