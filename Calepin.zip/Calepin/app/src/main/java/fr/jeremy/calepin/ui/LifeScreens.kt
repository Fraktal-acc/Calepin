package fr.jeremy.calepin.ui

import android.view.WindowManager
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.StopCircle
import androidx.compose.material.icons.filled.Tv
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.CompositingStrategy
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import fr.jeremy.calepin.BuildConfig
import fr.jeremy.calepin.NotesViewModel
import fr.jeremy.calepin.care.NightWork
import fr.jeremy.calepin.care.WorkHours
import fr.jeremy.calepin.control.TvGuide
import fr.jeremy.calepin.control.TvProgram
import fr.jeremy.calepin.data.NoteDb
import fr.jeremy.calepin.i18n.I18n
import fr.jeremy.calepin.i18n.RawText
import fr.jeremy.calepin.i18n.Text
import fr.jeremy.calepin.ui.tools.ToolHint
import fr.jeremy.calepin.ui.tools.ToolScaffold
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date

// ------------------------------------------------------------------ Mode nuit au travail

/**
 * Enveloppe toute l'appli : en mode nuit au travail, l'écran passe en rouge très sombre (luminosité au minimum)
 * et tout est un peu plus grand, pour viser les boutons sans lunettes ni lumière.
 */
@Composable
fun NightWorkFrame(content: @Composable () -> Unit) {
    val ctx = LocalContext.current
    LaunchedEffect(Unit) { NightWork.init(ctx) }
    val on by NightWork.on.collectAsStateWithLifecycle()
    val activity = ctx as? android.app.Activity
    DisposableEffect(on) {
        val w = activity?.window
        if (w != null) {
            val lp = w.attributes
            lp.screenBrightness = if (on) 0.02f else WindowManager.LayoutParams.BRIGHTNESS_OVERRIDE_NONE
            w.attributes = lp
        }
        onDispose { }
    }
    if (!on) {
        content()
        return
    }
    val d = LocalDensity.current
    Box(
        Modifier
            .fillMaxSize()
            .graphicsLayer { compositingStrategy = CompositingStrategy.Offscreen }
            .drawWithContent {
                drawContent()
                // Noir et blanc, puis teinté de rouge, puis assombri
                if (android.os.Build.VERSION.SDK_INT >= 29) drawRect(Color.Black, blendMode = BlendMode.Saturation)
                drawRect(Color(0xFFFF3020), blendMode = BlendMode.Multiply)
                drawRect(Color.Black.copy(alpha = 0.35f))
            },
    ) {
        CompositionLocalProvider(LocalDensity provides Density(d.density * 1.15f, d.fontScale)) { content() }
        Surface(
            onClick = { NightWork.set(ctx, false) },
            shape = CircleShape,
            color = Color(0xFF2A0000),
            modifier = Modifier.align(Alignment.BottomStart).navigationBarsPadding().padding(12.dp),
        ) {
            Text("☾ Quitter le mode nuit", color = Color(0xFFFF7060), modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp))
        }
    }
}

// ------------------------------------------------------------------ Lire ma journée

/** Bouton « Lire ma journée à voix haute » (rendez-vous, vacation, météo, rappels). */
@Composable
fun ReadDayButton() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var speaking by remember { mutableStateOf(false) }
    val speaker = remember { fr.jeremy.calepin.assistant.Speaker(ctx) { speaking = false } }
    DisposableEffect(Unit) { onDispose { speaker.shutdown() } }
    IconButton(onClick = {
        if (speaking) { speaker.stop(); speaking = false; return@IconButton }
        speaking = true
        scope.launch {
            val text = withContext(Dispatchers.IO) {
                runCatching { fr.jeremy.calepin.assistant.Assistant(fr.jeremy.calepin.assistant.DbAssistantData(ctx)).briefing().text }.getOrDefault("")
            }
            if (text.isBlank()) speaking = false else speaker.speak(text)
        }
    }) {
        Icon(if (speaking) Icons.Filled.StopCircle else Icons.AutoMirrored.Filled.VolumeUp, if (speaking) "Arrêter la lecture" else "Lire ma journée à voix haute")
    }
}

// ------------------------------------------------------------------ Programme télé

/** Programme de la TNT : ce soir (première partie de soirée) et en ce moment. */
@Composable
fun TvGuideScreen(onClose: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var all by remember { mutableStateOf<List<TvProgram>?>(null) }
    var error by remember { mutableStateOf<String?>(null) }
    var loading by remember { mutableStateOf(false) }
    var tab by remember { mutableIntStateOf(0) }
    var open by remember { mutableStateOf<TvProgram?>(null) }
    var reply by remember { mutableStateOf<String?>(null) }
    fun load(force: Boolean) {
        loading = true; error = null
        scope.launch {
            TvGuide.load(ctx, force).onSuccess { all = it }.onFailure { error = I18n.tr("Programme indisponible (pas de connexion ?).") }
            loading = false
        }
    }
    LaunchedEffect(Unit) { load(false) }
    val hm = remember { SimpleDateFormat(I18n.pattern("HH'h'mm"), I18n.locale) }
    ToolScaffold("Programme télé", onClose, actions = {
        IconButton(onClick = { load(true) }, enabled = !loading) { Icon(Icons.Filled.Refresh, "Actualiser") }
    }) {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(selected = tab == 0, onClick = { tab = 0 }, label = { Text("Ce soir") })
            FilterChip(selected = tab == 1, onClick = { tab = 1 }, label = { Text("En ce moment") })
            FilterChip(selected = tab == 2, onClick = { tab = 2 }, label = { Text("Films") })
        }
        if (loading) LinearProgressIndicator(Modifier.fillMaxWidth())
        error?.let { RawText(it, color = MaterialTheme.colorScheme.error) }
        reply?.let { RawText(it, color = MaterialTheme.colorScheme.primary) }
        val list = all.orEmpty().let { a ->
            when (tab) {
                0 -> TvGuide.tonight(a)
                1 -> TvGuide.now(a)
                else -> a.filter { (it.isFilm || it.isTvFilm) && it.end > System.currentTimeMillis() }.sortedBy { it.start }
            }
        }
        if (all != null && list.isEmpty()) ToolHint("Rien à afficher pour le moment.")
        list.forEach { p ->
            Surface(
                shape = MaterialTheme.shapes.large, color = MaterialTheme.colorScheme.surfaceContainerLow, border = appBorder(),
                modifier = Modifier.fillMaxWidth().clickable { open = if (open == p) null else p },
            ) {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            Modifier.size(34.dp).background(MaterialTheme.colorScheme.primaryContainer, RoundedCornerShape(8.dp)),
                            contentAlignment = Alignment.Center,
                        ) { RawText(p.number?.toString() ?: "·", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onPrimaryContainer) }
                        Spacer(Modifier.width(10.dp))
                        Column(Modifier.weight(1f)) {
                            RawText(p.title, style = MaterialTheme.typography.titleMedium, maxLines = 2)
                            RawText(
                                listOf(p.channel, hm.format(Date(p.start)) + "–" + hm.format(Date(p.end)), p.category.substringBefore(",")).filter { it.isNotBlank() }.joinToString(" · "),
                                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1,
                            )
                        }
                        if (p.isFilm) RawText("🎬")
                    }
                    if (open == p) {
                        if (p.subtitle.isNotBlank()) RawText(p.subtitle, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
                        if (p.desc.isNotBlank()) RawText(p.desc, style = MaterialTheme.typography.bodyMedium)
                        if (BuildConfig.AI && p.number != null) {
                            TextButton(onClick = {
                                scope.launch { reply = fr.jeremy.calepin.control.DeviceCommands(ctx).handle("mets la chaîne ${p.number}")?.text }
                            }) { Icon(Icons.Filled.Tv, null, Modifier.size(18.dp)); Text("  Mettre cette chaîne") }
                        }
                    }
                }
            }
        }
        ToolHint("Programme des chaînes de la TNT fourni par xmltvfr.fr, mis à jour chaque nuit.")
    }
}

// ------------------------------------------------------------------ Statistiques

private data class Stats(
    val notes: Int,
    val words: Int,
    val notesThisMonth: Int,
    val perMonth: List<Pair<String, Int>>,
    val topFolders: List<Pair<String, Int>>,
    val topTags: List<Pair<String, Int>>,
    val trash: Int,
    val eventsThisMonth: Int,
    val upcoming: Int,
    val workThisMonth: Int,
    val workLastMonth: Int,
    val recordings: Int,
    val cashedYear: Double,
    val unpaid: Int,
)

/** Quelques chiffres sur l'utilisation de Calepin et sur ton travail. */
@Composable
fun StatsScreen(vm: NotesViewModel, onClose: () -> Unit) {
    val ctx = LocalContext.current
    val events by vm.events.collectAsStateWithLifecycle()
    var s by remember { mutableStateOf<Stats?>(null) }
    LaunchedEffect(events) {
        s = withContext(Dispatchers.IO) { runCatching { computeStats(ctx, events) }.getOrNull() }
    }
    ToolScaffold("Statistiques", onClose) {
        val st = s
        if (st == null) {
            LinearProgressIndicator(Modifier.fillMaxWidth())
            return@ToolScaffold
        }
        SubTitle("Notes")
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Tile("${st.notes}", "Notes", Modifier.weight(1f))
            Tile("%,d".format(I18n.locale, st.words), "Mots écrits", Modifier.weight(1f))
            Tile("${st.notesThisMonth}", "Ce mois-ci", Modifier.weight(1f))
        }
        Bars(st.perMonth)
        if (st.topFolders.isNotEmpty()) Ranking("Dossiers les plus remplis", st.topFolders)
        if (st.topTags.isNotEmpty()) Ranking("Étiquettes les plus utilisées", st.topTags)
        RawText(I18n.trf("{0} mémo(s) vocal(aux) · {1} note(s) dans la corbeille", st.recordings, st.trash), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)

        SubTitle("Agenda et travail")
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Tile("${st.eventsThisMonth}", "Rendez-vous ce mois", Modifier.weight(1f))
            Tile("${st.upcoming}", "Dans les 7 jours", Modifier.weight(1f))
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Tile(WorkHours.hm(st.workThisMonth), "Travail ce mois", Modifier.weight(1f))
            Tile(WorkHours.hm(st.workLastMonth), "Mois dernier", Modifier.weight(1f))
        }
        if (st.cashedYear > 0 || st.unpaid > 0) {
            SubTitle("Pro")
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Tile("%,.0f €".format(I18n.locale, st.cashedYear), "Encaissé cette année", Modifier.weight(1f))
                Tile("${st.unpaid}", "Factures impayées", Modifier.weight(1f))
            }
        }
    }
}

private fun computeStats(ctx: android.content.Context, events: List<fr.jeremy.calepin.data.Event>): Stats {
    val db = NoteDb(ctx)
    val notes = db.all()
    val cal = Calendar.getInstance()
    val monthStart = (cal.clone() as Calendar).apply {
        set(Calendar.DAY_OF_MONTH, 1); set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
    }
    val monthEnd = (monthStart.clone() as Calendar).apply { add(Calendar.MONTH, 1) }.timeInMillis
    val mf = SimpleDateFormat(I18n.pattern("MMM"), I18n.locale)
    val perMonth = (5 downTo 0).map { back ->
        val from = (monthStart.clone() as Calendar).apply { add(Calendar.MONTH, -back) }
        val to = (from.clone() as Calendar).apply { add(Calendar.MONTH, 1) }.timeInMillis
        mf.format(from.time).trimEnd('.') to notes.count { it.createdAt >= from.timeInMillis && it.createdAt < to }
    }
    val words = notes.sumOf { n -> n.content.split(Regex("\\s+")).count { it.any(Char::isLetterOrDigit) } }
    val folders = notes.filter { it.folder.isNotBlank() }.groupingBy { it.folder.substringBefore("/") }.eachCount()
        .entries.sortedByDescending { it.value }.take(5).map { it.key to it.value }
    val tags = notes.flatMap { it.tags }.groupingBy { it }.eachCount().entries.sortedByDescending { it.value }.take(5).map { it.key to it.value }
    val now = System.currentTimeMillis()
    val weekly = WorkHours.weeklyMinutes(ctx)
    val ns = WorkHours.nightStart(ctx)
    val ne = WorkHours.nightEnd(ctx)
    val y = cal.get(Calendar.YEAR)
    val m = cal.get(Calendar.MONTH)
    val prev = (cal.clone() as Calendar).apply { add(Calendar.MONTH, -1) }
    val billing = fr.jeremy.calepin.pro.Billing.get(ctx)
    val yearStart = Calendar.getInstance().apply { clear(); set(y, 0, 1) }.timeInMillis
    return Stats(
        notes = notes.size,
        words = words,
        notesThisMonth = notes.count { it.createdAt >= monthStart.timeInMillis },
        perMonth = perMonth,
        topFolders = folders,
        topTags = tags,
        trash = runCatching { db.trashed().size }.getOrDefault(0),
        eventsThisMonth = events.count { it.start >= monthStart.timeInMillis && it.start < monthEnd && it.category != fr.jeremy.calepin.care.WakeAlarm.CATEGORY },
        upcoming = events.count { it.start in now..(now + 7 * 86_400_000L) && it.category != fr.jeremy.calepin.care.WakeAlarm.CATEGORY },
        workThisMonth = WorkHours.month(events, y, m, weekly, ns, ne).total,
        workLastMonth = WorkHours.month(events, prev.get(Calendar.YEAR), prev.get(Calendar.MONTH), weekly, ns, ne).total,
        recordings = runCatching { db.recordings().size }.getOrDefault(0),
        cashedYear = billing.cashed(yearStart, now + 1),
        unpaid = billing.unpaid().size,
    )
}

@Composable
private fun Tile(value: String, label: String, modifier: Modifier = Modifier) {
    Surface(shape = MaterialTheme.shapes.medium, color = MaterialTheme.colorScheme.surfaceContainerHigh, modifier = modifier) {
        Column(Modifier.padding(horizontal = 12.dp, vertical = 10.dp)) {
            RawText(value, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary, maxLines = 1)
            Text(label, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1)
        }
    }
}

/** Petit histogramme : notes créées par mois. */
@Composable
private fun Bars(data: List<Pair<String, Int>>) {
    val max = (data.maxOfOrNull { it.second } ?: 0).coerceAtLeast(1)
    Surface(shape = MaterialTheme.shapes.large, color = MaterialTheme.colorScheme.surfaceContainerLow, border = appBorder(), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp)) {
            Text("Notes créées par mois", style = MaterialTheme.typography.titleSmall)
            Spacer(Modifier.height(10.dp))
            Row(Modifier.fillMaxWidth().height(110.dp), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.Bottom) {
                data.forEach { (label, v) ->
                    Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                        RawText("$v", style = MaterialTheme.typography.labelSmall)
                        Box(
                            Modifier.fillMaxWidth().height((70f * v / max).dp.coerceAtLeast(3.dp))
                                .background(MaterialTheme.colorScheme.primary, RoundedCornerShape(topStart = 6.dp, topEnd = 6.dp)),
                        )
                        RawText(label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1)
                    }
                }
            }
        }
    }
}

@Composable
private fun Ranking(title: String, items: List<Pair<String, Int>>) {
    val max = (items.maxOfOrNull { it.second } ?: 1).coerceAtLeast(1)
    Surface(shape = MaterialTheme.shapes.large, color = MaterialTheme.colorScheme.surfaceContainerLow, border = appBorder(), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(title, style = MaterialTheme.typography.titleSmall)
            items.forEach { (k, v) ->
                Row(verticalAlignment = Alignment.CenterVertically) {
                    RawText(k, modifier = Modifier.width(120.dp), maxLines = 1)
                    Box(Modifier.weight(1f)) {
                        Box(Modifier.fillMaxWidth(v.toFloat() / max).height(10.dp).background(MaterialTheme.colorScheme.primary.copy(alpha = 0.7f), RoundedCornerShape(5.dp)))
                    }
                    RawText(" $v", style = MaterialTheme.typography.labelMedium)
                }
            }
        }
    }
}
