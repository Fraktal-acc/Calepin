package fr.jeremy.calepin.ui

import android.content.Context
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.NewReleases
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import fr.jeremy.calepin.BuildConfig
import fr.jeremy.calepin.i18n.I18n
import fr.jeremy.calepin.i18n.LocalLanguage
import fr.jeremy.calepin.i18n.RawText
import fr.jeremy.calepin.i18n.Text
import fr.jeremy.calepin.ui.tools.ToolHint
import fr.jeremy.calepin.ui.tools.ToolScaffold
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.format.DateTimeFormatter

/**
 * Journal des versions (assets/changelog.txt) : ce qui a changé à chaque mise à jour.
 *
 * Après une mise à jour, une fenêtre montre les nouveautés de toutes les versions arrivées depuis la
 * dernière ouverture ; l'écran « Historique des mises à jour » garde toutes les versions précédentes.
 * La section « ## Nouveautés » du fichier est celle de la version installée : GitHub la numérote
 * (numéro de compilation et date) une fois la compilation réussie.
 */
object Changelog {
    /** Un changement ; [tr] : traductions par code de langue (« en », « it »…). */
    class Item(val fr: String, val tr: Map<String, String>) {
        /** Texte dans la langue de l'appli (le français si la traduction manque). */
        fun text(): String = tr[I18n.language.value.code] ?: fr
    }

    /** Une version : numéro, date (null si inconnue) et changements. */
    class Entry(val version: Int, val date: LocalDate?, val items: List<Item>)

    private const val PREFS = "calepin_changelog"
    private const val SEEN = "seen"

    @Volatile private var cache: List<Entry>? = null

    /** Toutes les versions, la plus récente d'abord (celles qui n'ont rien pour cette édition sont retirées). */
    fun entries(ctx: Context): List<Entry> = cache ?: load(ctx).also { cache = it }

    private val HEADER = Regex("""^##\s+(\d+)\s*(?:[·|\-–]\s*(\d{4}-\d{2}-\d{2}))?\s*$""")
    private val UPCOMING = Regex("""^##\s+(Nouveautés|Nouveautes)\s*$""", RegexOption.IGNORE_CASE)
    private val TRANSLATION = Regex("""^\s+([a-z]{2})\s*:\s*(.+)$""")

    private class Raw(val version: Int?, val date: LocalDate?, val items: MutableList<Item> = mutableListOf())

    private fun load(ctx: Context): List<Entry> {
        val lines = runCatching { ctx.assets.open("changelog.txt").bufferedReader().readLines() }.getOrElse { return emptyList() }
        val raws = mutableListOf<Raw>()
        var current: Raw? = null
        var fr: String? = null
        var tr = mutableMapOf<String, String>()
        fun flushItem() {
            val text = fr ?: return
            val ia = text.startsWith("[IA]")
            if (!ia || BuildConfig.AI) current?.items?.add(Item(text.removePrefix("[IA]").trim(), tr))
            fr = null
            tr = mutableMapOf()
        }
        for (line in lines) {
            if (line.isBlank() || (line.startsWith("#") && !line.startsWith("##"))) continue
            val h = HEADER.matchEntire(line.trim())
            if (h != null || UPCOMING.matches(line.trim())) {
                flushItem()
                current = Raw(
                    version = h?.groupValues?.get(1)?.toIntOrNull(),
                    date = h?.groupValues?.get(2)?.takeIf { it.isNotEmpty() }?.let { runCatching { LocalDate.parse(it) }.getOrNull() },
                ).also { raws += it }
                continue
            }
            if (current == null) continue
            val t = TRANSLATION.matchEntire(line)
            when {
                line.trimStart().startsWith("- ") -> { flushItem(); fr = line.trimStart().removePrefix("- ").trim() }
                t != null && fr != null -> tr[t.groupValues[1]] = t.groupValues[2].trim()
                fr != null -> fr = fr + " " + line.trim() // texte sur plusieurs lignes
            }
        }
        flushItem()
        // « Nouveautés » = la version installée (une compilation locale porte le numéro 1 : on la place en tête)
        val highest = raws.mapNotNull { it.version }.maxOrNull() ?: 0
        val installed = installDate(ctx)
        return raws.mapNotNull { r ->
            if (r.items.isEmpty()) return@mapNotNull null
            if (r.version != null) Entry(r.version, r.date, r.items)
            else Entry(maxOf(BuildConfig.VERSION_CODE, highest + 1), installed, r.items)
        }
            .groupBy { it.version } // même numéro deux fois : changements réunis
            .map { (v, list) -> Entry(v, list.firstNotNullOfOrNull { it.date }, list.flatMap { it.items }) }
            .sortedByDescending { it.version }
    }

    private fun installDate(ctx: Context): LocalDate? = runCatching {
        val t = ctx.packageManager.getPackageInfo(ctx.packageName, 0).lastUpdateTime
        Instant.ofEpochMilli(t).atZone(ZoneId.systemDefault()).toLocalDate()
    }.getOrNull()

    /**
     * Versions à présenter après une mise à jour (vide sinon).
     * Première installation : rien à montrer. Mise à jour depuis une version d'avant le journal :
     * les nouveautés de la version installée.
     */
    fun pending(ctx: Context): List<Entry> {
        val p = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val current = BuildConfig.VERSION_CODE
        var seen = p.getInt(SEEN, -1)
        if (seen == -1) {
            val info = runCatching { ctx.packageManager.getPackageInfo(ctx.packageName, 0) }.getOrNull()
            val freshInstall = info == null || info.firstInstallTime == info.lastUpdateTime
            if (freshInstall) { markSeen(ctx); return emptyList() }
            seen = current - 1
        }
        if (seen >= current) return emptyList()
        // Une compilation locale (numéro 1) ou un retour en arrière : on ne montre que la version installée
        val all = entries(ctx)
        val top = all.firstOrNull()?.version ?: return emptyList()
        return all.filter { it.version > seen && it.version <= maxOf(current, top) }.ifEmpty { emptyList() }
    }

    /** La fenêtre des nouveautés a été vue : elle ne revient qu'à la prochaine mise à jour. */
    fun markSeen(ctx: Context) {
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putInt(SEEN, BuildConfig.VERSION_CODE).apply()
    }

    /** Date dans la langue de l'appli : « 8 octobre 2026 ». */
    fun formatDate(d: LocalDate): String =
        d.format(DateTimeFormatter.ofPattern(I18n.pattern("d MMMM yyyy"), I18n.locale))
}

/** Nombre de versions montrées dans la fenêtre ; les autres sont dans l'historique. */
private const val DIALOG_MAX = 8

/** Fenêtre affichée après une mise à jour : nouveautés des versions arrivées depuis la dernière ouverture. */
@Composable
fun WhatsNewDialog(entries: List<Changelog.Entry>, onDismiss: () -> Unit, onHistory: () -> Unit) {
    LocalLanguage.current // relit les textes si la langue change
    val newest = entries.first()
    val shown = entries.take(DIALOG_MAX)
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = MaterialTheme.colorScheme.surface,
        icon = { Icon(Icons.Filled.NewReleases, null, tint = MaterialTheme.colorScheme.primary) },
        title = {
            Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
                Text("Quoi de neuf ?")
                RawText(
                    if (entries.size > 1) I18n.trf("Versions {0} à {1}", entries.last().version, newest.version)
                    else I18n.trf("Version {0}", newest.version),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        },
        text = {
            Column(
                Modifier.heightIn(max = 420.dp).verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                shown.forEach { e -> VersionBlock(e, showHeader = entries.size > 1) }
                if (entries.size > DIALOG_MAX) {
                    ToolHint(I18n.trf("Et {0} autres versions : voir l'historique.", entries.size - DIALOG_MAX))
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("OK") } },
        dismissButton = { TextButton(onClick = onHistory) { Text("Historique") } },
    )
}

/** Historique de toutes les mises à jour, la plus récente en tête. */
@Composable
fun ChangelogScreen(onClose: () -> Unit) {
    val ctx = LocalContext.current
    LocalLanguage.current
    val entries = remember { Changelog.entries(ctx) }
    ToolScaffold("Historique des mises à jour", onClose) {
        ToolHint("Tout ce qui a changé dans Calepin, version par version.")
        if (entries.isEmpty()) ToolHint("Aucune version enregistrée.")
        entries.forEach { e ->
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = if (e.version == entries.first().version) MaterialTheme.colorScheme.primaryContainer
                else MaterialTheme.colorScheme.surfaceContainerLow,
                modifier = Modifier.fillMaxWidth(),
            ) {
                Column(Modifier.padding(14.dp)) { VersionBlock(e, showHeader = true, installed = e.version == entries.first().version) }
            }
        }
    }
}

/** Une version : numéro et date, puis ses changements en puces. */
@Composable
private fun VersionBlock(e: Changelog.Entry, showHeader: Boolean, installed: Boolean = false) {
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        if (showHeader) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                RawText(I18n.trf("Version {0}", e.version), style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                if (installed) {
                    Spacer(Modifier.width(8.dp))
                    Text("installée", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
                }
                Spacer(Modifier.weight(1f))
                e.date?.let {
                    RawText(Changelog.formatDate(it), style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
        e.items.forEach { item ->
            Row {
                RawText("•  ", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.primary)
                RawText(item.text(), style = MaterialTheme.typography.bodyMedium)
            }
        }
    }
}
