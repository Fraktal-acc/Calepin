package fr.jeremy.calepin

import android.content.ActivityNotFoundException
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.AlarmClock
import android.provider.CalendarContract
import android.provider.ContactsContract
import android.widget.Toast
import java.util.Calendar

/** Ouverture des autres applications (téléphone, Maps, contacts, agenda…) par Intents Android. */
object Actions {

    private fun launch(ctx: Context, intent: Intent, fallback: Intent? = null) {
        LockGuard.external()
        try {
            ctx.startActivity(intent)
        } catch (e: ActivityNotFoundException) {
            if (fallback != null) launch(ctx, fallback)
            else fr.jeremy.calepin.i18n.I18n.toast(ctx, "Aucune application installée pour cette action", Toast.LENGTH_SHORT).show()
        }
    }

    // Téléphone
    fun dial(ctx: Context, number: String) =
        launch(ctx, Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + Uri.encode(number))))

    /** Appel direct (permission « Téléphone » accordée), sinon simple composition du numéro. */
    fun call(ctx: Context, number: String) {
        LockGuard.external()
        try {
            ctx.startActivity(Intent(Intent.ACTION_CALL, Uri.parse("tel:" + Uri.encode(number))))
        } catch (e: Exception) {
            dial(ctx, number)
        }
    }

    fun sms(ctx: Context, number: String) =
        launch(ctx, Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:" + Uri.encode(number))))

    fun whatsapp(ctx: Context, number: String) {
        var n = number.filter { it.isDigit() || it == '+' }
        if (n.startsWith("0") && !n.startsWith("00")) n = "+33" + n.substring(1) // numéro français local
        n = n.removePrefix("+")
        launch(ctx, Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/$n")))
    }

    /** Ouvre l'écran « Nouveau contact » prérempli avec tout ce que la note contient. */
    fun addContact(ctx: Context, name: String, phone: String?, email: String?, address: String?, notes: String?) {
        val i = Intent(ContactsContract.Intents.Insert.ACTION).apply {
            type = ContactsContract.RawContacts.CONTENT_TYPE
            if (name.isNotBlank()) putExtra(ContactsContract.Intents.Insert.NAME, name)
            phone?.let { putExtra(ContactsContract.Intents.Insert.PHONE, it) }
            email?.let { putExtra(ContactsContract.Intents.Insert.EMAIL, it) }
            address?.let { putExtra(ContactsContract.Intents.Insert.POSTAL, it) }
            notes?.takeIf { it.isNotBlank() }?.let { putExtra(ContactsContract.Intents.Insert.NOTES, it.take(500)) }
        }
        launch(ctx, i)
    }

    /** Fiche du contact dans l'appli Contacts du téléphone. */
    fun openContact(ctx: Context, id: Long, lookupKey: String?) =
        launch(ctx, Intent(Intent.ACTION_VIEW, ContactsContract.Contacts.getLookupUri(id, lookupKey)))

    /** Modification du contact dans l'appli Contacts. */
    fun editContact(ctx: Context, id: Long, lookupKey: String?) =
        launch(
            ctx,
            Intent(Intent.ACTION_EDIT, ContactsContract.Contacts.getLookupUri(id, lookupKey))
                .putExtra("finishActivityOnSaveCompleted", true),
        )

    // E-mail
    fun email(ctx: Context, to: String, subject: String) {
        val i = Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:" + Uri.encode(to))).apply {
            putExtra(Intent.EXTRA_EMAIL, arrayOf(to))
            if (subject.isNotBlank()) putExtra(Intent.EXTRA_SUBJECT, subject)
        }
        launch(ctx, i)
    }

    // Cartes
    fun showOnMap(ctx: Context, address: String) = launch(
        ctx,
        Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=" + Uri.encode(address))),
        Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/maps/search/?api=1&query=" + Uri.encode(address))),
    )

    fun directions(ctx: Context, address: String) = launch(
        ctx,
        Intent(Intent.ACTION_VIEW, Uri.parse("google.navigation:q=" + Uri.encode(address))),
        Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/maps/dir/?api=1&destination=" + Uri.encode(address))),
    )

    fun waze(ctx: Context, address: String) =
        launch(ctx, Intent(Intent.ACTION_VIEW, Uri.parse("https://waze.com/ul?navigate=yes&q=" + Uri.encode(address))))

    // Agenda
    fun addEvent(ctx: Context, title: String, description: String, begin: Long, hasTime: Boolean, location: String?, end: Long? = null) {
        val i = Intent(Intent.ACTION_INSERT).apply {
            data = CalendarContract.Events.CONTENT_URI
            putExtra(CalendarContract.EXTRA_EVENT_BEGIN_TIME, begin)
            val stop = when {
                end != null && end > begin -> if (hasTime) end else end + 86_400_000L // journée entière : jusqu'au lendemain du dernier jour
                else -> begin + if (hasTime) 3_600_000L else 86_400_000L
            }
            putExtra(CalendarContract.EXTRA_EVENT_END_TIME, stop)
            putExtra(CalendarContract.EXTRA_EVENT_ALL_DAY, !hasTime)
            putExtra(CalendarContract.Events.TITLE, title.ifBlank { "Note Calepin" })
            putExtra(CalendarContract.Events.DESCRIPTION, description)
            location?.let { putExtra(CalendarContract.Events.EVENT_LOCATION, it) }
        }
        launch(ctx, i)
    }

    fun openCalendarAt(ctx: Context, time: Long) {
        val uri = CalendarContract.CONTENT_URI.buildUpon().appendPath("time").appendPath(time.toString()).build()
        launch(ctx, Intent(Intent.ACTION_VIEW, uri))
    }

    /** Le réveil Android ne gère qu'une heure : proposé seulement pour aujourd'hui ou demain. */
    fun canSetAlarm(time: Long, hasTime: Boolean): Boolean {
        if (!hasTime) return false
        val diff = time - System.currentTimeMillis()
        return diff in 0..(36 * 3_600_000L)
    }

    fun setAlarm(ctx: Context, time: Long, label: String) {
        val c = Calendar.getInstance().apply { timeInMillis = time }
        val i = Intent(AlarmClock.ACTION_SET_ALARM).apply {
            putExtra(AlarmClock.EXTRA_HOUR, c.get(Calendar.HOUR_OF_DAY))
            putExtra(AlarmClock.EXTRA_MINUTES, c.get(Calendar.MINUTE))
            putExtra(AlarmClock.EXTRA_MESSAGE, label.ifBlank { "Calepin" }.take(60))
        }
        launch(ctx, i)
    }

    // Web, copie, partage
    fun openUrl(ctx: Context, url: String) = launch(ctx, Intent(Intent.ACTION_VIEW, Uri.parse(url)))

    fun copy(ctx: Context, text: String) {
        val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("Calepin", text))
        fr.jeremy.calepin.i18n.I18n.toast(ctx, "Copié", Toast.LENGTH_SHORT).show()
    }

    fun share(ctx: Context, title: String, content: String) {
        val body = if (title.isBlank()) content else "$title\n\n$content"
        val i = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_SUBJECT, title)
            putExtra(Intent.EXTRA_TEXT, body)
        }
        launch(ctx, Intent.createChooser(i, fr.jeremy.calepin.i18n.I18n.tr("Partager la note")))
    }
}
