package fr.jeremy.calepin.ui

import androidx.compose.material3.LocalTextStyle
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.isSpecified
import androidx.compose.ui.unit.sp

/**
 * Texte qui se réduit tout seul pour tenir en entier dans la place disponible
 * (police large comme « Futuriste », texte agrandi, langue aux mots longs…).
 * Il rétrécit par petits pas jusqu'à [minScale] de sa taille ; s'il ne tient toujours pas,
 * il se termine par « … ». Le texte est traduit dans la langue de l'appli.
 */
@Composable
fun FitText(
    text: String,
    modifier: Modifier = Modifier,
    style: TextStyle = LocalTextStyle.current,
    color: Color = Color.Unspecified,
    fontWeight: FontWeight? = null,
    textAlign: TextAlign? = null,
    maxLines: Int = 1,
    minScale: Float = 0.65f,
    translate: Boolean = true,
) {
    val shown = if (translate) fr.jeremy.calepin.i18n.tr(text) else text
    // Recalculé quand le texte, le style ou la place changent (nouvelle mise en page)
    var scale by remember(shown, style, maxLines) { mutableFloatStateOf(1f) }
    var ready by remember(shown, style, maxLines) { mutableStateOf(false) }
    val baseSize: TextUnit = if (style.fontSize.isSpecified) style.fontSize else 16.sp
    val baseLine: TextUnit = style.lineHeight
    val atMin = scale <= minScale + 0.001f
    androidx.compose.material3.Text(
        text = shown,
        // Rien n'est dessiné tant que la bonne taille n'est pas trouvée : pas de clignotement
        modifier = modifier.drawWithContent { if (ready) drawContent() },
        color = color,
        fontWeight = fontWeight,
        textAlign = textAlign,
        maxLines = maxLines,
        softWrap = maxLines > 1,
        overflow = if (atMin) TextOverflow.Ellipsis else TextOverflow.Clip,
        style = style.copy(
            fontSize = baseSize * scale,
            lineHeight = if (baseLine.isSpecified) baseLine * scale else TextUnit.Unspecified,
        ),
        onTextLayout = { r ->
            val overflow = r.didOverflowWidth || r.didOverflowHeight || r.hasVisualOverflow
            if (overflow && !atMin) {
                scale = (scale - 0.05f).coerceAtLeast(minScale)
            } else {
                ready = true
            }
        },
    )
}
