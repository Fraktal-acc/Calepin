package fr.jeremy.calepin.radio

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.HttpUrl.Companion.toHttpUrl
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.concurrent.TimeUnit

/** Une webradio de l'annuaire libre radio-browser.info (plus de 50 000 radios du monde entier). */
data class Station(
    val uuid: String,
    val name: String,
    val url: String,
    val countryCode: String = "",
    val country: String = "",
    val tags: String = "",
    val favicon: String = "",
    val codec: String = "",
    val bitrate: Int = 0,
) {
    fun toJson(): JSONObject = JSONObject()
        .put("uuid", uuid).put("name", name).put("url", url).put("cc", countryCode).put("country", country)
        .put("tags", tags).put("favicon", favicon).put("codec", codec).put("bitrate", bitrate)

    companion object {
        fun fromJson(o: JSONObject) = Station(
            uuid = o.optString("uuid"), name = o.optString("name"), url = o.optString("url"),
            countryCode = o.optString("cc"), country = o.optString("country"), tags = o.optString("tags"),
            favicon = o.optString("favicon"), codec = o.optString("codec"), bitrate = o.optInt("bitrate"),
        )
    }
}

/** Pays de l'annuaire, avec le nombre de radios. */
data class RadioCountry(val code: String, val name: String, val count: Int)

/**
 * Annuaire radio-browser.info : liste des pays, radios d'un pays, recherche par nom ou par style.
 * Plusieurs serveurs miroirs : si l'un ne répond pas, on passe au suivant.
 */
object RadioApi {
    private val SERVERS = listOf(
        "https://all.api.radio-browser.info",
        "https://de1.api.radio-browser.info",
        "https://de2.api.radio-browser.info",
        "https://fi1.api.radio-browser.info",
        "https://nl1.api.radio-browser.info",
        "https://at1.api.radio-browser.info",
    )
    @Volatile private var preferred = 0

    private val http by lazy {
        OkHttpClient.Builder()
            .connectTimeout(8, TimeUnit.SECONDS)
            .readTimeout(15, TimeUnit.SECONDS)
            .build()
    }

    @Volatile private var countriesCache: List<RadioCountry>? = null

    private fun get(path: String, params: Map<String, String> = emptyMap()): String {
        var last: Exception? = null
        for (k in SERVERS.indices) {
            val i = (preferred + k) % SERVERS.size
            try {
                val b = (SERVERS[i] + path).toHttpUrl().newBuilder()
                params.forEach { (key, v) -> b.addQueryParameter(key, v) }
                val req = Request.Builder().url(b.build()).header("User-Agent", "Calepin/1.0 (Android)").build()
                http.newCall(req).execute().use { r ->
                    if (!r.isSuccessful) throw java.io.IOException("HTTP ${r.code}")
                    val body = r.body?.string() ?: throw java.io.IOException("vide")
                    preferred = i
                    return body
                }
            } catch (e: Exception) {
                last = e
            }
        }
        throw last ?: java.io.IOException("Annuaire injoignable")
    }

    /** Pays ayant au moins une radio (mis en cache sur le téléphone pour une semaine). */
    suspend fun countries(ctx: Context): List<RadioCountry> = withContext(Dispatchers.IO) {
        countriesCache?.let { return@withContext it }
        val file = File(ctx.cacheDir, "radio_countries.json")
        val fresh = file.exists() && System.currentTimeMillis() - file.lastModified() < 7L * 86_400_000L
        val text = if (fresh) file.readText() else try {
            get("/json/countries", mapOf("hidebroken" to "true")).also { runCatching { file.writeText(it) } }
        } catch (e: Exception) {
            if (file.exists()) file.readText() else throw e
        }
        val arr = JSONArray(text)
        val merged = LinkedHashMap<String, RadioCountry>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            val code = o.optString("iso_3166_1").uppercase()
            val count = o.optInt("stationcount")
            if (code.length != 2 || count <= 0) continue
            val prev = merged[code]
            merged[code] = RadioCountry(code, o.optString("name"), count + (prev?.count ?: 0))
        }
        merged.values.toList().also { countriesCache = it }
    }

    /** Radios d'un pays, les plus écoutées d'abord. */
    suspend fun byCountry(code: String, offset: Int = 0, limit: Int = 100): List<Station> = withContext(Dispatchers.IO) {
        parse(
            get(
                "/json/stations/bycountrycodeexact/" + code.lowercase(),
                mapOf("hidebroken" to "true", "order" to "clickcount", "reverse" to "true", "offset" to "$offset", "limit" to "$limit"),
            )
        )
    }

    /** Recherche par nom de radio, puis par style (« jazz », « rock »…). */
    suspend fun search(q: String, limit: Int = 80): List<Station> = withContext(Dispatchers.IO) {
        val common = mapOf("hidebroken" to "true", "order" to "clickcount", "reverse" to "true", "limit" to "$limit")
        val byName = parse(get("/json/stations/search", common + ("name" to q)))
        val byTag = if (byName.size < 20) runCatching { parse(get("/json/stations/search", common + ("tag" to q.lowercase()))) }.getOrDefault(emptyList()) else emptyList()
        (byName + byTag).distinctBy { it.uuid }
    }

    /** Signale l'écoute à l'annuaire (classement des radios populaires). Sans importance si ça échoue. */
    suspend fun click(uuid: String) = withContext(Dispatchers.IO) {
        runCatching { get("/json/url/$uuid") }
        Unit
    }

    private fun parse(text: String): List<Station> {
        val arr = JSONArray(text)
        val out = ArrayList<Station>(arr.length())
        val seen = HashSet<String>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            val url = o.optString("url_resolved").ifBlank { o.optString("url") }.trim()
            val name = o.optString("name").trim()
            if (url.isEmpty() || name.isEmpty()) continue
            // Même radio enregistrée plusieurs fois : on n'en garde qu'une
            if (!seen.add(name.lowercase() + "|" + o.optString("countrycode"))) continue
            out += Station(
                uuid = o.optString("stationuuid"),
                name = name,
                url = url,
                countryCode = o.optString("countrycode").uppercase(),
                country = o.optString("country"),
                tags = o.optString("tags").split(',').map { it.trim() }.filter { it.isNotEmpty() }.take(4).joinToString(", "),
                favicon = o.optString("favicon").trim(),
                codec = o.optString("codec"),
                bitrate = o.optInt("bitrate"),
            )
        }
        return out
    }
}

/** Radios favorites et dernière radio écoutée, gardées sur le téléphone. */
object RadioPrefs {
    private fun p(ctx: Context) = ctx.getSharedPreferences("calepin_radio", Context.MODE_PRIVATE)

    fun favorites(ctx: Context): List<Station> = runCatching {
        val arr = JSONArray(p(ctx).getString("favorites", "[]"))
        (0 until arr.length()).map { Station.fromJson(arr.getJSONObject(it)) }
    }.getOrDefault(emptyList())

    fun setFavorites(ctx: Context, list: List<Station>) {
        val arr = JSONArray()
        list.forEach { arr.put(it.toJson()) }
        p(ctx).edit().putString("favorites", arr.toString()).apply()
    }

    fun last(ctx: Context): Station? = p(ctx).getString("last", null)?.let { runCatching { Station.fromJson(JSONObject(it)) }.getOrNull() }
    fun setLast(ctx: Context, s: Station) { p(ctx).edit().putString("last", s.toJson().toString()).apply() }
}
