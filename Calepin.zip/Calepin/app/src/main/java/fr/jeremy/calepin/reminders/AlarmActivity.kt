package fr.jeremy.calepin.reminders

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Build
import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Alarm
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import fr.jeremy.calepin.i18n.Text
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import fr.jeremy.calepin.data.NoteDb
import fr.jeremy.calepin.ui.CalepinTheme
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Écran d'alarme plein écran, même téléphone verrouillé. */
class AlarmActivity : ComponentActivity() {
    private val finished = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) = finish()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 27) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
        } else {
            @Suppress("DEPRECATION")
            window.addFlags(WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON)
        }
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        ContextCompat.registerReceiver(this, finished, IntentFilter(AlarmService.ACTION_FINISHED), ContextCompat.RECEIVER_NOT_EXPORTED)

        val id = intent.getLongExtra(Reminders.EXTRA_EVENT, -1)
        val e = NoteDb(this).event(id)
        val title = e?.title ?: "Alarme"
        val sub = e?.let { ReminderReceiver.whenText(it.start, it.allDay) } ?: ""
        val now = SimpleDateFormat(fr.jeremy.calepin.i18n.I18n.pattern("HH:mm"), fr.jeremy.calepin.i18n.I18n.locale).format(Date())

        setContent {
            CalepinTheme {
                Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                    Column(
                        Modifier
                            .fillMaxSize()
                            .padding(32.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center,
                    ) {
                        Icon(Icons.Filled.Alarm, null, tint = MaterialTheme.colorScheme.secondary, modifier = Modifier.size(64.dp))
                        Spacer(Modifier.height(16.dp))
                        Text(now, fontSize = 64.sp, fontWeight = FontWeight.Light, color = MaterialTheme.colorScheme.primary)
                        Spacer(Modifier.height(12.dp))
                        Text(title, style = MaterialTheme.typography.headlineSmall, textAlign = TextAlign.Center)
                        Text(sub, color = MaterialTheme.colorScheme.onSurfaceVariant, textAlign = TextAlign.Center)
                        Spacer(Modifier.height(48.dp))
                        Button(
                            onClick = { AlarmService.send(this@AlarmActivity, AlarmService.ACTION_STOP, id); finish() },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(64.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                        ) { Text("Arrêter", fontSize = 20.sp) }
                        Spacer(Modifier.height(16.dp))
                        OutlinedButton(
                            onClick = { AlarmService.send(this@AlarmActivity, AlarmService.ACTION_SNOOZE, id); finish() },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(56.dp),
                        ) { Text("Répéter dans 5 minutes", fontSize = 16.sp) }
                    }
                }
            }
        }
    }

    override fun onDestroy() {
        runCatching { unregisterReceiver(finished) }
        super.onDestroy()
    }
}
