package fr.jeremy.calepin.ui

/**
 * Menus et réglages de Calepin, pour les retrouver depuis la recherche de l'accueil.
 * [nav] : écran à ouvrir (mêmes noms que les demandes à l'assistant ; « settings:<rubrique> » ouvre
 * une rubrique des paramètres).
 */
data class Feature(val label: String, val detail: String, val keywords: String, val nav: String, val aiOnly: Boolean = false) {
    val searchText: String get() = "$label $detail $keywords"
}

object SearchCatalog {
    val features: List<Feature> = listOf(
        Feature("Notes", "Toutes les notes et dossiers", "carnet bloc-notes dossiers étiquettes", "notes"),
        Feature("Nouvelle note", "Écrire une note", "créer ajouter écrire", "new_note"),
        Feature("Nouvelle liste", "Liste à cocher (courses, tâches)", "checklist courses tâches cases à cocher", "new_list"),
        Feature("Scanner un texte", "Lire un texte avec l'appareil photo", "photo ocr reconnaissance caméra document", "scan"),
        Feature("Agenda", "Rendez-vous, plannings, vacations", "calendrier événements rendez-vous planning", "agenda"),
        Feature("Heures de travail et réveil", "Relevé du mois, nuits, heures sup", "planning vacations heures nuit dimanche fériés salaire réveil", "workhours"),
        Feature("Pro", "Clients et interventions", "clients interventions factures devis compte rendu urssaf chiffre d'affaires", "pro"),
        Feature("Bureau", "Documents et PDF", "office documents pdf", "office"),
        Feature("PDF", "Lire, annoter, signer, fusionner", "pdf signer annoter fusionner formulaire mot de passe", "pdf"),
        Feature("Mise en page PDF", "Une note → un beau PDF (Menu de la note → Mise en page PDF)", "mise en page pdf imprimer document assistant beau propre présentation exporter", "notes"),
        Feature("Détente", "Jeux, guide TV", "loisirs détente", "relax"),
        Feature("Jeux", "Petits jeux", "jeux jouer", "games"),
        Feature("Webradios", "Radios du monde entier, aussi sur l'accueil", "radio musique écouter webradio", "radio"),
        Feature("Guide TV", "Programmes de la télé", "télé programme tnt ce soir", "tvguide"),
        Feature("Télécommande", "Télé et décodeur", "télé tv décodeur orange sony chaînes volume", "remote", aiOnly = true),
        Feature("Maison", "Appareils de la maison", "lampes lumières prises appareils domotique", "devices", aiOnly = true),
        Feature("Scénarios", "Plusieurs actions d'un coup", "scénario routine automatisation", "scenarios", aiOnly = true),
        Feature("Téléphone", "Entretien, nettoyage, fichiers", "téléphone stockage batterie", "phone"),
        Feature("Nettoyeur", "Libérer de la place", "nettoyage stockage cache fichiers inutiles", "cleaner"),
        Feature("Optimiseur", "Accélérer le téléphone", "optimiser vitesse mémoire batterie", "optimizer"),
        Feature("Fichiers", "Fichiers du téléphone", "fichiers téléchargements dossiers documents", "files"),
        Feature("Assistant", "Demander à l'écrit ou à la voix", "voix parler demander commandes", "assistant"),
        Feature("Apparence", "Fonds, couleurs, bulles, icônes, accueil", "thème fond d'écran couleurs sombre police taille texte bulles opacité icônes tuiles", "appearance"),
        Feature("Paramètres", "Tous les réglages", "réglages options configuration", "settings"),
        Feature("Sauvegarde", "Sauvegarder et restaurer", "sauvegarde restaurer export import json drive", "backup"),
        Feature("Corbeille", "Notes supprimées, gardées 30 jours", "supprimées restaurer récupérer", "trash"),
        Feature("Rappels par lieu", "Un rappel en arrivant quelque part", "lieu géolocalisation position gps", "places"),
        Feature("Statistiques", "Notes, agenda, heures, chiffre d'affaires", "stats chiffres graphiques", "stats"),
        Feature("Mes commandes", "Tes propres phrases pour l'assistant", "commandes personnalisées raccourcis phrases", "commands"),
        Feature("Historique des mises à jour", "Nouveautés de chaque version", "versions nouveautés changelog journal", "changelog"),
        Feature("À propos et confidentialité", "Version et confidentialité", "version confidentialité développeur", "about"),
        Feature("Journal des plantages", "Erreurs enregistrées", "plantage erreur bug crash", "crashes"),
        // Rubriques des paramètres
        Feature("Widgets", "Paramètres → Widgets", "widget écran d'accueil ajouter", "settings:Widgets"),
        Feature("Affichage des notes", "Paramètres → Affichage des notes", "liste grille cartes présentation", "settings:Affichage des notes"),
        Feature("Mémos vocaux", "Paramètres → Mémos vocaux", "enregistrement audio dictée transcription module vocal", "settings:Mémos vocaux"),
        Feature("Réglages de l'assistant", "Paramètres → Assistant", "voix réponse hors ligne", "settings:Assistant"),
        Feature("Intelligence artificielle", "Paramètres → Intelligence artificielle", "ia modèle gemma hors ligne", "settings:Intelligence artificielle", aiOnly = true),
        Feature("Maison et téléphone", "Paramètres → Maison et téléphone", "appareils télé décodeur réseau", "settings:Maison et téléphone", aiOnly = true),
        Feature("Rappels et alarmes", "Paramètres → Rappels et alarmes", "sonnerie alarme notification rappel", "settings:Rappels et alarmes"),
        Feature("Sécurité à l'ouverture", "Paramètres → Sécurité", "code pin empreinte verrouillage biométrie protéger", "settings:Sécurité à l'ouverture"),
        Feature("Importer depuis une autre appli", "Paramètres → Importer", "import keep evernote samsung notes", "settings:Importer depuis une autre appli"),
        Feature("Sauvegarde et export", "Paramètres → Sauvegarde et export", "export pdf texte json", "settings:Sauvegarde et export"),
        Feature("Mode nuit au travail", "Paramètres → Mode nuit au travail", "nuit rouge sombre", "settings:Mode nuit au travail"),
    )

    fun available(ai: Boolean) = features.filter { ai || !it.aiOnly }
}

/** Rubrique des paramètres à ouvrir (et faire apparaître) depuis la recherche. */
object SettingsTarget {
    @Volatile var section: String? = null

    /** Vrai une seule fois pour la rubrique demandée. */
    fun consume(title: String): Boolean {
        if (section != title) return false
        section = null
        return true
    }
}
