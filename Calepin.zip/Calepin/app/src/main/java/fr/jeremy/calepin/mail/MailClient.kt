package fr.jeremy.calepin.mail

import android.content.Context
import com.sun.mail.imap.IMAPFolder
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.io.File
import java.util.Date
import java.util.Properties
import java.util.concurrent.ConcurrentHashMap
import javax.mail.Address
import javax.mail.AuthenticationFailedException
import javax.mail.FetchProfile
import javax.mail.Flags
import javax.mail.Folder
import javax.mail.Message
import javax.mail.Multipart
import javax.mail.Part
import javax.mail.Session
import javax.mail.Store
import javax.mail.UIDFolder
import javax.mail.internet.InternetAddress
import javax.mail.internet.MimeBodyPart
import javax.mail.internet.MimeMessage
import javax.mail.internet.MimeMultipart
import javax.mail.internet.MimeUtility

/** En-tête d'un mail de la boîte de réception. */
data class MailHeader(
    val uid: Long,
    val from: String,
    val fromAddr: String,
    val subject: String,
    val date: Long,
    val seen: Boolean,
    val attach: Boolean,
    /** Dossier sur le serveur (boîte de réception, ou « Envoyés » pour une recherche). */
    val folder: String = "INBOX",
    /** Compte d'où vient le mail (recherche dans plusieurs boîtes). */
    val accountId: String = "",
)

data class MailAttachment(val index: Int, val name: String, val size: Int, val mime: String)

/** Mail ouvert : texte lisible, pièces jointes, et de quoi répondre. */
data class MailBody(
    val header: MailHeader,
    val to: String,
    val cc: String,
    val text: String,
    val attachments: List<MailAttachment>,
    val messageId: String?,
    val references: String?,
    val replyTo: String,
)

/** Fichier à joindre à un mail ([name] : nom vu par le destinataire). */
data class Outgoing(val file: File, val name: String, val mime: String = "application/octet-stream")

/** Erreur lisible pour l'utilisateur. */
class MailError(msg: String) : Exception(fr.jeremy.calepin.i18n.I18n.tr(msg))

/**
 * Réception (IMAP) et envoi (SMTP) avec les adresses de l'utilisateur. Tout se fait directement entre le
 * téléphone et le serveur de mail : rien ne passe par un autre service.
 */
object MailClient {
    private val stores = ConcurrentHashMap<String, Store>()
    private val locks = ConcurrentHashMap<String, Mutex>()
    private fun lockOf(id: String) = locks.getOrPut(id) { Mutex() }

    private val _inbox = MutableStateFlow<Map<String, List<MailHeader>>>(emptyMap())
    /** Derniers mails reçus, par compte (gardés en mémoire pendant que l'appli est ouverte). */
    val inbox: StateFlow<Map<String, List<MailHeader>>> = _inbox

    fun forget(id: String) {
        stores.remove(id)?.let { runCatching { it.close() } }
        _inbox.value = _inbox.value - id
    }

    private fun props(a: MailAccount): Properties = Properties().apply {
        // Réception
        val ip = if (a.imapSec == Security.SSL) "imaps" else "imap"
        put("mail.store.protocol", ip)
        put("mail.$ip.host", a.imapHost)
        put("mail.$ip.port", a.imapPort.toString())
        put("mail.$ip.connectiontimeout", "20000")
        put("mail.$ip.timeout", "30000")
        if (a.imapSec == Security.STARTTLS) { put("mail.imap.starttls.enable", "true"); put("mail.imap.starttls.required", "true") }
        put("mail.$ip.ssl.checkserveridentity", "true")
        // Envoi
        put("mail.smtp.host", a.smtpHost)
        put("mail.smtp.port", a.smtpPort.toString())
        put("mail.smtp.auth", "true")
        put("mail.smtp.connectiontimeout", "20000")
        put("mail.smtp.timeout", "30000")
        put("mail.smtp.writetimeout", "60000")
        if (a.smtpSec == Security.SSL) { put("mail.smtp.ssl.enable", "true"); put("mail.smtp.ssl.checkserveridentity", "true") }
        else { put("mail.smtp.starttls.enable", "true"); put("mail.smtp.starttls.required", "true") }
    }

    private fun session(a: MailAccount) = Session.getInstance(props(a), null)

    private fun readable(e: Throwable): MailError = when {
        e is MailError -> e
        e is AuthenticationFailedException -> MailError("Identifiant ou mot de passe refusé par le serveur. Pour Gmail, Yahoo, iCloud ou Outlook, il faut un mot de passe d'application.")
        e.cause is java.net.UnknownHostException || e is java.net.UnknownHostException -> MailError("Serveur introuvable : vérifie la connexion Internet et le nom du serveur.")
        e.cause is java.net.SocketTimeoutException || e is java.net.SocketTimeoutException -> MailError("Le serveur ne répond pas (délai dépassé).")
        else -> MailError((e.message ?: e.javaClass.simpleName).take(200))
    }

    private fun pwd(ctx: Context, a: MailAccount) = MailAccounts.password(ctx, a) ?: throw MailError("Mot de passe introuvable : modifie l'adresse et saisis-le à nouveau.")

    private fun store(ctx: Context, a: MailAccount): Store {
        stores[a.id]?.let { if (it.isConnected) return it }
        val s = session(a).store
        s.connect(a.imapHost, a.imapPort, a.user, pwd(ctx, a))
        stores[a.id] = s
        return s
    }

    /** Vérifie la réception et l'envoi avant d'enregistrer une adresse. */
    suspend fun test(a: MailAccount, password: String) = withContext(Dispatchers.IO) {
        try {
            session(a).store.apply { connect(a.imapHost, a.imapPort, a.user, password); close() }
        } catch (e: Throwable) {
            throw MailError(fr.jeremy.calepin.i18n.I18n.tr("Réception (IMAP) :") + " " + readable(e).message)
        }
        try {
            session(a).getTransport("smtp").apply { connect(a.smtpHost, a.smtpPort, a.user, password); close() }
        } catch (e: Throwable) {
            throw MailError(fr.jeremy.calepin.i18n.I18n.tr("Envoi (SMTP) :") + " " + readable(e).message)
        }
    }

    private fun addr(a: Array<Address>?): Pair<String, String> {
        val x = a?.firstOrNull() ?: return "" to ""
        return if (x is InternetAddress) (x.personal?.takeIf { it.isNotBlank() } ?: x.address.orEmpty()) to x.address.orEmpty()
        else x.toString() to x.toString()
    }

    private fun list(a: Array<Address>?) = a?.joinToString(", ") { x -> if (x is InternetAddress) x.toUnicodeString() else x.toString() }.orEmpty()

    private fun header(f: Folder, m: Message, accountId: String = ""): MailHeader {
        val (name, mail) = addr(runCatching { m.from }.getOrNull())
        return MailHeader(
            uid = (f as UIDFolder).getUID(m),
            from = name.ifBlank { mail },
            fromAddr = mail,
            subject = runCatching { m.subject }.getOrNull().orEmpty(),
            date = (runCatching { m.receivedDate ?: m.sentDate }.getOrNull() ?: Date(0)).time,
            seen = runCatching { m.isSet(Flags.Flag.SEEN) }.getOrDefault(true),
            attach = runCatching { m.isMimeType("multipart/mixed") }.getOrDefault(false),
            folder = f.fullName,
            accountId = accountId,
        )
    }

    /** Recharge les [count] derniers mails de la boîte de réception. */
    suspend fun refresh(ctx: Context, a: MailAccount, count: Int = 60): List<MailHeader> = withContext(Dispatchers.IO) {
        lockOf(a.id).withLock {
            try {
                val f = store(ctx, a).getFolder("INBOX")
                f.open(Folder.READ_ONLY)
                try {
                    val n = f.messageCount
                    val list = if (n <= 0) emptyList() else {
                        val msgs = f.getMessages(maxOf(1, n - count + 1), n)
                        val fp = FetchProfile().apply {
                            add(FetchProfile.Item.ENVELOPE); add(FetchProfile.Item.FLAGS); add(FetchProfile.Item.CONTENT_INFO); add(UIDFolder.FetchProfileItem.UID)
                        }
                        f.fetch(msgs, fp)
                        msgs.map { header(f, it, a.id) }.sortedByDescending { it.date }
                    }
                    _inbox.value = _inbox.value + (a.id to list)
                    list
                } finally {
                    runCatching { f.close(false) }
                }
            } catch (e: Throwable) {
                stores.remove(a.id)
                throw readable(e)
            }
        }
    }

    private class Parts {
        val text = StringBuilder()
        var html: String? = null
        val attachments = mutableListOf<Part>()
    }

    private fun str(p: Part): String = runCatching {
        when (val c = p.content) {
            is String -> c
            is java.io.InputStream -> c.readBytes().toString(Charsets.UTF_8)
            else -> c.toString()
        }
    }.getOrDefault("")

    private fun walk(p: Part, out: Parts) {
        val fileName = runCatching { p.fileName }.getOrNull()
        val isAttachment = Part.ATTACHMENT.equals(p.disposition, ignoreCase = true) || (fileName != null && !p.isMimeType("multipart/*"))
        when {
            isAttachment -> out.attachments.add(p)
            p.isMimeType("multipart/alternative") -> {
                val mp = p.content as Multipart
                var plain: Part? = null
                var html: Part? = null
                for (i in 0 until mp.count) {
                    val bp = mp.getBodyPart(i)
                    when {
                        bp.isMimeType("text/plain") && plain == null -> plain = bp
                        bp.isMimeType("text/html") && html == null -> html = bp
                        else -> walk(bp, out)
                    }
                }
                if (plain != null) out.text.append(str(plain)).append('\n')
                else if (html != null && out.html == null) out.html = str(html)
            }
            p.isMimeType("multipart/*") -> {
                val mp = p.content as Multipart
                for (i in 0 until mp.count) walk(mp.getBodyPart(i), out)
            }
            p.isMimeType("message/rfc822") -> (p.content as? Part)?.let { walk(it, out) }
            p.isMimeType("text/plain") -> out.text.append(str(p)).append('\n')
            p.isMimeType("text/html") -> if (out.html == null) out.html = str(p)
        }
    }

    /** HTML → texte lisible (les mails sans version texte). */
    private fun htmlToText(html: String): String {
        val clean = html.replace(Regex("(?is)<(style|script|head)[^>]*>.*?</\\1>"), "")
        return android.text.Html.fromHtml(clean, android.text.Html.FROM_HTML_MODE_COMPACT).toString()
            .replace('￼', ' ').replace(Regex("[ \\t]+\\n"), "\n").replace(Regex("\\n{3,}"), "\n\n").trim()
    }

    private fun decodeName(n: String?): String = runCatching { MimeUtility.decodeText(n ?: "") }.getOrDefault(n ?: "").ifBlank { "pièce jointe" }

    /** Ouvre un mail (et le marque comme lu). */
    suspend fun open(ctx: Context, a: MailAccount, uid: Long, folder: String = "INBOX"): MailBody = withContext(Dispatchers.IO) {
        lockOf(a.id).withLock {
            try {
                val f = store(ctx, a).getFolder(folder)
                f.open(Folder.READ_WRITE)
                try {
                    val m = (f as UIDFolder).getMessageByUID(uid) ?: throw MailError("Ce mail n'existe plus sur le serveur.")
                    val parts = Parts()
                    walk(m, parts)
                    runCatching { m.setFlag(Flags.Flag.SEEN, true) }
                    val h = header(f, m).copy(seen = true)
                    _inbox.value = _inbox.value + (a.id to _inbox.value[a.id].orEmpty().map { if (it.uid == uid) it.copy(seen = true) else it })
                    val text = parts.text.toString().trim().ifBlank { parts.html?.let { htmlToText(it) }.orEmpty() }
                    MailBody(
                        header = h,
                        to = list(runCatching { m.getRecipients(Message.RecipientType.TO) }.getOrNull()),
                        cc = list(runCatching { m.getRecipients(Message.RecipientType.CC) }.getOrNull()),
                        text = text,
                        attachments = parts.attachments.mapIndexed { i, p -> MailAttachment(i, decodeName(p.fileName), runCatching { p.size }.getOrDefault(-1), runCatching { p.contentType.substringBefore(';').lowercase() }.getOrDefault("application/octet-stream")) },
                        messageId = runCatching { (m as MimeMessage).messageID }.getOrNull(),
                        references = runCatching { m.getHeader("References")?.firstOrNull() }.getOrNull(),
                        replyTo = addr(runCatching { m.replyTo }.getOrNull()).second.ifBlank { h.fromAddr },
                    )
                } finally {
                    runCatching { f.close(false) }
                }
            } catch (e: Throwable) {
                if (e !is MailError) stores.remove(a.id)
                throw readable(e)
            }
        }
    }

    /**
     * Recherche sur le serveur (boîte de réception et Envoyés) : tous les mots doivent se trouver dans
     * l'expéditeur, l'objet ou le texte, avec ou sans accents, sans tenir compte des majuscules.
     */
    suspend fun search(ctx: Context, a: MailAccount, query: String, max: Int = 40): List<MailHeader> = withContext(Dispatchers.IO) {
        val words = query.trim().split(Regex("\\s+")).filter { it.length >= 2 }
        if (words.isEmpty()) return@withContext emptyList()
        fun termFor(w: String): javax.mail.search.SearchTerm {
            val variants = linkedSetOf(w, fr.jeremy.calepin.search.TextNorm.norm(w))
            return javax.mail.search.OrTerm(
                variants.flatMap { v ->
                    listOf(javax.mail.search.SubjectTerm(v), javax.mail.search.FromStringTerm(v), javax.mail.search.BodyTerm(v))
                }.toTypedArray(),
            )
        }
        val term = if (words.size == 1) termFor(words[0]) else javax.mail.search.AndTerm(words.map { termFor(it) }.toTypedArray())
        lockOf(a.id).withLock {
            try {
                val st = store(ctx, a)
                val folders = listOfNotNull(st.getFolder("INBOX"), specialFolder(st, "\\Sent", listOf("Sent", "Envoyés", "Éléments envoyés", "INBOX.Sent", "Sent Items", "Sent Messages", "[Gmail]/Sent Mail", "[Gmail]/Messages envoyés")))
                    .distinctBy { it.fullName }
                folders.flatMap { f ->
                    runCatching {
                        f.open(Folder.READ_ONLY)
                        try {
                            val found = f.search(term).takeLast(max)
                            val fp = FetchProfile().apply {
                                add(FetchProfile.Item.ENVELOPE); add(FetchProfile.Item.FLAGS); add(FetchProfile.Item.CONTENT_INFO); add(UIDFolder.FetchProfileItem.UID)
                            }
                            f.fetch(found, fp)
                            found.map { header(f, it, a.id) }
                        } finally {
                            runCatching { f.close(false) }
                        }
                    }.getOrDefault(emptyList())
                }.sortedByDescending { it.date }
            } catch (e: Throwable) {
                stores.remove(a.id)
                throw readable(e)
            }
        }
    }

    /** Télécharge une pièce jointe dans le cache (pour l'ouvrir ou la partager). */
    suspend fun saveAttachment(ctx: Context, a: MailAccount, uid: Long, index: Int, folder: String = "INBOX"): File = withContext(Dispatchers.IO) {
        lockOf(a.id).withLock {
            try {
                val f = store(ctx, a).getFolder(folder)
                f.open(Folder.READ_ONLY)
                try {
                    val m = (f as UIDFolder).getMessageByUID(uid) ?: throw MailError("Ce mail n'existe plus sur le serveur.")
                    val parts = Parts()
                    walk(m, parts)
                    val p = parts.attachments.getOrNull(index) ?: throw MailError("Pièce jointe introuvable.")
                    val name = decodeName(p.fileName).replace(Regex("[\\\\/:*?\"<>|]"), "_")
                    val dir = File(ctx.cacheDir, "mail/$uid").apply { mkdirs() }
                    val out = File(dir, name)
                    p.inputStream.use { input -> out.outputStream().use { input.copyTo(it) } }
                    out
                } finally {
                    runCatching { f.close(false) }
                }
            } catch (e: Throwable) {
                if (e !is MailError) stores.remove(a.id)
                throw readable(e)
            }
        }
    }

    /** Retire le mail de la boîte de réception (corbeille ou archive selon le fournisseur). */
    suspend fun delete(ctx: Context, a: MailAccount, uid: Long, folder: String = "INBOX") = withContext(Dispatchers.IO) {
        lockOf(a.id).withLock {
            try {
                val st = store(ctx, a)
                val f = st.getFolder(folder)
                f.open(Folder.READ_WRITE)
                try {
                    val m = (f as UIDFolder).getMessageByUID(uid) ?: return@withLock
                    // Copie dans la corbeille quand elle existe (sauf Gmail, qui archive tout seul)
                    if (!a.isGmail) specialFolder(st, "\\Trash", listOf("Trash", "Corbeille", "INBOX.Trash", "Deleted", "Deleted Items", "Éléments supprimés"))
                        ?.let { t -> runCatching { f.copyMessages(arrayOf(m), t) } }
                    m.setFlag(Flags.Flag.DELETED, true)
                } finally {
                    runCatching { f.close(true) }
                }
                _inbox.value = _inbox.value + (a.id to _inbox.value[a.id].orEmpty().filter { it.uid != uid })
            } catch (e: Throwable) {
                stores.remove(a.id)
                throw readable(e)
            }
        }
    }

    private fun specialFolder(st: Store, attr: String, names: List<String>): Folder? = runCatching {
        val all = st.defaultFolder.list("*")
        all.firstOrNull { f -> (f as? IMAPFolder)?.attributes?.any { it.equals(attr, true) } == true }
            ?: names.firstNotNullOfOrNull { n -> all.firstOrNull { it.fullName.equals(n, true) || it.name.equals(n, true) } }
    }.getOrNull()

    /** Envoie un mail (avec pièces jointes). [reply] : mail auquel on répond (pour garder la conversation). */
    suspend fun send(
        ctx: Context, a: MailAccount, to: String, cc: String, subject: String, body: String,
        attachments: List<Outgoing>, reply: MailBody? = null,
    ) = withContext(Dispatchers.IO) {
        try {
            val s = session(a)
            val msg = MimeMessage(s)
            msg.setFrom(InternetAddress(a.email, a.name.ifBlank { null }, "UTF-8"))
            val toList = InternetAddress.parse(to.replace(';', ','), false)
            if (toList.isEmpty()) throw MailError("Ajoute au moins un destinataire.")
            msg.setRecipients(Message.RecipientType.TO, toList)
            if (cc.isNotBlank()) msg.setRecipients(Message.RecipientType.CC, InternetAddress.parse(cc.replace(';', ','), false))
            msg.setSubject(subject, "UTF-8")
            msg.sentDate = Date()
            reply?.messageId?.let { id ->
                msg.setHeader("In-Reply-To", id)
                msg.setHeader("References", listOfNotNull(reply.references, id).joinToString(" "))
            }
            if (attachments.isEmpty()) msg.setText(body, "UTF-8")
            else {
                val mp = MimeMultipart()
                mp.addBodyPart(MimeBodyPart().apply { setText(body, "UTF-8") })
                attachments.forEach { o ->
                    mp.addBodyPart(MimeBodyPart().apply {
                        attachFile(o.file, o.mime, null)
                        fileName = MimeUtility.encodeText(o.name, "UTF-8", null)
                    })
                }
                msg.setContent(mp)
            }
            msg.saveChanges()
            s.getTransport("smtp").useT { t ->
                t.connect(a.smtpHost, a.smtpPort, a.user, pwd(ctx, a))
                t.sendMessage(msg, msg.allRecipients)
            }
            // Copie dans « Envoyés » (Gmail le fait tout seul)
            if (!a.isGmail) lockOf(a.id).withLock {
                runCatching {
                    val st = store(ctx, a)
                    specialFolder(st, "\\Sent", listOf("Sent", "Envoyés", "Éléments envoyés", "INBOX.Sent", "Sent Items", "Sent Messages", "OUTBOX"))?.let { f ->
                        msg.setFlag(Flags.Flag.SEEN, true)
                        f.appendMessages(arrayOf(msg))
                    }
                }
            }
        } catch (e: Throwable) {
            throw readable(e)
        }
    }
}

private inline fun <T : javax.mail.Transport, R> T.useT(block: (T) -> R): R = try { block(this) } finally { runCatching { close() } }
