package fr.jeremy.calepin.text

/** Majuscules automatiques : au début du message et après . ! ? … (suivis d'un espace ou d'un retour à la ligne). */
object Sentences {
    fun fix(s: String): String {
        if (s.isEmpty()) return s
        val b = StringBuilder(s)
        var capNext = true
        var i = 0
        while (i < b.length) {
            val c = b[i]
            when {
                c.isLetter() -> {
                    if (capNext && !looksLikeLink(b, i)) b.setCharAt(i, c.uppercaseChar())
                    capNext = false
                }
                c == '.' || c == '!' || c == '?' || c == '…' -> {
                    // « 3.5 », « www.site.fr », « ... » au milieu d'un mot : pas de nouvelle phrase
                    val next = b.getOrNull(i + 1)
                    capNext = next == null || next.isWhitespace() || next == '"' || next == '»' || next == ')'
                    if (c == '.' && i + 1 < b.length && b[i + 1] == '.') capNext = false
                }
                c == '\n' -> capNext = true
                c.isDigit() -> capNext = false
            }
            i++
        }
        return b.toString()
    }

    /** Pas de majuscule forcée dans une adresse (www.…, http…, mail@…). */
    private fun looksLikeLink(b: CharSequence, i: Int): Boolean {
        var end = i
        while (end < b.length && !b[end].isWhitespace()) end++
        val word = b.subSequence(i, end).toString().lowercase()
        return word.startsWith("http") || word.startsWith("www.") || '@' in word
    }
}
