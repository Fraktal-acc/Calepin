package fr.jeremy.calepin.mail

/**
 * Mise en page d'un mail pour l'affichage (comme une boîte mail classique) : HTML adapté à l'écran,
 * images intégrées (« cid: »), liens cliquables dans les mails en texte seul, liens « mailto: ».
 */

/** Adresse fictive des images intégrées : interceptée par l'affichage, jamais demandée sur Internet. */
const val CID_HOST = "cid.calepin.invalid"

/** Le HTML cite l'image intégrée [id] (« cid:… »). */
fun citesCid(html: String?, id: String): Boolean {
    if (html.isNullOrEmpty()) return false
    return html.contains("cid:$id", ignoreCase = true) || html.contains("cid:" + percentEncode(id), ignoreCase = true)
}

private fun percentEncode(s: String): String = buildString {
    s.toByteArray(Charsets.UTF_8).forEach { b ->
        val c = b.toInt() and 0xFF
        if ((c in 'a'.code..'z'.code) || (c in 'A'.code..'Z'.code) || (c in '0'.code..'9'.code) || c == '-'.code || c == '.'.code || c == '_'.code || c == '~'.code || c == '@'.code) append(c.toChar())
        else append('%').append("%02X".format(c))
    }
}

/** Décodage « %XX » (UTF-8), sans transformer les « + » (adresses mailto). */
fun percentDecode(s: String): String {
    if ('%' !in s) return s
    val out = java.io.ByteArrayOutputStream()
    var i = 0
    while (i < s.length) {
        val c = s[i]
        if (c == '%' && i + 2 < s.length && s.substring(i + 1, i + 3).all { it.isDigit() || it.lowercaseChar() in 'a'..'f' }) {
            out.write(s.substring(i + 1, i + 3).toInt(16)); i += 3
        } else {
            out.write(c.toString().toByteArray(Charsets.UTF_8)); i++
        }
    }
    return out.toString("UTF-8")
}

/** Remplace les images « cid:… » par l'adresse interceptée. */
fun rewriteCids(html: String, ids: Collection<String>): String {
    var h = html
    ids.forEach { id ->
        val target = "https://$CID_HOST/" + percentEncode(id)
        h = h.replace(Regex("cid:" + Regex.escape(id), RegexOption.IGNORE_CASE), Regex.escapeReplacement(target))
        val enc = percentEncode(id)
        if (enc != id) h = h.replace(Regex("cid:" + Regex.escape(enc), RegexOption.IGNORE_CASE), Regex.escapeReplacement(target))
    }
    return h
}

/** Identifiant d'image intégrée d'après l'adresse interceptée. */
fun cidFromUrl(path: String?): String = percentDecode(path.orEmpty().removePrefix("/"))

private fun escapeHtml(s: String) = s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;")

private val LINKS = Regex(
    "(?i)\\b(?:https?://|www\\.)[^\\s<>\"]+" +
        "|\\b[a-z0-9._%+-]+@[a-z0-9.-]+\\.[a-z]{2,}\\b" +
        "|(?<![\\w+])(?:\\+33\\s?|0)[1-9](?:[ .-]?\\d{2}){4}(?!\\d)",
)

/** Texte d'un mail → HTML avec les liens, adresses mail et numéros de téléphone cliquables. */
fun textToHtml(text: String): String {
    val sb = StringBuilder()
    var last = 0
    LINKS.findAll(text).forEach { m ->
        // Ponctuation de fin de phrase : hors du lien (une parenthèse fermante seulement si elle n'a pas été ouverte dans le lien)
        var v = m.value.trimEnd('.', ',', ';', ':', '!', '?', ']', '»', '\'')
        while (v.endsWith(")") && v.count { it == '(' } < v.count { it == ')' }) v = v.dropLast(1).trimEnd('.', ',', ';', ':', '!', '?', ']', '»', '\'')
        val end = m.range.first + v.length
        sb.append(escapeHtml(text.substring(last, m.range.first)))
        val href = when {
            v.contains('@') && !v.contains("://") && !v.startsWith("www.", true) -> "mailto:$v"
            v.startsWith("www.", true) -> "https://$v"
            v.first().isDigit() || v.startsWith("+") -> "tel:" + v.filter { it.isDigit() || it == '+' }
            else -> v
        }
        sb.append("<a href=\"").append(escapeHtml(href)).append("\">").append(escapeHtml(v)).append("</a>")
        last = end
    }
    sb.append(escapeHtml(text.substring(last)))
    return "<div class=\"calepin-text\">" + sb.toString().replace("\r\n", "\n").replace("\n", "<br>") + "</div>"
}

/**
 * Page complète prête à afficher : adaptée à la largeur de l'écran, images à la taille de l'écran.
 * [fg]/[bg]/[link] : couleurs du thème (mails en texte seul) ; les mails HTML gardent leurs couleurs sur fond blanc.
 */
fun mailPage(html: String?, text: String, fg: String, bg: String, link: String): String {
    val head = "<meta charset=\"utf-8\"><meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">"
    return if (html != null) {
        val css = "<style>html,body{margin:0;padding:0;background:#ffffff;}body{padding:8px;word-wrap:break-word;overflow-wrap:break-word;}" +
            "img{max-width:100% !important;height:auto !important;}pre{white-space:pre-wrap;}</style>"
        // Le HTML du mail peut déjà avoir <html>/<head> : on ajoute nos réglages au début
        val meta = if (Regex("(?i)<meta[^>]+name=[\"']?viewport").containsMatchIn(html)) "<meta charset=\"utf-8\">" else head
        val h = Regex("(?i)<head(?:\\s[^>]*)?>").find(html)
        if (h != null) html.substring(0, h.range.last + 1) + meta + css + html.substring(h.range.last + 1)
        else "<!DOCTYPE html><html><head>$meta$css</head><body>$html</body></html>"
    } else {
        "<!DOCTYPE html><html><head>$head<style>html,body{margin:0;padding:0;background:$bg;color:$fg;}" +
            "body{font-family:sans-serif;font-size:16px;line-height:1.45;padding:2px 0;word-wrap:break-word;overflow-wrap:anywhere;}" +
            "a{color:$link;}</style></head><body>" + textToHtml(text) + "</body></html>"
    }
}

/** Contenu d'un lien « mailto: » : destinataires, copie, objet et texte. */
data class Mailto(val to: String, val cc: String, val subject: String, val body: String)

fun parseMailto(url: String): Mailto {
    val rest = url.substringAfter(':', "")
    val addr = percentDecode(rest.substringBefore('?'))
    val params = rest.substringAfter('?', "").split('&').filter { it.contains('=') }.associate { kv ->
        kv.substringBefore('=').lowercase() to percentDecode(kv.substringAfter('='))
    }
    val to = listOf(addr, params["to"].orEmpty()).filter { it.isNotBlank() }.joinToString(", ")
    return Mailto(to, params["cc"].orEmpty(), params["subject"].orEmpty(), params["body"].orEmpty())
}
