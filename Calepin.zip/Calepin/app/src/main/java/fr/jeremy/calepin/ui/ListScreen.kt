package fr.jeremy.calepin.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.combinedClickable
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.lazy.staggeredgrid.LazyVerticalStaggeredGrid
import androidx.compose.foundation.lazy.staggeredgrid.StaggeredGridCells
import androidx.compose.foundation.lazy.staggeredgrid.items as gridItems
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.GridView
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.SaveAlt
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.SmartToy
import androidx.compose.material.icons.filled.Contacts
import androidx.compose.material.icons.filled.UnfoldMore
import androidx.compose.material.icons.filled.ViewAgenda
import androidx.compose.material.icons.filled.ViewHeadline
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.RadioButtonUnchecked
import androidx.compose.material.icons.filled.SelectAll
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.HelpOutline
import androidx.compose.material.icons.filled.PushPin
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.SportsEsports
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Card
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.draw.clip
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import fr.jeremy.calepin.BuildConfig
import fr.jeremy.calepin.DisplayMode
import fr.jeremy.calepin.NotesViewModel
import fr.jeremy.calepin.data.Note
import fr.jeremy.calepin.detect.EntityType
import fr.jeremy.calepin.search.Period
import fr.jeremy.calepin.search.Scope
import fr.jeremy.calepin.search.SearchOptions
import fr.jeremy.calepin.search.SearchResult
import fr.jeremy.calepin.search.Sort
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ListScreen(
    vm: NotesViewModel,
    onOpen: (Long) -> Unit,
    onNew: () -> Unit,
    onSettings: () -> Unit,
    onCalendar: () -> Unit,
    onAssistant: () -> Unit,
    onContacts: () -> Unit,
    onGames: () -> Unit,
) {
    val query by vm.query.collectAsStateWithLifecycle()
    val options by vm.options.collectAsStateWithLifecycle()
    val results by vm.results.collectAsStateWithLifecycle()
    val total by vm.noteCount.collectAsStateWithLifecycle()
    val tags by vm.allTags.collectAsStateWithLifecycle()
    var showFilters by remember { mutableStateOf(false) }
    var showHelp by remember { mutableStateOf(false) }
    var selected by remember { mutableStateOf(setOf<Long>()) }
    var confirmDelete by remember { mutableStateOf(false) }
    var exporting by remember { mutableStateOf<List<Note>?>(null) }
    var displayMenu by remember { mutableStateOf(false) }
    var expanded by remember { mutableStateOf(setOf<Long>()) }
    val display by vm.settings.display.collectAsStateWithLifecycle()
    val withAudio by vm.withAudio.collectAsStateWithLifecycle()
    val withMedia by vm.withMedia.collectAsStateWithLifecycle()
    val selecting = selected.isNotEmpty()
    val haptic = LocalHapticFeedback.current
    val currentFolder by vm.currentFolder.collectAsStateWithLifecycle()
    val folders by vm.folders.collectAsStateWithLifecycle()
    var movingSelection by remember { mutableStateOf(false) }

    // Retirer de la sélection les notes qui ne sont plus affichées
    val visibleIds = results.map { it.note.id }.toSet()
    LaunchedEffect(visibleIds) {
        if (!visibleIds.containsAll(selected)) selected = selected intersect visibleIds
    }

    BackHandler(enabled = selecting) { selected = emptySet() }
    // Retour : remonter d'un dossier avant de quitter l'appli
    BackHandler(enabled = !selecting && currentFolder != null) {
        val f = currentFolder.orEmpty()
        vm.openFolder(if (f.contains('/')) f.substringBeforeLast('/') else null)
    }

    Scaffold(
        topBar = {
            Column(
                Modifier
                    .statusBarsPadding()
                    .padding(start = 16.dp, end = 8.dp, top = 8.dp, bottom = 4.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                if (selecting) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconButton(onClick = { selected = emptySet() }) {
                            Icon(Icons.Filled.Close, contentDescription = "Annuler la sélection")
                        }
                        Text(
                            "${selected.size} sélectionnée${if (selected.size > 1) "s" else ""}",
                            style = MaterialTheme.typography.titleLarge,
                            modifier = Modifier.weight(1f),
                        )
                        IconButton(onClick = {
                            selected = if (selected.size == visibleIds.size) emptySet() else visibleIds
                        }) {
                            Icon(Icons.Filled.SelectAll, contentDescription = "Tout sélectionner")
                        }
                        IconButton(onClick = { movingSelection = true }) {
                            Icon(Icons.Filled.Folder, contentDescription = "Ranger dans un dossier")
                        }
                        IconButton(onClick = { exporting = vm.notesByIds(selected) }) {
                            Icon(Icons.Filled.SaveAlt, contentDescription = "Exporter")
                        }
                        IconButton(onClick = { confirmDelete = true }) {
                            Icon(
                                Icons.Filled.Delete, contentDescription = "Supprimer",
                                tint = MaterialTheme.colorScheme.error,
                            )
                        }
                    }
                    Text(
                        "Touchez d'autres notes pour les ajouter ou les retirer.",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(start = 12.dp, bottom = 8.dp),
                    )
                } else {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        if (BuildConfig.AI) "Calepin IA" else "Calepin",
                        style = MaterialTheme.typography.headlineMedium,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.primary,
                        maxLines = 1,
                        softWrap = false,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f),
                    )
                    IconButton(onClick = onContacts) {
                        Icon(Icons.Filled.Contacts, contentDescription = "Contacts")
                    }
                    IconButton(onClick = onCalendar) {
                        Icon(Icons.Filled.CalendarMonth, contentDescription = "Agenda")
                    }
                    Box {
                        IconButton(onClick = { displayMenu = true }) {
                            Icon(display.icon(), contentDescription = "Affichage : ${display.label}")
                        }
                        DropdownMenu(expanded = displayMenu, onDismissRequest = { displayMenu = false }) {
                            DisplayMode.entries.forEach { m ->
                                DropdownMenuItem(
                                    text = { Text(m.label) },
                                    leadingIcon = { Icon(m.icon(), contentDescription = null) },
                                    trailingIcon = { if (m == display) Icon(Icons.Filled.Check, contentDescription = "Choisi") },
                                    onClick = { vm.settings.setDisplay(m); displayMenu = false },
                                )
                            }
                            HorizontalDivider()
                            DropdownMenuItem(
                                text = { Text("Jeux : Tetris, casse-briques, Snake") },
                                leadingIcon = { Icon(Icons.Filled.SportsEsports, contentDescription = null) },
                                onClick = { displayMenu = false; onGames() },
                            )
                        }
                    }
                    IconButton(onClick = onAssistant) {
                        Icon(Icons.Filled.SmartToy, contentDescription = "Assistant")
                    }
                    IconButton(onClick = onSettings) {
                        Icon(Icons.Filled.Settings, contentDescription = "Paramètres")
                    }
                }
                Row(Modifier.padding(end = 8.dp)) {
                    OutlinedTextField(
                        value = query,
                        onValueChange = vm::setQuery,
                        modifier = Modifier.fillMaxWidth(),
                        placeholder = { Text("Rechercher : mot, \"phrase\", 06 12…, #tag") },
                        leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
                        trailingIcon = {
                            Row {
                                if (query.isNotEmpty()) {
                                    IconButton(onClick = { vm.setQuery("") }) {
                                        Icon(Icons.Filled.Close, contentDescription = "Effacer")
                                    }
                                }
                                IconButton(onClick = { showFilters = true }) {
                                    BadgedBox(badge = {
                                        if (options.activeCount > 0) Badge { Text("${options.activeCount}") }
                                    }) {
                                        Icon(Icons.Filled.Tune, contentDescription = "Filtres")
                                    }
                                }
                            }
                        },
                        singleLine = true,
                        shape = RoundedCornerShape(28.dp),
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                    )
                }
                val filtering = query.isNotBlank() || options.activeCount > 0
                Text(
                    (if (filtering) "${results.size} résultat${if (results.size > 1) "s" else ""} sur $total note${if (total > 1) "s" else ""}"
                    else "$total note${if (total > 1) "s" else ""}") + " · version ${BuildConfig.VERSION_NAME}",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(start = 4.dp),
                )
                FolderBar(vm, currentFolder, folders)
                }
            }
        },
        floatingActionButton = {
            if (!selecting) {
                ExtendedFloatingActionButton(
                    onClick = onNew,
                    icon = { Icon(Icons.Filled.Add, contentDescription = null) },
                    text = { Text("Nouvelle note") },
                )
            }
        },
    ) { pad ->
        if (results.isEmpty()) {
            Column(
                Modifier
                    .fillMaxSize()
                    .padding(pad)
                    .padding(32.dp),
                verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Text(
                    when {
                        total == 0 -> "Aucune note pour l'instant"
                        currentFolder != null && query.isBlank() && options.activeCount == 0 -> "Ce dossier est vide"
                        else -> "Aucune note ne correspond"
                    },
                    style = MaterialTheme.typography.titleMedium,
                )
                Spacer(Modifier.size(6.dp))
                Text(
                    when {
                        total == 0 -> "Touchez « Nouvelle note » pour commencer."
                        currentFolder != null && query.isBlank() && options.activeCount == 0 ->
                            "Créez une note ici, ou rangez-y des notes : appui long sur une note, puis l'icône dossier."
                        else -> "Essayez moins de mots, ou activez la tolérance aux fautes dans les filtres."
                    },
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        } else {
            val padding = PaddingValues(
                start = 16.dp, end = 16.dp,
                top = pad.calculateTopPadding() + 4.dp,
                bottom = pad.calculateBottomPadding() + 96.dp,
            )
            val itemFor: @Composable (SearchResult) -> Unit = { r ->
                val id = r.note.id
                val click: () -> Unit = {
                    if (selecting) selected = if (id in selected) selected - id else selected + id
                    else onOpen(id)
                }
                val longClick: () -> Unit = {
                    haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                    selected = if (id in selected) selected - id else selected + id
                }
                when (display) {
                    DisplayMode.COMPACT -> CompactRow(r, selecting, id in selected, id in withAudio, click, longClick)
                    DisplayMode.EXPAND -> ExpandRow(
                        r, selecting, id in selected, id in withAudio, id in expanded,
                        onToggle = { expanded = if (id in expanded) expanded - id else expanded + id },
                        onOpen = { onOpen(id) },
                        onClick = click, onLongClick = longClick,
                    )
                    else -> NoteCard(
                        r, selecting = selecting, isSelected = id in selected, hasAudio = id in withAudio,
                        hasMedia = id in withMedia,
                        folder = if (currentFolder == null) r.note.folder else "",
                        maxLines = if (display == DisplayMode.GRID) 7 else 4,
                        onClick = click, onLongClick = longClick,
                    )
                }
            }
            if (display == DisplayMode.GRID) {
                LazyVerticalStaggeredGrid(
                    columns = StaggeredGridCells.Fixed(2),
                    contentPadding = padding,
                    verticalItemSpacing = 10.dp,
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    gridItems(results, key = { it.note.id }) { r -> itemFor(r) }
                }
            } else {
                LazyColumn(
                    contentPadding = padding,
                    verticalArrangement = Arrangement.spacedBy(if (display == DisplayMode.COMPACT) 0.dp else 10.dp),
                ) {
                    items(results, key = { it.note.id }) { r -> itemFor(r) }
                }
            }
        }
    }

    if (showFilters) {
        FilterSheet(
            options = options,
            tags = tags,
            onChange = { f -> vm.updateOptions(f) },
            onDismiss = { showFilters = false },
            onHelp = { showFilters = false; showHelp = true },
        )
    }
    if (showHelp) {
        SearchHelpDialog(onDismiss = { showHelp = false })
    }
    exporting?.let { list ->
        ExportSheet(vm, list, onDismiss = { exporting = null; selected = emptySet() })
    }
    if (movingSelection) {
        val n = selected.size
        FolderPickerDialog(
            vm = vm,
            title = if (n > 1) "Ranger $n notes dans…" else "Ranger la note dans…",
            folders = folders,
            current = null,
            onDismiss = { movingSelection = false },
        ) { target ->
            vm.moveNotes(selected, target)
            movingSelection = false
            selected = emptySet()
        }
    }
    if (confirmDelete) {
        val n = selected.size
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            title = { Text(if (n > 1) "Supprimer $n notes ?" else "Supprimer cette note ?") },
            text = { Text("Elles seront définitivement effacées de ce téléphone.") },
            confirmButton = {
                TextButton(onClick = {
                    vm.deleteMany(selected)
                    selected = emptySet()
                    confirmDelete = false
                }) { Text("Supprimer", color = MaterialTheme.colorScheme.error) }
            },
            dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text("Annuler") } },
        )
    }
}

@Composable
fun highlighted(text: String, ranges: List<IntRange>): AnnotatedString {
    val style = SpanStyle(
        background = MaterialTheme.colorScheme.secondaryContainer,
        color = MaterialTheme.colorScheme.onSecondaryContainer,
        fontWeight = FontWeight.SemiBold,
    )
    return buildAnnotatedString {
        append(text)
        ranges.forEach { r ->
            val s = r.first.coerceIn(0, text.length)
            val e = (r.last + 1).coerceIn(0, text.length)
            if (s < e) addStyle(style, s, e)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class, ExperimentalFoundationApi::class)
@Composable
private fun NoteCard(
    r: SearchResult,
    selecting: Boolean,
    isSelected: Boolean,
    hasAudio: Boolean,
    hasMedia: Boolean,
    folder: String,
    maxLines: Int,
    onClick: () -> Unit,
    onLongClick: () -> Unit,
) {
    val note = r.note
    val shape = RoundedCornerShape(14.dp)
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clip(shape)
            .combinedClickable(onClick = onClick, onLongClick = onLongClick),
        shape = shape,
        colors = CardDefaults.cardColors(
            containerColor = if (isSelected) MaterialTheme.colorScheme.primaryContainer
            else MaterialTheme.colorScheme.surfaceContainerLow,
        ),
        border = if (isSelected) BorderStroke(2.dp, MaterialTheme.colorScheme.primary) else null,
    ) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (selecting) {
                    Icon(
                        if (isSelected) Icons.Filled.CheckCircle else Icons.Filled.RadioButtonUnchecked,
                        contentDescription = if (isSelected) "Sélectionnée" else "Non sélectionnée",
                        tint = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.size(22.dp),
                    )
                    Spacer(Modifier.width(10.dp))
                }
                if (note.pinned) {
                    Icon(
                        Icons.Filled.PushPin, contentDescription = "Épinglée",
                        tint = MaterialTheme.colorScheme.secondary,
                        modifier = Modifier.size(16.dp),
                    )
                    Spacer(Modifier.width(6.dp))
                }
                Text(
                    highlighted(note.title.ifBlank { "Sans titre" }, if (note.title.isBlank()) emptyList() else r.titleHighlights),
                    style = MaterialTheme.typography.titleMedium,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f),
                )
            }
            if (r.snippet.text.isNotBlank()) {
                Text(
                    highlighted(r.snippet.text, r.snippet.highlights),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = maxLines,
                    overflow = TextOverflow.Ellipsis,
                )
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (hasMedia) {
                    Icon(
                        Icons.Filled.Image, contentDescription = "Photos ou vidéos",
                        tint = MaterialTheme.colorScheme.secondary,
                        modifier = Modifier
                            .padding(end = 6.dp)
                            .size(16.dp),
                    )
                }
                if (hasAudio) {
                    Icon(
                        Icons.Filled.Mic, contentDescription = "Mémo vocal",
                        tint = MaterialTheme.colorScheme.secondary,
                        modifier = Modifier
                            .padding(end = 6.dp)
                            .size(16.dp),
                    )
                }
                r.entities.map { it.type }.distinct().sortedBy { it.ordinal }.forEach { t ->
                    Icon(
                        t.icon(), contentDescription = t.label,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier
                            .padding(end = 6.dp)
                            .size(16.dp),
                    )
                }
                if (r.approximate) {
                    Text(
                        "≈ approché",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.tertiary,
                    )
                }
                Spacer(Modifier.weight(1f))
                if (folder.isNotEmpty()) {
                    Icon(
                        Icons.Filled.Folder, contentDescription = "Dossier",
                        tint = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier
                            .padding(end = 3.dp)
                            .size(14.dp),
                    )
                    Text(
                        folderName(folder),
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f, fill = false),
                    )
                    Spacer(Modifier.width(8.dp))
                }
                if (note.tags.isNotEmpty()) {
                    Text(
                        note.tags.joinToString(" · "),
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.secondary,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f, fill = false),
                    )
                    Spacer(Modifier.width(8.dp))
                }
                Text(
                    shortDate(note.updatedAt),
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
    }
}

fun DisplayMode.icon(): ImageVector = when (this) {
    DisplayMode.CARDS -> Icons.Filled.ViewAgenda
    DisplayMode.COMPACT -> Icons.Filled.ViewHeadline
    DisplayMode.GRID -> Icons.Filled.GridView
    DisplayMode.EXPAND -> Icons.Filled.UnfoldMore
}

@Composable
private fun SelectMark(selecting: Boolean, isSelected: Boolean) {
    if (!selecting) return
    Icon(
        if (isSelected) Icons.Filled.CheckCircle else Icons.Filled.RadioButtonUnchecked,
        contentDescription = if (isSelected) "Sélectionnée" else "Non sélectionnée",
        tint = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
        modifier = Modifier
            .padding(end = 10.dp)
            .size(22.dp),
    )
}

/** Une ligne par note : titre, début du texte, date. */
@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun CompactRow(
    r: SearchResult,
    selecting: Boolean,
    isSelected: Boolean,
    hasAudio: Boolean,
    onClick: () -> Unit,
    onLongClick: () -> Unit,
) {
    val note = r.note
    Column(
        Modifier
            .fillMaxWidth()
            .background(if (isSelected) MaterialTheme.colorScheme.primaryContainer else Color.Transparent)
            .combinedClickable(onClick = onClick, onLongClick = onLongClick),
    ) {
        Row(Modifier.padding(horizontal = 4.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            SelectMark(selecting, isSelected)
            Column(Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (note.pinned) {
                        Icon(Icons.Filled.PushPin, "Épinglée", tint = MaterialTheme.colorScheme.secondary, modifier = Modifier.size(14.dp))
                        Spacer(Modifier.width(4.dp))
                    }
                    if (hasAudio) {
                        Icon(Icons.Filled.Mic, "Mémo vocal", tint = MaterialTheme.colorScheme.secondary, modifier = Modifier.size(14.dp))
                        Spacer(Modifier.width(4.dp))
                    }
                    Text(
                        highlighted(note.title.ifBlank { "Sans titre" }, if (note.title.isBlank()) emptyList() else r.titleHighlights),
                        style = MaterialTheme.typography.titleSmall,
                        maxLines = 1, overflow = TextOverflow.Ellipsis,
                    )
                }
                if (r.snippet.text.isNotBlank()) {
                    Text(
                        highlighted(r.snippet.text, r.snippet.highlights),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1, overflow = TextOverflow.Ellipsis,
                    )
                }
            }
            Spacer(Modifier.width(8.dp))
            Text(shortDate(note.updatedAt), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        HorizontalDivider()
    }
}

/** Titres seuls ; la flèche déplie le texte complet sur place. */
@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun ExpandRow(
    r: SearchResult,
    selecting: Boolean,
    isSelected: Boolean,
    hasAudio: Boolean,
    isExpanded: Boolean,
    onToggle: () -> Unit,
    onOpen: () -> Unit,
    onClick: () -> Unit,
    onLongClick: () -> Unit,
) {
    val note = r.note
    val shape = RoundedCornerShape(12.dp)
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clip(shape)
            .combinedClickable(onClick = { if (selecting) onClick() else onToggle() }, onLongClick = onLongClick),
        shape = shape,
        colors = CardDefaults.cardColors(
            containerColor = if (isSelected) MaterialTheme.colorScheme.primaryContainer
            else MaterialTheme.colorScheme.surfaceContainerLow,
        ),
        border = if (isSelected) BorderStroke(2.dp, MaterialTheme.colorScheme.primary) else null,
    ) {
        Column(Modifier.padding(start = 14.dp, end = 4.dp, top = 4.dp, bottom = 4.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                SelectMark(selecting, isSelected)
                if (note.pinned) {
                    Icon(Icons.Filled.PushPin, "Épinglée", tint = MaterialTheme.colorScheme.secondary, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(6.dp))
                }
                if (hasAudio) {
                    Icon(Icons.Filled.Mic, "Mémo vocal", tint = MaterialTheme.colorScheme.secondary, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(6.dp))
                }
                Text(
                    highlighted(note.title.ifBlank { "Sans titre" }, if (note.title.isBlank()) emptyList() else r.titleHighlights),
                    style = MaterialTheme.typography.titleMedium,
                    maxLines = 1, overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f),
                )
                IconButton(onClick = onToggle) {
                    Icon(
                        if (isExpanded) Icons.Filled.ExpandLess else Icons.Filled.ExpandMore,
                        contentDescription = if (isExpanded) "Replier" else "Déplier",
                    )
                }
            }
            AnimatedVisibility(visible = isExpanded) {
                Column(Modifier.padding(end = 10.dp, bottom = 6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(
                        note.content.ifBlank { "(note vide)" },
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            (if (note.tags.isNotEmpty()) note.tags.joinToString(" · ") + " · " else "") + shortDate(note.updatedAt),
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.secondary,
                            modifier = Modifier.weight(1f),
                        )
                        TextButton(onClick = onOpen) { Text("Ouvrir") }
                    }
                }
            }
        }
    }
}

fun shortDate(t: Long): String {
    val c = Calendar.getInstance().apply { timeInMillis = t }
    val now = Calendar.getInstance()
    val sameDay = c.get(Calendar.YEAR) == now.get(Calendar.YEAR) && c.get(Calendar.DAY_OF_YEAR) == now.get(Calendar.DAY_OF_YEAR)
    val pattern = when {
        sameDay -> "HH:mm"
        c.get(Calendar.YEAR) == now.get(Calendar.YEAR) -> "d MMM"
        else -> "d MMM yyyy"
    }
    return SimpleDateFormat(pattern, Locale.FRANCE).format(Date(t))
}

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
private fun FilterSheet(
    options: SearchOptions,
    tags: List<String>,
    onChange: (SearchOptions.() -> SearchOptions) -> Unit,
    onDismiss: () -> Unit,
    onHelp: () -> Unit,
) {
    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(
            Modifier
                .padding(horizontal = 20.dp)
                .padding(bottom = 32.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Filtres de recherche", style = MaterialTheme.typography.titleLarge, modifier = Modifier.weight(1f))
                TextButton(onClick = onHelp) { Text("Aide à la recherche") }
            }

            FilterSection("Chercher dans") {
                Scope.entries.forEach { s ->
                    FilterChip(
                        selected = options.scope == s,
                        onClick = { onChange { copy(scope = s) } },
                        label = { Text(s.label) },
                    )
                }
            }
            FilterSection("La note doit contenir") {
                EntityType.entries.forEach { t ->
                    val on = t in options.types
                    FilterChip(
                        selected = on,
                        onClick = { onChange { copy(types = if (on) types - t else types + t) } },
                        label = { Text(t.label) },
                        leadingIcon = { Icon(t.icon(), contentDescription = null, modifier = Modifier.size(18.dp)) },
                    )
                }
            }
            if (tags.isNotEmpty()) {
                FilterSection("Étiquettes (au moins une)") {
                    tags.forEach { tag ->
                        val on = options.tags.any { it.equals(tag, ignoreCase = true) }
                        FilterChip(
                            selected = on,
                            onClick = {
                                onChange {
                                    copy(tags = if (on) this.tags.filterNot { it.equals(tag, true) }.toSet() else this.tags + tag)
                                }
                            },
                            label = { Text(tag) },
                        )
                    }
                }
            }
            FilterSection("Modifiée") {
                Period.entries.forEach { p ->
                    FilterChip(
                        selected = options.period == p,
                        onClick = { onChange { copy(period = p) } },
                        label = { Text(p.label) },
                    )
                }
            }
            FilterSection("Trier par") {
                Sort.entries.forEach { s ->
                    FilterChip(
                        selected = options.sort == s,
                        onClick = { onChange { copy(sort = s) } },
                        label = { Text(s.label) },
                    )
                }
            }
            SwitchRow(
                "Tolérer les fautes de frappe",
                "« plombeir » trouve « plombier »",
                options.fuzzy,
            ) { v -> onChange { copy(fuzzy = v) } }
            SwitchRow("Notes épinglées uniquement", null, options.pinnedOnly) { v -> onChange { copy(pinnedOnly = v) } }

            TextButton(onClick = { onChange { SearchOptions() } }) { Text("Réinitialiser les filtres") }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun FilterSection(title: String, content: @Composable () -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text(title, style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) { content() }
    }
}

@Composable
private fun SwitchRow(title: String, subtitle: String?, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.bodyLarge)
            if (subtitle != null) {
                Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
private fun SearchHelpDialog(onDismiss: () -> Unit) {
    val rows = listOf(
        "villa rossi" to "les deux mots, dans n'importe quel ordre",
        "\"place aux herbes\"" to "l'expression exacte",
        "monaco OU menton" to "l'un ou l'autre",
        "clés -garage" to "exclut les notes contenant « garage »",
        "06 12 34" to "un numéro, avec ou sans espaces ; +33 6 12… trouve aussi 06 12…",
        "pays:italie  pays:+39" to "notes contenant un numéro de ce pays",
        "titre:devis" to "seulement dans le titre (contenu: pour le texte)",
        "#clients  tag:clients" to "par étiquette",
        "type:tel  type:adresse" to "notes contenant un téléphone, une adresse, une date, un mail, un lien",
        "date:14/10" to "notes qui mentionnent ce jour (ou date:10/2026)",
        "apres:01/09  avant:31/12" to "selon la date de modification",
        "est:epingle" to "notes épinglées",
    )
    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = { TextButton(onClick = onDismiss) { Text("Compris") } },
        title = { Text("Recherche avancée") },
        text = {
            Column(
                Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                Text(
                    "Majuscules et accents sont ignorés : « electricien » trouve « Électricien ».",
                    style = MaterialTheme.typography.bodyMedium,
                )
                rows.forEach { (ex, what) ->
                    Column {
                        Text(
                            ex,
                            fontFamily = FontFamily.Monospace,
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.primary,
                        )
                        Text(what, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        },
    )
}

