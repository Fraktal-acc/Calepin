package fr.jeremy.calepin.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.RadioButtonUnchecked
import androidx.compose.material.icons.filled.SelectAll
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.HelpOutline
import androidx.compose.material.icons.filled.PushPin
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import fr.jeremy.calepin.BuildConfig
import fr.jeremy.calepin.NotesViewModel
import fr.jeremy.calepin.detect.EntityType
import fr.jeremy.calepin.search.Period
import fr.jeremy.calepin.search.Scope
import fr.jeremy.calepin.search.SearchOptions
import fr.jeremy.calepin.search.SearchResult
import fr.jeremy.calepin.search.Sort
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ListScreen(vm: NotesViewModel, onOpen: (Long) -> Unit, onNew: () -> Unit) {
    val query by vm.query.collectAsStateWithLifecycle()
    val options by vm.options.collectAsStateWithLifecycle()
    val results by vm.results.collectAsStateWithLifecycle()
    val total by vm.noteCount.collectAsStateWithLifecycle()
    val tags by vm.allTags.collectAsStateWithLifecycle()
    var showFilters by remember { mutableStateOf(false) }
    var showHelp by remember { mutableStateOf(false) }
    var selected by remember { mutableStateOf(setOf<Long>()) }
    var confirmDelete by remember { mutableStateOf(false) }
    val selecting = selected.isNotEmpty()
    val haptic = LocalHapticFeedback.current

    // Retirer de la sélection les notes qui ne sont plus affichées
    val visibleIds = results.map { it.note.id }.toSet()
    LaunchedEffect(visibleIds) {
        if (!visibleIds.containsAll(selected)) selected = selected intersect visibleIds
    }

    BackHandler(enabled = selecting) { selected = emptySet() }

    Scaffold(
        topBar = {
            Column(
                Modifier
                    .statusBarsPadding()
                    .padding(start = 16.dp, end = 8.dp, top = 8.dp, bottom = 4.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                if (selecting) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconButton(onClick = { selected = emptySet() }) {
                            Icon(Icons.Filled.Close, contentDescription = "Annuler la sélection")
                        }
                        Text(
                            "${selected.size} sélectionnée${if (selected.size > 1) "s" else ""}",
                            style = MaterialTheme.typography.titleLarge,
                            modifier = Modifier.weight(1f),
                        )
                        IconButton(onClick = {
                            selected = if (selected.size == visibleIds.size) emptySet() else visibleIds
                        }) {
                            Icon(Icons.Filled.SelectAll, contentDescription = "Tout sélectionner")
                        }
                        IconButton(onClick = { confirmDelete = true }) {
                            Icon(
                                Icons.Filled.Delete, contentDescription = "Supprimer",
                                tint = MaterialTheme.colorScheme.error,
                            )
                        }
                    }
                    Text(
                        "Touchez d'autres notes pour les ajouter ou les retirer.",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(start = 12.dp, bottom = 8.dp),
                    )
                } else {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        "Calepin",
                        style = MaterialTheme.typography.headlineMedium,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.weight(1f),
                    )
                    IconButton(onClick = { showHelp = true }) {
                        Icon(Icons.Filled.HelpOutline, contentDescription = "Aide à la recherche")
                    }
                }
                Row(Modifier.padding(end = 8.dp)) {
                    OutlinedTextField(
                        value = query,
                        onValueChange = vm::setQuery,
                        modifier = Modifier.fillMaxWidth(),
                        placeholder = { Text("Rechercher : mot, \"phrase\", 06 12…, #tag") },
                        leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
                        trailingIcon = {
                            Row {
                                if (query.isNotEmpty()) {
                                    IconButton(onClick = { vm.setQuery("") }) {
                                        Icon(Icons.Filled.Close, contentDescription = "Effacer")
                                    }
                                }
                                IconButton(onClick = { showFilters = true }) {
                                    BadgedBox(badge = {
                                        if (options.activeCount > 0) Badge { Text("${options.activeCount}") }
                                    }) {
                                        Icon(Icons.Filled.Tune, contentDescription = "Filtres")
                                    }
                                }
                            }
                        },
                        singleLine = true,
                        shape = RoundedCornerShape(28.dp),
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                    )
                }
                val filtering = query.isNotBlank() || options.activeCount > 0
                Text(
                    (if (filtering) "${results.size} résultat${if (results.size > 1) "s" else ""} sur $total note${if (total > 1) "s" else ""}"
                    else "$total note${if (total > 1) "s" else ""}") + " · version ${BuildConfig.VERSION_NAME}",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(start = 4.dp),
                )
                }
            }
        },
        floatingActionButton = {
            if (!selecting) {
                ExtendedFloatingActionButton(
                    onClick = onNew,
                    icon = { Icon(Icons.Filled.Add, contentDescription = null) },
                    text = { Text("Nouvelle note") },
                )
            }
        },
    ) { pad ->
        if (results.isEmpty()) {
            Column(
                Modifier
                    .fillMaxSize()
                    .padding(pad)
                    .padding(32.dp),
                verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Text(
                    if (total == 0) "Aucune note pour l'instant" else "Aucune note ne correspond",
                    style = MaterialTheme.typography.titleMedium,
                )
                Spacer(Modifier.size(6.dp))
                Text(
                    if (total == 0) "Touchez « Nouvelle note » pour commencer."
                    else "Essayez moins de mots, ou activez la tolérance aux fautes dans les filtres.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        } else {
            LazyColumn(
                contentPadding = PaddingValues(
                    start = 16.dp, end = 16.dp,
                    top = pad.calculateTopPadding() + 4.dp,
                    bottom = pad.calculateBottomPadding() + 96.dp,
                ),
                verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                items(results, key = { it.note.id }) { r ->
                    val id = r.note.id
                    NoteCard(
                        r,
                        selecting = selecting,
                        isSelected = id in selected,
                        onClick = {
                            if (selecting) selected = if (id in selected) selected - id else selected + id
                            else onOpen(id)
                        },
                        onLongClick = {
                            haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                            selected = if (id in selected) selected - id else selected + id
                        },
                    )
                }
            }
        }
    }

    if (showFilters) {
        FilterSheet(
            options = options,
            tags = tags,
            onChange = { f -> vm.updateOptions(f) },
            onDismiss = { showFilters = false },
        )
    }
    if (showHelp) {
        SearchHelpDialog(onDismiss = { showHelp = false })
    }
    if (confirmDelete) {
        val n = selected.size
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            title = { Text(if (n > 1) "Supprimer $n notes ?" else "Supprimer cette note ?") },
            text = { Text("Elles seront définitivement effacées de ce téléphone.") },
            confirmButton = {
                TextButton(onClick = {
                    vm.deleteMany(selected)
                    selected = emptySet()
                    confirmDelete = false
                }) { Text("Supprimer", color = MaterialTheme.colorScheme.error) }
            },
            dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text("Annuler") } },
        )
    }
}

@Composable
fun highlighted(text: String, ranges: List<IntRange>): AnnotatedString {
    val style = SpanStyle(
        background = MaterialTheme.colorScheme.secondaryContainer,
        color = MaterialTheme.colorScheme.onSecondaryContainer,
        fontWeight = FontWeight.SemiBold,
    )
    return buildAnnotatedString {
        append(text)
        ranges.forEach { r ->
            val s = r.first.coerceIn(0, text.length)
            val e = (r.last + 1).coerceIn(0, text.length)
            if (s < e) addStyle(style, s, e)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class, ExperimentalFoundationApi::class)
@Composable
private fun NoteCard(
    r: SearchResult,
    selecting: Boolean,
    isSelected: Boolean,
    onClick: () -> Unit,
    onLongClick: () -> Unit,
) {
    val note = r.note
    val shape = RoundedCornerShape(14.dp)
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clip(shape)
            .combinedClickable(onClick = onClick, onLongClick = onLongClick),
        shape = shape,
        colors = CardDefaults.cardColors(
            containerColor = if (isSelected) MaterialTheme.colorScheme.primaryContainer
            else MaterialTheme.colorScheme.surfaceContainerLow,
        ),
        border = if (isSelected) BorderStroke(2.dp, MaterialTheme.colorScheme.primary) else null,
    ) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (selecting) {
                    Icon(
                        if (isSelected) Icons.Filled.CheckCircle else Icons.Filled.RadioButtonUnchecked,
                        contentDescription = if (isSelected) "Sélectionnée" else "Non sélectionnée",
                        tint = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.size(22.dp),
                    )
                    Spacer(Modifier.width(10.dp))
                }
                if (note.pinned) {
                    Icon(
                        Icons.Filled.PushPin, contentDescription = "Épinglée",
                        tint = MaterialTheme.colorScheme.secondary,
                        modifier = Modifier.size(16.dp),
                    )
                    Spacer(Modifier.width(6.dp))
                }
                Text(
                    highlighted(note.title.ifBlank { "Sans titre" }, if (note.title.isBlank()) emptyList() else r.titleHighlights),
                    style = MaterialTheme.typography.titleMedium,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f),
                )
            }
            if (r.snippet.text.isNotBlank()) {
                Text(
                    highlighted(r.snippet.text, r.snippet.highlights),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 4,
                    overflow = TextOverflow.Ellipsis,
                )
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                r.entities.map { it.type }.distinct().sortedBy { it.ordinal }.forEach { t ->
                    Icon(
                        t.icon(), contentDescription = t.label,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier
                            .padding(end = 6.dp)
                            .size(16.dp),
                    )
                }
                if (r.approximate) {
                    Text(
                        "≈ approché",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.tertiary,
                    )
                }
                Spacer(Modifier.weight(1f))
                if (note.tags.isNotEmpty()) {
                    Text(
                        note.tags.joinToString(" · "),
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.secondary,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f, fill = false),
                    )
                    Spacer(Modifier.width(8.dp))
                }
                Text(
                    shortDate(note.updatedAt),
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
    }
}

fun shortDate(t: Long): String {
    val c = Calendar.getInstance().apply { timeInMillis = t }
    val now = Calendar.getInstance()
    val sameDay = c.get(Calendar.YEAR) == now.get(Calendar.YEAR) && c.get(Calendar.DAY_OF_YEAR) == now.get(Calendar.DAY_OF_YEAR)
    val pattern = when {
        sameDay -> "HH:mm"
        c.get(Calendar.YEAR) == now.get(Calendar.YEAR) -> "d MMM"
        else -> "d MMM yyyy"
    }
    return SimpleDateFormat(pattern, Locale.FRANCE).format(Date(t))
}

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
private fun FilterSheet(
    options: SearchOptions,
    tags: List<String>,
    onChange: (SearchOptions.() -> SearchOptions) -> Unit,
    onDismiss: () -> Unit,
) {
    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(
            Modifier
                .padding(horizontal = 20.dp)
                .padding(bottom = 32.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            Text("Filtres de recherche", style = MaterialTheme.typography.titleLarge)

            FilterSection("Chercher dans") {
                Scope.entries.forEach { s ->
                    FilterChip(
                        selected = options.scope == s,
                        onClick = { onChange { copy(scope = s) } },
                        label = { Text(s.label) },
                    )
                }
            }
            FilterSection("La note doit contenir") {
                EntityType.entries.forEach { t ->
                    val on = t in options.types
                    FilterChip(
                        selected = on,
                        onClick = { onChange { copy(types = if (on) types - t else types + t) } },
                        label = { Text(t.label) },
                        leadingIcon = { Icon(t.icon(), contentDescription = null, modifier = Modifier.size(18.dp)) },
                    )
                }
            }
            if (tags.isNotEmpty()) {
                FilterSection("Étiquettes (au moins une)") {
                    tags.forEach { tag ->
                        val on = options.tags.any { it.equals(tag, ignoreCase = true) }
                        FilterChip(
                            selected = on,
                            onClick = {
                                onChange {
                                    copy(tags = if (on) this.tags.filterNot { it.equals(tag, true) }.toSet() else this.tags + tag)
                                }
                            },
                            label = { Text(tag) },
                        )
                    }
                }
            }
            FilterSection("Modifiée") {
                Period.entries.forEach { p ->
                    FilterChip(
                        selected = options.period == p,
                        onClick = { onChange { copy(period = p) } },
                        label = { Text(p.label) },
                    )
                }
            }
            FilterSection("Trier par") {
                Sort.entries.forEach { s ->
                    FilterChip(
                        selected = options.sort == s,
                        onClick = { onChange { copy(sort = s) } },
                        label = { Text(s.label) },
                    )
                }
            }
            SwitchRow(
                "Tolérer les fautes de frappe",
                "« plombeir » trouve « plombier »",
                options.fuzzy,
            ) { v -> onChange { copy(fuzzy = v) } }
            SwitchRow("Notes épinglées uniquement", null, options.pinnedOnly) { v -> onChange { copy(pinnedOnly = v) } }

            TextButton(onClick = { onChange { SearchOptions() } }) { Text("Réinitialiser les filtres") }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun FilterSection(title: String, content: @Composable () -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text(title, style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) { content() }
    }
}

@Composable
private fun SwitchRow(title: String, subtitle: String?, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.bodyLarge)
            if (subtitle != null) {
                Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
private fun SearchHelpDialog(onDismiss: () -> Unit) {
    val rows = listOf(
        "villa rossi" to "les deux mots, dans n'importe quel ordre",
        "\"place aux herbes\"" to "l'expression exacte",
        "monaco OU menton" to "l'un ou l'autre",
        "clés -garage" to "exclut les notes contenant « garage »",
        "06 12 34" to "un numéro, avec ou sans espaces ; +33 6 12… trouve aussi 06 12…",
        "pays:italie  pays:+39" to "notes contenant un numéro de ce pays",
        "titre:devis" to "seulement dans le titre (contenu: pour le texte)",
        "#clients  tag:clients" to "par étiquette",
        "type:tel  type:adresse" to "notes contenant un téléphone, une adresse, une date, un mail, un lien",
        "date:14/10" to "notes qui mentionnent ce jour (ou date:10/2026)",
        "apres:01/09  avant:31/12" to "selon la date de modification",
        "est:epingle" to "notes épinglées",
    )
    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = { TextButton(onClick = onDismiss) { Text("Compris") } },
        title = { Text("Recherche avancée") },
        text = {
            Column(
                Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                Text(
                    "Majuscules et accents sont ignorés : « electricien » trouve « Électricien ».",
                    style = MaterialTheme.typography.bodyMedium,
                )
                rows.forEach { (ex, what) ->
                    Column {
                        Text(
                            ex,
                            fontFamily = FontFamily.Monospace,
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.primary,
                        )
                        Text(what, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        },
    )
}

