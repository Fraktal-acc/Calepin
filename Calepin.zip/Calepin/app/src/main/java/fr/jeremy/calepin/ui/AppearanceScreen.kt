package fr.jeremy.calepin.ui

import android.os.Build
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import fr.jeremy.calepin.DisplayMode
import fr.jeremy.calepin.NotesViewModel

/** Thèmes de couleur, mode sombre, taille du texte, formes, accueil et affichage des notes. */
@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun AppearanceScreen(vm: NotesViewModel, onClose: () -> Unit) {
    val ctx = LocalContext.current
    val a = remember { Appearance.get(ctx) }
    val palette by a.palette.collectAsStateWithLifecycle()
    val dark by a.dark.collectAsStateWithLifecycle()
    val text by a.text.collectAsStateWithLifecycle()
    val shapes by a.shapes.collectAsStateWithLifecycle()
    val home by a.home.collectAsStateWithLifecycle()
    val display by vm.settings.display.collectAsStateWithLifecycle()
    BackHandler { onClose() }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Apparence") },
                navigationIcon = { IconButton(onClick = onClose) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Retour") } },
            )
        },
    ) { pad ->
        Column(
            Modifier
                .fillMaxSize()
                .padding(pad)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp)
                .padding(bottom = 40.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            Text(
                "Tout se change aussi à la voix : « thème océan », « mode sombre », « texte plus grand », « accueil en liste »…",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )

            Title("Couleurs")
            FlowRow(horizontalArrangement = Arrangement.spacedBy(12.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Palette.entries.filter { it != Palette.DYNAMIQUE || Build.VERSION.SDK_INT >= 31 }.forEach { p ->
                    Swatch(p, selected = p == palette) { a.setPalette(p) }
                }
            }

            Title("Mode")
            Chips(DarkMode.entries, dark, { it.label }) { a.setDark(it) }

            Title("Taille du texte")
            Chips(TextSize.entries, text, { it.label }) { a.setText(it) }

            Title("Formes")
            Chips(ShapeStyle.entries, shapes, { it.label }) { a.setShapes(it) }

            Title("Écran d'accueil")
            Chips(HomeStyle.entries, home, { it.label }) { a.setHome(it) }

            Title("Affichage des notes")
            Chips(DisplayMode.entries, display, { it.label }) { vm.settings.setDisplay(it) }

            // Aperçu
            Title("Aperçu")
            Surface(color = MaterialTheme.colorScheme.surfaceContainerLow, shape = MaterialTheme.shapes.large) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Visite villa Cap-Martin", style = MaterialTheme.typography.titleMedium)
                    Text("Rendez-vous avec M. Rossi le 14 octobre à 10h30.", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Surface(color = MaterialTheme.colorScheme.primaryContainer, shape = MaterialTheme.shapes.small) {
                            Text("Clients", Modifier.padding(horizontal = 10.dp, vertical = 4.dp), color = MaterialTheme.colorScheme.onPrimaryContainer, style = MaterialTheme.typography.labelMedium)
                        }
                        Surface(color = MaterialTheme.colorScheme.secondaryContainer, shape = MaterialTheme.shapes.small) {
                            Text("Urgent", Modifier.padding(horizontal = 10.dp, vertical = 4.dp), color = MaterialTheme.colorScheme.onSecondaryContainer, style = MaterialTheme.typography.labelMedium)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun Title(t: String) {
    Text(t, style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary)
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun <T> Chips(items: List<T>, selected: T, label: (T) -> String, onPick: (T) -> Unit) {
    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        items.forEach { v -> FilterChip(selected = v == selected, onClick = { onPick(v) }, label = { Text(label(v)) }) }
    }
}

@Composable
private fun Swatch(p: Palette, selected: Boolean, onClick: () -> Unit) {
    Column(
        Modifier
            .width(76.dp)
            .clip(RoundedCornerShape(12.dp))
            .clickable(onClick = onClick)
            .padding(4.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Box(
            Modifier
                .size(52.dp)
                .clip(CircleShape)
                .border(if (selected) BorderStroke(3.dp, MaterialTheme.colorScheme.onSurface) else BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant), CircleShape),
            contentAlignment = Alignment.Center,
        ) {
            if (p == Palette.DYNAMIQUE) {
                Box(Modifier.size(52.dp).background(MaterialTheme.colorScheme.surfaceVariant))
                Text("Auto", style = MaterialTheme.typography.labelSmall)
            } else {
                Row(Modifier.size(52.dp)) {
                    Box(Modifier.weight(2f).size(52.dp).background(Color(p.primary)))
                    Column(Modifier.weight(1f)) {
                        Box(Modifier.weight(1f).size(26.dp).background(Color(p.secondary)))
                        Box(Modifier.weight(1f).size(26.dp).background(Color(p.tertiary)))
                    }
                }
            }
            if (selected) {
                Surface(shape = CircleShape, color = MaterialTheme.colorScheme.surface) {
                    Icon(Icons.Filled.Check, "Choisi", Modifier.size(20.dp).padding(2.dp))
                }
            }
        }
        Text(p.label, style = MaterialTheme.typography.labelSmall, textAlign = TextAlign.Center, maxLines = 2)
    }
}
