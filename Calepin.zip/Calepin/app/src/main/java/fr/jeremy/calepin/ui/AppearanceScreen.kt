package fr.jeremy.calepin.ui

import android.os.Build
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Spacer
import androidx.compose.material.icons.filled.Casino
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Switch
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.res.painterResource
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import fr.jeremy.calepin.i18n.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import fr.jeremy.calepin.DisplayMode
import fr.jeremy.calepin.NotesViewModel

/** Thèmes de couleur, mode sombre, taille du texte, formes, accueil et affichage des notes. */
@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun AppearanceScreen(vm: NotesViewModel, onClose: () -> Unit) {
    val ctx = LocalContext.current
    val a = remember { Appearance.get(ctx) }
    val palette by a.palette.collectAsStateWithLifecycle()
    val dark by a.dark.collectAsStateWithLifecycle()
    val text by a.text.collectAsStateWithLifecycle()
    val shapes by a.shapes.collectAsStateWithLifecycle()
    val home by a.home.collectAsStateWithLifecycle()
    val font by a.font.collectAsStateWithLifecycle()
    val icons by a.icons.collectAsStateWithLifecycle()
    val bodyFont by a.bodyFont.collectAsStateWithLifecycle()
    val animations by a.animations.collectAsStateWithLifecycle()
    val widgetStyle by a.widgetStyle.collectAsStateWithLifecycle()
    var launcher by remember { mutableStateOf(LauncherIcon.current(ctx)) }
    val display by vm.settings.display.collectAsStateWithLifecycle()
    BackHandler { onClose() }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Apparence") },
                navigationIcon = { IconButton(onClick = onClose) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Retour") } },
            )
        },
    ) { pad ->
        Column(
            Modifier
                .fillMaxSize()
                .padding(pad)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp)
                .padding(bottom = 40.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            Text(
                "Tout se change aussi à la voix : « thème cyberpunk », « dark fantasy », « thème aléatoire », « icônes néon », « mode sombre », « texte plus grand »…",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )

            Title("Thèmes")
            listOf(
                0 to "Classiques",
                1 to "Ambiances animées",
                2 to "Inspirés des films, séries et mangas",
                3 to "Spéciaux",
            ).forEach { (g, name) ->
                Text(name, style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(12.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Palette.entries.filter { it.group == g && (it != Palette.DYNAMIQUE || Build.VERSION.SDK_INT >= 31) }.forEach { p ->
                        Swatch(p, selected = p == palette) { a.setPalette(p) }
                    }
                }
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Décors animés", style = MaterialTheme.typography.bodyLarge)
                    Text("Étoiles, neige, pluie, braises… Désactive pour économiser la batterie.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                Switch(checked = animations, onCheckedChange = { a.setAnimations(it) })
            }
            if (palette == Palette.ALEATOIRE) {
                OutlinedButton(onClick = { a.reroll() }) {
                    Icon(Icons.Filled.Casino, null)
                    Spacer(Modifier.width(8.dp))
                    Text("Nouveau tirage")
                }
            }

            Title("Fond personnel")
            WallpaperSection()

            Title("Mode")
            if (a.spec(palette).forceDark != null) {
                Text(
                    "Ce thème a sa propre ambiance ; le réglage ci-dessous sert pour les autres thèmes (« Noir » assombrit encore le fond).",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            Chips(DarkMode.entries, dark, { it.label }) { a.setDark(it) }

            Title("Style des icônes")
            FlowRow(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                IconStyle.entries.forEach { st ->
                    val sel = st == icons
                    Column(
                        Modifier
                            .width(92.dp.grow())
                            .clip(MaterialTheme.shapes.medium)
                            .border(if (sel) 2.dp else 1.dp, if (sel) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant, MaterialTheme.shapes.medium)
                            .clickable { a.setIcons(st) }
                            .padding(8.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(6.dp),
                    ) {
                        val shown = if (st == IconStyle.AUTO) LocalLook.current.let { Appearance.iconsFor(it.deco, it.dark) } else st
                        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            ThemedIcon(AppIcon.NOTES, 0, 34.dp, shown)
                            ThemedIcon(AppIcon.GAMES, 1, 34.dp, shown)
                        }
                        Text(st.label, style = MaterialTheme.typography.labelSmall, textAlign = TextAlign.Center, maxLines = 2)
                    }
                }
            }

            Title("Icône de l'appli")
            Text(
                "L'icône change sur l'écran du téléphone après quelques secondes. Si tu l'avais posée sur l'écran d'accueil, il faudra peut-être la remettre.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            FlowRow(horizontalArrangement = Arrangement.spacedBy(12.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                LauncherIcon.entries.forEach { li ->
                    val sel = li == launcher
                    Column(
                        Modifier
                            .width(76.dp.grow())
                            .clip(RoundedCornerShape(12.dp))
                            .clickable {
                                runCatching { LauncherIcon.apply(ctx, li) }
                                launcher = li
                            }
                            .padding(4.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                    ) {
                        Box(
                            Modifier
                                .size(60.dp)
                                .clip(CircleShape)
                                .background(Color(li.bgColor))
                                .border(if (sel) BorderStroke(3.dp, MaterialTheme.colorScheme.primary) else BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant), CircleShape),
                            contentAlignment = Alignment.Center,
                        ) {
                            li.bg?.let { Image(painterResource(it), null, Modifier.size(90.dp)) }
                            Image(painterResource(li.fg), null, Modifier.size(90.dp))
                        }
                        Text(li.label, style = MaterialTheme.typography.labelSmall, textAlign = TextAlign.Center)
                    }
                }
            }

            Title("Police des titres")
            FontChips(FontChoice.entries.filter { it.available(ctx) }, font) { a.setFont(it) }
            Title("Police du texte")
            FontChips(FontChoice.entries.filter { !it.display && it.available(ctx) }, bodyFont) { a.setBodyFont(it) }

            Title("Style des widgets")
            Text("Pour les widgets posés sur l'écran du téléphone.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Chips(WidgetStyle.entries, widgetStyle, { it.label }) {
                a.setWidgetStyle(it)
                fr.jeremy.calepin.widgets.Widgets.refreshAll(ctx)
            }

            Title("Taille du texte")
            Chips(TextSize.entries, text, { it.label }) { a.setText(it) }

            Title("Formes")
            Chips(ShapeStyle.entries, shapes, { it.label }) { a.setShapes(it) }

            Title("Écran d'accueil")
            Chips(HomeStyle.entries, home, { it.label }) { a.setHome(it) }

            Title("Affichage des notes")
            Chips(DisplayMode.entries, display, { it.label }) { vm.settings.setDisplay(it) }

            // Aperçu
            Title("Aperçu")
            Surface(color = MaterialTheme.colorScheme.surfaceContainerLow, shape = MaterialTheme.shapes.large) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Visite villa Cap-Martin", style = MaterialTheme.typography.titleMedium)
                    Text("Rendez-vous avec M. Rossi le 14 octobre à 10h30.", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Surface(color = MaterialTheme.colorScheme.primaryContainer, shape = MaterialTheme.shapes.small) {
                            Text("Clients", Modifier.padding(horizontal = 10.dp, vertical = 4.dp), color = MaterialTheme.colorScheme.onPrimaryContainer, style = MaterialTheme.typography.labelMedium)
                        }
                        Surface(color = MaterialTheme.colorScheme.secondaryContainer, shape = MaterialTheme.shapes.small) {
                            Text("Urgent", Modifier.padding(horizontal = 10.dp, vertical = 4.dp), color = MaterialTheme.colorScheme.onSecondaryContainer, style = MaterialTheme.typography.labelMedium)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun Title(t: String) {
    Text(t, style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary)
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun <T> Chips(items: List<T>, selected: T, label: (T) -> String, onPick: (T) -> Unit) {
    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        items.forEach { v -> FilterChip(selected = v == selected, onClick = { onPick(v) }, label = { Text(label(v)) }) }
    }
}

/** Puces de polices, chacune écrite dans sa propre police. */
@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun FontChips(items: List<FontChoice>, selected: FontChoice, onPick: (FontChoice) -> Unit) {
    val ctx = LocalContext.current
    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        items.forEach { f ->
            FilterChip(
                selected = f == selected,
                onClick = { onPick(f) },
                label = { Text(f.label, fontFamily = if (f == FontChoice.AUTO) null else f.family(ctx)) },
            )
        }
    }
}

@Composable
private fun Swatch(p: Palette, selected: Boolean, onClick: () -> Unit) {
    Column(
        Modifier
            .width(76.dp.grow())
            .clip(RoundedCornerShape(12.dp))
            .clickable(onClick = onClick)
            .padding(4.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Box(
            Modifier
                .size(52.dp)
                .clip(CircleShape)
                .border(if (selected) BorderStroke(3.dp, MaterialTheme.colorScheme.onSurface) else BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant), CircleShape),
            contentAlignment = Alignment.Center,
        ) {
            if (p == Palette.DYNAMIQUE) {
                Box(Modifier.size(52.dp).background(MaterialTheme.colorScheme.surfaceVariant))
                Text("Auto", style = MaterialTheme.typography.labelSmall)
            } else if (p == Palette.ALEATOIRE) {
                Box(Modifier.size(52.dp).background(Brush.sweepGradient(listOf(Color(0xFFFF2BD6), Color(0xFF00F0FF), Color(0xFFF5FF3B), Color(0xFF33FF66), Color(0xFFFF2BD6)))))
                Icon(Icons.Filled.Casino, null, tint = Color.White)
            } else if (p.forceDark == true) {
                // Thèmes à ambiance : fond sombre et trois touches de couleur
                Box(Modifier.size(52.dp).background(Color(p.neutral)))
                Row(horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                    listOf(p.primary, p.secondary, p.tertiary).forEach { c ->
                        Box(Modifier.size(9.dp).clip(CircleShape).background(Color(c)))
                    }
                }
            } else {
                Row(Modifier.size(52.dp)) {
                    Box(Modifier.weight(2f).size(52.dp).background(Color(p.primary)))
                    Column(Modifier.weight(1f)) {
                        Box(Modifier.weight(1f).size(26.dp).background(Color(p.secondary)))
                        Box(Modifier.weight(1f).size(26.dp).background(Color(p.tertiary)))
                    }
                }
            }
            if (selected) {
                Surface(shape = CircleShape, color = MaterialTheme.colorScheme.surface) {
                    Icon(Icons.Filled.Check, "Choisi", Modifier.size(20.dp).padding(2.dp))
                }
            }
        }
        Text(p.label, style = MaterialTheme.typography.labelSmall, textAlign = TextAlign.Center, maxLines = 2)
    }
}
