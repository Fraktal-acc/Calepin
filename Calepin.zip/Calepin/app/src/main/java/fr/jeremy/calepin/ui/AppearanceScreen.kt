package fr.jeremy.calepin.ui

import android.os.Build
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Spacer
import androidx.compose.material.icons.filled.Casino
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material3.Checkbox
import androidx.compose.material.icons.filled.BookmarkAdd
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.TextButton
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.graphics.toArgb
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Switch
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.res.painterResource
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.FontDownload
import androidx.compose.material.icons.filled.FormatColorText
import androidx.compose.material.icons.filled.FormatSize
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.Wallpaper
import androidx.compose.material.icons.filled.Widgets
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import fr.jeremy.calepin.i18n.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import fr.jeremy.calepin.DisplayMode
import fr.jeremy.calepin.NotesViewModel

/** Thèmes de couleur, mode sombre, taille du texte, formes, accueil et affichage des notes. */
@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun AppearanceScreen(vm: NotesViewModel, onClose: () -> Unit) {
    val ctx = LocalContext.current
    val a = remember { Appearance.get(ctx) }
    val palette by a.palette.collectAsStateWithLifecycle()
    val dark by a.dark.collectAsStateWithLifecycle()
    val text by a.text.collectAsStateWithLifecycle()
    val shapes by a.shapes.collectAsStateWithLifecycle()
    val home by a.home.collectAsStateWithLifecycle()
    val font by a.font.collectAsStateWithLifecycle()
    val icons by a.icons.collectAsStateWithLifecycle()
    val bodyFont by a.bodyFont.collectAsStateWithLifecycle()
    val animations by a.animations.collectAsStateWithLifecycle()
    val widgetStyle by a.widgetStyle.collectAsStateWithLifecycle()
    var launcher by remember { mutableStateOf(LauncherIcon.current(ctx)) }
    val display by vm.settings.display.collectAsStateWithLifecycle()
    val customs by a.customThemes.collectAsStateWithLifecycle()
    val customId by a.customId.collectAsStateWithLifecycle()
    val textColor by a.textColor.collectAsStateWithLifecycle()
    val titleColor by a.titleColor.collectAsStateWithLifecycle()
    val borderColor by a.borderColor.collectAsStateWithLifecycle()
    val widgetBorder by a.widgetBorder.collectAsStateWithLifecycle()
    val widgetText by a.widgetText.collectAsStateWithLifecycle()
    val random by a.random.collectAsStateWithLifecycle()
    // Fenêtres : nommer un thème gardé, renommer ou supprimer un thème perso
    var naming by remember { mutableStateOf<String?>(null) }
    var renaming by remember { mutableStateOf<CustomTheme?>(null) }
    var deleting by remember { mutableStateOf<CustomTheme?>(null) }
    BackHandler { onClose() }
    val currentPalette: Palette = palette
    val themeName: String = if (currentPalette == Palette.PERSO) customs.firstOrNull { it.id == customId }?.name ?: currentPalette.label else currentPalette.label

    Scaffold(
        topBar = {
            TopAppBar(
                title = { fr.jeremy.calepin.ui.FitText("Apparence") },
                navigationIcon = { IconButton(onClick = onClose) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Retour") } },
            )
        },
    ) { pad ->
        Column(
            Modifier
                .fillMaxSize()
                .padding(pad)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp)
                .padding(bottom = 40.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            Text(
                "Tout se change aussi à la voix : « thème cyberpunk », « dark fantasy », « thème aléatoire », « icônes néon », « mode sombre », « texte plus grand »…",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )

            FoldSection("Thèmes", Icons.Filled.Palette, summary = themeName) {
                // Mes thèmes : les tirages au sort gardés et nommés
                Text("Mes thèmes", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
                if (customs.isEmpty()) {
                    Text(
                        "Aucun pour l'instant : choisis « Aléatoire » (Spéciaux, plus bas), tire au sort jusqu'à trouver un thème qui te plaît, puis touche « Garder ce thème ».",
                        style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                } else {
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(12.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        customs.forEach { c ->
                            SpecSwatch(c.spec, c.name, selected = palette == Palette.PERSO && c.id == customId) { a.selectCustom(c.id) }
                        }
                    }
                    val current = customs.firstOrNull { it.id == customId }
                    if (palette == Palette.PERSO && current != null) {
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(onClick = { renaming = current }) { Text("Renommer") }
                            OutlinedButton(onClick = { deleting = current }) { Text("Supprimer") }
                        }
                    }
                }
                listOf(
                    0 to "Classiques",
                    1 to "Ambiances animées",
                    2 to "Inspirés des films, séries et mangas",
                    3 to "Spéciaux",
                ).forEach { (g, name) ->
                    Text(name, style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(12.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Palette.entries.filter { it.group == g && (it != Palette.DYNAMIQUE || Build.VERSION.SDK_INT >= 31) }.forEach { p ->
                            Swatch(p, selected = p == palette) { a.setPalette(p) }
                        }
                    }
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Décors animés", style = MaterialTheme.typography.bodyLarge)
                        Text("Étoiles, neige, pluie, braises… Désactive pour économiser la batterie.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    Switch(checked = animations, onCheckedChange = { a.setAnimations(it) })
                }
                if (palette == Palette.ALEATOIRE) {
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = { a.reroll() }) {
                            Icon(Icons.Filled.Casino, null)
                            Spacer(Modifier.width(8.dp))
                            Text("Nouveau tirage")
                        }
                        Button(onClick = { naming = "" }) {
                            Icon(Icons.Filled.BookmarkAdd, null)
                            Spacer(Modifier.width(8.dp))
                            Text("Garder ce thème")
                        }
                    }
                }
            }

            FoldSection("Fond personnel", Icons.Filled.Wallpaper) {
                WallpaperSection()
            }

            FoldSection("Mode clair / sombre", Icons.Filled.DarkMode, summary = dark.label) {
                if (a.spec(palette).forceDark != null) {
                    Text(
                        "Ce thème a sa propre ambiance ; le réglage ci-dessous sert pour les autres thèmes (« Noir » assombrit encore le fond).",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                Chips(DarkMode.entries, dark, { it.label }) { a.setDark(it) }
            }

            FoldSection("Couleurs du texte et bordures", Icons.Filled.FormatColorText) {
                SubTitle("Couleur du texte")
                ColorPrefRow(textColor, allowNone = false) { a.setTextColor(it) }
                SubTitle("Couleur des titres")
                ColorPrefRow(titleColor, allowNone = false) { a.setTitleColor(it) }
                SubTitle("Bordures")
                Text("Cartes, tuiles, bulles, champs de saisie et séparateurs.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                ColorPrefRow(borderColor, allowNone = true) { a.setBorderColor(it) }
            }

            FoldSection("Polices", Icons.Filled.FontDownload, summary = "${font.label} · ${bodyFont.label}") {
                SubTitle("Police des titres")
                FontChips(FontChoice.entries.filter { it.available(ctx) }, font) { a.setFont(it) }
                SubTitle("Police du texte")
                FontChips(FontChoice.entries.filter { it.available(ctx) }, bodyFont) { a.setBodyFont(it) }
                Text(
                    "Toutes les polices sont possibles pour le texte ; les plus décoratives se lisent moins bien sur les longues notes.",
                    style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }

            FoldSection("Taille du texte et formes", Icons.Filled.FormatSize, summary = "${text.label} · ${shapes.label}") {
                SubTitle("Taille du texte")
                Chips(TextSize.entries, text, { it.label }) { a.setText(it) }
                SubTitle("Formes")
                Chips(ShapeStyle.entries, shapes, { it.label }) { a.setShapes(it) }
            }

            FoldSection("Icônes", Icons.Filled.Apps, summary = icons.label) {
                SubTitle("Style des icônes")
                FlowRow(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    IconStyle.entries.forEach { st ->
                        val sel = st == icons
                        Column(
                            Modifier
                                .width(92.dp.grow())
                                .clip(MaterialTheme.shapes.medium)
                                .border(if (sel) 2.dp else 1.dp, if (sel) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant, MaterialTheme.shapes.medium)
                                .clickable { a.setIcons(st) }
                                .padding(8.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(6.dp),
                        ) {
                            val shown = if (st == IconStyle.AUTO) LocalLook.current.let { Appearance.iconsFor(it.deco, it.dark) } else st
                            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                ThemedIcon(AppIcon.NOTES, 0, 34.dp, shown)
                                ThemedIcon(AppIcon.GAMES, 1, 34.dp, shown)
                            }
                            Text(st.label, style = MaterialTheme.typography.labelSmall, textAlign = TextAlign.Center, maxLines = 2)
                        }
                    }
                }
                SubTitle("Icône de l'appli")
                Text(
                    "L'icône change sur l'écran du téléphone après quelques secondes. Si tu l'avais posée sur l'écran d'accueil, il faudra peut-être la remettre.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                FlowRow(horizontalArrangement = Arrangement.spacedBy(12.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    LauncherIcon.entries.forEach { li ->
                        val sel = li == launcher
                        Column(
                            Modifier
                                .width(76.dp.grow())
                                .clip(RoundedCornerShape(12.dp))
                                .clickable {
                                    runCatching { LauncherIcon.apply(ctx, li) }
                                    launcher = li
                                }
                                .padding(4.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                        ) {
                            Box(
                                Modifier
                                    .size(60.dp)
                                    .clip(CircleShape)
                                    .background(Color(li.bgColor))
                                    .border(if (sel) BorderStroke(3.dp, MaterialTheme.colorScheme.primary) else BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant), CircleShape),
                                contentAlignment = Alignment.Center,
                            ) {
                                li.bg?.let { Image(painterResource(it), null, Modifier.size(90.dp)) }
                                Image(painterResource(li.fg), null, Modifier.size(90.dp))
                            }
                            Text(li.label, style = MaterialTheme.typography.labelSmall, textAlign = TextAlign.Center)
                        }
                    }
                }
            }

            FoldSection("Accueil et notes", Icons.Filled.Home, summary = "${home.label} · ${display.label}") {
                SubTitle("Écran d'accueil")
                HomeStylePicker(home) { a.setHome(it) }
                val showWeather by a.showWeather.collectAsStateWithLifecycle()
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Météo sur l'accueil", style = MaterialTheme.typography.bodyLarge)
                        Text("Selon ta position, ta ville ou ton code postal", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    Switch(checked = showWeather, onCheckedChange = { a.setShowWeather(it) })
                }
                HomeTilesEditor(a)
                SubTitle("Affichage des notes")
                Chips(DisplayMode.entries, display, { it.label }) { vm.settings.setDisplay(it) }
            }

            FoldSection("Widgets", Icons.Filled.Widgets, summary = widgetStyle.label) {
                SubTitle("Style des widgets")
                Text("Pour les widgets posés sur l'écran du téléphone.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Chips(WidgetStyle.entries, widgetStyle, { it.label }) {
                    a.setWidgetStyle(it)
                    fr.jeremy.calepin.widgets.Widgets.refreshAll(ctx)
                }
                Text("Bordure des widgets", style = MaterialTheme.typography.bodyMedium)
                ColorPrefRow(widgetBorder, allowNone = false, autoLabel = "Aucune") {
                    a.setWidgetBorder(it)
                    fr.jeremy.calepin.widgets.Widgets.refreshAll(ctx)
                }
                Text("Texte des widgets", style = MaterialTheme.typography.bodyMedium)
                ColorPrefRow(widgetText, allowNone = false) {
                    a.setWidgetText(it)
                    fr.jeremy.calepin.widgets.Widgets.refreshAll(ctx)
                }
            }
        }
    }

    naming?.let { initial ->
        NameDialog(
            title = "Garder ce thème",
            initial = initial,
            onDismiss = { naming = null },
            onSave = { name -> a.saveCustom(name, random); naming = null },
        )
    }
    renaming?.let { c ->
        NameDialog(
            title = "Renommer le thème",
            initial = c.name,
            onDismiss = { renaming = null },
            onSave = { name -> a.renameCustom(c.id, name); renaming = null },
        )
    }
    deleting?.let { c ->
        AlertDialog(
            onDismissRequest = { deleting = null },
            title = { Text("Supprimer « ${c.name} » ?") },
            text = { Text("Le thème disparaît de « Mes thèmes ». Calepin reprend le thème Méditerranée.") },
            confirmButton = { TextButton(onClick = { a.deleteCustom(c.id); deleting = null }) { Text("Supprimer", color = MaterialTheme.colorScheme.error) } },
            dismissButton = { TextButton(onClick = { deleting = null }) { Text("Annuler") } },
        )
    }
}

/**
 * Rubriques de l'accueil : cocher pour afficher, flèches pour changer l'ordre.
 * « Paramètres » reste toujours affiché (pour pouvoir revenir ici).
 */
@Composable
private fun HomeTilesEditor(a: Appearance) {
    val order by a.homeTiles.collectAsStateWithLifecycle()
    // Les rubriques absentes de cette version (télécommande, maison sans Calepin IA) ne sont pas proposées
    val available = Appearance.HOME_TILES.filter { fr.jeremy.calepin.BuildConfig.AI || (it != "remote" && it != "devices") }
    val rows = order.filter { it in available } + available.filter { it !in order }
    Text("Rubriques affichées et leur ordre", style = MaterialTheme.typography.bodyMedium)
    Surface(color = MaterialTheme.colorScheme.surfaceContainerLow, shape = MaterialTheme.shapes.medium, border = appBorder()) {
        Column(Modifier.padding(vertical = 4.dp)) {
            rows.forEachIndexed { i, id ->
                val shown = id in order
                Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(
                        checked = shown,
                        enabled = id != "settings",
                        onCheckedChange = { on -> a.setHomeTiles(if (on) rows.filter { it in order || it == id } else order - id) },
                    )
                    FitText(Appearance.HOME_TILE_LABELS[id] ?: id, Modifier.weight(1f), style = MaterialTheme.typography.bodyLarge)
                    IconButton(onClick = { a.setHomeTiles(rows.move(i, i - 1).filter { it in order }) }, enabled = shown && i > 0) {
                        Icon(Icons.Filled.KeyboardArrowUp, "Monter")
                    }
                    IconButton(onClick = { a.setHomeTiles(rows.move(i, i + 1).filter { it in order }) }, enabled = shown && i < rows.lastIndex) {
                        Icon(Icons.Filled.KeyboardArrowDown, "Descendre")
                    }
                }
            }
        }
    }
}

private fun <T> List<T>.move(from: Int, to: Int): List<T> {
    if (to !in indices || from !in indices) return this
    val m = toMutableList()
    val x = m.removeAt(from)
    m.add(to, x)
    return m
}

/** Nom d'un thème perso. */
@Composable
private fun NameDialog(title: String, initial: String, onDismiss: () -> Unit, onSave: (String) -> Unit) {
    var name by remember { mutableStateOf(initial) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            OutlinedTextField(
                value = name,
                onValueChange = { name = it.take(40) },
                label = { Text("Nom du thème") },
                singleLine = true,
            )
        },
        confirmButton = { TextButton(onClick = { onSave(name) }, enabled = name.isNotBlank()) { Text("Enregistrer") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Annuler") } },
    )
}

/** Couleurs proposées pour le texte, les titres et les bordures. */
private val PRESET_COLORS = listOf(
    0xFFFFFFFF, 0xFFE0E0E0, 0xFF9E9E9E, 0xFF424242, 0xFF000000,
    0xFFD32F2F, 0xFFFF5722, 0xFFFF9800, 0xFFD4AF37, 0xFFFFEB3B,
    0xFF8BC34A, 0xFF2E7D32, 0xFF009688, 0xFF00E5FF, 0xFF1E88E5,
    0xFF3949AB, 0xFF8E24AA, 0xFFEC407A, 0xFFFF2BD6, 0xFF795548,
)

/**
 * Choix d'une couleur : « Auto » (celle du thème), « Aucune » si [allowNone], les couleurs du thème,
 * des couleurs toutes prêtes, et « Autre » pour en composer une.
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun ColorPrefRow(current: Long, allowNone: Boolean, autoLabel: String = "Auto", onPick: (Long) -> Unit) {
    val cs = MaterialTheme.colorScheme
    var custom by remember { mutableStateOf(false) }
    val themeColors = listOf(cs.primary, cs.secondary, cs.tertiary).map { ColorPref.of(it) }
    val all = (themeColors + PRESET_COLORS).distinct()
    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        FilterChip(selected = current == ColorPref.AUTO, onClick = { onPick(ColorPref.AUTO) }, label = { Text(autoLabel) })
        if (allowNone) FilterChip(selected = current == ColorPref.NONE, onClick = { onPick(ColorPref.NONE) }, label = { Text("Aucune") })
        all.forEach { v ->
            ColorDot(Color(v.toInt()), selected = current == v) { onPick(v) }
        }
        // Couleur composée à la main (affichée si elle n'est pas dans la liste)
        if (current != ColorPref.AUTO && current != ColorPref.NONE && current !in all) {
            ColorDot(Color(current.toInt()), selected = true) { custom = true }
        }
        FilterChip(selected = false, onClick = { custom = true }, label = { Text("Autre…") })
    }
    if (custom) {
        ColorDialog(
            initial = ColorPref.color(current) ?: cs.primary,
            onDismiss = { custom = false },
            onPick = { onPick(ColorPref.of(it)); custom = false },
        )
    }
}

@Composable
private fun ColorDot(c: Color, selected: Boolean, onClick: () -> Unit) {
    Box(
        Modifier
            .size(34.dp)
            .clip(CircleShape)
            .background(c)
            .border(if (selected) 3.dp else 1.dp, if (selected) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.outlineVariant, CircleShape)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        if (selected) Icon(Icons.Filled.Check, "Choisi", tint = if (c.luminance() > 0.5f) Color.Black else Color.White, modifier = Modifier.size(18.dp))
    }
}

/** Couleur composée : teinte, intensité et luminosité. */
@Composable
private fun ColorDialog(initial: Color, onDismiss: () -> Unit, onPick: (Color) -> Unit) {
    val hsv = remember {
        FloatArray(3).also { android.graphics.Color.colorToHSV(initial.toArgb(), it) }
    }
    var hue by remember { mutableStateOf(hsv[0]) }
    var sat by remember { mutableStateOf(hsv[1]) }
    var value by remember { mutableStateOf(hsv[2]) }
    val c = Color.hsv(hue.coerceIn(0f, 359.9f), sat.coerceIn(0f, 1f), value.coerceIn(0f, 1f))
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Autre couleur") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Box(Modifier.fillMaxWidth().height(44.dp).clip(RoundedCornerShape(10.dp)).background(c))
                Text("Teinte", style = MaterialTheme.typography.labelMedium)
                Box(
                    Modifier.fillMaxWidth().height(10.dp).clip(RoundedCornerShape(5.dp)).background(
                        Brush.horizontalGradient((0..6).map { Color.hsv(it * 59.99f, 1f, 1f) }),
                    ),
                )
                Slider(value = hue, onValueChange = { hue = it }, valueRange = 0f..359.9f)
                Text("Intensité", style = MaterialTheme.typography.labelMedium)
                Slider(value = sat, onValueChange = { sat = it })
                Text("Luminosité", style = MaterialTheme.typography.labelMedium)
                Slider(value = value, onValueChange = { value = it })
            }
        },
        confirmButton = { TextButton(onClick = { onPick(c) }) { Text("Choisir") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Annuler") } },
    )
}

/** Pastille d'un thème perso, dessinée à partir de ses couleurs. */
@Composable
private fun SpecSwatch(sp: ThemeSpec, name: String, selected: Boolean, onClick: () -> Unit) {
    Column(
        Modifier
            .width(76.dp.grow())
            .clip(RoundedCornerShape(12.dp))
            .clickable(onClick = onClick)
            .padding(4.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Box(
            Modifier
                .size(52.dp)
                .clip(CircleShape)
                .border(if (selected) BorderStroke(3.dp, MaterialTheme.colorScheme.onSurface) else BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant), CircleShape),
            contentAlignment = Alignment.Center,
        ) {
            Box(Modifier.size(52.dp).background(sp.neutral))
            Row(horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                listOf(sp.primary, sp.secondary, sp.tertiary).forEach { c ->
                    Box(Modifier.size(10.dp).clip(CircleShape).background(c))
                }
            }
            if (selected) {
                Surface(shape = CircleShape, color = MaterialTheme.colorScheme.surface, modifier = Modifier.align(Alignment.BottomEnd)) {
                    Icon(Icons.Filled.Check, "Choisi", Modifier.size(18.dp).padding(2.dp))
                }
            }
        }
        fr.jeremy.calepin.i18n.RawText(name, style = MaterialTheme.typography.labelSmall, textAlign = TextAlign.Center, maxLines = 2)
    }
}


@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun <T> Chips(items: List<T>, selected: T, label: (T) -> String, onPick: (T) -> Unit) {
    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        items.forEach { v -> FilterChip(selected = v == selected, onClick = { onPick(v) }, label = { Text(label(v)) }) }
    }
}

/** Puces de polices, chacune écrite dans sa propre police. */
@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun FontChips(items: List<FontChoice>, selected: FontChoice, onPick: (FontChoice) -> Unit) {
    val ctx = LocalContext.current
    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        items.forEach { f ->
            FilterChip(
                selected = f == selected,
                onClick = { onPick(f) },
                label = { Text(f.label, fontFamily = if (f == FontChoice.AUTO) null else f.family(ctx)) },
            )
        }
    }
}

@Composable
private fun Swatch(p: Palette, selected: Boolean, onClick: () -> Unit) {
    Column(
        Modifier
            .width(76.dp.grow())
            .clip(RoundedCornerShape(12.dp))
            .clickable(onClick = onClick)
            .padding(4.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Box(
            Modifier
                .size(52.dp)
                .clip(CircleShape)
                .border(if (selected) BorderStroke(3.dp, MaterialTheme.colorScheme.onSurface) else BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant), CircleShape),
            contentAlignment = Alignment.Center,
        ) {
            if (p == Palette.DYNAMIQUE) {
                Box(Modifier.size(52.dp).background(MaterialTheme.colorScheme.surfaceVariant))
                Text("Auto", style = MaterialTheme.typography.labelSmall)
            } else if (p == Palette.ALEATOIRE) {
                Box(Modifier.size(52.dp).background(Brush.sweepGradient(listOf(Color(0xFFFF2BD6), Color(0xFF00F0FF), Color(0xFFF5FF3B), Color(0xFF33FF66), Color(0xFFFF2BD6)))))
                Icon(Icons.Filled.Casino, null, tint = Color.White)
            } else if (p.forceDark == true) {
                // Thèmes à ambiance : fond sombre et trois touches de couleur
                Box(Modifier.size(52.dp).background(Color(p.neutral)))
                Row(horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                    listOf(p.primary, p.secondary, p.tertiary).forEach { c ->
                        Box(Modifier.size(9.dp).clip(CircleShape).background(Color(c)))
                    }
                }
            } else {
                Row(Modifier.size(52.dp)) {
                    Box(Modifier.weight(2f).size(52.dp).background(Color(p.primary)))
                    Column(Modifier.weight(1f)) {
                        Box(Modifier.weight(1f).size(26.dp).background(Color(p.secondary)))
                        Box(Modifier.weight(1f).size(26.dp).background(Color(p.tertiary)))
                    }
                }
            }
            if (selected) {
                Surface(shape = CircleShape, color = MaterialTheme.colorScheme.surface) {
                    Icon(Icons.Filled.Check, "Choisi", Modifier.size(20.dp).padding(2.dp))
                }
            }
        }
        Text(p.label, style = MaterialTheme.typography.labelSmall, textAlign = TextAlign.Center, maxLines = 2)
    }
}
