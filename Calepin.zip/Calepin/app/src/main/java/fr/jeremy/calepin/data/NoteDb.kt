package fr.jeremy.calepin.data

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

/** Stockage local SQLite, sans dépendance externe. */
class NoteDb(context: Context) : SQLiteOpenHelper(context, "calepin.db", null, 6) {

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            """
            CREATE TABLE notes (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                title TEXT NOT NULL DEFAULT '',
                content TEXT NOT NULL DEFAULT '',
                tag TEXT NOT NULL DEFAULT '',
                pinned INTEGER NOT NULL DEFAULT 0,
                created_at INTEGER NOT NULL,
                updated_at INTEGER NOT NULL
            )
            """.trimIndent()
        )
        createRecordings(db)
        db.execSQL("ALTER TABLE recordings ADD COLUMN transcript TEXT NOT NULL DEFAULT ''")
        createV3(db)
        upgradeV4(db)
        upgradeV5(db)
        upgradeV6(db)
    }

    /** Corbeille (notes supprimées gardées 30 jours) et versions précédentes des notes. */
    private fun upgradeV6(db: SQLiteDatabase) {
        db.execSQL("ALTER TABLE notes ADD COLUMN deleted_at INTEGER NOT NULL DEFAULT 0")
        // Rappels qui se répètent : "", "day", "weekdays", "week", "month", "year"
        db.execSQL("ALTER TABLE events ADD COLUMN repeat TEXT NOT NULL DEFAULT ''")
        db.execSQL(
            "CREATE TABLE IF NOT EXISTS note_versions (id INTEGER PRIMARY KEY AUTOINCREMENT, note_id INTEGER NOT NULL, " +
                "title TEXT NOT NULL DEFAULT '', content TEXT NOT NULL DEFAULT '', saved_at INTEGER NOT NULL)"
        )
    }

    private fun upgradeV5(db: SQLiteDatabase) {
        db.execSQL("ALTER TABLE notes ADD COLUMN folder TEXT NOT NULL DEFAULT ''")
        db.execSQL("CREATE TABLE IF NOT EXISTS folders (path TEXT PRIMARY KEY, created_at INTEGER NOT NULL)")
    }

    private fun upgradeV4(db: SQLiteDatabase) {
        db.execSQL("ALTER TABLE events ADD COLUMN end_time INTEGER NOT NULL DEFAULT 0")
        db.execSQL("ALTER TABLE events ADD COLUMN category TEXT NOT NULL DEFAULT ''")
    }

    private fun createV3(db: SQLiteDatabase) {
        db.execSQL(
            """
            CREATE TABLE IF NOT EXISTS attachments (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                note_id INTEGER NOT NULL,
                file_name TEXT NOT NULL,
                is_video INTEGER NOT NULL,
                created_at INTEGER NOT NULL
            )
            """.trimIndent()
        )
        db.execSQL(
            """
            CREATE TABLE IF NOT EXISTS events (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                note_id INTEGER NOT NULL DEFAULT 0,
                title TEXT NOT NULL,
                start INTEGER NOT NULL,
                all_day INTEGER NOT NULL DEFAULT 0,
                remind_minutes INTEGER NOT NULL DEFAULT -1,
                alarm INTEGER NOT NULL DEFAULT 0,
                ringtone TEXT NOT NULL DEFAULT '',
                created_at INTEGER NOT NULL
            )
            """.trimIndent()
        )
    }

    private fun createRecordings(db: SQLiteDatabase) {
        db.execSQL(
            """
            CREATE TABLE IF NOT EXISTS recordings (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                note_id INTEGER NOT NULL,
                file_name TEXT NOT NULL,
                format TEXT NOT NULL,
                duration_ms INTEGER NOT NULL,
                created_at INTEGER NOT NULL
            )
            """.trimIndent()
        )
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        if (oldVersion < 2) createRecordings(db)
        if (oldVersion < 3) {
            db.execSQL("ALTER TABLE recordings ADD COLUMN transcript TEXT NOT NULL DEFAULT ''")
            createV3(db)
        }
        if (oldVersion < 4) upgradeV4(db)
        if (oldVersion < 5) upgradeV5(db)
        if (oldVersion < 6) upgradeV6(db)
    }

    fun all(): List<Note> = query("deleted_at = 0")

    /** Notes de la corbeille, avec leur date de suppression. */
    fun trashed(): List<Pair<Note, Long>> {
        val notes = query("deleted_at > 0")
        val at = readableDatabase.rawQuery("SELECT id, deleted_at FROM notes WHERE deleted_at > 0", null).use { c ->
            buildMap { while (c.moveToNext()) put(c.getLong(0), c.getLong(1)) }
        }
        return notes.map { it to (at[it.id] ?: 0L) }.sortedByDescending { it.second }
    }

    fun softDelete(id: Long) {
        writableDatabase.execSQL("UPDATE notes SET deleted_at = ? WHERE id = ?", arrayOf<Any>(System.currentTimeMillis(), id))
    }

    fun restore(id: Long) {
        writableDatabase.execSQL("UPDATE notes SET deleted_at = 0 WHERE id = ?", arrayOf<Any>(id))
    }

    /** Identifiants des notes à la corbeille depuis plus de [days] jours. */
    fun expired(days: Int): List<Long> =
        readableDatabase.rawQuery("SELECT id FROM notes WHERE deleted_at > 0 AND deleted_at < ?", arrayOf((System.currentTimeMillis() - days * 86_400_000L).toString()))
            .use { c -> buildList { while (c.moveToNext()) add(c.getLong(0)) } }

    // ------------------------------------------------------- Versions

    fun addVersion(noteId: Long, title: String, content: String, keep: Int = 30) {
        val w = writableDatabase
        w.insert("note_versions", null, ContentValues().apply {
            put("note_id", noteId); put("title", title); put("content", content); put("saved_at", System.currentTimeMillis())
        })
        w.execSQL(
            "DELETE FROM note_versions WHERE note_id = ? AND id NOT IN (SELECT id FROM note_versions WHERE note_id = ? ORDER BY saved_at DESC LIMIT ?)",
            arrayOf<Any>(noteId, noteId, keep),
        )
    }

    fun lastVersionAt(noteId: Long): Long =
        readableDatabase.rawQuery("SELECT MAX(saved_at) FROM note_versions WHERE note_id = ?", arrayOf(noteId.toString()))
            .use { c -> if (c.moveToFirst() && !c.isNull(0)) c.getLong(0) else 0L }

    /** Versions précédentes d'une note : (titre, texte, date), la plus récente d'abord. */
    fun versions(noteId: Long): List<Triple<String, String, Long>> =
        readableDatabase.rawQuery("SELECT title, content, saved_at FROM note_versions WHERE note_id = ? ORDER BY saved_at DESC", arrayOf(noteId.toString()))
            .use { c -> buildList { while (c.moveToNext()) add(Triple(c.getString(0), c.getString(1), c.getLong(2))) } }

    private fun query(where: String): List<Note> =
        readableDatabase.query("notes", null, where, null, null, null, "updated_at DESC").use { c ->
            val iId = c.getColumnIndexOrThrow("id")
            val iTitle = c.getColumnIndexOrThrow("title")
            val iContent = c.getColumnIndexOrThrow("content")
            val iTag = c.getColumnIndexOrThrow("tag")
            val iPinned = c.getColumnIndexOrThrow("pinned")
            val iCreated = c.getColumnIndexOrThrow("created_at")
            val iUpdated = c.getColumnIndexOrThrow("updated_at")
            val iFolder = c.getColumnIndexOrThrow("folder")
            buildList {
                while (c.moveToNext()) {
                    add(
                        Note(
                            id = c.getLong(iId),
                            title = c.getString(iTitle),
                            content = c.getString(iContent),
                            tag = c.getString(iTag),
                            pinned = c.getInt(iPinned) == 1,
                            createdAt = c.getLong(iCreated),
                            updatedAt = c.getLong(iUpdated),
                            folder = c.getString(iFolder),
                        )
                    )
                }
            }
        }

    /** Insère ou met à jour, renvoie l'identifiant de la note. */
    fun upsert(n: Note): Long {
        val v = ContentValues().apply {
            put("title", n.title)
            put("content", n.content)
            put("tag", n.tag)
            put("pinned", if (n.pinned) 1 else 0)
            put("created_at", n.createdAt)
            put("updated_at", n.updatedAt)
            put("folder", n.folder)
        }
        return if (n.id == 0L) {
            writableDatabase.insert("notes", null, v)
        } else {
            writableDatabase.update("notes", v, "id=?", arrayOf(n.id.toString()))
            n.id
        }
    }

    fun delete(id: Long) {
        writableDatabase.delete("notes", "id=?", arrayOf(id.toString()))
        writableDatabase.delete("note_versions", "note_id=?", arrayOf(id.toString()))
    }

    // ------------------------------------------------------- Dossiers

    /** Dossiers créés (même vides). Les dossiers des notes s'y ajoutent dans le ViewModel. */
    fun folders(): List<String> =
        readableDatabase.query("folders", arrayOf("path"), null, null, null, null, null).use { c ->
            buildList { while (c.moveToNext()) add(c.getString(0)) }
        }

    fun addFolder(path: String) {
        writableDatabase.insertWithOnConflict(
            "folders", null,
            ContentValues().apply { put("path", path); put("created_at", System.currentTimeMillis()) },
            SQLiteDatabase.CONFLICT_IGNORE,
        )
    }

    /** Chemins « parent/… » : comparaison exacte (LIKE ignorerait la casse). */
    private fun under(col: String) = "substr($col, 1, ?) = ?"

    /** Renomme ou déplace un dossier et tout ce qu'il contient (sous-dossiers et notes). */
    fun renameFolder(from: String, to: String) {
        val w = writableDatabase
        val prefix = "$from/"
        w.beginTransaction()
        try {
            w.execSQL(
                "UPDATE notes SET folder = ? || substr(folder, ?) WHERE folder = ? OR ${under("folder")}",
                arrayOf<Any>(to, from.length + 1, from, prefix.length, prefix),
            )
            val olds = w.rawQuery(
                "SELECT path FROM folders WHERE path = ? OR ${under("path")}",
                arrayOf(from, prefix.length.toString(), prefix),
            ).use { c -> buildList { while (c.moveToNext()) add(c.getString(0)) } }
            olds.forEach { old ->
                w.delete("folders", "path=?", arrayOf(old))
                addFolder(to + old.substring(from.length))
            }
            w.setTransactionSuccessful()
        } finally {
            w.endTransaction()
        }
    }

    /** Supprime un dossier : ses notes et sous-dossiers remontent dans le dossier parent (rien n'est effacé). */
    fun deleteFolder(path: String) {
        val parent = path.substringBeforeLast('/', "")
        val prefix = "$path/"
        val w = writableDatabase
        w.beginTransaction()
        try {
            // « a/b » devient « a » ; « a/b/c » devient « a/c »
            w.execSQL("UPDATE notes SET folder = ? WHERE folder = ?", arrayOf<Any>(parent, path))
            w.execSQL(
                "UPDATE notes SET folder = ? || substr(folder, ?) WHERE ${under("folder")}",
                arrayOf<Any>(if (parent.isEmpty()) "" else "$parent/", prefix.length + 1, prefix.length, prefix),
            )
            val subs = w.rawQuery(
                "SELECT path FROM folders WHERE ${under("path")}",
                arrayOf(prefix.length.toString(), prefix),
            ).use { c -> buildList { while (c.moveToNext()) add(c.getString(0)) } }
            w.delete("folders", "path=?", arrayOf(path))
            subs.forEach { sub ->
                w.delete("folders", "path=?", arrayOf(sub))
                val rest = sub.substring(prefix.length)
                addFolder(if (parent.isEmpty()) rest else "$parent/$rest")
            }
            w.setTransactionSuccessful()
        } finally {
            w.endTransaction()
        }
    }

    fun moveNotes(ids: Collection<Long>, folder: String) {
        val w = writableDatabase
        w.beginTransaction()
        try {
            ids.forEach { id -> w.update("notes", ContentValues().apply { put("folder", folder) }, "id=?", arrayOf(id.toString())) }
            w.setTransactionSuccessful()
        } finally {
            w.endTransaction()
        }
    }

    // ------------------------------------------------------- Enregistrements

    fun recordings(noteId: Long? = null): List<Recording> {
        val sel = if (noteId != null) "note_id=?" else null
        val args = if (noteId != null) arrayOf(noteId.toString()) else null
        return readableDatabase.query("recordings", null, sel, args, null, null, "created_at ASC").use { c ->
            val iId = c.getColumnIndexOrThrow("id")
            val iNote = c.getColumnIndexOrThrow("note_id")
            val iFile = c.getColumnIndexOrThrow("file_name")
            val iFmt = c.getColumnIndexOrThrow("format")
            val iDur = c.getColumnIndexOrThrow("duration_ms")
            val iCreated = c.getColumnIndexOrThrow("created_at")
            val iText = c.getColumnIndexOrThrow("transcript")
            buildList {
                while (c.moveToNext()) {
                    add(
                        Recording(
                            id = c.getLong(iId), noteId = c.getLong(iNote), fileName = c.getString(iFile),
                            format = c.getString(iFmt), durationMs = c.getLong(iDur), createdAt = c.getLong(iCreated),
                            transcript = c.getString(iText),
                        )
                    )
                }
            }
        }
    }

    fun insertRecording(r: Recording): Long {
        val v = ContentValues().apply {
            put("note_id", r.noteId)
            put("file_name", r.fileName)
            put("format", r.format)
            put("duration_ms", r.durationMs)
            put("created_at", r.createdAt)
        }
        return writableDatabase.insert("recordings", null, v)
    }

    fun deleteRecording(id: Long) {
        writableDatabase.delete("recordings", "id=?", arrayOf(id.toString()))
    }

    fun setTranscript(id: Long, text: String) {
        writableDatabase.update("recordings", ContentValues().apply { put("transcript", text) }, "id=?", arrayOf(id.toString()))
    }

    // ------------------------------------------------------- Photos, vidéos

    fun attachments(noteId: Long? = null): List<Attachment> {
        val sel = if (noteId != null) "note_id=?" else null
        val args = if (noteId != null) arrayOf(noteId.toString()) else null
        return readableDatabase.query("attachments", null, sel, args, null, null, "created_at ASC").use { c ->
            buildList {
                while (c.moveToNext()) {
                    add(
                        Attachment(
                            id = c.getLong(c.getColumnIndexOrThrow("id")),
                            noteId = c.getLong(c.getColumnIndexOrThrow("note_id")),
                            fileName = c.getString(c.getColumnIndexOrThrow("file_name")),
                            isVideo = c.getInt(c.getColumnIndexOrThrow("is_video")) == 1,
                            createdAt = c.getLong(c.getColumnIndexOrThrow("created_at")),
                        )
                    )
                }
            }
        }
    }

    fun insertAttachment(a: Attachment): Long = writableDatabase.insert(
        "attachments", null,
        ContentValues().apply {
            put("note_id", a.noteId); put("file_name", a.fileName)
            put("is_video", if (a.isVideo) 1 else 0); put("created_at", a.createdAt)
        },
    )

    fun deleteAttachment(id: Long) {
        writableDatabase.delete("attachments", "id=?", arrayOf(id.toString()))
    }

    // ------------------------------------------------------------- Agenda

    fun events(): List<Event> =
        readableDatabase.query("events", null, null, null, null, null, "start ASC").use { c ->
            buildList {
                while (c.moveToNext()) {
                    add(
                        Event(
                            id = c.getLong(c.getColumnIndexOrThrow("id")),
                            noteId = c.getLong(c.getColumnIndexOrThrow("note_id")),
                            title = c.getString(c.getColumnIndexOrThrow("title")),
                            start = c.getLong(c.getColumnIndexOrThrow("start")),
                            allDay = c.getInt(c.getColumnIndexOrThrow("all_day")) == 1,
                            remindMinutes = c.getInt(c.getColumnIndexOrThrow("remind_minutes")),
                            alarm = c.getInt(c.getColumnIndexOrThrow("alarm")) == 1,
                            ringtone = c.getString(c.getColumnIndexOrThrow("ringtone")),
                            createdAt = c.getLong(c.getColumnIndexOrThrow("created_at")),
                            end = c.getLong(c.getColumnIndexOrThrow("end_time")),
                            category = c.getString(c.getColumnIndexOrThrow("category")),
                            repeat = c.getString(c.getColumnIndexOrThrow("repeat")) ?: "",
                        )
                    )
                }
            }
        }

    fun event(id: Long): Event? = events().firstOrNull { it.id == id }

    fun upsertEvent(e: Event): Long {
        val v = ContentValues().apply {
            put("note_id", e.noteId); put("title", e.title); put("start", e.start)
            put("all_day", if (e.allDay) 1 else 0); put("remind_minutes", e.remindMinutes)
            put("alarm", if (e.alarm) 1 else 0); put("ringtone", e.ringtone); put("created_at", e.createdAt)
            put("end_time", e.end); put("category", e.category); put("repeat", e.repeat)
        }
        return if (e.id == 0L) writableDatabase.insert("events", null, v)
        else { writableDatabase.update("events", v, "id=?", arrayOf(e.id.toString())); e.id }
    }

    fun deleteEvent(id: Long) {
        writableDatabase.delete("events", "id=?", arrayOf(id.toString()))
    }
}
