package fr.jeremy.calepin.data

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

/** Stockage local SQLite, sans dépendance externe. */
class NoteDb(context: Context) : SQLiteOpenHelper(context, "calepin.db", null, 1) {

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            """
            CREATE TABLE notes (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                title TEXT NOT NULL DEFAULT '',
                content TEXT NOT NULL DEFAULT '',
                tag TEXT NOT NULL DEFAULT '',
                pinned INTEGER NOT NULL DEFAULT 0,
                created_at INTEGER NOT NULL,
                updated_at INTEGER NOT NULL
            )
            """.trimIndent()
        )
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) = Unit

    fun all(): List<Note> =
        readableDatabase.query("notes", null, null, null, null, null, "updated_at DESC").use { c ->
            val iId = c.getColumnIndexOrThrow("id")
            val iTitle = c.getColumnIndexOrThrow("title")
            val iContent = c.getColumnIndexOrThrow("content")
            val iTag = c.getColumnIndexOrThrow("tag")
            val iPinned = c.getColumnIndexOrThrow("pinned")
            val iCreated = c.getColumnIndexOrThrow("created_at")
            val iUpdated = c.getColumnIndexOrThrow("updated_at")
            buildList {
                while (c.moveToNext()) {
                    add(
                        Note(
                            id = c.getLong(iId),
                            title = c.getString(iTitle),
                            content = c.getString(iContent),
                            tag = c.getString(iTag),
                            pinned = c.getInt(iPinned) == 1,
                            createdAt = c.getLong(iCreated),
                            updatedAt = c.getLong(iUpdated),
                        )
                    )
                }
            }
        }

    /** Insère ou met à jour, renvoie l'identifiant de la note. */
    fun upsert(n: Note): Long {
        val v = ContentValues().apply {
            put("title", n.title)
            put("content", n.content)
            put("tag", n.tag)
            put("pinned", if (n.pinned) 1 else 0)
            put("created_at", n.createdAt)
            put("updated_at", n.updatedAt)
        }
        return if (n.id == 0L) {
            writableDatabase.insert("notes", null, v)
        } else {
            writableDatabase.update("notes", v, "id=?", arrayOf(n.id.toString()))
            n.id
        }
    }

    fun delete(id: Long) {
        writableDatabase.delete("notes", "id=?", arrayOf(id.toString()))
    }
}
