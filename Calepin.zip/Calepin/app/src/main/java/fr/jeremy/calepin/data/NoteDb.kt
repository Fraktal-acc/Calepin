package fr.jeremy.calepin.data

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

/** Stockage local SQLite, sans dépendance externe. */
class NoteDb(context: Context) : SQLiteOpenHelper(context, "calepin.db", null, 4) {

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            """
            CREATE TABLE notes (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                title TEXT NOT NULL DEFAULT '',
                content TEXT NOT NULL DEFAULT '',
                tag TEXT NOT NULL DEFAULT '',
                pinned INTEGER NOT NULL DEFAULT 0,
                created_at INTEGER NOT NULL,
                updated_at INTEGER NOT NULL
            )
            """.trimIndent()
        )
        createRecordings(db)
        db.execSQL("ALTER TABLE recordings ADD COLUMN transcript TEXT NOT NULL DEFAULT ''")
        createV3(db)
        upgradeV4(db)
    }

    private fun upgradeV4(db: SQLiteDatabase) {
        db.execSQL("ALTER TABLE events ADD COLUMN end_time INTEGER NOT NULL DEFAULT 0")
        db.execSQL("ALTER TABLE events ADD COLUMN category TEXT NOT NULL DEFAULT ''")
    }

    private fun createV3(db: SQLiteDatabase) {
        db.execSQL(
            """
            CREATE TABLE IF NOT EXISTS attachments (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                note_id INTEGER NOT NULL,
                file_name TEXT NOT NULL,
                is_video INTEGER NOT NULL,
                created_at INTEGER NOT NULL
            )
            """.trimIndent()
        )
        db.execSQL(
            """
            CREATE TABLE IF NOT EXISTS events (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                note_id INTEGER NOT NULL DEFAULT 0,
                title TEXT NOT NULL,
                start INTEGER NOT NULL,
                all_day INTEGER NOT NULL DEFAULT 0,
                remind_minutes INTEGER NOT NULL DEFAULT -1,
                alarm INTEGER NOT NULL DEFAULT 0,
                ringtone TEXT NOT NULL DEFAULT '',
                created_at INTEGER NOT NULL
            )
            """.trimIndent()
        )
    }

    private fun createRecordings(db: SQLiteDatabase) {
        db.execSQL(
            """
            CREATE TABLE IF NOT EXISTS recordings (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                note_id INTEGER NOT NULL,
                file_name TEXT NOT NULL,
                format TEXT NOT NULL,
                duration_ms INTEGER NOT NULL,
                created_at INTEGER NOT NULL
            )
            """.trimIndent()
        )
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        if (oldVersion < 2) createRecordings(db)
        if (oldVersion < 3) {
            db.execSQL("ALTER TABLE recordings ADD COLUMN transcript TEXT NOT NULL DEFAULT ''")
            createV3(db)
        }
        if (oldVersion < 4) upgradeV4(db)
    }

    fun all(): List<Note> =
        readableDatabase.query("notes", null, null, null, null, null, "updated_at DESC").use { c ->
            val iId = c.getColumnIndexOrThrow("id")
            val iTitle = c.getColumnIndexOrThrow("title")
            val iContent = c.getColumnIndexOrThrow("content")
            val iTag = c.getColumnIndexOrThrow("tag")
            val iPinned = c.getColumnIndexOrThrow("pinned")
            val iCreated = c.getColumnIndexOrThrow("created_at")
            val iUpdated = c.getColumnIndexOrThrow("updated_at")
            buildList {
                while (c.moveToNext()) {
                    add(
                        Note(
                            id = c.getLong(iId),
                            title = c.getString(iTitle),
                            content = c.getString(iContent),
                            tag = c.getString(iTag),
                            pinned = c.getInt(iPinned) == 1,
                            createdAt = c.getLong(iCreated),
                            updatedAt = c.getLong(iUpdated),
                        )
                    )
                }
            }
        }

    /** Insère ou met à jour, renvoie l'identifiant de la note. */
    fun upsert(n: Note): Long {
        val v = ContentValues().apply {
            put("title", n.title)
            put("content", n.content)
            put("tag", n.tag)
            put("pinned", if (n.pinned) 1 else 0)
            put("created_at", n.createdAt)
            put("updated_at", n.updatedAt)
        }
        return if (n.id == 0L) {
            writableDatabase.insert("notes", null, v)
        } else {
            writableDatabase.update("notes", v, "id=?", arrayOf(n.id.toString()))
            n.id
        }
    }

    fun delete(id: Long) {
        writableDatabase.delete("notes", "id=?", arrayOf(id.toString()))
    }

    // ------------------------------------------------------- Enregistrements

    fun recordings(noteId: Long? = null): List<Recording> {
        val sel = if (noteId != null) "note_id=?" else null
        val args = if (noteId != null) arrayOf(noteId.toString()) else null
        return readableDatabase.query("recordings", null, sel, args, null, null, "created_at ASC").use { c ->
            val iId = c.getColumnIndexOrThrow("id")
            val iNote = c.getColumnIndexOrThrow("note_id")
            val iFile = c.getColumnIndexOrThrow("file_name")
            val iFmt = c.getColumnIndexOrThrow("format")
            val iDur = c.getColumnIndexOrThrow("duration_ms")
            val iCreated = c.getColumnIndexOrThrow("created_at")
            val iText = c.getColumnIndexOrThrow("transcript")
            buildList {
                while (c.moveToNext()) {
                    add(
                        Recording(
                            id = c.getLong(iId), noteId = c.getLong(iNote), fileName = c.getString(iFile),
                            format = c.getString(iFmt), durationMs = c.getLong(iDur), createdAt = c.getLong(iCreated),
                            transcript = c.getString(iText),
                        )
                    )
                }
            }
        }
    }

    fun insertRecording(r: Recording): Long {
        val v = ContentValues().apply {
            put("note_id", r.noteId)
            put("file_name", r.fileName)
            put("format", r.format)
            put("duration_ms", r.durationMs)
            put("created_at", r.createdAt)
        }
        return writableDatabase.insert("recordings", null, v)
    }

    fun deleteRecording(id: Long) {
        writableDatabase.delete("recordings", "id=?", arrayOf(id.toString()))
    }

    fun setTranscript(id: Long, text: String) {
        writableDatabase.update("recordings", ContentValues().apply { put("transcript", text) }, "id=?", arrayOf(id.toString()))
    }

    // ------------------------------------------------------- Photos, vidéos

    fun attachments(noteId: Long? = null): List<Attachment> {
        val sel = if (noteId != null) "note_id=?" else null
        val args = if (noteId != null) arrayOf(noteId.toString()) else null
        return readableDatabase.query("attachments", null, sel, args, null, null, "created_at ASC").use { c ->
            buildList {
                while (c.moveToNext()) {
                    add(
                        Attachment(
                            id = c.getLong(c.getColumnIndexOrThrow("id")),
                            noteId = c.getLong(c.getColumnIndexOrThrow("note_id")),
                            fileName = c.getString(c.getColumnIndexOrThrow("file_name")),
                            isVideo = c.getInt(c.getColumnIndexOrThrow("is_video")) == 1,
                            createdAt = c.getLong(c.getColumnIndexOrThrow("created_at")),
                        )
                    )
                }
            }
        }
    }

    fun insertAttachment(a: Attachment): Long = writableDatabase.insert(
        "attachments", null,
        ContentValues().apply {
            put("note_id", a.noteId); put("file_name", a.fileName)
            put("is_video", if (a.isVideo) 1 else 0); put("created_at", a.createdAt)
        },
    )

    fun deleteAttachment(id: Long) {
        writableDatabase.delete("attachments", "id=?", arrayOf(id.toString()))
    }

    // ------------------------------------------------------------- Agenda

    fun events(): List<Event> =
        readableDatabase.query("events", null, null, null, null, null, "start ASC").use { c ->
            buildList {
                while (c.moveToNext()) {
                    add(
                        Event(
                            id = c.getLong(c.getColumnIndexOrThrow("id")),
                            noteId = c.getLong(c.getColumnIndexOrThrow("note_id")),
                            title = c.getString(c.getColumnIndexOrThrow("title")),
                            start = c.getLong(c.getColumnIndexOrThrow("start")),
                            allDay = c.getInt(c.getColumnIndexOrThrow("all_day")) == 1,
                            remindMinutes = c.getInt(c.getColumnIndexOrThrow("remind_minutes")),
                            alarm = c.getInt(c.getColumnIndexOrThrow("alarm")) == 1,
                            ringtone = c.getString(c.getColumnIndexOrThrow("ringtone")),
                            createdAt = c.getLong(c.getColumnIndexOrThrow("created_at")),
                            end = c.getLong(c.getColumnIndexOrThrow("end_time")),
                            category = c.getString(c.getColumnIndexOrThrow("category")),
                        )
                    )
                }
            }
        }

    fun event(id: Long): Event? = events().firstOrNull { it.id == id }

    fun upsertEvent(e: Event): Long {
        val v = ContentValues().apply {
            put("note_id", e.noteId); put("title", e.title); put("start", e.start)
            put("all_day", if (e.allDay) 1 else 0); put("remind_minutes", e.remindMinutes)
            put("alarm", if (e.alarm) 1 else 0); put("ringtone", e.ringtone); put("created_at", e.createdAt)
            put("end_time", e.end); put("category", e.category)
        }
        return if (e.id == 0L) writableDatabase.insert("events", null, v)
        else { writableDatabase.update("events", v, "id=?", arrayOf(e.id.toString())); e.id }
    }

    fun deleteEvent(id: Long) {
        writableDatabase.delete("events", "id=?", arrayOf(id.toString()))
    }
}
