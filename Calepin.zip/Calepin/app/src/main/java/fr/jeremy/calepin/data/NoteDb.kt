package fr.jeremy.calepin.data

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

/** Stockage local SQLite, sans dépendance externe. */
class NoteDb(context: Context) : SQLiteOpenHelper(context, "calepin.db", null, 2) {

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            """
            CREATE TABLE notes (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                title TEXT NOT NULL DEFAULT '',
                content TEXT NOT NULL DEFAULT '',
                tag TEXT NOT NULL DEFAULT '',
                pinned INTEGER NOT NULL DEFAULT 0,
                created_at INTEGER NOT NULL,
                updated_at INTEGER NOT NULL
            )
            """.trimIndent()
        )
        createRecordings(db)
    }

    private fun createRecordings(db: SQLiteDatabase) {
        db.execSQL(
            """
            CREATE TABLE IF NOT EXISTS recordings (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                note_id INTEGER NOT NULL,
                file_name TEXT NOT NULL,
                format TEXT NOT NULL,
                duration_ms INTEGER NOT NULL,
                created_at INTEGER NOT NULL
            )
            """.trimIndent()
        )
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        if (oldVersion < 2) createRecordings(db)
    }

    fun all(): List<Note> =
        readableDatabase.query("notes", null, null, null, null, null, "updated_at DESC").use { c ->
            val iId = c.getColumnIndexOrThrow("id")
            val iTitle = c.getColumnIndexOrThrow("title")
            val iContent = c.getColumnIndexOrThrow("content")
            val iTag = c.getColumnIndexOrThrow("tag")
            val iPinned = c.getColumnIndexOrThrow("pinned")
            val iCreated = c.getColumnIndexOrThrow("created_at")
            val iUpdated = c.getColumnIndexOrThrow("updated_at")
            buildList {
                while (c.moveToNext()) {
                    add(
                        Note(
                            id = c.getLong(iId),
                            title = c.getString(iTitle),
                            content = c.getString(iContent),
                            tag = c.getString(iTag),
                            pinned = c.getInt(iPinned) == 1,
                            createdAt = c.getLong(iCreated),
                            updatedAt = c.getLong(iUpdated),
                        )
                    )
                }
            }
        }

    /** Insère ou met à jour, renvoie l'identifiant de la note. */
    fun upsert(n: Note): Long {
        val v = ContentValues().apply {
            put("title", n.title)
            put("content", n.content)
            put("tag", n.tag)
            put("pinned", if (n.pinned) 1 else 0)
            put("created_at", n.createdAt)
            put("updated_at", n.updatedAt)
        }
        return if (n.id == 0L) {
            writableDatabase.insert("notes", null, v)
        } else {
            writableDatabase.update("notes", v, "id=?", arrayOf(n.id.toString()))
            n.id
        }
    }

    fun delete(id: Long) {
        writableDatabase.delete("notes", "id=?", arrayOf(id.toString()))
    }

    // ------------------------------------------------------- Enregistrements

    fun recordings(noteId: Long? = null): List<Recording> {
        val sel = if (noteId != null) "note_id=?" else null
        val args = if (noteId != null) arrayOf(noteId.toString()) else null
        return readableDatabase.query("recordings", null, sel, args, null, null, "created_at ASC").use { c ->
            val iId = c.getColumnIndexOrThrow("id")
            val iNote = c.getColumnIndexOrThrow("note_id")
            val iFile = c.getColumnIndexOrThrow("file_name")
            val iFmt = c.getColumnIndexOrThrow("format")
            val iDur = c.getColumnIndexOrThrow("duration_ms")
            val iCreated = c.getColumnIndexOrThrow("created_at")
            buildList {
                while (c.moveToNext()) {
                    add(
                        Recording(
                            id = c.getLong(iId), noteId = c.getLong(iNote), fileName = c.getString(iFile),
                            format = c.getString(iFmt), durationMs = c.getLong(iDur), createdAt = c.getLong(iCreated),
                        )
                    )
                }
            }
        }
    }

    fun insertRecording(r: Recording): Long {
        val v = ContentValues().apply {
            put("note_id", r.noteId)
            put("file_name", r.fileName)
            put("format", r.format)
            put("duration_ms", r.durationMs)
            put("created_at", r.createdAt)
        }
        return writableDatabase.insert("recordings", null, v)
    }

    fun deleteRecording(id: Long) {
        writableDatabase.delete("recordings", "id=?", arrayOf(id.toString()))
    }
}
