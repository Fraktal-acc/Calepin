package fr.jeremy.calepin.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import fr.jeremy.calepin.i18n.Text

/** Nom affiché de chaque fond. */
val DECO_LABELS: Map<Deco, String> = mapOf(
    Deco.NONE to "Aucun", Deco.PAPER to "Papier", Deco.NEON to "Néon", Deco.GRIMOIRE to "Grimoire", Deco.TERMINAL to "Terminal",
    Deco.SUNSET to "Coucher rétro", Deco.AURORA to "Aurore", Deco.STARS to "Étoiles", Deco.SNOW to "Neige", Deco.FOG to "Brouillard",
    Deco.BLOOD to "Éclaboussures", Deco.RAIN to "Pluie", Deco.LEAVES to "Feuilles", Deco.ENERGY to "Énergie", Deco.SHADOWS to "Ombres",
    Deco.FIREFLIES to "Lucioles", Deco.BUBBLES to "Bulles", Deco.STORM to "Orage", Deco.SAKURA to "Cerisiers", Deco.WAVES to "Vagues",
    Deco.LAVA to "Lampe à lave", Deco.BOKEH to "Lumières floues", Deco.CONFETTI to "Confettis", Deco.DUNES to "Dunes", Deco.NEBULA to "Nébuleuse",
    Deco.FLAMES to "Flammes", Deco.HEARTS to "Cœurs", Deco.CIRCUIT to "Circuit", Deco.GEARS to "Engrenages", Deco.SUNNY to "Soleil",
    Deco.CLOUDS to "Nuages", Deco.MOUNTAINS to "Montagnes à l'aube", Deco.SEASCAPE to "Océan au couchant", Deco.FOREST to "Forêt dans la brume",
    Deco.CITY to "Ville la nuit", Deco.STARRY_DESERT to "Désert sous les étoiles", Deco.LAKE_AURORA to "Aurore sur le lac",
    Deco.TROPICAL to "Plage tropicale", Deco.SAVANNA to "Savane", Deco.LAVENDER to "Champs de lavande", Deco.RIVIERA to "Côte d'Azur",
    Deco.SEIGAIHA to "Vagues japonaises", Deco.LANTERNS to "Lanternes chinoises", Deco.MANDALA to "Mandala", Deco.ZELLIGE to "Zellige",
    Deco.PAPEL to "Papel picado", Deco.MEANDER to "Frise grecque",
)

fun decoLabel(choice: String): String =
    Deco.entries.firstOrNull { it.name == choice }?.let { DECO_LABELS[it] ?: it.name } ?: "Selon le thème"

/**
 * Choix du fond, indépendant du thème : chaque fond est montré par une vignette dessinée en direct
 * avec les couleurs du thème choisi.
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun DecoPicker(selected: String, onPick: (String) -> Unit) {
    val groups = listOf(
        "Paysages peints" to LANDSCAPE_DECOS.toList(),
        "Animés" to Deco.entries.filter { it.animated && it !in LANDSCAPE_DECOS && it !in CULTURE_DECOS },
        "Autres cultures" to CULTURE_DECOS.toList(),
        "Fixes" to listOf(Deco.NONE, Deco.PAPER),
    )
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        FlowRow(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            DecoTile(null, "Selon le thème", selected.isBlank()) { onPick("") }
        }
        groups.forEach { (title, list) ->
            Text(title, style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
            FlowRow(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                list.forEach { d -> DecoTile(d, DECO_LABELS[d] ?: d.name, selected == d.name) { onPick(d.name) } }
            }
        }
    }
}

@Composable
private fun DecoTile(deco: Deco?, label: String, selected: Boolean, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val look = LocalLook.current
    Column(
        Modifier
            .width(84.dp.grow())
            .clip(RoundedCornerShape(12.dp))
            .clickable(onClick = onClick),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Box(
            Modifier
                .width(84.dp.grow())
                .height(110.dp)
                .clip(RoundedCornerShape(12.dp))
                .background(look.bg)
                .border(if (selected) BorderStroke(3.dp, cs.primary) else BorderStroke(1.dp, cs.outlineVariant), RoundedCornerShape(12.dp)),
            contentAlignment = Alignment.Center,
        ) {
            if (deco == null) {
                Text("Auto", style = MaterialTheme.typography.titleSmall, color = cs.primary, fontWeight = FontWeight.SemiBold)
            } else {
                // Image fixe (instant choisi pour que chaque fond soit reconnaissable)
                Canvas(Modifier.fillMaxSize()) { drawDeco(deco, cs, look.bg, 4.2f) }
            }
            if (selected) {
                Surface(shape = RoundedCornerShape(8.dp), color = cs.primary, modifier = Modifier.align(Alignment.BottomEnd)) {
                    Text(" ✓ ", color = cs.onPrimary, style = MaterialTheme.typography.labelMedium)
                }
            }
        }
        Text(label, style = MaterialTheme.typography.labelSmall, textAlign = TextAlign.Center, maxLines = 2)
    }
}
