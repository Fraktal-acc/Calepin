package fr.jeremy.calepin.ui

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.StarBorder
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import fr.jeremy.calepin.i18n.I18n
import fr.jeremy.calepin.i18n.RawText
import fr.jeremy.calepin.i18n.Text
import fr.jeremy.calepin.radio.RadioApi
import fr.jeremy.calepin.radio.RadioCountry
import fr.jeremy.calepin.radio.RadioLogos
import fr.jeremy.calepin.radio.RadioPlayer
import fr.jeremy.calepin.radio.RadioPrefs
import fr.jeremy.calepin.radio.Station
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.text.Collator
import java.util.Locale

/** Drapeau d'un pays à partir de son code (« FR » → 🇫🇷). */
fun flagOf(code: String): String {
    if (code.length != 2 || !code.all { it in 'A'..'Z' || it in 'a'..'z' }) return "📻"
    val sb = StringBuilder()
    code.uppercase().forEach { sb.appendCodePoint(0x1F1E6 + (it - 'A')) }
    return sb.toString()
}

/** Nom du pays dans la langue de l'appli. */
fun countryName(code: String, fallback: String): String =
    runCatching { Locale.Builder().setRegion(code).build().getDisplayCountry(I18n.locale) }.getOrNull()
        ?.takeIf { it.isNotBlank() && !it.equals(code, ignoreCase = true) } ?: fallback

/** Webradios du monde entier : recherche, favoris et radios classées par pays. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RadioScreen(onClose: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var query by rememberSaveable { mutableStateOf("") }
    var favorites by remember { mutableStateOf(RadioPrefs.favorites(ctx)) }
    var countries by remember { mutableStateOf<List<RadioCountry>?>(null) }
    var countriesError by remember { mutableStateOf(false) }
    var reload by remember { mutableStateOf(0) }
    var results by remember { mutableStateOf<List<Station>?>(null) }
    var searching by remember { mutableStateOf(false) }
    var searchError by remember { mutableStateOf(false) }
    var askedNotif by rememberSaveable { mutableStateOf(false) }
    val notifPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    BackHandler { onClose() }

    LaunchedEffect(Unit) { RadioPlayer.attach(ctx) }
    LaunchedEffect(reload) {
        countriesError = false
        countries = runCatching { RadioApi.countries(ctx) }.onFailure { countriesError = true }.getOrNull()
    }
    LaunchedEffect(query) {
        val q = query.trim()
        if (q.length < 2) { results = null; searching = false; return@LaunchedEffect }
        delay(450)
        searching = true
        searchError = false
        results = runCatching { RadioApi.search(q) }.onFailure { searchError = true }.getOrNull()
        searching = false
    }

    val isFav: (Station) -> Boolean = { s -> favorites.any { it.uuid == s.uuid } }
    val toggleFav: (Station) -> Unit = { s ->
        favorites = if (isFav(s)) favorites.filterNot { it.uuid == s.uuid } else favorites + s
        RadioPrefs.setFavorites(ctx, favorites)
    }
    val play: (Station) -> Unit = { s ->
        // Android 13+ : la notification de lecture (pause, arrêt) demande une autorisation
        if (!askedNotif && Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            askedNotif = true
            fr.jeremy.calepin.LockGuard.external()
            notifPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
        RadioPlayer.play(ctx, s)
    }

    // Pays : celui du téléphone en premier, puis les autres par ordre alphabétique
    val home = remember { Locale.getDefault().country.uppercase().ifBlank { "FR" } }
    val lang by I18n.language.collectAsStateWithLifecycle()
    val sorted = remember(countries, lang) {
        val collator = Collator.getInstance(I18n.locale)
        countries.orEmpty()
            .map { it.copy(name = countryName(it.code, it.name)) }
            .sortedWith { a, b -> collator.compare(a.name, b.name) }
    }
    val q = query.trim()
    val norm: (String) -> String = { s ->
        java.text.Normalizer.normalize(s.lowercase(), java.text.Normalizer.Form.NFD).replace(Regex("\\p{M}+"), "")
    }
    val matchingCountries = remember(sorted, q) {
        if (q.length < 2) emptyList() else sorted.filter { norm(it.name).contains(norm(q)) || it.code.equals(q, ignoreCase = true) }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { FitText("Webradios") },
                navigationIcon = { IconButton(onClick = onClose) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Retour") } },
            )
        },
    ) { pad ->
        LazyColumn(
            Modifier.fillMaxSize().padding(pad),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 40.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            item(key = "search") {
                OutlinedTextField(
                    value = query,
                    onValueChange = { query = it },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    leadingIcon = { Icon(Icons.Filled.Search, null) },
                    trailingIcon = {
                        if (query.isNotEmpty()) IconButton(onClick = { query = "" }) { Icon(Icons.Filled.Close, "Effacer") }
                    },
                    placeholder = { Text("Nom de la radio, style ou pays") },
                    shape = MaterialTheme.shapes.large,
                )
            }
            item(key = "now") { RadioNowPlaying(isFavorite = isFav, onFavorite = toggleFav) }

            if (q.length >= 2) {
                items(matchingCountries, key = { "c_" + it.code }) { c ->
                    CountryFold(c, isFav, toggleFav, play)
                }
                item(key = "results_title") { SubTitle("Radios trouvées") }
                when {
                    searching || (results == null && !searchError) -> item(key = "searching") { Loading() }
                    searchError -> item(key = "search_error") {
                        Hint("L'annuaire des radios ne répond pas. Vérifie la connexion puis réessaie.")
                    }
                    results.isNullOrEmpty() -> item(key = "none") { Hint("Aucune radio ne correspond à cette recherche.") }
                    else -> items(results.orEmpty(), key = { "r_" + it.uuid }) { s ->
                        StationRow(s, isFav(s), showCountry = true, onFavorite = { toggleFav(s) }) { play(s) }
                    }
                }
            } else {
                item(key = "favorites") {
                    FoldSection(
                        "Mes radios",
                        Icons.Filled.Star,
                        summary = if (favorites.isEmpty()) "Touche l'étoile d'une radio pour la retrouver ici" else favorites.joinToString(", ") { it.name },
                        startOpen = favorites.isNotEmpty(),
                    ) {
                        if (favorites.isEmpty()) {
                            Hint("Touche l'étoile d'une radio pour la retrouver ici")
                        } else {
                            favorites.forEach { s ->
                                StationRow(s, true, showCountry = true, onFavorite = { toggleFav(s) }) { play(s) }
                            }
                        }
                    }
                }
                item(key = "by_country") { SubTitle("Par pays") }
                when {
                    countriesError -> item(key = "countries_error") {
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Hint("L'annuaire des radios ne répond pas. Vérifie la connexion puis réessaie.")
                            OutlinedButton(onClick = { reload++ }) { Text("Réessayer") }
                        }
                    }
                    countries == null -> item(key = "countries_loading") { Loading() }
                    else -> {
                        val mine = sorted.filter { it.code == home }
                        items(mine + sorted.filter { it.code != home }, key = { "c_" + it.code }) { c ->
                            CountryFold(c, isFav, toggleFav, play)
                        }
                    }
                }
                item(key = "credit") {
                    Hint("Annuaire libre radio-browser.info : plus de 50 000 radios du monde entier.")
                }
            }
        }
    }
}

/** Un pays : ses radios se chargent quand on ouvre le menu (les plus écoutées d'abord). */
@Composable
private fun CountryFold(c: RadioCountry, isFav: (Station) -> Boolean, toggleFav: (Station) -> Unit, play: (Station) -> Unit) {
    FoldSection(
        title = c.name,
        icon = Icons.Filled.GraphicEq,
        summary = I18n.trf("{0} radios", c.count),
        emoji = flagOf(c.code),
        translate = false,
    ) {
        var stations by remember { mutableStateOf<List<Station>>(emptyList()) }
        var loading by remember { mutableStateOf(true) }
        var failed by remember { mutableStateOf(false) }
        var more by remember { mutableStateOf(false) }
        var page by remember { mutableStateOf(0) }
        var retry by remember { mutableStateOf(0) }
        LaunchedEffect(page, retry) {
            loading = true
            failed = false
            runCatching { RadioApi.byCountry(c.code, offset = page * PAGE, limit = PAGE) }
                .onSuccess { got ->
                    stations = (stations + got).distinctBy { it.uuid }
                    more = got.size >= PAGE
                }
                .onFailure { failed = true }
            loading = false
        }
        stations.forEach { s ->
            StationRow(s, isFav(s), showCountry = false, onFavorite = { toggleFav(s) }) { play(s) }
        }
        when {
            loading -> Loading()
            failed -> Row(verticalAlignment = Alignment.CenterVertically) {
                Hint("Chargement impossible.")
                Spacer(Modifier.width(8.dp))
                OutlinedButton(onClick = { retry++ }) { Text("Réessayer") }
            }
            more -> OutlinedButton(onClick = { page++ }, modifier = Modifier.fillMaxWidth()) { Text("Voir plus de radios") }
            stations.isEmpty() -> Hint("Aucune radio disponible pour ce pays.")
        }
    }
}

private const val PAGE = 100

/** Radio en cours : pause / lecture, arrêt, favori, titre du morceau quand la radio le diffuse. */
@Composable
fun RadioNowPlaying(isFavorite: ((Station) -> Boolean)? = null, onFavorite: ((Station) -> Unit)? = null) {
    val ctx = LocalContext.current
    val current by RadioPlayer.current.collectAsStateWithLifecycle()
    val playing by RadioPlayer.playing.collectAsStateWithLifecycle()
    val buffering by RadioPlayer.buffering.collectAsStateWithLifecycle()
    val track by RadioPlayer.track.collectAsStateWithLifecycle()
    val error by RadioPlayer.error.collectAsStateWithLifecycle()
    val s = current ?: return
    val cs = MaterialTheme.colorScheme
    Surface(
        shape = MaterialTheme.shapes.large,
        color = cs.primaryContainer,
        border = appBorder(BorderStroke(1.dp, cs.primary.copy(alpha = 0.5f))),
        modifier = Modifier.fillMaxWidth(),
    ) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                StationLogo(s, 56.dp)
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(
                        when {
                            buffering -> "Connexion…"
                            playing -> "En direct"
                            else -> "En pause"
                        },
                        style = MaterialTheme.typography.labelMedium, color = cs.primary,
                    )
                    RawText(s.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold, color = cs.onPrimaryContainer, maxLines = 2, overflow = TextOverflow.Ellipsis)
                    val sub = track ?: listOf(flagOf(s.countryCode) + " " + countryName(s.countryCode, s.country), s.tags).filter { it.isNotBlank() }.joinToString(" · ")
                    RawText(sub, style = MaterialTheme.typography.bodySmall, color = cs.onPrimaryContainer.copy(alpha = 0.8f), maxLines = 2, overflow = TextOverflow.Ellipsis)
                }
            }
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilledIconButton(onClick = { RadioPlayer.toggle(ctx) }, modifier = Modifier.size(52.dp)) {
                    if (buffering) {
                        CircularProgressIndicator(Modifier.size(22.dp), strokeWidth = 2.dp, color = cs.onPrimary)
                    } else {
                        Icon(if (playing) Icons.Filled.Pause else Icons.Filled.PlayArrow, if (playing) "Pause" else "Lecture", Modifier.size(30.dp))
                    }
                }
                IconButton(onClick = { RadioPlayer.stop(ctx) }) { Icon(Icons.Filled.Stop, "Arrêter", tint = cs.onPrimaryContainer) }
                Spacer(Modifier.weight(1f))
                if (isFavorite != null && onFavorite != null) {
                    val fav = isFavorite(s)
                    IconButton(onClick = { onFavorite(s) }) {
                        Icon(if (fav) Icons.Filled.Star else Icons.Filled.StarBorder, if (fav) "Retirer de mes radios" else "Ajouter à mes radios", tint = cs.primary)
                    }
                }
            }
            error?.let { Text(it, style = MaterialTheme.typography.bodySmall, color = cs.error) }
        }
    }
}

@Composable
private fun StationRow(s: Station, favorite: Boolean, showCountry: Boolean, onFavorite: () -> Unit, onPlay: () -> Unit) {
    val current by RadioPlayer.current.collectAsStateWithLifecycle()
    val playing by RadioPlayer.playing.collectAsStateWithLifecycle()
    val active = current?.uuid == s.uuid
    val cs = MaterialTheme.colorScheme
    Row(
        Modifier
            .fillMaxWidth()
            .clip(MaterialTheme.shapes.medium)
            .background(if (active) cs.secondaryContainer else androidx.compose.ui.graphics.Color.Transparent)
            .clickable(onClick = onPlay)
            .padding(horizontal = 6.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        StationLogo(s, 44.dp)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            RawText(s.name, style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
            val details = buildList {
                if (showCountry && s.countryCode.isNotBlank()) add(flagOf(s.countryCode) + " " + countryName(s.countryCode, s.country))
                if (s.tags.isNotBlank()) add(s.tags)
                if (s.bitrate > 0) add("${s.bitrate} kb/s")
            }.joinToString(" · ")
            if (details.isNotEmpty()) {
                RawText(details, style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
        }
        if (active && playing) Icon(Icons.Filled.GraphicEq, "En direct", tint = cs.primary, modifier = Modifier.padding(horizontal = 4.dp))
        IconButton(onClick = onFavorite) {
            Icon(if (favorite) Icons.Filled.Star else Icons.Filled.StarBorder, if (favorite) "Retirer de mes radios" else "Ajouter à mes radios", tint = if (favorite) cs.primary else cs.onSurfaceVariant)
        }
    }
}

/** Logo de la radio, ou son drapeau en attendant (ou s'il n'y en a pas). */
@Composable
private fun StationLogo(s: Station, size: Dp) {
    val bmp: ImageBitmap? by produceState(RadioLogos.cached(s.favicon), s.favicon) {
        if (value == null && s.favicon.startsWith("http")) value = RadioLogos.load(s.favicon)
    }
    Box(
        Modifier
            .size(size)
            .clip(RoundedCornerShape(10.dp))
            .background(MaterialTheme.colorScheme.surfaceContainerHighest),
        contentAlignment = Alignment.Center,
    ) {
        val b = bmp
        if (b != null) {
            Image(b, contentDescription = null, modifier = Modifier.size(size), contentScale = ContentScale.Fit)
        } else {
            androidx.compose.material3.Text(flagOf(s.countryCode), fontSize = (size.value * 0.45f).sp)
        }
    }
}

@Composable
private fun Loading() {
    Box(Modifier.fillMaxWidth().padding(16.dp), contentAlignment = Alignment.Center) {
        CircularProgressIndicator(Modifier.size(28.dp), strokeWidth = 3.dp)
    }
}

@Composable
private fun Hint(text: String) {
    Text(text, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
}
