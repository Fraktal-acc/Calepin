package fr.jeremy.calepin.games

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.ui.unit.dp
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

/** Terrain en unités : 1 de large, 1,4 de haut (indépendant de la taille de l'écran). */
private class BreakoutState {
    val fw = 1f
    val fh = 1.4f
    val cols = 8
    val rows = 6
    private val margin = 0.03f
    private val gap = 0.008f
    val brickW = (fw - 2 * margin - (cols - 1) * gap) / cols
    val brickH = 0.04f
    private val top = 0.14f
    val bricks = BooleanArray(cols * rows)

    var paddleX = 0.5f
    val paddleW = 0.22f
    val paddleY = fh - 0.09f
    val paddleH = 0.026f

    val r = 0.018f
    var bx = 0.5f
    var by = 0f
    var vx = 0f
    var vy = 0f
    var stuck = true

    var score by mutableIntStateOf(0)
    var lives by mutableIntStateOf(3)
    var level by mutableIntStateOf(1)
    var over by mutableStateOf(false)
    var frame by mutableIntStateOf(0)

    private fun speed() = 0.8f + (level - 1) * 0.1f

    fun brickX(c: Int) = margin + c * (brickW + gap)
    fun brickY(row: Int) = top + row * (brickH + gap)

    fun reset() {
        score = 0; lives = 3; level = 1; over = false
        newLevel()
    }

    private fun newLevel() {
        bricks.fill(true)
        paddleX = 0.5f
        stuck = true
        frame++
    }

    fun setPaddle(x: Float) {
        paddleX = x.coerceIn(paddleW / 2, fw - paddleW / 2)
        frame++
    }

    fun launch() {
        if (!stuck || over) return
        stuck = false
        val a = 0.35f
        vx = speed() * a
        vy = -speed() * sqrt(1 - a * a)
    }

    fun update(dtMs: Float) {
        if (over) return
        if (stuck) {
            bx = paddleX
            by = paddleY - r
            frame++
            return
        }
        val dt = dtMs / 1000f
        val steps = ceil(speed() * dt / (r * 0.5f)).toInt().coerceAtLeast(1)
        val sdt = dt / steps
        repeat(steps) { if (!stuck && !over) sub(sdt) }
        frame++
    }

    private fun sub(dt: Float) {
        bx += vx * dt
        by += vy * dt
        // Murs
        if (bx < r) { bx = r; vx = abs(vx) }
        if (bx > fw - r) { bx = fw - r; vx = -abs(vx) }
        if (by < r) { by = r; vy = abs(vy) }
        // Balle perdue
        if (by > fh + r) {
            lives--
            if (lives <= 0) over = true else stuck = true
            return
        }
        // Raquette : l'angle de renvoi dépend de l'endroit touché
        if (vy > 0 && by + r >= paddleY && by - r <= paddleY + paddleH &&
            bx >= paddleX - paddleW / 2 - r && bx <= paddleX + paddleW / 2 + r
        ) {
            val hit = ((bx - paddleX) / (paddleW / 2)).coerceIn(-1f, 1f)
            val angle = hit * 1.05f // jusqu'à ~60°
            vx = speed() * sin(angle)
            vy = -speed() * cos(angle)
            by = paddleY - r
        }
        // Briques : une seule par pas
        for (i in bricks.indices) {
            if (!bricks[i]) continue
            val x0 = brickX(i % cols)
            val y0 = brickY(i / cols)
            val cx = bx.coerceIn(x0, x0 + brickW)
            val cy = by.coerceIn(y0, y0 + brickH)
            val dx = bx - cx
            val dy = by - cy
            if (dx * dx + dy * dy <= r * r) {
                bricks[i] = false
                score += (rows - i / cols) * 10
                val rx = (bx - (x0 + brickW / 2)) / (brickW / 2 + r)
                val ry = (by - (y0 + brickH / 2)) / (brickH / 2 + r)
                if (abs(rx) > abs(ry)) vx = if (rx > 0) abs(vx) else -abs(vx)
                else vy = if (ry > 0) abs(vy) else -abs(vy)
                if (bricks.none { it }) {
                    level++
                    newLevel()
                }
                break
            }
        }
    }
}

@Composable
internal fun BreakoutGame() {
    val ctx = LocalContext.current
    val g = remember { BreakoutState().apply { reset() } }
    var paused by remember { mutableStateOf(true) }
    var best by remember { mutableIntStateOf(GameScores.best(ctx, "breakout")) }
    var record by remember { mutableStateOf(false) }

    GameLoop(running = !paused && !g.over) { g.update(it) }
    LaunchedEffect(g.over) {
        if (g.over) {
            record = GameScores.submit(ctx, "breakout", g.score)
            if (record) best = g.score
        }
    }

    Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally) {
        ScoreBar(g.score, best, extra = "Niveau ${g.level} · " + "♥".repeat(g.lives.coerceAtLeast(0)))
        Box(
            Modifier
                .weight(1f)
                .fillMaxWidth(),
            contentAlignment = Alignment.Center,
        ) {
            Box(
                Modifier
                    .aspectRatio(1f / 1.4f, matchHeightConstraintsFirst = true)
                    .pointerInput(Unit) {
                        // Le doigt pilote la raquette ; lever le doigt lance la balle
                        awaitEachGesture {
                            val down = awaitFirstDown()
                            val scale = size.width / g.fw
                            if (g.over) {
                                g.reset(); record = false; paused = false
                            } else if (paused) {
                                paused = false
                            }
                            g.setPaddle(down.position.x / scale)
                            while (true) {
                                val ev = awaitPointerEvent()
                                val ch = ev.changes.firstOrNull() ?: break
                                if (!ch.pressed) break
                                g.setPaddle(ch.position.x / scale)
                                ch.consume()
                            }
                            if (!paused) g.launch()
                        }
                    },
            ) {
                Canvas(Modifier.fillMaxSize()) {
                    g.frame
                    val s = size.width / g.fw
                    drawRoundRect(BoardBackground, cornerRadius = CornerRadius(16f))
                    for (i in g.bricks.indices) {
                        if (!g.bricks[i]) continue
                        val row = i / g.cols
                        drawRoundRect(
                            GamePalette[row % GamePalette.size],
                            Offset(g.brickX(i % g.cols) * s, g.brickY(row) * s),
                            Size(g.brickW * s, g.brickH * s),
                            CornerRadius(4f),
                        )
                    }
                    drawRoundRect(
                        Color(0xFFE0E0E0),
                        Offset((g.paddleX - g.paddleW / 2) * s, g.paddleY * s),
                        Size(g.paddleW * s, g.paddleH * s),
                        CornerRadius(g.paddleH * s / 2),
                    )
                    val ballY = if (g.stuck) g.paddleY - g.r else g.by
                    val ballX = if (g.stuck) g.paddleX else g.bx
                    drawCircle(Color(0xFFFFCA28), radius = g.r * s, center = Offset(ballX * s, ballY * s))
                }
                when {
                    g.over -> Overlay(if (record) "Nouveau record : ${g.score} !" else "Partie terminée", "Touchez pour rejouer")
                    paused -> Overlay(
                        if (g.score == 0) "Casse-briques" else "Pause",
                        "Faites glisser le doigt pour bouger la raquette,\nlevez-le pour lancer la balle.",
                    )
                }
            }
        }
        Spacer(Modifier.size(10.dp))
        PadButton(if (paused) Icons.Filled.PlayArrow else Icons.Filled.Pause, if (paused) "Jouer" else "Pause") {
            if (!g.over) paused = !paused
        }
    }
}
