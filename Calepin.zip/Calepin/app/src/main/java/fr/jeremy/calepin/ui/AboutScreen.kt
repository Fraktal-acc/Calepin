package fr.jeremy.calepin.ui

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import fr.jeremy.calepin.BuildConfig
import fr.jeremy.calepin.LockGuard

/** Texte de la politique de confidentialité (le même que PRIVACY.md, à publier pour le Play Store). */
object Privacy {
    const val CONTACT = "contact@lintendantadomicile.fr"

    val SECTIONS: List<Pair<String, String>> = listOf(
        "En résumé" to "Calepin fonctionne sans compte et sans serveur. Tes notes, ton agenda, tes photos, tes mémos vocaux, " +
            "tes clients et tes réglages sont enregistrés uniquement sur ton téléphone. Aucune donnée n'est vendue, partagée, " +
            "ni envoyée à l'éditeur. Il n'y a ni publicité ni mesure d'audience.",
        "Autorisations et à quoi elles servent" to
            "• Micro : dictée, mémos vocaux et commandes à la voix, seulement quand tu appuies sur le bouton.\n" +
            "• Appareil photo : photos des notes, scanner de texte, photos avant/après — l'image reste sur le téléphone.\n" +
            "• Contacts (lecture) : afficher tes contacts et les retrouver dans tes notes ; rien n'est copié ailleurs.\n" +
            "• Appels : uniquement quand tu demandes à l'assistant d'appeler quelqu'un.\n" +
            "• Notifications, alarmes exactes, démarrage : pour que tes rappels sonnent à l'heure, même après un redémarrage.\n" +
            "• Empreinte / visage : verrouillage facultatif de l'appli, géré par Android.\n" +
            "• Internet : téléchargements que tu demandes (module de transcription vocale, modèles d'IA de Calepin IA) " +
            "et, dans Calepin IA, commande des appareils de ton réseau Wi-Fi local (télé, décodeur, lumières).",
        "Intelligence artificielle (Calepin IA)" to "Les modèles d'IA sont téléchargés depuis Hugging Face uniquement si tu le choisis, " +
            "puis fonctionnent entièrement sur le téléphone, sans Internet. Tes questions et tes notes ne quittent pas l'appareil.",
        "Appareils de la maison (Calepin IA)" to "Les commandes de la télé, du décodeur et des objets connectés passent directement " +
            "sur ton réseau Wi-Fi, sans passer par un serveur extérieur. Les codes d'appairage sont gardés sur le téléphone.",
        "Partages et sauvegardes" to "Quand tu partages une note, un export ou une sauvegarde, c'est toi qui choisis l'application " +
            "de destination (mail, Drive, WhatsApp…), dont la politique de confidentialité s'applique alors. " +
            "Une sauvegarde protégée par mot de passe est chiffrée (AES-256) : sans le mot de passe, elle est illisible.",
        "Effacer tes données" to "Désinstaller Calepin efface toutes ses données du téléphone. Tu peux aussi supprimer chaque note, " +
            "photo ou mémo, ou effacer les données de l'appli dans les réglages d'Android.",
        "Enfants" to "Calepin ne s'adresse pas spécifiquement aux enfants et ne collecte aucune donnée personnelle.",
        "Contact" to "Pour toute question : $CONTACT",
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AboutScreen(onClose: () -> Unit) {
    val ctx = LocalContext.current
    BackHandler { onClose() }
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("À propos") },
                navigationIcon = { IconButton(onClick = onClose) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Retour") } },
            )
        },
    ) { pad ->
        Column(
            Modifier.fillMaxSize().padding(pad).verticalScroll(rememberScrollState()).padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            Text(if (BuildConfig.AI) "Calepin IA" else "Calepin", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.SemiBold)
            Text("Version ${BuildConfig.VERSION_NAME}", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text("Bloc-notes intelligent, agenda, assistant vocal et outils pro — tout reste sur ton téléphone.")
            TextButton(onClick = { mail(ctx) }) { Text("Écrire au développeur") }
            TextButton(onClick = {
                Onboarding.reset(ctx)
                Toast.makeText(ctx, "La présentation s'affichera au prochain lancement.", Toast.LENGTH_SHORT).show()
            }) { Text("Revoir la présentation") }
            HorizontalDivider()
            Text("Politique de confidentialité", style = MaterialTheme.typography.titleMedium)
            Privacy.SECTIONS.forEach { (title, body) ->
                Text(title, style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.primary)
                Text(body, style = MaterialTheme.typography.bodyMedium)
            }
            HorizontalDivider()
            Text("Logiciels libres utilisés", style = MaterialTheme.typography.titleSmall)
            Text(
                "Jetpack Compose et AndroidX (Apache 2.0), Vosk (Apache 2.0), PdfBox-Android (Apache 2.0), ML Kit (Google), " +
                    "OkHttp (Apache 2.0), polices Google Fonts : Orbitron, Audiowide, Cinzel, UnifrakturMaguntia, Creepster, Nosifer, Bebas Neue, " +
                    "Bangers, Shojumaru, Permanent Marker, Press Start 2P, Pacifico, Special Elite, Caveat (OFL / Apache 2.0)" +
                    if (BuildConfig.AI) ", LiteRT-LM (Apache 2.0)." else ".",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}

private fun mail(ctx: Context) {
    LockGuard.external()
    runCatching {
        ctx.startActivity(Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:" + Privacy.CONTACT)).putExtra(Intent.EXTRA_SUBJECT, "Calepin " + BuildConfig.VERSION_NAME))
    }
}
