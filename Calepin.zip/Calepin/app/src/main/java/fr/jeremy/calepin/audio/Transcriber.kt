package fr.jeremy.calepin.audio

import android.content.Context
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import org.json.JSONObject
import org.vosk.Model
import org.vosk.Recognizer
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.nio.ByteOrder
import java.util.zip.ZipInputStream
import kotlin.coroutines.coroutineContext

/**
 * Transcription hors ligne des mémos vocaux avec Vosk (modèle français, téléchargé une seule fois).
 * Le son est décodé (M4A ou MP3), mis en mono 16 kHz, puis reconnu sur le téléphone, sans envoi en ligne.
 */
object Transcriber {
    const val MODEL_URL = "https://alphacephei.com/vosk/models/vosk-model-small-fr-0.22.zip"
    const val MODEL_SIZE_MB = 41
    private const val RATE = 16000

    fun modelDir(ctx: Context) = File(ctx.filesDir, "vosk-fr")
    fun isInstalled(ctx: Context) = File(modelDir(ctx), ".ready").exists()

    fun remove(ctx: Context) {
        modelDir(ctx).deleteRecursively()
        cachedModel?.close()
        cachedModel = null
    }

    private var cachedModel: Model? = null

    /** Modèle français chargé une fois (partagé avec l'assistant vocal). */
    @Synchronized
    fun model(ctx: Context): Model = cachedModel ?: Model(modelDir(ctx).absolutePath).also { cachedModel = it }

    /** Télécharge et décompresse le modèle français. [onProgress] reçoit 0..1. */
    suspend fun download(ctx: Context, onProgress: (Float) -> Unit) = withContext(Dispatchers.IO) {
        val tmp = File(ctx.cacheDir, "vosk-fr.zip")
        val conn = (URL(MODEL_URL).openConnection() as HttpURLConnection).apply {
            connectTimeout = 20_000; readTimeout = 30_000; instanceFollowRedirects = true
        }
        try {
            if (conn.responseCode !in 200..299) error("Téléchargement refusé (code ${conn.responseCode})")
            val total = conn.contentLengthLong.takeIf { it > 0 } ?: (MODEL_SIZE_MB * 1_048_576L)
            conn.inputStream.use { input ->
                FileOutputStream(tmp).use { out ->
                    val buf = ByteArray(64 * 1024)
                    var done = 0L
                    while (true) {
                        coroutineContext.ensureActive()
                        val n = input.read(buf)
                        if (n < 0) break
                        out.write(buf, 0, n)
                        done += n
                        onProgress((done.toFloat() / total).coerceIn(0f, 0.95f))
                    }
                }
            }
        } finally {
            conn.disconnect()
        }
        val dir = modelDir(ctx)
        dir.deleteRecursively()
        dir.mkdirs()
        ZipInputStream(tmp.inputStream().buffered()).use { zip ->
            while (true) {
                val entry = zip.nextEntry ?: break
                // On retire le dossier racine « vosk-model-small-fr-0.22/ »
                val rel = entry.name.substringAfter('/', "")
                if (rel.isEmpty() || rel.contains("..")) continue
                val f = File(dir, rel)
                if (entry.isDirectory) f.mkdirs() else {
                    f.parentFile?.mkdirs()
                    FileOutputStream(f).use { zip.copyTo(it) }
                }
            }
        }
        tmp.delete()
        File(dir, ".ready").writeText("ok")
        onProgress(1f)
    }

    /** Transcrit un fichier audio. [onProgress] reçoit 0..1. */
    suspend fun transcribe(ctx: Context, file: File, onProgress: (Float) -> Unit): String = withContext(Dispatchers.Default) {
        val model = model(ctx)
        val pieces = mutableListOf<String>()
        val rec = Recognizer(model, RATE.toFloat())
        fun take(json: String) {
            val t = runCatching { JSONObject(json).optString("text") }.getOrDefault("").trim()
            if (t.isNotEmpty()) pieces += t
        }
        try {
            decode(file, onProgress) { pcm, n ->
                if (rec.acceptWaveForm(pcm, n)) take(rec.result)
            }
            take(rec.finalResult)
        } finally {
            rec.close()
        }
        tidy(pieces)
    }

    /** Majuscule en début de phrase et point final (le modèle rend du texte brut en minuscules). */
    fun tidy(pieces: List<String>): String = pieces.joinToString(". ") { p ->
        p.replaceFirstChar { it.uppercase() }
    }.let { if (it.isNotEmpty() && !it.endsWith(".")) "$it." else it }

    /** Décode en PCM 16 bits mono 16 kHz et passe les blocs à [sink]. */
    private suspend fun decode(file: File, onProgress: (Float) -> Unit, sink: (ShortArray, Int) -> Unit) {
        val ex = MediaExtractor()
        ex.setDataSource(file.absolutePath)
        val track = (0 until ex.trackCount).firstOrNull {
            ex.getTrackFormat(it).getString(MediaFormat.KEY_MIME)?.startsWith("audio/") == true
        } ?: error("Aucune piste audio")
        ex.selectTrack(track)
        val fmt = ex.getTrackFormat(track)
        val mime = fmt.getString(MediaFormat.KEY_MIME)!!
        val durationUs = if (fmt.containsKey(MediaFormat.KEY_DURATION)) fmt.getLong(MediaFormat.KEY_DURATION) else 0L
        var rate = fmt.getInteger(MediaFormat.KEY_SAMPLE_RATE)
        var channels = fmt.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
        var resampler = Resampler(rate, RATE)

        val codec = MediaCodec.createDecoderByType(mime)
        codec.configure(fmt, null, null, 0)
        codec.start()
        val info = MediaCodec.BufferInfo()
        var inputDone = false
        try {
            while (true) {
                coroutineContext.ensureActive()
                if (!inputDone) {
                    val inIdx = codec.dequeueInputBuffer(10_000)
                    if (inIdx >= 0) {
                        val buf = codec.getInputBuffer(inIdx)!!
                        val size = ex.readSampleData(buf, 0)
                        if (size < 0) {
                            codec.queueInputBuffer(inIdx, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            inputDone = true
                        } else {
                            codec.queueInputBuffer(inIdx, 0, size, ex.sampleTime, 0)
                            if (durationUs > 0) onProgress((ex.sampleTime.toFloat() / durationUs).coerceIn(0f, 0.99f))
                            ex.advance()
                        }
                    }
                }
                val outIdx = codec.dequeueOutputBuffer(info, 10_000)
                if (outIdx == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    val of = codec.outputFormat
                    rate = of.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                    channels = of.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
                    resampler = Resampler(rate, RATE)
                } else if (outIdx >= 0) {
                    if (info.size > 0) {
                        val out = codec.getOutputBuffer(outIdx)!!
                        out.position(info.offset)
                        out.limit(info.offset + info.size)
                        val sb = out.order(ByteOrder.nativeOrder()).asShortBuffer()
                        val raw = ShortArray(sb.remaining())
                        sb.get(raw)
                        val frames = raw.size / channels
                        val mono = if (channels == 1) raw else ShortArray(frames) { f ->
                            var sum = 0
                            for (c in 0 until channels) sum += raw[f * channels + c]
                            (sum / channels).toShort()
                        }
                        val res = resampler.process(mono, frames)
                        if (res.isNotEmpty()) sink(res, res.size)
                    }
                    codec.releaseOutputBuffer(outIdx, false)
                    if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) break
                }
            }
        } finally {
            runCatching { codec.stop() }
            codec.release()
            ex.release()
        }
        onProgress(1f)
    }
}
