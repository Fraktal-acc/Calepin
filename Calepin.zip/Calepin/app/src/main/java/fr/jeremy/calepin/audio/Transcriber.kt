package fr.jeremy.calepin.audio

import android.content.Context
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import org.json.JSONObject
import org.vosk.Model
import org.vosk.Recognizer
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.nio.ByteOrder
import java.util.zip.ZipInputStream
import kotlin.coroutines.coroutineContext
import fr.jeremy.calepin.i18n.AppLanguage
import fr.jeremy.calepin.i18n.I18n

/** Module de reconnaissance vocale hors ligne (Vosk) pour une langue de l'appli. */
enum class VoiceModule(val lang: AppLanguage, val file: String, val sizeMb: Int, val dirName: String) {
    FR(AppLanguage.FR, "vosk-model-small-fr-0.22", 41, "vosk-fr"),
    EN(AppLanguage.EN, "vosk-model-small-en-us-0.15", 40, "vosk-en"),
    IT(AppLanguage.IT, "vosk-model-small-it-0.22", 48, "vosk-it"),
    ES(AppLanguage.ES, "vosk-model-small-es-0.42", 39, "vosk-es"),
    DE(AppLanguage.DE, "vosk-model-small-de-0.15", 45, "vosk-de");

    val url: String get() = "https://alphacephei.com/vosk/models/$file.zip"

    companion object {
        fun of(lang: AppLanguage): VoiceModule = entries.first { it.lang == lang }
        /** Module de la langue choisie dans les paramètres. */
        val current: VoiceModule get() = of(I18n.language.value)
    }
}

/**
 * Transcription hors ligne des mémos vocaux avec Vosk (un modèle par langue, téléchargé une seule fois).
 * Le son est décodé (M4A ou MP3), mis en mono 16 kHz, puis reconnu sur le téléphone, sans envoi en ligne.
 * Sans module précisé, c'est celui de la langue choisie dans les paramètres qui sert.
 */
object Transcriber {
    /** Taille du module de la langue en cours (Mo). */
    val MODEL_SIZE_MB: Int get() = VoiceModule.current.sizeMb
    private const val RATE = 16000

    fun modelDir(ctx: Context, m: VoiceModule = VoiceModule.current) = File(ctx.filesDir, m.dirName)
    fun isInstalled(ctx: Context, m: VoiceModule = VoiceModule.current) = File(modelDir(ctx, m), ".ready").exists()

    fun remove(ctx: Context, m: VoiceModule = VoiceModule.current) {
        synchronized(this) {
            cached.remove(m)?.close()
        }
        modelDir(ctx, m).deleteRecursively()
    }

    private val cached = HashMap<VoiceModule, Model>()

    /** Modèle chargé une fois par langue (partagé avec l'assistant vocal). */
    @Synchronized
    fun model(ctx: Context, m: VoiceModule = VoiceModule.current): Model =
        cached[m] ?: Model(modelDir(ctx, m).absolutePath).also { cached[m] = it }

    /** Télécharge et décompresse le module de la langue. [onProgress] reçoit 0..1. */
    suspend fun download(ctx: Context, m: VoiceModule = VoiceModule.current, onProgress: (Float) -> Unit) = withContext(Dispatchers.IO) {
        val tmp = File(ctx.cacheDir, m.dirName + ".zip")
        val conn = (URL(m.url).openConnection() as HttpURLConnection).apply {
            connectTimeout = 20_000; readTimeout = 30_000; instanceFollowRedirects = true
        }
        try {
            if (conn.responseCode !in 200..299) error(I18n.trf("Téléchargement refusé (code {0})", conn.responseCode))
            val total = conn.contentLengthLong.takeIf { it > 0 } ?: (m.sizeMb * 1_048_576L)
            conn.inputStream.use { input ->
                FileOutputStream(tmp).use { out ->
                    val buf = ByteArray(64 * 1024)
                    var done = 0L
                    while (true) {
                        coroutineContext.ensureActive()
                        val n = input.read(buf)
                        if (n < 0) break
                        out.write(buf, 0, n)
                        done += n
                        onProgress((done.toFloat() / total).coerceIn(0f, 0.95f))
                    }
                }
            }
        } finally {
            conn.disconnect()
        }
        val dir = modelDir(ctx, m)
        dir.deleteRecursively()
        dir.mkdirs()
        ZipInputStream(tmp.inputStream().buffered()).use { zip ->
            while (true) {
                val entry = zip.nextEntry ?: break
                // On retire le dossier racine (« vosk-model-small-fr-0.22/ »…)
                val rel = entry.name.substringAfter('/', "")
                if (rel.isEmpty() || rel.contains("..")) continue
                val f = File(dir, rel)
                if (entry.isDirectory) f.mkdirs() else {
                    f.parentFile?.mkdirs()
                    FileOutputStream(f).use { zip.copyTo(it) }
                }
            }
        }
        tmp.delete()
        File(dir, ".ready").writeText("ok")
        onProgress(1f)
    }

    /** Transcrit un fichier audio. [onProgress] reçoit 0..1. */
    suspend fun transcribe(ctx: Context, file: File, m: VoiceModule = VoiceModule.current, onProgress: (Float) -> Unit): String = withContext(Dispatchers.Default) {
        val model = model(ctx, m)
        val pieces = mutableListOf<String>()
        val rec = Recognizer(model, RATE.toFloat())
        fun take(json: String) {
            val t = runCatching { JSONObject(json).optString("text") }.getOrDefault("").trim()
            if (t.isNotEmpty()) pieces += t
        }
        try {
            decode(file, onProgress) { pcm, n ->
                if (rec.acceptWaveForm(pcm, n)) take(rec.result)
            }
            take(rec.finalResult)
        } finally {
            rec.close()
        }
        tidy(pieces)
    }

    /** Majuscule en début de phrase et point final (le modèle rend du texte brut en minuscules). */
    fun tidy(pieces: List<String>): String = pieces.joinToString(". ") { p ->
        p.replaceFirstChar { it.uppercase() }
    }.let { if (it.isNotEmpty() && !it.endsWith(".")) "$it." else it }

    /** Décode en PCM 16 bits mono 16 kHz et passe les blocs à [sink]. */
    private suspend fun decode(file: File, onProgress: (Float) -> Unit, sink: (ShortArray, Int) -> Unit) {
        val ex = MediaExtractor()
        ex.setDataSource(file.absolutePath)
        val track = (0 until ex.trackCount).firstOrNull {
            ex.getTrackFormat(it).getString(MediaFormat.KEY_MIME)?.startsWith("audio/") == true
        } ?: error(I18n.tr("Aucune piste audio"))
        ex.selectTrack(track)
        val fmt = ex.getTrackFormat(track)
        val mime = fmt.getString(MediaFormat.KEY_MIME)!!
        val durationUs = if (fmt.containsKey(MediaFormat.KEY_DURATION)) fmt.getLong(MediaFormat.KEY_DURATION) else 0L
        var rate = fmt.getInteger(MediaFormat.KEY_SAMPLE_RATE)
        var channels = fmt.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
        var resampler = Resampler(rate, RATE)

        val codec = MediaCodec.createDecoderByType(mime)
        codec.configure(fmt, null, null, 0)
        codec.start()
        val info = MediaCodec.BufferInfo()
        var inputDone = false
        try {
            while (true) {
                coroutineContext.ensureActive()
                if (!inputDone) {
                    val inIdx = codec.dequeueInputBuffer(10_000)
                    if (inIdx >= 0) {
                        val buf = codec.getInputBuffer(inIdx)!!
                        val size = ex.readSampleData(buf, 0)
                        if (size < 0) {
                            codec.queueInputBuffer(inIdx, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            inputDone = true
                        } else {
                            codec.queueInputBuffer(inIdx, 0, size, ex.sampleTime, 0)
                            if (durationUs > 0) onProgress((ex.sampleTime.toFloat() / durationUs).coerceIn(0f, 0.99f))
                            ex.advance()
                        }
                    }
                }
                val outIdx = codec.dequeueOutputBuffer(info, 10_000)
                if (outIdx == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    val of = codec.outputFormat
                    rate = of.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                    channels = of.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
                    resampler = Resampler(rate, RATE)
                } else if (outIdx >= 0) {
                    if (info.size > 0) {
                        val out = codec.getOutputBuffer(outIdx)!!
                        out.position(info.offset)
                        out.limit(info.offset + info.size)
                        val sb = out.order(ByteOrder.nativeOrder()).asShortBuffer()
                        val raw = ShortArray(sb.remaining())
                        sb.get(raw)
                        val frames = raw.size / channels
                        val mono = if (channels == 1) raw else ShortArray(frames) { f ->
                            var sum = 0
                            for (c in 0 until channels) sum += raw[f * channels + c]
                            (sum / channels).toShort()
                        }
                        val res = resampler.process(mono, frames)
                        if (res.isNotEmpty()) sink(res, res.size)
                    }
                    codec.releaseOutputBuffer(outIdx, false)
                    if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) break
                }
            }
        } finally {
            runCatching { codec.stop() }
            codec.release()
            ex.release()
        }
        onProgress(1f)
    }
}
