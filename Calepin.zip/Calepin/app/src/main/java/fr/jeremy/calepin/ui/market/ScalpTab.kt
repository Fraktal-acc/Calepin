package fr.jeremy.calepin.ui.market

import android.Manifest
import android.os.Build
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.NotificationsNone
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import fr.jeremy.calepin.i18n.I18n
import fr.jeremy.calepin.i18n.RawText
import fr.jeremy.calepin.i18n.Text
import fr.jeremy.calepin.market.Market
import fr.jeremy.calepin.market.ScalpPosition
import fr.jeremy.calepin.market.ScalpSide
import fr.jeremy.calepin.market.ScalpSignal
import fr.jeremy.calepin.market.ScalpState
import fr.jeremy.calepin.market.ScalpWatch
import fr.jeremy.calepin.market.Scalper
import fr.jeremy.calepin.market.ScalpBacktest
import fr.jeremy.calepin.ui.appBorder
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Locale
import kotlin.math.abs

private val GREEN = Color(0xFF2E9E5B)
private val RED = Color(0xFFD9534F)
private val AMBER = Color(0xFFE0A100)

private fun px(x: Double): String = if (x.isNaN()) "–" else String.format(Locale.FRANCE, if (abs(x) < 2) "%.5f" else if (abs(x) < 20) "%.4f" else "%.2f", x)
private fun pc(x: Double, d: Int = 2): String = if (x.isNaN()) "–" else String.format(Locale.FRANCE, "%+.${d}f %%", x)

/**
 * Onglet « Scalping » : bougies d'une minute en direct et assistant qui dit quand entrer (achat ou vente à
 * découvert), où placer le stop et les objectifs, puis suit la position jusqu'à la sortie.
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
internal fun ScalpTab(onOpen: (String) -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    remember { ScalpWatch.init(ctx); Market.init(ctx); true }
    val watchList by Market.watch.collectAsStateWithLifecycle()
    val focus by ScalpWatch.focus.collectAsStateWithLifecycle()
    val watched by ScalpWatch.watched.collectAsStateWithLifecycle()
    val signals by ScalpWatch.signals.collectAsStateWithLifecycle()
    val seriesMap by ScalpWatch.series.collectAsStateWithLifecycle()
    val errors by ScalpWatch.errors.collectAsStateWithLifecycle()
    val position by ScalpWatch.position.collectAsStateWithLifecycle()
    val sound by ScalpWatch.sound.collectAsStateWithLifecycle()
    val background by ScalpWatch.background.collectAsStateWithLifecycle()
    val cs = MaterialTheme.colorScheme
    val notifPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }

    // Premier instrument par défaut : le premier suivi
    LaunchedEffect(watchList) { if (focus.isBlank()) watchList.firstOrNull()?.let { ScalpWatch.setFocus(ctx, it.symbol) } }
    LaunchedEffect(Unit) { ScalpWatch.resume(ctx) }
    // Cours de l'instrument regardé toutes les 3 secondes, les autres surveillés toutes les 15 secondes
    LaunchedEffect(focus) {
        if (focus.isBlank()) return@LaunchedEffect
        var n = 0
        while (true) {
            val others = if (n % 5 == 0) (watched + listOfNotNull(position?.symbol)) - focus else emptySet()
            withContext(Dispatchers.IO) { ScalpWatch.checkAll(ctx, listOf(focus) + others, notify = false) }
            n++
            delay(3_000L)
        }
    }
    // Compte à rebours jusqu'à la clôture de la bougie en cours
    var nowMs by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) { while (true) { nowMs = System.currentTimeMillis(); delay(1_000L) } }

    val series = seriesMap[focus]
    val sig = signals[focus]
    val name = watchList.firstOrNull { it.symbol == focus }?.name ?: series?.name ?: focus
    // Fiabilité des signaux sur l'historique (recalculée à chaque nouvelle bougie)
    val lastT = series?.candles?.lastOrNull()?.t ?: 0L
    var bt by remember(focus) { mutableStateOf<ScalpBacktest?>(null) }
    LaunchedEffect(focus, lastT / 60) {
        val c = series?.candles ?: return@LaunchedEffect
        bt = withContext(Dispatchers.Default) { runCatching { Scalper.backtest(c, System.currentTimeMillis() / 1000) }.getOrNull() }
    }
    var custom by remember { mutableStateOf("") }
    var simDialog by remember { mutableStateOf(false) }

    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 40.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        // Choix de l'instrument
        item {
            FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                watchList.forEach { w ->
                    val st = signals[w.symbol]
                    FilterChip(
                        selected = w.symbol == focus,
                        onClick = { ScalpWatch.setFocus(ctx, w.symbol) },
                        label = { RawText(w.name.take(18), maxLines = 1) },
                        leadingIcon = if (st != null) ({ Box(Modifier.size(10.dp).background(stateColor(st), CircleShape)) }) else null,
                    )
                }
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(
                    custom, { custom = it.uppercase().trim() },
                    placeholder = { Text("Autre symbole (ex. EURUSD=X, ^GDAXI, BTC-EUR)") },
                    singleLine = true, modifier = Modifier.weight(1f),
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Go),
                    keyboardActions = KeyboardActions(onGo = { if (custom.isNotBlank()) { ScalpWatch.setFocus(ctx, custom); custom = "" } }),
                )
                TextButton(onClick = { if (custom.isNotBlank()) { ScalpWatch.setFocus(ctx, custom); custom = "" } }) { Text("Voir") }
            }
        }
        if (focus.isBlank()) {
            item { Text("Ajoute un instrument dans « Suivi » ou tape un symbole pour commencer.", color = cs.onSurfaceVariant) }
            return@LazyColumn
        }
        // Signal
        item {
            SignalCard(name, focus, sig, series?.price ?: Double.NaN, nowMs, errors[focus], bt,
                onOpen = { onOpen(focus) },
                onEnter = { s ->
                    ScalpWatch.enter(ctx, ScalpPosition(focus, name, s.side!!, series?.price ?: s.entry, s.stop, s.target1, s.target2, System.currentTimeMillis()))
                    I18n.toast(ctx, "Position suivie : je te dis quand sortir.", Toast.LENGTH_SHORT).show()
                },
                onSimulate = { simDialog = true },
                hasPosition = position != null,
            )
        }
        // Position en cours
        position?.let { pos ->
            item {
                val cur = seriesMap[pos.symbol]?.price ?: Double.NaN
                PositionCard(pos, cur, signals[pos.symbol],
                    onExit = {
                        if (pos.simulated) {
                            val ser = seriesMap[pos.symbol]
                            if (ser != null) scope.launch {
                                val msg = withContext(Dispatchers.IO) { Market.manualTrade(ctx, ser, buy = false, amountEur = 0.0, reason = "Scalping") }
                                I18n.toast(ctx, msg, Toast.LENGTH_SHORT).show()
                            }
                        }
                        ScalpWatch.exit(ctx)
                    },
                )
            }
        }
        // Graphique 1 minute avec le plan de trade
        item {
            ChartCard(focus, 0, fixedTf = fr.jeremy.calepin.market.Timeframe.M1, source = series, extraLevels = sig?.levels.orEmpty())
        }
        // Alertes
        item {
            Surface(shape = MaterialTheme.shapes.large, color = cs.surfaceContainerLow, border = appBorder(), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("Alertes", style = MaterialTheme.typography.titleSmall)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Son et vibration à chaque signal « entrer »", Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium)
                        Switch(checked = sound, onCheckedChange = { ScalpWatch.setSound(ctx, it) })
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("Surveiller appli fermée", style = MaterialTheme.typography.bodyMedium)
                            Text(
                                "Vérifie les instruments cochés (cloche) toutes les 15 secondes et envoie une notification au signal. Consomme de la batterie et des données : à couper après la séance.",
                                style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant,
                            )
                        }
                        Switch(checked = background, onCheckedChange = { on ->
                            if (on && Build.VERSION.SDK_INT >= 33) notifPerm.launch(Manifest.permission.POST_NOTIFICATIONS)
                            ScalpWatch.setBackground(ctx, on)
                        })
                    }
                    Text("Instruments surveillés (${watched.size}/${ScalpWatch.MAX_WATCH})", style = MaterialTheme.typography.labelLarge, color = cs.primary)
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        (watchList.map { it.symbol to it.name } + listOfNotNull(focus.takeIf { f -> watchList.none { it.symbol == f } }?.let { it to it })).forEach { (sym, nm) ->
                            val on = sym in watched
                            FilterChip(
                                selected = on,
                                onClick = { if (!ScalpWatch.toggleWatch(ctx, sym)) I18n.toast(ctx, "${ScalpWatch.MAX_WATCH} instruments au plus", Toast.LENGTH_SHORT).show() },
                                label = { RawText(nm.take(16), maxLines = 1) },
                                leadingIcon = { Icon(if (on) Icons.Filled.NotificationsActive else Icons.Filled.NotificationsNone, null, Modifier.size(16.dp)) },
                            )
                        }
                    }
                }
            }
        }
        // Signaux en direct des instruments surveillés
        val others = watched.filter { it != focus }
        if (others.isNotEmpty()) item {
            Text("Signaux en direct", style = MaterialTheme.typography.titleSmall)
            Spacer(Modifier.height(4.dp))
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                others.forEach { sym ->
                    val s = signals[sym]
                    val nm = watchList.firstOrNull { it.symbol == sym }?.name ?: sym
                    Surface(onClick = { ScalpWatch.setFocus(ctx, sym) }, shape = MaterialTheme.shapes.medium, color = cs.surfaceContainerLow, border = appBorder(), modifier = Modifier.fillMaxWidth()) {
                        Row(Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                            Box(Modifier.size(12.dp).background(s?.let { stateColor(it) } ?: cs.outline, CircleShape))
                            Spacer(Modifier.width(10.dp))
                            RawText(nm, Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                            RawText(s?.let { stateText(it) } ?: "…", style = MaterialTheme.typography.labelMedium, color = s?.let { stateColor(it) } ?: cs.onSurfaceVariant)
                        }
                    }
                }
            }
        }
        item {
            Text(
                "Scalping : positions de quelques minutes, sur des bougies d'une minute. Les cours gratuits (Yahoo) peuvent avoir un léger retard et diffèrent un peu des prix CFD d'XTB : vérifie toujours le prix chez ton courtier, place le stop dès l'entrée et ne risque qu'une petite part de ton capital par trade. Ce sont des aides à la décision, pas des conseils.",
                style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant,
            )
        }
    }

    if (simDialog) {
        val s = sig
        val ser = series
        var amount by remember { mutableStateOf("1000") }
        if (s?.side == null || ser == null) simDialog = false
        else AlertDialog(
            onDismissRequest = { simDialog = false },
            title = { Text(if (s.side == ScalpSide.LONG) "Acheter en simulation" else "Vendre à découvert en simulation") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    RawText("Stop " + px(s.stop) + " · objectif " + px(s.target1), style = MaterialTheme.typography.bodyMedium)
                    OutlinedTextField(amount, { amount = it }, label = { Text("Montant en euros") }, singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal))
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    simDialog = false
                    val a = amount.replace(',', '.').toDoubleOrNull() ?: 0.0
                    val p = ser.price
                    val stopPct = abs(p - s.stop) / p * 100
                    val takePct = abs(s.target1 - p) / p * 100
                    scope.launch {
                        val msg = withContext(Dispatchers.IO) {
                            Market.manualTrade(ctx, ser, buy = s.side == ScalpSide.LONG, amountEur = a, short = s.side == ScalpSide.SHORT, stopPct = stopPct, takePct = takePct, reason = "Scalping")
                        }
                        I18n.toast(ctx, msg, Toast.LENGTH_SHORT).show()
                        if (!msg.contains("impossible")) {
                            ScalpWatch.enter(ctx, ScalpPosition(focus, name, s.side, p, s.stop, s.target1, s.target2, System.currentTimeMillis(), simulated = true))
                        }
                    }
                }) { Text("Valider") }
            },
            dismissButton = { TextButton(onClick = { simDialog = false }) { Text("Annuler") } },
        )
    }
}

private fun stateColor(s: ScalpSignal): Color = when (s.state) {
    ScalpState.ENTER -> if (s.side == ScalpSide.LONG) GREEN else RED
    ScalpState.PREPARE -> AMBER
    else -> Color(0xFF8A8F98)
}

private fun stateText(s: ScalpSignal): String = when (s.state) {
    ScalpState.ENTER -> if (s.side == ScalpSide.LONG) "ACHETER" else "VENDRE À DÉCOUVERT"
    ScalpState.PREPARE -> if (s.side == ScalpSide.LONG) "Prépare un achat" else "Prépare une vente"
    ScalpState.WAIT -> "Attendre"
    ScalpState.NO_TRADE -> "Pas de trade"
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun SignalCard(
    name: String, symbol: String, s: ScalpSignal?, price: Double, nowMs: Long, error: String?, bt: ScalpBacktest?,
    onOpen: () -> Unit, onEnter: (ScalpSignal) -> Unit, onSimulate: () -> Unit, hasPosition: Boolean,
) {
    val cs = MaterialTheme.colorScheme
    Surface(shape = MaterialTheme.shapes.large, color = cs.surfaceContainerLow, border = appBorder(), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    RawText(name, style = MaterialTheme.typography.titleMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    RawText(symbol + " · " + px(price), style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
                }
                TextButton(onClick = onOpen) { Text("Fiche") }
            }
            if (s == null) {
                Text(
                    if (error != null) "Cours indisponibles : $error" else "Chargement des bougies d'une minute… (il en faut au moins ${Scalper.MIN_CANDLES})",
                    color = cs.onSurfaceVariant,
                )
                if (error == null) LinearProgressIndicator(Modifier.fillMaxWidth())
                return@Column
            }
            val col = stateColor(s)
            // Grand bandeau : quoi faire maintenant
            Surface(shape = MaterialTheme.shapes.medium, color = col.copy(alpha = 0.16f), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    RawText(
                        when (s.state) {
                            ScalpState.ENTER -> (if (s.side == ScalpSide.LONG) "ACHETER MAINTENANT" else "VENDRE À DÉCOUVERT MAINTENANT")
                            ScalpState.PREPARE -> (if (s.side == ScalpSide.LONG) "PRÉPARE-TOI : achat au-dessus de " else "PRÉPARE-TOI : vente sous ") + px(s.entry)
                            ScalpState.WAIT -> "ATTENDRE : rien de net"
                            ScalpState.NO_TRADE -> "PAS DE TRADE"
                        },
                        style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = col,
                    )
                    // Bougie suivante : le signal est recalculé à chaque clôture
                    val nextClose = ((s.candleTime + 120) * 1000 - nowMs).coerceAtLeast(0) / 1000
                    RawText(
                        "Force ${s.strength}/100 · " + (if (nextClose in 1..60) "prochaine bougie dans $nextClose s" else "bougie en cours") +
                            " · tendance 5 min " + when (s.trend5) { 1 -> "haussière"; -1 -> "baissière"; else -> "neutre" },
                        style = MaterialTheme.typography.labelMedium, color = cs.onSurfaceVariant,
                    )
                    LinearProgressIndicator(progress = { s.strength / 100f }, modifier = Modifier.fillMaxWidth(), color = col)
                }
            }
            if (s.side != null && (s.state == ScalpState.ENTER || s.state == ScalpState.PREPARE)) {
                val long = s.side == ScalpSide.LONG
                fun dist(x: Double) = pc((x - s.entry) / s.entry * 100, 3)
                Plan("Entrée", px(s.entry), if (s.state == ScalpState.ENTER) "au cours" else "si le cours franchit ce prix", cs.primary)
                Plan("Stop", px(s.stop), dist(s.stop), RED)
                Plan("Objectif 1", px(s.target1), dist(s.target1) + " · gain/risque " + String.format(Locale.FRANCE, "%.1f", s.rr), GREEN)
                Plan("Objectif 2", px(s.target2), dist(s.target2), GREEN)
                if (!hasPosition) Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        onClick = { onEnter(s) },
                        colors = ButtonDefaults.buttonColors(containerColor = if (long) GREEN else RED),
                    ) { Text(if (long) "Je suis entré (achat)" else "Je suis entré (vente)") }
                    OutlinedButton(onClick = onSimulate) { Text("En simulation") }
                }
            }
            if (s.setups.isNotEmpty()) FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                s.setups.forEach { st ->
                    Surface(shape = MaterialTheme.shapes.small, color = cs.secondaryContainer) {
                        RawText(st, style = MaterialTheme.typography.labelMedium, modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp))
                    }
                }
            }
            s.reasons.take(5).forEach { RawText("▲ $it", style = MaterialTheme.typography.bodySmall, color = GREEN) }
            s.warnings.take(3).forEach { RawText("⚠ $it", style = MaterialTheme.typography.bodySmall, color = RED) }
            RawText(
                "VWAP " + px(s.vwap) + " · RSI 7 " + (if (s.rsi.isNaN()) "–" else s.rsi.toInt().toString()) + " · ATR " + px(s.atr) +
                    " (" + String.format(Locale.FRANCE, "%.3f", s.atr / s.price * 100) + " %)",
                style = MaterialTheme.typography.labelSmall, color = cs.onSurfaceVariant,
            )
            if (bt != null) RawText(
                if (bt.trades == 0) "Fiabilité : pas encore de signal « entrer » sur l'historique de quelques jours."
                else "Fiabilité sur les derniers jours : ${bt.wins}/${bt.trades} signaux gagnants (" + bt.winRate.toInt() + " %), " +
                    String.format(Locale.FRANCE, "%+.2f", bt.avgR) + " R en moyenne par trade" +
                    if (bt.trades >= 8 && bt.avgR < 0) " — peu fiable sur cet instrument en ce moment" else "",
                style = MaterialTheme.typography.labelMedium, color = if (bt.trades >= 8 && bt.avgR < 0) RED else cs.primary,
            )
        }
    }
}

@Composable
private fun Plan(label: String, value: String, detail: String, color: Color) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(10.dp).background(color, CircleShape))
        Spacer(Modifier.width(8.dp))
        Text(label, Modifier.width(92.dp), style = MaterialTheme.typography.bodyMedium)
        RawText(value, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.width(8.dp))
        RawText(detail, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
private fun PositionCard(pos: ScalpPosition, price: Double, sig: ScalpSignal?, onExit: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val adv = if (price.isNaN()) null else Scalper.follow(pos.side, pos.entry, pos.stop, pos.target1, pos.target2, price, sig)
    val col = when {
        adv == null -> cs.onSurfaceVariant
        adv.exit && adv.pnlPct < 0 -> RED
        adv.pnlPct >= 0 -> GREEN
        else -> RED
    }
    Surface(shape = MaterialTheme.shapes.large, color = col.copy(alpha = 0.10f), border = appBorder(), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            RawText(
                "Ma position : " + (if (pos.side == ScalpSide.LONG) "achat" else "vente à découvert") + " · " + pos.name + (if (pos.simulated) " (simulation)" else ""),
                style = MaterialTheme.typography.titleSmall,
            )
            RawText("Entrée " + px(pos.entry) + " · stop " + px(pos.stop) + " · objectifs " + px(pos.target1) + " / " + px(pos.target2), style = MaterialTheme.typography.bodySmall)
            if (adv != null) {
                RawText(pc(adv.pnlPct, 3) + " · " + String.format(Locale.FRANCE, "%+.2f R", adv.r), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = col)
                RawText(adv.text, style = MaterialTheme.typography.bodyMedium, fontWeight = if (adv.exit) FontWeight.Bold else FontWeight.Normal, color = if (adv.exit) col else cs.onSurface)
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = onExit, colors = ButtonDefaults.buttonColors(containerColor = if (adv?.exit == true) RED else cs.primary)) {
                    Text(if (pos.simulated) "Sortir (simulation)" else "Je suis sorti")
                }
            }
        }
    }
}
