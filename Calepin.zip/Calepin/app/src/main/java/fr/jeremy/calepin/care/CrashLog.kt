package fr.jeremy.calepin.care

import android.content.Context
import android.os.Build
import java.io.File
import java.io.PrintWriter
import java.io.StringWriter
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Journal des plantages : quand l'appli se ferme toute seule, l'erreur est écrite sur le téléphone
 * (avec la version et le modèle), pour pouvoir l'envoyer et la corriger.
 */
object CrashLog {
    private const val MAX = 120_000

    private fun file(ctx: Context) = File(ctx.filesDir, "plantages.txt")
    private fun prefs(ctx: Context) = ctx.getSharedPreferences("calepin_crash", Context.MODE_PRIVATE)

    fun install(ctx: Context) {
        val app = ctx.applicationContext
        val previous = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, error ->
            runCatching { record(app, thread.name, error) }
            previous?.uncaughtException(thread, error)
        }
    }

    /** Erreur grave attrapée ailleurs (sans fermeture de l'appli) : gardée aussi, pour information. */
    fun note(ctx: Context, where: String, error: Throwable) = runCatching { record(ctx.applicationContext, where, error, fatal = false) }

    private fun record(ctx: Context, where: String, error: Throwable, fatal: Boolean = true) {
        val sw = StringWriter()
        error.printStackTrace(PrintWriter(sw))
        val version = runCatching {
            val pi = ctx.packageManager.getPackageInfo(ctx.packageName, 0)
            "${pi.versionName} (${ctx.packageName})"
        }.getOrDefault("?")
        val entry = buildString {
            append("===== ").append(SimpleDateFormat("dd/MM/yyyy HH:mm:ss", Locale.FRANCE).format(Date()))
            append(if (fatal) " · fermeture de l'appli" else " · erreur rattrapée").append('\n')
            append("Version ").append(version).append(" · ").append(Build.MANUFACTURER).append(' ').append(Build.MODEL)
            append(" · Android ").append(Build.VERSION.RELEASE).append(" · fil ").append(where).append('\n')
            append(sw.toString().lines().take(60).joinToString("\n")).append("\n\n")
        }
        val f = file(ctx)
        val old = if (f.exists()) f.readText() else ""
        // Les plus récents d'abord, taille limitée
        f.writeText((entry + old).take(MAX))
        if (fatal) prefs(ctx).edit().putBoolean("new", true).commit()
    }

    fun read(ctx: Context): String = file(ctx).takeIf { it.exists() }?.readText().orEmpty()
    fun count(ctx: Context): Int = Regex("^===== ", RegexOption.MULTILINE).findAll(read(ctx)).count()
    fun hasNew(ctx: Context) = prefs(ctx).getBoolean("new", false)
    fun markSeen(ctx: Context) = prefs(ctx).edit().putBoolean("new", false).apply()
    fun clear(ctx: Context) { file(ctx).delete(); markSeen(ctx) }
}
