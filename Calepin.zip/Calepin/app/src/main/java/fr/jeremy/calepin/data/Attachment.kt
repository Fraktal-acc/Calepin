package fr.jeremy.calepin.data

/** Photo ou vidéo jointe à une note, copiée dans le dossier privé « media » de l'appli. */
data class Attachment(
    val id: Long = 0,
    val noteId: Long,
    val fileName: String,
    val isVideo: Boolean,
    val createdAt: Long = System.currentTimeMillis(),
) {
    val mime: String get() = if (isVideo) "video/mp4" else "image/jpeg"
}

/** Rendez-vous de l'agenda Calepin, éventuellement lié à une note, avec rappel facultatif. */
data class Event(
    val id: Long = 0,
    val noteId: Long = 0,
    val title: String,
    val start: Long,
    val allDay: Boolean = false,
    /** Minutes avant le début pour le rappel ; -1 = pas de rappel. */
    val remindMinutes: Int = -1,
    /** Vrai = alarme plein écran qui sonne jusqu'à l'arrêt ; faux = simple notification. */
    val alarm: Boolean = false,
    /** Sonnerie choisie (URI Android) ; vide = sonnerie par défaut. */
    val ringtone: String = "",
    val createdAt: Long = System.currentTimeMillis(),
    /** Fin (0 = sans fin). Journée entière : minuit du dernier jour inclus. */
    val end: Long = 0,
    /** Catégorie : « travail » pour les créneaux importés d'un planning, sinon vide. */
    val category: String = "",
    /** Répétition : "" (aucune), "day", "weekdays" (lundi → vendredi), "week", "month", "year". */
    val repeat: String = "",
) {
    val isPeriod: Boolean get() = end > start && (allDay || end - start >= 86_400_000L)
    val isWork: Boolean get() = category == CATEGORY_WORK
    /** Absence lue dans un planning (indisponibilité, visite médicale…) : ni heures de travail, ni réveil. */
    val isAbsence: Boolean get() = category == CATEGORY_ABSENCE
    val remindAt: Long? get() = if (remindMinutes < 0) null else start - remindMinutes * 60_000L

    /** Prochaine occurrence après [after] (même durée), ou null si le rendez-vous ne se répète pas. */
    fun nextOccurrence(after: Long = System.currentTimeMillis()): Event? {
        if (repeat.isEmpty()) return null
        val c = java.util.Calendar.getInstance().apply { timeInMillis = start }
        val len = if (end > start) end - start else 0L
        var guard = 0
        while (c.timeInMillis <= after && guard++ < 2000) {
            when (repeat) {
                "day" -> c.add(java.util.Calendar.DAY_OF_YEAR, 1)
                "weekdays" -> do { c.add(java.util.Calendar.DAY_OF_YEAR, 1) } while (c.get(java.util.Calendar.DAY_OF_WEEK).let { it == java.util.Calendar.SATURDAY || it == java.util.Calendar.SUNDAY })
                "week" -> c.add(java.util.Calendar.WEEK_OF_YEAR, 1)
                "month" -> c.add(java.util.Calendar.MONTH, 1)
                "year" -> c.add(java.util.Calendar.YEAR, 1)
                else -> return null
            }
        }
        return copy(start = c.timeInMillis, end = if (len > 0) c.timeInMillis + len else 0L)
    }

    companion object {
        const val CATEGORY_WORK = "travail"
        const val CATEGORY_ABSENCE = "absence"
        val REPEATS = listOf("" to "Une seule fois", "day" to "Chaque jour", "weekdays" to "Du lundi au vendredi", "week" to "Chaque semaine", "month" to "Chaque mois", "year" to "Chaque année")
    }
}
