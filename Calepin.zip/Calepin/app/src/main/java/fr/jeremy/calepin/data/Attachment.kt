package fr.jeremy.calepin.data

/** Photo ou vidéo jointe à une note, copiée dans le dossier privé « media » de l'appli. */
data class Attachment(
    val id: Long = 0,
    val noteId: Long,
    val fileName: String,
    val isVideo: Boolean,
    val createdAt: Long = System.currentTimeMillis(),
) {
    val mime: String get() = if (isVideo) "video/mp4" else "image/jpeg"
}

/** Rendez-vous de l'agenda Calepin, éventuellement lié à une note, avec rappel facultatif. */
data class Event(
    val id: Long = 0,
    val noteId: Long = 0,
    val title: String,
    val start: Long,
    val allDay: Boolean = false,
    /** Minutes avant le début pour le rappel ; -1 = pas de rappel. */
    val remindMinutes: Int = -1,
    /** Vrai = alarme plein écran qui sonne jusqu'à l'arrêt ; faux = simple notification. */
    val alarm: Boolean = false,
    /** Sonnerie choisie (URI Android) ; vide = sonnerie par défaut. */
    val ringtone: String = "",
    val createdAt: Long = System.currentTimeMillis(),
) {
    val remindAt: Long? get() = if (remindMinutes < 0) null else start - remindMinutes * 60_000L
}
