package fr.jeremy.calepin.data

data class Recording(
    val id: Long = 0,
    val noteId: Long,
    /** Nom du fichier dans le dossier privé « recordings » de l'appli. */
    val fileName: String,
    val format: String,
    val durationMs: Long,
    val createdAt: Long = System.currentTimeMillis(),
    /** Texte transcrit du mémo (vide tant qu'il n'a pas été transcrit). */
    val transcript: String = "",
) {
    val extension: String get() = fileName.substringAfterLast('.', "m4a")
    val mime: String get() = if (extension == "mp3") "audio/mpeg" else "audio/mp4"
}
