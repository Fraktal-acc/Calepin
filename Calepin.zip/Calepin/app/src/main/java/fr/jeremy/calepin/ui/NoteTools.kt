package fr.jeremy.calepin.ui

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import fr.jeremy.calepin.NotesViewModel
import fr.jeremy.calepin.ai.AiTool

/** Ce qu'on fait du texte produit par l'IA. */
class AiToolResult(val onReplace: (String) -> Unit, val onAppend: (String) -> Unit, val onNewNote: (String) -> Unit)

/** Fenêtre qui montre la réponse de l'IA pendant qu'elle s'écrit, puis propose de l'utiliser. */
@Composable
fun AiToolDialog(vm: NotesViewModel, tool: AiTool, text: String, use: AiToolResult, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    var output by remember { mutableStateOf("") }
    var done by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(tool, text) {
        try {
            output = vm.aiTool(tool, text) { output = it }
        } catch (e: kotlinx.coroutines.CancellationException) {
            throw e
        } catch (e: Throwable) {
            error = e.message ?: "L'IA n'a pas pu répondre."
        }
        done = true
    }

    AlertDialog(
        onDismissRequest = { if (done) onDismiss() else { vm.stopAi(); onDismiss() } },
        title = { Text(tool.label) },
        text = {
            Column(Modifier.fillMaxWidth().heightIn(max = 420.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                if (!done && output.isEmpty()) {
                    CircularProgressIndicator(Modifier.size(28.dp))
                    Text("L'IA travaille sur le téléphone… (le premier usage charge le modèle, quelques secondes)", style = MaterialTheme.typography.bodySmall)
                }
                error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
                if (output.isNotEmpty()) SelectionContainer { Text(output, style = MaterialTheme.typography.bodyMedium) }
            }
        },
        confirmButton = {
            if (done && output.isNotBlank()) {
                Column(horizontalAlignment = androidx.compose.ui.Alignment.End) {
                    TextButton(onClick = { use.onReplace(output); onDismiss() }) { Text("Remplacer le texte") }
                    TextButton(onClick = { use.onAppend(output); onDismiss() }) { Text("Ajouter à la fin") }
                    TextButton(onClick = { use.onNewNote(output); onDismiss() }) { Text("Nouvelle note") }
                    TextButton(onClick = { copy(ctx, output) }) { Text("Copier") }
                }
            } else if (!done) {
                TextButton(onClick = { vm.stopAi() }) { Text("Arrêter") }
            }
        },
        dismissButton = { TextButton(onClick = { if (!done) vm.stopAi(); onDismiss() }) { Text("Fermer") } },
    )
}

private fun copy(ctx: Context, text: String) {
    (ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("Calepin", text))
    Toast.makeText(ctx, "Copié", Toast.LENGTH_SHORT).show()
}
