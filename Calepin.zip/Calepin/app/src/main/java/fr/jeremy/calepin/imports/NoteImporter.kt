package fr.jeremy.calepin.imports

import android.content.Context
import android.net.Uri
import android.provider.DocumentsContract
import android.provider.OpenableColumns
import android.text.Html
import android.util.Xml
import fr.jeremy.calepin.data.Note
import fr.jeremy.calepin.export.Backup
import fr.jeremy.calepin.media.PdfText
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import org.xmlpull.v1.XmlPullParser
import java.io.File
import java.io.InputStream
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.TimeZone
import java.util.zip.ZipFile
import java.util.zip.ZipInputStream

/**
 * Applis d'où l'on peut importer. Android interdit de lire directement les notes d'une autre appli :
 * on passe donc par les fichiers qu'elle sait exporter (le format est reconnu automatiquement).
 */
enum class NoteSource(val label: String, val tag: String, val howTo: String, val imagesInFolder: Boolean = false) {
    SAMSUNG(
        "Samsung Notes", "Samsung Notes",
        "Dans Samsung Notes, appuyez longuement sur une note puis cochez celles à importer (ou « Tout »). " +
            "Touchez ⋮ ou « Plus » → « Enregistrer en tant que fichier » et choisissez « Fichier texte », « Microsoft Word » ou « PDF » " +
            "(les libellés varient selon la version de One UI). Les fichiers arrivent dans Mes fichiers → Documents → Samsung Notes : " +
            "choisissez ce dossier ci-dessous.\nLes notes manuscrites exportées en PDF ou en image sont lues par reconnaissance d'écriture.",
        imagesInFolder = true,
    ),
    KEEP(
        "Google Keep", "Google Keep",
        "Keep n'a pas d'export intégré : passez par Google Takeout. Ouvrez takeout.google.com, touchez « Tout désélectionner », " +
            "cochez seulement « Keep », puis « Étape suivante » → « Créer une exportation ». Vous recevez un mail avec un fichier .zip : " +
            "téléchargez-le, puis choisissez ce .zip ci-dessous. Libellés, épinglage, listes à cocher et dates sont conservés ; " +
            "les notes de la corbeille sont ignorées.",
    ),
    EVERNOTE(
        "Evernote", "Evernote",
        "L'export se fait depuis Evernote sur ordinateur : sélectionnez les notes (ou un carnet) → clic droit → « Exporter » → " +
            "format « ENEX ». Envoyez le fichier .enex sur votre téléphone (Drive, mail…) et choisissez-le ci-dessous. " +
            "Étiquettes, dates et cases à cocher sont conservées.",
    ),
    ONENOTE(
        "Microsoft OneNote", "OneNote",
        "OneNote ne permet pas d'exporter toutes les notes d'un coup. Sur ordinateur (OneNote pour Windows), ouvrez une page ou une section → " +
            "« Fichier » → « Exporter » → Word (.docx) ou PDF. Pour une seule page sur le téléphone, copiez son texte puis " +
            "« Partager → Calepin ».",
    ),
    NOTION(
        "Notion", "Notion",
        "Dans Notion : « Paramètres » → « Exporter tout le contenu de l'espace de travail » (ou ⋯ → « Exporter » sur une page), " +
            "format « Markdown et CSV ». Choisissez ensuite le fichier .zip reçu.",
    ),
    MARKDOWN(
        "Obsidian, Joplin, Markor (Markdown)", "Importé",
        "Ces applis rangent les notes en fichiers .md. Choisissez directement le dossier du coffre (Obsidian) ou du carnet. " +
            "Pour Joplin : « Exporter » → « MD – Markdown » dans un dossier, puis choisissez ce dossier.",
    ),
    SIMPLENOTE(
        "Simplenote", "Simplenote",
        "Sur simplenote.com ou l'appli ordinateur : « Paramètres » → « Outils » → « Exporter les notes ». Choisissez ensuite le .zip obtenu.",
    ),
    OTHER(
        "Autre appli (Xiaomi, Huawei, ColorNote…)", "Importé",
        "Exportez ou partagez vos notes en texte (.txt), PDF, Word (.docx), HTML ou image, enregistrez-les dans un dossier, " +
            "puis choisissez ce dossier ou les fichiers. Pour une seule note, « Partager → Calepin » depuis l'appli fonctionne aussi.",
        imagesInFolder = true,
    ),
}

object NoteImporter {

    data class Report(val notes: List<Note>, val files: Int, val unsupported: List<String>, val unreadable: List<String>)

    private class Run(
        val ctx: Context,
        val source: NoteSource,
        val addSourceTag: Boolean,
        val onProgress: (String) -> Unit,
    ) {
        val notes = mutableListOf<Note>()
        val unsupported = mutableListOf<String>()
        val unreadable = mutableListOf<String>()
        var files = 0

        fun tags(extra: List<String> = emptyList()): String =
            ((if (addSourceTag) listOf(source.tag) else emptyList()) + extra)
                .map { it.replace(',', ' ').trim() }.filter { it.isNotEmpty() }.distinct().joinToString(", ")

        fun add(n: Note?) { if (n != null) notes += n }
    }

    /** Fichiers choisis un par un (.txt, .md, .pdf, .docx, .enex, .zip, images…). */
    suspend fun fromFiles(
        ctx: Context, uris: List<Uri>, source: NoteSource, addSourceTag: Boolean, onProgress: (String) -> Unit,
    ): Report = withContext(Dispatchers.IO) {
        val r = Run(ctx, source, addSourceTag, onProgress)
        val items = uris.map { u -> Triple(u, displayName(ctx, u), lastModified(ctx, u)) }
        val names = items.map { it.second.lowercase() }.toSet()
        items.forEachIndexed { i, (uri, name, modified) ->
            onProgress("Lecture de « $name » (${i + 1}/${items.size})…")
            handle(r, name, modified, allowImages = true, siblings = names,
                open = { ctx.contentResolver.openInputStream(uri) ?: error("illisible") }, asUri = { uri })
        }
        r.report()
    }

    /** Tout un dossier, sous-dossiers compris (ex. Documents/Samsung Notes, coffre Obsidian). */
    suspend fun fromFolder(
        ctx: Context, tree: Uri, source: NoteSource, addSourceTag: Boolean, onProgress: (String) -> Unit,
    ): Report = withContext(Dispatchers.IO) {
        val r = Run(ctx, source, addSourceTag, onProgress)
        onProgress("Recherche des fichiers…")
        val docs = mutableListOf<TreeDoc>()
        listTree(ctx, tree, DocumentsContract.getTreeDocumentId(tree), "", docs, 0)
        val names = docs.map { it.path.lowercase() }.toSet()
        docs.forEachIndexed { i, d ->
            onProgress("Lecture de « ${d.path} » (${i + 1}/${docs.size})…")
            handle(r, d.path, d.modified, allowImages = source.imagesInFolder, siblings = names,
                open = { ctx.contentResolver.openInputStream(d.uri) ?: error("illisible") }, asUri = { d.uri })
        }
        r.report()
    }

    private fun Run.report() = Report(notes.toList(), files, unsupported.toList(), unreadable.toList())

    // ------------------------------------------------------------ Aiguillage

    private val TEXT = setOf("txt", "text")
    private val MARKDOWN = setOf("md", "markdown")
    private val IMAGES = setOf("jpg", "jpeg", "png", "webp")

    private suspend fun handle(
        r: Run, path: String, modified: Long, allowImages: Boolean, siblings: Set<String>,
        open: () -> InputStream, asUri: suspend () -> Uri,
    ) {
        val name = path.substringAfterLast('/')
        val lower = path.lowercase()
        val ext = name.substringAfterLast('.', "").lowercase()
        val stem = lower.substringBeforeLast('.')
        if (ignored(lower, r.source)) return
        // Google Takeout fournit chaque note Keep en .json ET en .html : le .json est plus complet
        if ((ext == "html" || ext == "htm") && "$stem.json" in siblings) return
        if (ext in IMAGES && !allowImages) return
        val base = name.substringBeforeLast('.')
        val date = if (modified > 0) modified else System.currentTimeMillis()
        try {
            when (ext) {
                in TEXT -> r.add(plain(r, base, decode(open().use { it.readBytes() }), date, markdown = false))
                in MARKDOWN -> r.add(plain(r, base, decode(open().use { it.readBytes() }), date, markdown = true))
                "html", "htm" -> r.add(html(r, base, decode(open().use { it.readBytes() }), date))
                "json" -> json(r, decode(open().use { it.readBytes() }), date, path)
                "enex" -> open().use { enex(r, it) }
                "docx" -> r.add(make(r, cleanTitle(base), open().use { docxText(it) }, date, date))
                "pdf" -> r.add(make(r, cleanTitle(base), PdfText.extract(r.ctx, asUri()) { r.onProgress(it) }.text, date, date))
                in IMAGES -> r.add(make(r, cleanTitle(base), PdfText.extractImage(r.ctx, asUri()).text, date, date))
                "zip" -> zip(r, open)
                else -> { r.unsupported += name; return }
            }
            r.files++
        } catch (e: Exception) {
            r.unreadable += name
        }
    }

    private fun ignored(lowerPath: String, source: NoteSource): Boolean {
        val segments = lowerPath.split('/')
        if (segments.any { it.startsWith(".") || it == "__macosx" }) return true
        val name = segments.last()
        if (name == "archive_browser.html") return true // page d'accueil de Google Takeout
        if (name == "labels.txt" && (source == NoteSource.KEEP || "keep" in segments)) return true
        return false
    }

    // ------------------------------------------------------------ Formats

    private fun plain(r: Run, fileName: String, raw: String, date: Long, markdown: Boolean): Note? {
        var body = raw.replace("\r\n", "\n").replace('\r', '\n')
        var title = cleanTitle(fileName)
        if (markdown) {
            // En-tête YAML (Obsidian, Jekyll…) : on le retire
            if (body.startsWith("---\n")) {
                val end = body.indexOf("\n---", 4)
                if (end > 0) body = body.substring(end + 4).trimStart('-').trimStart('\n')
            }
            val first = body.trimStart().lineSequence().firstOrNull().orEmpty()
            if (first.startsWith("# ")) {
                val h = first.removePrefix("# ").trim()
                if (title.isBlank() || h.equals(title, ignoreCase = true) || looksGenerated(title)) {
                    title = h
                    body = body.trimStart().substringAfter('\n', "")
                }
            }
        }
        return make(r, title, body, date, date)
    }

    private fun html(r: Run, fileName: String, html: String, date: Long): Note? {
        // Note Google Keep au format HTML (quand le .json manque)
        val keepTitle = Regex("(?is)<div class=\"title\">(.*?)</div>").find(html)?.groupValues?.get(1)
        val pageTitle = Regex("(?is)<title>(.*?)</title>").find(html)?.groupValues?.get(1)
        val body = html
            .replace(Regex("(?is)<div class=\"title\">.*?</div>"), "")
            .replace(Regex("(?is)<div class=\"heading\">.*?</div>"), "")
        val title = keepTitle?.let { htmlText(it) }?.takeIf { it.isNotBlank() }
            ?: pageTitle?.let { htmlText(it) }?.takeIf { it.isNotBlank() }
            ?: cleanTitle(fileName)
        return make(r, title, htmlText(body), date, date)
    }

    private fun json(r: Run, text: String, date: Long, path: String) {
        val o = JSONObject(text)
        when {
            o.has("activeNotes") -> simplenote(r, o)
            o.optJSONArray("notes") != null -> Backup.parse(text).forEach { n ->
                r.add(n.copy(tag = r.tags(n.tags)))
            }
            o.has("textContent") || o.has("listContent") || o.has("userEditedTimestampUsec") -> r.add(keep(r, o, date))
            else -> throw IllegalArgumentException("JSON inconnu : $path")
        }
    }

    private fun keep(r: Run, o: JSONObject, date: Long): Note? {
        if (o.optBoolean("isTrashed")) return null
        val sb = StringBuilder(o.optString("textContent"))
        o.optJSONArray("listContent")?.let { arr ->
            if (sb.isNotEmpty()) sb.append('\n')
            for (i in 0 until arr.length()) {
                val it = arr.optJSONObject(i) ?: continue
                sb.append(if (it.optBoolean("isChecked")) "☑ " else "☐ ").append(it.optString("text")).append('\n')
            }
        }
        o.optJSONArray("annotations")?.let { arr ->
            val links = (0 until arr.length()).mapNotNull { arr.optJSONObject(it)?.optString("url")?.takeIf { u -> u.isNotBlank() } }
            if (links.isNotEmpty()) sb.append("\n\n").append(links.joinToString("\n"))
        }
        val labels = o.optJSONArray("labels")?.let { arr ->
            (0 until arr.length()).mapNotNull { arr.optJSONObject(it)?.optString("name") }
        }.orEmpty()
        val created = o.optLong("createdTimestampUsec", 0) / 1000
        val updated = o.optLong("userEditedTimestampUsec", 0) / 1000
        return make(
            r, o.optString("title"), sb.toString(),
            created.takeIf { it > 0 } ?: date, updated.takeIf { it > 0 } ?: date,
            labels, pinned = o.optBoolean("isPinned"),
        )
    }

    private fun simplenote(r: Run, o: JSONObject) {
        val arr = o.optJSONArray("activeNotes") ?: return
        for (i in 0 until arr.length()) {
            val n = arr.optJSONObject(i) ?: continue
            val tags = n.optJSONArray("tags")?.let { t -> (0 until t.length()).map { t.optString(it) } }.orEmpty()
            val now = System.currentTimeMillis()
            r.add(
                make(
                    r, "", n.optString("content"),
                    isoDate(n.optString("creationDate")) ?: now, isoDate(n.optString("lastModified")) ?: now,
                    tags, pinned = n.optBoolean("pinned"),
                )
            )
        }
    }

    /** Evernote (.enex) : XML contenant le texte de chaque note en ENML (proche du HTML). */
    private fun enex(r: Run, input: InputStream) {
        val p = Xml.newPullParser()
        p.setFeature(XmlPullParser.FEATURE_PROCESS_NAMESPACES, false)
        p.setInput(input, null)
        val fields = setOf("title", "content", "created", "updated", "tag")
        var inNote = false
        var current: String? = null
        val buf = StringBuilder()
        var title = ""; var content = ""; var created = ""; var updated = ""
        val tags = mutableListOf<String>()
        var ev = p.eventType
        while (ev != XmlPullParser.END_DOCUMENT) {
            when (ev) {
                XmlPullParser.START_TAG -> when {
                    p.name == "note" -> {
                        inNote = true; title = ""; content = ""; created = ""; updated = ""; tags.clear()
                    }
                    inNote && p.name in fields && p.depth == 3 -> { current = p.name; buf.setLength(0) }
                }
                XmlPullParser.TEXT -> if (current != null) buf.append(p.text)
                XmlPullParser.END_TAG -> {
                    if (current != null && p.name == current) {
                        val v = buf.toString()
                        when (current) {
                            "title" -> title = v.trim()
                            "content" -> content = v
                            "created" -> created = v
                            "updated" -> updated = v
                            "tag" -> tags += v.trim()
                        }
                        current = null
                    }
                    if (p.name == "note" && inNote) {
                        inNote = false
                        val c = enexDate(created) ?: System.currentTimeMillis()
                        r.add(make(r, title, enml(content), c, enexDate(updated) ?: c, tags.toList()))
                    }
                }
            }
            ev = p.next()
        }
    }

    private fun enml(s: String): String = htmlText(
        s.replace(Regex("(?i)<en-todo[^>]*checked=\"true\"[^>]*>(</en-todo>)?"), "☑ ")
            .replace(Regex("(?i)<en-todo[^>]*>(</en-todo>)?"), "☐ ")
            .replace(Regex("(?is)<en-media[^>]*>(</en-media>)?"), "")
    )

    /** Word (.docx) : on lit word/document.xml, paragraphe par paragraphe. */
    private fun docxText(input: InputStream): String {
        ZipInputStream(input).use { z ->
            while (true) {
                val e = z.nextEntry ?: break
                if (e.name != "word/document.xml") continue
                val p = Xml.newPullParser()
                p.setFeature(XmlPullParser.FEATURE_PROCESS_NAMESPACES, false)
                p.setInput(z, "UTF-8")
                val sb = StringBuilder()
                var inText = false
                var ev = p.eventType
                while (ev != XmlPullParser.END_DOCUMENT) {
                    when (ev) {
                        XmlPullParser.START_TAG -> when (p.name) {
                            "w:t" -> inText = true
                            "w:tab" -> sb.append('\t')
                            "w:br", "w:cr" -> sb.append('\n')
                        }
                        XmlPullParser.TEXT -> if (inText) sb.append(p.text)
                        XmlPullParser.END_TAG -> when (p.name) {
                            "w:t" -> inText = false
                            "w:p" -> sb.append('\n')
                        }
                    }
                    ev = p.next()
                }
                return sb.toString()
            }
        }
        throw IllegalArgumentException("Pas un document Word")
    }

    /** Archive .zip (Google Takeout, Notion, Simplenote…) : chaque fichier est lu comme s'il était choisi seul. */
    private suspend fun zip(r: Run, open: () -> InputStream) {
        val dir = File(r.ctx.cacheDir, "import").apply { mkdirs() }
        val tmp = File.createTempFile("archive", ".zip", dir)
        try {
            open().use { input -> tmp.outputStream().use { input.copyTo(it) } }
            // Noms de fichiers en UTF-8, ou ancien encodage Windows pour les archives faites sur PC
            var zf = ZipFile(tmp)
            val all = try {
                zf.entries().toList()
            } catch (e: IllegalArgumentException) {
                zf.close()
                zf = ZipFile(tmp, charset("IBM437"))
                zf.entries().toList()
            }
            zf.use { z ->
                val entries = all.filter { !it.isDirectory }
                val names = entries.map { it.name.lowercase() }.toSet()
                // Simplenote met chaque note en .txt ET dans source/notes.json : le .json suffit
                val simplenote = names.any { it.endsWith("source/notes.json") }
                entries.forEachIndexed { i, e ->
                    if (simplenote && e.name.endsWith(".txt", ignoreCase = true)) return@forEachIndexed
                    if (e.name.endsWith(".zip", ignoreCase = true)) return@forEachIndexed
                    r.onProgress("Archive : ${e.name.substringAfterLast('/')} (${i + 1}/${entries.size})…")
                    handle(
                        r, e.name, e.time, allowImages = false, siblings = names,
                        open = { z.getInputStream(e) },
                        asUri = {
                            val out = File(dir, "entry_" + i + "." + e.name.substringAfterLast('.', "bin"))
                            z.getInputStream(e).use { input -> out.outputStream().use { input.copyTo(it) } }
                            Uri.fromFile(out)
                        },
                    )
                }
            }
        } finally {
            dir.listFiles()?.forEach { it.delete() }
        }
    }

    // ------------------------------------------------------------ Outils

    private fun make(
        r: Run, title: String, content: String, created: Long, updated: Long,
        tags: List<String> = emptyList(), pinned: Boolean = false,
    ): Note? {
        var t = title.trim()
        var body = tidy(content)
        if (t.isEmpty() && body.isEmpty()) return null
        if (t.isEmpty()) {
            val first = body.lineSequence().first().trim()
            t = first.removePrefix("# ").take(60)
            if (first.length <= 60) body = body.substringAfter('\n', "").trim()
        }
        return Note(title = t, content = body, tag = r.tags(tags), pinned = pinned, createdAt = created, updatedAt = updated)
    }

    private fun tidy(s: String) = s
        .replace("\r\n", "\n").replace('\r', '\n')
        .replace(' ', ' ').replace("￼", "")
        .lines().joinToString("\n") { it.trimEnd() }
        .replace(Regex("\n{3,}"), "\n\n")
        .trim()

    private fun htmlText(html: String): String {
        val cleaned = html
            .replace(Regex("(?s)<\\?xml.*?\\?>"), "")
            .replace(Regex("(?is)<!DOCTYPE[^>]*>"), "")
            .replace(Regex("(?is)<head.*?</head>"), "")
            .replace(Regex("(?is)<style[^>]*>.*?</style>"), "")
            .replace(Regex("(?is)<script[^>]*>.*?</script>"), "")
        return tidy(Html.fromHtml(cleaned, Html.FROM_HTML_MODE_LEGACY).toString())
    }

    /** Titre tiré d'un nom de fichier (retire l'identifiant que Notion ajoute à la fin). */
    private fun cleanTitle(fileName: String) = fileName
        .replace(Regex("\\s+[0-9a-f]{32}$"), "")
        .trim()

    private fun looksGenerated(title: String) = title.matches(Regex("(?i)(note|untitled|sans titre)?[ _-]*[0-9_ -]{6,}"))

    private fun decode(b: ByteArray): String {
        if (b.size >= 2 && b[0] == 0xFF.toByte() && b[1] == 0xFE.toByte()) return String(b, 2, b.size - 2, Charsets.UTF_16LE)
        if (b.size >= 2 && b[0] == 0xFE.toByte() && b[1] == 0xFF.toByte()) return String(b, 2, b.size - 2, Charsets.UTF_16BE)
        val utf8 = String(b, Charsets.UTF_8)
        val s = if ('�' in utf8) String(b, charset("windows-1252")) else utf8
        return s.removePrefix("﻿")
    }

    private fun enexDate(s: String): Long? = runCatching {
        SimpleDateFormat("yyyyMMdd'T'HHmmss'Z'", Locale.US).apply { timeZone = TimeZone.getTimeZone("UTC") }.parse(s.trim())!!.time
    }.getOrNull()

    private fun isoDate(s: String): Long? = runCatching { java.time.Instant.parse(s.trim()).toEpochMilli() }.getOrNull()

    // ------------------------------------------------------------ Fichiers et dossiers

    private class TreeDoc(val uri: Uri, val path: String, val modified: Long)

    private fun listTree(ctx: Context, tree: Uri, docId: String, prefix: String, out: MutableList<TreeDoc>, depth: Int) {
        if (depth > 8 || out.size >= 5000) return
        val children = DocumentsContract.buildChildDocumentsUriUsingTree(tree, docId)
        val cols = arrayOf(
            DocumentsContract.Document.COLUMN_DOCUMENT_ID,
            DocumentsContract.Document.COLUMN_DISPLAY_NAME,
            DocumentsContract.Document.COLUMN_MIME_TYPE,
            DocumentsContract.Document.COLUMN_LAST_MODIFIED,
        )
        ctx.contentResolver.query(children, cols, null, null, null)?.use { c ->
            while (c.moveToNext()) {
                val id = c.getString(0) ?: continue
                val name = c.getString(1) ?: continue
                val path = if (prefix.isEmpty()) name else "$prefix/$name"
                if (c.getString(2) == DocumentsContract.Document.MIME_TYPE_DIR) {
                    listTree(ctx, tree, id, path, out, depth + 1)
                } else {
                    out += TreeDoc(DocumentsContract.buildDocumentUriUsingTree(tree, id), path, if (c.isNull(3)) 0 else c.getLong(3))
                }
            }
        }
    }

    private fun displayName(ctx: Context, uri: Uri): String = runCatching {
        ctx.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst()) c.getString(0) else null
        }
    }.getOrNull() ?: uri.lastPathSegment?.substringAfterLast('/') ?: "fichier"

    private fun lastModified(ctx: Context, uri: Uri): Long = runCatching {
        ctx.contentResolver.query(uri, arrayOf(DocumentsContract.Document.COLUMN_LAST_MODIFIED), null, null, null)?.use { c ->
            if (c.moveToFirst() && !c.isNull(0)) c.getLong(0) else 0L
        }
    }.getOrNull() ?: 0L
}
