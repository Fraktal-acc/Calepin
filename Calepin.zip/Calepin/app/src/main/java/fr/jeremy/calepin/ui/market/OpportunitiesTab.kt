package fr.jeremy.calepin.ui.market

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.TravelExplore
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import fr.jeremy.calepin.i18n.RawText
import fr.jeremy.calepin.i18n.Text
import fr.jeremy.calepin.market.Instrument
import fr.jeremy.calepin.market.Market
import fr.jeremy.calepin.market.Opportunities
import fr.jeremy.calepin.market.Opportunity
import fr.jeremy.calepin.market.OpportunityScanner
import fr.jeremy.calepin.market.TradeSide
import fr.jeremy.calepin.market.TradingStyle
import fr.jeremy.calepin.ui.appBorder
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val UP = Color(0xFF2E9E5B)
private val DOWN = Color(0xFFD9534F)

private fun f(x: Double, d: Int = 2) = String.format(Locale.FRANCE, "%.${d}f", x)

/**
 * Onglet « Opportunités » : le robot passe des listes d'instruments au crible et classe ceux qui présentent
 * le plus fort potentiel d'achat d'après ses analyses, les actualités et ses propres signaux.
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
internal fun OpportunitiesTab(onOpen: (String) -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    remember { OpportunityScanner.init(ctx); true }
    val results by OpportunityScanner.results.collectAsStateWithLifecycle()
    val progress by OpportunityScanner.progress.collectAsStateWithLifecycle()
    val last by OpportunityScanner.lastScan.collectAsStateWithLifecycle()
    val lists by OpportunityScanner.lists.collectAsStateWithLifecycle()
    val auto by OpportunityScanner.auto.collectAsStateWithLifecycle()
    val threshold by OpportunityScanner.threshold.collectAsStateWithLifecycle()
    val failed by OpportunityScanner.failed.collectAsStateWithLifecycle()
    val style by OpportunityScanner.style.collectAsStateWithLifecycle()
    val side by OpportunityScanner.side.collectAsStateWithLifecycle()
    val closed by OpportunityScanner.closed.collectAsStateWithLifecycle()
    val robotOn by Market.robotOn.collectAsStateWithLifecycle()
    val watch by Market.watch.collectAsStateWithLifecycle()
    val cs = MaterialTheme.colorScheme

    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 40.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        item {
            Text(
                "Le robot passe au crible les listes choisies dans le style de trading voulu : tendance, élan, excès, Fibonacci, supports et résistances, volume, " +
                    "tendance de fond, réussite passée de ses signaux sur chaque instrument, puis actualités du web et climat des marchés " +
                    "pour les meilleurs. Il les classe par potentiel. Ce sont des pistes à étudier, pas des conseils : rien n'est acheté ni vendu.",
                style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant,
            )
        }
        item {
            Text("Style de trading", style = MaterialTheme.typography.titleSmall)
            Spacer(Modifier.height(6.dp))
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                TradingStyle.entries.forEach { st ->
                    FilterChip(selected = style == st, onClick = { OpportunityScanner.setStyle(ctx, st) }, label = { Text(st.label) }, enabled = progress == null)
                }
            }
            Text(style.desc, style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
            if (style == TradingStyle.SCALPING || style == TradingStyle.DAY) Text(
                "Seuls les marchés ouverts sont analysés. Les cours gratuits peuvent avoir quelques minutes de retard : vérifie toujours sur XTB avant d'entrer.",
                style = MaterialTheme.typography.bodySmall, color = DOWN,
            )
        }
        item {
            Text("Sens", style = MaterialTheme.typography.titleSmall)
            Spacer(Modifier.height(6.dp))
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                TradeSide.entries.forEach { sd ->
                    FilterChip(selected = side == sd, onClick = { OpportunityScanner.setSide(ctx, sd) }, label = { Text(sd.label) }, enabled = progress == null)
                }
            }
        }
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Où chercher", style = MaterialTheme.typography.titleSmall, modifier = Modifier.weight(1f))
                // Tout : actions, ETF, cryptos, matières premières, devises, CFD et spéculatif
                val everything = (Opportunities.DYNAMIC.map { it.first } + Opportunities.UNIVERSES.map { it.id }).toSet()
                androidx.compose.material3.TextButton(onClick = { OpportunityScanner.setLists(ctx, everything) }, enabled = progress == null) { Text("Tout") }
                androidx.compose.material3.TextButton(onClick = { OpportunityScanner.setLists(ctx, setOf(Opportunities.WATCH)) }, enabled = progress == null) { Text("Le minimum") }
            }
            if (lists.size > 8) Text(
                "Beaucoup de listes cochées : la recherche peut prendre plusieurs minutes (plus de 250 instruments). Mieux vaut le Wi-Fi.",
                style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant,
            )
            Spacer(Modifier.height(6.dp))
            val toggle: (String) -> Unit = { id -> val next = if (id in lists) lists - id else lists + id; if (next.isNotEmpty()) OpportunityScanner.setLists(ctx, next) }
            ListChips(Opportunities.DYNAMIC.take(2) + Opportunities.UNIVERSES.filter { !it.speculative }.map { it.id to it.label + " (" + it.instruments.size + ")" }, lists, progress == null, toggle)
            Spacer(Modifier.height(8.dp))
            Text("CFD et spéculatif", style = MaterialTheme.typography.labelLarge, color = cs.primary)
            ListChips(Opportunities.DYNAMIC.drop(2) + Opportunities.UNIVERSES.filter { it.speculative }.map { it.id to it.label + " (" + it.instruments.size + ")" }, lists, progress == null, toggle)
            if (side != TradeSide.BUY || Opportunities.UNIVERSES.any { it.speculative && it.id in lists } || Opportunities.SMALL_CAPS in lists) Text(
                "CFD et instruments spéculatifs : effet de levier et fortes variations, les pertes peuvent dépasser vite la mise. Le cours analysé est celui du marché sous-jacent (Yahoo), proche mais pas identique au prix du CFD chez XTB.",
                style = MaterialTheme.typography.bodySmall, color = DOWN,
            )
        }
        item {
            val p = progress
            if (p == null) {
                Button(onClick = { scope.launch { OpportunityScanner.scan(ctx) } }, modifier = Modifier.fillMaxWidth()) {
                    Icon(Icons.Filled.TravelExplore, null)
                    Text("  Chercher les opportunités")
                }
            } else Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                if (p.total > 0) LinearProgressIndicator(progress = { p.done.toFloat() / p.total }, modifier = Modifier.fillMaxWidth())
                else LinearProgressIndicator(Modifier.fillMaxWidth())
                RawText(
                    p.step + if (p.total > 0) " · ${p.done}/${p.total}" else "",
                    style = MaterialTheme.typography.labelSmall, color = cs.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis,
                )
            }
            if (last > 0 && progress == null) {
                Spacer(Modifier.height(4.dp))
                RawText(
                    "Dernière recherche : " + SimpleDateFormat("EEEE d MMMM 'à' HH'h'mm", Locale.FRANCE).format(Date(last)) +
                        (if (closed > 0) " · $closed marché(s) fermé(s) écarté(s)" else "") +
                        (if (failed > 0) " · $failed instrument(s) illisible(s)" else ""),
                    style = MaterialTheme.typography.labelSmall, color = cs.onSurfaceVariant,
                )
            }
        }
        item {
            Surface(shape = MaterialTheme.shapes.large, color = cs.surfaceContainerLow, border = appBorder(), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("Chercher tout seul chaque jour", style = MaterialTheme.typography.bodyMedium)
                            Text(
                                if (robotOn) "Une recherche par jour quand le robot est en marche, avec une notification pour les meilleures."
                                else "Le robot est à l'arrêt : mets-le en marche (onglet Robot) pour la recherche quotidienne.",
                                style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant,
                            )
                        }
                        Switch(checked = auto, onCheckedChange = { OpportunityScanner.setAuto(ctx, it) })
                    }
                    if (auto) {
                        var t by remember(threshold) { mutableFloatStateOf(threshold.toFloat()) }
                        RawText("Prévenir à partir d'un potentiel de ${t.toInt()}/100", style = MaterialTheme.typography.bodySmall)
                        Slider(value = t, onValueChange = { t = it }, valueRange = 40f..90f, steps = 9,
                            onValueChangeFinished = { OpportunityScanner.setThreshold(ctx, t.toInt()) })
                    }
                }
            }
        }
        if (results.isEmpty() && progress == null) item {
            Text(
                if (last == 0L) "Touche « Chercher les opportunités » pour lancer la première recherche (une à deux minutes selon les listes)."
                else if (closed > 0 && (style == TradingStyle.SCALPING || style == TradingStyle.DAY)) "Rien de net pour l'instant : une partie des marchés est fermée. Réessaie pendant les heures d'ouverture (Europe 9 h – 17 h 30, États-Unis 15 h 30 – 22 h ; cryptos et devises presque tout le temps)."
                else "Aucune opportunité nette pour l'instant dans ces listes : réessaie plus tard, change de style ou ajoute d'autres listes.",
                style = MaterialTheme.typography.bodyMedium, color = cs.onSurfaceVariant,
            )
        }
        items(results, key = { it.symbol + "|" + it.buy }) { o ->
            OpportunityCard(
                rank = results.indexOf(o) + 1, o = o,
                followed = watch.any { it.symbol == o.symbol },
                onFollow = { Market.addWatch(ctx, Instrument(o.symbol, o.name, "", o.type)) },
                onUnfollow = { Market.removeWatch(ctx, o.symbol) },
                onOpen = { onOpen(o.symbol) },
            )
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun ListChips(all: List<Pair<String, String>>, lists: Set<String>, enabled: Boolean, onToggle: (String) -> Unit) {
    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
        all.forEach { (id, label) ->
            val on = id in lists
            FilterChip(
                selected = on,
                onClick = { onToggle(id) },
                label = { Text(label) },
                leadingIcon = if (on) ({ Icon(Icons.Filled.Check, null, Modifier.size(16.dp)) }) else null,
                enabled = enabled,
            )
        }
    }
}

@Composable
private fun OpportunityCard(rank: Int, o: Opportunity, followed: Boolean, onFollow: () -> Unit, onUnfollow: () -> Unit, onOpen: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    Surface(onClick = onOpen, shape = MaterialTheme.shapes.large, color = cs.surfaceContainerLow, border = appBorder(), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                RawText("$rank", style = MaterialTheme.typography.titleLarge, color = cs.primary, fontWeight = FontWeight.Bold, modifier = Modifier.width(34.dp))
                Column(Modifier.weight(1f)) {
                    RawText(o.name, style = MaterialTheme.typography.titleSmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    RawText(o.symbol + " · " + f(o.price) + " " + o.currency, style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
                }
                Column(horizontalAlignment = Alignment.End) {
                    RawText("${o.potential.toInt()}/100", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold,
                        color = if (o.potential >= 60) UP else cs.onSurface)
                    Text(Opportunities.level(o.potential), style = MaterialTheme.typography.labelSmall, color = cs.onSurfaceVariant)
                }
                if (!followed) IconButton(onClick = onFollow) { Icon(Icons.Filled.Add, "Suivre", tint = cs.primary) }
                else IconButton(onClick = onUnfollow) { Icon(Icons.Filled.Delete, "Ne plus suivre", tint = cs.onSurfaceVariant) }
            }
            LinearProgressIndicator(progress = { (o.potential / 100).toFloat() }, modifier = Modifier.fillMaxWidth(), color = if (o.potential >= 60) UP else cs.primary)
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Surface(shape = MaterialTheme.shapes.small, color = (if (o.buy) UP else DOWN).copy(alpha = 0.18f)) {
                    RawText(if (o.buy) "ACHAT" else "VENTE À DÉCOUVERT", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold,
                        color = if (o.buy) UP else DOWN, modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp))
                }
                TradingStyle.entries.firstOrNull { it.name == o.style }?.let { st ->
                    Surface(shape = MaterialTheme.shapes.small, color = cs.secondaryContainer) {
                        RawText(st.label, style = MaterialTheme.typography.labelSmall, modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp))
                    }
                }
            }
            val facts = buildList {
                add(o.verdict)
                val sg = if (o.buy) "+" else "-"
                val sl = if (o.buy) "-" else "+"
                if (!o.upside.isNaN()) add("objectif " + sg + f(o.upside, 2) + " % (" + f(o.target) + ")")
                if (!o.downside.isNaN()) add("stop " + sl + f(o.downside, 2) + " % (" + f(o.stop) + ")")
                if (!o.atrPct.isNaN()) add("volatilité " + f(o.atrPct, 2) + " % par bougie")
                if (o.rr > 0) add("gain/risque " + f(o.rr, 1))
                add("confiance " + o.confidence.toInt() + " %")
                if (!o.winRate.isNaN()) add("réussite passée " + o.winRate.toInt() + " %")
            }
            RawText(facts.joinToString(" · "), style = MaterialTheme.typography.labelMedium, color = cs.primary)
            o.reasons.take(3).forEach { r ->
                RawText("▲ $r", style = MaterialTheme.typography.bodySmall, color = UP, maxLines = 2, overflow = TextOverflow.Ellipsis)
            }
            o.risks.take(1).forEach { r ->
                RawText("▼ $r", style = MaterialTheme.typography.bodySmall, color = DOWN, maxLines = 2, overflow = TextOverflow.Ellipsis)
            }
        }
    }
}
