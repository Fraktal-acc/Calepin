package fr.jeremy.calepin.ui.market

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.TravelExplore
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import fr.jeremy.calepin.i18n.RawText
import fr.jeremy.calepin.i18n.Text
import fr.jeremy.calepin.market.Instrument
import fr.jeremy.calepin.market.Market
import fr.jeremy.calepin.market.Opportunities
import fr.jeremy.calepin.market.Opportunity
import fr.jeremy.calepin.market.OpportunityScanner
import fr.jeremy.calepin.ui.appBorder
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val UP = Color(0xFF2E9E5B)
private val DOWN = Color(0xFFD9534F)

private fun f(x: Double, d: Int = 2) = String.format(Locale.FRANCE, "%.${d}f", x)

/**
 * Onglet « Opportunités » : le robot passe des listes d'instruments au crible et classe ceux qui présentent
 * le plus fort potentiel d'achat d'après ses analyses, les actualités et ses propres signaux.
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
internal fun OpportunitiesTab(onOpen: (String) -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    remember { OpportunityScanner.init(ctx); true }
    val results by OpportunityScanner.results.collectAsStateWithLifecycle()
    val progress by OpportunityScanner.progress.collectAsStateWithLifecycle()
    val last by OpportunityScanner.lastScan.collectAsStateWithLifecycle()
    val lists by OpportunityScanner.lists.collectAsStateWithLifecycle()
    val auto by OpportunityScanner.auto.collectAsStateWithLifecycle()
    val threshold by OpportunityScanner.threshold.collectAsStateWithLifecycle()
    val failed by OpportunityScanner.failed.collectAsStateWithLifecycle()
    val robotOn by Market.robotOn.collectAsStateWithLifecycle()
    val watch by Market.watch.collectAsStateWithLifecycle()
    val cs = MaterialTheme.colorScheme

    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 40.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        item {
            Text(
                "Le robot passe au crible les listes choisies : tendance, élan, excès, Fibonacci, supports et résistances, volume, " +
                    "tendance de fond, réussite passée de ses signaux sur chaque instrument, puis actualités du web et climat des marchés " +
                    "pour les meilleurs. Il les classe par potentiel d'achat. Ce sont des pistes à étudier, pas des conseils : rien n'est acheté.",
                style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant,
            )
        }
        item {
            Text("Où chercher", style = MaterialTheme.typography.titleSmall)
            Spacer(Modifier.height(6.dp))
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                val all = Opportunities.DYNAMIC + Opportunities.UNIVERSES.map { it.id to it.label + " (" + it.instruments.size + ")" }
                all.forEach { (id, label) ->
                    val on = id in lists
                    FilterChip(
                        selected = on,
                        onClick = { val next = if (on) lists - id else lists + id; if (next.isNotEmpty()) OpportunityScanner.setLists(ctx, next) },
                        label = { Text(label) },
                        leadingIcon = if (on) ({ Icon(Icons.Filled.Check, null, Modifier.size(16.dp)) }) else null,
                        enabled = progress == null,
                    )
                }
            }
        }
        item {
            val p = progress
            if (p == null) {
                Button(onClick = { scope.launch { OpportunityScanner.scan(ctx) } }, modifier = Modifier.fillMaxWidth()) {
                    Icon(Icons.Filled.TravelExplore, null)
                    Text("  Chercher les opportunités")
                }
            } else Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                if (p.total > 0) LinearProgressIndicator(progress = { p.done.toFloat() / p.total }, modifier = Modifier.fillMaxWidth())
                else LinearProgressIndicator(Modifier.fillMaxWidth())
                RawText(
                    p.step + if (p.total > 0) " · ${p.done}/${p.total}" else "",
                    style = MaterialTheme.typography.labelSmall, color = cs.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis,
                )
            }
            if (last > 0 && progress == null) {
                Spacer(Modifier.height(4.dp))
                RawText(
                    "Dernière recherche : " + SimpleDateFormat("EEEE d MMMM 'à' HH'h'mm", Locale.FRANCE).format(Date(last)) +
                        (if (failed > 0) " · $failed instrument(s) illisible(s)" else ""),
                    style = MaterialTheme.typography.labelSmall, color = cs.onSurfaceVariant,
                )
            }
        }
        item {
            Surface(shape = MaterialTheme.shapes.large, color = cs.surfaceContainerLow, border = appBorder(), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("Chercher tout seul chaque jour", style = MaterialTheme.typography.bodyMedium)
                            Text(
                                if (robotOn) "Une recherche par jour quand le robot est en marche, avec une notification pour les meilleures."
                                else "Le robot est à l'arrêt : mets-le en marche (onglet Robot) pour la recherche quotidienne.",
                                style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant,
                            )
                        }
                        Switch(checked = auto, onCheckedChange = { OpportunityScanner.setAuto(ctx, it) })
                    }
                    if (auto) {
                        var t by remember(threshold) { mutableFloatStateOf(threshold.toFloat()) }
                        RawText("Prévenir à partir d'un potentiel de ${t.toInt()}/100", style = MaterialTheme.typography.bodySmall)
                        Slider(value = t, onValueChange = { t = it }, valueRange = 40f..90f, steps = 9,
                            onValueChangeFinished = { OpportunityScanner.setThreshold(ctx, t.toInt()) })
                    }
                }
            }
        }
        if (results.isEmpty() && progress == null) item {
            Text(
                if (last == 0L) "Touche « Chercher les opportunités » pour lancer la première recherche (une à deux minutes selon les listes)."
                else "Aucun instrument à l'achat pour l'instant dans ces listes : réessaie plus tard ou ajoute d'autres listes.",
                style = MaterialTheme.typography.bodyMedium, color = cs.onSurfaceVariant,
            )
        }
        items(results, key = { it.symbol }) { o ->
            OpportunityCard(
                rank = results.indexOf(o) + 1, o = o,
                followed = watch.any { it.symbol == o.symbol },
                onFollow = { Market.addWatch(ctx, Instrument(o.symbol, o.name, "", o.type)) },
                onOpen = { onOpen(o.symbol) },
            )
        }
    }
}

@Composable
private fun OpportunityCard(rank: Int, o: Opportunity, followed: Boolean, onFollow: () -> Unit, onOpen: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    Surface(onClick = onOpen, shape = MaterialTheme.shapes.large, color = cs.surfaceContainerLow, border = appBorder(), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                RawText("$rank", style = MaterialTheme.typography.titleLarge, color = cs.primary, fontWeight = FontWeight.Bold, modifier = Modifier.width(34.dp))
                Column(Modifier.weight(1f)) {
                    RawText(o.name, style = MaterialTheme.typography.titleSmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    RawText(o.symbol + " · " + f(o.price) + " " + o.currency, style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
                }
                Column(horizontalAlignment = Alignment.End) {
                    RawText("${o.potential.toInt()}/100", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold,
                        color = if (o.potential >= 60) UP else cs.onSurface)
                    Text(Opportunities.level(o.potential), style = MaterialTheme.typography.labelSmall, color = cs.onSurfaceVariant)
                }
                if (!followed) IconButton(onClick = onFollow) { Icon(Icons.Filled.Add, "Suivre", tint = cs.primary) }
            }
            LinearProgressIndicator(progress = { (o.potential / 100).toFloat() }, modifier = Modifier.fillMaxWidth(), color = if (o.potential >= 60) UP else cs.primary)
            val facts = buildList {
                add(o.verdict)
                if (!o.upside.isNaN()) add("objectif +" + f(o.upside, 1) + " % (" + f(o.target) + ")")
                if (!o.downside.isNaN()) add("stop -" + f(o.downside, 1) + " % (" + f(o.stop) + ")")
                if (o.rr > 0) add("gain/risque " + f(o.rr, 1))
                add("confiance " + o.confidence.toInt() + " %")
                if (!o.winRate.isNaN()) add("réussite passée " + o.winRate.toInt() + " %")
            }
            RawText(facts.joinToString(" · "), style = MaterialTheme.typography.labelMedium, color = cs.primary)
            o.reasons.take(3).forEach { r ->
                RawText("▲ $r", style = MaterialTheme.typography.bodySmall, color = UP, maxLines = 2, overflow = TextOverflow.Ellipsis)
            }
            o.risks.take(1).forEach { r ->
                RawText("▼ $r", style = MaterialTheme.typography.bodySmall, color = DOWN, maxLines = 2, overflow = TextOverflow.Ellipsis)
            }
        }
    }
}
