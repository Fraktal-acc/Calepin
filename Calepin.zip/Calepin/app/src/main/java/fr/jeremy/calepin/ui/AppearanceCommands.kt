package fr.jeremy.calepin.ui

import android.content.Context
import android.os.Build
import fr.jeremy.calepin.AppSettings
import fr.jeremy.calepin.BuildConfig
import fr.jeremy.calepin.DisplayMode
import fr.jeremy.calepin.search.TextNorm

/**
 * Commandes d'apparence et de navigation en français courant :
 * « thème océan », « mode sombre », « texte plus grand », « accueil en liste », « ouvre la télécommande »…
 */
object AppearanceCommands {

    /** Réponse à afficher et écran à ouvrir (ou null). */
    data class Result(val reply: String, val navigate: String? = null)

    private val PALETTE_WORDS_BASE = listOf(
        Palette.MEDITERRANEE to listOf("mediterranee", "mediterraneen", "mer", "classique", "par defaut", "origine"),
        Palette.OCEAN to listOf("ocean", "bleu"),
        Palette.FORET to listOf("foret", "vert", "nature"),
        Palette.LAVANDE to listOf("lavande", "violet", "mauve"),
        Palette.SOLEIL to listOf("soleil", "orange", "jaune", "ambre"),
        Palette.CORAIL to listOf("corail", "rouge"),
        Palette.ROSE to listOf("rose"),
        Palette.ARDOISE to listOf("ardoise", "gris", "sobre", "neutre"),
        Palette.DYNAMIQUE to listOf("fond d'ecran", "fond ecran", "dynamique", "material you"),
        Palette.CYBERPUNK to listOf("cyberpunk", "cyber punk", "cyber", "neon", "futuriste"),
        Palette.DARK_FANTASY to listOf("dark fantasy", "dark fantaisie", "fantasy", "fantaisie", "grimoire", "medieval", "gothique", "sorcier"),
        Palette.SYNTHWAVE to listOf("synthwave", "synth wave", "retrowave", "annees 80", "coucher de soleil"),
        Palette.TERMINAL to listOf("terminal", "hacker", "matrix", "retro", "console"),
        Palette.AURORE to listOf("aurore", "boreale", "polaire"),
        Palette.PARCHEMIN to listOf("parchemin", "vintage", "papier", "ancien", "sepia"),
        Palette.ALEATOIRE to listOf("aleatoire", "au hasard", "hasard", "surprise", "surprends moi"),
        Palette.GALAXIE to listOf("galaxie", "galaxie lointaine", "star wars", "guerre des etoiles", "space opera", "jedi", "sabre laser", "espace"),
        Palette.ROYAUMES to listOf("game of thrones", "trone de fer", "royaumes", "glace et de feu", "westeros", "dragons"),
        Palette.APOCALYPSE to listOf("walking dead", "zombie", "zombies", "apocalypse"),
        Palette.MEDICO_LEGAL to listOf("dexter", "medico legal", "medico-legal", "scene de crime", "labo"),
        Palette.NAPLES to listOf("gomorra", "naples", "camorra", "mafia", "naples noir"),
        Palette.NINJA to listOf("naruto", "ninja", "voie du ninja"),
        Palette.AURA to listOf("dragon ball", "dragon ball z", "dbz", "saiyan", "aura", "aura de combat"),
        Palette.CARNET_MAUDIT to listOf("death note", "carnet maudit", "shinigami"),
        Palette.LUCIOLES to listOf("lucioles", "luciole"),
        Palette.ABYSSES to listOf("abysses", "fond marin", "sous-marin", "ocean profond", "bulles"),
        Palette.ORAGE to listOf("orage", "tempete", "eclairs"),
        Palette.SAKURA to listOf("sakura", "cerisier", "cerisiers", "japon"),
    )

    private val THEMED_WORDS: String by lazy {
        PALETTE_WORDS_BASE.filter { it.first.group >= 1 || it.first == Palette.PARCHEMIN }.flatMap { it.second }.filter { it.length > 3 }.joinToString("|") { Regex.escape(it) }
    }

    /** Thèmes à ambiance d'abord (« vert terminal » doit donner Terminal, pas Forêt). */
    private val PALETTE_WORDS = PALETTE_WORDS_BASE.sortedByDescending { it.first.forceDark != null || it.first == Palette.ALEATOIRE }

    fun handle(ctx: Context, settings: AppSettings, raw: String): Result? {
        val n = TextNorm.norm(raw).trim().trimEnd('.', '!', '?').replace(Regex("\\s+"), " ")
        val a = Appearance.get(ctx)
        fun has(rx: String) = Regex(rx).containsMatchIn(n)

        // Navigation
        if (has("^(ouvre|affiche|montre|lance|va (sur|dans|a))\\b")) {
            when {
                has("\\btelecommande\\b") && BuildConfig.AI -> return Result("J'ouvre la télécommande.", "remote")
                has("\\b(appareils|maison|domotique)\\b") && BuildConfig.AI && !has("\\bnote") -> return Result("J'ouvre les appareils de la maison.", "devices")
                has("\\b(apparence|themes?|couleurs)\\b") -> return Result("J'ouvre l'apparence.", "appearance")
                has("\\b(jeux|jeu)\\b") -> return Result("J'ouvre les jeux.", "games")
                has("\\b(mode pro|clients?|interventions?|pro)\\b") && !has("\\bnotes?\\b") -> return Result("J'ouvre le mode pro.", "pro")
                has("\\bscenarios?\\b") && BuildConfig.AI -> return Result("J'ouvre les scénarios.", "scenarios")
                has("\\bsauvegarde\\b") -> return Result("J'ouvre la sauvegarde.", "backup")
                has("\\b(parametres|reglages)\\b") -> return Result("J'ouvre les paramètres.", "settings")
                has("\\baccueil\\b") -> return Result("Retour à l'accueil.", "home")
                has("^\\S+ (les |mes )?notes$") -> return Result("J'ouvre les notes.", "notes")
            }
        }
        if (has("^(retour (a l')?accueil|ecran d'accueil|accueil)$")) return Result("Retour à l'accueil.", "home")

        // Mode clair / sombre / noir
        if (has("\\b(mode|theme|passe en|mets en|affichage)\\b") || has("^(sombre|clair|noir)$")) {
            val mode = when {
                has("\\b(noir total|tout noir|oled|amoled|mode noir|theme noir)\\b") -> DarkMode.BLACK
                has("\\b(sombre|nuit|fonce)\\b") -> DarkMode.DARK
                has("\\b(clair|jour|blanc)\\b") -> DarkMode.LIGHT
                has("\\bmode (automatique|auto|systeme)\\b|comme le telephone") -> DarkMode.SYSTEM
                else -> null
            }
            if (mode != null && !has("\\b(couleur|palette)\\b")) {
                a.setDark(mode)
                return Result("Mode ${mode.label.lowercase()} activé.")
            }
        }

        // Palette de couleurs
        if (!has("\\b(icones?|police|typo)\\b") && has("\\b(theme|couleurs?|palette|teinte|style|ambiance|mode)\\b") || has("^(passe|mets)( tout)? en (bleu|vert|violet|rose|rouge|orange|gris)\\b") ||
            has("^(mets |passe en |active |lance )?(le |la |l'|les )?(" + THEMED_WORDS + ")$")) {
            val p = PALETTE_WORDS.firstOrNull { (_, words) -> words.any { w -> has("\\b" + Regex.escape(w) + "\\b") } }?.first
            if (p != null) {
                if (p == Palette.DYNAMIQUE && Build.VERSION.SDK_INT < 31) return Result("Les couleurs du fond d'écran demandent Android 12 ou plus récent.")
                a.setPalette(p)
                return Result("Thème « ${p.label} » appliqué.")
            }
            if (has("\\b(theme|couleurs?)\\b") && has("\\b(change|autre|suivant)\\b")) {
                val list = Palette.entries.filter { it != Palette.DYNAMIQUE && it != Palette.ALEATOIRE }
                val next = list[(list.indexOf(a.palette.value) + 1).mod(list.size)]
                a.setPalette(next)
                return Result("Thème « ${next.label} » appliqué.")
            }
        }

        // « Surprends-moi » : nouveau tirage au sort
        if (has("^(surprends[- ]moi|theme (au hasard|aleatoire)|un autre tirage|nouveau tirage|relance le (theme|tirage))$") ||
            (a.palette.value == Palette.ALEATOIRE && has("\\b(autre|nouveau) (tirage|theme)\\b"))) {
            if (a.palette.value != Palette.ALEATOIRE) a.setPalette(Palette.ALEATOIRE) else a.reroll()
            return Result("Nouveau thème tiré au sort !")
        }

        // Style des icônes
        if (has("\\bicones?\\b")) {
            val st = when {
                has("\\bneon|cyber") -> IconStyle.NEON
                has("\\b(grimoire|fantasy|fantaisie|medieva|gothique)") -> IconStyle.GRIMOIRE
                has("\\b(terminal|hacker|retro|console)") -> IconStyle.TERMINAL
                has("\\b(bulles?|degrade)") -> IconStyle.BULLE
                has("\\b(contour|trait|fines?)\\b") -> IconStyle.CONTOUR
                has("\\b(minimal|simples?|sobres?)") -> IconStyle.MINIMAL
                has("\\bhologramm") -> IconStyle.HOLOGRAMME
                has("\\b(blason|ecu|chevalier)") -> IconStyle.BLASON
                has("\\b(manga|bd|comic)") -> IconStyle.MANGA
                has("\\b(grunge|abime|zombie)") -> IconStyle.GRUNGE
                has("\\b(encre|pinceau|zen)") -> IconStyle.ENCRE
                has("\\bvitrail") -> IconStyle.VITRAIL
                has("\\b(pleines?|classiques?)\\b") -> IconStyle.PLEIN
                has("\\b(theme|auto)") -> IconStyle.AUTO
                else -> null
            }
            if (st != null) {
                a.setIcons(st)
                return Result("Icônes : ${st.label.lowercase()}.")
            }
        }

        // Décors animés
        if (has("\\banimations?\\b|\\bdecors? animes?\\b")) {
            val on = !has("\\b(desactive|coupe|arrete|enleve|retire|stop|sans)\\b")
            a.setAnimations(on)
            return Result(if (on) "Décors animés activés." else "Décors animés désactivés.")
        }

        // Police
        if (has("\\b(police|typo|typographie|ecriture)\\b") && !has("\\b(plus grand|plus gros|plus petit|taille|grande?|petite?)\\b")) {
            val f = when {
                has("\\bfuturist") -> FontChoice.FUTURISTE
                has("\\bhologramm") -> FontChoice.HOLOGRAMME
                has("\\bmediev") -> FontChoice.MEDIEVALE
                has("\\bgothique") -> FontChoice.GOTHIQUE
                has("\\b(horreur|zombie)") -> FontChoice.HORREUR
                has("\\b(sanglante|sang)\\b") -> FontChoice.SANGLANTE
                has("\\b(affiche|condensee)") -> FontChoice.CONDENSEE
                has("\\b(manga|bd|comic)") -> FontChoice.MANGA
                has("\\bsamourai") -> FontChoice.SAMOURAI
                has("\\bmarqueur") -> FontChoice.MARQUEUR
                has("\\b(pixel|jeu video|retro)") -> FontChoice.PIXEL
                has("\\bdouce") -> FontChoice.DOUCE
                has("\\bcrayon") -> FontChoice.CRAYON
                has("\\bmachine a ecrire") -> FontChoice.MACHINE
                has("\\b(mono|code|terminal)") -> FontChoice.MONO
                has("\\b(elegante?|serif|livre|classique ancienne)") -> FontChoice.SERIF
                has("\\b(manuscrite|cursive|a la main|attachee)") -> FontChoice.CURSIVE
                has("\\b(classique|normale|simple)\\b") -> FontChoice.SANS
                has("\\b(theme|auto)") -> FontChoice.AUTO
                else -> null
            }
            if (f != null) {
                a.setFont(f)
                return Result("Police : ${f.label.lowercase()}.")
            }
        }

        // Taille du texte
        if (has("\\b(texte|police|ecriture|caracteres|lettres)\\b")) {
            val cur = a.text.value.ordinal
            val target = when {
                has("\\btres (grand|gros)") -> TextSize.XLARGE
                has("\\b(plus grand|plus gros|agrandi|augmente|grossi)") -> TextSize.entries[(cur + 1).coerceAtMost(TextSize.entries.size - 1)]
                has("\\b(plus petit|reduis|reduire|diminue|rapetisse)") -> TextSize.entries[(cur - 1).coerceAtLeast(0)]
                has("\\bnormal") -> TextSize.NORMAL
                has("\\bpetite?\\b") -> TextSize.SMALL
                has("\\b(grande?|grosse?)\\b") -> TextSize.LARGE
                else -> null
            }
            if (target != null) {
                a.setText(target)
                return Result("Texte : ${target.label.lowercase()}.")
            }
        }

        // Formes
        if (has("\\b(formes?|coins|angles|boutons)\\b")) {
            val s = when {
                has("\\btres arrondi") -> ShapeStyle.PILL
                has("\\barrondi") -> ShapeStyle.ROUNDED
                has("\\b(carre|droit|angle)") -> ShapeStyle.SQUARE
                has("\\bdoux") -> ShapeStyle.SOFT
                has("\\b(biseaute|coupe|futuriste)") -> ShapeStyle.CUT
                else -> null
            }
            if (s != null) {
                a.setShapes(s)
                return Result("Formes : ${s.label.lowercase()}.")
            }
        }

        // Écran d'accueil
        if (has("\\baccueil\\b")) {
            val h = when {
                has("\\b(liste)\\b") -> HomeStyle.LIST
                has("\\b(tuiles|grille|cartes|blocs)\\b") -> HomeStyle.GRID
                has("\\b(compact|icones|petites)\\b") -> HomeStyle.COMPACT
                else -> null
            }
            if (h != null) {
                a.setHome(h)
                return Result("Accueil en ${h.label.lowercase()}.")
            }
        }

        // Affichage des notes
        if (has("\\bnotes\\b") && has("\\b(affiche|affichage|presente|mets|montre)\\b")) {
            val d = when {
                has("\\b(depliable|deroulant)") -> DisplayMode.EXPAND
                has("\\bcompact") -> DisplayMode.COMPACT
                has("\\bgrille\\b") -> DisplayMode.GRID
                has("\\bcartes?\\b") -> DisplayMode.CARDS
                has("\\bliste\\b") -> DisplayMode.COMPACT
                else -> null
            }
            if (d != null) {
                settings.setDisplay(d)
                return Result("Notes affichées en « ${d.label.lowercase()} ».")
            }
        }
        return null
    }
}
