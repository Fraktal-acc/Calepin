package fr.jeremy.calepin.ui

import android.content.Context
import android.os.Build
import fr.jeremy.calepin.AppSettings
import fr.jeremy.calepin.BuildConfig
import fr.jeremy.calepin.DisplayMode
import fr.jeremy.calepin.search.TextNorm

/**
 * Commandes d'apparence et de navigation en français courant :
 * « thème océan », « mode sombre », « texte plus grand », « accueil en liste », « ouvre la télécommande »…
 */
object AppearanceCommands {

    /** Réponse à afficher et écran à ouvrir (ou null). */
    data class Result(val reply: String, val navigate: String? = null)

    private val PALETTE_WORDS = listOf(
        Palette.MEDITERRANEE to listOf("mediterranee", "mediterraneen", "mer", "classique", "par defaut", "origine"),
        Palette.OCEAN to listOf("ocean", "bleu"),
        Palette.FORET to listOf("foret", "vert", "nature"),
        Palette.LAVANDE to listOf("lavande", "violet", "mauve"),
        Palette.SOLEIL to listOf("soleil", "orange", "jaune", "ambre"),
        Palette.CORAIL to listOf("corail", "rouge"),
        Palette.ROSE to listOf("rose"),
        Palette.ARDOISE to listOf("ardoise", "gris", "sobre", "neutre"),
        Palette.DYNAMIQUE to listOf("fond d'ecran", "fond ecran", "dynamique", "material you"),
    )

    fun handle(ctx: Context, settings: AppSettings, raw: String): Result? {
        val n = TextNorm.norm(raw).trim().trimEnd('.', '!', '?').replace(Regex("\\s+"), " ")
        val a = Appearance.get(ctx)
        fun has(rx: String) = Regex(rx).containsMatchIn(n)

        // Navigation
        if (has("^(ouvre|affiche|montre|lance|va (sur|dans|a))\\b")) {
            when {
                has("\\btelecommande\\b") && BuildConfig.AI -> return Result("J'ouvre la télécommande.", "remote")
                has("\\b(appareils|maison|domotique)\\b") && BuildConfig.AI && !has("\\bnote") -> return Result("J'ouvre les appareils de la maison.", "devices")
                has("\\b(apparence|themes?|couleurs)\\b") -> return Result("J'ouvre l'apparence.", "appearance")
                has("\\b(jeux|jeu)\\b") -> return Result("J'ouvre les jeux.", "games")
                has("\\b(parametres|reglages)\\b") -> return Result("J'ouvre les paramètres.", "settings")
                has("\\baccueil\\b") -> return Result("Retour à l'accueil.", "home")
                has("^\\S+ (les |mes )?notes$") -> return Result("J'ouvre les notes.", "notes")
            }
        }
        if (has("^(retour (a l')?accueil|ecran d'accueil|accueil)$")) return Result("Retour à l'accueil.", "home")

        // Mode clair / sombre / noir
        if (has("\\b(mode|theme|passe en|mets en|affichage)\\b") || has("^(sombre|clair|noir)$")) {
            val mode = when {
                has("\\b(noir total|tout noir|oled|amoled|mode noir|theme noir)\\b") -> DarkMode.BLACK
                has("\\b(sombre|nuit|fonce)\\b") -> DarkMode.DARK
                has("\\b(clair|jour|blanc)\\b") -> DarkMode.LIGHT
                has("\\bmode (automatique|auto|systeme)\\b|comme le telephone") -> DarkMode.SYSTEM
                else -> null
            }
            if (mode != null && !has("\\b(couleur|palette)\\b")) {
                a.setDark(mode)
                return Result("Mode ${mode.label.lowercase()} activé.")
            }
        }

        // Palette de couleurs
        if (has("\\b(theme|couleurs?|palette|teinte)\\b") || has("^(passe|mets)( tout)? en (bleu|vert|violet|rose|rouge|orange|gris)\\b")) {
            val p = PALETTE_WORDS.firstOrNull { (_, words) -> words.any { w -> has("\\b" + Regex.escape(w) + "\\b") } }?.first
            if (p != null) {
                if (p == Palette.DYNAMIQUE && Build.VERSION.SDK_INT < 31) return Result("Les couleurs du fond d'écran demandent Android 12 ou plus récent.")
                a.setPalette(p)
                return Result("Thème « ${p.label} » appliqué.")
            }
            if (has("\\b(theme|couleurs?)\\b") && has("\\b(change|autre|suivant)\\b")) {
                val list = Palette.entries.filter { it != Palette.DYNAMIQUE }
                val next = list[(list.indexOf(a.palette.value) + 1).mod(list.size)]
                a.setPalette(next)
                return Result("Thème « ${next.label} » appliqué.")
            }
        }

        // Taille du texte
        if (has("\\b(texte|police|ecriture|caracteres|lettres)\\b")) {
            val cur = a.text.value.ordinal
            val target = when {
                has("\\btres (grand|gros)") -> TextSize.XLARGE
                has("\\b(plus grand|plus gros|agrandi|augmente|grossi)") -> TextSize.entries[(cur + 1).coerceAtMost(TextSize.entries.size - 1)]
                has("\\b(plus petit|reduis|reduire|diminue|rapetisse)") -> TextSize.entries[(cur - 1).coerceAtLeast(0)]
                has("\\bnormal") -> TextSize.NORMAL
                has("\\bpetite?\\b") -> TextSize.SMALL
                has("\\b(grande?|grosse?)\\b") -> TextSize.LARGE
                else -> null
            }
            if (target != null) {
                a.setText(target)
                return Result("Texte : ${target.label.lowercase()}.")
            }
        }

        // Formes
        if (has("\\b(formes?|coins|angles|boutons)\\b")) {
            val s = when {
                has("\\btres arrondi") -> ShapeStyle.PILL
                has("\\barrondi") -> ShapeStyle.ROUNDED
                has("\\b(carre|droit|angle)") -> ShapeStyle.SQUARE
                has("\\bdoux") -> ShapeStyle.SOFT
                else -> null
            }
            if (s != null) {
                a.setShapes(s)
                return Result("Formes : ${s.label.lowercase()}.")
            }
        }

        // Écran d'accueil
        if (has("\\baccueil\\b")) {
            val h = when {
                has("\\b(liste)\\b") -> HomeStyle.LIST
                has("\\b(tuiles|grille|cartes|blocs)\\b") -> HomeStyle.GRID
                has("\\b(compact|icones|petites)\\b") -> HomeStyle.COMPACT
                else -> null
            }
            if (h != null) {
                a.setHome(h)
                return Result("Accueil en ${h.label.lowercase()}.")
            }
        }

        // Affichage des notes
        if (has("\\bnotes\\b") && has("\\b(affiche|affichage|presente|mets|montre)\\b")) {
            val d = when {
                has("\\b(depliable|deroulant)") -> DisplayMode.EXPAND
                has("\\bcompact") -> DisplayMode.COMPACT
                has("\\bgrille\\b") -> DisplayMode.GRID
                has("\\bcartes?\\b") -> DisplayMode.CARDS
                has("\\bliste\\b") -> DisplayMode.COMPACT
                else -> null
            }
            if (d != null) {
                settings.setDisplay(d)
                return Result("Notes affichées en « ${d.label.lowercase()} ».")
            }
        }
        return null
    }
}
