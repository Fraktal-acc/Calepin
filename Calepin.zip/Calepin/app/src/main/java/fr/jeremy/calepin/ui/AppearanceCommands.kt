package fr.jeremy.calepin.ui

import android.content.Context
import android.os.Build
import fr.jeremy.calepin.AppSettings
import fr.jeremy.calepin.BuildConfig
import fr.jeremy.calepin.DisplayMode
import fr.jeremy.calepin.search.TextNorm

/**
 * Commandes d'apparence et de navigation en français courant :
 * « fond étoiles », « mode sombre », « texte plus grand », « accueil en liste », « ouvre la télécommande »…
 */
object AppearanceCommands {

    /** Réponse à afficher et écran à ouvrir (ou null). */
    data class Result(val reply: String, val navigate: String? = null)

    private val PALETTE_WORDS_BASE = listOf(
        Palette.MEDITERRANEE to listOf("mediterranee", "mediterraneen", "mer", "classique", "par defaut", "origine"),
        Palette.OCEAN to listOf("ocean", "bleu"),
        Palette.FORET to listOf("foret", "vert", "nature"),
        Palette.LAVANDE to listOf("lavande", "violet", "mauve"),
        Palette.SOLEIL to listOf("soleil", "orange", "jaune", "ambre"),
        Palette.CORAIL to listOf("corail", "rouge"),
        Palette.ROSE to listOf("rose"),
        Palette.ARDOISE to listOf("ardoise", "gris", "sobre", "neutre"),
        Palette.DYNAMIQUE to listOf("fond d'ecran", "fond ecran", "dynamique", "material you"),
        Palette.CYBERPUNK to listOf("cyberpunk", "cyber punk", "cyber", "neon", "futuriste"),
        Palette.DARK_FANTASY to listOf("dark fantasy", "dark fantaisie", "fantasy", "fantaisie", "grimoire", "medieval", "gothique", "sorcier"),
        Palette.SYNTHWAVE to listOf("synthwave", "synth wave", "retrowave", "annees 80", "coucher de soleil"),
        Palette.TERMINAL to listOf("terminal", "hacker", "matrix", "retro", "console"),
        Palette.AURORE to listOf("aurore", "boreale", "polaire"),
        Palette.PARCHEMIN to listOf("parchemin", "vintage", "papier", "ancien", "sepia"),
        Palette.ALEATOIRE to listOf("aleatoire", "au hasard", "hasard", "surprise", "surprends moi"),
        Palette.GALAXIE to listOf("galaxie", "galaxie lointaine", "star wars", "guerre des etoiles", "space opera", "jedi", "sabre laser", "espace"),
        Palette.ROYAUMES to listOf("game of thrones", "trone de fer", "royaumes", "glace et de feu", "westeros", "dragons"),
        Palette.APOCALYPSE to listOf("walking dead", "zombie", "zombies", "apocalypse"),
        Palette.MEDICO_LEGAL to listOf("dexter", "medico legal", "medico-legal", "scene de crime", "labo"),
        Palette.NAPLES to listOf("gomorra", "naples", "camorra", "mafia", "naples noir"),
        Palette.NINJA to listOf("naruto", "ninja", "voie du ninja"),
        Palette.AURA to listOf("dragon ball", "dragon ball z", "dbz", "saiyan", "aura", "aura de combat"),
        Palette.CARNET_MAUDIT to listOf("death note", "carnet maudit", "shinigami"),
        Palette.LUCIOLES to listOf("lucioles", "luciole"),
        Palette.ABYSSES to listOf("abysses", "fond marin", "sous-marin", "ocean profond", "bulles"),
        Palette.ORAGE to listOf("orage", "tempete", "eclairs"),
        Palette.SAKURA to listOf("sakura", "cerisier", "cerisiers", "japon"),
        Palette.MENTHE to listOf("menthe"),
        Palette.TURQUOISE to listOf("turquoise"),
        Palette.INDIGO to listOf("indigo"),
        Palette.CERISE to listOf("cerise"),
        Palette.BORDEAUX to listOf("bordeaux", "lie de vin"),
        Palette.SABLE to listOf("sable", "beige"),
        Palette.OLIVE to listOf("olive", "kaki"),
        Palette.MONOCHROME to listOf("monochrome", "noir et blanc"),
        Palette.NUIT to listOf("nuit bleue", "bleu nuit"),
        Palette.GRAPHITE to listOf("graphite", "anthracite"),
        Palette.LAGON to listOf("lagon", "vagues", "tropical", "plage"),
        Palette.LAVE to listOf("lampe a lave", "lave"),
        Palette.VILLE to listOf("lumieres de la ville", "ville", "bokeh"),
        Palette.FETE to listOf("fete", "confettis", "anniversaire"),
        Palette.DESERT to listOf("desert", "dunes", "sahara"),
        Palette.NEBULEUSE to listOf("nebuleuse", "cosmos"),
        Palette.BRASIER to listOf("brasier", "feu", "flammes"),
        Palette.ROMANCE to listOf("romance", "romantique", "coeurs", "saint valentin"),
        Palette.AUTOMNE to listOf("automne", "feuilles mortes"),
        Palette.HIVER to listOf("nuit d'hiver", "hiver", "neige", "flocons"),
        Palette.JAPON to listOf("japon", "japonais", "zen"),
        Palette.CHINE to listOf("chine", "chinois", "nouvel an chinois", "lanternes"),
        Palette.INDE to listOf("inde", "indien", "mandala"),
        Palette.MAROC to listOf("maroc", "marocain", "riad", "zellige"),
        Palette.MEXIQUE to listOf("mexique", "mexicain", "fiesta"),
        Palette.GRECE to listOf("grece", "grec", "grecque"),
        Palette.EGYPTE to listOf("egypte", "egyptien", "pharaon"),
        Palette.AFRIQUE to listOf("afrique", "africain", "savane"),
        Palette.NORDIQUE to listOf("nordique", "scandinave", "hygge"),
        Palette.POLYNESIE to listOf("polynesie", "tahiti", "polynesien"),
        Palette.MONTAGNES to listOf("montagne", "montagnes"),
        Palette.OCEAN_SOIR to listOf("ocean", "couchant", "coucher de soleil sur la mer"),
        Palette.FORET_BRUME to listOf("foret dans la brume", "foret brumeuse", "brume"),
        Palette.VILLE_NUIT to listOf("ville la nuit", "ville de nuit", "skyline"),
        Palette.DESERT_ETOILE to listOf("desert sous les etoiles", "voie lactee"),
        Palette.CHAMPS_LAVANDE to listOf("champs de lavande", "provence"),
        Palette.COTE_AZUR to listOf("cote d'azur", "riviera", "cote azur"),
        Palette.ADAPTATIF to listOf("adaptatif", "adaptative", "selon l'heure", "selon le temps", "heure et meteo"),
        Palette.PIRATES to listOf("pirates", "mers des pirates", "bateau pirate", "caraibes"),
        Palette.FAR_WEST to listOf("far west", "western", "cowboy"),
        Palette.RESEAU to listOf("reseau fantome", "circuit", "cyber hacker", "pirate informatique"),
        Palette.VAMPIRES to listOf("vampires", "vampire", "nuit des vampires", "dracula"),
        Palette.VOLCAN to listOf("volcan", "ile du volcan", "jurassique", "dinosaures"),
    )

    private val THEMED_WORDS: String by lazy {
        PALETTE_WORDS_BASE.filter { it.first.group >= 1 || it.first == Palette.PARCHEMIN }.flatMap { it.second }.filter { it.length > 3 }.joinToString("|") { Regex.escape(it) }
    }

    /** Thèmes à ambiance d'abord (« vert terminal » doit donner Terminal, pas Forêt). */
    private val PALETTE_WORDS = PALETTE_WORDS_BASE.sortedByDescending { it.first.forceDark != null || it.first == Palette.ALEATOIRE }

    /** Réponse traduite dans la langue de l'appli (les commandes, elles, sont en français). */
    fun handle(ctx: Context, settings: AppSettings, raw: String): Result? =
        handleFr(ctx, settings, raw)?.let { it.copy(reply = fr.jeremy.calepin.i18n.I18n.tr(it.reply)) }

    private fun handleFr(ctx: Context, settings: AppSettings, raw: String): Result? {
        val n = TextNorm.norm(raw).trim().trimEnd('.', '!', '?').replace(Regex("\\s+"), " ")
        val a = Appearance.get(ctx)
        fun has(rx: String) = Regex(rx).containsMatchIn(n)

        // Navigation
        if (has("^(ouvre|affiche|montre|lance|va (sur|dans|a))\\b")) {
            when {
                has("\\btelecommande\\b") && BuildConfig.AI -> return Result("J'ouvre la télécommande.", "remote")
                has("\\b(appareils|maison|domotique)\\b") && BuildConfig.AI && !has("\\bnote") -> return Result("J'ouvre les appareils de la maison.", "devices")
                has("\\b(apparence|themes?|couleurs)\\b") -> return Result("J'ouvre l'apparence.", "appearance")
                has("\\b(meteo|previsions)\\b") -> return Result("J'ouvre la météo.", "weather")
                has("\\b(nettoyeur|nettoyage)\\b") -> return Result("J'ouvre le nettoyeur.", "cleaner")
                has("\\b(explorateur|gestionnaire de fichiers|fichiers du telephone|mes fichiers)\\b") -> return Result("J'ouvre les fichiers.", "files")
                has("\\b(optimiseur|optimisation|entretien)\\b") -> return Result("J'ouvre l'optimiseur.", "optimizer")
                has("\\b(web ?radios?|radios?)\\b") -> return Result("J'ouvre les webradios.", "radio")
                has("\\bdetente\\b") -> return Result("J'ouvre la détente.", "relax")
                has("\\b(jeux|jeu)\\b") -> return Result("J'ouvre les jeux.", "games")
                has("\\b(mode pro|clients?|interventions?|pro)\\b") && !has("\\bnotes?\\b") -> return Result("J'ouvre le mode pro.", "pro")
                has("\\bscenarios?\\b") && BuildConfig.AI -> return Result("J'ouvre les scénarios.", "scenarios")
                has("\\b(heures de travail|releve d'heures|mes heures|heures sup)") -> return Result("J'ouvre les heures de travail.", "workhours")
                has("\\bcorbeille\\b") -> return Result("J'ouvre la corbeille.", "trash")
                has("\\b(pdf|mes documents)\\b") -> return Result("J'ouvre les PDF.", "pdf")
                has("\\bbureau\\b") -> return Result("J'ouvre le bureau.", "office")
                has("\\b(statistiques|stats)\\b") -> return Result("J'ouvre les statistiques.", "stats")
                has("\\b(programme tele|programme tv|guide tele|guide tv|programme de ce soir)\\b") -> return Result("J'ouvre le programme télé.", "tvguide")
                has("\\b(rappels? par lieu|rappels? de lieu)\\b") -> return Result("J'ouvre les rappels par lieu.", "places")
                has("\\b(journal des plantages|plantages)\\b") -> return Result("J'ouvre le journal des plantages.", "crashes")
                has("\\b(historique des (mises a jour|versions)|journal des versions|nouveautes|changelog)\\b") -> return Result("J'ouvre l'historique des mises à jour.", "changelog")
                has("\\b(mes commandes|commandes personnelles)\\b") -> return Result("J'ouvre tes commandes.", "commands")
                has("\\bsauvegarde\\b") -> return Result("J'ouvre la sauvegarde.", "backup")
                has("\\b(parametres|reglages)\\b") -> return Result("J'ouvre les paramètres.", "settings")
                has("\\baccueil\\b") -> return Result("Retour à l'accueil.", "home")
                has("^\\S+ (les |mes )?notes$") -> return Result("J'ouvre les notes.", "notes")
            }
        }
        if (has("^(retour (a l')?accueil|ecran d'accueil|accueil)$")) return Result("Retour à l'accueil.", "home")
        // Nouveautés de l'appli : « quoi de neuf ? », « quoi de neuf dans Calepin ? », « qu'est-ce qui a changé dans cette version ? »
        if (has("^(quoi de neuf|qu'est-ce qui a change|qu'est-ce qu'il y a de nouveau|quelles sont les nouveautes|les nouveautes)\\b") &&
            has("\\b(calepin|appli|application|version|mise a jour|nouveautes)\\b") ||
            has("^(quoi de neuf|nouveautes|historique des mises a jour|journal des versions)$")
        ) return Result("Voici l'historique des mises à jour.", "changelog")
        // Mode nuit au travail (écran rouge très sombre, gros boutons)
        if (has("\\bmode (nuit|de nuit) (au |du )?travail\\b|\\bmode travail de nuit\\b|\\becran rouge\\b")) {
            val off = has("\\b(desactive|enleve|quitte|arrete|coupe|sors)\\b")
            fr.jeremy.calepin.care.NightWork.set(ctx, !off)
            return Result(if (off) "Mode nuit désactivé." else "Mode nuit activé : écran rouge et très sombre. Dis « quitte le mode nuit » pour revenir.")
        }
        if (fr.jeremy.calepin.care.NightWork.on.value && has("^(desactive|enleve|quitte|arrete|coupe|sors du) (le )?mode nuit")) {
            fr.jeremy.calepin.care.NightWork.set(ctx, false)
            return Result("Mode nuit désactivé.")
        }
        // Météo
        if (has("^(nettoie|nettoyer|optimise|optimiser) (le |mon )?telephone$")) return Result("J'ouvre le nettoyeur.", "cleaner")
        if (!has("^(note|rappel|rappelle|ajoute|cherche)\\b") && !has("\\b(theme|ambiance)\\b") &&
            has("\\b(meteo|quel temps|temps fait|temps va|fait il chaud|fait il froid|fait-il|il va pleuvoir|va pleuvoir|va-t-il pleuvoir|pleuvoir)\\b")
        ) {
            fr.jeremy.calepin.weather.WeatherRepo.loadCached(ctx)
            val wantTomorrow = has("\\bdemain\\b")
            val text = if (wantTomorrow) fr.jeremy.calepin.weather.WeatherRepo.tomorrow() else fr.jeremy.calepin.weather.WeatherRepo.summary()
            return if (text != null) Result(text) else Result("Choisis d'abord ta ville ou ta position dans la météo.", "weather")
        }

        // Webradio en cours
        if (has("^(coupe|arrete|stoppe|eteins|stop) (la )?(web ?)?radio$")) {
            fr.jeremy.calepin.radio.RadioPlayer.stop(ctx)
            return Result("J'arrête la radio.")
        }
        if (has("^(mets|remets|relance|reprends) (la )?(web ?)?radio$")) {
            return if (fr.jeremy.calepin.radio.RadioPlayer.resumeLast(ctx)) Result("Je remets la radio.") else Result("Choisis d'abord une radio.", "radio")
        }

        // Mode clair / sombre / noir
        if (has("\\b(mode|theme|passe en|mets en|affichage)\\b") || has("^(sombre|clair|noir)$")) {
            val mode = when {
                has("\\b(noir total|tout noir|oled|amoled|mode noir|theme noir)\\b") -> DarkMode.BLACK
                has("\\b(sombre|nuit|fonce)\\b") -> DarkMode.DARK
                has("\\b(clair|jour|blanc)\\b") -> DarkMode.LIGHT
                has("\\bmode (automatique|auto|systeme)\\b|comme le telephone") -> DarkMode.SYSTEM
                else -> null
            }
            // « thème nuit bleue », « nuit des vampires », « noir et blanc »… sont des thèmes, pas le mode sombre
            val isThemeName = has("\\bnuit (bleue|d'hiver|des)\\b|\\bbleu nuit\\b|\\bnoir et blanc\\b") ||
                a.customThemes.value.any { c -> TextNorm.norm(c.name).trim().let { it.length >= 2 && n.contains(it) } }
            if (mode != null && !isThemeName && !has("\\b(couleur|palette)\\b")) {
                a.setDark(mode)
                return Result("Mode ${mode.let { fr.jeremy.calepin.i18n.I18n.tr(it.label) }.lowercase()} activé.")
            }
        }

        // « Garde ce thème (sous le nom X) » : l'apparence du moment (ou le tirage au sort) dans « Mes thèmes »
        Regex("^(garde|sauvegarde|enregistre|conserve)( moi)? (ce|le|mon) theme( (sous le nom|appele|nomme|qui s'appelle) (.+))?$").find(n)?.let { m ->
            val raw = m.groupValues[6].trim()
            val name = if (raw.isNotEmpty()) raw.replaceFirstChar { it.uppercase() } else "Mon thème " + (a.customThemes.value.size + 1)
            a.saveCurrent(name)
            return Result("Thème « $name » gardé dans « Mes thèmes ».")
        }

        // Thème aléatoire : « thème aléatoire », « surprends-moi », « nouveau tirage »
        if (has("^(surprends[- ]moi|(mets |passe en |active )?(le )?theme (au hasard|aleatoire)|un autre tirage|nouveau tirage|relance le (theme|tirage))$") ||
            (a.palette.value == Palette.ALEATOIRE && has("\\b(autre|nouveau) (tirage|theme)\\b"))) {
            if (a.palette.value != Palette.ALEATOIRE) a.setPalette(Palette.ALEATOIRE) else a.reroll()
            return Result("Nouveau thème tiré au sort !")
        }

        // Thème perso appelé par son nom
        if (has("\\b(theme|ambiance|mets|passe)\\b")) {
            a.customThemes.value.sortedByDescending { it.name.length }.firstOrNull { c ->
                val cn = TextNorm.norm(c.name).trim()
                cn.length >= 2 && has("\\b" + Regex.escape(cn) + "\\b")
            }?.let { c ->
                a.selectCustom(c.id)
                return Result("Thème « ${c.name} » appliqué.")
            }
            if (has("\\btheme (d'origine|par defaut|classique|mediterranee)\\b")) {
                a.setPalette(Palette.MEDITERRANEE)
                return Result("Apparence d'origine.")
            }
        }

        // Fond d'écran par son nom : « fond étoiles », « fond d'écran neige », « mets le fond lucioles »
        if (has("\\b(fond|fonds|decor|decors|theme|ambiance|mets|passe)\\b") && !has("\\b(icones?|police|typo)\\b")) {
            if (has("\\b(aucun fond|sans fond|enleve le fond|retire le fond|fond uni)\\b")) {
                a.setDecoOverride(Deco.NONE.name)
                return Result("Fond retiré.")
            }
            if (has("\\bfond (par defaut|d'origine)\\b")) {
                a.setDecoOverride("")
                return Result("Fond par défaut.")
            }
            DECO_LABELS.entries.sortedByDescending { it.value.length }.firstOrNull { (d, label) ->
                d != Deco.NONE && TextNorm.norm(label).lowercase().let { l -> l.length >= 3 && has("\\b" + Regex.escape(l) + "\\b") }
            }?.let { (d, label) ->
                a.setDecoOverride(d.name)
                return Result("Fond « ${fr.jeremy.calepin.i18n.I18n.tr(label)} » appliqué.")
            }
        }

        // Anciens noms de thèmes : leur fond d'écran (« cyberpunk », « dark fantasy »…) ou leur couleur (« passe en bleu »)
        if (!has("\\b(icones?|police|typo)\\b") && has("\\b(theme|couleurs?|palette|teinte|style|ambiance|mode|fond)\\b") || has("^(passe|mets)( tout)? en (bleu|vert|violet|rose|rouge|orange|gris)\\b") ||
            has("^(mets |passe en |active |lance )?(le |la |l'|les )?(" + THEMED_WORDS + ")$")) {
            val p = PALETTE_WORDS.firstOrNull { (_, words) -> words.any { w -> has("\\b" + Regex.escape(w) + "\\b") } }?.first
            if (p != null && p != Palette.ALEATOIRE && p != Palette.ADAPTATIF && p != Palette.DYNAMIQUE) {
                if (p.deco != Deco.NONE) {
                    a.setDecoOverride(p.deco.name)
                    return Result("Fond « ${fr.jeremy.calepin.i18n.I18n.tr(DECO_LABELS[p.deco] ?: p.label)} » appliqué.")
                }
                a.setAccentColor(ColorPref.of(androidx.compose.ui.graphics.Color(p.primary)))
                return Result("Couleur principale changée.")
            }
        }

        // « Surprends-moi » : un fond animé au hasard
        if (has("^(fond (au hasard|aleatoire)|un autre fond|change de fond)$")) {
            val d = Deco.entries.filter { it.animated && it != Deco.SUNNY && it != Deco.CLOUDS }.random()
            a.setDecoOverride(d.name)
            return Result("Fond « ${fr.jeremy.calepin.i18n.I18n.tr(DECO_LABELS[d] ?: d.name)} » appliqué.")
        }

        // Style des icônes
        if (has("\\bicones?\\b")) {
            val st = when {
                has("\\bneon|cyber") -> IconStyle.NEON
                has("\\b(grimoire|fantasy|fantaisie|medieva|gothique)") -> IconStyle.GRIMOIRE
                has("\\b(terminal|hacker|retro|console)") -> IconStyle.TERMINAL
                has("\\b(bulles?|degrade)") -> IconStyle.BULLE
                has("\\b(contour|trait|fines?)\\b") -> IconStyle.CONTOUR
                has("\\b(minimal|simples?|sobres?)") -> IconStyle.MINIMAL
                has("\\bhologramm") -> IconStyle.HOLOGRAMME
                has("\\baquarell") -> IconStyle.AQUARELLE
                has("\\bvagues?\\b") -> IconStyle.VAGUE
                has("\\b(glace|cristal|givre)") -> IconStyle.GLACE
                has("\\b(verre|depoli)") -> IconStyle.VERRE
                has("\\b(flamme|feu)") -> IconStyle.FLAMME
                has("\\bcoeurs?\\b") -> IconStyle.COEUR
                has("\\bplanete") -> IconStyle.PLANETE
                has("\\b(circuit|puce)") -> IconStyle.CIRCUIT
                has("\\bengrenage") -> IconStyle.ENGRENAGE
                has("\\b(sceau|tampon|hanko)") -> IconStyle.SCEAU
                has("\\blanterne") -> IconStyle.LANTERNE
                has("\\b(zellige|mosaique)") -> IconStyle.ZELLIGE
                has("\\bpapel") -> IconStyle.PAPEL
                has("\\b(grecque|meandre)") -> IconStyle.GRECQUE
                has("\\b(blason|ecu|chevalier)") -> IconStyle.BLASON
                has("\\b(manga|bd|comic)") -> IconStyle.MANGA
                has("\\b(grunge|abime|zombie)") -> IconStyle.GRUNGE
                has("\\b(encre|pinceau|zen)") -> IconStyle.ENCRE
                has("\\bvitrail") -> IconStyle.VITRAIL
                has("\\b(pleines?|classiques?)\\b") -> IconStyle.PLEIN
                has("\\b(theme|auto)") -> IconStyle.AUTO
                else -> null
            }
            if (st != null) {
                a.setIcons(st)
                return Result("Icônes : ${st.let { fr.jeremy.calepin.i18n.I18n.tr(it.label) }.lowercase()}.")
            }
        }

        // Décors animés
        if (has("\\banimations?\\b|\\bdecors? animes?\\b")) {
            val on = !has("\\b(desactive|coupe|arrete|enleve|retire|stop|sans)\\b")
            a.setAnimations(on)
            return Result(if (on) "Décors animés activés." else "Décors animés désactivés.")
        }

        // Police
        if (has("\\b(police|typo|typographie|ecriture)\\b") && !has("\\b(plus grand|plus gros|plus petit|taille|grande?|petite?)\\b")) {
            val f = when {
                has("\\bfuturist") -> FontChoice.FUTURISTE
                has("\\bhologramm") -> FontChoice.HOLOGRAMME
                has("\\bmediev") -> FontChoice.MEDIEVALE
                has("\\bgothique") -> FontChoice.GOTHIQUE
                has("\\b(horreur|zombie)") -> FontChoice.HORREUR
                has("\\b(sanglante|sang)\\b") -> FontChoice.SANGLANTE
                has("\\b(affiche|condensee)") -> FontChoice.CONDENSEE
                has("\\b(manga|bd|comic)") -> FontChoice.MANGA
                has("\\bsamourai") -> FontChoice.SAMOURAI
                has("\\bmarqueur") -> FontChoice.MARQUEUR
                has("\\b(pixel|jeu video|retro)") -> FontChoice.PIXEL
                has("\\bdouce") -> FontChoice.DOUCE
                has("\\bcrayon") -> FontChoice.CRAYON
                has("\\bmachine a ecrire") -> FontChoice.MACHINE
                has("\\b(mono|code|terminal)") -> FontChoice.MONO
                has("\\b(elegante?|serif|livre|classique ancienne)") -> FontChoice.SERIF
                has("\\b(manuscrite|cursive|a la main|attachee)") -> FontChoice.CURSIVE
                has("\\b(classique|normale|simple)\\b") -> FontChoice.SANS
                has("\\b(theme|auto)") -> FontChoice.AUTO
                else -> null
            }
            if (f != null) {
                a.setFont(f)
                return Result("Police : ${f.let { fr.jeremy.calepin.i18n.I18n.tr(it.label) }.lowercase()}.")
            }
        }

        // Taille du texte
        if (has("\\b(texte|police|ecriture|caracteres|lettres)\\b")) {
            val cur = a.text.value.ordinal
            val target = when {
                has("\\btres (grand|gros)") -> TextSize.XLARGE
                has("\\b(plus grand|plus gros|agrandi|augmente|grossi)") -> TextSize.entries[(cur + 1).coerceAtMost(TextSize.entries.size - 1)]
                has("\\b(plus petit|reduis|reduire|diminue|rapetisse)") -> TextSize.entries[(cur - 1).coerceAtLeast(0)]
                has("\\bnormal") -> TextSize.NORMAL
                has("\\bpetite?\\b") -> TextSize.SMALL
                has("\\b(grande?|grosse?)\\b") -> TextSize.LARGE
                else -> null
            }
            if (target != null) {
                a.setText(target)
                return Result("Texte : ${target.let { fr.jeremy.calepin.i18n.I18n.tr(it.label) }.lowercase()}.")
            }
        }

        // Formes
        if (has("\\b(formes?|coins|angles|boutons)\\b")) {
            val s = when {
                has("\\btres arrondi") -> ShapeStyle.PILL
                has("\\barrondi") -> ShapeStyle.ROUNDED
                has("\\b(carre|droit|angle)") -> ShapeStyle.SQUARE
                has("\\bdoux") -> ShapeStyle.SOFT
                has("\\b(biseaute|coupe|futuriste)") -> ShapeStyle.CUT
                else -> null
            }
            if (s != null) {
                a.setShapes(s)
                return Result("Formes : ${s.let { fr.jeremy.calepin.i18n.I18n.tr(it.label) }.lowercase()}.")
            }
        }

        // Écran d'accueil
        if (has("\\baccueil\\b")) {
            val h = when {
                has("\\b(liste)\\b") -> HomeStyle.LIST
                has("\\b(mosaique)\\b") -> HomeStyle.MOSAIC
                has("\\b(carrousel|carousel|defilant|defilante|defilement)\\b") -> HomeStyle.CAROUSEL
                has("\\b(grandes cartes|cartes|bandeaux)\\b") -> HomeStyle.CARDS
                has("\\b(grille)\\b") -> HomeStyle.GRID3
                has("\\b(tuiles|blocs)\\b") -> HomeStyle.GRID
                has("\\b(compact|icones|petites)\\b") -> HomeStyle.COMPACT
                else -> null
            }
            if (h != null) {
                a.setHome(h)
                return Result("Accueil en ${h.let { fr.jeremy.calepin.i18n.I18n.tr(it.label) }.lowercase()}.")
            }
        }

        // Affichage des notes
        if (has("\\bnotes\\b") && has("\\b(affiche|affichage|presente|mets|montre)\\b")) {
            val d = when {
                has("\\b(depliable|deroulant)") -> DisplayMode.EXPAND
                has("\\bcompact") -> DisplayMode.COMPACT
                has("\\bgrille\\b") -> DisplayMode.GRID
                has("\\bcartes?\\b") -> DisplayMode.CARDS
                has("\\bliste\\b") -> DisplayMode.COMPACT
                else -> null
            }
            if (d != null) {
                settings.setDisplay(d)
                return Result("Notes affichées en « ${d.let { fr.jeremy.calepin.i18n.I18n.tr(it.label) }.lowercase()} ».")
            }
        }
        return null
    }
}
