package fr.jeremy.calepin.market

import java.util.Locale
import kotlin.math.abs

/**
 * Durée de chaque bougie étudiée par le robot. [interval] et [range] : ce qu'on demande à Yahoo Finance ;
 * [bucket] (secondes) : bougies regroupées (4 heures = 4 bougies d'une heure), 0 = telles quelles.
 */
enum class Timeframe(val label: String, val interval: String, val range: String, val bucket: Long = 0L) {
    M5("5 minutes", "5m", "5d"),
    M15("15 minutes", "15m", "1mo"),
    M30("30 minutes", "30m", "1mo"),
    H1("1 heure", "60m", "3mo"),
    H4("4 heures", "60m", "1y", 4 * 3600L),
    D1("1 jour", "1d", "2y"),
    W1("1 semaine", "1wk", "10y"),
}

/** Ce que fait une règle quand ses conditions sont réunies. */
enum class Action(val label: String) {
    BUY("Acheter"),
    SELL("Vendre"),
    /** Vente à découvert (CFD) : on gagne quand le cours baisse. */
    SHORT("Vendre à découvert (CFD)"),
    /** Rachat qui ferme une vente à découvert. */
    COVER("Racheter la vente à découvert"),
    ALERT("Me prévenir seulement"),
}

/**
 * Types de conditions. [pa]/[pb] : nom des réglages (null = pas de réglage), [da]/[db] : valeurs par défaut.
 */
enum class CondType(val label: String, val pa: String?, val da: Double, val pb: String? = null, val db: Double = 0.0) {
    RSI_BELOW("RSI sous un seuil (survendu)", "Seuil", 30.0, "Période", 14.0),
    RSI_ABOVE("RSI au-dessus d'un seuil (suracheté)", "Seuil", 70.0, "Période", 14.0),
    PRICE_ABOVE_SMA("Cours au-dessus de la moyenne mobile", "Période", 50.0),
    PRICE_BELOW_SMA("Cours sous la moyenne mobile", "Période", 50.0),
    PRICE_CROSS_UP_SMA("Cours qui passe au-dessus de la moyenne mobile", "Période", 50.0),
    PRICE_CROSS_DOWN_SMA("Cours qui passe sous la moyenne mobile", "Période", 50.0),
    SMA_CROSS_UP("Moyenne courte qui croise la longue vers le haut", "Courte", 50.0, "Longue", 200.0),
    SMA_CROSS_DOWN("Moyenne courte qui croise la longue vers le bas", "Courte", 50.0, "Longue", 200.0),
    EMA_CROSS_UP("Moyenne exponentielle courte qui croise la longue vers le haut", "Courte", 12.0, "Longue", 26.0),
    EMA_CROSS_DOWN("Moyenne exponentielle courte qui croise la longue vers le bas", "Courte", 12.0, "Longue", 26.0),
    MACD_CROSS_UP("MACD qui croise son signal vers le haut", null, 0.0),
    MACD_CROSS_DOWN("MACD qui croise son signal vers le bas", null, 0.0),
    BOLL_BELOW("Cours sous la bande de Bollinger basse", "Période", 20.0, "Écarts", 2.0),
    BOLL_ABOVE("Cours au-dessus de la bande de Bollinger haute", "Période", 20.0, "Écarts", 2.0),
    STOCH_BELOW("Stochastique sous un seuil", "Seuil", 20.0, "Période", 14.0),
    STOCH_ABOVE("Stochastique au-dessus d'un seuil", "Seuil", 80.0, "Période", 14.0),
    BREAKOUT_HIGH("Cours au plus haut depuis N bougies", "Bougies", 20.0),
    BREAKDOWN_LOW("Cours au plus bas depuis N bougies", "Bougies", 20.0),
    CHANGE_UP("Hausse d'au moins X % sur N bougies", "%", 3.0, "Bougies", 1.0),
    CHANGE_DOWN("Baisse d'au moins X % sur N bougies", "%", 3.0, "Bougies", 1.0),
    PRICE_ABOVE("Cours au-dessus d'un prix", "Prix", 0.0),
    PRICE_BELOW("Cours sous un prix", "Prix", 0.0),
    VOLUME_SPIKE("Volume au moins X fois la moyenne", "Fois", 2.0, "Période", 20.0),
    SCORE_ABOVE("Analyse complète : score d'achat au moins égal à", "Score", 50.0),
    SCORE_BELOW("Analyse complète : score de vente au moins égal à", "Score", 50.0),
    FIB_SUPPORT("Repli sur un niveau de Fibonacci (38,2 à 61,8 %) en tendance haussière", null, 0.0),
    FIB_RESIST("Rebond sous un niveau de Fibonacci (38,2 à 61,8 %) en tendance baissière", null, 0.0),
    NEWS_POSITIVE("Actualités favorables (ton au moins égal à)", "Ton %", 30.0),
    NEWS_NEGATIVE("Actualités défavorables (ton au moins égal à)", "Ton %", 30.0),
}

data class Condition(val type: CondType, val a: Double = type.da, val b: Double = type.db)

data class Rule(
    val id: String,
    val name: String,
    val symbols: List<String>,
    val timeframe: Timeframe = Timeframe.D1,
    val action: Action = Action.BUY,
    /** true : toutes les conditions (ET) ; false : une seule suffit (OU). */
    val all: Boolean = true,
    val conditions: List<Condition> = emptyList(),
    /** Achète ou vend dans le portefeuille de simulation (sinon : notification seulement). */
    val simulate: Boolean = true,
    /** Stop et objectif placés par l'analyse (supports, résistances, Fibonacci) au lieu des pourcentages fixes. */
    val smartExit: Boolean = false,
    /** Montant de chaque achat simulé, en euros. */
    val amount: Double = 1000.0,
    /** Stop de perte et objectif de gain en % (0 = aucun), pour les positions ouvertes par cette règle. */
    val stopLoss: Double = 5.0,
    val takeProfit: Double = 10.0,
    val enabled: Boolean = true,
)

/** Résultat d'une condition : vraie ou non, et ce qui a été mesuré (pour l'expliquer). */
data class CondResult(val ok: Boolean, val detail: String, val known: Boolean = true)

object Strategy {
    private fun f(x: Double, d: Int = 2) = String.format(Locale.FRANCE, "%.${d}f", x)

    /** Évalue une condition sur la dernière bougie (la bougie en cours compte, avec le dernier cours). */
    fun evaluate(c: Condition, candles: List<Candle>, news: NewsTone? = null, context: List<Factor> = emptyList()): CondResult {
        val n = candles.size
        if (n < 3) return CondResult(false, "pas assez de données", false)
        val close = candles.map { it.c }
        val last = close[n - 1]
        val i = n - 1
        fun unknown() = CondResult(false, "pas assez d'historique", false)
        fun crossUp(a: List<Double>, b: List<Double>): Boolean? {
            if (a[i].isNaN() || b[i].isNaN() || a[i - 1].isNaN() || b[i - 1].isNaN()) return null
            return a[i - 1] <= b[i - 1] && a[i] > b[i]
        }
        fun crossDown(a: List<Double>, b: List<Double>): Boolean? {
            if (a[i].isNaN() || b[i].isNaN() || a[i - 1].isNaN() || b[i - 1].isNaN()) return null
            return a[i - 1] >= b[i - 1] && a[i] < b[i]
        }
        val pa = c.a.toInt().coerceAtLeast(1)
        val pb = c.b.toInt().coerceAtLeast(1)
        return when (c.type) {
            CondType.RSI_BELOW, CondType.RSI_ABOVE -> {
                val r = Indicators.rsi(close, pb)[i]
                if (r.isNaN()) unknown()
                else CondResult(if (c.type == CondType.RSI_BELOW) r < c.a else r > c.a, "RSI $pb = ${f(r, 1)}")
            }
            CondType.PRICE_ABOVE_SMA, CondType.PRICE_BELOW_SMA -> {
                val m = Indicators.sma(close, pa)[i]
                if (m.isNaN()) unknown()
                else CondResult(if (c.type == CondType.PRICE_ABOVE_SMA) last > m else last < m, "cours ${f(last)} · moyenne $pa = ${f(m)}")
            }
            CondType.PRICE_CROSS_UP_SMA, CondType.PRICE_CROSS_DOWN_SMA -> {
                val m = Indicators.sma(close, pa)
                val x = if (c.type == CondType.PRICE_CROSS_UP_SMA) crossUp(close, m) else crossDown(close, m)
                if (x == null) unknown() else CondResult(x, "cours ${f(last)} · moyenne $pa = ${f(m[i])}")
            }
            CondType.SMA_CROSS_UP, CondType.SMA_CROSS_DOWN, CondType.EMA_CROSS_UP, CondType.EMA_CROSS_DOWN -> {
                val ema = c.type == CondType.EMA_CROSS_UP || c.type == CondType.EMA_CROSS_DOWN
                val fa = if (ema) Indicators.ema(close, pa) else Indicators.sma(close, pa)
                val sl = if (ema) Indicators.ema(close, pb) else Indicators.sma(close, pb)
                val up = c.type == CondType.SMA_CROSS_UP || c.type == CondType.EMA_CROSS_UP
                val x = if (up) crossUp(fa, sl) else crossDown(fa, sl)
                val kind = if (ema) "MME" else "MM"
                if (x == null) unknown() else CondResult(x, "$kind $pa = ${f(fa[i])} · $kind $pb = ${f(sl[i])}")
            }
            CondType.MACD_CROSS_UP, CondType.MACD_CROSS_DOWN -> {
                val (line, sig, _) = Indicators.macd(close)
                val x = if (c.type == CondType.MACD_CROSS_UP) crossUp(line, sig) else crossDown(line, sig)
                if (x == null) unknown() else CondResult(x, "MACD ${f(line[i], 3)} · signal ${f(sig[i], 3)}")
            }
            CondType.BOLL_BELOW, CondType.BOLL_ABOVE -> {
                val (lo, _, hi) = Indicators.bollinger(close, pa, c.b.takeIf { it > 0 } ?: 2.0)
                if (lo[i].isNaN()) unknown()
                else if (c.type == CondType.BOLL_BELOW) CondResult(last < lo[i], "cours ${f(last)} · bande basse ${f(lo[i])}")
                else CondResult(last > hi[i], "cours ${f(last)} · bande haute ${f(hi[i])}")
            }
            CondType.STOCH_BELOW, CondType.STOCH_ABOVE -> {
                val s = Indicators.stochastic(candles, pb)[i]
                if (s.isNaN()) unknown()
                else CondResult(if (c.type == CondType.STOCH_BELOW) s < c.a else s > c.a, "stochastique ${f(s, 1)}")
            }
            CondType.BREAKOUT_HIGH, CondType.BREAKDOWN_LOW -> {
                if (n <= pa) unknown()
                else {
                    val prev = candles.subList(n - 1 - pa, n - 1)
                    if (c.type == CondType.BREAKOUT_HIGH) {
                        val hh = prev.maxOf { it.h }
                        CondResult(last > hh, "cours ${f(last)} · plus haut de $pa bougies ${f(hh)}")
                    } else {
                        val ll = prev.minOf { it.l }
                        CondResult(last < ll, "cours ${f(last)} · plus bas de $pa bougies ${f(ll)}")
                    }
                }
            }
            CondType.CHANGE_UP, CondType.CHANGE_DOWN -> {
                if (n <= pb) unknown()
                else {
                    val ref = close[n - 1 - pb]
                    val ch = if (ref == 0.0) 0.0 else (last - ref) / ref * 100
                    CondResult(if (c.type == CondType.CHANGE_UP) ch >= c.a else ch <= -c.a, "variation ${if (ch >= 0) "+" else ""}${f(ch)} % sur $pb bougie${if (pb > 1) "s" else ""}")
                }
            }
            CondType.PRICE_ABOVE -> CondResult(last > c.a, "cours ${f(last)}")
            CondType.PRICE_BELOW -> CondResult(last < c.a, "cours ${f(last)}")
            CondType.SCORE_ABOVE, CondType.SCORE_BELOW -> {
                val r = Analyzer(candles).analyze(withBacktest = false, extra = listOfNotNull(news?.let { NewsText.factor(it) }) + context)
                if (r == null) unknown()
                else if (c.type == CondType.SCORE_ABOVE) CondResult(r.score >= c.a, "score ${f(r.score, 0)} (${r.verdict.lowercase()})")
                else CondResult(r.score <= -abs(c.a), "score ${f(r.score, 0)} (${r.verdict.lowercase()})")
            }
            CondType.NEWS_POSITIVE, CondType.NEWS_NEGATIVE -> {
                if (news == null || news.items.isEmpty()) CondResult(false, "aucune actualité trouvée", news != null)
                else {
                    val pct = news.score * 100
                    val d = "ton ${if (pct >= 0) "+" else ""}${f(pct, 0)} % sur ${news.items.size} articles"
                    CondResult(if (c.type == CondType.NEWS_POSITIVE) pct >= c.a else pct <= -abs(c.a), d)
                }
            }
            CondType.FIB_SUPPORT, CondType.FIB_RESIST -> {
                val fx = Analyzer(candles).factorsAt(n - 1).firstOrNull { it.name == "Fibonacci" }
                if (fx == null) unknown()
                else CondResult(if (c.type == CondType.FIB_SUPPORT) fx.value >= 0.5 else fx.value <= -0.5, fx.detail)
            }
            CondType.VOLUME_SPIKE -> {
                val vol = candles.map { it.v }
                if (n <= pb) unknown()
                else {
                    val avg = vol.subList(n - 1 - pb, n - 1).average()
                    val v = vol[i]
                    if (avg <= 0.0) CondResult(false, "volume inconnu", false)
                    else CondResult(v >= avg * c.a, "volume ${f(v / avg, 1)} × la moyenne")
                }
            }
        }
    }

    /** La règle est-elle remplie ? Avec le détail de chaque condition. */
    fun evaluate(rule: Rule, candles: List<Candle>, news: NewsTone? = null, context: List<Factor> = emptyList()): Pair<Boolean, List<CondResult>> {
        val res = rule.conditions.map { evaluate(it, candles, news, context) }
        if (res.isEmpty()) return false to res
        val ok = if (rule.all) res.all { it.ok } else res.any { it.ok }
        return ok to res
    }

    /** La règle a-t-elle besoin des actualités (analyse complète ou condition sur l'actualité) ? */
    fun needsNews(rule: Rule) = rule.conditions.any {
        it.type == CondType.SCORE_ABOVE || it.type == CondType.SCORE_BELOW || it.type == CondType.NEWS_POSITIVE || it.type == CondType.NEWS_NEGATIVE
    }

    /** Description courte d'une condition, avec ses réglages. */
    fun describe(c: Condition): String {
        fun v(x: Double) = if (x == kotlin.math.floor(x)) x.toLong().toString() else f(x)
        return when (c.type) {
            CondType.RSI_BELOW -> "RSI ${v(c.b)} < ${v(c.a)}"
            CondType.RSI_ABOVE -> "RSI ${v(c.b)} > ${v(c.a)}"
            CondType.PRICE_ABOVE_SMA -> "Cours > MM ${v(c.a)}"
            CondType.PRICE_BELOW_SMA -> "Cours < MM ${v(c.a)}"
            CondType.PRICE_CROSS_UP_SMA -> "Cours croise MM ${v(c.a)} ↑"
            CondType.PRICE_CROSS_DOWN_SMA -> "Cours croise MM ${v(c.a)} ↓"
            CondType.SMA_CROSS_UP -> "MM ${v(c.a)} croise MM ${v(c.b)} ↑"
            CondType.SMA_CROSS_DOWN -> "MM ${v(c.a)} croise MM ${v(c.b)} ↓"
            CondType.EMA_CROSS_UP -> "MME ${v(c.a)} croise MME ${v(c.b)} ↑"
            CondType.EMA_CROSS_DOWN -> "MME ${v(c.a)} croise MME ${v(c.b)} ↓"
            CondType.MACD_CROSS_UP -> "MACD croise signal ↑"
            CondType.MACD_CROSS_DOWN -> "MACD croise signal ↓"
            CondType.BOLL_BELOW -> "Cours < Bollinger basse (${v(c.a)}, ${v(c.b)})"
            CondType.BOLL_ABOVE -> "Cours > Bollinger haute (${v(c.a)}, ${v(c.b)})"
            CondType.STOCH_BELOW -> "Stochastique ${v(c.b)} < ${v(c.a)}"
            CondType.STOCH_ABOVE -> "Stochastique ${v(c.b)} > ${v(c.a)}"
            CondType.BREAKOUT_HIGH -> "Plus haut sur ${v(c.a)} bougies"
            CondType.BREAKDOWN_LOW -> "Plus bas sur ${v(c.a)} bougies"
            CondType.CHANGE_UP -> "Hausse ≥ ${v(c.a)} % sur ${v(c.b)}"
            CondType.CHANGE_DOWN -> "Baisse ≥ ${v(c.a)} % sur ${v(c.b)}"
            CondType.PRICE_ABOVE -> "Cours > ${v(c.a)}"
            CondType.PRICE_BELOW -> "Cours < ${v(c.a)}"
            CondType.VOLUME_SPIKE -> "Volume ≥ ${v(c.a)} × moyenne ${v(c.b)}"
            CondType.SCORE_ABOVE -> "Score d'analyse ≥ ${v(c.a)}"
            CondType.SCORE_BELOW -> "Score d'analyse ≤ −${v(abs(c.a))}"
            CondType.FIB_SUPPORT -> "Repli sur Fibonacci (achat)"
            CondType.FIB_RESIST -> "Rebond sous Fibonacci (vente)"
            CondType.NEWS_POSITIVE -> "Actualités ≥ +${v(c.a)} %"
            CondType.NEWS_NEGATIVE -> "Actualités ≤ −${v(abs(c.a))} %"
        }
    }

    /** Modèles prêts à l'emploi, pour démarrer. */
    fun templates(): List<Pair<String, Rule>> = listOf(
        // Styles de trading : durée des bougies, stop et objectif adaptés
        "Scalping (bougies de 5 min) : achat" to Rule("", "Scalping – achat", emptyList(), Timeframe.M5, Action.BUY, true,
            listOf(Condition(CondType.EMA_CROSS_UP, 9.0, 21.0), Condition(CondType.PRICE_ABOVE_SMA, 50.0), Condition(CondType.VOLUME_SPIKE, 1.3, 20.0)),
            smartExit = true, stopLoss = 0.4, takeProfit = 0.8),
        "Scalping : vente à découvert (CFD)" to Rule("", "Scalping – vente à découvert", emptyList(), Timeframe.M5, Action.SHORT, true,
            listOf(Condition(CondType.EMA_CROSS_DOWN, 9.0, 21.0), Condition(CondType.PRICE_BELOW_SMA, 50.0), Condition(CondType.VOLUME_SPIKE, 1.3, 20.0)),
            smartExit = true, stopLoss = 0.4, takeProfit = 0.8),
        "Day trading (bougies de 15 min) : achat" to Rule("", "Day trading – achat", emptyList(), Timeframe.M15, Action.BUY, true,
            listOf(Condition(CondType.SCORE_ABOVE, 45.0), Condition(CondType.PRICE_ABOVE_SMA, 50.0)),
            smartExit = true, stopLoss = 1.2, takeProfit = 2.5),
        "Day trading : vente à découvert (CFD)" to Rule("", "Day trading – vente à découvert", emptyList(), Timeframe.M15, Action.SHORT, true,
            listOf(Condition(CondType.SCORE_BELOW, 45.0), Condition(CondType.PRICE_BELOW_SMA, 50.0)), smartExit = true, stopLoss = 1.2, takeProfit = 2.5),
        "Swing trading (bougies de 4 h) : achat" to Rule("", "Swing – achat", emptyList(), Timeframe.H4, Action.BUY, true,
            listOf(Condition(CondType.SCORE_ABOVE, 50.0), Condition(CondType.RSI_BELOW, 60.0, 14.0)),
            smartExit = true, stopLoss = 4.0, takeProfit = 8.0),
        "Swing trading : vente à découvert (CFD)" to Rule("", "Swing – vente à découvert", emptyList(), Timeframe.H4, Action.SHORT, true,
            listOf(Condition(CondType.SCORE_BELOW, 50.0), Condition(CondType.RSI_ABOVE, 40.0, 14.0)), smartExit = true, stopLoss = 4.0, takeProfit = 8.0),
        "Robot complet : achat (toutes les analyses)" to Rule("", "Robot complet – achat", emptyList(), Timeframe.D1, Action.BUY, true,
            listOf(Condition(CondType.SCORE_ABOVE, 50.0)), smartExit = true),
        "Robot complet : vente à découvert (CFD)" to Rule("", "Robot complet – vente à découvert", emptyList(), Timeframe.D1, Action.SHORT, true,
            listOf(Condition(CondType.SCORE_BELOW, 50.0)), smartExit = true),
        "Rachat d'une vente à découvert (rebond)" to Rule("", "Rachat – rebond", emptyList(), Timeframe.D1, Action.COVER, false,
            listOf(Condition(CondType.RSI_BELOW, 30.0, 14.0), Condition(CondType.SCORE_ABOVE, 30.0))),
        "Robot complet : vente (toutes les analyses)" to Rule("", "Robot complet – vente", emptyList(), Timeframe.D1, Action.SELL, true,
            listOf(Condition(CondType.SCORE_BELOW, 50.0))),
        "Repli sur Fibonacci en tendance" to Rule("", "Repli Fibonacci", emptyList(), Timeframe.H4, Action.BUY, true,
            listOf(Condition(CondType.FIB_SUPPORT), Condition(CondType.RSI_BELOW, 50.0, 14.0)), smartExit = true),
        "Rebond de RSI" to Rule("", "Rebond de RSI", emptyList(), Timeframe.D1, Action.BUY, true,
            listOf(Condition(CondType.RSI_BELOW, 30.0, 14.0), Condition(CondType.PRICE_ABOVE_SMA, 200.0))),
        "Croisement doré (MM 50 / 200)" to Rule("", "Croisement doré", emptyList(), Timeframe.D1, Action.BUY, true,
            listOf(Condition(CondType.SMA_CROSS_UP, 50.0, 200.0))),
        "Croisement de la mort (vente)" to Rule("", "Croisement de la mort", emptyList(), Timeframe.D1, Action.SELL, true,
            listOf(Condition(CondType.SMA_CROSS_DOWN, 50.0, 200.0))),
        "MACD haussier" to Rule("", "MACD haussier", emptyList(), Timeframe.D1, Action.BUY, true,
            listOf(Condition(CondType.MACD_CROSS_UP), Condition(CondType.PRICE_ABOVE_SMA, 50.0))),
        "Cassure de plus haut" to Rule("", "Cassure", emptyList(), Timeframe.D1, Action.BUY, true,
            listOf(Condition(CondType.BREAKOUT_HIGH, 20.0), Condition(CondType.VOLUME_SPIKE, 1.5, 20.0))),
        "Suracheté (vente)" to Rule("", "Suracheté", emptyList(), Timeframe.D1, Action.SELL, false,
            listOf(Condition(CondType.RSI_ABOVE, 70.0, 14.0), Condition(CondType.BOLL_ABOVE, 20.0, 2.0))),
    )
}

// ------------------------------------------------------------------ Portefeuille de simulation

data class Position(
    val symbol: String,
    val name: String,
    val qty: Double,
    /** Prix moyen d'achat, dans la devise de l'instrument. */
    val avg: Double,
    val currency: String,
    /** Coût total en euros (pour le gain ou la perte). */
    val costEur: Double,
    val openedAt: Long,
    /** Prix de stop et d'objectif (0 = aucun), dans la devise de l'instrument. */
    val stop: Double = 0.0,
    val take: Double = 0.0,
    val ruleId: String = "",
    /** Vente à découvert : gagne quand le cours baisse ; stop au-dessus, objectif en dessous. */
    val short: Boolean = false,
) {
    /** Valeur en euros de la position au cours [priceEur] (cours en euros d'une unité). */
    fun valueEur(priceEur: Double): Double =
        if (short) (costEur + qty * (costEur / qty - priceEur)).coerceAtLeast(0.0) else qty * priceEur
}

data class Trade(
    val t: Long,
    val symbol: String,
    val name: String,
    val buy: Boolean,
    val qty: Double,
    val price: Double,
    val currency: String,
    val eur: Double,
    /** Gain ou perte réalisé en euros (ventes seulement). */
    val pnl: Double,
    val reason: String,
    /** Opération d'une vente à découvert (ouverture : vente ; fermeture : rachat). */
    val short: Boolean = false,
) {
    /** Opération qui ferme une position (vente d'un achat, rachat d'une vente à découvert). */
    val closes: Boolean get() = buy == short
}

data class Portfolio(
    val start: Double = 10_000.0,
    val cash: Double = 10_000.0,
    val positions: List<Position> = emptyList(),
    val trades: List<Trade> = emptyList(),
) {
    /** Achat simulé de [amountEur] euros. [fx] : valeur en euros d'une unité de la devise. Null si impossible. */
    fun buy(symbol: String, name: String, price: Double, currency: String, fx: Double, amountEur: Double,
            stopPct: Double, takePct: Double, reason: String, t: Long, ruleId: String = ""): Portfolio? {
        if (price <= 0 || fx <= 0 || amountEur <= 0) return null
        if (positions.any { it.symbol == symbol }) return null
        val spend = minOf(amountEur, cash)
        if (spend < 1.0) return null
        val qty = spend / (price * fx)
        val pos = Position(
            symbol, name, qty, price, currency, spend, t,
            stop = if (stopPct > 0) price * (1 - stopPct / 100) else 0.0,
            take = if (takePct > 0) price * (1 + takePct / 100) else 0.0,
            ruleId = ruleId,
        )
        val tr = Trade(t, symbol, name, true, qty, price, currency, spend, 0.0, reason)
        return copy(cash = cash - spend, positions = positions + pos, trades = (listOf(tr) + trades).take(500))
    }

    /**
     * Vente à découvert simulée de [amountEur] euros (la somme est bloquée comme garantie). Gain si le cours baisse.
     * Null si impossible (déjà une position sur l'instrument, pas assez de liquidités…).
     */
    fun short(symbol: String, name: String, price: Double, currency: String, fx: Double, amountEur: Double,
              stopPct: Double, takePct: Double, reason: String, t: Long, ruleId: String = ""): Portfolio? {
        if (price <= 0 || fx <= 0 || amountEur <= 0) return null
        if (positions.any { it.symbol == symbol }) return null
        val spend = minOf(amountEur, cash)
        if (spend < 1.0) return null
        val qty = spend / (price * fx)
        val pos = Position(
            symbol, name, qty, price, currency, spend, t,
            stop = if (stopPct > 0) price * (1 + stopPct / 100) else 0.0,
            take = if (takePct > 0) price * (1 - takePct / 100) else 0.0,
            ruleId = ruleId, short = true,
        )
        val tr = Trade(t, symbol, name, false, qty, price, currency, spend, 0.0, reason, short = true)
        return copy(cash = cash - spend, positions = positions + pos, trades = (listOf(tr) + trades).take(500))
    }

    /** Ferme toute la position (vente d'un achat ou rachat d'une vente à découvert). Null s'il n'y en a pas. */
    fun close(symbol: String, price: Double, fx: Double, reason: String, t: Long): Portfolio? {
        val pos = positions.firstOrNull { it.symbol == symbol } ?: return null
        if (price <= 0 || fx <= 0) return null
        val eur = pos.valueEur(price * fx)
        val tr = Trade(t, symbol, pos.name, pos.short, pos.qty, price, pos.currency, eur, eur - pos.costEur, reason, short = pos.short)
        return copy(cash = cash + eur, positions = positions - pos, trades = (listOf(tr) + trades).take(500))
    }

    /** Vente simulée d'une position achetée. Null s'il n'y en a pas. */
    fun sell(symbol: String, price: Double, fx: Double, reason: String, t: Long): Portfolio? =
        if (positions.any { it.symbol == symbol && !it.short }) close(symbol, price, fx, reason, t) else null

    /** Rachat simulé d'une vente à découvert. Null s'il n'y en a pas. */
    fun cover(symbol: String, price: Double, fx: Double, reason: String, t: Long): Portfolio? =
        if (positions.any { it.symbol == symbol && it.short }) close(symbol, price, fx, reason, t) else null

    /** Valeur totale en euros avec les cours donnés (symbole → cours en euros d'une unité). */
    fun value(pricesEur: Map<String, Double>): Double =
        cash + positions.sumOf { p -> p.valueEur(pricesEur[p.symbol] ?: (p.costEur / p.qty)) }

    val realized: Double get() = trades.filter { it.closes }.sumOf { it.pnl }
}
