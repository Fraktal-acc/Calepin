package fr.jeremy.calepin.market

import java.util.Locale

/** Durée de chaque bougie étudiée par le robot. [interval] et [range] : ce qu'on demande à Yahoo Finance. */
enum class Timeframe(val label: String, val interval: String, val range: String) {
    M15("15 minutes", "15m", "1mo"),
    H1("1 heure", "60m", "3mo"),
    D1("1 jour", "1d", "2y"),
    W1("1 semaine", "1wk", "10y"),
}

/** Ce que fait une règle quand ses conditions sont réunies. */
enum class Action(val label: String) {
    BUY("Acheter"),
    SELL("Vendre"),
    ALERT("Me prévenir seulement"),
}

/**
 * Types de conditions. [pa]/[pb] : nom des réglages (null = pas de réglage), [da]/[db] : valeurs par défaut.
 */
enum class CondType(val label: String, val pa: String?, val da: Double, val pb: String? = null, val db: Double = 0.0) {
    RSI_BELOW("RSI sous un seuil (survendu)", "Seuil", 30.0, "Période", 14.0),
    RSI_ABOVE("RSI au-dessus d'un seuil (suracheté)", "Seuil", 70.0, "Période", 14.0),
    PRICE_ABOVE_SMA("Cours au-dessus de la moyenne mobile", "Période", 50.0),
    PRICE_BELOW_SMA("Cours sous la moyenne mobile", "Période", 50.0),
    PRICE_CROSS_UP_SMA("Cours qui passe au-dessus de la moyenne mobile", "Période", 50.0),
    PRICE_CROSS_DOWN_SMA("Cours qui passe sous la moyenne mobile", "Période", 50.0),
    SMA_CROSS_UP("Moyenne courte qui croise la longue vers le haut", "Courte", 50.0, "Longue", 200.0),
    SMA_CROSS_DOWN("Moyenne courte qui croise la longue vers le bas", "Courte", 50.0, "Longue", 200.0),
    EMA_CROSS_UP("Moyenne exponentielle courte qui croise la longue vers le haut", "Courte", 12.0, "Longue", 26.0),
    EMA_CROSS_DOWN("Moyenne exponentielle courte qui croise la longue vers le bas", "Courte", 12.0, "Longue", 26.0),
    MACD_CROSS_UP("MACD qui croise son signal vers le haut", null, 0.0),
    MACD_CROSS_DOWN("MACD qui croise son signal vers le bas", null, 0.0),
    BOLL_BELOW("Cours sous la bande de Bollinger basse", "Période", 20.0, "Écarts", 2.0),
    BOLL_ABOVE("Cours au-dessus de la bande de Bollinger haute", "Période", 20.0, "Écarts", 2.0),
    STOCH_BELOW("Stochastique sous un seuil", "Seuil", 20.0, "Période", 14.0),
    STOCH_ABOVE("Stochastique au-dessus d'un seuil", "Seuil", 80.0, "Période", 14.0),
    BREAKOUT_HIGH("Cours au plus haut depuis N bougies", "Bougies", 20.0),
    BREAKDOWN_LOW("Cours au plus bas depuis N bougies", "Bougies", 20.0),
    CHANGE_UP("Hausse d'au moins X % sur N bougies", "%", 3.0, "Bougies", 1.0),
    CHANGE_DOWN("Baisse d'au moins X % sur N bougies", "%", 3.0, "Bougies", 1.0),
    PRICE_ABOVE("Cours au-dessus d'un prix", "Prix", 0.0),
    PRICE_BELOW("Cours sous un prix", "Prix", 0.0),
    VOLUME_SPIKE("Volume au moins X fois la moyenne", "Fois", 2.0, "Période", 20.0),
}

data class Condition(val type: CondType, val a: Double = type.da, val b: Double = type.db)

data class Rule(
    val id: String,
    val name: String,
    val symbols: List<String>,
    val timeframe: Timeframe = Timeframe.D1,
    val action: Action = Action.BUY,
    /** true : toutes les conditions (ET) ; false : une seule suffit (OU). */
    val all: Boolean = true,
    val conditions: List<Condition> = emptyList(),
    /** Achète ou vend dans le portefeuille de simulation (sinon : notification seulement). */
    val simulate: Boolean = true,
    /** Montant de chaque achat simulé, en euros. */
    val amount: Double = 1000.0,
    /** Stop de perte et objectif de gain en % (0 = aucun), pour les positions ouvertes par cette règle. */
    val stopLoss: Double = 5.0,
    val takeProfit: Double = 10.0,
    val enabled: Boolean = true,
)

/** Résultat d'une condition : vraie ou non, et ce qui a été mesuré (pour l'expliquer). */
data class CondResult(val ok: Boolean, val detail: String, val known: Boolean = true)

object Strategy {
    private fun f(x: Double, d: Int = 2) = String.format(Locale.FRANCE, "%.${d}f", x)

    /** Évalue une condition sur la dernière bougie (la bougie en cours compte, avec le dernier cours). */
    fun evaluate(c: Condition, candles: List<Candle>): CondResult {
        val n = candles.size
        if (n < 3) return CondResult(false, "pas assez de données", false)
        val close = candles.map { it.c }
        val last = close[n - 1]
        val i = n - 1
        fun unknown() = CondResult(false, "pas assez d'historique", false)
        fun crossUp(a: List<Double>, b: List<Double>): Boolean? {
            if (a[i].isNaN() || b[i].isNaN() || a[i - 1].isNaN() || b[i - 1].isNaN()) return null
            return a[i - 1] <= b[i - 1] && a[i] > b[i]
        }
        fun crossDown(a: List<Double>, b: List<Double>): Boolean? {
            if (a[i].isNaN() || b[i].isNaN() || a[i - 1].isNaN() || b[i - 1].isNaN()) return null
            return a[i - 1] >= b[i - 1] && a[i] < b[i]
        }
        val pa = c.a.toInt().coerceAtLeast(1)
        val pb = c.b.toInt().coerceAtLeast(1)
        return when (c.type) {
            CondType.RSI_BELOW, CondType.RSI_ABOVE -> {
                val r = Indicators.rsi(close, pb)[i]
                if (r.isNaN()) unknown()
                else CondResult(if (c.type == CondType.RSI_BELOW) r < c.a else r > c.a, "RSI $pb = ${f(r, 1)}")
            }
            CondType.PRICE_ABOVE_SMA, CondType.PRICE_BELOW_SMA -> {
                val m = Indicators.sma(close, pa)[i]
                if (m.isNaN()) unknown()
                else CondResult(if (c.type == CondType.PRICE_ABOVE_SMA) last > m else last < m, "cours ${f(last)} · moyenne $pa = ${f(m)}")
            }
            CondType.PRICE_CROSS_UP_SMA, CondType.PRICE_CROSS_DOWN_SMA -> {
                val m = Indicators.sma(close, pa)
                val x = if (c.type == CondType.PRICE_CROSS_UP_SMA) crossUp(close, m) else crossDown(close, m)
                if (x == null) unknown() else CondResult(x, "cours ${f(last)} · moyenne $pa = ${f(m[i])}")
            }
            CondType.SMA_CROSS_UP, CondType.SMA_CROSS_DOWN, CondType.EMA_CROSS_UP, CondType.EMA_CROSS_DOWN -> {
                val ema = c.type == CondType.EMA_CROSS_UP || c.type == CondType.EMA_CROSS_DOWN
                val fa = if (ema) Indicators.ema(close, pa) else Indicators.sma(close, pa)
                val sl = if (ema) Indicators.ema(close, pb) else Indicators.sma(close, pb)
                val up = c.type == CondType.SMA_CROSS_UP || c.type == CondType.EMA_CROSS_UP
                val x = if (up) crossUp(fa, sl) else crossDown(fa, sl)
                val kind = if (ema) "MME" else "MM"
                if (x == null) unknown() else CondResult(x, "$kind $pa = ${f(fa[i])} · $kind $pb = ${f(sl[i])}")
            }
            CondType.MACD_CROSS_UP, CondType.MACD_CROSS_DOWN -> {
                val (line, sig, _) = Indicators.macd(close)
                val x = if (c.type == CondType.MACD_CROSS_UP) crossUp(line, sig) else crossDown(line, sig)
                if (x == null) unknown() else CondResult(x, "MACD ${f(line[i], 3)} · signal ${f(sig[i], 3)}")
            }
            CondType.BOLL_BELOW, CondType.BOLL_ABOVE -> {
                val (lo, _, hi) = Indicators.bollinger(close, pa, c.b.takeIf { it > 0 } ?: 2.0)
                if (lo[i].isNaN()) unknown()
                else if (c.type == CondType.BOLL_BELOW) CondResult(last < lo[i], "cours ${f(last)} · bande basse ${f(lo[i])}")
                else CondResult(last > hi[i], "cours ${f(last)} · bande haute ${f(hi[i])}")
            }
            CondType.STOCH_BELOW, CondType.STOCH_ABOVE -> {
                val s = Indicators.stochastic(candles, pb)[i]
                if (s.isNaN()) unknown()
                else CondResult(if (c.type == CondType.STOCH_BELOW) s < c.a else s > c.a, "stochastique ${f(s, 1)}")
            }
            CondType.BREAKOUT_HIGH, CondType.BREAKDOWN_LOW -> {
                if (n <= pa) unknown()
                else {
                    val prev = candles.subList(n - 1 - pa, n - 1)
                    if (c.type == CondType.BREAKOUT_HIGH) {
                        val hh = prev.maxOf { it.h }
                        CondResult(last > hh, "cours ${f(last)} · plus haut de $pa bougies ${f(hh)}")
                    } else {
                        val ll = prev.minOf { it.l }
                        CondResult(last < ll, "cours ${f(last)} · plus bas de $pa bougies ${f(ll)}")
                    }
                }
            }
            CondType.CHANGE_UP, CondType.CHANGE_DOWN -> {
                if (n <= pb) unknown()
                else {
                    val ref = close[n - 1 - pb]
                    val ch = if (ref == 0.0) 0.0 else (last - ref) / ref * 100
                    CondResult(if (c.type == CondType.CHANGE_UP) ch >= c.a else ch <= -c.a, "variation ${if (ch >= 0) "+" else ""}${f(ch)} % sur $pb bougie${if (pb > 1) "s" else ""}")
                }
            }
            CondType.PRICE_ABOVE -> CondResult(last > c.a, "cours ${f(last)}")
            CondType.PRICE_BELOW -> CondResult(last < c.a, "cours ${f(last)}")
            CondType.VOLUME_SPIKE -> {
                val vol = candles.map { it.v }
                if (n <= pb) unknown()
                else {
                    val avg = vol.subList(n - 1 - pb, n - 1).average()
                    val v = vol[i]
                    if (avg <= 0.0) CondResult(false, "volume inconnu", false)
                    else CondResult(v >= avg * c.a, "volume ${f(v / avg, 1)} × la moyenne")
                }
            }
        }
    }

    /** La règle est-elle remplie ? Avec le détail de chaque condition. */
    fun evaluate(rule: Rule, candles: List<Candle>): Pair<Boolean, List<CondResult>> {
        val res = rule.conditions.map { evaluate(it, candles) }
        if (res.isEmpty()) return false to res
        val ok = if (rule.all) res.all { it.ok } else res.any { it.ok }
        return ok to res
    }

    /** Description courte d'une condition, avec ses réglages. */
    fun describe(c: Condition): String {
        fun v(x: Double) = if (x == kotlin.math.floor(x)) x.toLong().toString() else f(x)
        return when (c.type) {
            CondType.RSI_BELOW -> "RSI ${v(c.b)} < ${v(c.a)}"
            CondType.RSI_ABOVE -> "RSI ${v(c.b)} > ${v(c.a)}"
            CondType.PRICE_ABOVE_SMA -> "Cours > MM ${v(c.a)}"
            CondType.PRICE_BELOW_SMA -> "Cours < MM ${v(c.a)}"
            CondType.PRICE_CROSS_UP_SMA -> "Cours croise MM ${v(c.a)} ↑"
            CondType.PRICE_CROSS_DOWN_SMA -> "Cours croise MM ${v(c.a)} ↓"
            CondType.SMA_CROSS_UP -> "MM ${v(c.a)} croise MM ${v(c.b)} ↑"
            CondType.SMA_CROSS_DOWN -> "MM ${v(c.a)} croise MM ${v(c.b)} ↓"
            CondType.EMA_CROSS_UP -> "MME ${v(c.a)} croise MME ${v(c.b)} ↑"
            CondType.EMA_CROSS_DOWN -> "MME ${v(c.a)} croise MME ${v(c.b)} ↓"
            CondType.MACD_CROSS_UP -> "MACD croise signal ↑"
            CondType.MACD_CROSS_DOWN -> "MACD croise signal ↓"
            CondType.BOLL_BELOW -> "Cours < Bollinger basse (${v(c.a)}, ${v(c.b)})"
            CondType.BOLL_ABOVE -> "Cours > Bollinger haute (${v(c.a)}, ${v(c.b)})"
            CondType.STOCH_BELOW -> "Stochastique ${v(c.b)} < ${v(c.a)}"
            CondType.STOCH_ABOVE -> "Stochastique ${v(c.b)} > ${v(c.a)}"
            CondType.BREAKOUT_HIGH -> "Plus haut sur ${v(c.a)} bougies"
            CondType.BREAKDOWN_LOW -> "Plus bas sur ${v(c.a)} bougies"
            CondType.CHANGE_UP -> "Hausse ≥ ${v(c.a)} % sur ${v(c.b)}"
            CondType.CHANGE_DOWN -> "Baisse ≥ ${v(c.a)} % sur ${v(c.b)}"
            CondType.PRICE_ABOVE -> "Cours > ${v(c.a)}"
            CondType.PRICE_BELOW -> "Cours < ${v(c.a)}"
            CondType.VOLUME_SPIKE -> "Volume ≥ ${v(c.a)} × moyenne ${v(c.b)}"
        }
    }

    /** Modèles prêts à l'emploi, pour démarrer. */
    fun templates(): List<Pair<String, Rule>> = listOf(
        "Rebond de RSI" to Rule("", "Rebond de RSI", emptyList(), Timeframe.D1, Action.BUY, true,
            listOf(Condition(CondType.RSI_BELOW, 30.0, 14.0), Condition(CondType.PRICE_ABOVE_SMA, 200.0))),
        "Croisement doré (MM 50 / 200)" to Rule("", "Croisement doré", emptyList(), Timeframe.D1, Action.BUY, true,
            listOf(Condition(CondType.SMA_CROSS_UP, 50.0, 200.0))),
        "Croisement de la mort (vente)" to Rule("", "Croisement de la mort", emptyList(), Timeframe.D1, Action.SELL, true,
            listOf(Condition(CondType.SMA_CROSS_DOWN, 50.0, 200.0))),
        "MACD haussier" to Rule("", "MACD haussier", emptyList(), Timeframe.D1, Action.BUY, true,
            listOf(Condition(CondType.MACD_CROSS_UP), Condition(CondType.PRICE_ABOVE_SMA, 50.0))),
        "Cassure de plus haut" to Rule("", "Cassure", emptyList(), Timeframe.D1, Action.BUY, true,
            listOf(Condition(CondType.BREAKOUT_HIGH, 20.0), Condition(CondType.VOLUME_SPIKE, 1.5, 20.0))),
        "Suracheté (vente)" to Rule("", "Suracheté", emptyList(), Timeframe.D1, Action.SELL, false,
            listOf(Condition(CondType.RSI_ABOVE, 70.0, 14.0), Condition(CondType.BOLL_ABOVE, 20.0, 2.0))),
    )
}

// ------------------------------------------------------------------ Portefeuille de simulation

data class Position(
    val symbol: String,
    val name: String,
    val qty: Double,
    /** Prix moyen d'achat, dans la devise de l'instrument. */
    val avg: Double,
    val currency: String,
    /** Coût total en euros (pour le gain ou la perte). */
    val costEur: Double,
    val openedAt: Long,
    /** Prix de stop et d'objectif (0 = aucun), dans la devise de l'instrument. */
    val stop: Double = 0.0,
    val take: Double = 0.0,
    val ruleId: String = "",
)

data class Trade(
    val t: Long,
    val symbol: String,
    val name: String,
    val buy: Boolean,
    val qty: Double,
    val price: Double,
    val currency: String,
    val eur: Double,
    /** Gain ou perte réalisé en euros (ventes seulement). */
    val pnl: Double,
    val reason: String,
)

data class Portfolio(
    val start: Double = 10_000.0,
    val cash: Double = 10_000.0,
    val positions: List<Position> = emptyList(),
    val trades: List<Trade> = emptyList(),
) {
    /** Achat simulé de [amountEur] euros. [fx] : valeur en euros d'une unité de la devise. Null si impossible. */
    fun buy(symbol: String, name: String, price: Double, currency: String, fx: Double, amountEur: Double,
            stopPct: Double, takePct: Double, reason: String, t: Long, ruleId: String = ""): Portfolio? {
        if (price <= 0 || fx <= 0 || amountEur <= 0) return null
        if (positions.any { it.symbol == symbol }) return null
        val spend = minOf(amountEur, cash)
        if (spend < 1.0) return null
        val qty = spend / (price * fx)
        val pos = Position(
            symbol, name, qty, price, currency, spend, t,
            stop = if (stopPct > 0) price * (1 - stopPct / 100) else 0.0,
            take = if (takePct > 0) price * (1 + takePct / 100) else 0.0,
            ruleId = ruleId,
        )
        val tr = Trade(t, symbol, name, true, qty, price, currency, spend, 0.0, reason)
        return copy(cash = cash - spend, positions = positions + pos, trades = (listOf(tr) + trades).take(500))
    }

    /** Vente simulée de toute la position. Null s'il n'y en a pas. */
    fun sell(symbol: String, price: Double, fx: Double, reason: String, t: Long): Portfolio? {
        val pos = positions.firstOrNull { it.symbol == symbol } ?: return null
        if (price <= 0 || fx <= 0) return null
        val eur = pos.qty * price * fx
        val tr = Trade(t, symbol, pos.name, false, pos.qty, price, pos.currency, eur, eur - pos.costEur, reason)
        return copy(cash = cash + eur, positions = positions - pos, trades = (listOf(tr) + trades).take(500))
    }

    /** Valeur totale en euros avec les cours donnés (symbole → cours en euros d'une unité). */
    fun value(pricesEur: Map<String, Double>): Double =
        cash + positions.sumOf { p -> p.qty * (pricesEur[p.symbol] ?: (p.costEur / p.qty)) }

    val realized: Double get() = trades.filter { !it.buy }.sumOf { it.pnl }
}
