package fr.jeremy.calepin.ui

import android.content.Context
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BusinessCenter
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Contacts
import androidx.compose.material.icons.filled.EditNote
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Forum
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Radio
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Badge
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import fr.jeremy.calepin.NotesViewModel
import fr.jeremy.calepin.contacts.PhoneContact
import fr.jeremy.calepin.contacts.PhoneContacts
import fr.jeremy.calepin.data.Event
import fr.jeremy.calepin.data.Note
import fr.jeremy.calepin.i18n.I18n
import fr.jeremy.calepin.i18n.RawText
import fr.jeremy.calepin.i18n.Text
import fr.jeremy.calepin.pro.ProStore
import fr.jeremy.calepin.radio.RadioApi
import fr.jeremy.calepin.radio.RadioPlayer
import fr.jeremy.calepin.radio.RadioPrefs
import fr.jeremy.calepin.radio.Station
import fr.jeremy.calepin.search.TextNorm
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date

/** Où chercher depuis l'accueil. */
enum class SearchScope(val label: String, val icon: ImageVector) {
    NOTES("Notes", Icons.Filled.EditNote),
    AGENDA("Agenda", Icons.Filled.CalendarMonth),
    CONTACTS("Contacts", Icons.Filled.Contacts),
    PRO("Pro", Icons.Filled.BusinessCenter),
    RADIOS("Radios", Icons.Filled.Radio),
    CONVERSATIONS("Conversations", Icons.Filled.Forum),
    MAILS("Mails", Icons.Filled.Email),
}

/** Choix des endroits où chercher, gardé sur le téléphone. */
object SearchScopes {
    private fun p(ctx: Context) = ctx.applicationContext.getSharedPreferences("calepin_search", Context.MODE_PRIVATE)

    /** Les endroits ajoutés dans une nouvelle version sont cochés d'office. */
    fun load(ctx: Context): Set<SearchScope> {
        val saved = p(ctx).getString("scopes", null)?.split(',')?.mapNotNull { n -> SearchScope.entries.firstOrNull { it.name == n } }?.toSet()
            ?: return SearchScope.entries.toSet()
        val known = p(ctx).getString("known", null)?.split(',')?.toSet()
            ?: setOf("NOTES", "AGENDA", "CONTACTS", "PRO", "RADIOS")
        return saved + SearchScope.entries.filter { it.name !in known }
    }

    fun save(ctx: Context, s: Set<SearchScope>) {
        p(ctx).edit().putString("scopes", s.joinToString(",") { it.name }).putString("known", SearchScope.entries.joinToString(",") { it.name }).apply()
    }
}

/** Ce qu'on ouvre depuis un résultat. */
class SearchActions(
    val onNote: (Long) -> Unit,
    val onAllNotes: (String) -> Unit,
    val onEvent: (Event) -> Unit,
    val onContact: (Long) -> Unit,
    val onContacts: () -> Unit,
    val onClient: (String) -> Unit,
    val onRadios: () -> Unit,
    /** Conversation WhatsApp / Telegram ouverte sur un message (clé, heure du message ; -1 = sans message précis). */
    val onConversation: (String, Long) -> Unit = { _, _ -> },
    /** Mail d'une de mes adresses (boîte de réception ou envoyés). */
    val onMail: (fr.jeremy.calepin.mail.MailHeader) -> Unit = {},
    val onMessages: () -> Unit = {},
)

/**
 * Barre de recherche de l'accueil : le bouton à droite choisit où chercher
 * (notes, agenda, contacts, pro, radios) en cochant ou décochant.
 */
@Composable
fun HomeSearchBar(query: String, onQuery: (String) -> Unit, scopes: Set<SearchScope>, onScopes: (Set<SearchScope>) -> Unit, onSubmit: () -> Unit) {
    var menu by remember { mutableStateOf(false) }
    val cs = MaterialTheme.colorScheme
    OutlinedTextField(
        value = query,
        onValueChange = onQuery,
        modifier = Modifier.fillMaxWidth(),
        placeholder = {
            Text(
                if (scopes.size == SearchScope.entries.size) "Rechercher partout"
                else I18n.tr("Rechercher dans :") + " " + SearchScope.entries.filter { it in scopes }.joinToString(", ") { I18n.tr(it.label).lowercase() },
                maxLines = 1,
            )
        },
        leadingIcon = { Icon(Icons.Filled.Search, null) },
        trailingIcon = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (query.isNotEmpty()) IconButton(onClick = { onQuery("") }) { Icon(Icons.Filled.Close, "Effacer") }
                Box {
                    IconButton(onClick = { menu = true }) {
                        Box {
                            Icon(Icons.Filled.Tune, "Où chercher", tint = if (scopes.size < SearchScope.entries.size) cs.primary else cs.onSurfaceVariant)
                            if (scopes.size < SearchScope.entries.size) {
                                Badge(Modifier.align(Alignment.TopEnd)) { RawText("${scopes.size}") }
                            }
                        }
                    }
                    DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                        Text(
                            "Chercher dans",
                            style = MaterialTheme.typography.labelLarge, color = cs.primary,
                            modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp),
                        )
                        SearchScope.entries.forEach { s ->
                            val on = s in scopes
                            DropdownMenuItem(
                                text = { Text(s.label) },
                                leadingIcon = { Icon(s.icon, null, tint = if (on) cs.primary else cs.onSurfaceVariant) },
                                trailingIcon = {
                                    Checkbox(checked = on, onCheckedChange = { c ->
                                        val next = if (c) scopes + s else scopes - s
                                        if (next.isNotEmpty()) onScopes(next)
                                    })
                                },
                                // Le menu reste ouvert pour cocher plusieurs cases ; au moins un endroit reste coché
                                onClick = {
                                    val next = if (on) scopes - s else scopes + s
                                    if (next.isNotEmpty()) onScopes(next)
                                },
                            )
                        }
                        HorizontalDivider()
                        DropdownMenuItem(
                            text = { Text("Tout cocher") },
                            onClick = { onScopes(SearchScope.entries.toSet()); menu = false },
                        )
                    }
                }
            }
        },
        singleLine = true,
        shape = MaterialTheme.shapes.extraLarge,
        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
        keyboardActions = KeyboardActions(onSearch = { onSubmit() }),
    )
}

/** Mots de la recherche, sans accents ni majuscules : tous doivent être présents. */
private fun words(q: String) = TextNorm.norm(q).split(Regex("\\s+")).filter { it.isNotEmpty() }
private fun matches(text: String, w: List<String>): Boolean { val t = TextNorm.norm(text); return w.all { t.contains(it) } }

/** Résultats de la recherche de l'accueil, rangés par endroit. */
@Composable
fun GlobalSearchResults(vm: NotesViewModel, query: String, scopes: Set<SearchScope>, a: SearchActions) {
    val ctx = LocalContext.current
    val q = query.trim()
    val w = remember(q) { words(q) }
    val events by vm.events.collectAsStateWithLifecycle()
    val store = remember { ProStore.get(ctx) }
    val clients by store.clients.collectAsStateWithLifecycle()
    val interventions by store.interventions.collectAsStateWithLifecycle()
    var contacts by remember { mutableStateOf<List<PhoneContact>?>(null) }
    val contactsAllowed = remember { PhoneContacts.hasPermission(ctx) }
    var radios by remember { mutableStateOf<List<Station>>(emptyList()) }
    var radioLoading by remember { mutableStateOf(false) }
    val playing by RadioPlayer.current.collectAsStateWithLifecycle()

    LaunchedEffect(SearchScope.CONTACTS in scopes) {
        if (SearchScope.CONTACTS in scopes && contacts == null && contactsAllowed) {
            contacts = withContext(Dispatchers.IO) { runCatching { PhoneContacts.load(ctx) }.getOrDefault(emptyList()) }
        }
    }
    // Radios : d'abord les favorites, puis l'annuaire en ligne (après une courte pause de frappe)
    LaunchedEffect(q, SearchScope.RADIOS in scopes) {
        radios = emptyList()
        if (SearchScope.RADIOS !in scopes || q.length < 2) return@LaunchedEffect
        val favs = RadioPrefs.favorites(ctx).filter { matches(it.name + " " + it.tags + " " + it.country, w) }
        radios = favs
        delay(500)
        radioLoading = true
        val online = runCatching { RadioApi.search(q, limit = 12) }.getOrDefault(emptyList())
        radios = (favs + online).distinctBy { it.uuid }.take(8)
        radioLoading = false
    }

    // Rubriques protégées par code et pas encore ouvertes : rien n'apparaît dans la recherche
    fr.jeremy.calepin.SectionLock.unlocked.collectAsStateWithLifecycle().value
    // Messages : conversations suivies et mails (le menu peut être protégé par code)
    val messagesLocked = fr.jeremy.calepin.SectionLock.needs(fr.jeremy.calepin.SectionLock.MESSAGES)
    remember { fr.jeremy.calepin.control.MessageHub.init(ctx); fr.jeremy.calepin.mail.MailAccounts.init(ctx) }
    val convs by fr.jeremy.calepin.control.MessageHub.convs.collectAsStateWithLifecycle()
    val convMsgs by fr.jeremy.calepin.control.MessageHub.messages.collectAsStateWithLifecycle()
    val notifMails by fr.jeremy.calepin.control.MessageHub.mails.collectAsStateWithLifecycle()
    val inboxes by fr.jeremy.calepin.mail.MailClient.inbox.collectAsStateWithLifecycle()
    val accounts by fr.jeremy.calepin.mail.MailAccounts.accounts.collectAsStateWithLifecycle()
    var serverMails by remember { mutableStateOf<List<fr.jeremy.calepin.mail.MailHeader>>(emptyList()) }
    var mailLoading by remember { mutableStateOf(false) }
    // Recherche dans mes boîtes mail (sur les serveurs), après une courte pause de frappe
    LaunchedEffect(q, SearchScope.MAILS in scopes, accounts) {
        serverMails = emptyList()
        if (SearchScope.MAILS !in scopes || q.length < 3 || accounts.isEmpty() || messagesLocked) return@LaunchedEffect
        delay(700)
        mailLoading = true
        val found = mutableListOf<fr.jeremy.calepin.mail.MailHeader>()
        accounts.forEach { acc -> runCatching { fr.jeremy.calepin.mail.MailClient.search(ctx, acc, q, max = 15) }.onSuccess { found += it } }
        serverMails = found
        mailLoading = false
    }

    if (q.length < 2) return
    val convHits: List<Pair<fr.jeremy.calepin.control.Conv, fr.jeremy.calepin.control.Msg?>> =
        if (SearchScope.CONVERSATIONS in scopes && !messagesLocked) remember(q, convs, convMsgs) {
            convs.filter { matches(it.name, w) }.map { it to null } +
                convs.flatMap { c -> convMsgs[c.key].orEmpty().filter { m -> matches(m.text + " " + m.from, w) }.map { c to it } }
                    .sortedByDescending { it.second?.time ?: 0L }
        } else emptyList()
    // Mails : d'abord ceux déjà chargés (instantané), puis ceux trouvés sur les serveurs
    val mailHits: List<fr.jeremy.calepin.mail.MailHeader> =
        if (SearchScope.MAILS in scopes && !messagesLocked) remember(q, inboxes, serverMails) {
            (inboxes.values.flatten().filter { matches(it.from + " " + it.fromAddr + " " + it.subject, w) } + serverMails)
                .distinctBy { it.accountId + "|" + it.folder + "|" + it.uid }
                .sortedByDescending { it.date }
        } else emptyList()
    val notifMailHits = if (SearchScope.MAILS in scopes && !messagesLocked) notifMails.filter { matches(it.from + " " + it.subject + " " + it.body, w) } else emptyList()
    val notes: List<Note> = if (SearchScope.NOTES in scopes) {
        vm.allNotes().filter { !fr.jeremy.calepin.SectionLock.noteHidden(it.id) }.filter { matches(it.title + " " + it.content + " " + it.tag + " " + it.folder, w) }
            .sortedWith(compareByDescending<Note> { matches(it.title, w) }.thenByDescending { it.updatedAt })
    } else emptyList()
    val now = System.currentTimeMillis()
    val evs: List<Event> = if (SearchScope.AGENDA in scopes) remember(q, events) {
        events.filter { matches(it.title, w) }
            // Les prochains d'abord, puis les passés du plus récent au plus ancien
            .sortedWith(compareBy<Event> { if (it.start >= now) 0 else 1 }.thenBy { if (it.start >= now) it.start else -it.start })
    } else emptyList()
    val cts: List<PhoneContact> = if (SearchScope.CONTACTS in scopes && !fr.jeremy.calepin.SectionLock.needs(fr.jeremy.calepin.SectionLock.CONTACTS)) remember(q, contacts) {
        val digits = q.filter { it.isDigit() }
        contacts.orEmpty().filter { c ->
            w.all { c.searchText.contains(it) } || (digits.length >= 3 && c.phoneDigits.any { it.contains(digits) })
        }
    } else emptyList()
    val pro: List<Triple<String, String, String>> = if (SearchScope.PRO in scopes && !fr.jeremy.calepin.SectionLock.needs(fr.jeremy.calepin.SectionLock.PRO)) remember(q, clients, interventions) {
        val byId = clients.associateBy { it.id }
        clients.filter { matches(listOf(it.name, it.kind, it.address, it.phone, it.email, it.notes).joinToString(" "), w) }
            .map { Triple(it.id, it.name, listOf(it.kind, it.address).filter { s -> s.isNotBlank() }.joinToString(" · ")) } +
            interventions.filter { matches(it.title + " " + it.notes + " " + it.checklist, w) }.sortedByDescending { it.date }.map { iv ->
                Triple(iv.clientId, iv.title, listOfNotNull(byId[iv.clientId]?.name, dateText(iv.date, false)).joinToString(" · "))
            }
    } else emptyList()

    val nothing = notes.isEmpty() && evs.isEmpty() && cts.isEmpty() && pro.isEmpty() && radios.isEmpty() && !radioLoading &&
        convHits.isEmpty() && mailHits.isEmpty() && notifMailHits.isEmpty() && !mailLoading &&
        !(SearchScope.CONTACTS in scopes && !contactsAllowed)
    if (nothing) {
        Text(I18n.trf("Aucun résultat pour « {0} »", q), style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        return
    }

    if (notes.isNotEmpty()) ResultSection(SearchScope.NOTES, notes.size) {
        notes.take(5).forEach { n ->
            ResultRow(n.title.ifBlank { I18n.tr("Sans titre") }, snippet(n.content, w), SearchScope.NOTES.icon) { a.onNote(n.id) }
        }
        TextButton(onClick = { a.onAllNotes(q) }) { Text(I18n.trf("Voir les {0} notes avec la recherche avancée", notes.size)) }
    }
    if (evs.isNotEmpty()) ResultSection(SearchScope.AGENDA, evs.size) {
        evs.take(6).forEach { e -> ResultRow(e.title, dateText(e.start, !e.allDay), SearchScope.AGENDA.icon) { a.onEvent(e) } }
    }
    if (SearchScope.CONTACTS in scopes) {
        if (!contactsAllowed) {
            ResultSection(SearchScope.CONTACTS, 0) {
                TextButton(onClick = a.onContacts) { Text("Autoriser l'accès aux contacts") }
            }
        } else if (cts.isNotEmpty()) ResultSection(SearchScope.CONTACTS, cts.size) {
            cts.take(5).forEach { c ->
                ResultRow(
                    c.name,
                    listOfNotNull(c.phones.firstOrNull()?.value, c.organization).joinToString(" · "),
                    SearchScope.CONTACTS.icon,
                    trailingIcon = if (c.phones.isNotEmpty()) Icons.Filled.Call else null,
                    onTrailing = { c.phones.firstOrNull()?.let { p -> fr.jeremy.calepin.Actions.dial(ctx, p.value) } },
                ) { a.onContact(c.id) }
            }
        }
    }
    if (convHits.isNotEmpty()) ResultSection(SearchScope.CONVERSATIONS, convHits.size) {
        convHits.take(6).forEach { (c, m) ->
            val app = if (c.app == fr.jeremy.calepin.control.Conv.TELEGRAM) "Telegram" else "WhatsApp"
            if (m == null) ResultRow(c.name, app, SearchScope.CONVERSATIONS.icon) { a.onConversation(c.key, -1L) }
            else ResultRow(
                c.name,
                (if (m.mine) I18n.tr("Moi") + " : " else if (m.from.isNotBlank() && !m.from.equals(c.name, true)) m.from + " : " else "") +
                    snippet(m.text, w) + " · " + dateText(m.time, true),
                SearchScope.CONVERSATIONS.icon,
            ) { a.onConversation(c.key, m.time) }
        }
        TextButton(onClick = a.onMessages) { Text("Ouvrir les messages") }
    }
    if (SearchScope.MAILS in scopes && (mailHits.isNotEmpty() || notifMailHits.isNotEmpty() || mailLoading)) ResultSection(SearchScope.MAILS, mailHits.size + notifMailHits.size) {
        mailHits.take(8).forEach { h ->
            val acc = accounts.firstOrNull { it.id == h.accountId }?.email.orEmpty()
            ResultRow(
                h.subject.ifBlank { I18n.tr("(sans objet)") },
                listOf(h.from, dateText(h.date, true), if (accounts.size > 1) acc else "").filter { it.isNotBlank() }.joinToString(" · "),
                SearchScope.MAILS.icon,
            ) { a.onMail(h) }
        }
        notifMailHits.take(4).forEach { m ->
            ResultRow(m.subject.ifBlank { I18n.tr("(sans objet)") }, m.from + " · " + dateText(m.time, true), SearchScope.MAILS.icon) {
                fr.jeremy.calepin.control.MessageHub.openMail(ctx, m)
            }
        }
        if (mailLoading) Row(verticalAlignment = Alignment.CenterVertically) {
            CircularProgressIndicator(Modifier.size(20.dp).padding(2.dp), strokeWidth = 2.dp)
            Spacer(Modifier.width(8.dp))
            Text("Recherche dans mes boîtes mail…", style = MaterialTheme.typography.bodySmall)
        }
    }
    if (pro.isNotEmpty()) ResultSection(SearchScope.PRO, pro.size) {
        pro.take(6).forEach { (id, title, sub) -> ResultRow(title, sub, SearchScope.PRO.icon) { a.onClient(id) } }
    }
    if (SearchScope.RADIOS in scopes && (radios.isNotEmpty() || radioLoading)) ResultSection(SearchScope.RADIOS, radios.size) {
        radios.forEach { s ->
            val on = playing?.uuid == s.uuid
            ResultRow(
                s.name,
                listOf(flagOf(s.countryCode) + " " + countryName(s.countryCode, s.country), s.tags).filter { it.isNotBlank() }.joinToString(" · "),
                SearchScope.RADIOS.icon,
                trailingIcon = if (on) Icons.Filled.GraphicEq else Icons.Filled.PlayArrow,
                onTrailing = { RadioPlayer.play(ctx, s) },
            ) { RadioPlayer.play(ctx, s) }
        }
        if (radioLoading) CircularProgressIndicator(Modifier.size(20.dp).padding(2.dp), strokeWidth = 2.dp)
        TextButton(onClick = a.onRadios) { Text("Ouvrir les webradios") }
    }
}

private fun dateText(t: Long, withTime: Boolean): String =
    SimpleDateFormat(I18n.pattern(if (withTime) "EEE d MMM yyyy · HH'h'mm" else "EEE d MMM yyyy"), I18n.locale).format(Date(t))
        .replaceFirstChar { it.uppercase() }

/** Extrait du texte autour du premier mot trouvé. */
private fun snippet(text: String, w: List<String>): String {
    val flat = text.replace('\n', ' ').trim()
    if (w.isEmpty()) return flat.take(90)
    val norm = TextNorm.norm(flat)
    val i = norm.indexOf(w.first()).takeIf { it >= 0 && norm.length == flat.length } ?: return flat.take(90)
    val start = (i - 30).coerceAtLeast(0)
    return (if (start > 0) "…" else "") + flat.substring(start, minOf(flat.length, start + 90))
}

@Composable
private fun ResultSection(scope: SearchScope, count: Int, content: @Composable () -> Unit) {
    FoldSection(
        scope.label, scope.icon,
        summary = if (count > 0) I18n.trf("{0} résultat(s)", count) else null,
        startOpen = true,
    ) { content() }
}

@Composable
private fun ResultRow(
    title: String,
    subtitle: String,
    icon: ImageVector,
    trailingIcon: ImageVector? = null,
    onTrailing: () -> Unit = {},
    onClick: () -> Unit,
) {
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 4.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(icon, null, Modifier.size(20.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(1.dp)) {
            RawText(title, style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
            if (subtitle.isNotBlank()) {
                RawText(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 2, overflow = TextOverflow.Ellipsis)
            }
        }
        if (trailingIcon != null) {
            IconButton(onClick = onTrailing) { Icon(trailingIcon, null, tint = MaterialTheme.colorScheme.primary) }
        }
    }
}
