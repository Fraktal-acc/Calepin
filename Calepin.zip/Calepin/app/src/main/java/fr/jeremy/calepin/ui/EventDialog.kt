package fr.jeremy.calepin.ui

import android.Manifest
import android.app.Activity
import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccessTime
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import fr.jeremy.calepin.i18n.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.core.content.IntentCompat
import fr.jeremy.calepin.LockGuard
import fr.jeremy.calepin.data.Event
import fr.jeremy.calepin.reminders.Reminders
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

private val TIMED_REMINDERS = listOf(
    -1 to "Aucun", 0 to "À l'heure", 5 to "5 min avant", 15 to "15 min avant",
    30 to "30 min avant", 60 to "1 h avant", 1440 to "La veille",
)

// Pour un rendez-vous « toute la journée », le début est à minuit : -540 = le jour même à 9 h, 360 = la veille à 18 h.
private val ALLDAY_REMINDERS = listOf(-1 to "Aucun", -540 to "Le jour même à 9 h", 360 to "La veille à 18 h")

/** Création ou modification d'un rendez-vous, avec rappel, alarme et sonnerie. */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun EventDialog(
    initial: Event,
    defaultRingtone: String,
    onDismiss: () -> Unit,
    onSave: (Event) -> Unit,
    onDelete: (() -> Unit)? = null,
) {
    val ctx = LocalContext.current
    var title by remember { mutableStateOf(initial.title) }
    var start by remember { mutableLongStateOf(initial.start) }
    var end by remember { mutableLongStateOf(initial.end) }
    var allDay by remember { mutableStateOf(initial.allDay) }
    var remind by remember { mutableIntStateOf(initial.remindMinutes) }
    var alarm by remember { mutableStateOf(initial.alarm) }
    var ringtone by remember { mutableStateOf(initial.ringtone.ifBlank { defaultRingtone }) }
    var soundPicker by remember { mutableStateOf(false) }
    var repeat by remember { mutableStateOf(initial.repeat) }

    val cal = Calendar.getInstance().apply { timeInMillis = start }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { res ->
        if (res.resultCode == Activity.RESULT_OK) {
            val uri = res.data?.let { IntentCompat.getParcelableExtra(it, RingtoneManager.EXTRA_RINGTONE_PICKED_URI, Uri::class.java) }
            ringtone = uri?.toString() ?: ""
        }
    }
    val notifPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }

    fun midnight(t: Long) = Calendar.getInstance().apply {
        timeInMillis = t
        set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
    }.timeInMillis

    fun save() {
        val s0 = if (allDay) midnight(start) else start
        val e0 = when {
            end == 0L -> 0L
            allDay -> midnight(end).takeIf { it > s0 } ?: 0L
            else -> end.takeIf { it > s0 } ?: 0L
        }
        val e = initial.copy(
            end = e0,
            title = title.trim().ifBlank { "Rendez-vous" },
            start = if (allDay) Calendar.getInstance().apply {
                timeInMillis = start
                set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
            }.timeInMillis else start,
            allDay = allDay,
            remindMinutes = remind,
            alarm = alarm && remind != -1,
            ringtone = ringtone,
            repeat = repeat,
        )
        if (remind != -1 && Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            LockGuard.external()
            notifPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
        onSave(e)
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (initial.id == 0L) "Nouveau rendez-vous" else "Rendez-vous") },
        text = {
            Column(
                Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                OutlinedTextField(
                    value = title, onValueChange = { title = it },
                    label = { Text("Titre") },
                    modifier = Modifier.fillMaxWidth(),
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = {
                        DatePickerDialog(ctx, { _, y, m, d ->
                            start = Calendar.getInstance().apply { timeInMillis = start; set(y, m, d) }.timeInMillis
                        }, cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH)).show()
                    }) {
                        Icon(Icons.Filled.CalendarMonth, null, Modifier.size(18.dp))
                        Text(" " + SimpleDateFormat(fr.jeremy.calepin.i18n.I18n.pattern("EEE d MMM yyyy"), fr.jeremy.calepin.i18n.I18n.locale).format(Date(start)))
                    }
                    if (!allDay) {
                        OutlinedButton(onClick = {
                            TimePickerDialog(ctx, { _, h, min ->
                                start = Calendar.getInstance().apply {
                                    timeInMillis = start; set(Calendar.HOUR_OF_DAY, h); set(Calendar.MINUTE, min); set(Calendar.SECOND, 0)
                                }.timeInMillis
                            }, cal.get(Calendar.HOUR_OF_DAY), cal.get(Calendar.MINUTE), true).show()
                        }) {
                            Icon(Icons.Filled.AccessTime, null, Modifier.size(18.dp))
                            Text(" " + SimpleDateFormat(fr.jeremy.calepin.i18n.I18n.pattern("HH:mm"), fr.jeremy.calepin.i18n.I18n.locale).format(Date(start)))
                        }
                    }
                }
                if (end == 0L) {
                    TextButton(onClick = {
                        end = if (allDay) start + 86_400_000L else start + 3_600_000L
                    }) { Text(if (allDay) "+ Jusqu'au… (période de plusieurs jours)" else "+ Heure de fin / jusqu'au…") }
                } else {
                    val ec = Calendar.getInstance().apply { timeInMillis = end }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text("Jusqu'au", style = MaterialTheme.typography.labelLarge)
                        OutlinedButton(onClick = {
                            DatePickerDialog(ctx, { _, y, m, d ->
                                end = Calendar.getInstance().apply { timeInMillis = end; set(y, m, d) }.timeInMillis
                            }, ec.get(Calendar.YEAR), ec.get(Calendar.MONTH), ec.get(Calendar.DAY_OF_MONTH)).apply {
                                datePicker.minDate = midnight(start)
                            }.show()
                        }) { Text(SimpleDateFormat(fr.jeremy.calepin.i18n.I18n.pattern("EEE d MMM"), fr.jeremy.calepin.i18n.I18n.locale).format(Date(end))) }
                        if (!allDay) {
                            OutlinedButton(onClick = {
                                TimePickerDialog(ctx, { _, h, min ->
                                    end = Calendar.getInstance().apply {
                                        timeInMillis = end; set(Calendar.HOUR_OF_DAY, h); set(Calendar.MINUTE, min); set(Calendar.SECOND, 0)
                                    }.timeInMillis
                                }, ec.get(Calendar.HOUR_OF_DAY), ec.get(Calendar.MINUTE), true).show()
                            }) { Text(SimpleDateFormat(fr.jeremy.calepin.i18n.I18n.pattern("HH:mm"), fr.jeremy.calepin.i18n.I18n.locale).format(Date(end))) }
                        }
                        TextButton(onClick = { end = 0L }) { Text("×") }
                    }
                    if (end < start) {
                        Text("La fin est avant le début", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                    }
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Toute la journée", Modifier.weight(1f))
                    Switch(checked = allDay, onCheckedChange = {
                        allDay = it
                        remind = if (it) (if (remind == -1) -1 else -540) else (if (remind == -1) -1 else 15)
                    })
                }
                Text("Répétition", style = MaterialTheme.typography.labelLarge)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Event.REPEATS.forEach { (k, label) ->
                        FilterChip(selected = repeat == k, onClick = { repeat = k }, label = { Text(label) })
                    }
                }
                Text("Rappel", style = MaterialTheme.typography.labelLarge)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    (if (allDay) ALLDAY_REMINDERS else TIMED_REMINDERS).forEach { (m, label) ->
                        FilterChip(selected = remind == m, onClick = { remind = m }, label = { Text(label) })
                    }
                }
                if (remind != -1) {
                    Text("Type de rappel", style = MaterialTheme.typography.labelLarge)
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        FilterChip(selected = !alarm, onClick = { alarm = false }, label = { Text("Notification") })
                        FilterChip(selected = alarm, onClick = { alarm = true }, label = { Text("Alarme qui sonne") })
                    }
                    OutlinedButton(onClick = {
                        soundPicker = true
                    }, modifier = Modifier.fillMaxWidth()) {
                        Icon(Icons.Filled.MusicNote, null, Modifier.size(18.dp))
                        Text(" " + Reminders.ringtoneName(ctx, ringtone), maxLines = 1)
                    }
                    if (!Reminders.canExact(ctx)) {
                        TextButton(onClick = {
                            if (Build.VERSION.SDK_INT >= 31) {
                                LockGuard.external()
                                ctx.startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:" + ctx.packageName)))
                            }
                        }) { Text("Autoriser les rappels à l'heure exacte") }
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = { save() }) { Text("Enregistrer") } },
        dismissButton = {
            Row {
                if (onDelete != null) {
                    TextButton(onClick = onDelete) { Text("Supprimer", color = MaterialTheme.colorScheme.error) }
                }
                TextButton(onClick = onDismiss) { Text("Annuler") }
            }
        },
    )
    if (soundPicker) {
        SoundPickerDialog(ringtone, alarm = alarm, onDismiss = { soundPicker = false }) { ringtone = it }
    }
}
