package fr.jeremy.calepin.office

import android.content.Context
import android.net.Uri
import android.os.Environment
import android.os.FileObserver
import android.os.Handler
import android.os.Looper
import android.widget.Toast
import fr.jeremy.calepin.search.TextNorm
import fr.jeremy.calepin.tools.StorageAccess
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.io.File

/**
 * PDF du dossier « Download » du téléphone : ajoutés tout seuls au Bureau (dossier « Téléchargements ») dès qu'ils
 * sont téléchargés (navigateur, mails, WhatsApp…), et trouvés par l'assistant par leur nom.
 * Demande l'accès à tous les fichiers (déjà utilisé par l'explorateur).
 */
object PdfDownloads {
    const val FOLDER = "Téléchargements"

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val mutex = Mutex()
    private var observer: FileObserver? = null

    private fun p(ctx: Context) = ctx.applicationContext.getSharedPreferences("calepin_pdf_auto", Context.MODE_PRIVATE)

    fun enabled(ctx: Context) = p(ctx).getBoolean("on", true)

    fun setEnabled(ctx: Context, on: Boolean) {
        // Activation : seuls les PDF téléchargés à partir de maintenant sont ajoutés
        val e = p(ctx).edit().putBoolean("on", on)
        if (on) e.putLong("since", System.currentTimeMillis())
        e.apply()
        if (on) start(ctx) else stop()
    }

    fun dir(): File = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)

    /** PDF du dossier Download (et de ses sous-dossiers), du plus récent au plus ancien. */
    fun list(): List<File> {
        fun walk(d: File, depth: Int): List<File> = d.listFiles()?.flatMap { f ->
            when {
                f.isDirectory && depth > 0 && !f.name.startsWith(".") -> walk(f, depth - 1)
                f.isFile && f.name.endsWith(".pdf", ignoreCase = true) && f.length() > 0 -> listOf(f)
                else -> emptyList()
            }
        }.orEmpty()
        return walk(dir(), 2).sortedByDescending { it.lastModified() }
    }

    /** PDF du dossier Download au nom le plus proche ([name] vide ou « dernier » : le plus récent). */
    fun find(name: String): File? {
        val all = list()
        val w = TextNorm.norm(name).lowercase().trim()
        if (w.isEmpty() || w == "__dernier__") return all.firstOrNull()
        fun n(f: File) = TextNorm.norm(f.nameWithoutExtension).lowercase().replace('_', ' ').replace('-', ' ')
        return all.firstOrNull { n(it) == w }
            ?: all.firstOrNull { n(it).contains(w) }
            ?: all.firstOrNull { f -> w.split(' ').filter { it.length > 2 }.let { ws -> ws.isNotEmpty() && ws.all { n(f).contains(it) } } }
    }

    private fun key(f: File) = f.path + "|" + f.length() + "|" + f.lastModified()

    /** Copie un PDF du dossier Download dans le Bureau (dossier « Téléchargements »). */
    suspend fun import(ctx: Context, f: File): PdfEntry = withContext(Dispatchers.IO) {
        val lib = PdfLibrary.get(ctx)
        // Déjà dans le Bureau (même nom, même nombre d'octets) : on le reprend
        lib.items.value.firstOrNull { e -> e.name.equals(f.nameWithoutExtension, true) && lib.file(e.id).length() == f.length() }?.let { return@withContext it }
        lib.addFolder(FOLDER)
        val saved = lib.currentFolder
        lib.currentFolder = FOLDER
        try {
            lib.import(Uri.fromFile(f))
        } finally {
            lib.currentFolder = saved
        }
    }

    /** Ajoute au Bureau les PDF téléchargés depuis la dernière fois. Renvoie le nombre de PDF ajoutés. */
    suspend fun sync(ctx: Context): Int = mutex.withLock {
        if (!enabled(ctx) || !StorageAccess.granted(ctx)) return@withLock 0
        val prefs = p(ctx)
        val since = prefs.getLong("since", 0L).takeIf { it > 0 } ?: System.currentTimeMillis().also { prefs.edit().putLong("since", it).apply() }
        val seen = prefs.getStringSet("seen", emptySet()).orEmpty().toMutableSet()
        val now = System.currentTimeMillis()
        // Fichier encore en cours d'écriture : on attend la fois suivante
        val fresh = list().filter { it.lastModified() > since && it.lastModified() < now - 2_000 && key(it) !in seen }
        var added = 0
        fresh.forEach { f ->
            seen += key(f)
            if (runCatching { import(ctx, f) }.isSuccess) added++
        }
        if (fresh.isNotEmpty()) prefs.edit().putStringSet("seen", seen.toList().takeLast(500).toSet()).apply()
        added
    }

    /** Surveillance du dossier pendant que Calepin tourne (sinon, rattrapage à l'ouverture). */
    @Suppress("DEPRECATION")
    fun start(ctx: Context) {
        val app = ctx.applicationContext
        if (observer != null || !enabled(app) || !StorageAccess.granted(app)) return
        val d = dir()
        if (!d.isDirectory) return
        val mask = FileObserver.CLOSE_WRITE or FileObserver.MOVED_TO
        observer = (if (android.os.Build.VERSION.SDK_INT >= 29) object : FileObserver(d, mask) {
            override fun onEvent(event: Int, path: String?) = onFile(app, path)
        } else object : FileObserver(d.path, mask) {
            override fun onEvent(event: Int, path: String?) = onFile(app, path)
        }).also { it.startWatching() }
        scope.launch { notify(app, sync(app)) }
    }

    /** À l'ouverture de Calepin : surveillance (re)lancée et PDF téléchargés entre-temps ajoutés. */
    fun refresh(ctx: Context) {
        val app = ctx.applicationContext
        if (observer == null) start(app) else scope.launch { notify(app, sync(app)) }
    }

    fun stop() {
        observer?.stopWatching()
        observer = null
    }

    private fun onFile(app: Context, path: String?) {
        if (path == null || !path.endsWith(".pdf", ignoreCase = true)) return
        scope.launch {
            delay(3_000)
            notify(app, sync(app))
        }
    }

    private fun notify(app: Context, n: Int) {
        if (n <= 0) return
        Handler(Looper.getMainLooper()).post {
            runCatching {
                val t = if (n == 1) fr.jeremy.calepin.i18n.I18n.tr("PDF téléchargé ajouté au Bureau (Téléchargements).")
                else fr.jeremy.calepin.i18n.I18n.trf("{0} PDF téléchargés ajoutés au Bureau (Téléchargements).", n.toString())
                Toast.makeText(app, t, Toast.LENGTH_LONG).show()
            }
        }
    }
}
