package fr.jeremy.calepin.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.BatteryChargingFull
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import fr.jeremy.calepin.i18n.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import fr.jeremy.calepin.control.Scenario
import fr.jeremy.calepin.control.Scenarios
import kotlinx.coroutines.launch

/** Scénarios : plusieurs commandes d'un seul geste ou d'une phrase (« lance soirée film »). */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ScenariosScreen(onClose: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var list by remember { mutableStateOf(Scenarios.all(ctx)) }
    var editing by remember { mutableStateOf<Scenario?>(null) }
    var status by remember { mutableStateOf<String?>(null) }
    var routineFor by remember { mutableStateOf<Scenario?>(null) }
    var routinesVersion by remember { mutableStateOf(0) }
    BackHandler { onClose() }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { fr.jeremy.calepin.ui.FitText("Scénarios") },
                navigationIcon = { IconButton(onClick = onClose) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Retour") } },
            )
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = { editing = Scenario(name = "", steps = emptyList()) },
                icon = { Icon(Icons.Filled.Add, null) },
                text = { Text("Nouveau scénario") },
            )
        },
    ) { pad ->
        Column(
            Modifier.fillMaxSize().padding(pad).verticalScroll(rememberScrollState()).padding(horizontal = 16.dp).padding(bottom = 96.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Text(
                "Un scénario enchaîne plusieurs commandes. Lance-le d'ici ou à la voix : « lance soirée film », « bonne nuit ».",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            status?.let {
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer)) {
                    Text(it, Modifier.padding(12.dp), style = MaterialTheme.typography.bodySmall)
                }
            }
            list.forEach { sc ->
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLow), modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(sc.name, style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
                            IconButton(onClick = { editing = sc }) { Icon(Icons.Filled.Edit, "Modifier") }
                            IconButton(onClick = { Scenarios.delete(ctx, sc.id); list = Scenarios.all(ctx) }) { Icon(Icons.Filled.Delete, "Supprimer") }
                        }
                        val trig = remember(sc.id, routinesVersion) { fr.jeremy.calepin.care.Routines.trigger(ctx, sc.id) }
                        androidx.compose.material3.AssistChip(
                            onClick = { routineFor = sc },
                            label = { fr.jeremy.calepin.i18n.RawText(fr.jeremy.calepin.care.Routines.describe(trig)) },
                            leadingIcon = { Icon(if (trig.type == "charger") Icons.Filled.BatteryChargingFull else Icons.Filled.Schedule, null) },
                        )
                        sc.steps.forEachIndexed { i, st ->
                            Text("${i + 1}. $st", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        FilledTonalButton(onClick = {
                            status = "« ${sc.name} » en cours…"
                            scope.launch { status = Scenarios.run(ctx, sc) { step -> status = "« ${sc.name} » : $step" } }
                        }, enabled = !Scenarios.running) {
                            Icon(Icons.Filled.PlayArrow, null); Text(" Lancer")
                        }
                    }
                }
            }
        }
    }

    routineFor?.let { sc ->
        RoutineDialog(sc, onDismiss = { routineFor = null; routinesVersion++ })
    }

    editing?.let { sc ->
        var name by remember(sc.id) { mutableStateOf(sc.name) }
        var steps by remember(sc.id) { mutableStateOf(sc.steps.joinToString("\n")) }
        AlertDialog(
            onDismissRequest = { editing = null },
            title = { Text(if (sc.name.isBlank()) "Nouveau scénario" else "Modifier le scénario") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(name, { name = it }, label = { Text("Nom (ex. Soirée film)") }, singleLine = true)
                    OutlinedTextField(
                        steps, { steps = it },
                        label = { Text("Une commande par ligne") },
                        modifier = Modifier.heightIn(min = 160.dp),
                    )
                    Text(
                        "Exemples : « allume la télé », « mets la télé sur HDMI 1 », « mets France 2 », « baisse la lumière du salon à 20 % », " +
                            "« éteins toutes les lumières », « active ne pas déranger », « pause 5 » (attendre 5 secondes).",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            },
            confirmButton = {
                TextButton(enabled = name.isNotBlank(), onClick = {
                    Scenarios.upsert(ctx, sc.copy(name = name.trim(), steps = steps.lines().map { it.trim() }.filter { it.isNotEmpty() }))
                    list = Scenarios.all(ctx)
                    editing = null
                }) { Text("Enregistrer") }
            },
            dismissButton = { TextButton(onClick = { editing = null }) { Text("Annuler") } },
        )
    }
}

/** Déclenchement automatique d'un scénario : à heure fixe, ou en branchant le chargeur dans une plage horaire. */
@OptIn(androidx.compose.foundation.layout.ExperimentalLayoutApi::class)
@Composable
private fun RoutineDialog(sc: Scenario, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    val cur = remember(sc.id) { fr.jeremy.calepin.care.Routines.trigger(ctx, sc.id) }
    var type by remember(sc.id) { mutableStateOf(cur.type) }
    var minutes by remember(sc.id) { mutableStateOf(cur.minutes) }
    var until by remember(sc.id) { mutableStateOf(cur.until) }
    var days by remember(sc.id) { mutableStateOf(cur.days) }
    // Initiales des jours dans la langue de l'appli, du lundi au dimanche
    val labels = remember {
        val sw = java.text.DateFormatSymbols(fr.jeremy.calepin.i18n.I18n.locale).shortWeekdays
        listOf(2, 3, 4, 5, 6, 7, 1).map { sw[it].trim('.').take(2).replaceFirstChar { c -> c.uppercase() } }
    }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { fr.jeremy.calepin.i18n.RawText(fr.jeremy.calepin.i18n.I18n.trf("Lancer « {0} » automatiquement", sc.name)) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                androidx.compose.foundation.layout.FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("none" to "À la demande", "time" to "À une heure", "charger" to "En branchant le chargeur").forEach { (k, l) ->
                        androidx.compose.material3.FilterChip(selected = type == k, onClick = { type = k }, label = { Text(l) })
                    }
                }
                if (type == "time") {
                    TimeButton("Heure", minutes) { minutes = it }
                }
                if (type == "charger") {
                    TimeButton("Entre", minutes) { minutes = it }
                    TimeButton("Et", until) { until = it }
                    Text("Même heure aux deux : à n'importe quel moment. Exemple : entre 21h et 2h pour « bonne nuit ».", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                if (type != "none") {
                    Text("Jours", style = MaterialTheme.typography.bodyMedium)
                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        labels.forEachIndexed { i, l ->
                            val dv: Int = days
                            val on = (dv and (1 shl i)) != 0
                            androidx.compose.material3.FilterChip(
                                selected = on,
                                onClick = { days = if (on) days and (1 shl i).inv() else days or (1 shl i) },
                                label = { fr.jeremy.calepin.i18n.RawText(l) },
                            )
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                fr.jeremy.calepin.care.Routines.setTrigger(ctx, sc.id, fr.jeremy.calepin.care.RoutineTrigger(type, minutes, until, if (days == 0) 0b1111111 else days))
                onDismiss()
            }) { Text("Enregistrer") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Annuler") } },
    )
}
