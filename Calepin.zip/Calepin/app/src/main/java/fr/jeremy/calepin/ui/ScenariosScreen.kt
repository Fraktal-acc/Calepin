package fr.jeremy.calepin.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import fr.jeremy.calepin.i18n.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import fr.jeremy.calepin.control.Scenario
import fr.jeremy.calepin.control.Scenarios
import kotlinx.coroutines.launch

/** Scénarios : plusieurs commandes d'un seul geste ou d'une phrase (« lance soirée film »). */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ScenariosScreen(onClose: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var list by remember { mutableStateOf(Scenarios.all(ctx)) }
    var editing by remember { mutableStateOf<Scenario?>(null) }
    var status by remember { mutableStateOf<String?>(null) }
    BackHandler { onClose() }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { fr.jeremy.calepin.ui.FitText("Scénarios") },
                navigationIcon = { IconButton(onClick = onClose) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Retour") } },
            )
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = { editing = Scenario(name = "", steps = emptyList()) },
                icon = { Icon(Icons.Filled.Add, null) },
                text = { Text("Nouveau scénario") },
            )
        },
    ) { pad ->
        Column(
            Modifier.fillMaxSize().padding(pad).verticalScroll(rememberScrollState()).padding(horizontal = 16.dp).padding(bottom = 96.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Text(
                "Un scénario enchaîne plusieurs commandes. Lance-le d'ici ou à la voix : « lance soirée film », « bonne nuit ».",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            status?.let {
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer)) {
                    Text(it, Modifier.padding(12.dp), style = MaterialTheme.typography.bodySmall)
                }
            }
            list.forEach { sc ->
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLow), modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(sc.name, style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
                            IconButton(onClick = { editing = sc }) { Icon(Icons.Filled.Edit, "Modifier") }
                            IconButton(onClick = { Scenarios.delete(ctx, sc.id); list = Scenarios.all(ctx) }) { Icon(Icons.Filled.Delete, "Supprimer") }
                        }
                        sc.steps.forEachIndexed { i, st ->
                            Text("${i + 1}. $st", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        FilledTonalButton(onClick = {
                            status = "« ${sc.name} » en cours…"
                            scope.launch { status = Scenarios.run(ctx, sc) { step -> status = "« ${sc.name} » : $step" } }
                        }, enabled = !Scenarios.running) {
                            Icon(Icons.Filled.PlayArrow, null); Text(" Lancer")
                        }
                    }
                }
            }
        }
    }

    editing?.let { sc ->
        var name by remember(sc.id) { mutableStateOf(sc.name) }
        var steps by remember(sc.id) { mutableStateOf(sc.steps.joinToString("\n")) }
        AlertDialog(
            onDismissRequest = { editing = null },
            title = { Text(if (sc.name.isBlank()) "Nouveau scénario" else "Modifier le scénario") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(name, { name = it }, label = { Text("Nom (ex. Soirée film)") }, singleLine = true)
                    OutlinedTextField(
                        steps, { steps = it },
                        label = { Text("Une commande par ligne") },
                        modifier = Modifier.heightIn(min = 160.dp),
                    )
                    Text(
                        "Exemples : « allume la télé », « mets la télé sur HDMI 1 », « mets France 2 », « baisse la lumière du salon à 20 % », " +
                            "« éteins toutes les lumières », « active ne pas déranger », « pause 5 » (attendre 5 secondes).",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            },
            confirmButton = {
                TextButton(enabled = name.isNotBlank(), onClick = {
                    Scenarios.upsert(ctx, sc.copy(name = name.trim(), steps = steps.lines().map { it.trim() }.filter { it.isNotEmpty() }))
                    list = Scenarios.all(ctx)
                    editing = null
                }) { Text("Enregistrer") }
            },
            dismissButton = { TextButton(onClick = { editing = null }) { Text("Annuler") } },
        )
    }
}
