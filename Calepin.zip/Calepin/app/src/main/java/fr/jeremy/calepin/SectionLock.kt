package fr.jeremy.calepin

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import java.security.MessageDigest
import java.security.SecureRandom

/**
 * Code PIN des rubriques protégées (Notes, Contacts, Messages, Téléphone, Pro) et des notes sensibles.
 * Indépendant du verrouillage à l'ouverture. Une rubrique déverrouillée le reste tant que l'on ne quitte
 * pas Calepin (même délai que le verrouillage à l'ouverture).
 */
object SectionLock {
    const val NOTES = "notes"
    const val PRIVATE = "private"
    const val CONTACTS = "contacts"
    const val MESSAGES = "messages"
    const val PHONE = "phone"
    const val PRO = "pro"

    /** Rubriques réglables, dans l'ordre des paramètres. */
    val SECTIONS = listOf(
        PRIVATE to "Notes sensibles",
        NOTES to "Toutes les notes",
        CONTACTS to "Contacts",
        MESSAGES to "Messages",
        PHONE to "Téléphone",
        PRO to "Pro",
    )

    private lateinit var app: Context
    @Volatile private var ready = false

    private val _hasPin = MutableStateFlow(false)
    val hasPin: StateFlow<Boolean> = _hasPin
    private val _guarded = MutableStateFlow<Set<String>>(emptySet())
    val guarded: StateFlow<Set<String>> = _guarded
    private val _privateNotes = MutableStateFlow<Set<Long>>(emptySet())
    val privateNotes: StateFlow<Set<Long>> = _privateNotes
    private val _bio = MutableStateFlow(false)
    val bio: StateFlow<Boolean> = _bio
    private val _unlocked = MutableStateFlow<Set<String>>(emptySet())
    val unlocked: StateFlow<Set<String>> = _unlocked

    private fun p() = app.getSharedPreferences("calepin_guard", Context.MODE_PRIVATE)

    fun init(ctx: Context) {
        if (ready) return
        synchronized(this) {
            if (ready) return
            app = ctx.applicationContext
            val p = p()
            _hasPin.value = p.getString("pin_hash", null) != null
            _guarded.value = p.getStringSet("guarded", emptySet()).orEmpty().toSet()
            _privateNotes.value = p.getStringSet("private_notes", emptySet()).orEmpty().mapNotNull { it.toLongOrNull() }.toSet()
            _bio.value = p.getBoolean("bio", false)
            ready = true
        }
    }

    // ------------------------------------------------------------ Code

    fun setPin(pin: String) {
        val salt = ByteArray(16).also { SecureRandom().nextBytes(it) }.joinToString("") { "%02x".format(it) }
        p().edit().putString("pin_salt", salt).putString("pin_hash", hash(pin, salt)).apply()
        _hasPin.value = true
    }

    /** Supprime le code : plus aucune rubrique n'est protégée (les notes restent marquées « sensibles »). */
    fun clearPin() {
        p().edit().remove("pin_hash").remove("pin_salt").putStringSet("guarded", emptySet()).apply()
        _hasPin.value = false
        _guarded.value = emptySet()
    }

    fun checkPin(pin: String): Boolean {
        if (!ready) return false
        val salt = p().getString("pin_salt", null) ?: return false
        return hash(pin, salt) == p().getString("pin_hash", null)
    }

    var failedAttempts: Int
        get() = p().getInt("fails", 0)
        set(v) { p().edit().putInt("fails", v).apply() }
    var lockedUntil: Long
        get() = p().getLong("locked_until", 0)
        set(v) { p().edit().putLong("locked_until", v).apply() }

    private fun hash(pin: String, salt: String): String {
        var bytes = (salt + pin).toByteArray()
        val md = MessageDigest.getInstance("SHA-256")
        repeat(10_000) { bytes = md.digest(bytes) }
        return bytes.joinToString("") { "%02x".format(it) }
    }

    fun setBio(on: Boolean) { p().edit().putBoolean("bio", on).apply(); _bio.value = on }

    // ------------------------------------------------------------ Rubriques

    fun setGuard(section: String, on: Boolean) {
        val s = if (on) _guarded.value + section else _guarded.value - section
        p().edit().putStringSet("guarded", s).apply()
        _guarded.value = s
        // Une rubrique qu'on vient de protéger est considérée déverrouillée jusqu'à la sortie de l'appli
        if (on) unlock(section)
    }

    fun isGuarded(section: String) = ready && _hasPin.value && section in _guarded.value

    /** Vrai si la rubrique demande le code maintenant. */
    fun needs(section: String) = isGuarded(section) && section !in _unlocked.value

    fun unlock(section: String) { _unlocked.value = _unlocked.value + section }

    /** À la sortie de l'appli : tout se reverrouille. */
    fun relock() { _unlocked.value = emptySet() }

    // ------------------------------------------------------------ Notes sensibles

    fun isPrivate(id: Long?) = id != null && ready && id in _privateNotes.value

    fun setPrivate(id: Long, on: Boolean) {
        val s = if (on) _privateNotes.value + id else _privateNotes.value - id
        p().edit().putStringSet("private_notes", s.map { it.toString() }.toSet()).apply()
        _privateNotes.value = s
    }

    /** La note demande le code maintenant (note sensible, ou toutes les notes protégées). */
    fun noteLocked(id: Long?): Boolean = needs(NOTES) || (isPrivate(id) && needs(PRIVATE))

    /** Note à cacher à l'assistant, à l'IA et aux widgets tant qu'elle est verrouillée. */
    fun noteHidden(id: Long): Boolean = noteLocked(id)
}
