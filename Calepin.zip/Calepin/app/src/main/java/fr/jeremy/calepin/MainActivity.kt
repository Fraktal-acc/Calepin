package fr.jeremy.calepin

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import fr.jeremy.calepin.ui.CalepinTheme
import fr.jeremy.calepin.ui.EditorScreen
import fr.jeremy.calepin.ui.ListScreen

class MainActivity : ComponentActivity() {
    private val vm: NotesViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        val shared = if (savedInstanceState == null) sharedText(intent) else null
        setContent {
            CalepinTheme { App(vm, shared) }
        }
    }

    private fun sharedText(i: Intent?): String? =
        if (i?.action == Intent.ACTION_SEND && i.type?.startsWith("text/") == true) {
            i.getStringExtra(Intent.EXTRA_TEXT)
        } else {
            null
        }
}

private sealed interface Screen {
    data object Home : Screen
    data class Edit(val id: Long?, val initialText: String? = null) : Screen
}

@Composable
private fun App(vm: NotesViewModel, sharedText: String?) {
    var screen by remember {
        mutableStateOf<Screen>(if (sharedText != null) Screen.Edit(null, sharedText) else Screen.Home)
    }
    when (val s = screen) {
        Screen.Home -> ListScreen(
            vm = vm,
            onOpen = { screen = Screen.Edit(it) },
            onNew = { screen = Screen.Edit(null) },
        )
        is Screen.Edit -> EditorScreen(
            vm = vm,
            noteId = s.id,
            initialText = s.initialText,
            onClose = { screen = Screen.Home },
        )
    }
}
