package fr.jeremy.calepin

import android.content.Intent
import android.os.Bundle
import android.view.WindowManager
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import kotlinx.coroutines.flow.first
import fr.jeremy.calepin.ui.CalendarScreen
import fr.jeremy.calepin.ui.CalepinTheme
import fr.jeremy.calepin.ui.EditorScreen
import fr.jeremy.calepin.ui.ListScreen
import fr.jeremy.calepin.ui.LockScreen
import fr.jeremy.calepin.ui.SettingsScreen

// FragmentActivity (et non ComponentActivity) : nécessaire pour l'empreinte digitale / le visage.
class MainActivity : FragmentActivity() {
    private val vm: NotesViewModel by viewModels()
    private var locked by mutableStateOf(false)
    private var leftAt = 0L
    /** Note à ouvrir (touché d'un rappel). */
    private var openNote by mutableStateOf<Long?>(null)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        locked = savedInstanceState?.getBoolean("locked") ?: vm.settings.lockActive
        val shared = if (savedInstanceState == null) sharedText(intent) else null
        if (savedInstanceState == null) openNote = noteFrom(intent)
        // Rappels reprogrammés à chaque démarrage (après une mise à jour par exemple)
        Thread { runCatching { fr.jeremy.calepin.reminders.Reminders.rescheduleAll(applicationContext) } }.start()
        setContent {
            CalepinTheme {
                val hide by vm.settings.hideInRecents.collectAsStateWithLifecycle()
                LaunchedEffect(hide) {
                    if (hide) window.addFlags(WindowManager.LayoutParams.FLAG_SECURE)
                    else window.clearFlags(WindowManager.LayoutParams.FLAG_SECURE)
                }
                if (locked) {
                    LockScreen(vm.settings) { locked = false }
                } else {
                    App(vm, shared, openNote, onOpened = { openNote = null })
                }
            }
        }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putBoolean("locked", locked)
    }

    override fun onStop() {
        super.onStop()
        if (!isChangingConfigurations) leftAt = System.currentTimeMillis()
    }

    override fun onStart() {
        super.onStart()
        val away = leftAt
        leftAt = 0L
        if (away == 0L || !vm.settings.lockActive) return
        if (LockGuard.consume()) return // retour d'une appli ouverte par Calepin (partage, Maps…)
        if (System.currentTimeMillis() - away >= vm.settings.lockDelay.value * 1000L) locked = true
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        noteFrom(intent)?.let { openNote = it }
    }

    private fun noteFrom(i: Intent?): Long? =
        i?.getLongExtra(fr.jeremy.calepin.reminders.Reminders.EXTRA_NOTE, 0L)?.takeIf { it > 0L }

    private fun sharedText(i: Intent?): String? =
        if (i?.action == Intent.ACTION_SEND && i.type?.startsWith("text/") == true) {
            i.getStringExtra(Intent.EXTRA_TEXT)
        } else {
            null
        }
}

private sealed interface Screen {
    data object Home : Screen
    data object Settings : Screen
    data object Calendar : Screen
    data class Edit(val id: Long?, val initialText: String? = null) : Screen
}

@Composable
private fun App(vm: NotesViewModel, sharedText: String?, openNote: Long?, onOpened: () -> Unit) {
    var screen by remember {
        mutableStateOf<Screen>(if (sharedText != null) Screen.Edit(null, sharedText) else Screen.Home)
    }
    LaunchedEffect(openNote) {
        if (openNote != null) {
            vm.loaded.first { it } // attendre le chargement des notes avant d'ouvrir celle du rappel
            screen = Screen.Edit(openNote)
            onOpened()
        }
    }
    when (val s = screen) {
        Screen.Home -> ListScreen(
            vm = vm,
            onOpen = { screen = Screen.Edit(it) },
            onNew = { screen = Screen.Edit(null) },
            onSettings = { screen = Screen.Settings },
            onCalendar = { screen = Screen.Calendar },
        )
        Screen.Calendar -> CalendarScreen(
            vm = vm,
            onOpenNote = { screen = Screen.Edit(it) },
            onClose = { screen = Screen.Home },
        )
        Screen.Settings -> SettingsScreen(vm = vm, onClose = { screen = Screen.Home })
        is Screen.Edit -> EditorScreen(
            vm = vm,
            noteId = s.id,
            initialText = s.initialText,
            onClose = { screen = Screen.Home },
        )
    }
}
