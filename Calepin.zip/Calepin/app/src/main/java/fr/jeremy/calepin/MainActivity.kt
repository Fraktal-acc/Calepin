package fr.jeremy.calepin

import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.launch
import android.content.Intent
import android.os.Bundle
import android.view.WindowManager
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.material3.MaterialTheme
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import kotlinx.coroutines.flow.first
import fr.jeremy.calepin.ui.AssistantScreen
import fr.jeremy.calepin.ui.CalendarScreen
import fr.jeremy.calepin.ui.CalepinTheme
import fr.jeremy.calepin.ui.ContactsScreen
import fr.jeremy.calepin.ui.EditorScreen
import fr.jeremy.calepin.games.GamesScreen
import fr.jeremy.calepin.ui.ListScreen
import fr.jeremy.calepin.ui.DashboardScreen
import fr.jeremy.calepin.ui.DashboardActions
import fr.jeremy.calepin.ui.AppearanceScreen
import fr.jeremy.calepin.ui.RemoteScreen
import fr.jeremy.calepin.ui.LockScreen
import fr.jeremy.calepin.ui.SettingsScreen

// FragmentActivity (et non ComponentActivity) : nécessaire pour l'empreinte digitale / le visage.
class MainActivity : FragmentActivity() {
    private val vm: NotesViewModel by viewModels()
    private var locked by mutableStateOf(false)
    private var leftAt = 0L
    /** Note à ouvrir (touché d'un rappel). */
    private var openNote by mutableStateOf<Long?>(null)
    /** Ouvrir l'assistant (touché du briefing du matin). */
    private var openAssistant by mutableStateOf(false)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        fr.jeremy.calepin.i18n.I18n.init(this)
        fr.jeremy.calepin.ui.Onboarding.prepare(this)
        enableEdgeToEdge()
        locked = savedInstanceState?.getBoolean("locked") ?: vm.settings.lockActive
        val shared = if (savedInstanceState == null) sharedText(intent) else null
        if (savedInstanceState == null) {
            openNote = noteFrom(intent)
            openAssistant = intent?.getBooleanExtra(fr.jeremy.calepin.assistant.Briefing.EXTRA_OPEN_ASSISTANT, false) == true
            openFrom(intent)
            openPdf(intent)
        }
        fr.jeremy.calepin.assistant.Briefing.schedule(applicationContext)
        // Rappels reprogrammés à chaque démarrage (après une mise à jour par exemple)
        Thread { runCatching { fr.jeremy.calepin.reminders.Reminders.rescheduleAll(applicationContext) } }.start()
        setContent {
            CalepinTheme {
                val hide by vm.settings.hideInRecents.collectAsStateWithLifecycle()
                LaunchedEffect(hide) {
                    if (hide) window.addFlags(WindowManager.LayoutParams.FLAG_SECURE)
                    else window.clearFlags(WindowManager.LayoutParams.FLAG_SECURE)
                }
                // L'appli reste en place sous l'écran de verrouillage : après le code ou l'empreinte,
                // on retrouve exactement l'écran (et la note) où l'on était
                androidx.compose.foundation.layout.Box(androidx.compose.ui.Modifier.fillMaxSize()) {
                    fr.jeremy.calepin.ui.NightWorkFrame {
                        App(vm, shared, openNote, onOpened = { openNote = null }, openAssistant, onAssistantOpened = { openAssistant = false })
                    }
                    if (locked) {
                        val focusManager = androidx.compose.ui.platform.LocalFocusManager.current
                        val keyboard = androidx.compose.ui.platform.LocalSoftwareKeyboardController.current
                        LaunchedEffect(Unit) { focusManager.clearFocus(force = true); keyboard?.hide() }
                        // Retour : on quitte l'appli sans rien dévoiler
                        androidx.activity.compose.BackHandler { moveTaskToBack(true) }
                        androidx.compose.foundation.layout.Box(
                            androidx.compose.ui.Modifier
                                .fillMaxSize()
                                .background(MaterialTheme.colorScheme.surface)
                                // Les touchers s'arrêtent ici (rien n'atteint les écrans en dessous),
                                // sans être « consommés » : les touches du code PIN fonctionnent normalement
                                .pointerInput(Unit) { awaitPointerEventScope { while (true) awaitPointerEvent() } },
                        ) {
                            LockScreen(vm.settings) { locked = false }
                        }
                    }
                }
            }
        }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putBoolean("locked", locked)
    }

    override fun onStop() {
        super.onStop()
        if (!isChangingConfigurations) leftAt = System.currentTimeMillis()
    }

    override fun onStart() {
        super.onStart()
        val away = leftAt
        leftAt = 0L
        if (away == 0L) return
        if (LockGuard.consume()) return // retour d'une appli ouverte par Calepin (partage, Maps…)
        if (System.currentTimeMillis() - away >= vm.settings.lockDelay.value * 1000L) {
            SectionLock.relock() // rubriques protégées par code : à redemander
            if (vm.settings.lockActive) locked = true
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        noteFrom(intent)?.let { openNote = it }
        openPdf(intent)
        if (intent.getBooleanExtra(fr.jeremy.calepin.assistant.Briefing.EXTRA_OPEN_ASSISTANT, false)) openAssistant = true
        openFrom(intent)
    }

    /** PDF ouvert depuis une autre appli (« Ouvrir avec Calepin ») : copié dans la bibliothèque puis affiché. */
    private fun openPdf(i: Intent?) {
        val uri = i?.data ?: return
        if (i.action != Intent.ACTION_VIEW) return
        val type = i.type ?: contentResolver.getType(uri) ?: ""
        if (type != "application/pdf" && !uri.toString().lowercase().endsWith(".pdf")) return
        lifecycleScope.launch {
            val id = fr.jeremy.calepin.ui.office.importExternalPdf(applicationContext, uri)
            vm.navigation.value = if (id != null) "pdf:$id" else "pdf"
        }
    }

    /** Widget ou bouton du volet rapide : écran à ouvrir. */
    private fun openFrom(i: Intent?) {
        val what = i?.getStringExtra(fr.jeremy.calepin.widgets.Widgets.EXTRA_OPEN) ?: return
        if (what != "note") vm.navigation.value = what
    }

    /** Boutons de volume du téléphone : pilotent la télé quand l'écran Télécommande est ouvert. */
    override fun dispatchKeyEvent(event: android.view.KeyEvent): Boolean {
        val h = fr.jeremy.calepin.ui.VolumeKeys.handler
        val code = event.keyCode
        if (h != null && (code == android.view.KeyEvent.KEYCODE_VOLUME_UP || code == android.view.KeyEvent.KEYCODE_VOLUME_DOWN)) {
            if (event.action == android.view.KeyEvent.ACTION_DOWN) h(code == android.view.KeyEvent.KEYCODE_VOLUME_UP)
            return true
        }
        return super.dispatchKeyEvent(event)
    }

    private fun noteFrom(i: Intent?): Long? =
        i?.getLongExtra(fr.jeremy.calepin.reminders.Reminders.EXTRA_NOTE, 0L)?.takeIf { it > 0L }

    private fun sharedText(i: Intent?): String? =
        if (i?.action == Intent.ACTION_SEND && i.type?.startsWith("text/") == true) {
            i.getStringExtra(Intent.EXTRA_TEXT)
        } else {
            null
        }
}

private sealed interface Screen {
    /** Accueil : toutes les rubriques. */
    data object Dashboard : Screen
    /** Liste des notes. */
    data object Home : Screen
    data object Settings : Screen
    data object Calendar : Screen
    data object Assistant : Screen
    data object Contacts : Screen
    data object Games : Screen
    data object Relax : Screen
    data object Radio : Screen
    data object Weather : Screen
    data object Phone : Screen
    data object Optimizer : Screen
    data object Cleaner : Screen
    data object Files : Screen
    data object Devices : Screen
    data object Remote : Screen
    data object Appearance : Screen
    data object Pro : Screen
    data object Scenarios : Screen
    data object About : Screen
    data object Backup : Screen
    data object WorkHours : Screen
    data object Trash : Screen
    data object CrashLog : Screen
    data object Places : Screen
    data object Stats : Screen
    data object TvGuide : Screen
    data object Office : Screen
    data object Messages : Screen
    data object PdfLibrary : Screen
    data class PdfView(val id: String) : Screen
    /** [back] : écran où revenir en fermant la note. */
    data class Edit(
        val id: Long?,
        val initialText: String? = null,
        val initialTitle: String? = null,
        val back: Screen = Screen.Home,
        val folder: String = "",
        /** Ouvrir directement l'appareil photo pour lire un texte (widget « Scanner »). */
        val scan: Boolean = false,
    ) : Screen
}

@Composable
private fun App(
    vm: NotesViewModel,
    sharedText: String?,
    openNote: Long?,
    onOpened: () -> Unit,
    openAssistant: Boolean,
    onAssistantOpened: () -> Unit,
) {
    var screen by remember {
        mutableStateOf<Screen>(if (sharedText != null) Screen.Edit(null, sharedText, back = Screen.Dashboard) else Screen.Dashboard)
    }
    // Premier lancement : présentation en trois écrans
    val ctx = androidx.compose.ui.platform.LocalContext.current
    var onboarded by remember { mutableStateOf(fr.jeremy.calepin.ui.Onboarding.done(ctx)) }
    if (!onboarded) {
        fr.jeremy.calepin.ui.OnboardingScreen(onFinish = { fr.jeremy.calepin.ui.Onboarding.markDone(ctx); onboarded = true })
        return
    }
    // Fond « accueil seulement » : il faut savoir si l'accueil est affiché
    LaunchedEffect(screen) { fr.jeremy.calepin.ui.Appearance.get(ctx).onHome.value = screen == Screen.Dashboard }
    // Retour vers l'écran d'où l'on vient (accueil ou télécommande pour les appareils, par exemple)
    var devicesBack by remember { mutableStateOf<Screen>(Screen.Dashboard) }
    // Ouverts depuis la recherche de l'accueil
    var contactTarget by remember { mutableStateOf<Long?>(null) }
    var clientTarget by remember { mutableStateOf<String?>(null) }
    var eventTarget by remember { mutableStateOf<fr.jeremy.calepin.data.Event?>(null) }
    LaunchedEffect(openNote) {
        if (openNote != null) {
            vm.loaded.first { it } // attendre le chargement des notes avant d'ouvrir celle du rappel
            screen = Screen.Edit(openNote, back = Screen.Dashboard)
            onOpened()
        }
    }
    LaunchedEffect(openAssistant) {
        if (openAssistant) {
            vm.loaded.first { it }
            vm.ask(fr.jeremy.calepin.i18n.I18n.tr("Résumé de ma journée"), "Résumé de ma journée")
            screen = Screen.Assistant
            onAssistantOpened()
        }
    }
    // Navigation demandée à l'assistant (« ouvre la télécommande », « montre l'apparence »…)
    val nav by vm.navigation.collectAsStateWithLifecycle()
    LaunchedEffect(nav) {
        val target = when (nav) {
            "remote" -> if (BuildConfig.AI) Screen.Remote else null
            "devices" -> if (BuildConfig.AI) Screen.Devices.also { devicesBack = Screen.Dashboard } else null
            "appearance" -> Screen.Appearance
            "notes" -> Screen.Home
            "agenda" -> Screen.Calendar
            "contacts" -> Screen.Contacts
            "games" -> Screen.Games
            "relax" -> Screen.Relax
            "radio" -> Screen.Radio
            "weather" -> Screen.Weather
            "phone" -> Screen.Phone
            "cleaner" -> Screen.Cleaner
            "files" -> Screen.Files
            "optimizer" -> Screen.Optimizer
            "settings" -> Screen.Settings
            "home" -> Screen.Dashboard
            "new_note" -> Screen.Edit(null, back = Screen.Dashboard)
            "new_list" -> Screen.Edit(null, initialText = fr.jeremy.calepin.ui.Checklist.OPEN, back = Screen.Dashboard)
            "scan" -> Screen.Edit(null, back = Screen.Dashboard, scan = true)
            "assistant" -> Screen.Assistant
            "pro" -> Screen.Pro
            "scenarios" -> if (BuildConfig.AI) Screen.Scenarios else null
            "about" -> Screen.About
            "backup" -> Screen.Backup
            "workhours" -> Screen.WorkHours
            "trash" -> Screen.Trash
            "crashes" -> Screen.CrashLog
            "places" -> Screen.Places
            "stats" -> Screen.Stats
            "tvguide" -> Screen.TvGuide
            "office" -> Screen.Office
            "messages" -> Screen.Messages
            "pdf" -> Screen.PdfLibrary
            else -> nav?.takeIf { it.startsWith("pdf:") }?.let { Screen.PdfView(it.removePrefix("pdf:")) }
                ?: nav?.takeIf { it.startsWith("note:") }?.removePrefix("note:")?.toLongOrNull()?.let { Screen.Edit(it, back = screen) }
        }
        if (target != null) screen = target
        if (nav != null) vm.navigation.value = null
    }
    // L'assistant sait quel menu est ouvert (« ce PDF », « cette note »…)
    LaunchedEffect(screen) {
        val sc = screen
        ScreenContext.screen = when (sc) {
            Screen.Home -> "notes"
            Screen.Calendar, Screen.WorkHours -> "agenda"
            Screen.Contacts -> "contacts"
            Screen.Messages -> "messages"
            Screen.Pro -> "pro"
            Screen.Office, Screen.PdfLibrary -> "office"
            is Screen.PdfView -> "pdf"
            is Screen.Edit -> "note"
            Screen.Phone, Screen.Files, Screen.Cleaner, Screen.Optimizer -> "phone"
            else -> "home"
        }
        ScreenContext.pdfId = (sc as? Screen.PdfView)?.id
        ScreenContext.noteId = (sc as? Screen.Edit)?.id
    }
    // Bouton de l'assistant dans les menus (l'accueil et l'assistant ont déjà le leur ; l'éditeur garde sa barre)
    val quickAssistant = when (screen) {
        Screen.Dashboard, Screen.Assistant, is Screen.Edit, Screen.Games -> false
        else -> true
    }
    Box(Modifier.fillMaxSize()) {
    when (val s = screen) {
        Screen.Dashboard -> DashboardScreen(
            vm = vm,
            a = DashboardActions(
                onNotes = { vm.openFolder(null); screen = Screen.Home },
                onNote = { screen = Screen.Edit(it, back = Screen.Dashboard) },
                onNewNote = { screen = Screen.Edit(null, back = Screen.Dashboard) },
                onSearch = { q -> vm.openFolder(null); vm.setQuery(q); screen = Screen.Home },
                onCalendar = { screen = Screen.Calendar },
                onContacts = { screen = Screen.Contacts },
                onAssistant = { screen = Screen.Assistant },
                onRemote = if (BuildConfig.AI) ({ screen = Screen.Remote }) else null,
                onDevices = if (BuildConfig.AI) ({ devicesBack = Screen.Dashboard; screen = Screen.Devices }) else null,
                onGames = { screen = Screen.Relax },
                onSettings = { screen = Screen.Settings },
                onAppearance = { screen = Screen.Appearance },
                onPro = { screen = Screen.Pro },
                onWeather = { screen = Screen.Weather },
                onPhone = { screen = Screen.Phone },
                onEvent = { eventTarget = it; screen = Screen.Calendar },
                onContact = { contactTarget = it; screen = Screen.Contacts },
                onClient = { clientTarget = it; screen = Screen.Pro },
                onRadios = { screen = Screen.Radio },
                onCrashLog = { screen = Screen.CrashLog },
                onOffice = { screen = Screen.Office },
                onMessages = { screen = Screen.Messages },
            ),
        )
        Screen.Home -> fr.jeremy.calepin.ui.SectionGate(fr.jeremy.calepin.SectionLock.NOTES, onCancel = { screen = Screen.Dashboard }) {
            ListScreen(
                vm = vm,
                onOpen = { screen = Screen.Edit(it) },
                onNew = { screen = Screen.Edit(null, folder = vm.currentFolder.value.orEmpty()) },
                onBack = { vm.setQuery(""); screen = Screen.Dashboard },
            )
        }
        Screen.Relax -> fr.jeremy.calepin.ui.RelaxScreen(
            onGames = { screen = Screen.Games },
            onRadio = { screen = Screen.Radio },
            onTvGuide = { screen = Screen.TvGuide },
            onRemote = if (BuildConfig.AI) ({ screen = Screen.Remote }) else null,
            onClose = { screen = Screen.Dashboard },
        )
        Screen.Games -> GamesScreen(onClose = { screen = Screen.Relax })
        Screen.Radio -> fr.jeremy.calepin.ui.RadioScreen(onClose = { screen = Screen.Relax })
        Screen.Weather -> fr.jeremy.calepin.ui.WeatherScreen(onClose = { screen = Screen.Dashboard })
        Screen.Phone -> fr.jeremy.calepin.ui.SectionGate(fr.jeremy.calepin.SectionLock.PHONE, onCancel = { screen = Screen.Dashboard }) {
            fr.jeremy.calepin.ui.tools.PhoneScreen(
                onOptimizer = { screen = Screen.Optimizer },
                onCleaner = { screen = Screen.Cleaner },
                onFiles = { screen = Screen.Files },
                onClose = { screen = Screen.Dashboard },
            )
        }
        Screen.Optimizer -> fr.jeremy.calepin.ui.SectionGate(fr.jeremy.calepin.SectionLock.PHONE, onCancel = { screen = Screen.Dashboard }) {
            fr.jeremy.calepin.ui.tools.OptimizerScreen(onCleaner = { screen = Screen.Cleaner }, onClose = { screen = Screen.Phone })
        }
        Screen.Cleaner -> fr.jeremy.calepin.ui.SectionGate(fr.jeremy.calepin.SectionLock.PHONE, onCancel = { screen = Screen.Dashboard }) {
            fr.jeremy.calepin.ui.tools.CleanerScreen(onClose = { screen = Screen.Phone })
        }
        Screen.Files -> fr.jeremy.calepin.ui.SectionGate(fr.jeremy.calepin.SectionLock.PHONE, onCancel = { screen = Screen.Dashboard }) {
            fr.jeremy.calepin.ui.tools.FilesScreen(onClose = { screen = Screen.Phone })
        }
        Screen.Appearance -> AppearanceScreen(vm = vm, onClose = { screen = Screen.Settings })
        Screen.Remote -> RemoteScreen(
            onClose = { screen = Screen.Relax },
            onDevices = { devicesBack = Screen.Remote; screen = Screen.Devices },
            onScenarios = { screen = Screen.Scenarios },
        )
        Screen.Scenarios -> fr.jeremy.calepin.ui.ScenariosScreen(onClose = { screen = Screen.Remote })
        Screen.Pro -> fr.jeremy.calepin.ui.SectionGate(fr.jeremy.calepin.SectionLock.PRO, onCancel = { clientTarget = null; screen = Screen.Dashboard }) {
            fr.jeremy.calepin.ui.pro.ProScreen(vm = vm, onClose = { clientTarget = null; screen = Screen.Dashboard }, initialClient = clientTarget)
            LaunchedEffect(Unit) { clientTarget = null }
        }
        Screen.About -> fr.jeremy.calepin.ui.AboutScreen(onClose = { screen = Screen.Settings })
        Screen.Backup -> fr.jeremy.calepin.ui.BackupScreen(vm = vm, onClose = { screen = Screen.Settings })
        Screen.WorkHours -> fr.jeremy.calepin.ui.WorkHoursScreen(vm = vm, onClose = { screen = Screen.Calendar })
        Screen.Trash -> fr.jeremy.calepin.ui.TrashScreen(vm = vm, onClose = { screen = Screen.Settings })
        Screen.CrashLog -> fr.jeremy.calepin.ui.CrashLogScreen(onClose = { screen = Screen.Settings })
        Screen.Places -> fr.jeremy.calepin.ui.PlaceRemindersScreen(onClose = { screen = Screen.Settings })
        Screen.Stats -> fr.jeremy.calepin.ui.StatsScreen(vm = vm, onClose = { screen = Screen.Settings })
        Screen.TvGuide -> fr.jeremy.calepin.ui.TvGuideScreen(onClose = { screen = Screen.Relax })
        Screen.Messages -> fr.jeremy.calepin.ui.SectionGate(fr.jeremy.calepin.SectionLock.MESSAGES, onCancel = { screen = Screen.Dashboard }) {
            fr.jeremy.calepin.ui.MessagesScreen(onClose = { screen = Screen.Dashboard })
        }
        Screen.Office -> fr.jeremy.calepin.ui.office.OfficeScreen(onPdf = { screen = Screen.PdfLibrary }, onClose = { screen = Screen.Dashboard })
        Screen.PdfLibrary -> fr.jeremy.calepin.ui.office.PdfLibraryScreen(onOpen = { screen = Screen.PdfView(it) }, onClose = { screen = Screen.Office })
        is Screen.PdfView -> androidx.compose.runtime.key(s.id) {
            fr.jeremy.calepin.ui.office.PdfViewerScreen(s.id, onClose = { screen = Screen.PdfLibrary }, onOpen = { screen = Screen.PdfView(it) })
        }
        Screen.Contacts -> fr.jeremy.calepin.ui.SectionGate(fr.jeremy.calepin.SectionLock.CONTACTS, onCancel = { contactTarget = null; screen = Screen.Dashboard }) {
            ContactsScreen(
                vm = vm,
                onOpenNote = { screen = Screen.Edit(it, back = Screen.Contacts) },
                onNewNote = { title, text -> screen = Screen.Edit(null, initialText = text, initialTitle = title, back = Screen.Contacts) },
                onClose = { contactTarget = null; screen = Screen.Dashboard },
                initialContactId = contactTarget,
            )
            // Consommé une seule fois : un retour plus tard sur l'écran ne rouvre pas le même contact
            LaunchedEffect(Unit) { contactTarget = null }
        }
        Screen.Assistant -> AssistantScreen(
            vm = vm,
            onOpenNote = { screen = Screen.Edit(it, back = Screen.Assistant) },
            onSearch = { q -> vm.setQuery(q); screen = Screen.Home },
            onCalendar = { screen = Screen.Calendar },
            onClose = { screen = Screen.Dashboard },
        )
        Screen.Calendar -> {
            CalendarScreen(
                vm = vm,
                onOpenNote = { screen = Screen.Edit(it, back = Screen.Calendar) },
                onClose = { eventTarget = null; screen = Screen.Dashboard },
                initialEvent = eventTarget,
                onWorkHours = { screen = Screen.WorkHours },
            )
            LaunchedEffect(Unit) { eventTarget = null }
        }
        Screen.Settings -> SettingsScreen(
            vm = vm,
            onClose = { screen = Screen.Dashboard },
            onGames = { screen = Screen.Games },
            onDevices = { devicesBack = Screen.Settings; screen = Screen.Devices },
            onAppearance = { screen = Screen.Appearance },
            onBackup = { screen = Screen.Backup },
            onAbout = { screen = Screen.About },
            onScenarios = if (BuildConfig.AI) ({ screen = Screen.Scenarios }) else null,
            onTrash = { screen = Screen.Trash },
            onCrashLog = { screen = Screen.CrashLog },
            onWorkHours = { screen = Screen.WorkHours },
            onPlaces = { screen = Screen.Places },
            onStats = { screen = Screen.Stats },
        )
        Screen.Devices -> fr.jeremy.calepin.ui.DevicesScreen(onClose = { screen = devicesBack })
        // Une note par composition : passer d'une note à l'autre (lien) repart de zéro
        is Screen.Edit -> androidx.compose.runtime.key(s) {
          fr.jeremy.calepin.ui.NoteGate(s.id, onCancel = { screen = s.back }) {
            EditorScreen(
                vm = vm,
                noteId = s.id,
                initialText = s.initialText,
                initialTitle = s.initialTitle,
                initialFolder = s.folder,
                scanOnOpen = s.scan,
                onClose = { screen = s.back },
                // Lien [[Autre note]] : on l'ouvre (ou on la crée), et le retour ramène au même endroit
                onOpenNote = { id, t -> screen = if (id != null) Screen.Edit(id, back = s.back) else Screen.Edit(null, initialTitle = t, back = s.back) },
            )
          }
        }
    }
    if (quickAssistant) fr.jeremy.calepin.ui.QuickAssistant(
        vm, onOpenFull = { screen = Screen.Assistant },
        modifier = Modifier.align(Alignment.BottomStart).navigationBarsPadding().padding(start = 12.dp, bottom = 96.dp),
    )
    }
}
