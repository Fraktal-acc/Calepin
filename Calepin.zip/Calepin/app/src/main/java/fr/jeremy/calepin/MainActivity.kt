package fr.jeremy.calepin

import android.content.Intent
import android.os.Bundle
import android.view.WindowManager
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import kotlinx.coroutines.flow.first
import fr.jeremy.calepin.ui.AssistantScreen
import fr.jeremy.calepin.ui.CalendarScreen
import fr.jeremy.calepin.ui.CalepinTheme
import fr.jeremy.calepin.ui.ContactsScreen
import fr.jeremy.calepin.ui.EditorScreen
import fr.jeremy.calepin.games.GamesScreen
import fr.jeremy.calepin.ui.ListScreen
import fr.jeremy.calepin.ui.DashboardScreen
import fr.jeremy.calepin.ui.DashboardActions
import fr.jeremy.calepin.ui.AppearanceScreen
import fr.jeremy.calepin.ui.RemoteScreen
import fr.jeremy.calepin.ui.LockScreen
import fr.jeremy.calepin.ui.SettingsScreen

// FragmentActivity (et non ComponentActivity) : nécessaire pour l'empreinte digitale / le visage.
class MainActivity : FragmentActivity() {
    private val vm: NotesViewModel by viewModels()
    private var locked by mutableStateOf(false)
    private var leftAt = 0L
    /** Note à ouvrir (touché d'un rappel). */
    private var openNote by mutableStateOf<Long?>(null)
    /** Ouvrir l'assistant (touché du briefing du matin). */
    private var openAssistant by mutableStateOf(false)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        locked = savedInstanceState?.getBoolean("locked") ?: vm.settings.lockActive
        val shared = if (savedInstanceState == null) sharedText(intent) else null
        if (savedInstanceState == null) {
            openNote = noteFrom(intent)
            openAssistant = intent?.getBooleanExtra(fr.jeremy.calepin.assistant.Briefing.EXTRA_OPEN_ASSISTANT, false) == true
        }
        fr.jeremy.calepin.assistant.Briefing.schedule(applicationContext)
        // Rappels reprogrammés à chaque démarrage (après une mise à jour par exemple)
        Thread { runCatching { fr.jeremy.calepin.reminders.Reminders.rescheduleAll(applicationContext) } }.start()
        setContent {
            CalepinTheme {
                val hide by vm.settings.hideInRecents.collectAsStateWithLifecycle()
                LaunchedEffect(hide) {
                    if (hide) window.addFlags(WindowManager.LayoutParams.FLAG_SECURE)
                    else window.clearFlags(WindowManager.LayoutParams.FLAG_SECURE)
                }
                if (locked) {
                    LockScreen(vm.settings) { locked = false }
                } else {
                    App(vm, shared, openNote, onOpened = { openNote = null }, openAssistant, onAssistantOpened = { openAssistant = false })
                }
            }
        }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putBoolean("locked", locked)
    }

    override fun onStop() {
        super.onStop()
        if (!isChangingConfigurations) leftAt = System.currentTimeMillis()
    }

    override fun onStart() {
        super.onStart()
        val away = leftAt
        leftAt = 0L
        if (away == 0L || !vm.settings.lockActive) return
        if (LockGuard.consume()) return // retour d'une appli ouverte par Calepin (partage, Maps…)
        if (System.currentTimeMillis() - away >= vm.settings.lockDelay.value * 1000L) locked = true
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        noteFrom(intent)?.let { openNote = it }
        if (intent.getBooleanExtra(fr.jeremy.calepin.assistant.Briefing.EXTRA_OPEN_ASSISTANT, false)) openAssistant = true
    }

    private fun noteFrom(i: Intent?): Long? =
        i?.getLongExtra(fr.jeremy.calepin.reminders.Reminders.EXTRA_NOTE, 0L)?.takeIf { it > 0L }

    private fun sharedText(i: Intent?): String? =
        if (i?.action == Intent.ACTION_SEND && i.type?.startsWith("text/") == true) {
            i.getStringExtra(Intent.EXTRA_TEXT)
        } else {
            null
        }
}

private sealed interface Screen {
    /** Accueil : toutes les rubriques. */
    data object Dashboard : Screen
    /** Liste des notes. */
    data object Home : Screen
    data object Settings : Screen
    data object Calendar : Screen
    data object Assistant : Screen
    data object Contacts : Screen
    data object Games : Screen
    data object Devices : Screen
    data object Remote : Screen
    data object Appearance : Screen
    /** [back] : écran où revenir en fermant la note. */
    data class Edit(
        val id: Long?,
        val initialText: String? = null,
        val initialTitle: String? = null,
        val back: Screen = Screen.Home,
        val folder: String = "",
    ) : Screen
}

@Composable
private fun App(
    vm: NotesViewModel,
    sharedText: String?,
    openNote: Long?,
    onOpened: () -> Unit,
    openAssistant: Boolean,
    onAssistantOpened: () -> Unit,
) {
    var screen by remember {
        mutableStateOf<Screen>(if (sharedText != null) Screen.Edit(null, sharedText, back = Screen.Dashboard) else Screen.Dashboard)
    }
    // Retour vers l'écran d'où l'on vient (accueil ou télécommande pour les appareils, par exemple)
    var devicesBack by remember { mutableStateOf<Screen>(Screen.Dashboard) }
    LaunchedEffect(openNote) {
        if (openNote != null) {
            vm.loaded.first { it } // attendre le chargement des notes avant d'ouvrir celle du rappel
            screen = Screen.Edit(openNote, back = Screen.Dashboard)
            onOpened()
        }
    }
    LaunchedEffect(openAssistant) {
        if (openAssistant) {
            vm.loaded.first { it }
            vm.ask("Résumé de ma journée")
            screen = Screen.Assistant
            onAssistantOpened()
        }
    }
    // Navigation demandée à l'assistant (« ouvre la télécommande », « montre l'apparence »…)
    val nav by vm.navigation.collectAsStateWithLifecycle()
    LaunchedEffect(nav) {
        val target = when (nav) {
            "remote" -> if (BuildConfig.AI) Screen.Remote else null
            "devices" -> if (BuildConfig.AI) Screen.Devices.also { devicesBack = Screen.Dashboard } else null
            "appearance" -> Screen.Appearance
            "notes" -> Screen.Home
            "agenda" -> Screen.Calendar
            "contacts" -> Screen.Contacts
            "games" -> Screen.Games
            "settings" -> Screen.Settings
            "home" -> Screen.Dashboard
            else -> null
        }
        if (target != null) screen = target
        if (nav != null) vm.navigation.value = null
    }
    when (val s = screen) {
        Screen.Dashboard -> DashboardScreen(
            vm = vm,
            a = DashboardActions(
                onNotes = { vm.openFolder(null); screen = Screen.Home },
                onNote = { screen = Screen.Edit(it, back = Screen.Dashboard) },
                onNewNote = { screen = Screen.Edit(null, back = Screen.Dashboard) },
                onSearch = { q -> vm.openFolder(null); vm.setQuery(q); screen = Screen.Home },
                onCalendar = { screen = Screen.Calendar },
                onContacts = { screen = Screen.Contacts },
                onAssistant = { screen = Screen.Assistant },
                onRemote = if (BuildConfig.AI) ({ screen = Screen.Remote }) else null,
                onDevices = if (BuildConfig.AI) ({ devicesBack = Screen.Dashboard; screen = Screen.Devices }) else null,
                onGames = { screen = Screen.Games },
                onSettings = { screen = Screen.Settings },
                onAppearance = { screen = Screen.Appearance },
            ),
        )
        Screen.Home -> ListScreen(
            vm = vm,
            onOpen = { screen = Screen.Edit(it) },
            onNew = { screen = Screen.Edit(null, folder = vm.currentFolder.value.orEmpty()) },
            onBack = { vm.setQuery(""); screen = Screen.Dashboard },
        )
        Screen.Games -> GamesScreen(onClose = { screen = Screen.Dashboard })
        Screen.Appearance -> AppearanceScreen(vm = vm, onClose = { screen = Screen.Dashboard })
        Screen.Remote -> RemoteScreen(onClose = { screen = Screen.Dashboard }, onDevices = { devicesBack = Screen.Remote; screen = Screen.Devices })
        Screen.Contacts -> ContactsScreen(
            vm = vm,
            onOpenNote = { screen = Screen.Edit(it, back = Screen.Contacts) },
            onNewNote = { title, text -> screen = Screen.Edit(null, initialText = text, initialTitle = title, back = Screen.Contacts) },
            onClose = { screen = Screen.Dashboard },
        )
        Screen.Assistant -> AssistantScreen(
            vm = vm,
            onOpenNote = { screen = Screen.Edit(it, back = Screen.Assistant) },
            onSearch = { q -> vm.setQuery(q); screen = Screen.Home },
            onCalendar = { screen = Screen.Calendar },
            onClose = { screen = Screen.Dashboard },
        )
        Screen.Calendar -> CalendarScreen(
            vm = vm,
            onOpenNote = { screen = Screen.Edit(it, back = Screen.Calendar) },
            onClose = { screen = Screen.Dashboard },
        )
        Screen.Settings -> SettingsScreen(
            vm = vm,
            onClose = { screen = Screen.Dashboard },
            onGames = { screen = Screen.Games },
            onDevices = { devicesBack = Screen.Settings; screen = Screen.Devices },
            onAppearance = { screen = Screen.Appearance },
        )
        Screen.Devices -> fr.jeremy.calepin.ui.DevicesScreen(onClose = { screen = devicesBack })
        is Screen.Edit -> EditorScreen(
            vm = vm,
            noteId = s.id,
            initialText = s.initialText,
            initialTitle = s.initialTitle,
            initialFolder = s.folder,
            onClose = { screen = s.back },
        )
    }
}
