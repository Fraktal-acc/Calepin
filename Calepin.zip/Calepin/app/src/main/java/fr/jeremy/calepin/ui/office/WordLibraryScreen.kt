package fr.jeremy.calepin.ui.office

import android.app.Activity
import android.content.Context
import android.net.Uri
import android.os.Bundle
import android.os.CancellationSignal
import android.os.ParcelFileDescriptor
import android.print.PageRange
import android.print.PrintAttributes
import android.print.PrintDocumentAdapter
import android.print.PrintDocumentInfo
import android.print.PrintManager
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.DriveFileRenameOutline
import androidx.compose.material.icons.filled.FileOpen
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.PushPin
import androidx.compose.material.icons.filled.SaveAlt
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import fr.jeremy.calepin.Files
import fr.jeremy.calepin.LockGuard
import fr.jeremy.calepin.export.NotePdf
import fr.jeremy.calepin.i18n.I18n
import fr.jeremy.calepin.i18n.RawText
import fr.jeremy.calepin.i18n.Text
import fr.jeremy.calepin.media.Media
import fr.jeremy.calepin.office.word.DocBlock
import fr.jeremy.calepin.office.word.PageSetup
import fr.jeremy.calepin.office.word.WordDoc
import fr.jeremy.calepin.office.word.WordEntry
import fr.jeremy.calepin.office.word.WordLibrary
import fr.jeremy.calepin.office.word.WordTemplate
import fr.jeremy.calepin.text.AutoLayout
import fr.jeremy.calepin.ui.Undo
import fr.jeremy.calepin.ui.appBorder
import fr.jeremy.calepin.ui.bubble
import fr.jeremy.calepin.ui.tools.ToolHint
import fr.jeremy.calepin.ui.tools.ToolScaffold
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

const val DOCX_MIME = "application/vnd.openxmlformats-officedocument.wordprocessingml.document"

/** Types de fichiers proposés à l'import. */
val WORD_IMPORT_TYPES = arrayOf(
    DOCX_MIME, "application/vnd.oasis.opendocument.text", "application/msword",
    "text/plain", "text/markdown", "text/html", "application/octet-stream",
)

/** Outils des documents Word : PDF, impression, partage. */
object WordTools {
    /** PDF du document, avec sa mise en page (format, marges, police, en-tête, pied de page). */
    suspend fun pdf(ctx: Context, id: String, doc: WordDoc, name: String): ByteArray = withContext(Dispatchers.Default) {
        val lib = WordLibrary.get(ctx)
        val md = lib.mediaDir(id)
        val o = AutoLayout.Options(summary = false, guessHeadings = false, typography = false)
        val blocks = ArrayList<AutoLayout.Block>()
        doc.blocks.forEach { b ->
            when (b) {
                is DocBlock.Text -> blocks += AutoLayout.blocks(b.text, o)
                is DocBlock.Table -> blocks += AutoLayout.Block.Table(if (b.header) b.rows.firstOrNull() else null, if (b.header) b.rows.drop(1) else b.rows)
                is DocBlock.Image -> blocks += AutoLayout.Block.Photo(b.file, false, null, b.widthPct)
                is DocBlock.PageBreak -> blocks += AutoLayout.Block.PageBreak
            }
        }
        val pg = doc.page
        val pt = { twips: Int -> twips / 20f }
        val page = NotePdf.DocPage(
            w = pt(pg.widthTwips), h = pt(pg.heightTwips), margin = pt(pg.marginTwips),
            serif = PageSetup.isSerif(pg.font), mono = PageSetup.isMono(pg.font), size = pg.sizePt.toFloat(),
            header = pg.header, footer = pg.footer, pageNumbers = pg.pageNumbers,
        )
        NotePdf.renderDocument(
            AutoLayout.Doc(name, "", emptyList(), blocks), page,
            media = { f -> File(md, f).takeIf { it.exists() }?.let { it to false } },
            thumbnail = { f, v, max -> Media.thumbnail(f, v, max) },
        )
    }

    /** Impression (ou « Enregistrer en PDF ») par Android. */
    fun print(ctx: Context, name: String, bytes: ByteArray) {
        val pm = ctx.getSystemService(Context.PRINT_SERVICE) as? PrintManager ?: return
        pm.print(name, object : PrintDocumentAdapter() {
            override fun onLayout(old: PrintAttributes?, new: PrintAttributes?, cancel: CancellationSignal?, cb: LayoutResultCallback, extras: Bundle?) {
                if (cancel?.isCanceled == true) { cb.onLayoutCancelled(); return }
                cb.onLayoutFinished(PrintDocumentInfo.Builder("$name.pdf").setContentType(PrintDocumentInfo.CONTENT_TYPE_DOCUMENT).build(), true)
            }

            override fun onWrite(pages: Array<out PageRange>?, dest: ParcelFileDescriptor, cancel: CancellationSignal?, cb: WriteResultCallback) {
                runCatching { ParcelFileDescriptor.AutoCloseOutputStream(dest).use { it.write(bytes) } }
                    .onSuccess { cb.onWriteFinished(arrayOf(PageRange.ALL_PAGES)) }
                    .onFailure { cb.onWriteFailed(it.message) }
            }
        }, null)
    }

    fun fileName(name: String, ext: String) = name.replace(Regex("[\\\\/:*?\"<>|]"), "_").trim().ifBlank { "Document" } + "." + ext
}

/**
 * Documents Word du Bureau : créer (vierge ou à partir d'un modèle), importer (.docx, .odt, texte),
 * ouvrir, renommer, dupliquer, partager, exporter en PDF, imprimer, supprimer (avec « Annuler »).
 */
@Composable
fun WordLibraryScreen(onOpen: (String) -> Unit, onClose: () -> Unit) {
    val ctx = LocalContext.current
    val lib = remember { WordLibrary.get(ctx) }
    val items by lib.items.collectAsStateWithLifecycle()
    val scope = rememberCoroutineScope()
    var creating by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf<String?>(null) }
    var query by remember { mutableStateOf("") }
    var renaming by remember { mutableStateOf<WordEntry?>(null) }
    var saving by remember { mutableStateOf<WordEntry?>(null) }

    fun toast(t: String) = I18n.toast(ctx, t, Toast.LENGTH_LONG).show()

    val importer = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        uri ?: return@rememberLauncherForActivityResult
        busy = "Ouverture du document…"
        scope.launch {
            runCatching { lib.import(uri) }
                .onSuccess { busy = null; onOpen(it.id) }
                .onFailure { busy = null; toast(it.message ?: "Document illisible") }
        }
    }
    val saver = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { res ->
        val e = saving; saving = null
        val uri = res.data?.data
        if (res.resultCode == Activity.RESULT_OK && uri != null && e != null) {
            val ok = Files.write(ctx, uri, lib.file(e.id).readBytes())
            toast(if (ok) "Document enregistré" else "Impossible d'écrire le fichier")
        }
    }

    fun shareDocx(e: WordEntry) {
        LockGuard.external()
        Files.shareBytes(ctx, lib.file(e.id).readBytes(), WordTools.fileName(e.name, "docx"), DOCX_MIME)
    }

    fun sharePdf(e: WordEntry) {
        busy = "Création du PDF…"
        scope.launch {
            runCatching { WordTools.pdf(ctx, e.id, lib.open(e.id), e.name) }
                .onSuccess { b -> busy = null; LockGuard.external(); Files.shareBytes(ctx, b, WordTools.fileName(e.name, "pdf"), "application/pdf") }
                .onFailure { busy = null; toast("PDF impossible : " + (it.message ?: "erreur")) }
        }
    }

    ToolScaffold("Documents Word", onClose) {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
            Button(onClick = { creating = true }, modifier = Modifier.weight(1f)) {
                Icon(Icons.Filled.Add, null, Modifier.size(18.dp)); Text(" Nouveau")
            }
            OutlinedButton(onClick = { LockGuard.external(); importer.launch(WORD_IMPORT_TYPES) }, modifier = Modifier.weight(1f)) {
                Icon(Icons.Filled.FileOpen, null, Modifier.size(18.dp)); Text(" Importer")
            }
        }
        busy?.let {
            Row(verticalAlignment = Alignment.CenterVertically) {
                CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp)
                Text("  $it", style = MaterialTheme.typography.bodyMedium)
            }
        }
        if (items.size > 6) {
            OutlinedTextField(query, { query = it }, leadingIcon = { Icon(Icons.Filled.Search, null) }, placeholder = { Text("Chercher un document") },
                singleLine = true, modifier = Modifier.fillMaxWidth())
        }
        val shown = items
            .filter { query.isBlank() || it.name.contains(query, true) || it.preview.contains(query, true) }
            .sortedWith(compareByDescending<WordEntry> { it.pinned }.thenByDescending { it.updated })
        if (items.isEmpty()) {
            ToolHint("Crée un document (lettre, compte rendu, devis…) ou importe un fichier Word (.docx), LibreOffice (.odt) ou texte. " +
                "Il s'ouvre dans un éditeur comme Word : styles, gras, couleurs, listes, tableaux, images, en-tête et pied de page. " +
                "Le document reste un vrai fichier Word, à partager ou à imprimer.")
        }
        shown.forEach { e -> DocCard(e, onOpen = { onOpen(e.id) }, onRename = { renaming = e },
            onDuplicate = { scope.launch { lib.duplicate(e.id)?.let { toast("Copie créée : « ${it.name} »") } } },
            onShare = { shareDocx(e) }, onPdf = { sharePdf(e) },
            onSave = { saving = e; LockGuard.external(); saver.launch(Files.createDocumentIntent(WordTools.fileName(e.name, "docx"), DOCX_MIME)) },
            onPin = { lib.togglePin(e.id) },
            onDelete = {
                val removed = lib.remove(e.id) ?: return@DocCard
                Undo.offer("Document « ${e.name} » supprimé", commit = { lib.purge(e.id) }) { lib.restore(removed) }
            },
        ) }
        if (items.isNotEmpty()) ToolHint("Les documents restent dans Calepin et dans la sauvegarde complète. Tu peux aussi ouvrir un .docx depuis une autre appli avec « Ouvrir avec Calepin ».")
    }

    if (creating) NewDocDialog(onDismiss = { creating = false }) { name, tpl ->
        creating = false
        scope.launch { val e = lib.create(name, tpl); onOpen(e.id) }
    }
    renaming?.let { e ->
        RenameDialog(e.name, onDismiss = { renaming = null }) { lib.rename(e.id, it); renaming = null }
    }
}

@Composable
private fun DocCard(
    e: WordEntry, onOpen: () -> Unit, onRename: () -> Unit, onDuplicate: () -> Unit, onShare: () -> Unit, onPdf: () -> Unit,
    onSave: () -> Unit, onPin: () -> Unit, onDelete: () -> Unit,
) {
    var menu by remember { mutableStateOf(false) }
    val fmt = remember { SimpleDateFormat("d MMM yyyy, HH:mm", Locale.FRANCE) }
    Card(onClick = onOpen, colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer.bubble()), border = appBorder(), modifier = Modifier.fillMaxWidth()) {
        Row(Modifier.padding(start = 14.dp, top = 12.dp, bottom = 12.dp, end = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Filled.Description, null, Modifier.size(34.dp), tint = Color(0xFF2B579A))
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (e.pinned) Icon(Icons.Filled.PushPin, "Épinglé", Modifier.size(14.dp), tint = MaterialTheme.colorScheme.primary)
                    RawText(e.name, style = MaterialTheme.typography.titleSmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
                RawText(fmt.format(Date(e.updated)) + " · " + I18n.trf("{0} mots", e.words), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                if (e.preview.isNotBlank()) RawText(e.preview, style = MaterialTheme.typography.bodySmall, maxLines = 2, overflow = TextOverflow.Ellipsis, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Box {
                IconButton(onClick = { menu = true }) { Icon(Icons.Filled.MoreVert, "Plus d'options") }
                DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                    DropdownMenuItem(text = { Text("Renommer") }, leadingIcon = { Icon(Icons.Filled.DriveFileRenameOutline, null) }, onClick = { menu = false; onRename() })
                    DropdownMenuItem(text = { Text("Dupliquer") }, leadingIcon = { Icon(Icons.Filled.ContentCopy, null) }, onClick = { menu = false; onDuplicate() })
                    DropdownMenuItem(text = { Text("Partager (Word)") }, leadingIcon = { Icon(Icons.Filled.Share, null) }, onClick = { menu = false; onShare() })
                    DropdownMenuItem(text = { Text("Partager en PDF") }, leadingIcon = { Icon(Icons.Filled.PictureAsPdf, null) }, onClick = { menu = false; onPdf() })
                    DropdownMenuItem(text = { Text("Enregistrer sur le téléphone") }, leadingIcon = { Icon(Icons.Filled.SaveAlt, null) }, onClick = { menu = false; onSave() })
                    DropdownMenuItem(text = { Text(if (e.pinned) "Ne plus épingler" else "Épingler en haut") }, leadingIcon = { Icon(Icons.Filled.PushPin, null) }, onClick = { menu = false; onPin() })
                    DropdownMenuItem(text = { Text("Supprimer", color = MaterialTheme.colorScheme.error) }, leadingIcon = { Icon(Icons.Filled.Delete, null, tint = MaterialTheme.colorScheme.error) }, onClick = { menu = false; onDelete() })
                }
            }
        }
    }
}

@Composable
private fun NewDocDialog(onDismiss: () -> Unit, onCreate: (String, WordTemplate) -> Unit) {
    var name by remember { mutableStateOf("") }
    var tpl by remember { mutableStateOf(WordTemplate.VIERGE) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Nouveau document") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                OutlinedTextField(name, { name = it }, label = { Text("Nom du document") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                WordTemplate.entries.forEach { t ->
                    Row(
                        Modifier.fillMaxWidth().padding(vertical = 2.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        androidx.compose.material3.RadioButton(selected = tpl == t, onClick = { tpl = t })
                        Column(Modifier.weight(1f)) {
                            Text(t.label, style = MaterialTheme.typography.bodyLarge)
                            Text(t.hint, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = { onCreate(name.trim(), tpl) }) { Text("Créer") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Annuler") } },
    )
}

@Composable
internal fun RenameDialog(current: String, onDismiss: () -> Unit, onDone: (String) -> Unit) {
    var name by remember { mutableStateOf(current) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Renommer") },
        text = { OutlinedTextField(name, { name = it }, singleLine = true, modifier = Modifier.fillMaxWidth()) },
        confirmButton = { TextButton(enabled = name.isNotBlank(), onClick = { onDone(name.trim()) }) { Text("OK") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Annuler") } },
    )
}

/** Fichier Word ouvert depuis une autre appli : ajouté aux documents ; renvoie son identifiant. */
suspend fun importExternalWord(ctx: Context, uri: Uri): String? = runCatching { WordLibrary.get(ctx).import(uri).id }.getOrNull()
