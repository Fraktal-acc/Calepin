package fr.jeremy.calepin.market

import kotlin.math.abs
import kotlin.math.min

/** Liste d'instruments à passer au crible. [speculative] : très volatils (CFD à effet de levier, petites valeurs…). */
data class Universe(val id: String, val label: String, val instruments: List<Instrument>, val speculative: Boolean = false)

/**
 * Style de trading : durée des bougies analysées, tendance de fond (bougies regroupées), poids de la marge
 * jusqu'à l'objectif (un objectif de 0,3 % compte autant en scalping qu'un objectif de 8 % à moyen terme).
 * [staleSec] : en scalping et day trading, un marché fermé depuis plus longtemps est écarté.
 */
enum class TradingStyle(val label: String, val tf: Timeframe, val htfSeconds: Long, val desc: String, val upsideScale: Double, val staleSec: Long) {
    SCALPING("Scalping", Timeframe.M5, 1_800L, "Bougies de 5 min, tendance sur 30 min : positions de quelques minutes", 25.0, 1_800L),
    DAY("Day trading", Timeframe.M15, 3_600L, "Bougies de 15 min, tendance horaire : positions ouvertes et fermées dans la journée", 10.0, 7_200L),
    SWING("Swing trading", Timeframe.H4, 86_400L, "Bougies de 4 h, tendance quotidienne : positions de quelques jours", 4.0, 0L),
    POSITION("Moyen terme", Timeframe.D1, 604_800L, "Bougies d'un jour, tendance hebdomadaire : positions de plusieurs semaines", 1.5, 0L),
}

/** Sens recherché : achat, vente à découvert (CFD), ou les deux. */
enum class TradeSide(val label: String) {
    BUY("À l'achat"),
    SELL("À la vente (CFD, à découvert)"),
    BOTH("Les deux"),
}

/**
 * Instrument au fort potentiel d'achat trouvé par le détecteur.
 * [potential] : note de 0 à 100 qui combine le score de l'analyse, la confiance (réussite passée des signaux),
 * la marge jusqu'à l'objectif, le rapport gain / risque et les signaux récents du robot.
 */
data class Opportunity(
    val symbol: String,
    val name: String,
    val type: String,
    val price: Double,
    val currency: String,
    val score: Double,
    val confidence: Double,
    val potential: Double,
    /** Hausse possible jusqu'au premier objectif, en % (NaN : pas de plan). */
    val upside: Double,
    /** Baisse jusqu'au stop, en % (NaN : pas de plan). */
    val downside: Double,
    val rr: Double,
    /** Taux de réussite des signaux passés sur cet instrument, en % (NaN : pas assez de recul). */
    val winRate: Double,
    val verdict: String,
    val stop: Double,
    val target: Double,
    /** Ce qui plaide pour l'achat (éléments les plus forts de l'analyse). */
    val reasons: List<String>,
    /** Ce qui freine (éléments défavorables les plus forts). */
    val risks: List<String>,
    val time: Long,
    /** true : à l'achat ; false : à la vente (à découvert, avec un CFD). */
    val buy: Boolean = true,
    /** Style de trading de l'analyse ([TradingStyle] : son nom). */
    val style: String = TradingStyle.POSITION.name,
    /** Volatilité : ATR en % du cours (NaN : inconnue). */
    val atrPct: Double = Double.NaN,
)

/**
 * Détecteur d'opportunités : listes d'instruments proposées, note de potentiel d'achat et classement.
 * Calculs purs (sans réseau) : le téléchargement des cours est fait par [OpportunityScanner].
 */
object Opportunities {
    private fun i(s: String, n: String, e: String, t: String) = Instrument(s, n, e, t)

    val UNIVERSES: List<Universe> = listOf(
        Universe("cac40", "CAC 40", listOf(
            i("AI.PA", "Air Liquide", "Paris", "Action"), i("AIR.PA", "Airbus", "Paris", "Action"), i("ALO.PA", "Alstom", "Paris", "Action"),
            i("MT.AS", "ArcelorMittal", "Amsterdam", "Action"), i("CS.PA", "AXA", "Paris", "Action"), i("BNP.PA", "BNP Paribas", "Paris", "Action"),
            i("EN.PA", "Bouygues", "Paris", "Action"), i("CAP.PA", "Capgemini", "Paris", "Action"), i("CA.PA", "Carrefour", "Paris", "Action"),
            i("ACA.PA", "Crédit Agricole", "Paris", "Action"), i("BN.PA", "Danone", "Paris", "Action"), i("DSY.PA", "Dassault Systèmes", "Paris", "Action"),
            i("EDEN.PA", "Edenred", "Paris", "Action"), i("ENGI.PA", "Engie", "Paris", "Action"), i("EL.PA", "EssilorLuxottica", "Paris", "Action"),
            i("ERF.PA", "Eurofins Scientific", "Paris", "Action"), i("RMS.PA", "Hermès", "Paris", "Action"), i("KER.PA", "Kering", "Paris", "Action"),
            i("OR.PA", "L'Oréal", "Paris", "Action"), i("LR.PA", "Legrand", "Paris", "Action"), i("MC.PA", "LVMH", "Paris", "Action"),
            i("ML.PA", "Michelin", "Paris", "Action"), i("ORA.PA", "Orange", "Paris", "Action"), i("RI.PA", "Pernod Ricard", "Paris", "Action"),
            i("PUB.PA", "Publicis", "Paris", "Action"), i("RNO.PA", "Renault", "Paris", "Action"), i("SAF.PA", "Safran", "Paris", "Action"),
            i("SGO.PA", "Saint-Gobain", "Paris", "Action"), i("SAN.PA", "Sanofi", "Paris", "Action"), i("SU.PA", "Schneider Electric", "Paris", "Action"),
            i("GLE.PA", "Société Générale", "Paris", "Action"), i("STLAP.PA", "Stellantis", "Paris", "Action"), i("STMPA.PA", "STMicroelectronics", "Paris", "Action"),
            i("TEP.PA", "Teleperformance", "Paris", "Action"), i("HO.PA", "Thales", "Paris", "Action"), i("TTE.PA", "TotalEnergies", "Paris", "Action"),
            i("URW.PA", "Unibail-Rodamco-Westfield", "Paris", "Action"), i("VIE.PA", "Veolia", "Paris", "Action"), i("DG.PA", "Vinci", "Paris", "Action"),
            i("VIV.PA", "Vivendi", "Paris", "Action"),
        )),
        Universe("us", "Grandes valeurs US", listOf(
            i("AAPL", "Apple", "Nasdaq", "Action"), i("MSFT", "Microsoft", "Nasdaq", "Action"), i("NVDA", "NVIDIA", "Nasdaq", "Action"),
            i("AMZN", "Amazon", "Nasdaq", "Action"), i("GOOGL", "Alphabet", "Nasdaq", "Action"), i("META", "Meta Platforms", "Nasdaq", "Action"),
            i("TSLA", "Tesla", "Nasdaq", "Action"), i("AVGO", "Broadcom", "Nasdaq", "Action"), i("AMD", "AMD", "Nasdaq", "Action"),
            i("NFLX", "Netflix", "Nasdaq", "Action"), i("ADBE", "Adobe", "Nasdaq", "Action"), i("QCOM", "Qualcomm", "Nasdaq", "Action"),
            i("INTC", "Intel", "Nasdaq", "Action"), i("COST", "Costco", "Nasdaq", "Action"), i("PEP", "PepsiCo", "Nasdaq", "Action"),
            i("JPM", "JPMorgan Chase", "NYSE", "Action"), i("BAC", "Bank of America", "NYSE", "Action"), i("V", "Visa", "NYSE", "Action"),
            i("MA", "Mastercard", "NYSE", "Action"), i("UNH", "UnitedHealth", "NYSE", "Action"), i("LLY", "Eli Lilly", "NYSE", "Action"),
            i("JNJ", "Johnson & Johnson", "NYSE", "Action"), i("XOM", "ExxonMobil", "NYSE", "Action"), i("WMT", "Walmart", "NYSE", "Action"),
            i("PG", "Procter & Gamble", "NYSE", "Action"), i("HD", "Home Depot", "NYSE", "Action"), i("KO", "Coca-Cola", "NYSE", "Action"),
            i("DIS", "Disney", "NYSE", "Action"), i("ORCL", "Oracle", "NYSE", "Action"), i("CRM", "Salesforce", "NYSE", "Action"),
        )),
        Universe("dax", "DAX (Allemagne)", listOf(
            i("SAP.DE", "SAP", "Xetra", "Action"), i("SIE.DE", "Siemens", "Xetra", "Action"), i("ALV.DE", "Allianz", "Xetra", "Action"),
            i("DTE.DE", "Deutsche Telekom", "Xetra", "Action"), i("MBG.DE", "Mercedes-Benz", "Xetra", "Action"), i("BMW.DE", "BMW", "Xetra", "Action"),
            i("BAS.DE", "BASF", "Xetra", "Action"), i("BAYN.DE", "Bayer", "Xetra", "Action"), i("IFX.DE", "Infineon", "Xetra", "Action"),
            i("MUV2.DE", "Munich Re", "Xetra", "Action"), i("DBK.DE", "Deutsche Bank", "Xetra", "Action"), i("ADS.DE", "Adidas", "Xetra", "Action"),
            i("VOW3.DE", "Volkswagen", "Xetra", "Action"), i("RHM.DE", "Rheinmetall", "Xetra", "Action"), i("DHL.DE", "DHL Group", "Xetra", "Action"),
            i("EOAN.DE", "E.ON", "Xetra", "Action"), i("RWE.DE", "RWE", "Xetra", "Action"), i("SHL.DE", "Siemens Healthineers", "Xetra", "Action"),
        )),
        Universe("crypto", "Cryptos", listOf(
            i("BTC-EUR", "Bitcoin", "Crypto", "Crypto"), i("ETH-EUR", "Ethereum", "Crypto", "Crypto"), i("SOL-EUR", "Solana", "Crypto", "Crypto"),
            i("XRP-EUR", "XRP", "Crypto", "Crypto"), i("BNB-EUR", "BNB", "Crypto", "Crypto"), i("ADA-EUR", "Cardano", "Crypto", "Crypto"),
            i("DOGE-EUR", "Dogecoin", "Crypto", "Crypto"), i("AVAX-EUR", "Avalanche", "Crypto", "Crypto"), i("DOT-EUR", "Polkadot", "Crypto", "Crypto"),
            i("LINK-EUR", "Chainlink", "Crypto", "Crypto"),
        )),
        Universe("commo", "Matières premières et indices", listOf(
            i("GC=F", "Or", "COMEX", "Contrat à terme"), i("SI=F", "Argent", "COMEX", "Contrat à terme"), i("CL=F", "Pétrole WTI", "NYMEX", "Contrat à terme"),
            i("BZ=F", "Pétrole Brent", "ICE", "Contrat à terme"), i("NG=F", "Gaz naturel", "NYMEX", "Contrat à terme"), i("HG=F", "Cuivre", "COMEX", "Contrat à terme"),
            i("^FCHI", "CAC 40", "Paris", "Indice"), i("^GSPC", "S&P 500", "US", "Indice"), i("^IXIC", "Nasdaq", "US", "Indice"), i("^GDAXI", "DAX", "Xetra", "Indice"),
        )),
        Universe("fx", "Devises", listOf(
            i("EURUSD=X", "Euro / Dollar", "Devises", "Devise"), i("EURGBP=X", "Euro / Livre", "Devises", "Devise"), i("EURJPY=X", "Euro / Yen", "Devises", "Devise"),
            i("EURCHF=X", "Euro / Franc suisse", "Devises", "Devise"), i("GBPUSD=X", "Livre / Dollar", "Devises", "Devise"), i("USDJPY=X", "Dollar / Yen", "Devises", "Devise"),
        )),
        Universe("cfd_idx", "CFD indices mondiaux", listOf(
            i("^GSPC", "US 500 (S&P 500)", "US", "Indice"), i("^NDX", "US 100 (Nasdaq 100)", "US", "Indice"), i("^DJI", "US 30 (Dow Jones)", "US", "Indice"),
            i("^RUT", "US 2000 (Russell)", "US", "Indice"), i("^GDAXI", "DE 40 (DAX)", "Xetra", "Indice"), i("^FCHI", "FRA 40 (CAC 40)", "Paris", "Indice"),
            i("^FTSE", "UK 100 (FTSE)", "Londres", "Indice"), i("^STOXX50E", "EU 50 (Euro Stoxx)", "Europe", "Indice"), i("^IBEX", "SPA 35 (Ibex)", "Madrid", "Indice"),
            i("FTSEMIB.MI", "ITA 40 (FTSE MIB)", "Milan", "Indice"), i("^SSMI", "SUI 20 (SMI)", "Zurich", "Indice"), i("^N225", "JAP 225 (Nikkei)", "Tokyo", "Indice"),
            i("^HSI", "HK 50 (Hang Seng)", "Hong Kong", "Indice"), i("^AXJO", "AUS 200", "Sydney", "Indice"), i("^VIX", "VIX (volatilité)", "US", "Indice"),
        ), speculative = true),
        Universe("cfd_commo", "CFD matières premières", listOf(
            i("GC=F", "Or", "COMEX", "Contrat à terme"), i("SI=F", "Argent", "COMEX", "Contrat à terme"), i("PL=F", "Platine", "NYMEX", "Contrat à terme"),
            i("PA=F", "Palladium", "NYMEX", "Contrat à terme"), i("HG=F", "Cuivre", "COMEX", "Contrat à terme"), i("CL=F", "Pétrole WTI", "NYMEX", "Contrat à terme"),
            i("BZ=F", "Pétrole Brent", "ICE", "Contrat à terme"), i("NG=F", "Gaz naturel", "NYMEX", "Contrat à terme"), i("ZW=F", "Blé", "CBOT", "Contrat à terme"),
            i("ZC=F", "Maïs", "CBOT", "Contrat à terme"), i("ZS=F", "Soja", "CBOT", "Contrat à terme"), i("KC=F", "Café", "ICE", "Contrat à terme"),
            i("CC=F", "Cacao", "ICE", "Contrat à terme"), i("SB=F", "Sucre", "ICE", "Contrat à terme"),
        ), speculative = true),
        Universe("cfd_fx", "CFD devises (majeures et croisées)", listOf(
            i("EURUSD=X", "EUR/USD", "Devises", "Devise"), i("GBPUSD=X", "GBP/USD", "Devises", "Devise"), i("USDJPY=X", "USD/JPY", "Devises", "Devise"),
            i("USDCHF=X", "USD/CHF", "Devises", "Devise"), i("AUDUSD=X", "AUD/USD", "Devises", "Devise"), i("USDCAD=X", "USD/CAD", "Devises", "Devise"),
            i("NZDUSD=X", "NZD/USD", "Devises", "Devise"), i("EURGBP=X", "EUR/GBP", "Devises", "Devise"), i("EURJPY=X", "EUR/JPY", "Devises", "Devise"),
            i("GBPJPY=X", "GBP/JPY", "Devises", "Devise"), i("EURCHF=X", "EUR/CHF", "Devises", "Devise"), i("AUDJPY=X", "AUD/JPY", "Devises", "Devise"),
            i("USDTRY=X", "USD/TRY", "Devises", "Devise"), i("USDMXN=X", "USD/MXN", "Devises", "Devise"), i("USDZAR=X", "USD/ZAR", "Devises", "Devise"),
        ), speculative = true),
        Universe("spec_us", "Actions spéculatives US", listOf(
            i("PLTR", "Palantir", "Nasdaq", "Action"), i("COIN", "Coinbase", "Nasdaq", "Action"), i("MSTR", "MicroStrategy", "Nasdaq", "Action"),
            i("SMCI", "Super Micro Computer", "Nasdaq", "Action"), i("ARM", "Arm Holdings", "Nasdaq", "Action"), i("IONQ", "IonQ", "NYSE", "Action"),
            i("RIVN", "Rivian", "Nasdaq", "Action"), i("LCID", "Lucid", "Nasdaq", "Action"), i("NIO", "NIO", "NYSE", "Action"),
            i("SOFI", "SoFi", "Nasdaq", "Action"), i("HOOD", "Robinhood", "Nasdaq", "Action"), i("UPST", "Upstart", "Nasdaq", "Action"),
            i("AFRM", "Affirm", "Nasdaq", "Action"), i("MARA", "MARA Holdings", "Nasdaq", "Action"), i("RIOT", "Riot Platforms", "Nasdaq", "Action"),
            i("GME", "GameStop", "NYSE", "Action"), i("AMC", "AMC Entertainment", "NYSE", "Action"), i("SNAP", "Snap", "NYSE", "Action"),
            i("RKLB", "Rocket Lab", "Nasdaq", "Action"), i("SOUN", "SoundHound AI", "Nasdaq", "Action"),
        ), speculative = true),
        Universe("spec_lev", "ETF à effet de levier", listOf(
            i("TQQQ", "Nasdaq 100 x3", "Nasdaq", "ETF"), i("SQQQ", "Nasdaq 100 x-3", "Nasdaq", "ETF"), i("SOXL", "Semi-conducteurs x3", "NYSE", "ETF"),
            i("SOXS", "Semi-conducteurs x-3", "NYSE", "ETF"), i("SPXL", "S&P 500 x3", "NYSE", "ETF"), i("UVXY", "Volatilité VIX x1,5", "NYSE", "ETF"),
            i("LABU", "Biotech x3", "NYSE", "ETF"), i("TNA", "Russell 2000 x3", "NYSE", "ETF"),
        ), speculative = true),
        Universe("spec_crypto", "Cryptos spéculatives", listOf(
            i("SHIB-EUR", "Shiba Inu", "Crypto", "Crypto"), i("LTC-EUR", "Litecoin", "Crypto", "Crypto"), i("TRX-EUR", "Tron", "Crypto", "Crypto"),
            i("NEAR-EUR", "Near", "Crypto", "Crypto"), i("ATOM-EUR", "Cosmos", "Crypto", "Crypto"), i("XLM-EUR", "Stellar", "Crypto", "Crypto"),
            i("BCH-EUR", "Bitcoin Cash", "Crypto", "Crypto"), i("ETC-EUR", "Ethereum Classic", "Crypto", "Crypto"), i("HBAR-EUR", "Hedera", "Crypto", "Crypto"),
            i("ALGO-EUR", "Algorand", "Crypto", "Crypto"),
        ), speculative = true),
    )

    /** Listes qu'on ne connaît qu'au moment de chercher (instruments suivis, tendances du jour en ligne). */
    const val WATCH = "watch"
    const val TRENDING = "trending"
    const val SMALL_CAPS = "small_caps"
    val DYNAMIC = listOf(
        WATCH to "Mes instruments suivis",
        TRENDING to "Tendances du jour (en ligne)",
        SMALL_CAPS to "Petites valeurs agressives (en ligne)",
    )

    /**
     * Note de potentiel d'achat (0 à 100) ; null si l'analyse n'est pas à l'achat.
     * Score de l'analyse (45 %), confiance (35 %), marge jusqu'à l'objectif, rapport gain / risque,
     * et un bonus quand une règle du robot vient de donner un signal d'achat.
     */
    fun potential(r: AnalysisResult, recentBuySignal: Boolean = false, buy: Boolean = true, scale: Double = 1.5): Double? {
        val sc = if (buy) r.score else -r.score
        if (sc <= 0) return null
        val plan = r.plan?.takeIf { it.buy == buy }
        var p = 0.45 * sc + 0.35 * r.confidence
        if (plan != null && plan.entry > 0) {
            val up = abs(plan.target1 - plan.entry) / plan.entry * 100
            p += min(up * scale, 12.0).coerceAtLeast(0.0)
            p += ((plan.rr - 1.3).coerceIn(0.0, 2.0)) * 4
        } else {
            // Pas de plan rentable (objectif trop proche du stop) : potentiel réduit
            p *= 0.7
        }
        if (recentBuySignal) p += 8
        return p.coerceIn(0.0, 100.0)
    }

    /** Opportunité tirée d'une analyse, ou null si l'analyse ne penche pas à l'achat. */
    fun from(
        inst: Instrument, price: Double, currency: String, r: AnalysisResult, now: Long, robotSignal: String? = null,
        style: TradingStyle = TradingStyle.POSITION, buy: Boolean = true,
    ): Opportunity? {
        val pot = potential(r, robotSignal != null, buy, style.upsideScale) ?: return null
        val plan = r.plan?.takeIf { it.buy == buy }
        // Pour une vente, ce sont les éléments défavorables qui plaident
        val sign = if (buy) 1.0 else -1.0
        val pos = r.factors.filter { it.value * sign > 0.15 }.sortedByDescending { it.value * sign * it.weight }
        val neg = r.factors.filter { it.value * sign < -0.15 }.sortedBy { it.value * sign * it.weight }
        val reasons = buildList {
            if (robotSignal != null) add((if (buy) "Signal d'achat" else "Signal de vente") + " récent du robot ($robotSignal)")
            pos.take(4).forEach { add(it.name + " : " + it.detail) }
        }
        return Opportunity(
            symbol = inst.symbol, name = inst.name, type = inst.type, price = price, currency = currency,
            score = r.score, confidence = r.confidence, potential = pot,
            upside = plan?.let { abs(it.target1 - it.entry) / it.entry * 100 } ?: Double.NaN,
            downside = plan?.let { abs(it.entry - it.stop) / it.entry * 100 } ?: Double.NaN,
            rr = plan?.rr ?: 0.0,
            winRate = r.backtest?.takeIf { it.trades >= 5 }?.winRate ?: Double.NaN,
            verdict = r.verdict,
            stop = plan?.stop ?: 0.0, target = plan?.target1 ?: 0.0,
            reasons = reasons, risks = neg.take(2).map { it.name + " : " + it.detail },
            time = now,
            buy = buy, style = style.name,
            atrPct = if (price > 0 && !r.atr.isNaN()) r.atr / price * 100 else Double.NaN,
        )
    }

    /** Classement : meilleur potentiel d'abord ; un instrument n'apparaît qu'une fois. */
    fun rank(list: List<Opportunity>): List<Opportunity> =
        list.groupBy { it.symbol + "|" + it.buy }.values.map { g -> g.maxBy { it.potential } }
            .sortedWith(compareByDescending<Opportunity> { it.potential }.thenByDescending { it.score })

    /** Niveau affiché de la note. */
    fun level(potential: Double): String = when {
        potential >= 75 -> "Très fort potentiel"
        potential >= 60 -> "Fort potentiel"
        potential >= 45 -> "Potentiel intéressant"
        else -> "Potentiel modéré"
    }

    /** Instruments à analyser pour les listes [ids] (sans les doublons). */
    fun instruments(ids: Collection<String>, watch: List<Instrument>, trending: List<Instrument>, smallCaps: List<Instrument> = emptyList()): List<Instrument> {
        val out = LinkedHashMap<String, Instrument>()
        if (WATCH in ids) watch.forEach { out.putIfAbsent(it.symbol, it) }
        UNIVERSES.filter { it.id in ids }.forEach { u -> u.instruments.forEach { out.putIfAbsent(it.symbol, it) } }
        if (TRENDING in ids) trending.forEach { out.putIfAbsent(it.symbol, it) }
        if (SMALL_CAPS in ids) smallCaps.forEach { out.putIfAbsent(it.symbol, it) }
        return out.values.toList()
    }

    /** Marché fermé depuis trop longtemps pour du scalping ou du day trading (dernière bougie trop ancienne). */
    fun stale(style: TradingStyle, lastCandleSec: Long, nowMs: Long): Boolean =
        style.staleSec > 0 && nowMs / 1000 - lastCandleSec > style.staleSec + style.tf.let { if (it.bucket > 0) it.bucket else 0L }

    /** Écart relatif entre deux prix (pour éviter de signaler deux fois la même opportunité). */
    fun moved(a: Double, b: Double): Double = if (a > 0) abs(b - a) / a * 100 else 100.0
}
