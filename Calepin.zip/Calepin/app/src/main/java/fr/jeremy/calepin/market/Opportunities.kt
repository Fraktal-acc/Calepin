package fr.jeremy.calepin.market

import kotlin.math.abs
import kotlin.math.min

/** Liste d'instruments à passer au crible. */
data class Universe(val id: String, val label: String, val instruments: List<Instrument>)

/**
 * Instrument au fort potentiel d'achat trouvé par le détecteur.
 * [potential] : note de 0 à 100 qui combine le score de l'analyse, la confiance (réussite passée des signaux),
 * la marge jusqu'à l'objectif, le rapport gain / risque et les signaux récents du robot.
 */
data class Opportunity(
    val symbol: String,
    val name: String,
    val type: String,
    val price: Double,
    val currency: String,
    val score: Double,
    val confidence: Double,
    val potential: Double,
    /** Hausse possible jusqu'au premier objectif, en % (NaN : pas de plan). */
    val upside: Double,
    /** Baisse jusqu'au stop, en % (NaN : pas de plan). */
    val downside: Double,
    val rr: Double,
    /** Taux de réussite des signaux passés sur cet instrument, en % (NaN : pas assez de recul). */
    val winRate: Double,
    val verdict: String,
    val stop: Double,
    val target: Double,
    /** Ce qui plaide pour l'achat (éléments les plus forts de l'analyse). */
    val reasons: List<String>,
    /** Ce qui freine (éléments défavorables les plus forts). */
    val risks: List<String>,
    val time: Long,
)

/**
 * Détecteur d'opportunités : listes d'instruments proposées, note de potentiel d'achat et classement.
 * Calculs purs (sans réseau) : le téléchargement des cours est fait par [OpportunityScanner].
 */
object Opportunities {
    private fun i(s: String, n: String, e: String, t: String) = Instrument(s, n, e, t)

    val UNIVERSES: List<Universe> = listOf(
        Universe("cac40", "CAC 40", listOf(
            i("AI.PA", "Air Liquide", "Paris", "Action"), i("AIR.PA", "Airbus", "Paris", "Action"), i("ALO.PA", "Alstom", "Paris", "Action"),
            i("MT.AS", "ArcelorMittal", "Amsterdam", "Action"), i("CS.PA", "AXA", "Paris", "Action"), i("BNP.PA", "BNP Paribas", "Paris", "Action"),
            i("EN.PA", "Bouygues", "Paris", "Action"), i("CAP.PA", "Capgemini", "Paris", "Action"), i("CA.PA", "Carrefour", "Paris", "Action"),
            i("ACA.PA", "Crédit Agricole", "Paris", "Action"), i("BN.PA", "Danone", "Paris", "Action"), i("DSY.PA", "Dassault Systèmes", "Paris", "Action"),
            i("EDEN.PA", "Edenred", "Paris", "Action"), i("ENGI.PA", "Engie", "Paris", "Action"), i("EL.PA", "EssilorLuxottica", "Paris", "Action"),
            i("ERF.PA", "Eurofins Scientific", "Paris", "Action"), i("RMS.PA", "Hermès", "Paris", "Action"), i("KER.PA", "Kering", "Paris", "Action"),
            i("OR.PA", "L'Oréal", "Paris", "Action"), i("LR.PA", "Legrand", "Paris", "Action"), i("MC.PA", "LVMH", "Paris", "Action"),
            i("ML.PA", "Michelin", "Paris", "Action"), i("ORA.PA", "Orange", "Paris", "Action"), i("RI.PA", "Pernod Ricard", "Paris", "Action"),
            i("PUB.PA", "Publicis", "Paris", "Action"), i("RNO.PA", "Renault", "Paris", "Action"), i("SAF.PA", "Safran", "Paris", "Action"),
            i("SGO.PA", "Saint-Gobain", "Paris", "Action"), i("SAN.PA", "Sanofi", "Paris", "Action"), i("SU.PA", "Schneider Electric", "Paris", "Action"),
            i("GLE.PA", "Société Générale", "Paris", "Action"), i("STLAP.PA", "Stellantis", "Paris", "Action"), i("STMPA.PA", "STMicroelectronics", "Paris", "Action"),
            i("TEP.PA", "Teleperformance", "Paris", "Action"), i("HO.PA", "Thales", "Paris", "Action"), i("TTE.PA", "TotalEnergies", "Paris", "Action"),
            i("URW.PA", "Unibail-Rodamco-Westfield", "Paris", "Action"), i("VIE.PA", "Veolia", "Paris", "Action"), i("DG.PA", "Vinci", "Paris", "Action"),
            i("VIV.PA", "Vivendi", "Paris", "Action"),
        )),
        Universe("us", "Grandes valeurs US", listOf(
            i("AAPL", "Apple", "Nasdaq", "Action"), i("MSFT", "Microsoft", "Nasdaq", "Action"), i("NVDA", "NVIDIA", "Nasdaq", "Action"),
            i("AMZN", "Amazon", "Nasdaq", "Action"), i("GOOGL", "Alphabet", "Nasdaq", "Action"), i("META", "Meta Platforms", "Nasdaq", "Action"),
            i("TSLA", "Tesla", "Nasdaq", "Action"), i("AVGO", "Broadcom", "Nasdaq", "Action"), i("AMD", "AMD", "Nasdaq", "Action"),
            i("NFLX", "Netflix", "Nasdaq", "Action"), i("ADBE", "Adobe", "Nasdaq", "Action"), i("QCOM", "Qualcomm", "Nasdaq", "Action"),
            i("INTC", "Intel", "Nasdaq", "Action"), i("COST", "Costco", "Nasdaq", "Action"), i("PEP", "PepsiCo", "Nasdaq", "Action"),
            i("JPM", "JPMorgan Chase", "NYSE", "Action"), i("BAC", "Bank of America", "NYSE", "Action"), i("V", "Visa", "NYSE", "Action"),
            i("MA", "Mastercard", "NYSE", "Action"), i("UNH", "UnitedHealth", "NYSE", "Action"), i("LLY", "Eli Lilly", "NYSE", "Action"),
            i("JNJ", "Johnson & Johnson", "NYSE", "Action"), i("XOM", "ExxonMobil", "NYSE", "Action"), i("WMT", "Walmart", "NYSE", "Action"),
            i("PG", "Procter & Gamble", "NYSE", "Action"), i("HD", "Home Depot", "NYSE", "Action"), i("KO", "Coca-Cola", "NYSE", "Action"),
            i("DIS", "Disney", "NYSE", "Action"), i("ORCL", "Oracle", "NYSE", "Action"), i("CRM", "Salesforce", "NYSE", "Action"),
        )),
        Universe("dax", "DAX (Allemagne)", listOf(
            i("SAP.DE", "SAP", "Xetra", "Action"), i("SIE.DE", "Siemens", "Xetra", "Action"), i("ALV.DE", "Allianz", "Xetra", "Action"),
            i("DTE.DE", "Deutsche Telekom", "Xetra", "Action"), i("MBG.DE", "Mercedes-Benz", "Xetra", "Action"), i("BMW.DE", "BMW", "Xetra", "Action"),
            i("BAS.DE", "BASF", "Xetra", "Action"), i("BAYN.DE", "Bayer", "Xetra", "Action"), i("IFX.DE", "Infineon", "Xetra", "Action"),
            i("MUV2.DE", "Munich Re", "Xetra", "Action"), i("DBK.DE", "Deutsche Bank", "Xetra", "Action"), i("ADS.DE", "Adidas", "Xetra", "Action"),
            i("VOW3.DE", "Volkswagen", "Xetra", "Action"), i("RHM.DE", "Rheinmetall", "Xetra", "Action"), i("DHL.DE", "DHL Group", "Xetra", "Action"),
            i("EOAN.DE", "E.ON", "Xetra", "Action"), i("RWE.DE", "RWE", "Xetra", "Action"), i("SHL.DE", "Siemens Healthineers", "Xetra", "Action"),
        )),
        Universe("crypto", "Cryptos", listOf(
            i("BTC-EUR", "Bitcoin", "Crypto", "Crypto"), i("ETH-EUR", "Ethereum", "Crypto", "Crypto"), i("SOL-EUR", "Solana", "Crypto", "Crypto"),
            i("XRP-EUR", "XRP", "Crypto", "Crypto"), i("BNB-EUR", "BNB", "Crypto", "Crypto"), i("ADA-EUR", "Cardano", "Crypto", "Crypto"),
            i("DOGE-EUR", "Dogecoin", "Crypto", "Crypto"), i("AVAX-EUR", "Avalanche", "Crypto", "Crypto"), i("DOT-EUR", "Polkadot", "Crypto", "Crypto"),
            i("LINK-EUR", "Chainlink", "Crypto", "Crypto"),
        )),
        Universe("commo", "Matières premières et indices", listOf(
            i("GC=F", "Or", "COMEX", "Contrat à terme"), i("SI=F", "Argent", "COMEX", "Contrat à terme"), i("CL=F", "Pétrole WTI", "NYMEX", "Contrat à terme"),
            i("BZ=F", "Pétrole Brent", "ICE", "Contrat à terme"), i("NG=F", "Gaz naturel", "NYMEX", "Contrat à terme"), i("HG=F", "Cuivre", "COMEX", "Contrat à terme"),
            i("^FCHI", "CAC 40", "Paris", "Indice"), i("^GSPC", "S&P 500", "US", "Indice"), i("^IXIC", "Nasdaq", "US", "Indice"), i("^GDAXI", "DAX", "Xetra", "Indice"),
        )),
        Universe("fx", "Devises", listOf(
            i("EURUSD=X", "Euro / Dollar", "Devises", "Devise"), i("EURGBP=X", "Euro / Livre", "Devises", "Devise"), i("EURJPY=X", "Euro / Yen", "Devises", "Devise"),
            i("EURCHF=X", "Euro / Franc suisse", "Devises", "Devise"), i("GBPUSD=X", "Livre / Dollar", "Devises", "Devise"), i("USDJPY=X", "Dollar / Yen", "Devises", "Devise"),
        )),
    )

    /** Listes qu'on ne connaît qu'au moment de chercher (instruments suivis, tendances du jour en ligne). */
    const val WATCH = "watch"
    const val TRENDING = "trending"
    val DYNAMIC = listOf(WATCH to "Mes instruments suivis", TRENDING to "Tendances du jour (en ligne)")

    /**
     * Note de potentiel d'achat (0 à 100) ; null si l'analyse n'est pas à l'achat.
     * Score de l'analyse (45 %), confiance (35 %), marge jusqu'à l'objectif, rapport gain / risque,
     * et un bonus quand une règle du robot vient de donner un signal d'achat.
     */
    fun potential(r: AnalysisResult, recentBuySignal: Boolean = false): Double? {
        if (r.score <= 0) return null
        val plan = r.plan?.takeIf { it.buy }
        var p = 0.45 * r.score + 0.35 * r.confidence
        if (plan != null && plan.entry > 0) {
            val up = (plan.target1 - plan.entry) / plan.entry * 100
            p += min(up * 1.5, 12.0).coerceAtLeast(0.0)
            p += ((plan.rr - 1.3).coerceIn(0.0, 2.0)) * 4
        } else {
            // Pas de plan rentable (objectif trop proche du stop) : potentiel réduit
            p *= 0.7
        }
        if (recentBuySignal) p += 8
        return p.coerceIn(0.0, 100.0)
    }

    /** Opportunité tirée d'une analyse, ou null si l'analyse ne penche pas à l'achat. */
    fun from(inst: Instrument, price: Double, currency: String, r: AnalysisResult, now: Long, robotSignal: String? = null): Opportunity? {
        val pot = potential(r, robotSignal != null) ?: return null
        val plan = r.plan?.takeIf { it.buy }
        val pos = r.factors.filter { it.value > 0.15 }.sortedByDescending { it.value * it.weight }
        val neg = r.factors.filter { it.value < -0.15 }.sortedBy { it.value * it.weight }
        val reasons = buildList {
            if (robotSignal != null) add("Signal d'achat récent du robot ($robotSignal)")
            pos.take(4).forEach { add(it.name + " : " + it.detail) }
        }
        return Opportunity(
            symbol = inst.symbol, name = inst.name, type = inst.type, price = price, currency = currency,
            score = r.score, confidence = r.confidence, potential = pot,
            upside = plan?.let { (it.target1 - it.entry) / it.entry * 100 } ?: Double.NaN,
            downside = plan?.let { (it.entry - it.stop) / it.entry * 100 } ?: Double.NaN,
            rr = plan?.rr ?: 0.0,
            winRate = r.backtest?.takeIf { it.trades >= 5 }?.winRate ?: Double.NaN,
            verdict = r.verdict,
            stop = plan?.stop ?: 0.0, target = plan?.target1 ?: 0.0,
            reasons = reasons, risks = neg.take(2).map { it.name + " : " + it.detail },
            time = now,
        )
    }

    /** Classement : meilleur potentiel d'abord ; un instrument n'apparaît qu'une fois. */
    fun rank(list: List<Opportunity>): List<Opportunity> =
        list.groupBy { it.symbol }.values.map { g -> g.maxBy { it.potential } }
            .sortedWith(compareByDescending<Opportunity> { it.potential }.thenByDescending { it.score })

    /** Niveau affiché de la note. */
    fun level(potential: Double): String = when {
        potential >= 75 -> "Très fort potentiel"
        potential >= 60 -> "Fort potentiel"
        potential >= 45 -> "Potentiel intéressant"
        else -> "Potentiel modéré"
    }

    /** Instruments à analyser pour les listes [ids] (sans les doublons). */
    fun instruments(ids: Collection<String>, watch: List<Instrument>, trending: List<Instrument>): List<Instrument> {
        val out = LinkedHashMap<String, Instrument>()
        if (WATCH in ids) watch.forEach { out.putIfAbsent(it.symbol, it) }
        UNIVERSES.filter { it.id in ids }.forEach { u -> u.instruments.forEach { out.putIfAbsent(it.symbol, it) } }
        if (TRENDING in ids) trending.forEach { out.putIfAbsent(it.symbol, it) }
        return out.values.toList()
    }

    /** Écart relatif entre deux prix (pour éviter de signaler deux fois la même opportunité). */
    fun moved(a: Double, b: Double): Double = if (a > 0) abs(b - a) / a * 100 else 100.0
}
