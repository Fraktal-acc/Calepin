package fr.jeremy.calepin.market

import okhttp3.HttpUrl.Companion.toHttpUrl
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/** Instrument suivi (action, indice, devise, crypto, matière première…). */
data class Instrument(val symbol: String, val name: String, val exchange: String = "", val type: String = "")

/** Cours et historique d'un instrument. */
data class Series(
    val symbol: String,
    val name: String,
    val currency: String,
    val price: Double,
    /** Clôture de la veille (pour la variation du jour). */
    val prevClose: Double,
    val time: Long,
    val candles: List<Candle>,
) {
    val change: Double get() = if (prevClose > 0) (price - prevClose) / prevClose * 100 else 0.0
}

/**
 * Cours de bourse gratuits (Yahoo Finance, sans compte) : recherche d'instruments, historique en bougies,
 * taux de change vers l'euro. Les cours peuvent avoir quelques minutes de retard selon la place de cotation.
 */
object MarketData {
    private val http by lazy {
        OkHttpClient.Builder().connectTimeout(10, TimeUnit.SECONDS).readTimeout(15, TimeUnit.SECONDS).build()
    }
    private const val UA = "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Mobile Safari/537.36"

    private fun get(url: String): JSONObject {
        val req = Request.Builder().url(url).header("User-Agent", UA).header("Accept", "application/json").build()
        http.newCall(req).execute().use { r ->
            val body = r.body?.string().orEmpty()
            if (!r.isSuccessful && body.isBlank()) throw java.io.IOException("HTTP ${r.code}")
            return JSONObject(body)
        }
    }

    /** Recherche par nom ou symbole (« apple », « CAC 40 », « bitcoin », « EUR/USD »…). */
    fun search(q: String): List<Instrument> {
        if (q.isBlank()) return emptyList()
        val url = "https://query1.finance.yahoo.com/v1/finance/search".toHttpUrl().newBuilder()
            .addQueryParameter("q", q.trim())
            .addQueryParameter("quotesCount", "15")
            .addQueryParameter("newsCount", "0")
            .addQueryParameter("lang", "fr-FR")
            .build().toString()
        val arr = get(url).optJSONArray("quotes") ?: return emptyList()
        val out = ArrayList<Instrument>()
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            val sym = o.optString("symbol").ifBlank { null } ?: continue
            out += Instrument(
                symbol = sym,
                name = o.optString("longname").ifBlank { o.optString("shortname") }.ifBlank { sym },
                exchange = o.optString("exchDisp").ifBlank { o.optString("exchange") },
                type = typeLabel(o.optString("quoteType")),
            )
        }
        return out
    }

    private fun typeLabel(t: String) = when (t.uppercase()) {
        "EQUITY" -> "Action"
        "ETF" -> "ETF"
        "INDEX" -> "Indice"
        "CURRENCY" -> "Devise"
        "CRYPTOCURRENCY" -> "Crypto"
        "FUTURE" -> "Contrat à terme"
        "MUTUALFUND" -> "Fonds"
        else -> t.lowercase().replaceFirstChar { it.uppercase() }
    }

    /** Historique en bougies : [interval] « 15m », « 60m », « 1d », « 1wk » ; [range] « 1mo », « 1y »… */
    fun series(symbol: String, interval: String = "1d", range: String = "1y"): Series {
        val url = "https://query1.finance.yahoo.com/v8/finance/chart/".toHttpUrl().newBuilder()
            .addPathSegment(symbol)
            .addQueryParameter("interval", interval)
            .addQueryParameter("range", range)
            .addQueryParameter("includePrePost", "false")
            .build().toString()
        val root = get(url).optJSONObject("chart") ?: throw java.io.IOException("Réponse vide")
        root.optJSONObject("error")?.let { throw java.io.IOException(it.optString("description", "Symbole inconnu")) }
        val res = root.optJSONArray("result")?.optJSONObject(0) ?: throw java.io.IOException("Symbole inconnu")
        val meta = res.optJSONObject("meta") ?: JSONObject()
        val ts = res.optJSONArray("timestamp")
        val q = res.optJSONObject("indicators")?.optJSONArray("quote")?.optJSONObject(0)
        val candles = ArrayList<Candle>()
        if (ts != null && q != null) {
            val o = q.optJSONArray("open"); val h = q.optJSONArray("high"); val l = q.optJSONArray("low")
            val c = q.optJSONArray("close"); val v = q.optJSONArray("volume")
            for (i in 0 until ts.length()) {
                val close = c?.optDouble(i, Double.NaN) ?: Double.NaN
                if (close.isNaN()) continue
                fun d(a: org.json.JSONArray?, def: Double) = a?.optDouble(i, def)?.takeIf { !it.isNaN() } ?: def
                candles += Candle(ts.optLong(i), d(o, close), d(h, close), d(l, close), close, d(v, 0.0))
            }
        }
        val price = meta.optDouble("regularMarketPrice", candles.lastOrNull()?.c ?: Double.NaN)
        // Le dernier cours remplace la clôture de la bougie en cours (cours en direct)
        if (candles.isNotEmpty() && !price.isNaN()) {
            val lc = candles.last()
            candles[candles.size - 1] = lc.copy(c = price, h = maxOf(lc.h, price), l = minOf(lc.l, price))
        }
        val prev = when {
            interval == "1d" && candles.size >= 2 -> candles[candles.size - 2].c
            else -> meta.optDouble("previousClose", meta.optDouble("chartPreviousClose", Double.NaN))
        }
        return Series(
            symbol = meta.optString("symbol", symbol),
            name = meta.optString("longName").ifBlank { meta.optString("shortName") }.ifBlank { symbol },
            currency = meta.optString("currency", ""),
            price = if (price.isNaN()) 0.0 else price,
            prevClose = if (prev.isNaN()) 0.0 else prev,
            time = meta.optLong("regularMarketTime", candles.lastOrNull()?.t ?: 0L) * 1000L,
            candles = candles,
        )
    }

    /** Historique avec la durée de bougie d'une règle (les bougies de 4 heures sont faites à partir de celles d'une heure). */
    fun series(symbol: String, tf: Timeframe): Series {
        val s = series(symbol, tf.interval, tf.range)
        return if (tf.bucket > 0) s.copy(candles = Indicators.aggregate(s.candles, tf.bucket)) else s
    }

    private val fxCache = HashMap<String, Pair<Double, Long>>()

    /** Valeur en euros d'une unité de [currency] (1 pour l'euro ; les pence britanniques comptent pour 1/100 de livre). */
    fun fx(currency: String): Double {
        val cur = currency.trim()
        if (cur.isEmpty() || cur.equals("EUR", true)) return 1.0
        if (cur == "GBp" || cur.equals("GBX", true)) return fx("GBP") / 100
        if (cur == "ZAc") return fx("ZAR") / 100
        val key = cur.uppercase()
        synchronized(fxCache) {
            fxCache[key]?.let { (v, at) -> if (System.currentTimeMillis() - at < 3_600_000L) return v }
        }
        // Taux introuvable : 0 (les achats et ventes simulés sont alors reportés)
        val v = runCatching { series("${key}EUR=X", "1d", "5d").price }.getOrNull()?.takeIf { it > 0 } ?: return 0.0
        synchronized(fxCache) { fxCache[key] = v to System.currentTimeMillis() }
        return v
    }
}
