package fr.jeremy.calepin.ui

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.speech.RecognizerIntent
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.VolumeOff
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.AssistChip
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.IconButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import fr.jeremy.calepin.i18n.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import fr.jeremy.calepin.Actions
import fr.jeremy.calepin.LockGuard
import fr.jeremy.calepin.NotesViewModel
import fr.jeremy.calepin.assistant.AssistantAction
import fr.jeremy.calepin.assistant.OfflineListener
import fr.jeremy.calepin.assistant.Speaker
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

private val SUGGESTIONS = listOf(
    "Résumé de ma journée", "Qu'est-ce que j'ai demain ?", "Quand est-ce que je travaille ?",
    "Combien d'heures ce mois-ci ?", "Rappelle-moi dans 10 minutes de", "Nouvelle note", "Aide",
)

/** Assistant : conversation à l'écrit ou à la voix, réponses lues à voix haute, actions dans l'appli. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AssistantScreen(
    vm: NotesViewModel,
    onOpenNote: (Long) -> Unit,
    onSearch: (String) -> Unit,
    onCalendar: () -> Unit,
    onClose: () -> Unit,
) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val chat by vm.chat.collectAsStateWithLifecycle()
    val voiceOn by vm.settings.assistantVoice.collectAsStateWithLifecycle()
    val offlinePref by vm.settings.assistantOffline.collectAsStateWithLifecycle()
    val rate by vm.settings.speechRate.collectAsStateWithLifecycle()
    val directCall by vm.settings.assistantDirectCall.collectAsStateWithLifecycle()
    var input by remember { mutableStateOf("") }
    var listening by remember { mutableStateOf(false) }
    var partial by remember { mutableStateOf("") }
    /** Après une réponse vocale qui attend une suite (« que dois-je noter ? »), on réécoute. */
    var listenAfterSpeech by remember { mutableStateOf(false) }
    var speechFinished by remember { mutableStateOf(0) }
    val listState = rememberLazyListState()

    val speaker = remember { Speaker(ctx) { speechFinished++ } }
    val offline = remember { OfflineListener(ctx) }
    DisposableEffect(Unit) {
        onDispose { speaker.shutdown(); offline.stop() }
    }
    LaunchedEffect(rate) { speaker.rate = rate }
    LaunchedEffect(chat.size) { if (chat.isNotEmpty()) listState.animateScrollToItem(chat.lastIndex) }
    // Réponse de l'IA qui s'écrit : suivre le bas du texte
    val streamingLength = chat.lastOrNull()?.text?.length ?: 0
    LaunchedEffect(streamingLength) { if (chat.isNotEmpty()) listState.scrollToItem(chat.lastIndex, 100_000) }
    BackHandler { onClose() }

    // Appel direct : permission « Téléphone » demandée une fois, sinon on compose seulement le numéro
    var pendingCall by remember { mutableStateOf<String?>(null) }
    val callPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        pendingCall?.let { if (ok) Actions.call(ctx, it) else Actions.dial(ctx, it) }
        pendingCall = null
    }

    fun placeCall(number: String) {
        when {
            !directCall -> Actions.dial(ctx, number)
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED ->
                Actions.call(ctx, number)
            else -> {
                pendingCall = number
                LockGuard.external()
                callPermission.launch(Manifest.permission.CALL_PHONE)
            }
        }
    }

    fun addToPhoneCalendar(a: AssistantAction.PhoneCalendar) {
        Actions.addEvent(ctx, a.title, "", a.start, !a.allDay, null, a.end.takeIf { it > a.start })
    }

    suspend fun runActions(actions: List<AssistantAction>, afterSpeech: Boolean) {
        actions.forEach { a ->
            when (a) {
                is AssistantAction.Dial -> {
                    if (afterSpeech) delay(1600) // laisser dire « J'appelle Marc » avant l'appel
                    placeCall(a.number)
                }
                is AssistantAction.PhoneCalendar -> if (a.auto) addToPhoneCalendar(a)
                is AssistantAction.Sms -> Actions.sms(ctx, a.number)
                is AssistantAction.Directions -> Actions.directions(ctx, a.address)
                is AssistantAction.OpenNote -> Unit // proposé sous la réponse plutôt qu'ouvert d'office
                else -> Unit
            }
        }
    }

    var lastActions by remember { mutableStateOf<List<AssistantAction>>(emptyList()) }
    var startListening: () -> Unit = {}

    /** [french] : commande française déjà connue (suggestion touchée), exécutée sans passer par l'IA. */
    fun send(text: String, byVoice: Boolean, french: String? = null) {
        val t = text.trim()
        if (t.isEmpty()) return
        input = ""
        scope.launch {
            val r = vm.ask(t, french)
            lastActions = r.actions
            val again = byVoice && r.actions.any { it is AssistantAction.ListenAgain }
            if (voiceOn) {
                listenAfterSpeech = again
                speaker.speak(r.text)
            } else if (again) {
                startListening()
            }
            runActions(r.actions, afterSpeech = voiceOn)
        }
    }

    val googleSpeech = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { res ->
        listening = false
        val text = res.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
        if (res.resultCode == Activity.RESULT_OK && !text.isNullOrBlank()) send(text, byVoice = true)
    }

    fun listenWithPhone() {
        LockGuard.external()
        try {
            listening = true
            googleSpeech.launch(
                Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE, fr.jeremy.calepin.i18n.I18n.language.value.speechTag)
                    putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
                    putExtra(RecognizerIntent.EXTRA_PROMPT, fr.jeremy.calepin.i18n.I18n.tr("Je t'écoute"))
                }
            )
        } catch (e: Exception) {
            listening = false
            fr.jeremy.calepin.i18n.I18n.toast(ctx, "Aucune reconnaissance vocale sur ce téléphone", Toast.LENGTH_LONG).show()
        }
    }

    fun listenOffline() {
        speaker.stop()
        listening = true
        partial = ""
        scope.launch {
            try {
                offline.start(
                    onPartial = { partial = it },
                    onResult = { listening = false; partial = ""; send(it, byVoice = true) },
                    onError = { listening = false; partial = ""; fr.jeremy.calepin.i18n.I18n.toast(ctx, it, Toast.LENGTH_SHORT).show() },
                )
            } catch (e: Throwable) {
                listening = false
                fr.jeremy.calepin.i18n.I18n.toast(ctx, "Écoute hors ligne impossible : ${e.message}", Toast.LENGTH_LONG).show()
            }
        }
    }

    val micPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) listenOffline() else fr.jeremy.calepin.i18n.I18n.toast(ctx, "Autorisez le micro pour parler à l'assistant", Toast.LENGTH_LONG).show()
    }

    startListening = {
        speaker.stop()
        if (offlinePref && offline.available) {
            if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) listenOffline()
            else { LockGuard.external(); micPermission.launch(Manifest.permission.RECORD_AUDIO) }
        } else {
            listenWithPhone()
        }
    }

    // Réécoute automatique à la fin de la réponse parlée, si l'assistant attend une suite
    LaunchedEffect(speechFinished) {
        if (listenAfterSpeech) { listenAfterSpeech = false; startListening() }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Assistant") },
                navigationIcon = { IconButton(onClick = onClose) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Retour") } },
                actions = {
                    IconButton(onClick = { vm.settings.setAssistantVoice(!voiceOn); if (voiceOn) speaker.stop() }) {
                        Icon(
                            if (voiceOn) Icons.Filled.VolumeUp else Icons.Filled.VolumeOff,
                            if (voiceOn) "Couper la voix" else "Réponses à voix haute",
                        )
                    }
                    IconButton(onClick = { vm.clearChat() }) { Icon(Icons.Filled.DeleteSweep, "Effacer la conversation") }
                },
            )
        },
    ) { pad ->
        Column(
            Modifier
                .fillMaxSize()
                .padding(pad)
                .imePadding(),
        ) {
            LazyColumn(
                state = listState,
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                contentPadding = androidx.compose.foundation.layout.PaddingValues(12.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                itemsIndexed(chat) { i, msg ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = if (msg.fromUser) Arrangement.End else Arrangement.Start) {
                        Surface(
                            shape = RoundedCornerShape(
                                topStart = 16.dp, topEnd = 16.dp,
                                bottomStart = if (msg.fromUser) 16.dp else 4.dp, bottomEnd = if (msg.fromUser) 4.dp else 16.dp,
                            ),
                            color = if (msg.fromUser) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceContainer,
                            border = appBorder(),
                            modifier = Modifier.widthIn(max = 320.dp),
                        ) {
                            Column(Modifier.padding(horizontal = 12.dp, vertical = 8.dp)) {
                                SelectionContainer {
                                    // Le message d'accueil est traduit ; les autres sont déjà dans la bonne langue (ou écrits par toi)
                                    if (i == 0) Text(msg.text, style = MaterialTheme.typography.bodyMedium)
                                    else fr.jeremy.calepin.i18n.RawText(msg.text, style = MaterialTheme.typography.bodyMedium)
                                }
                                // Raccourcis sous la dernière réponse
                                if (!msg.fromUser && i == chat.lastIndex) {
                                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                        lastActions.forEach { a ->
                                            when (a) {
                                                is AssistantAction.OpenNote -> TextButton(onClick = { onOpenNote(a.id) }) { Text("Ouvrir la note") }
                                                is AssistantAction.Search -> TextButton(onClick = { onSearch(a.query) }) { Text("Voir les notes") }
                                                AssistantAction.OpenCalendar -> TextButton(onClick = onCalendar) { Text("Ouvrir l'agenda") }
                                                is AssistantAction.PhoneCalendar -> if (!a.auto) {
                                                    TextButton(onClick = { addToPhoneCalendar(a) }) { Text("Agenda du téléphone") }
                                                }
                                                is AssistantAction.Dial -> TextButton(onClick = { placeCall(a.number) }) { Text("Rappeler") }
                                                else -> Unit
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                if (listening && partial.isNotBlank()) {
                    item {
                        Text(
                            "« $partial… »",
                            fontStyle = FontStyle.Italic,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.fillMaxWidth(),
                        )
                    }
                }
            }

            // Calepin IA : arrêter une réponse en cours
            val aiWorking by vm.aiWorking.collectAsStateWithLifecycle()
            if (aiWorking) {
                TextButton(onClick = { vm.stopAi() }, modifier = Modifier.padding(horizontal = 8.dp)) {
                    Text("■ Arrêter la réponse")
                }
            }

            // Suggestions
            Row(
                Modifier
                    .horizontalScroll(rememberScrollState())
                    .padding(horizontal = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
            ) {
                SUGGESTIONS.forEach { sug ->
                    val shown = fr.jeremy.calepin.i18n.tr(sug)
                    AssistChip(onClick = {
                        if (sug.endsWith(" de")) input = "$shown " else send(shown, byVoice = false, french = sug)
                    }, label = { fr.jeremy.calepin.i18n.RawText(shown) })
                }
            }

            Surface(tonalElevation = 2.dp) {
                Row(
                    Modifier
                        .fillMaxWidth()
                        .navigationBarsPadding()
                        .padding(8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    OutlinedTextField(
                        value = input,
                        onValueChange = { input = it },
                        placeholder = { Text(if (listening) "J'écoute…" else "Écris ou touche le micro") },
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(24.dp),
                        maxLines = 4,
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                        keyboardActions = KeyboardActions(onSend = { send(input, byVoice = false) }),
                    )
                    Spacer(Modifier.size(6.dp))
                    if (input.isNotBlank()) {
                        FilledIconButton(onClick = { send(input, byVoice = false) }) {
                            Icon(Icons.AutoMirrored.Filled.Send, "Envoyer")
                        }
                    } else {
                        FilledIconButton(
                            onClick = { if (listening) { offline.stop(); listening = false } else startListening() },
                            modifier = Modifier.size(52.dp),
                            colors = if (listening) IconButtonDefaults.filledIconButtonColors(
                                containerColor = MaterialTheme.colorScheme.error,
                            ) else IconButtonDefaults.filledIconButtonColors(),
                        ) {
                            Icon(if (listening) Icons.Filled.Stop else Icons.Filled.Mic, if (listening) "Arrêter l'écoute" else "Parler")
                        }
                    }
                }
            }
            if (offlinePref && !offline.available) {
                Box(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp)) {
                    Text(
                        "Écoute hors ligne : installe le module vocal de la langue dans Paramètres (sinon la reconnaissance du téléphone est utilisée).",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
        }
    }
}
