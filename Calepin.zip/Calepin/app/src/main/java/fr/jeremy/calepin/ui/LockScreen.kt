package fr.jeremy.calepin.ui

import android.content.Context
import android.os.Build
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricManager.Authenticators.BIOMETRIC_WEAK
import androidx.biometric.BiometricManager.Authenticators.DEVICE_CREDENTIAL
import androidx.biometric.BiometricPrompt
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Backspace
import androidx.compose.material.icons.filled.Fingerprint
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import fr.jeremy.calepin.i18n.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity
import fr.jeremy.calepin.AppSettings
import kotlinx.coroutines.delay

/** Empreinte digitale / visage via l'API officielle d'Android. */
object Bio {
    /** Le téléphone a une empreinte ou un visage enregistré, utilisable par les applis. */
    fun available(ctx: Context): Boolean =
        BiometricManager.from(ctx).canAuthenticate(BIOMETRIC_WEAK) == BiometricManager.BIOMETRIC_SUCCESS

    /** Repli possible sur le code de verrouillage du téléphone (Android 11 et plus). */
    fun deviceCredentialFallback(ctx: Context): Boolean =
        Build.VERSION.SDK_INT >= 30 &&
            BiometricManager.from(ctx).canAuthenticate(DEVICE_CREDENTIAL) == BiometricManager.BIOMETRIC_SUCCESS

    fun prompt(
        activity: FragmentActivity,
        pinAlsoEnabled: Boolean,
        onSuccess: () -> Unit,
        onFail: (String) -> Unit,
    ) {
        val bioOk = available(activity)
        val credOk = !pinAlsoEnabled && deviceCredentialFallback(activity)
        if (!bioOk && !credOk) {
            onFail("Aucune empreinte ni visage enregistré sur ce téléphone.")
            return
        }
        val builder = BiometricPrompt.PromptInfo.Builder()
            .setTitle(fr.jeremy.calepin.i18n.I18n.tr("Déverrouiller Calepin"))
            .setSubtitle(fr.jeremy.calepin.i18n.I18n.tr(if (bioOk) "Empreinte digitale ou visage" else "Code de verrouillage du téléphone"))
        when {
            credOk -> builder.setAllowedAuthenticators((if (bioOk) BIOMETRIC_WEAK else 0) or DEVICE_CREDENTIAL)
            else -> builder.setAllowedAuthenticators(BIOMETRIC_WEAK)
                .setNegativeButtonText(fr.jeremy.calepin.i18n.I18n.tr(if (pinAlsoEnabled) "Utiliser le code PIN" else "Annuler"))
        }
        val prompt = BiometricPrompt(
            activity,
            ContextCompat.getMainExecutor(activity),
            object : BiometricPrompt.AuthenticationCallback() {
                override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) = onSuccess()
                override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                    if (errorCode != BiometricPrompt.ERROR_NEGATIVE_BUTTON && errorCode != BiometricPrompt.ERROR_USER_CANCELED) {
                        onFail(errString.toString())
                    }
                }
            },
        )
        prompt.authenticate(builder.build())
    }
}

@Composable
fun LockScreen(settings: AppSettings, onUnlocked: () -> Unit) {
    val ctx = LocalContext.current
    val activity = ctx as? FragmentActivity
    val pinOn = settings.pinEnabled.value
    val bioOn = settings.bioEnabled.value
    var entered by remember { mutableStateOf("") }
    var message by remember { mutableStateOf<String?>(null) }
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    val waitUntil = settings.lockedUntil
    val waiting = waitUntil > now

    LaunchedEffect(waiting) {
        while (settings.lockedUntil > System.currentTimeMillis()) {
            now = System.currentTimeMillis(); delay(500)
        }
        now = System.currentTimeMillis()
    }

    fun askBio() {
        if (activity != null) Bio.prompt(activity, pinOn, onSuccess = onUnlocked, onFail = { message = it })
    }
    LaunchedEffect(Unit) { if (bioOn) askBio() }

    fun tryPin(pin: String) {
        if (settings.checkPin(pin)) {
            settings.failedAttempts = 0
            onUnlocked()
        } else {
            val fails = settings.failedAttempts + 1
            settings.failedAttempts = fails
            entered = ""
            if (fails >= 5) {
                settings.lockedUntil = System.currentTimeMillis() + 30_000
                settings.failedAttempts = 0
                now = System.currentTimeMillis()
                message = "Trop d'essais. Patientez 30 secondes."
            } else {
                message = "Code incorrect (${5 - fails} essai${if (5 - fails > 1) "s" else ""} avant attente)"
            }
        }
    }

    Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
        Column(
            Modifier
                .fillMaxSize()
                .systemBarsPadding()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
        ) {
            Icon(Icons.Filled.Lock, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(40.dp))
            Spacer(Modifier.height(12.dp))
            Text("Calepin est verrouillé", style = MaterialTheme.typography.headlineSmall)
            Spacer(Modifier.height(6.dp))
            Text(
                when {
                    pinOn && bioOn -> "Code PIN, empreinte ou visage"
                    pinOn -> "Saisissez votre code PIN"
                    else -> "Empreinte digitale ou visage"
                },
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Spacer(Modifier.height(24.dp))

            if (pinOn) {
                Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                    repeat(maxOf(4, entered.length)) { i ->
                        Box(
                            Modifier
                                .size(14.dp)
                                .then(
                                    if (i < entered.length) Modifier.background(MaterialTheme.colorScheme.primary, CircleShape)
                                    else Modifier.border(1.5.dp, MaterialTheme.colorScheme.outline, CircleShape)
                                ),
                        )
                    }
                }
                Spacer(Modifier.height(10.dp))
            }
            Text(
                if (waiting) "Patientez ${((waitUntil - now) / 1000) + 1} s" else message ?: " ",
                color = MaterialTheme.colorScheme.error,
                style = MaterialTheme.typography.bodyMedium,
            )
            Spacer(Modifier.height(16.dp))

            if (pinOn) {
                val keys = listOf("1", "2", "3", "4", "5", "6", "7", "8", "9", "bio", "0", "del")
                keys.chunked(3).forEach { row ->
                    Row(horizontalArrangement = Arrangement.spacedBy(18.dp), modifier = Modifier.padding(vertical = 7.dp)) {
                        row.forEach { k ->
                            Box(Modifier.size(72.dp), contentAlignment = Alignment.Center) {
                                when (k) {
                                    "bio" -> if (bioOn) {
                                        IconButton(onClick = { askBio() }, modifier = Modifier.size(64.dp)) {
                                            Icon(Icons.Filled.Fingerprint, "Empreinte ou visage", modifier = Modifier.size(32.dp))
                                        }
                                    }
                                    "del" -> IconButton(onClick = { entered = entered.dropLast(1) }, modifier = Modifier.size(64.dp)) {
                                        Icon(Icons.Filled.Backspace, "Effacer")
                                    }
                                    else -> FilledTonalButton(
                                        onClick = {
                                            if (!waiting && entered.length < 8) {
                                                entered += k
                                                message = null
                                                if (entered.length >= 4 && settings.checkPin(entered)) tryPin(entered)
                                            }
                                        },
                                        shape = CircleShape,
                                        modifier = Modifier.size(68.dp),
                                        enabled = !waiting,
                                    ) { Text(k, fontSize = 24.sp, fontWeight = FontWeight.Medium) }
                                }
                            }
                        }
                    }
                }
                Spacer(Modifier.height(8.dp))
                TextButton(onClick = { if (entered.length >= 4) tryPin(entered) }, enabled = !waiting && entered.length >= 4) {
                    Text("Valider")
                }
            } else {
                FilledTonalButton(onClick = { askBio() }) {
                    Icon(Icons.Filled.Fingerprint, contentDescription = null)
                    Text("  Déverrouiller")
                }
            }
        }
    }
}
