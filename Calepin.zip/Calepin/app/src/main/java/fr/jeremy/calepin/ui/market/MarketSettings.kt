package fr.jeremy.calepin.ui.market

import android.Manifest
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import fr.jeremy.calepin.i18n.Text
import fr.jeremy.calepin.market.Market

/** Paramètres → Bourse : robot en marche ou à l'arrêt, fréquence des vérifications, économie de batterie. */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun MarketSettings() {
    val ctx = LocalContext.current
    remember { Market.init(ctx); true }
    val on by Market.robotOn.collectAsStateWithLifecycle()
    val every by Market.every.collectAsStateWithLifecycle()
    val saver by Market.batterySaver.collectAsStateWithLifecycle()
    val rules by Market.rules.collectAsStateWithLifecycle()
    val notifPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    Column(verticalArrangement = Arrangement.spacedBy(10.dp())) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("Robot de bourse", style = MaterialTheme.typography.bodyLarge)
                Text(
                    if (on) "En marche : il vérifie tes règles en arrière-plan (${rules.count { it.enabled }} règle(s) active(s))"
                    else "À l'arrêt : aucune vérification en arrière-plan, aucune consommation de batterie",
                    style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            Switch(checked = on, onCheckedChange = {
                Market.setRobot(ctx, it)
                if (it && Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
                    fr.jeremy.calepin.LockGuard.external()
                    notifPerm.launch(Manifest.permission.POST_NOTIFICATIONS)
                }
            })
        }
        if (on) {
            Text("Vérification toutes les :", style = MaterialTheme.typography.bodyMedium)
            FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp())) {
                listOf(5 to "5 min", 15 to "15 min", 30 to "30 min", 60 to "1 h", 240 to "4 h", 1440 to "1 jour").forEach { (m, label) ->
                    FilterChip(selected = every == m, onClick = { Market.setEvery(ctx, m) }, label = { Text(label) })
                }
            }
            Text("Plus c'est espacé, moins le robot consomme de batterie et de données.", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Pause quand la batterie est faible", style = MaterialTheme.typography.bodyLarge)
                    Text("Sous 20 % (hors charge) ou en mode économie d'énergie, le robot ne vérifie plus jusqu'à ce que la batterie remonte", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                Switch(checked = saver, onCheckedChange = { Market.setBatterySaver(ctx, it) })
            }
        }
    }
}

private fun Int.dp() = androidx.compose.ui.unit.Dp(this.toFloat())
