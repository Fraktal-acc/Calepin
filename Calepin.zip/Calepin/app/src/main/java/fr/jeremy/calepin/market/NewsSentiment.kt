package fr.jeremy.calepin.market

import java.text.Normalizer
import java.text.SimpleDateFormat
import java.util.Locale
import kotlin.math.exp

/** Une actualité sur un instrument. [score] : de -1 (mauvaise nouvelle) à +1 (bonne nouvelle). */
data class NewsItem(val title: String, val source: String, val link: String, val time: Long, val score: Double)

/** Ton général des actualités récentes ([score] de -1 à +1, les plus récentes comptent plus). */
data class NewsTone(val items: List<NewsItem>, val score: Double, val positive: Int, val negative: Int, val recent: Int)

/**
 * Lecture des actualités : flux RSS, ton de chaque titre (mots et expressions de la bourse, en français
 * et en anglais), ton général pondéré par la fraîcheur.
 */
object NewsText {
    private fun norm(s: String): String =
        Normalizer.normalize(s.lowercase(Locale.ROOT), Normalizer.Form.NFD).replace(Regex("\\p{Mn}+"), "")
            .replace('’', '\'')

    // Expressions (plus fiables que les mots seuls), puis mots
    private val POS_PHRASES = listOf(
        "depasse les attentes", "superieur aux attentes", "au-dessus des attentes", "releve ses objectifs", "releve sa prevision",
        "rehausse ses objectifs", "releve sa recommandation", "a l'achat", "objectif de cours releve", "rachat d'actions",
        "hausse du dividende", "benefice en hausse", "chiffre d'affaires en hausse", "resultats solides", "plus haut historique",
        "beats estimates", "beat estimates", "tops estimates", "raises guidance", "raised guidance", "price target raised",
        "upgraded to buy", "share buyback", "record high", "all-time high", "better than expected", "strong demand",
    )
    private val NEG_PHRASES = listOf(
        "en deca des attentes", "inferieur aux attentes", "sous les attentes", "abaisse ses objectifs", "abaisse sa prevision",
        "abaisse sa recommandation", "a la vente", "objectif de cours abaisse", "avertissement sur resultats", "profit warning",
        "perte nette", "plan social", "plus bas annuel", "misses estimates", "missed estimates", "cuts guidance", "cut guidance",
        "lowered guidance", "price target cut", "downgraded to sell", "worse than expected", "weak demand", "sell-off", "selloff",
    )
    private val POS_WORDS = setOf(
        "hausse", "hausses", "bondit", "bond", "grimpe", "grimpent", "progresse", "progression", "envole", "envolee", "record", "records",
        "rebond", "rebondit", "releve", "rehausse", "surperforme", "optimiste", "optimisme", "solide", "solides", "croissance",
        "dividende", "accord", "contrat", "succes", "approbation", "approuve", "acquisition", "benefice", "benefices", "embellie",
        "reprise", "soutien", "favorable", "ameliore", "amelioration", "gagne", "gain", "gains", "flambe",
        "surge", "surges", "soar", "soars", "jump", "jumps", "rally", "rallies", "gain", "gains", "rise", "rises", "rising",
        "beat", "beats", "upgrade", "upgrades", "upgraded", "bullish", "outperform", "strong", "growth", "profit", "profits", "boost", "boosts",
        "record", "approval", "approved", "deal", "wins", "rebound", "rebounds", "recovery", "higher",
    )
    private val NEG_WORDS = setOf(
        "baisse", "baisses", "chute", "chutent", "plonge", "plongent", "recule", "reculent", "recul", "degringole", "effondre",
        "effondrement", "perte", "pertes", "abaisse", "avertissement", "decoit", "decevant", "decevants", "decue", "enquete", "amende",
        "proces", "plainte", "faillite", "licenciements", "greve", "crise", "recession", "sanction", "sanctions", "guerre", "menace",
        "menaces", "degradation", "degrade", "rappel", "piratage", "cyberattaque", "panne", "deficit", "endettement", "pessimiste",
        "inquietude", "inquietudes", "craintes", "crainte", "tensions", "repli", "glisse", "lourd", "lourde", "sombre",
        "plunge", "plunges", "fall", "falls", "drop", "drops", "slump", "slumps", "tumble", "tumbles", "miss", "misses", "downgrade",
        "downgrades", "downgraded", "lawsuit", "probe", "investigation", "bankruptcy", "layoffs", "recall", "warning", "bearish", "weak",
        "loss", "losses", "decline", "declines", "fears", "fear", "crash", "lower", "slides", "slide", "sinks", "sink", "concerns",
    )

    private val NEGATIONS = setOf("pas", "sans", "aucun", "aucune", "no", "not", "without", "never", "jamais")

    /** Ton d'un titre : -1 à +1 (0 si rien de net). */
    fun scoreTitle(title: String): Double {
        val t = " " + norm(title).replace(Regex("[^a-z0-9%' -]"), " ") + " "
        var pos = 0.0
        var neg = 0.0
        POS_PHRASES.forEach { if (t.contains(it)) pos += 2 }
        NEG_PHRASES.forEach { if (t.contains(it)) neg += 2 }
        val words = t.split(Regex("[\\s']+")).filter { it.isNotBlank() }
        words.forEachIndexed { i, w ->
            // Négation juste avant (« pas de hausse », « no gain », « sans rebond »)
            val negated = (1..2).any { k -> i - k >= 0 && words[i - k] in NEGATIONS }
            if (w in POS_WORDS) { if (negated) neg += 1 else pos += 1 }
            if (w in NEG_WORDS) { if (negated) pos += 0.5 else neg += 1 }
        }
        // Pourcentages : « +5 % » / « -3 % »
        Regex("([+-])\\s?\\d+(?:[.,]\\d+)?\\s?%").findAll(t).forEach { m -> if (m.groupValues[1] == "+") pos += 1 else neg += 1 }
        if (pos + neg == 0.0) return 0.0
        return ((pos - neg) / (pos + neg)).coerceIn(-1.0, 1.0)
    }

    /** Ton général : moyenne pondérée par la fraîcheur (une nouvelle de 36 h compte deux fois moins qu'une nouvelle d'il y a 1 h). */
    fun tone(items: List<NewsItem>, now: Long = System.currentTimeMillis()): NewsTone {
        var sw = 0.0
        var s = 0.0
        var recent = 0
        for (it in items) {
            val ageH = ((now - it.time).coerceAtLeast(0L)) / 3_600_000.0
            if (ageH < 48) recent++
            val w = exp(-ageH / 52.0) * (if (it.score == 0.0) 0.3 else 1.0)
            s += it.score * w
            sw += w
        }
        val score = if (sw > 0) (s / sw).coerceIn(-1.0, 1.0) else 0.0
        return NewsTone(items, score, items.count { it.score >= 0.3 }, items.count { it.score <= -0.3 }, recent)
    }

    private fun unescape(s: String) = s.replace("<![CDATA[", "").replace("]]>", "")
        .replace("&amp;", "&").replace("&quot;", "\"").replace("&#39;", "'").replace("&apos;", "'")
        .replace("&lt;", "<").replace("&gt;", ">").replace("&nbsp;", " ").replace(Regex("<[^>]+>"), "").trim()

    private fun tag(block: String, name: String): String? =
        Regex("<$name(?:\\s[^>]*)?>([\\s\\S]*?)</$name>", RegexOption.IGNORE_CASE).find(block)?.groupValues?.get(1)?.let { unescape(it) }

    private val RSS_DATES = listOf("EEE, dd MMM yyyy HH:mm:ss zzz", "EEE, dd MMM yyyy HH:mm:ss Z", "EEE, d MMM yyyy HH:mm:ss zzz")

    private fun date(s: String?): Long {
        if (s.isNullOrBlank()) return 0L
        for (p in RSS_DATES) {
            runCatching { return SimpleDateFormat(p, Locale.ENGLISH).parse(s.trim())!!.time }
        }
        return 0L
    }

    /** Articles d'un flux RSS (Google Actualités, Yahoo…). */
    fun parseRss(xml: String, defaultSource: String): List<NewsItem> =
        Regex("<item>([\\s\\S]*?)</item>", RegexOption.IGNORE_CASE).findAll(xml).mapNotNull { m ->
            val b = m.groupValues[1]
            var title = tag(b, "title") ?: return@mapNotNull null
            val source = tag(b, "source") ?: defaultSource
            // Google Actualités ajoute « - Source » à la fin du titre
            if (source.isNotBlank() && title.endsWith(" - $source")) title = title.removeSuffix(" - $source")
            val link = tag(b, "link").orEmpty()
            NewsItem(title, source, link, date(tag(b, "pubDate")), scoreTitle(title))
        }.toList()

    /** Nom utilisable pour chercher des actualités (« Apple Inc. » → « Apple », « Brent Oil (Derivatives) USD » → « Brent Oil »). */
    fun queryName(name: String, symbol: String): String {
        var n = name.replace(Regex("\\(.*?\\)"), " ")
            .replace(Regex("\\b(Inc|Corp|Corporation|Ltd|PLC|S\\.?A|SE|N\\.?V|AG|Holdings?|Group|Company|Co|USD|EUR|Futures?)\\b\\.?", RegexOption.IGNORE_CASE), " ")
            .replace(Regex("[,.]"), " ").replace(Regex("\\s+"), " ").trim()
        if (n.length < 2) n = symbol.substringBefore('.').substringBefore('=').trimStart('^')
        return n
    }

    /** Doublons (même titre dans plusieurs sources) retirés, plus récents d'abord. */
    fun dedupe(items: List<NewsItem>): List<NewsItem> {
        val seen = HashSet<String>()
        return items.sortedByDescending { it.time }.filter { seen.add(norm(it.title).replace(Regex("[^a-z0-9]"), "").take(60)) }
    }

    /** Note des actualités pour l'analyse (élément « Actualités »). */
    fun factor(t: NewsTone): Factor? {
        if (t.items.isEmpty()) return null
        val best = t.items.filter { it.score != 0.0 }.take(8).maxByOrNull { kotlin.math.abs(it.score) }
        val txt = buildString {
            append(t.items.size).append(" articles (").append(t.recent).append(" en 48 h) : ")
            append(t.positive).append(" plutôt positifs, ").append(t.negative).append(" plutôt négatifs")
            if (best != null) append(" · « ").append(best.title.take(110)).append(" »")
        }
        // Peu d'articles récents : l'actualité compte moins
        val w = when { t.recent >= 6 -> 12.0; t.recent >= 2 -> 9.0; else -> 5.0 }
        return Factor("Actualités", (t.score * 1.4).coerceIn(-1.0, 1.0), w, txt)
    }
}
