package fr.jeremy.calepin.weather

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import android.location.Geocoder
import android.location.Location
import android.location.LocationManager
import android.os.Build
import androidx.core.content.ContextCompat
import fr.jeremy.calepin.i18n.I18n
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import okhttp3.HttpUrl.Companion.toHttpUrl
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import java.time.LocalDate
import java.time.LocalDateTime
import java.util.concurrent.TimeUnit
import kotlin.coroutines.resume

/** Lieu de la météo : choisi (ville, code postal) ou trouvé par la position du téléphone. */
data class WeatherPlace(val name: String, val detail: String, val lat: Double, val lon: Double) {
    fun toJson(): JSONObject = JSONObject().put("name", name).put("detail", detail).put("lat", lat).put("lon", lon)

    companion object {
        fun fromJson(o: JSONObject) = WeatherPlace(o.optString("name"), o.optString("detail"), o.optDouble("lat"), o.optDouble("lon"))
    }
}

data class HourWeather(val time: LocalDateTime, val temp: Double, val code: Int, val rain: Int, val isDay: Boolean)
data class DayWeather(val date: LocalDate, val code: Int, val max: Double, val min: Double, val rain: Int, val sunrise: String, val sunset: String, val uv: Double)

data class Forecast(
    val place: WeatherPlace,
    val fetchedAt: Long,
    val temp: Double,
    val feels: Double,
    val humidity: Int,
    val wind: Double,
    val code: Int,
    val isDay: Boolean,
    val hours: List<HourWeather>,
    val days: List<DayWeather>,
)

/** Codes météo de l'OMM (renvoyés par Open-Meteo) : description et pictogramme. */
object WeatherCodes {
    fun label(code: Int): String = when (code) {
        0 -> "Ciel dégagé"
        1 -> "Plutôt dégagé"
        2 -> "Partiellement nuageux"
        3 -> "Couvert"
        45, 48 -> "Brouillard"
        51, 53, 55 -> "Bruine"
        56, 57 -> "Bruine verglaçante"
        61 -> "Pluie faible"
        63 -> "Pluie"
        65 -> "Forte pluie"
        66, 67 -> "Pluie verglaçante"
        71 -> "Neige faible"
        73 -> "Neige"
        75 -> "Forte neige"
        77 -> "Grains de neige"
        80, 81 -> "Averses"
        82 -> "Fortes averses"
        85, 86 -> "Averses de neige"
        95 -> "Orage"
        96, 99 -> "Orage avec grêle"
        else -> "Météo"
    }

    fun emoji(code: Int, day: Boolean = true): String = when (code) {
        0 -> if (day) "☀️" else "🌙"
        1 -> if (day) "🌤️" else "🌙"
        2 -> if (day) "⛅" else "☁️"
        3 -> "☁️"
        45, 48 -> "🌫️"
        51, 53, 55, 56, 57 -> "🌦️"
        61, 63, 65, 66, 67, 80, 81, 82 -> "🌧️"
        71, 73, 75, 77, 85, 86 -> "❄️"
        95, 96, 99 -> "⛈️"
        else -> "🌡️"
    }
}

/**
 * Météo gratuite et sans compte (Open-Meteo, données des services météo nationaux, dont Météo-France).
 * Le lieu se choisit par la position du téléphone, un nom de ville ou un code postal.
 */
object WeatherRepo {
    private const val PREFS = "calepin_weather"
    private const val MAX_AGE = 30 * 60_000L

    private val http by lazy {
        OkHttpClient.Builder().connectTimeout(8, TimeUnit.SECONDS).readTimeout(12, TimeUnit.SECONDS).build()
    }

    private val _forecast = MutableStateFlow<Forecast?>(null)
    val forecast: StateFlow<Forecast?> = _forecast
    private val _loading = MutableStateFlow(false)
    val loading: StateFlow<Boolean> = _loading
    private val _error = MutableStateFlow<String?>(null)
    val error: StateFlow<String?> = _error

    private fun prefs(ctx: Context) = ctx.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    /** Vrai : le lieu suit la position du téléphone. */
    fun isAuto(ctx: Context) = prefs(ctx).getBoolean("auto", false)

    fun place(ctx: Context): WeatherPlace? =
        prefs(ctx).getString("place", null)?.let { runCatching { WeatherPlace.fromJson(JSONObject(it)) }.getOrNull() }

    fun recent(ctx: Context): List<WeatherPlace> = runCatching {
        val a = JSONArray(prefs(ctx).getString("recent", "[]"))
        (0 until a.length()).map { WeatherPlace.fromJson(a.getJSONObject(it)) }
    }.getOrDefault(emptyList())

    private fun savePlace(ctx: Context, p: WeatherPlace, auto: Boolean) {
        val rec = (listOf(p) + recent(ctx).filterNot { it.name == p.name && it.detail == p.detail }).take(6)
        val arr = JSONArray().also { a -> rec.forEach { a.put(it.toJson()) } }
        prefs(ctx).edit().putString("place", p.toJson().toString()).putBoolean("auto", auto).putString("recent", arr.toString()).apply()
    }

    fun hasLocationPermission(ctx: Context) =
        ContextCompat.checkSelfPermission(ctx, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED

    /** Dernières prévisions gardées sur le téléphone (affichage immédiat, même hors connexion). */
    fun loadCached(ctx: Context) {
        if (_forecast.value != null) return
        val text = prefs(ctx).getString("cache", null) ?: return
        runCatching { parseForecast(JSONObject(text), place(ctx) ?: return, prefs(ctx).getLong("cache_at", 0L)) }
            .onSuccess { _forecast.value = it }
    }

    /** Met à jour si les prévisions ont plus d'une demi-heure (ou tout de suite avec [force]). */
    suspend fun refresh(ctx: Context, force: Boolean = false) {
        loadCached(ctx)
        val cur = _forecast.value
        if (!force && cur != null && System.currentTimeMillis() - cur.fetchedAt < MAX_AGE) return
        if (_loading.value) return
        _loading.value = true
        try {
            var p = place(ctx)
            if (isAuto(ctx) && hasLocationPermission(ctx)) {
                locate(ctx)?.let { found -> p = found; savePlace(ctx, found, auto = true) }
            }
            val target = p ?: run { _loading.value = false; return }
            fetch(ctx, target)
        } finally {
            _loading.value = false
        }
    }

    /** Choisit un lieu (recherche ou lieu récent) et charge sa météo. */
    suspend fun choose(ctx: Context, p: WeatherPlace) {
        savePlace(ctx, p, auto = false)
        _loading.value = true
        try { fetch(ctx, p) } finally { _loading.value = false }
    }

    /** Suit la position du téléphone. Faux si la position est introuvable. */
    suspend fun useLocation(ctx: Context): Boolean {
        _loading.value = true
        try {
            val p = locate(ctx) ?: run {
                _error.value = "Position introuvable. Active la localisation du téléphone ou cherche ta ville."
                return false
            }
            savePlace(ctx, p, auto = true)
            fetch(ctx, p)
            return true
        } finally {
            _loading.value = false
        }
    }

    private suspend fun fetch(ctx: Context, p: WeatherPlace) = withContext(Dispatchers.IO) {
        try {
            val url = "https://api.open-meteo.com/v1/forecast".toHttpUrl().newBuilder()
                .addQueryParameter("latitude", "%.4f".format(java.util.Locale.US, p.lat))
                .addQueryParameter("longitude", "%.4f".format(java.util.Locale.US, p.lon))
                .addQueryParameter("current", "temperature_2m,apparent_temperature,relative_humidity_2m,weather_code,is_day,wind_speed_10m")
                .addQueryParameter("hourly", "temperature_2m,weather_code,precipitation_probability,is_day")
                .addQueryParameter("daily", "weather_code,temperature_2m_max,temperature_2m_min,precipitation_probability_max,sunrise,sunset,uv_index_max")
                .addQueryParameter("timezone", "auto")
                .addQueryParameter("forecast_days", "7")
                .build()
            val text = http.newCall(Request.Builder().url(url).build()).execute().use { r ->
                if (!r.isSuccessful) throw java.io.IOException("HTTP ${r.code}")
                r.body?.string() ?: throw java.io.IOException("vide")
            }
            val now = System.currentTimeMillis()
            val f = parseForecast(JSONObject(text), p, now)
            prefs(ctx).edit().putString("cache", text).putLong("cache_at", now).apply()
            _forecast.value = f
            _error.value = null
        } catch (e: Exception) {
            _error.value = "Météo indisponible pour le moment (pas de connexion ?)."
        }
    }

    private fun parseForecast(o: JSONObject, p: WeatherPlace, at: Long): Forecast {
        val c = o.getJSONObject("current")
        val h = o.getJSONObject("hourly")
        val ht = h.getJSONArray("time")
        val now = LocalDateTime.now().withMinute(0).withSecond(0).withNano(0)
        val hours = (0 until ht.length()).map { i ->
            HourWeather(
                LocalDateTime.parse(ht.getString(i)),
                h.getJSONArray("temperature_2m").optDouble(i),
                h.getJSONArray("weather_code").optInt(i),
                h.getJSONArray("precipitation_probability").optInt(i),
                h.getJSONArray("is_day").optInt(i, 1) == 1,
            )
        }.filter { !it.time.isBefore(now) }.take(24)
        val d = o.getJSONObject("daily")
        val dt = d.getJSONArray("time")
        val days = (0 until dt.length()).map { i ->
            DayWeather(
                LocalDate.parse(dt.getString(i)),
                d.getJSONArray("weather_code").optInt(i),
                d.getJSONArray("temperature_2m_max").optDouble(i),
                d.getJSONArray("temperature_2m_min").optDouble(i),
                d.getJSONArray("precipitation_probability_max").optInt(i),
                d.getJSONArray("sunrise").optString(i).substringAfter('T'),
                d.getJSONArray("sunset").optString(i).substringAfter('T'),
                d.getJSONArray("uv_index_max").optDouble(i, 0.0),
            )
        }
        return Forecast(
            place = p, fetchedAt = at,
            temp = c.optDouble("temperature_2m"),
            feels = c.optDouble("apparent_temperature"),
            humidity = c.optInt("relative_humidity_2m"),
            wind = c.optDouble("wind_speed_10m"),
            code = c.optInt("weather_code"),
            isDay = c.optInt("is_day", 1) == 1,
            hours = hours, days = days,
        )
    }

    /** Recherche d'une ville ou d'un code postal (Open-Meteo, complété par le géocodeur du téléphone). */
    suspend fun search(ctx: Context, q: String): List<WeatherPlace> = withContext(Dispatchers.IO) {
        val out = ArrayList<WeatherPlace>()
        runCatching {
            val url = "https://geocoding-api.open-meteo.com/v1/search".toHttpUrl().newBuilder()
                .addQueryParameter("name", q.trim())
                .addQueryParameter("count", "10")
                .addQueryParameter("language", I18n.language.value.code)
                .addQueryParameter("format", "json")
                .build()
            val text = http.newCall(Request.Builder().url(url).build()).execute().use { it.body?.string().orEmpty() }
            val arr = JSONObject(text).optJSONArray("results") ?: JSONArray()
            for (i in 0 until arr.length()) {
                val r = arr.getJSONObject(i)
                val pcs = r.optJSONArray("postcodes")
                val pc = if (pcs != null && pcs.length() > 0) pcs.optString(0) else ""
                val detail = listOf(pc, r.optString("admin2"), r.optString("admin1"), r.optString("country"))
                    .filter { it.isNotBlank() }.distinct().joinToString(", ")
                out += WeatherPlace(r.optString("name"), detail, r.optDouble("latitude"), r.optDouble("longitude"))
            }
        }
        // Codes postaux et adresses : le géocodeur du téléphone les connaît souvent mieux
        if (out.size < 3 && Geocoder.isPresent()) {
            runCatching {
                @Suppress("DEPRECATION")
                Geocoder(ctx, I18n.locale).getFromLocationName(q.trim(), 5)?.forEach { a ->
                    val name = a.locality ?: a.subAdminArea ?: a.featureName ?: q.trim()
                    val detail = listOfNotNull(a.postalCode, a.adminArea, a.countryName).filter { it.isNotBlank() }.joinToString(", ")
                    if (out.none { kotlin.math.abs(it.lat - a.latitude) < 0.02 && kotlin.math.abs(it.lon - a.longitude) < 0.02 }) {
                        out += WeatherPlace(name, detail, a.latitude, a.longitude)
                    }
                }
            }
        }
        out
    }

    /** Position actuelle du téléphone (réseau ou GPS), avec le nom de la ville. */
    @SuppressLint("MissingPermission")
    suspend fun locate(ctx: Context): WeatherPlace? {
        if (!hasLocationPermission(ctx)) return null
        val lm = ctx.getSystemService(LocationManager::class.java) ?: return null
        val providers = buildList {
            if (Build.VERSION.SDK_INT >= 31) add(LocationManager.FUSED_PROVIDER)
            add(LocationManager.NETWORK_PROVIDER)
            add(LocationManager.GPS_PROVIDER)
        }.filter { runCatching { lm.isProviderEnabled(it) }.getOrDefault(false) }
        var loc: Location? = null
        if (Build.VERSION.SDK_INT >= 30) {
            for (pr in providers) {
                loc = withTimeoutOrNull(12_000) {
                    suspendCancellableCoroutine<Location?> { cont ->
                        val signal = android.os.CancellationSignal()
                        cont.invokeOnCancellation { signal.cancel() }
                        runCatching {
                            lm.getCurrentLocation(pr, signal, ContextCompat.getMainExecutor(ctx)) { l -> if (cont.isActive) cont.resume(l) }
                        }.onFailure { if (cont.isActive) cont.resume(null) }
                    }
                }
                if (loc != null) break
            }
        }
        if (loc == null) {
            loc = (providers + LocationManager.PASSIVE_PROVIDER).mapNotNull { runCatching { lm.getLastKnownLocation(it) }.getOrNull() }
                .maxByOrNull { it.time }
        }
        val l = loc ?: return null
        val name = withContext(Dispatchers.IO) {
            runCatching {
                if (!Geocoder.isPresent()) null
                else {
                    @Suppress("DEPRECATION")
                    Geocoder(ctx, I18n.locale).getFromLocation(l.latitude, l.longitude, 1)?.firstOrNull()
                }
            }.getOrNull()
        }
        return WeatherPlace(
            name = name?.locality ?: name?.subAdminArea ?: I18n.tr("Ma position"),
            detail = listOfNotNull(name?.postalCode, name?.countryName).joinToString(", "),
            lat = l.latitude, lon = l.longitude,
        )
    }

    /** Prévision de demain pour l'assistant. */
    fun tomorrow(): String? {
        val f = _forecast.value ?: return null
        val d = f.days.getOrNull(1) ?: return null
        return I18n.trf("Demain à {0} : {1}, de {2} à {3}°, risque de pluie {4} %.", f.place.name, I18n.tr(WeatherCodes.label(d.code)).lowercase(), Math.round(d.min), Math.round(d.max), d.rain)
    }

    /** Phrase courte pour l'assistant : « 21° à Menton, ensoleillé ; 14 à 23° aujourd'hui, pluie 10 % ». */
    fun summary(): String? {
        val f = _forecast.value ?: return null
        val d = f.days.firstOrNull()
        val base = I18n.trf("{0}° à {1}, {2}.", Math.round(f.temp), f.place.name, I18n.tr(WeatherCodes.label(f.code)).lowercase())
        return if (d == null) base else base + " " + I18n.trf("Aujourd'hui de {0} à {1}°, risque de pluie {2} %.", Math.round(d.min), Math.round(d.max), d.rain)
    }
}
