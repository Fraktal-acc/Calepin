package fr.jeremy.calepin.reminders

import android.Manifest
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import fr.jeremy.calepin.R
import fr.jeremy.calepin.data.NoteDb
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Reçoit le déclenchement d'un rappel : notification simple, ou alarme qui sonne. */
class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        fr.jeremy.calepin.i18n.I18n.init(ctx)
        val id = intent.getLongExtra(Reminders.EXTRA_EVENT, -1)
        val e = NoteDb(ctx).event(id) ?: return // rendez-vous supprimé entre-temps
        // Rappel qui se répète : le rendez-vous passe à sa prochaine date (et son rappel est reprogrammé)
        if (e.repeat.isNotEmpty()) {
            runCatching {
                e.nextOccurrence(maxOf(System.currentTimeMillis(), e.start))?.let { next ->
                    NoteDb(ctx).upsertEvent(next)
                    Reminders.schedule(ctx, next)
                }
            }
        }
        if (e.alarm) {
            val svc = Intent(ctx, AlarmService::class.java).putExtra(Reminders.EXTRA_EVENT, id)
            ContextCompat.startForegroundService(ctx, svc)
            return
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) return
        val n = NotificationCompat.Builder(ctx, Reminders.notificationChannel(ctx, e.ringtone))
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle(e.title)
            .setContentText(whenText(e.start, e.allDay))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_REMINDER)
            .setContentIntent(Reminders.openPending(ctx, e))
            .setAutoCancel(true)
            .build()
        NotificationManagerCompat.from(ctx).notify(id.toInt(), n)
    }

    companion object {
        fun whenText(start: Long, allDay: Boolean): String {
            val d = SimpleDateFormat(fr.jeremy.calepin.i18n.I18n.pattern("EEEE d MMMM"), fr.jeremy.calepin.i18n.I18n.locale).format(Date(start))
            return (if (allDay) d else fr.jeremy.calepin.i18n.I18n.trf("{0} à {1}", d, SimpleDateFormat(fr.jeremy.calepin.i18n.I18n.pattern("HH'h'mm"), fr.jeremy.calepin.i18n.I18n.locale).format(Date(start))))
                .replaceFirstChar { it.uppercase() }
        }
    }
}

/** Reprogramme tous les rappels après un redémarrage ou une mise à jour de l'appli. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        Reminders.rescheduleAll(ctx)
        fr.jeremy.calepin.assistant.Briefing.schedule(ctx)
        fr.jeremy.calepin.care.Care.scheduleAll(ctx)
    }
}
