package fr.jeremy.calepin.assistant

import android.Manifest
import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import fr.jeremy.calepin.AppSettings
import fr.jeremy.calepin.MainActivity
import fr.jeremy.calepin.R
import java.util.Calendar

/** Briefing quotidien automatique : chaque jour à l'heure choisie, résumé de la journée en notification. */
object Briefing {
    const val EXTRA_OPEN_ASSISTANT = "open_assistant"
    private const val CHANNEL = "calepin_briefing"

    private fun pending(ctx: Context) = PendingIntent.getBroadcast(
        ctx, 777, Intent(ctx, BriefingReceiver::class.java),
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
    )

    /** (Re)programme le prochain briefing, ou l'annule s'il est désactivé. */
    fun schedule(ctx: Context) {
        val s = AppSettings(ctx)
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        am.cancel(pending(ctx))
        if (!s.briefingEnabled.value) return
        val minutes = s.briefingTime.value
        val c = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, minutes / 60); set(Calendar.MINUTE, minutes % 60); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
            if (timeInMillis <= System.currentTimeMillis()) add(Calendar.DAY_OF_YEAR, 1)
        }
        am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, c.timeInMillis, pending(ctx))
    }

    fun notify(ctx: Context) {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) return
        fr.jeremy.calepin.i18n.I18n.init(ctx)
        val text = Assistant(DbAssistantData(ctx)).briefing().text
        val nm = ctx.getSystemService(NotificationManager::class.java)
        if (nm.getNotificationChannel(CHANNEL) == null) {
            nm.createNotificationChannel(NotificationChannel(CHANNEL, fr.jeremy.calepin.i18n.I18n.tr("Briefing du jour"), NotificationManager.IMPORTANCE_DEFAULT))
        }
        val open = PendingIntent.getActivity(
            ctx, 778,
            Intent(ctx, MainActivity::class.java).putExtra(EXTRA_OPEN_ASSISTANT, true)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )
        val n = NotificationCompat.Builder(ctx, CHANNEL)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle(fr.jeremy.calepin.i18n.I18n.tr("Ta journée"))
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setContentIntent(open)
            .setAutoCancel(true)
            .build()
        NotificationManagerCompat.from(ctx).notify(779, n)
    }
}

class BriefingReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        runCatching { Briefing.notify(ctx) }
        Briefing.schedule(ctx) // et le lendemain
    }
}
