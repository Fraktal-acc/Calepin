package fr.jeremy.calepin.office.word

import fr.jeremy.calepin.text.DisplayMap
import fr.jeremy.calepin.text.MarkdownSigns
import fr.jeremy.calepin.text.RichText
import java.util.UUID

/**
 * Document Word tel que Calepin le modifie : une suite de blocs (texte, tableau, image, saut de page)
 * et la mise en page (format, marges, police, en-tête, pied de page).
 *
 * Le texte garde la même écriture que les notes (comprise par l'éditeur, le PDF et la recherche) :
 * « # » « ## » « ### » titres, « > » citation, « - » puces, « 1. » numéros, « ☐ » « ☑ » cases,
 * deux espaces de retrait par niveau de liste, **gras**, *italique*, ~~barré~~, [u]souligné[/u],
 * [c=#RRGGBB]couleur[/c], [bg=#RRGGBB]surlignage[/bg], [texte](adresse) liens, « [center] » ou « [right] »
 * en fin de ligne pour l'alignement.
 */
sealed interface DocBlock {
    val id: String

    data class Text(override val id: String = newId(), val text: String = "") : DocBlock
    /** Tableau : lignes de cellules (texte mis en forme, sur une ligne ou plusieurs). */
    data class Table(override val id: String = newId(), val rows: List<List<String>>, val header: Boolean = true) : DocBlock {
        val cols: Int get() = rows.maxOfOrNull { it.size } ?: 0
    }
    /** Image : fichier du dossier des images du document, largeur en % de la largeur du texte. */
    data class Image(override val id: String = newId(), val file: String, val widthPct: Int = 100, val align: String = "center") : DocBlock
    data class PageBreak(override val id: String = newId()) : DocBlock
}

internal fun newId() = UUID.randomUUID().toString().take(8)

enum class Paper(val label: String, val wTwips: Int, val hTwips: Int) {
    A4("A4", 11906, 16838), LETTER("Lettre US", 12240, 15840), A5("A5", 8391, 11906),
}

data class PageSetup(
    val paper: Paper = Paper.A4,
    val landscape: Boolean = false,
    /** Marges en millimètres. */
    val marginMm: Int = 25,
    val font: String = "Calibri",
    /** Taille du texte normal, en points. */
    val sizePt: Int = 11,
    val header: String = "",
    val footer: String = "",
    val pageNumbers: Boolean = false,
) {
    val marginTwips: Int get() = (marginMm * 56.6929f).toInt()
    val widthTwips: Int get() = if (landscape) paper.hTwips else paper.wTwips
    val heightTwips: Int get() = if (landscape) paper.wTwips else paper.hTwips
    /** Largeur du texte entre les marges (twips). */
    val textWidthTwips: Int get() = (widthTwips - 2 * marginTwips).coerceAtLeast(1440)

    companion object {
        val FONTS = listOf("Calibri", "Arial", "Helvetica", "Verdana", "Times New Roman", "Georgia", "Cambria", "Garamond", "Courier New")
        fun isSerif(font: String) = font.lowercase().let { f -> listOf("times", "georgia", "cambria", "garamond", "serif", "book", "palatino", "baskerville").any { it in f } && "sans" !in f }
        fun isMono(font: String) = font.lowercase().let { "courier" in it || "mono" in it || "consolas" in it }
    }
}

data class WordDoc(val blocks: List<DocBlock> = listOf(DocBlock.Text()), val page: PageSetup = PageSetup()) {
    /** Texte sans mise en forme (recherche, aperçu, statistiques). */
    fun plainText(): String = blocks.joinToString("\n") { b ->
        when (b) {
            is DocBlock.Text -> WordMarkup.plainLines(b.text)
            is DocBlock.Table -> b.rows.joinToString("\n") { r -> r.joinToString("\t") { WordMarkup.plainLines(it) } }
            else -> ""
        }
    }

    fun stats(): Stats {
        val t = plainText()
        val words = Regex("[\\p{L}\\p{N}][\\p{L}\\p{N}'’\\-]*").findAll(t).count()
        val paras = blocks.filterIsInstance<DocBlock.Text>().sumOf { b -> b.text.split('\n').count { it.isNotBlank() } }
        return Stats(words, t.count { !it.isWhitespace() }, t.replace("\n", "").length, paras, blocks.count { it is DocBlock.Table }, blocks.count { it is DocBlock.Image })
    }

    data class Stats(val words: Int, val charsNoSpaces: Int, val chars: Int, val paragraphs: Int, val tables: Int, val images: Int)

    /** Blocs de texte voisins réunis, et un bloc de texte toujours présent au début, à la fin et entre deux objets. */
    fun normalized(): WordDoc {
        val out = ArrayList<DocBlock>()
        for (b in blocks) {
            val last = out.lastOrNull()
            if (b is DocBlock.Text && last is DocBlock.Text) out[out.lastIndex] = last.copy(text = last.text + "\n" + b.text)
            else {
                if (b !is DocBlock.Text && (last == null || last !is DocBlock.Text)) out += DocBlock.Text()
                out += b
            }
        }
        if (out.lastOrNull() !is DocBlock.Text) out += DocBlock.Text()
        return copy(blocks = out)
    }
}

/** Opérations sur l'écriture des paragraphes (styles, listes, retraits), utilisées par l'éditeur et par Word. */
object WordMarkup {
    enum class Kind { NORMAL, H1, H2, H3, QUOTE, BULLET, NUMBER, CHECK }

    data class Line(val kind: Kind, val level: Int, /** Longueur du préfixe (retrait + signe). */ val prefix: Int, val number: Int = 0, val done: Boolean = false)

    private val numberRx = Regex("^(\\d{1,3})[.)] ")
    private val ALIGN_END = Regex("\\[(center|right)]$")

    fun parse(line: String): Line {
        var sp = 0
        while (sp < line.length && line[sp] == ' ') sp++
        val r = line.substring(sp)
        val level = (sp / 2).coerceAtMost(8)
        return when {
            sp == 0 && r.startsWith("### ") -> Line(Kind.H3, 0, 4)
            sp == 0 && r.startsWith("## ") -> Line(Kind.H2, 0, 3)
            sp == 0 && r.startsWith("# ") -> Line(Kind.H1, 0, 2)
            r.startsWith("> ") -> Line(Kind.QUOTE, 0, sp + 2)
            r.startsWith("- ") || r.startsWith("• ") -> Line(Kind.BULLET, level, sp + 2)
            r.startsWith("☐ ") || r.startsWith("☑ ") -> Line(Kind.CHECK, level, sp + 2, done = r.startsWith("☑"))
            r == "☐" || r == "☑" -> Line(Kind.CHECK, level, sp + 1, done = r == "☑")
            else -> numberRx.find(r)?.let { Line(Kind.NUMBER, level, sp + it.value.length, it.groupValues[1].toInt()) } ?: Line(Kind.NORMAL, 0, 0)
        }
    }

    fun isList(k: Kind) = k == Kind.BULLET || k == Kind.NUMBER || k == Kind.CHECK

    /** Texte d'une ligne sans son préfixe ni son alignement. */
    fun body(line: String): String = line.substring(parse(line).prefix).let { ALIGN_END.replace(it, "") }

    fun alignOf(line: String): String? = ALIGN_END.find(line)?.groupValues?.get(1)

    private fun prefixFor(k: Kind, level: Int, n: Int = 1): String {
        val ind = "  ".repeat(level)
        return when (k) {
            Kind.NORMAL -> ""
            Kind.H1 -> "# "
            Kind.H2 -> "## "
            Kind.H3 -> "### "
            Kind.QUOTE -> "> "
            Kind.BULLET -> "$ind- "
            Kind.NUMBER -> "$ind$n. "
            Kind.CHECK -> "$ind☐ "
        }
    }

    /** Lignes touchées par la sélection [a, b) : (début de la première, fin de la dernière). */
    fun lineRange(text: String, a: Int, b: Int): Pair<Int, Int> {
        val aa = a.coerceIn(0, text.length)
        val bb = b.coerceIn(aa, text.length)
        val s = if (aa == 0) 0 else text.lastIndexOf('\n', aa - 1) + 1
        val e = text.indexOf('\n', bb).let { if (it < 0) text.length else it }
        return s to e
    }

    data class Edit(val text: String, val start: Int, val end: Int)

    /** Remplace les lignes de [a, b) par [f] appliqué à chacune, puis renumérote. */
    private fun mapLines(text: String, a: Int, b: Int, f: (Int, String) -> String): Edit {
        val (s, e) = lineRange(text, a, b)
        val lines = text.substring(s, e).split('\n')
        val mapped = lines.mapIndexed { i, l -> f(i, l) }.joinToString("\n")
        val nt = text.substring(0, s) + mapped + text.substring(e)
        val r = renumber(nt)
        val delta = r.length - nt.length
        return Edit(r, s, (s + mapped.length + delta).coerceIn(s, r.length))
    }

    /** Style de paragraphe (normal, titres, citation) sur les lignes sélectionnées. */
    fun setStyle(text: String, a: Int, b: Int, k: Kind): Edit = mapLines(text, a, b) { _, l ->
        val p = parse(l)
        val rest = l.substring(p.prefix)
        if (rest.isEmpty() && l.isEmpty() && k == Kind.NORMAL) l else prefixFor(k, 0) + rest
    }

    /** Puces, numéros ou cases : ajoutés aux lignes sélectionnées, ou retirés si elles l'ont déjà toutes. */
    fun toggleList(text: String, a: Int, b: Int, k: Kind): Edit {
        val (s, e) = lineRange(text, a, b)
        val lines = text.substring(s, e).split('\n')
        val all = lines.all { parse(it).kind == k }
        var n = 0
        return mapLines(text, a, b) { _, l ->
            val p = parse(l)
            val rest = l.substring(p.prefix)
            if (all) rest
            else {
                n++
                prefixFor(k, if (isList(p.kind)) p.level else 0, n) + rest
            }
        }
    }

    /** Retrait d'un niveau de plus ([delta] 1) ou de moins (−1) pour les lignes de liste. */
    fun indent(text: String, a: Int, b: Int, delta: Int): Edit = mapLines(text, a, b) { _, l ->
        val p = parse(l)
        if (!isList(p.kind)) {
            // Paragraphe normal : « Augmenter le retrait » en fait un élément de liste à puces
            if (delta > 0 && p.kind == Kind.NORMAL && l.isNotBlank()) "- $l" else l
        } else {
            val lvl = (p.level + delta).coerceIn(0, 8)
            "  ".repeat(lvl) + l.trimStart(' ')
        }
    }

    /** Coche ou décoche la case de la ligne du curseur. */
    fun toggleCheck(text: String, pos: Int): Edit = mapLines(text, pos, pos) { _, l ->
        val p = parse(l)
        if (p.kind != Kind.CHECK) l
        else {
            val i = l.indexOfFirst { it == '☐' || it == '☑' }
            l.substring(0, i) + (if (p.done) '☐' else '☑') + l.substring(i + 1)
        }
    }

    /** Mise en forme des caractères retirée sur les lignes sélectionnées (style et alignement gardés). */
    fun clearFormatting(text: String, a: Int, b: Int): Edit = mapLines(text, a, b) { _, l ->
        val p = parse(l)
        val al = alignOf(l)
        val inner = l.substring(p.prefix).let { ALIGN_END.replace(it, "") }
        l.substring(0, p.prefix) + stripInline(inner) + (al?.let { "[$it]" } ?: "")
    }

    /** Numéros des listes recalculés (1, 2, 3… par niveau, chaque liste repart de son premier numéro). */
    fun renumber(text: String): String {
        if (!text.contains(Regex("(?m)^ *\\d{1,3}[.)] "))) return text
        val lines = text.split('\n').toMutableList()
        val counters = IntArray(9)
        val active = BooleanArray(9)
        for (i in lines.indices) {
            val p = parse(lines[i])
            if (p.kind == Kind.NUMBER) {
                val lv = p.level
                for (k in lv + 1 until 9) active[k] = false
                counters[lv] = if (active[lv]) counters[lv] + 1 else p.number.coerceAtLeast(1)
                active[lv] = true
                if (counters[lv] != p.number) {
                    val l = lines[i]
                    val sp = l.length - l.trimStart(' ').length
                    lines[i] = l.substring(0, sp) + l.substring(sp).replaceFirst(Regex("^\\d{1,3}"), counters[lv].toString())
                }
            } else if (p.kind == Kind.BULLET || p.kind == Kind.CHECK) {
                // Puce sous un numéro : la liste numérotée continue après ; puce au premier niveau : elle s'arrête
                for (k in p.level until 9) active[k] = false
            } else {
                active.fill(false)
            }
        }
        return lines.joinToString("\n")
    }

    /**
     * Après une frappe : Entrée au bout d'un élément de liste (ou d'une citation) en crée un nouveau ;
     * sur un élément vide, la liste s'arrête. Renvoie null si rien à faire.
     */
    fun afterEnter(old: String, new: String, cursor: Int): Pair<String, Int>? {
        if (new.length != old.length + 1 || cursor < 1 || cursor > new.length || new[cursor - 1] != '\n') return null
        val at = cursor - 1
        val ls = new.lastIndexOf('\n', at - 1) + 1
        val prev = new.substring(ls, at)
        val p = parse(prev)
        if (!isList(p.kind) && p.kind != Kind.QUOTE) return null
        val rest = ALIGN_END.replace(prev.substring(p.prefix), "")
        if (rest.isBlank()) {
            // Élément vide + Entrée : fin de la liste (un niveau de moins s'il est en retrait)
            return if (isList(p.kind) && p.level > 0) {
                val t = new.substring(0, ls) + "  ".repeat(p.level - 1) + prev.trimStart(' ') + new.substring(at + 1)
                renumber(t) to (ls + prev.length - 2).coerceAtLeast(ls)
            } else {
                val t = new.substring(0, ls) + new.substring(at + 1)
                t to ls
            }
        }
        val pre = when (p.kind) {
            Kind.NUMBER -> prefixFor(Kind.NUMBER, p.level, p.number + 1)
            Kind.QUOTE -> "> "
            else -> prefixFor(p.kind, p.level)
        }
        val t = new.substring(0, cursor) + pre + new.substring(cursor)
        val r = renumber(t)
        return r to (cursor + pre.length + (r.length - t.length)).coerceIn(0, r.length)
    }

    /** Mise en forme des caractères retirée (les liens gardent seulement leur texte). */
    fun stripInline(s: String): String {
        var t = RichText.strip(s)
        t = MarkdownSigns.webLinks.replace(t) { it.groupValues[1] }
        t = MarkdownSigns.bold.replace(t) { it.groupValues[1] }
        t = MarkdownSigns.strike.replace(t) { it.groupValues[1] }
        t = MarkdownSigns.italic.replace(t) { it.groupValues[1] }
        return t
    }

    /** Texte des lignes sans préfixes ni repères. */
    fun plainLines(text: String): String = text.split('\n').joinToString("\n") { l -> MarkdownSigns.plain(RichText.strip(body(l))) }

    // ------------------------------------------------------------------ Caractères

    /** Morceau de texte d'une même mise en forme. */
    data class Run(
        val text: String,
        val bold: Boolean = false,
        val italic: Boolean = false,
        val underline: Boolean = false,
        val strike: Boolean = false,
        val color: String? = null,
        val highlight: String? = null,
        val link: String? = null,
    )

    /** Découpe le texte d'un paragraphe (sans préfixe) en morceaux de même mise en forme. */
    fun runs(s: String): List<Run> {
        if (s.isEmpty()) return emptyList()
        if (s.none { it == '*' || it == '~' || it == '[' || it == '#' }) return listOf(Run(s))
        val hidden = (if ('[' in s) RichText.tokens(s).map { DisplayMap.Hidden(it.start, it.end, false) } else emptyList()) +
            MarkdownSigns.hidden(s).filter { h -> !(h.start == 0 && s.startsWith("#")) }
        val map = DisplayMap(s, hidden, emptyList())
        val vis = map.visible
        val n = vis.length
        val b = BooleanArray(n); val i = BooleanArray(n); val u = BooleanArray(n); val st = BooleanArray(n)
        val c = arrayOfNulls<String>(n); val bg = arrayOfNulls<String>(n); val ln = arrayOfNulls<String>(n)
        fun mark(a: Int, e: Int, f: (Int) -> Unit) { val va = map.toVisible(a); val ve = map.toVisible(e); for (k in va until ve.coerceAtMost(n)) f(k) }
        MarkdownSigns.bold.findAll(s).forEach { m -> m.groups[1]?.range?.let { r -> mark(r.first, r.last + 1) { b[it] = true } } }
        MarkdownSigns.italic.findAll(s).forEach { m -> m.groups[1]?.range?.let { r -> mark(r.first, r.last + 1) { i[it] = true } } }
        MarkdownSigns.strike.findAll(s).forEach { m -> m.groups[1]?.range?.let { r -> mark(r.first, r.last + 1) { st[it] = true } } }
        MarkdownSigns.webLinks.findAll(s).forEach { m -> val r = m.groups[1]!!.range; val url = m.groupValues[2]; mark(r.first, r.last + 1) { ln[it] = url } }
        if ('[' in s) RichText.spans(s).forEach { sp ->
            when (sp.kind) {
                "c" -> mark(sp.start, sp.end) { c[it] = sp.value }
                "bg" -> mark(sp.start, sp.end) { bg[it] = sp.value }
                "u" -> mark(sp.start, sp.end) { u[it] = true }
            }
        }
        val out = ArrayList<Run>()
        var start = 0
        fun same(x: Int, y: Int) = b[x] == b[y] && i[x] == i[y] && u[x] == u[y] && st[x] == st[y] && c[x] == c[y] && bg[x] == bg[y] && ln[x] == ln[y]
        for (k in 1..n) {
            if (k == n || !same(k, start)) {
                out += Run(vis.substring(start, k), b[start], i[start], u[start], st[start], c[start], bg[start], ln[start])
                start = k
            }
        }
        return out
    }

    /** Morceaux → écriture de Calepin (l'inverse de [runs]). */
    fun markup(runs: List<Run>): String {
        val sb = StringBuilder()
        // Morceaux voisins de même mise en forme réunis (les repères ne passent pas d'un morceau à l'autre)
        val merged = ArrayList<Run>()
        for (r in runs) {
            if (r.text.isEmpty()) continue
            val last = merged.lastOrNull()
            if (last != null && last.copy(text = "") == r.copy(text = "")) merged[merged.lastIndex] = last.copy(text = last.text + r.text)
            else merged += r
        }
        for (r in merged) {
            if (r.link != null) {
                val label = r.text.replace("[", "(").replace("]", ")").replace('\n', ' ')
                sb.append('[').append(label).append("](").append(r.link).append(')')
                continue
            }
            // Les espaces au bord restent hors des signes (sinon « ** mot** » n'est pas reconnu)
            val lead = r.text.takeWhile { it == ' ' || it == '\t' }
            val trail = r.text.drop(lead.length).takeLastWhile { it == ' ' || it == '\t' }
            val core = r.text.substring(lead.length, r.text.length - trail.length)
            sb.append(lead)
            if (core.isEmpty()) { sb.append(trail); continue }
            var t = core
            if (r.strike) t = "~~$t~~"
            if (r.italic) t = "*$t*"
            if (r.bold) t = "**$t**"
            if (r.underline) t = "[u]$t[/u]"
            if (r.highlight != null) t = "[bg=${r.highlight}]$t[/bg]"
            if (r.color != null) t = "[c=${r.color}]$t[/c]"
            sb.append(t).append(trail)
        }
        return sb.toString()
    }

    /** Positions des mots cherchés dans le texte (hors repères de mise en forme), sans tenir compte des majuscules. */
    fun find(text: String, query: String): List<IntRange> {
        if (query.isBlank()) return emptyList()
        val hidden = (if ('[' in text) RichText.tokens(text).map { it.start until it.end } else emptyList()) +
            MarkdownSigns.hidden(text).map { it.start until it.end }
        val out = ArrayList<IntRange>()
        var i = text.indexOf(query, ignoreCase = true)
        while (i >= 0) {
            val r = i until i + query.length
            if (hidden.none { h -> h.first < r.last + 1 && r.first < h.last + 1 }) out += r
            i = text.indexOf(query, i + query.length.coerceAtLeast(1), ignoreCase = true)
        }
        return out
    }
}
