package fr.jeremy.calepin.ui

import android.graphics.Bitmap
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Undo
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties

/** Un trait du croquis : ses points, sa couleur et son épaisseur (en pixels). */
private class SketchStroke(val points: List<Offset>, val color: Color, val width: Float)

private val INKS = listOf(
    Color(0xFF1B1C1E), Color(0xFFD32F2F), Color(0xFF1565C0), Color(0xFF2E7D32),
    Color(0xFFF9A825), Color(0xFF8E24AA), Color(0xFFFFFFFF),
)

/** Dessin à main levée sur une feuille blanche, enregistré en image dans la note. */
@Composable
fun SketchDialog(onSave: (Bitmap) -> Unit, onDismiss: () -> Unit) {
    val strokes = remember { mutableStateListOf<SketchStroke>() }
    var current by remember { mutableStateOf<List<Offset>>(emptyList()) }
    var ink by remember { mutableStateOf(INKS[0]) }
    var width by remember { mutableStateOf(8f) }
    var canvasSize by remember { mutableStateOf(IntSize.Zero) }

    fun render(): Bitmap {
        val w = canvasSize.width.coerceAtLeast(1)
        val h = canvasSize.height.coerceAtLeast(1)
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = android.graphics.Canvas(bmp)
        c.drawColor(android.graphics.Color.WHITE)
        val paint = android.graphics.Paint().apply {
            isAntiAlias = true
            style = android.graphics.Paint.Style.STROKE
            strokeCap = android.graphics.Paint.Cap.ROUND
            strokeJoin = android.graphics.Paint.Join.ROUND
        }
        strokes.forEach { s ->
            paint.color = s.color.toArgb()
            paint.strokeWidth = s.width
            if (s.points.size == 1) {
                paint.style = android.graphics.Paint.Style.FILL
                c.drawCircle(s.points[0].x, s.points[0].y, s.width / 2, paint)
                paint.style = android.graphics.Paint.Style.STROKE
            } else {
                val p = android.graphics.Path()
                s.points.forEachIndexed { i, o -> if (i == 0) p.moveTo(o.x, o.y) else p.lineTo(o.x, o.y) }
                c.drawPath(p, paint)
            }
        }
        return bmp
    }

    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false, dismissOnClickOutside = false)) {
        Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.surface) {
            Column(Modifier.fillMaxSize().systemBarsPadding()) {
                Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = onDismiss) { Icon(Icons.Filled.Close, "Annuler") }
                    Text("Croquis", style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
                    IconButton(onClick = { if (strokes.isNotEmpty()) strokes.removeAt(strokes.lastIndex) }, enabled = strokes.isNotEmpty()) {
                        Icon(Icons.AutoMirrored.Filled.Undo, "Annuler le dernier trait")
                    }
                    IconButton(onClick = { strokes.clear() }, enabled = strokes.isNotEmpty()) { Icon(Icons.Filled.DeleteSweep, "Tout effacer") }
                    TextButton(onClick = { if (strokes.isNotEmpty()) onSave(render()) else onDismiss() }) {
                        Icon(Icons.Filled.Check, null); Text(" Ajouter")
                    }
                }
                Box(
                    Modifier
                        .weight(1f)
                        .fillMaxWidth()
                        .padding(8.dp)
                        .clip(MaterialTheme.shapes.medium)
                        .background(Color.White)
                        .onSizeChanged { canvasSize = it }
                        .pointerInput(ink, width) {
                            detectTapGestures { p -> strokes.add(SketchStroke(listOf(p), ink, width)) }
                        }
                        .pointerInput(ink, width) {
                            detectDragGestures(
                                onDragStart = { p -> current = listOf(p) },
                                onDragEnd = {
                                    if (current.isNotEmpty()) strokes.add(SketchStroke(current, ink, width))
                                    current = emptyList()
                                },
                                onDragCancel = { current = emptyList() },
                            ) { change, _ -> current = current + change.position }
                        },
                ) {
                    Canvas(Modifier.fillMaxSize()) {
                        fun draw(points: List<Offset>, color: Color, w: Float) {
                            if (points.size == 1) { drawCircle(color, w / 2, points[0]); return }
                            val path = Path().apply { points.forEachIndexed { i, o -> if (i == 0) moveTo(o.x, o.y) else lineTo(o.x, o.y) } }
                            drawPath(path, color, style = Stroke(w, cap = StrokeCap.Round, join = StrokeJoin.Round))
                        }
                        strokes.forEach { draw(it.points, it.color, it.width) }
                        if (current.isNotEmpty()) draw(current, ink, width)
                    }
                }
                // Couleurs et épaisseurs
                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    INKS.forEach { c ->
                        Box(
                            Modifier
                                .size(30.dp)
                                .clip(CircleShape)
                                .background(c)
                                .border(if (c == ink) 3.dp else 1.dp, if (c == ink) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline, CircleShape)
                                .clickable { ink = c },
                        )
                    }
                    Spacer(Modifier.weight(1f))
                    listOf(4f, 8f, 18f).forEach { w ->
                        Box(
                            Modifier
                                .size(34.dp)
                                .clip(CircleShape)
                                .background(if (w == width) MaterialTheme.colorScheme.secondaryContainer else Color.Transparent)
                                .clickable { width = w },
                            contentAlignment = Alignment.Center,
                        ) { Box(Modifier.size((w / 1.5f).dp.coerceAtLeast(3.dp)).clip(CircleShape).background(MaterialTheme.colorScheme.onSurface)) }
                    }
                }
            }
        }
    }
}
