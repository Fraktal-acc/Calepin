package fr.jeremy.calepin.detect

import java.util.Calendar

/**
 * Analyse d'un planning lu (vacations et absences) : heures, nuits, dimanches, sites, enchaînements,
 * et comparaison avec les totaux imprimés sur le planning (« Services : 21 », « Travaillées : 154H20 »…).
 * Tout est calculé ici : l'assistant de base comme l'IA (Qwen, Gemma) reprennent ces chiffres au lieu de les deviner.
 */
object PlanningReport {

    /** Heures par site (ou par poste quand il n'y a pas de site). */
    class Site(val name: String, val count: Int, val minutes: Int)

    /** Totaux imprimés sur le planning (null = absent du document). */
    class Declared(
        val services: Int? = null,
        val workedMin: Int? = null,
        val nightMin: Int? = null,
        val sundayMin: Int? = null,
        val overtimeMin: Int? = null,
        /** « Hrs Trv payables » : heures de travail seules (sans les absences payées). */
        val payableMin: Int? = null,
        /** Cases remplies annoncées dans les propriétés du PDF (vacations + jours d'absence), logiciel Comète. */
        val items: Int? = null,
    ) {
        val isEmpty get() = services == null && workedMin == null && nightMin == null && sundayMin == null
    }

    class Facts(
        val shifts: List<Shift>,
        val absences: List<Shift>,
        val totalMin: Int,
        val nightMin: Int,
        val sundayMin: Int,
        val sites: List<Site>,
        /** Jours travaillés (au moins une vacation qui commence ce jour-là). */
        val daysWorked: Int,
        /** Jours sans vacation ni absence, entre le premier et le dernier jour du mois du planning. */
        val daysOff: Int,
        /** Plus longue suite de jours travaillés d'affilée. */
        val longestStreak: Int,
        /** Absences avec horaires (visite médicale…) : comptées dans les « heures travaillées » du planning. */
        val paidAbsenceMin: Int,
        /** Vacations de 10 heures ou plus. */
        val longShifts: Int,
        /** Repos le plus court entre deux journées de travail (minutes), null s'il n'y en a qu'une. */
        val shortestRestMin: Int?,
        val shortestRestAfter: Shift?,
        val declared: Declared,
    ) {
        /** Cases remplies comme les compte le logiciel du planning (une par jour d'absence). */
        val cells: Int get() = shifts.size + absences.sumOf { if (it.allDay) daysBetween(it.start, it.end) + 1 else 1 }

        /** Écarts avec les totaux du document (vide = tout concorde). */
        val mismatches: List<String>
            get() = buildList {
                declared.services?.let { if (it != shifts.size) add("services") }
                // « Travaillées » comprend les absences payées (visite médicale…) ; « payables » ne les comprend pas
                declared.workedMin?.let { if (kotlin.math.abs(it - totalMin) > 1 && kotlin.math.abs(it - totalMin - paidAbsenceMin) > 1) add("worked") }
                declared.payableMin?.let { if (kotlin.math.abs(it - totalMin) > 1) add("payable") }
                declared.nightMin?.let { if (kotlin.math.abs(it - nightMin) > 1) add("night") }
                declared.sundayMin?.let { if (kotlin.math.abs(it - sundayMin) > 1) add("sunday") }
                declared.items?.let { if (it != cells) add("items") }
            }
    }

    private const val DAY = 86_400_000L

    fun analyse(all: List<Shift>, text: String = "", keywords: String? = null): Facts {
        val shifts = all.filter { !it.absence }.sortedBy { it.start }
        val absences = all.filter { it.absence }.sortedBy { it.start }
        val total = shifts.sumOf { minutes(it.start, it.end) }
        val night = shifts.sumOf { nightMinutes(it.start, it.end) }
        val sunday = shifts.sumOf { sundayMinutes(it.start, it.end) }
        val sites = shifts.groupBy { siteOf(it.label) }
            .map { (name, l) -> Site(name, l.size, l.sumOf { minutes(it.start, it.end) }) }
            .sortedByDescending { it.minutes }
        val workDays = shifts.map { dayStart(it.start) }.toSortedSet()
        var streak = 0; var best = 0; var prev = Long.MIN_VALUE
        for (d in workDays) {
            streak = if (prev != Long.MIN_VALUE && daysBetween(prev, d) == 1) streak + 1 else 1
            best = maxOf(best, streak); prev = d
        }
        // Jours de repos : sur le mois du planning (du 1er au dernier jour), ni vacation ni absence
        val offDays = if (shifts.isEmpty()) 0 else {
            val c = Calendar.getInstance().apply { timeInMillis = shifts.first().start }
            val first = dayStart(c.apply { set(Calendar.DAY_OF_MONTH, 1) }.timeInMillis)
            val last = dayStart(c.apply { set(Calendar.DAY_OF_MONTH, getActualMaximum(Calendar.DAY_OF_MONTH)) }.timeInMillis)
            val absentDays = absences.flatMap { a ->
                val from = dayStart(a.start); val n = if (a.allDay) daysBetween(from, a.end) else 0
                (0..n).map { addDays(from, it) }
            }.toSet()
            (0..daysBetween(first, last)).map { addDays(first, it) }.count { it !in workDays && it !in absentDays }
        }
        // Repos entre deux journées : les vacations séparées de moins de 3 h forment une seule journée (coupure)
        val blocks = mutableListOf<Shift>()
        for (sh in shifts) {
            val last = blocks.lastOrNull()
            if (last != null && sh.start - last.end < 3 * 3_600_000L) blocks[blocks.lastIndex] = last.copy(end = maxOf(last.end, sh.end))
            else blocks += sh
        }
        var rest: Int? = null; var restAfter: Shift? = null
        blocks.zipWithNext().forEach { (a, b) ->
            val r = minutes(a.end, b.start)
            if (r >= 0 && (rest == null || r < rest!!)) { rest = r; restAfter = a }
        }
        return Facts(
            shifts, absences, total, night, sunday, sites,
            paidAbsenceMin = absences.filter { !it.allDay }.sumOf { minutes(it.start, it.end) },
            daysWorked = workDays.size, daysOff = offDays, longestStreak = best,
            longShifts = shifts.count { minutes(it.start, it.end) >= 600 },
            shortestRestMin = rest, shortestRestAfter = restAfter,
            declared = declared(text, keywords),
        )
    }

    /** Site d'une vacation : le début de son intitulé (« RONDIERS · MATIN » → « RONDIERS »). */
    fun siteOf(label: String): String = label.substringBefore(" · ").trim().ifBlank { "Travail" }

    private fun hm(h: String?, m: String?): Int? = h?.toIntOrNull()?.let { it * 60 + (m?.toIntOrNull() ?: 0) }

    /** Totaux imprimés : « Services : 21  Travaillées: 154H20  Nuit: 3H00  Dimanche: 24H00 ». */
    fun declared(text: String, keywords: String? = null): Declared {
        if (text.isBlank() && keywords.isNullOrBlank()) return Declared()
        val t = text.replace(' ', ' ')
        fun dur(label: String) = Regex("""(?i)$label\s*:\s*(\d{1,3})\s*[Hh:]\s*(\d{2})""").find(t)?.let { hm(it.groupValues[1], it.groupValues[2]) }
        return Declared(
            services = Regex("""(?i)Services\s*:\s*(\d{1,3})\b""").find(t)?.groupValues?.get(1)?.toIntOrNull(),
            workedMin = dur("Travaill[ée]es"),
            nightMin = dur("Nuit"),
            sundayMin = dur("Dimanche"),
            payableMin = dur("Hrs\\s+Trv\\s+payables"),
            overtimeMin = Regex("""(?i)Total\s+Heures\s+prises\s+en\s+compte[^\n:]*:\s*\d{1,3}\s*:\s*\d{2}\s+(\d{1,3})\s*:\s*(\d{2})""").find(t)
                ?.let { hm(it.groupValues[1], it.groupValues[2]) },
            items = keywords?.let { Regex(""""NbVac"\s*:\s*"?(\d+)""").find(it)?.groupValues?.get(1)?.toIntOrNull() },
        )
    }

    // ------------------------------------------------------------------ Calculs d'heures

    fun minutes(a: Long, b: Long): Int = ((b - a) / 60_000L).toInt()

    /** Heures de nuit : de 21 h à 6 h (définition du Code du travail, reprise par les plannings de sécurité). */
    fun nightMinutes(start: Long, end: Long): Int {
        var total = 0
        var d = addDays(dayStart(start), -1)
        while (d < end) {
            total += overlap(start, end, at(d, 21), at(addDays(d, 1), 6))
            d = addDays(d, 1)
        }
        return total
    }

    fun sundayMinutes(start: Long, end: Long): Int {
        var total = 0
        var d = dayStart(start)
        while (d < end) {
            val next = addDays(d, 1)
            if (Calendar.getInstance().apply { timeInMillis = d }.get(Calendar.DAY_OF_WEEK) == Calendar.SUNDAY) total += overlap(start, end, d, next)
            d = next
        }
        return total
    }

    private fun overlap(a1: Long, a2: Long, b1: Long, b2: Long): Int = maxOf(0L, minOf(a2, b2) - maxOf(a1, b1)).let { (it / 60_000L).toInt() }

    fun dayStart(t: Long): Long = Calendar.getInstance().apply {
        timeInMillis = t
        set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
    }.timeInMillis

    private fun at(day: Long, h: Int): Long = Calendar.getInstance().apply { timeInMillis = day; set(Calendar.HOUR_OF_DAY, h) }.timeInMillis

    private fun addDays(day: Long, n: Int): Long = Calendar.getInstance().apply { timeInMillis = day; add(Calendar.DAY_OF_YEAR, n) }.timeInMillis

    /** Nombre de jours entre deux dates (au jour près, changements d'heure compris). */
    fun daysBetween(a: Long, b: Long): Int = Math.round((dayStart(b) - dayStart(a)).toDouble() / DAY).toInt()
}
