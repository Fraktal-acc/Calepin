package fr.jeremy.calepin.office.word

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.UUID

/** Document Word du Bureau. */
data class WordEntry(
    val id: String,
    val name: String,
    val created: Long,
    val updated: Long,
    /** Début du texte, pour la liste. */
    val preview: String = "",
    val words: Int = 0,
    /** Ce qui a été simplifié à l'ouverture (montré une seule fois). */
    val warnings: List<String> = emptyList(),
    val pinned: Boolean = false,
) {
    fun toJson(): JSONObject = JSONObject().put("id", id).put("name", name).put("created", created).put("updated", updated)
        .put("preview", preview).put("words", words).put("warnings", JSONArray(warnings)).put("pinned", pinned)

    companion object {
        fun fromJson(o: JSONObject) = WordEntry(
            o.optString("id"), o.optString("name"), o.optLong("created"), o.optLong("updated"), o.optString("preview"), o.optInt("words"),
            o.optJSONArray("warnings")?.let { a -> (0 until a.length()).map { a.optString(it) } }.orEmpty(), o.optBoolean("pinned"),
        )
    }
}

/** Modèle de document proposé à la création. */
enum class WordTemplate(val label: String, val hint: String) {
    VIERGE("Document vierge", "Une page blanche"),
    LETTRE("Lettre", "Expéditeur, destinataire, objet, formule de politesse"),
    COMPTE_RENDU("Compte rendu", "Réunion ou intervention : présents, points, décisions, actions"),
    DEVIS("Devis", "Prestations, tableau des prix, conditions"),
    ;

    fun doc(name: String): WordDoc {
        val today = java.text.SimpleDateFormat("d MMMM yyyy", java.util.Locale.FRANCE).format(java.util.Date())
        val blocks: List<DocBlock> = when (this) {
            VIERGE -> listOf(DocBlock.Text(text = ""))
            LETTRE -> listOf(DocBlock.Text(text = "Prénom Nom\nAdresse\nCode postal Ville\nTéléphone · e-mail\n\n" +
                "Destinataire[right]\nAdresse[right]\nCode postal Ville[right]\n\nLe $today[right]\n\n**Objet : **\n\nMadame, Monsieur,\n\n\n\n" +
                "Je vous prie d'agréer, Madame, Monsieur, l'expression de mes salutations distinguées.\n\nPrénom Nom[right]"))
            COMPTE_RENDU -> listOf(
                DocBlock.Text(text = "# $name\n*$today*\n## Présents\n- \n## Points abordés\n1. \n## Décisions\n- "),
                DocBlock.Table(rows = listOf(listOf("Action", "Qui", "Pour quand"), listOf("", "", ""), listOf("", "", ""))),
                DocBlock.Text(text = "## Prochaine réunion\n"),
            )
            DEVIS -> listOf(
                DocBlock.Text(text = "# Devis[center]\nN° …  ·  le $today[center]\n\n**Client :** \n**Adresse :** \n\n## Prestations"),
                DocBlock.Table(rows = listOf(listOf("Description", "Quantité", "Prix unitaire", "Total"), listOf("", "", "", ""), listOf("", "", "", ""), listOf("**Total**", "", "", ""))),
                DocBlock.Text(text = "## Conditions\nDevis valable 30 jours. Paiement à réception de facture.\n\nBon pour accord, date et signature :"),
            )
        }
        return WordDoc(blocks).normalized()
    }
}

/**
 * Documents Word du Bureau : les fichiers .docx sont gardés dans Calepin (dossier « word »), avec les
 * images de chaque document à côté. Le fichier .docx reste la référence : il peut être partagé tel quel.
 */
class WordLibrary private constructor(ctx: Context) {
    private val app = ctx.applicationContext
    val dir: File = File(app.filesDir, DIR).apply { mkdirs() }
    private val index = File(dir, "index.json")
    private val _items = MutableStateFlow<List<WordEntry>>(emptyList())
    val items: StateFlow<List<WordEntry>> = _items

    init { load() }

    fun load() {
        _items.value = runCatching {
            val a = JSONArray(index.readText())
            (0 until a.length()).map { WordEntry.fromJson(a.getJSONObject(it)) }
        }.getOrDefault(emptyList()).filter { file(it.id).exists() }
    }

    @Synchronized
    private fun persist() {
        val a = JSONArray(); _items.value.forEach { a.put(it.toJson()) }
        val tmp = File(dir, "index.json.tmp"); tmp.writeText(a.toString()); tmp.renameTo(index)
    }

    private fun update(e: WordEntry) {
        val l = _items.value.toMutableList()
        val i = l.indexOfFirst { it.id == e.id }
        if (i >= 0) l[i] = e else l += e
        _items.value = l
        persist()
    }

    fun file(id: String) = File(dir, "$id.docx")
    fun mediaDir(id: String) = File(dir, "${id}_media").apply { mkdirs() }
    fun entry(id: String) = _items.value.firstOrNull { it.id == id }

    /** Nom unique (« Document », « Document 2 »…). */
    fun uniqueName(base: String): String {
        val names = _items.value.map { it.name.lowercase() }.toSet()
        if (base.lowercase() !in names) return base
        var n = 2
        while ("$base $n".lowercase() in names) n++
        return "$base $n"
    }

    suspend fun create(name: String, template: WordTemplate): WordEntry = withContext(Dispatchers.IO) {
        val id = UUID.randomUUID().toString()
        val n = uniqueName(name.ifBlank { template.label })
        val e = WordEntry(id, n, System.currentTimeMillis(), System.currentTimeMillis())
        writeDoc(e, template.doc(n))
    }

    /** Ouvre le document : le .docx est lu, ses images rangées dans son dossier. */
    suspend fun open(id: String): WordDoc = withContext(Dispatchers.IO) {
        val r = DocxReader.read(file(id).readBytes())
        val md = mediaDir(id)
        // Images du document relues à chaque ouverture (les anciennes retirées)
        md.listFiles()?.forEach { f -> if (f.name.startsWith("img_") && f.name !in r.images.keys) f.delete() }
        r.images.forEach { (n, b) -> File(md, n).let { if (!it.exists() || it.length() != b.size.toLong()) it.writeBytes(b) } }
        r.doc
    }

    /** Enregistre le document dans son fichier .docx. */
    suspend fun save(id: String, doc: WordDoc): WordEntry? = withContext(Dispatchers.IO) {
        val e = entry(id) ?: return@withContext null
        writeDoc(e.copy(updated = System.currentTimeMillis()), doc)
    }

    private fun writeDoc(e: WordEntry, doc: WordDoc): WordEntry {
        val md = mediaDir(e.id)
        val bytes = DocxWriter.write(doc, e.name) { n -> File(md, n).takeIf { it.exists() }?.readBytes() }
        val tmp = File(dir, e.id + ".tmp")
        tmp.writeBytes(bytes)
        if (!tmp.renameTo(file(e.id))) { file(e.id).writeBytes(bytes); tmp.delete() }
        val text = doc.plainText()
        val ne = e.copy(preview = text.lines().map { it.trim() }.filter { it.isNotEmpty() }.joinToString(" · ").take(160), words = doc.stats().words)
        update(ne)
        return ne
    }

    /** Ajoute une image au document (copiée dans son dossier) ; renvoie son nom. */
    suspend fun addImage(id: String, uri: Uri): String? = withContext(Dispatchers.IO) {
        runCatching {
            val mime = app.contentResolver.getType(uri).orEmpty()
            val ext = when { "png" in mime -> "png"; "gif" in mime -> "gif"; "webp" in mime -> "webp"; else -> "jpg" }
            val name = "pic_" + UUID.randomUUID().toString().take(8) + "." + ext
            val f = File(mediaDir(id), name)
            app.contentResolver.openInputStream(uri)?.use { i -> f.outputStream().use { i.copyTo(it) } } ?: return@runCatching null
            // Photo très grande : réduite (document plus léger)
            shrink(f)
            name
        }.getOrNull()
    }

    /** Photo prise avec l'appareil : fichier prêt à recevoir l'image. */
    fun newPhotoFile(id: String): File = File(mediaDir(id), "pic_" + UUID.randomUUID().toString().take(8) + ".jpg")

    fun shrink(f: File) {
        runCatching {
            val o = android.graphics.BitmapFactory.Options().apply { inJustDecodeBounds = true }
            android.graphics.BitmapFactory.decodeFile(f.path, o)
            if (maxOf(o.outWidth, o.outHeight) <= 2000 && f.length() < 1_500_000) return
            val bm = fr.jeremy.calepin.media.Media.thumbnail(f, false, 2000) ?: return
            val png = f.name.endsWith(".png")
            f.outputStream().use { bm.compress(if (png) android.graphics.Bitmap.CompressFormat.PNG else android.graphics.Bitmap.CompressFormat.JPEG, 88, it) }
            bm.recycle()
        }
    }

    /** Importe un fichier du téléphone : .docx tel quel ; .txt, .md, .html, .odt convertis. */
    suspend fun import(uri: Uri): WordEntry = withContext(Dispatchers.IO) {
        val name = displayName(uri)
        val base = name.substringBeforeLast('.').ifBlank { "Document" }
        val ext = name.substringAfterLast('.', "").lowercase()
        val bytes = app.contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: error("Fichier illisible")
        importBytes(bytes, base, ext)
    }

    suspend fun importBytes(bytes: ByteArray, base: String, ext: String): WordEntry = withContext(Dispatchers.IO) {
        val id = UUID.randomUUID().toString()
        val now = System.currentTimeMillis()
        val isZip = bytes.size > 4 && bytes[0] == 'P'.code.toByte() && bytes[1] == 'K'.code.toByte()
        when {
            ext == "doc" || (bytes.size > 8 && bytes[0] == 0xD0.toByte() && bytes[1] == 0xCF.toByte()) ->
                error("Les anciens fichiers Word (.doc) ne sont pas pris en charge : enregistre-le en .docx depuis Word, ou ouvre-le dans Google Docs puis télécharge-le en .docx.")
            ext == "odt" || (isZip && bytes.size > 100 && String(bytes, 30, 60, Charsets.ISO_8859_1).contains("mimetypeapplication/vnd.oasis")) -> {
                val r = OdtReader.read(bytes)
                val md = mediaDir(id)
                r.images.forEach { (n, b) -> File(md, n).writeBytes(b) }
                writeDoc(WordEntry(id, uniqueName(base), now, now, warnings = r.warnings), r.doc)
            }
            isZip -> {
                val r = DocxReader.read(bytes) // vérifie que c'est bien un document Word
                file(id).writeBytes(bytes)
                val e = WordEntry(id, uniqueName(r.title?.takeIf { base.isBlank() } ?: base), now, now, warnings = r.warnings)
                update(e)
                // Aperçu et nombre de mots
                e.copy(preview = r.doc.plainText().lines().map { it.trim() }.filter { it.isNotEmpty() }.joinToString(" · ").take(160), words = r.doc.stats().words).also { update(it) }
            }
            else -> {
                // Texte simple, Markdown ou page web
                val text = String(bytes, Charsets.UTF_8).let { t -> if (ext == "html" || ext == "htm" || t.trimStart().startsWith("<")) htmlToMarkup(t) else t }
                writeDoc(WordEntry(id, uniqueName(base), now, now), WordDoc(listOf(DocBlock.Text(text = text.replace("\r\n", "\n")))).normalized())
            }
        }
    }

    /** Crée un document à partir du texte d'une note (même écriture). */
    suspend fun fromNote(title: String, content: String): WordEntry = withContext(Dispatchers.IO) {
        val id = UUID.randomUUID().toString()
        val now = System.currentTimeMillis()
        val clean = fr.jeremy.calepin.text.NoteLayout.marker.replace(content, "").replace(Regex("\n{3,}"), "\n\n")
        val text = (if (title.isNotBlank()) "# $title\n" else "") + clean
        writeDoc(WordEntry(id, uniqueName(title.ifBlank { "Note" }), now, now), WordDoc(listOf(DocBlock.Text(text = text))).normalized())
    }

    private fun htmlToMarkup(html: String): String {
        var t = html.replace(Regex("(?is)<(script|style)[^>]*>.*?</\\1>"), "")
        t = t.replace(Regex("(?i)<h1[^>]*>"), "\n# ").replace(Regex("(?i)<h2[^>]*>"), "\n## ").replace(Regex("(?i)<h[3-6][^>]*>"), "\n### ")
        t = t.replace(Regex("(?i)<li[^>]*>"), "\n- ").replace(Regex("(?i)<(br|/p|/h\\d|/div|/tr)[^>]*>"), "\n")
        t = t.replace(Regex("(?i)</?(b|strong)>"), "**").replace(Regex("(?i)</?(i|em)>"), "*")
        t = t.replace(Regex("<[^>]+>"), "")
        t = t.replace("&nbsp;", " ").replace("&amp;", "&").replace("&lt;", "<").replace("&gt;", ">").replace("&quot;", "\"").replace("&#39;", "'")
        return t.lines().joinToString("\n") { it.trim() }.replace(Regex("\n{3,}"), "\n\n").trim()
    }

    fun displayName(uri: Uri): String = runCatching {
        app.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c -> if (c.moveToFirst()) c.getString(0) else null }
    }.getOrNull() ?: uri.lastPathSegment?.substringAfterLast('/') ?: "Document"

    fun rename(id: String, name: String) {
        val e = entry(id) ?: return
        update(e.copy(name = name.trim().ifBlank { e.name }))
    }

    fun clearWarnings(id: String) { entry(id)?.let { if (it.warnings.isNotEmpty()) update(it.copy(warnings = emptyList())) } }

    fun togglePin(id: String) { entry(id)?.let { update(it.copy(pinned = !it.pinned)) } }

    suspend fun duplicate(id: String): WordEntry? = withContext(Dispatchers.IO) {
        val e = entry(id) ?: return@withContext null
        val nid = UUID.randomUUID().toString()
        file(id).copyTo(file(nid), overwrite = true)
        mediaDir(id).listFiles()?.forEach { it.copyTo(File(mediaDir(nid), it.name), overwrite = true) }
        val now = System.currentTimeMillis()
        e.copy(id = nid, name = uniqueName(e.name + " (copie)"), created = now, updated = now, warnings = emptyList(), pinned = false).also { update(it) }
    }

    /** Retire le document de la liste ; les fichiers restent jusqu'à [purge] (« Annuler » possible). */
    fun remove(id: String): WordEntry? {
        val e = entry(id) ?: return null
        _items.value = _items.value.filterNot { it.id == id }
        persist()
        return e
    }

    fun restore(e: WordEntry) = update(e)

    fun purge(id: String) {
        if (entry(id) != null) return
        file(id).delete()
        File(dir, "${id}_media").deleteRecursively()
    }

    companion object {
        const val DIR = "word"
        @Volatile private var instance: WordLibrary? = null
        fun get(ctx: Context): WordLibrary = instance ?: synchronized(this) { instance ?: WordLibrary(ctx).also { instance = it } }
    }
}
