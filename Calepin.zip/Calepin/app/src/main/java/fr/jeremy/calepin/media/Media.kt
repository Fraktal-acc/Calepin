package fr.jeremy.calepin.media

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.media.ExifInterface
import android.media.MediaMetadataRetriever
import android.net.Uri
import java.io.File
import java.util.UUID

/** Photos et vidéos des notes : copie dans le dossier privé de l'appli et miniatures. */
object Media {
    fun dir(ctx: Context): File = File(ctx.filesDir, "media").apply { mkdirs() }

    /** Nouveau fichier vide pour l'appareil photo ou la caméra. */
    fun newFile(ctx: Context, video: Boolean): File =
        File(dir(ctx), UUID.randomUUID().toString() + if (video) ".mp4" else ".jpg")

    /** Copie un élément choisi dans la galerie ; renvoie le fichier et s'il s'agit d'une vidéo. */
    fun importUri(ctx: Context, uri: Uri): Pair<File, Boolean>? {
        val type = ctx.contentResolver.getType(uri) ?: ""
        val video = type.startsWith("video/")
        val ext = when {
            video -> "mp4"
            type.contains("png") -> "png"
            type.contains("webp") -> "webp"
            type.contains("heic") || type.contains("heif") -> "heic"
            type.contains("gif") -> "gif"
            else -> "jpg"
        }
        val f = File(dir(ctx), UUID.randomUUID().toString() + "." + ext)
        return try {
            ctx.contentResolver.openInputStream(uri)?.use { input -> f.outputStream().use { input.copyTo(it) } } ?: return null
            f to video
        } catch (e: Exception) {
            f.delete(); null
        }
    }

    fun mimeOf(f: File): String = when (f.extension.lowercase()) {
        "mp4" -> "video/mp4"
        "png" -> "image/png"
        "webp" -> "image/webp"
        "gif" -> "image/gif"
        "heic" -> "image/heic"
        else -> "image/jpeg"
    }

    /** Miniature (ou image réduite pour l'affichage) en respectant l'orientation de la photo. */
    fun thumbnail(f: File, isVideo: Boolean, maxSide: Int): Bitmap? = try {
        if (isVideo) {
            val r = MediaMetadataRetriever()
            try {
                r.setDataSource(f.absolutePath)
                r.getFrameAtTime(1_000_000)?.let { scale(it, maxSide) }
            } finally {
                r.release()
            }
        } else {
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(f.absolutePath, bounds)
            var sample = 1
            while (maxOf(bounds.outWidth, bounds.outHeight) / (sample * 2) >= maxSide) sample *= 2
            val bmp = BitmapFactory.decodeFile(f.absolutePath, BitmapFactory.Options().apply { inSampleSize = sample })
            bmp?.let { rotate(it, f) }
        }
    } catch (e: Throwable) {
        null
    }

    private fun scale(b: Bitmap, maxSide: Int): Bitmap {
        val m = maxOf(b.width, b.height)
        if (m <= maxSide) return b
        val k = maxSide.toFloat() / m
        return Bitmap.createScaledBitmap(b, (b.width * k).toInt().coerceAtLeast(1), (b.height * k).toInt().coerceAtLeast(1), true)
    }

    private fun rotate(b: Bitmap, f: File): Bitmap {
        val deg = runCatching {
            when (ExifInterface(f.absolutePath).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)) {
                ExifInterface.ORIENTATION_ROTATE_90 -> 90f
                ExifInterface.ORIENTATION_ROTATE_180 -> 180f
                ExifInterface.ORIENTATION_ROTATE_270 -> 270f
                else -> 0f
            }
        }.getOrDefault(0f)
        if (deg == 0f) return b
        return Bitmap.createBitmap(b, 0, 0, b.width, b.height, Matrix().apply { postRotate(deg) }, true)
    }
}
