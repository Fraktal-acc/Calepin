package fr.jeremy.calepin.ui

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.speech.RecognizerIntent
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.filled.AccessAlarm
import androidx.compose.material.icons.filled.Today
import androidx.compose.material.icons.filled.KeyboardVoice
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material3.Surface
import androidx.compose.runtime.derivedStateOf
import androidx.compose.ui.Alignment
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.input.TextFieldValue
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import fr.jeremy.calepin.LockGuard
import fr.jeremy.calepin.data.Event
import fr.jeremy.calepin.data.Attachment
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.width
import androidx.compose.ui.draw.clip
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.FolderOff
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.withFrameNanos
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.material.icons.filled.RecordVoiceOver
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.FormatBold
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.FormatUnderlined
import androidx.compose.material.icons.filled.FormatColorText
import androidx.compose.material.icons.filled.BorderColor
import androidx.compose.material.icons.filled.FormatAlignCenter
import androidx.compose.material.icons.filled.FormatAlignRight
import androidx.compose.material.icons.filled.FormatAlignLeft
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.layout.onPlaced
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.foundation.gestures.scrollBy
import androidx.compose.material.icons.filled.FormatItalic
import androidx.compose.material.icons.filled.FormatStrikethrough
import androidx.compose.material.icons.filled.Title
import androidx.compose.material.icons.filled.FormatListBulleted
import androidx.compose.material.icons.filled.Link
import androidx.compose.ui.unit.em
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.consumeWindowInsets
import androidx.compose.foundation.layout.ime
import androidx.compose.material.icons.filled.SelectAll
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInParent
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.TextLayoutResult
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Draw
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material.icons.filled.PhotoCamera
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Checklist
import androidx.compose.material.icons.filled.DocumentScanner
import androidx.compose.material.icons.filled.ImageSearch
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.runtime.rememberCoroutineScope
import kotlinx.coroutines.launch
import fr.jeremy.calepin.BuildConfig
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Alarm
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Directions
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.EventAvailable
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Map
import androidx.compose.material.icons.filled.Navigation
import androidx.compose.material.icons.filled.PersonAdd
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.PushPin
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.SaveAlt
import androidx.compose.material.icons.filled.Sms
import androidx.compose.material.icons.outlined.PushPin
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.AssistChip
import androidx.compose.material3.AssistChipDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ListItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Scaffold
import fr.jeremy.calepin.i18n.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.LinkAnnotation
import androidx.compose.ui.text.LinkInteractionListener
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextLinkStyles
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.withLink
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import fr.jeremy.calepin.Actions
import fr.jeremy.calepin.NotesViewModel
import fr.jeremy.calepin.data.Note
import fr.jeremy.calepin.detect.Entity
import fr.jeremy.calepin.detect.EntityDetector
import fr.jeremy.calepin.detect.EntityType
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun EditorScreen(
    vm: NotesViewModel,
    noteId: Long?,
    initialText: String?,
    initialTitle: String? = null,
    initialFolder: String = "",
    scanOnOpen: Boolean = false,
    onClose: () -> Unit,
    /** Lien [[Titre]] touché : note existante (id) ou nouvelle note à ce titre (id null). */
    onOpenNote: (Long?, String) -> Unit = { _, _ -> },
) {
    val existing = remember(noteId) { noteId?.let { vm.find(it) } }
    var id by remember { mutableLongStateOf(existing?.id ?: 0L) }
    var title by rememberSaveable { mutableStateOf(existing?.title ?: initialTitle ?: "") }
    var field by rememberSaveable(stateSaver = TextFieldValue.Saver) {
        val t0 = existing?.content ?: initialText ?: ""
        mutableStateOf(TextFieldValue(t0, TextRange(if (existing == null) t0.length else 0)))
    }
    val content by remember { derivedStateOf { field.text } }
    var tag by rememberSaveable { mutableStateOf(existing?.tag ?: "") }
    var pinned by rememberSaveable { mutableStateOf(existing?.pinned ?: false) }
    var folder by rememberSaveable { mutableStateOf(existing?.folder ?: initialFolder) }
    var pickingFolder by remember { mutableStateOf(false) }
    val allFolders by vm.folders.collectAsStateWithLifecycle()
    var editing by rememberSaveable { mutableStateOf(existing == null) }
    val createdAt = remember { existing?.createdAt ?: System.currentTimeMillis() }
    var savedSnapshot by remember { mutableStateOf(existing) }
    var selected by remember { mutableStateOf<Entity?>(null) }
    var confirmDelete by remember { mutableStateOf(false) }
    var exporting by remember { mutableStateOf(false) }
    var menuOpen by remember { mutableStateOf(false) }
    var aiMenu by remember { mutableStateOf(false) }
    var aiTool by remember { mutableStateOf<fr.jeremy.calepin.ai.AiTool?>(null) }
    var scanning by remember { mutableStateOf(false) }
    var scanFile by remember { mutableStateOf<java.io.File?>(null) }
    var eventDraft by remember { mutableStateOf<Event?>(null) }
    var showVersions by remember { mutableStateOf(false) }
    // Recherche dans la note ouverte
    var searchOpen by rememberSaveable { mutableStateOf(false) }
    var query by rememberSaveable { mutableStateOf("") }
    var matchIdx by remember { mutableIntStateOf(0) }
    // Photos et vidéos placées dans le texte
    var mediaVersion by remember { mutableIntStateOf(0) }
    var mediaMenu by remember { mutableStateOf(false) }
    var speaking by remember { mutableStateOf(false) }
    val speakerCtx = LocalContext.current
    val speaker = remember { fr.jeremy.calepin.assistant.Speaker(speakerCtx) { speaking = false } }
    DisposableEffect(Unit) { onDispose { speaker.shutdown() } }
    val allEvents by vm.events.collectAsStateWithLifecycle()
    val defaultRingtone by vm.settings.ringtone.collectAsStateWithLifecycle()
    val noteEvents = if (id == 0L) emptyList() else allEvents.filter { it.noteId == id }
    val ctx = LocalContext.current

    /** Insère du texte à l'emplacement du curseur (ou à la fin hors édition). */
    fun insertText(t: String) {
        val f = field
        val pos = if (editing) f.selection.end.coerceIn(0, f.text.length) else f.text.length
        val before = f.text.substring(0, pos)
        val sep = when {
            before.isEmpty() -> ""
            before.endsWith("\n") -> ""
            editing && !before.endsWith(" ") -> " "
            else -> "\n\n"
        }
        val newText = before + sep + t + f.text.substring(pos)
        field = TextFieldValue(newText, TextRange(pos + sep.length + t.length))
    }

    /** Prépare un rendez-vous à partir d'un texte : sa date s'il en contient une, sinon demain 9 h. */
    fun draftFrom(text: String, alarm: Boolean, fallbackTitle: String) {
        val d = EntityDetector.detect(text).firstOrNull { it.type == EntityType.DATE && it.timeMillis != null }
        val start = d?.timeMillis ?: java.util.Calendar.getInstance().apply {
            add(java.util.Calendar.DAY_OF_YEAR, 1)
            set(java.util.Calendar.HOUR_OF_DAY, 9); set(java.util.Calendar.MINUTE, 0); set(java.util.Calendar.SECOND, 0)
        }.timeInMillis
        val allDay = d != null && !d.hasTime
        val cleaned = text.replace(Regex("\\s+"), " ").trim().take(80)
        eventDraft = Event(
            title = cleaned.ifBlank { fallbackTitle },
            start = start,
            end = d?.endMillis ?: 0L,
            allDay = allDay,
            remindMinutes = if (allDay) -540 else if (alarm) 0 else 15,
            alarm = alarm,
        )
    }

    val dictation = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { res ->
        val text = res.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
        if (res.resultCode == Activity.RESULT_OK && !text.isNullOrBlank()) {
            insertText(text.replaceFirstChar { it.uppercase() })
        }
    }

    val scope = rememberCoroutineScope()

    /** Lit le texte d'une photo (sur le téléphone) et l'ajoute à la note. */
    fun ocr(uri: android.net.Uri, cleanup: java.io.File?) {
        scanning = true
        scope.launch {
            val text = runCatching { fr.jeremy.calepin.media.PdfText.extractImage(ctx, uri).text.trim() }.getOrDefault("")
            cleanup?.delete()
            scanning = false
            if (text.isBlank()) fr.jeremy.calepin.i18n.I18n.toast(ctx, "Aucun texte trouvé sur l'image", Toast.LENGTH_LONG).show()
            else { if (!editing) editing = true; insertText(text) }
        }
    }
    val scanPhoto = rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()) { ok ->
        val f = scanFile
        scanFile = null
        if (f != null) { if (ok) ocr(fr.jeremy.calepin.Files.uriFor(ctx, f), f) else f.delete() }
    }
    val scanPick = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) ocr(uri, null)
    }
    fun startScan(fromCamera: Boolean) {
        LockGuard.external()
        if (fromCamera) {
            val f = java.io.File(fr.jeremy.calepin.media.Media.dir(ctx), "scan_" + System.currentTimeMillis() + ".jpg")
            scanFile = f
            runCatching { scanPhoto.launch(fr.jeremy.calepin.Files.uriFor(ctx, f)) }
                .onFailure { scanFile = null; fr.jeremy.calepin.i18n.I18n.toast(ctx, "Aucun appareil photo disponible", Toast.LENGTH_SHORT).show() }
        } else {
            scanPick.launch(androidx.activity.result.PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
        }
    }

    // Widget « Scanner » : l'appareil photo s'ouvre tout de suite
    LaunchedEffect(Unit) { if (scanOnOpen && id == 0L && content.isEmpty()) startScan(fromCamera = true) }

    val entities = remember(content) { EntityDetector.detect(content) }

    fun persist() {
        if (title.isBlank() && content.isBlank()) return
        val s = savedSnapshot
        if (s != null && s.title == title && s.content == content && s.tag == tag && s.pinned == pinned && s.folder == folder) return
        val note = Note(
            id = id, title = title.trim(), content = content, tag = tag.trim(), pinned = pinned,
            createdAt = createdAt, updatedAt = System.currentTimeMillis(), folder = folder,
        )
        id = vm.saveNow(note)
        savedSnapshot = note.copy(id = id, title = title, tag = tag)
    }

    /** Pour un mémo vocal : la note doit exister. Une note vide reçoit un titre daté. */
    fun ensureNote(): Long {
        if (title.isBlank() && content.isBlank()) {
            title = fr.jeremy.calepin.i18n.I18n.tr("Mémo vocal du") + " " + SimpleDateFormat(fr.jeremy.calepin.i18n.I18n.pattern("d MMMM 'à' HH'h'mm"), fr.jeremy.calepin.i18n.I18n.locale).format(Date())
        }
        persist()
        return id
    }

    fun close() {
        persist()
        onClose()
    }

    BackHandler { if (searchOpen) { searchOpen = false; query = "" } else close() }

    // --- Recherche dans la note ---
    val matches = remember(content, query, searchOpen) { if (searchOpen) NoteFind.find(content, query) else emptyList() }
    LaunchedEffect(query) { matchIdx = 0 }
    val curIdx = if (matches.isEmpty()) -1 else matchIdx.coerceIn(0, matches.size - 1)
    val currentMatch = matches.getOrNull(curIdx)

    // --- Photos et vidéos dans le texte ---
    val attachments = remember(id, content, mediaVersion) { vm.attachmentsOf(id) }
    val placedFiles = remember(content) { InlineMedia.placed(content) }
    val inlineMedia = attachments.filter { it.fileName in placedFiles }

    /** Nouvelles photos : à l'endroit du curseur en écriture, sous le texte en lecture. */
    fun placeMedia(items: List<Attachment>) {
        if (items.isEmpty()) return
        field = if (editing) InlineMedia.insertAt(field, items)
        else TextFieldValue(InlineMedia.appendAtEnd(field.text, items), TextRange(0))
        mediaVersion++
        if (!editing) persist()
    }

    fun mediaUnplaced(a: Attachment) {
        val nt = InlineMedia.remove(field.text, a.fileName)
        if (nt != field.text) {
            field = TextFieldValue(nt, TextRange(field.selection.start.coerceIn(0, nt.length)))
            persist()
        }
        mediaVersion++
    }

    fun mediaDeleted(a: Attachment) {
        val nt = InlineMedia.remove(field.text, a.fileName)
        if (nt != field.text) {
            field = TextFieldValue(nt, TextRange(field.selection.start.coerceIn(0, nt.length)))
            persist()
        }
        mediaVersion++
    }

    // Sauvegarde automatique si l'appli passe en arrière-plan.
    val latestPersist by rememberUpdatedState({ persist() })
    val lifecycleOwner = LocalLifecycleOwner.current
    DisposableEffect(lifecycleOwner) {
        val obs = LifecycleEventObserver { _, e -> if (e == Lifecycle.Event.ON_STOP) latestPersist() }
        lifecycleOwner.lifecycle.addObserver(obs)
        onDispose { lifecycleOwner.lifecycle.removeObserver(obs) }
    }

    // --- Garder la position de lecture entre « lecture » et « modification » ---
    val scroll = rememberScrollState()
    val focus = remember { FocusRequester() }
    val focusManager = LocalFocusManager.current
    var readLayout by remember { mutableStateOf<TextLayoutResult?>(null) }
    var readTop by remember { mutableFloatStateOf(0f) }
    /** Lecture : chaque morceau de texte (coupé par les photos) → sa mise en page et sa position dans la page. */
    val readSegs = remember { androidx.compose.runtime.mutableStateMapOf<Int, Pair<TextLayoutResult, Float>>() }

    fun readTopOf(off: Int): Float? {
        val e = readSegs.entries.filter { it.key <= off }.maxByOrNull { it.key } ?: return null
        val (l, top) = e.value
        return top + l.getLineTop(l.getLineForOffset((off - e.key).coerceIn(0, l.layoutInput.text.length)))
    }

    fun readOffsetAt(y: Float): Int {
        val e = readSegs.entries.filter { it.value.second <= y }.maxByOrNull { it.value.second } ?: return 0
        val (l, top) = e.value
        return e.key + l.getOffsetForPosition(Offset(0f, (y - top).coerceAtLeast(0f)))
    }
    var editLayout by remember { mutableStateOf<TextLayoutResult?>(null) }
    var editTop by remember { mutableFloatStateOf(0f) }
    /** Après un changement de mode : (position dans le texte, hauteur voulue à l'écran pour cette ligne). */
    var anchor by remember { mutableStateOf<Pair<Int, Float>?>(null) }

    fun lineTop(l: TextLayoutResult, offset: Int): Float =
        l.getLineTop(l.getLineForOffset(offset.coerceIn(0, l.layoutInput.text.length)))

    /** Position dans le texte de la première ligne visible à l'écran. */
    fun firstVisible(l: TextLayoutResult?, top: Float): Int =
        l?.getOffsetForPosition(Offset(0f, (scroll.value - top).coerceAtLeast(0f))) ?: 0

    fun startEditing(offset: Int, screenY: Float) {
        field = field.copy(selection = TextRange(offset.coerceIn(0, field.text.length)))
        editLayout = null
        anchor = offset to screenY
        editing = true
    }

    fun startEditingHere() {
        val off = readOffsetAt(scroll.value.toFloat()).coerceIn(0, field.text.length)
        startEditing(off, (readTopOf(off) ?: scroll.value.toFloat()) - scroll.value)
    }

    fun stopEditing() {
        // Mises en forme vides ou incomplètes retirées
        val cleaned = fr.jeremy.calepin.text.RichText.clean(field.text)
        if (cleaned != field.text) field = TextFieldValue(cleaned, TextRange(field.selection.start.coerceIn(0, cleaned.length)))
        persist()
        // En lecture, on retrouve l'endroit où se trouvait le curseur (vers le haut de l'écran)
        anchor = field.selection.start.coerceIn(0, field.text.length) to 160f
        focusManager.clearFocus()
        readLayout = null
        readSegs.clear()
        editing = false
    }

    LaunchedEffect(anchor, editing, readLayout, editLayout) {
        val a = anchor ?: return@LaunchedEffect
        if ((if (editing) editLayout else readLayout) == null) return@LaunchedEffect
        withFrameNanos { } // laisser la mise en page se terminer
        val lineY = if (editing) editLayout?.let { editTop + lineTop(it, fr.jeremy.calepin.text.RichText.Mapping(field.text).toVisible(a.first)) } else readTopOf(a.first)
        if (lineY == null) return@LaunchedEffect
        scroll.scrollTo((lineY - a.second).toInt().coerceIn(0, scroll.maxValue))
        // Le curseur est déjà au bon endroit : le clavier s'ouvre sans faire sauter l'écran
        if (editing) runCatching { focus.requestFocus() }
        anchor = null
    }

    fun startDictation() {
        LockGuard.external()
        try {
            dictation.launch(
                Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE, fr.jeremy.calepin.i18n.I18n.language.value.speechTag)
                    putExtra(RecognizerIntent.EXTRA_PROMPT, fr.jeremy.calepin.i18n.I18n.tr("Parlez, le texte s'écrit dans la note"))
                }
            )
        } catch (e: Exception) {
            fr.jeremy.calepin.i18n.I18n.toast(ctx, "La dictée vocale n'est pas disponible sur ce téléphone", Toast.LENGTH_LONG).show()
        }
    }

    // Photos ajoutées en écrivant : placées sous la ligne du curseur
    val editAdder = rememberMediaAdder(vm, { ensureNote() }) { placeMedia(it) }

    // --- Mise en page des photos en lecture : appui long puis glisser pour déplacer ---
    /** Zone de la page de lecture (repère commun des textes et des photos). */
    val colRef = remember { arrayOfNulls<androidx.compose.ui.layout.LayoutCoordinates>(1) }
    var viewportH by remember { mutableIntStateOf(0) }
    val photoBounds = remember { HashMap<String, androidx.compose.ui.geometry.Rect>() }
    var dragFile by remember { mutableStateOf<String?>(null) }
    var dragOffset by remember { mutableStateOf(Offset.Zero) }
    var dragStart by remember { mutableStateOf<androidx.compose.ui.geometry.Rect?>(null) }
    var dragTouch by remember { mutableStateOf(Offset.Zero) }
    var ghost by remember { mutableStateOf<androidx.compose.ui.graphics.ImageBitmap?>(null) }
    var layoutFor by remember { mutableStateOf<Attachment?>(null) }
    var viewingMedia by remember { mutableStateOf<Attachment?>(null) }
    var deletingMedia by remember { mutableStateOf<Attachment?>(null) }
    val haptics = androidx.compose.ui.platform.LocalHapticFeedback.current

    /** Où la photo soulevée va se poser : (position dans le texte, hauteur du repère, côté). */
    fun dropTarget(): Triple<Int, Float, fr.jeremy.calepin.text.NoteLayout.Side>? {
        val st = dragStart ?: return null
        val r = st.translate(dragOffset)
        val colW = colRef[0]?.size?.width ?: return null
        val side = when {
            r.center.x < colW * 0.38f -> fr.jeremy.calepin.text.NoteLayout.Side.LEFT
            r.center.x > colW * 0.62f -> fr.jeremy.calepin.text.NoteLayout.Side.RIGHT
            else -> fr.jeremy.calepin.text.NoteLayout.Side.FULL
        }
        if (readSegs.isEmpty()) return Triple(content.length, r.top, side)
        val y = r.top
        val off = readOffsetAt(y).coerceIn(0, content.length)
        val ls = Checklist.lineStart(content, off)
        val nl = content.indexOf('\n', off)
        val next = if (nl < 0) content.length else nl + 1
        val yLs = readTopOf(ls) ?: y
        val yNext = if (next >= content.length) {
            val last = readSegs.entries.maxByOrNull { it.key }?.value
            if (last != null) last.second + last.first.size.height else y
        } else readTopOf(next) ?: y
        return if (kotlin.math.abs(y - yLs) <= kotlin.math.abs(y - yNext)) Triple(ls, yLs, side) else Triple(next, yNext, side)
    }

    fun endDrag() { dragFile = null; dragStart = null; dragOffset = Offset.Zero; ghost = null }

    /** Gestes d'une photo du texte : toucher = l'ouvrir, appui long = la soulever, glisser = la déplacer. */
    fun photoTouch(a: Attachment): Modifier = Modifier
        .onGloballyPositioned { c ->
            val col = colRef[0]
            if (col != null && col.isAttached && c.isAttached) photoBounds[a.fileName] = col.localBoundingBoxOf(c, false)
        }
        .photoGestures(
            key = a.fileName,
            onTap = { viewingMedia = a },
            onLift = { touch ->
                haptics.performHapticFeedback(androidx.compose.ui.hapticfeedback.HapticFeedbackType.LongPress)
                dragStart = photoBounds[a.fileName]
                dragTouch = touch
                dragOffset = Offset.Zero
                dragFile = a.fileName
                val f = vm.fileOf(a)
                scope.launch {
                    ghost = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) { fr.jeremy.calepin.media.Media.thumbnail(f, a.isVideo, 480) }?.asImageBitmap()
                }
            },
            onDrag = { d -> dragOffset += d },
            onDrop = { moved ->
                val target = if (moved) dropTarget() else null
                endDrag()
                if (!moved) layoutFor = a
                else if (target != null) {
                    val (pos, _, side) = target
                    val old = fr.jeremy.calepin.text.NoteLayout.specFor(content, a.fileName)
                    val w = when {
                        side == fr.jeremy.calepin.text.NoteLayout.Side.FULL -> if (old != null && old.side == fr.jeremy.calepin.text.NoteLayout.Side.FULL) old.width else 100
                        old != null && (old.side == fr.jeremy.calepin.text.NoteLayout.Side.LEFT || old.side == fr.jeremy.calepin.text.NoteLayout.Side.RIGHT) -> old.width
                        else -> fr.jeremy.calepin.text.NoteLayout.DEFAULT_WIDTH
                    }
                    val nt = fr.jeremy.calepin.text.NoteLayout.move(content, a.fileName, side, w, pos, a.isVideo)
                    if (nt != content) {
                        field = TextFieldValue(nt, TextRange(0))
                        persist()
                    }
                }
            },
        )

    // Photo soulevée près du haut ou du bas de l'écran : la page défile toute seule
    LaunchedEffect(dragFile) {
        if (dragFile == null) return@LaunchedEffect
        while (dragFile != null) {
            withFrameNanos { }
            val st = dragStart ?: continue
            val fingerY = st.top + dragTouch.y + dragOffset.y - scroll.value
            val edge = 140f
            val d = when {
                fingerY < edge -> -(edge - fingerY).coerceAtMost(edge) / 6f
                viewportH > 0 && fingerY > viewportH - edge -> (fingerY - (viewportH - edge)).coerceAtMost(edge) / 6f
                else -> 0f
            }
            if (d != 0f) {
                val used = scroll.scrollBy(d)
                if (used != 0f) dragOffset += Offset(0f, used)
            }
        }
    }

    // Lecture : faire défiler jusqu'au résultat de recherche en cours
    LaunchedEffect(currentMatch, readLayout, editing) {
        val m = currentMatch ?: return@LaunchedEffect
        if (editing) return@LaunchedEffect
        if (readLayout == null) return@LaunchedEffect
        val y = readTopOf(m.first) ?: return@LaunchedEffect
        scroll.animateScrollTo((y - 200f).toInt().coerceIn(0, scroll.maxValue))
    }

    val primaryColor = MaterialTheme.colorScheme.primary
    Scaffold(
        topBar = {
            if (searchOpen) {
                val searchFocus = remember { FocusRequester() }
                LaunchedEffect(Unit) { runCatching { searchFocus.requestFocus() } }
                TopAppBar(
                    navigationIcon = {
                        IconButton(onClick = { searchOpen = false; query = "" }) { Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Fermer la recherche") }
                    },
                    title = {
                        TextField(
                            value = query, onValueChange = { query = it },
                            placeholder = { Text("Chercher dans la note") },
                            singleLine = true,
                            colors = TextFieldDefaults.colors(
                                focusedContainerColor = Color.Transparent, unfocusedContainerColor = Color.Transparent,
                                focusedIndicatorColor = Color.Transparent, unfocusedIndicatorColor = Color.Transparent,
                            ),
                            keyboardOptions = KeyboardOptions(imeAction = androidx.compose.ui.text.input.ImeAction.Search),
                            keyboardActions = androidx.compose.foundation.text.KeyboardActions(onSearch = { if (matches.isNotEmpty()) matchIdx = (curIdx + 1) % matches.size }),
                            modifier = Modifier.fillMaxWidth().focusRequester(searchFocus),
                        )
                    },
                    actions = {
                        if (query.isNotBlank()) {
                            fr.jeremy.calepin.i18n.RawText(
                                if (matches.isEmpty()) "0" else "${curIdx + 1}/${matches.size}",
                                style = MaterialTheme.typography.labelLarge,
                                color = if (matches.isEmpty()) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                        IconButton(enabled = matches.isNotEmpty(), onClick = { matchIdx = (curIdx - 1 + matches.size) % matches.size }) {
                            Icon(Icons.Filled.KeyboardArrowUp, contentDescription = "Résultat précédent")
                        }
                        IconButton(enabled = matches.isNotEmpty(), onClick = { matchIdx = (curIdx + 1) % matches.size }) {
                            Icon(Icons.Filled.KeyboardArrowDown, contentDescription = "Résultat suivant")
                        }
                    },
                )
            } else
            TopAppBar(
                title = { fr.jeremy.calepin.ui.FitText(if (editing) "Écrire" else "Note") },
                navigationIcon = {
                    IconButton(onClick = { close() }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Retour")
                    }
                },
                actions = {
                    if (editing) {
                        IconButton(onClick = { startDictation() }) {
                            Icon(Icons.Filled.KeyboardVoice, contentDescription = "Dicter du texte")
                        }
                    }
                    if (editing) {
                        IconButton(onClick = { field = Checklist.toggleLines(field) }) {
                            Icon(Icons.Filled.Checklist, contentDescription = "Liste à cocher")
                        }
                    }
                    IconButton(onClick = { searchOpen = true }) {
                        Icon(Icons.Filled.Search, contentDescription = "Chercher dans la note")
                    }
                    IconButton(onClick = { pinned = !pinned }) {
                        Icon(
                            if (pinned) Icons.Filled.PushPin else Icons.Outlined.PushPin,
                            contentDescription = if (pinned) "Désépingler" else "Épingler",
                            tint = if (pinned) MaterialTheme.colorScheme.secondary else MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                    if (BuildConfig.AI) {
                        IconButton(onClick = { aiMenu = true }) { Icon(Icons.Filled.AutoAwesome, contentDescription = "Outils IA") }
                        DropdownMenu(expanded = aiMenu, onDismissRequest = { aiMenu = false }) {
                            fr.jeremy.calepin.ai.AiTool.entries.forEach { t ->
                                DropdownMenuItem(text = { Text(t.label) }, onClick = {
                                    aiMenu = false
                                    when {
                                        !vm.aiReady() -> fr.jeremy.calepin.i18n.I18n.toast(ctx, "Installe d'abord un modèle d'IA (Paramètres → Intelligence artificielle).", Toast.LENGTH_LONG).show()
                                        content.isBlank() && vm.recordingsOf(id).none { it.transcript.isNotBlank() } ->
                                            fr.jeremy.calepin.i18n.I18n.toast(ctx, "La note est vide.", Toast.LENGTH_SHORT).show()
                                        else -> { persist(); aiTool = t }
                                    }
                                })
                            }
                        }
                    }
                    IconButton(onClick = { menuOpen = true }) { Icon(Icons.Filled.MoreVert, contentDescription = "Plus d'actions") }
                    DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                        DropdownMenuItem(
                            text = { Text("Liste à cocher") },
                            leadingIcon = { Icon(Icons.Filled.Checklist, null) },
                            onClick = { menuOpen = false; if (!editing) editing = true; field = Checklist.toggleLines(field.copy(selection = TextRange(field.text.length))) },
                        )
                        DropdownMenuItem(
                            text = { Text("Scanner du texte (photo)") },
                            leadingIcon = { Icon(Icons.Filled.DocumentScanner, null) },
                            onClick = { menuOpen = false; startScan(fromCamera = true) },
                        )
                        DropdownMenuItem(
                            text = { Text("Texte d'une image de la galerie") },
                            leadingIcon = { Icon(Icons.Filled.ImageSearch, null) },
                            onClick = { menuOpen = false; startScan(fromCamera = false) },
                        )
                        DropdownMenuItem(
                            text = { Text("Partager") },
                            leadingIcon = { Icon(Icons.Filled.Share, null) },
                            onClick = { menuOpen = false; Actions.share(ctx, title, InlineMedia.strip(content)) },
                        )
                        // Note sensible : protégée par le code des rubriques (Paramètres → Sécurité)
                        val lockGuarded by fr.jeremy.calepin.SectionLock.guarded.collectAsStateWithLifecycle()
                        val lockPin by fr.jeremy.calepin.SectionLock.hasPin.collectAsStateWithLifecycle()
                        val privates by fr.jeremy.calepin.SectionLock.privateNotes.collectAsStateWithLifecycle()
                        if (lockPin && fr.jeremy.calepin.SectionLock.PRIVATE in lockGuarded) {
                            val isPriv = id != 0L && id in privates
                            DropdownMenuItem(
                                text = { Text(if (isPriv) "Ne plus protéger la note" else "Note sensible (code PIN)") },
                                leadingIcon = { Icon(if (isPriv) Icons.Filled.LockOpen else Icons.Filled.Lock, null) },
                                onClick = {
                                    menuOpen = false
                                    val nid = if (id != 0L) id else ensureNote()
                                    fr.jeremy.calepin.SectionLock.setPrivate(nid, !isPriv)
                                    fr.jeremy.calepin.SectionLock.unlock(fr.jeremy.calepin.SectionLock.PRIVATE)
                                    fr.jeremy.calepin.i18n.I18n.toast(ctx, if (isPriv) "La note n'est plus protégée." else "Note protégée par le code PIN.", android.widget.Toast.LENGTH_SHORT).show()
                                },
                            )
                        }
                        DropdownMenuItem(
                            text = { Text(if (speaking) "Arrêter la lecture" else "Lire à voix haute") },
                            leadingIcon = { Icon(Icons.Filled.RecordVoiceOver, null) },
                            onClick = {
                                menuOpen = false
                                if (speaking) { speaker.stop(); speaking = false }
                                else {
                                    speaking = true
                                    speaker.speak(listOf(title, InlineMedia.strip(content).replace("☑", "fait,").replace("☐", "")).filter { it.isNotBlank() }.joinToString(". ").replace(Regex("[#*_~\\[\\]]"), ""))
                                }
                            },
                        )
                        if (id != 0L) {
                            DropdownMenuItem(
                                text = { Text("Versions précédentes") },
                                leadingIcon = { Icon(Icons.Filled.History, null) },
                                onClick = { menuOpen = false; persist(); showVersions = true },
                            )
                        }
                        DropdownMenuItem(
                            text = { Text("Exporter (PDF, Word, Excel…)") },
                            leadingIcon = { Icon(Icons.Filled.SaveAlt, null) },
                            onClick = { menuOpen = false; persist(); exporting = true },
                        )
                        if (id != 0L) {
                            DropdownMenuItem(
                                text = { Text("Supprimer", color = MaterialTheme.colorScheme.error) },
                                leadingIcon = { Icon(Icons.Filled.Delete, null, tint = MaterialTheme.colorScheme.error) },
                                onClick = { menuOpen = false; confirmDelete = true },
                            )
                        }
                    }
                },
            )
        },
        floatingActionButton = {
            // En modification, « Terminer » est dans la barre au-dessus du clavier
            if (!editing) ExtendedFloatingActionButton(
                onClick = { if (editing) stopEditing() else startEditingHere() },
                icon = { Icon(if (editing) Icons.Filled.Check else Icons.Filled.Edit, contentDescription = null) },
                text = { Text(if (editing) "Terminer" else "Modifier") },
            )
        },
    ) { pad ->
        if (editing) {
            EditPane(
                pad = pad,
                scanning = scanning,
                title = title, onTitle = { title = it },
                tag = tag, onTag = { tag = it },
                folderText = folderLabel(folder), folderEmpty = folder.isEmpty(), onFolder = { pickingFolder = true },
                field = field,
                onField = { nv ->
                    val c = Checklist.afterEdit(field, nv)
                    // Entrée au bout d'une ligne centrée ou à droite : la nouvelle ligne garde l'alignement
                    val fix = if (c.selection.collapsed) fr.jeremy.calepin.text.RichText.afterEdit(field.text, c.text, c.selection.end) else null
                    field = if (fix != null) TextFieldValue(fix.first, TextRange(fix.second)) else c
                },
                onRich = { kind, value ->
                    val f = field
                    val a = f.selection.min
                    val b = f.selection.max
                    val e = when (kind) {
                        "u" -> fr.jeremy.calepin.text.RichText.toggleUnderline(f.text, a, b)
                        "align" -> fr.jeremy.calepin.text.RichText.setAlign(f.text, a, b, value)
                        else -> fr.jeremy.calepin.text.RichText.apply(f.text, a, b, kind, value)
                    }
                    field = TextFieldValue(e.text, if (a == b) TextRange(e.start) else TextRange(e.start, e.end))
                },
                focus = focus,
                onTextLayout = { editLayout = it },
                onChecklist = { field = Checklist.toggleLines(field) },
                onDictate = { startDictation() },
                onScan = { startScan(fromCamera = true) },
                onSelectAll = { field = field.copy(selection = TextRange(0, field.text.length)) },
                onAgenda = { sel -> draftFrom(sel, alarm = false, fallbackTitle = title) },
                onAlarm = { sel -> draftFrom(sel, alarm = true, fallbackTitle = title) },
                onDone = { stopEditing() },
                highlights = matches, current = curIdx,
                onMedia = { mediaMenu = true },
                mediaMenu = {
                    DropdownMenu(expanded = mediaMenu, onDismissRequest = { mediaMenu = false }) {
                        DropdownMenuItem(text = { Text("Photo") }, leadingIcon = { Icon(Icons.Filled.PhotoCamera, null) }, onClick = { mediaMenu = false; editAdder.capture(false) })
                        DropdownMenuItem(text = { Text("Vidéo") }, leadingIcon = { Icon(Icons.Filled.Videocam, null) }, onClick = { mediaMenu = false; editAdder.capture(true) })
                        DropdownMenuItem(text = { Text("Galerie") }, leadingIcon = { Icon(Icons.Filled.PhotoLibrary, null) }, onClick = { mediaMenu = false; editAdder.gallery() })
                        DropdownMenuItem(text = { Text("Croquis") }, leadingIcon = { Icon(Icons.Filled.Draw, null) }, onClick = { mediaMenu = false; editAdder.sketch() })
                    }
                },
                onFormat = { kind ->
                    field = when (kind) {
                        "bold" -> Markdown.wrap(field, "**")
                        "italic" -> Markdown.wrap(field, "*")
                        "strike" -> Markdown.wrap(field, "~~")
                        "title" -> Markdown.linePrefix(field, "# ")
                        "list" -> Markdown.linePrefix(field, "- ")
                        else -> Markdown.wrap(field, "[[", "]]")
                    }
                },
            )
        } else
        Column(
            Modifier
                .fillMaxSize()
                .padding(pad)
                .onSizeChanged { viewportH = it.height }
                .verticalScroll(scroll)
                .padding(horizontal = 16.dp)
                .padding(bottom = 96.dp)
                .onPlaced { colRef[0] = it }
                .drawWithContent {
                    drawContent()
                    // Photo soulevée : elle suit le doigt, et une ligne montre où elle va se poser
                    if (dragFile != null) {
                        val st = dragStart
                        if (st != null) {
                            dropTarget()?.let { (_, y, side) ->
                                val c = primaryColor
                                val w = size.width
                                val (x0, x1) = when (side) {
                                    fr.jeremy.calepin.text.NoteLayout.Side.LEFT -> 0f to w * 0.45f
                                    fr.jeremy.calepin.text.NoteLayout.Side.RIGHT -> w * 0.55f to w
                                    else -> 0f to w
                                }
                                drawLine(c, Offset(x0, y), Offset(x1, y), strokeWidth = 3.dp.toPx())
                                drawCircle(c, 5.dp.toPx(), Offset(x0, y))
                                drawCircle(c, 5.dp.toPx(), Offset(x1, y))
                            }
                            val r = st.translate(dragOffset)
                            val g = ghost
                            if (g != null) drawImage(
                                g,
                                dstOffset = androidx.compose.ui.unit.IntOffset(r.left.toInt(), r.top.toInt()),
                                dstSize = androidx.compose.ui.unit.IntSize(r.width.toInt().coerceAtLeast(1), r.height.toInt().coerceAtLeast(1)),
                                alpha = 0.85f,
                            )
                            else drawRoundRect(primaryColor.copy(alpha = 0.3f), r.topLeft, r.size, androidx.compose.ui.geometry.CornerRadius(10.dp.toPx()))
                        }
                    }
                },
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            if (scanning) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    androidx.compose.material3.CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp)
                    Text("  Lecture du texte de l'image…", style = MaterialTheme.typography.labelLarge)
                }
            }
            // Dossier de la note : touché = changer de dossier
            Row(
                Modifier
                    .padding(top = 4.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .clickable { pickingFolder = true }
                    .padding(horizontal = 4.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Icon(
                    if (folder.isEmpty()) Icons.Filled.FolderOff else Icons.Filled.Folder,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(18.dp),
                )
                Spacer(Modifier.width(6.dp))
                Text(
                    folderLabel(folder),
                    style = MaterialTheme.typography.labelLarge,
                    color = if (folder.isEmpty()) MaterialTheme.colorScheme.onSurfaceVariant else MaterialTheme.colorScheme.primary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            }
            run {
                Text(
                    title.ifBlank { "Sans titre" },
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.SemiBold,
                )
                val tagList = tag.split(',').map { it.trim() }.filter { it.isNotEmpty() }
                if (tagList.isNotEmpty()) {
                    Text(
                        tagList.joinToString(" · "),
                        style = MaterialTheme.typography.labelLarge,
                        color = MaterialTheme.colorScheme.secondary,
                    )
                }
                HorizontalDivider()
                // Le texte, coupé là où des photos ou vidéos sont placées : elles s'affichent à leur place,
                // en miniatures comme la galerie (toucher = plein écran)
                val full = linkified(
                    content, entities, { selected = it },
                    onNoteLink = { linked ->
                        persist()
                        val target = vm.allNotes().firstOrNull { it.title.trim().equals(linked.trim(), ignoreCase = true) }
                        onOpenNote(target?.id, linked.trim())
                    },
                    highlights = matches, current = curIdx,
                )
                val byFile = attachments.associateBy { it.fileName }
                val segments = remember(content) { InlineMedia.segments(content) }
                androidx.compose.runtime.SideEffect {
                    readSegs.keys.retainAll { k -> segments.any { sg -> sg.files == null && k >= sg.start && k <= sg.end } }
                }
                val bodyStyle = MaterialTheme.typography.bodyLarge
                // Morceau de texte : toucher ouvre la modification à cet endroit précis (les liens gardent leur action)
                val segText: @Composable (Int, Int, Modifier) -> Unit = { segStart, segEnd, mod ->
                    Text(
                        full.subSequence(segStart, segEnd),
                        style = bodyStyle,
                        onTextLayout = { l ->
                            readSegs[segStart] = l to (readSegs[segStart]?.second ?: 0f)
                            readLayout = l
                        },
                        modifier = mod
                            .then(if (segments.size == 1) Modifier.heightIn(min = 48.dp) else Modifier)
                            .onGloballyPositioned { c ->
                                val col = colRef[0]
                                val y = if (col != null && col.isAttached && c.isAttached) col.localPositionOf(c, Offset.Zero).y else c.positionInParent().y
                                readSegs[segStart]?.let { (l, top) -> if (top != y) readSegs[segStart] = l to y }
                                readTop = y
                            }
                            .pointerInput(content, entities, segStart) {
                                detectTapGestures { pos ->
                                    val l = readSegs[segStart]?.first
                                    if (l == null || content.isEmpty()) {
                                        startEditing(content.length, 0f)
                                        return@detectTapGestures
                                    }
                                    val off = (segStart + l.getOffsetForPosition(pos)).coerceIn(0, content.length)
                                    // Toucher une case la coche ou la décoche
                                    val ls = Checklist.lineStart(content, off)
                                    if (Checklist.isItem(content.substring(ls)) && off <= ls + 2) {
                                        field = TextFieldValue(Checklist.toggleAt(content, ls))
                                        persist()
                                        return@detectTapGestures
                                    }
                                    if (entities.any { off >= it.start && off < it.end }) return@detectTapGestures
                                    startEditing(off, (readTopOf(off) ?: 0f) - scroll.value)
                                }
                            },
                    )
                }
                segments.forEach { seg ->
                    val fl = seg.float
                    when {
                        seg.files != null -> {
                            val items = seg.files.mapNotNull { byFile[it] }
                            if (items.isNotEmpty()) {
                                Row(
                                    Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                ) {
                                    items.forEach { a ->
                                        NotePhoto(
                                            vm.fileOf(a), a.isVideo,
                                            Modifier.size(104.dp).then(photoTouch(a)),
                                            maxSide = 320, alpha = if (dragFile == a.fileName) 0.35f else 1f,
                                        )
                                    }
                                }
                            }
                        }
                        fl != null -> {
                            val a = byFile[fl.file]
                            if (a == null) segText(seg.start, seg.end, Modifier.fillMaxWidth())
                            else FloatLayout(
                                vm.fileOf(a), a.isVideo, fl,
                                full.subSequence(seg.start, seg.end), bodyStyle,
                                photoModifier = photoTouch(a),
                                photoAlpha = if (dragFile == a.fileName) 0.35f else 1f,
                            ) { from, to, mod -> segText(seg.start + from, seg.start + to, mod) }
                        }
                        else -> segText(seg.start, seg.end, Modifier.fillMaxWidth())
                    }
                }
            }

            if (entities.isNotEmpty()) {
                Spacer(Modifier.size(4.dp))
                Text(
                    "Reconnu dans la note · touchez pour agir",
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    entities.forEach { e ->
                        AssistChip(
                            onClick = { selected = e },
                            label = {
                                Text(
                                    when {
                                        e.type == EntityType.DATE -> e.value
                                        e.country != null -> e.country.substringBefore(' ') + "  " + e.text
                                        else -> e.text
                                    },
                                    maxLines = 1, overflow = TextOverflow.Ellipsis,
                                    modifier = Modifier.widthIn(max = 260.dp),
                                )
                            },
                            leadingIcon = {
                                Icon(e.type.icon(), contentDescription = e.type.label, modifier = Modifier.size(AssistChipDefaults.IconSize))
                            },
                        )
                    }
                }
            }

            // Notes qui pointent vers celle-ci avec [[Titre]]
            val backlinks = if (title.isBlank()) emptyList() else vm.allNotes().filter { it.id != id && it.content.contains("[[" + title.trim() + "]]", ignoreCase = true) }
            if (backlinks.isNotEmpty()) {
                Text("Notes qui renvoient ici", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    backlinks.take(12).forEach { n ->
                        AssistChip(
                            onClick = { persist(); onOpenNote(n.id, n.title) },
                            label = { fr.jeremy.calepin.i18n.RawText(n.title.ifBlank { "…" }, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                            leadingIcon = { Icon(Icons.Filled.Link, null, Modifier.size(AssistChipDefaults.IconSize)) },
                        )
                    }
                }
            }

            if (noteEvents.isNotEmpty()) {
                Text(
                    "Dans l'agenda",
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    noteEvents.forEach { ev ->
                        AssistChip(
                            onClick = { eventDraft = ev },
                            label = {
                                Text(
                                    SimpleDateFormat(fr.jeremy.calepin.i18n.I18n.pattern(if (ev.allDay) "d MMM" else "d MMM HH:mm"), fr.jeremy.calepin.i18n.I18n.locale).format(Date(ev.start)) +
                                        (if (ev.isPeriod) " → " + SimpleDateFormat(fr.jeremy.calepin.i18n.I18n.pattern("d MMM"), fr.jeremy.calepin.i18n.I18n.locale).format(Date(ev.end)) else "") +
                                        " · " + ev.title,
                                    maxLines = 1, overflow = TextOverflow.Ellipsis,
                                    modifier = Modifier.widthIn(max = 260.dp),
                                )
                            },
                            leadingIcon = {
                                Icon(
                                    when {
                                        ev.remindMinutes < 0 -> Icons.Filled.Today
                                        ev.alarm -> Icons.Filled.Alarm
                                        else -> Icons.Filled.NotificationsActive
                                    },
                                    null, Modifier.size(AssistChipDefaults.IconSize),
                                )
                            },
                        )
                    }
                }
            }

            Spacer(Modifier.size(4.dp))
            RecordingsSection(
                vm = vm, noteId = id, noteTitle = title,
                ensureNote = { ensureNote() },
                onInsertText = { insertText(it) },
            )
            MediaSection(
                vm = vm, noteId = id, ensureNote = { ensureNote() },
                placed = placedFiles, version = mediaVersion,
                onAdded = { placeMedia(it) },
                onPlace = { placeMedia(listOf(it)) },
                onDeleted = { mediaDeleted(it) },
            )

            if (existing != null) {
                val f = SimpleDateFormat(fr.jeremy.calepin.i18n.I18n.pattern("d MMM yyyy 'à' HH:mm"), fr.jeremy.calepin.i18n.I18n.locale)
                Text(
                    "Créée le ${f.format(Date(existing.createdAt))} · modifiée le ${f.format(Date(existing.updatedAt))}",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
    }

    viewingMedia?.let { a ->
        MediaViewer(vm = vm, a = a, onClose = { viewingMedia = null }, onDeleted = { viewingMedia = null; mediaDeleted(a) })
    }
    deletingMedia?.let { a ->
        DeleteMediaDialog(vm, a, onDismiss = { deletingMedia = null }, onDeleted = { deletingMedia = null; mediaDeleted(a) })
    }
    layoutFor?.let { a ->
        val spec = fr.jeremy.calepin.text.NoteLayout.specFor(content, a.fileName)
        if (spec != null) PhotoLayoutDialog(
            spec = spec,
            onSide = { side ->
                field = TextFieldValue(fr.jeremy.calepin.text.NoteLayout.setSpec(content, a.fileName, side, spec.width), TextRange(0))
                persist()
            },
            onWidth = { w ->
                field = TextFieldValue(fr.jeremy.calepin.text.NoteLayout.setWidth(content, a.fileName, w), TextRange(0))
                persist()
            },
            onUnplace = { layoutFor = null; mediaUnplaced(a) },
            onDelete = { layoutFor = null; deletingMedia = a },
            onDismiss = { layoutFor = null },
        )
    }

    if (showVersions) {
        val versions = remember(id) { vm.versionsOf(id) }
        AlertDialog(
            onDismissRequest = { showVersions = false },
            title = { Text("Versions précédentes") },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (versions.isEmpty()) Text("Pas encore d'ancienne version : Calepin en garde une à chaque modification (au plus une toutes les 10 minutes).")
                    val f = SimpleDateFormat(fr.jeremy.calepin.i18n.I18n.pattern("EEE d MMM 'à' HH'h'mm"), fr.jeremy.calepin.i18n.I18n.locale)
                    versions.forEach { (t, c, at) ->
                        Surface(color = MaterialTheme.colorScheme.surfaceContainerLow, shape = MaterialTheme.shapes.medium, modifier = Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(10.dp)) {
                                fr.jeremy.calepin.i18n.RawText(f.format(Date(at)), style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary)
                                fr.jeremy.calepin.i18n.RawText(InlineMedia.strip(c).take(160), style = MaterialTheme.typography.bodySmall, maxLines = 4, overflow = TextOverflow.Ellipsis)
                                TextButton(onClick = {
                                    // La version actuelle est d'abord gardée, pour pouvoir y revenir
                                    persist()
                                    title = t
                                    field = TextFieldValue(c, TextRange(0))
                                    persist()
                                    showVersions = false
                                }) { Text("Revenir à cette version") }
                            }
                        }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { showVersions = false }) { Text("Fermer") } },
        )
    }

    selected?.let { e ->
        EntitySheet(
            entity = e,
            all = entities,
            noteTitle = title,
            noteContent = content,
            onDismiss = { selected = null },
            onCalepinEvent = { ent, alarm ->
                selected = null
                val t = ent.timeMillis
                if (t != null) {
                    eventDraft = Event(
                        title = title.ifBlank { "Rendez-vous" }, start = t, allDay = !ent.hasTime,
                        end = ent.endMillis ?: 0L,
                        remindMinutes = if (!ent.hasTime) -540 else if (alarm) 0 else 15, alarm = alarm,
                    )
                }
            },
        )
    }

    eventDraft?.let { ev ->
        EventDialog(
            initial = ev,
            defaultRingtone = defaultRingtone,
            onDismiss = { eventDraft = null },
            onSave = { saved ->
                val nid = if (saved.noteId != 0L) saved.noteId else ensureNote()
                vm.saveEvent(saved.copy(noteId = nid))
                eventDraft = null
                fr.jeremy.calepin.i18n.I18n.toast(ctx, "Ajouté à l'agenda Calepin", Toast.LENGTH_SHORT).show()
            },
            onDelete = if (ev.id != 0L) ({ vm.deleteEvent(ev); eventDraft = null }) else null,
        )
    }

    if (pickingFolder) {
        FolderPickerDialog(
            vm = vm,
            title = "Ranger la note dans…",
            folders = allFolders,
            current = folder,
            onDismiss = { pickingFolder = false },
        ) { target ->
            folder = target
            pickingFolder = false
            persist()
        }
    }

    aiTool?.let { t ->
        val source = buildString {
            append(fr.jeremy.calepin.text.RichText.strip(content))
            vm.recordingsOf(id).map { it.transcript }.filter { it.isNotBlank() }.forEach { append("\n\n").append(it) }
        }.trim()
        AiToolDialog(
            vm = vm, tool = t, text = source,
            use = AiToolResult(
                onReplace = { out -> field = TextFieldValue(out, TextRange(out.length)); persist() },
                onAppend = { out ->
                    val base = field.text.trimEnd()
                    val nt = if (base.isEmpty()) out else base + "\n\n" + out
                    field = TextFieldValue(nt, TextRange(nt.length)); persist()
                },
                onNewNote = { out ->
                    val now = System.currentTimeMillis()
                    vm.saveNow(Note(title = t.label + " – " + title.ifBlank { "Sans titre" }, content = out, folder = folder, createdAt = now, updatedAt = now))
                    fr.jeremy.calepin.i18n.I18n.toast(ctx, "Nouvelle note créée", Toast.LENGTH_SHORT).show()
                },
            ),
            onDismiss = { aiTool = null },
        )
    }

    if (exporting) {
        val n = Note(id = id, title = title, content = content, tag = tag, pinned = pinned, createdAt = createdAt, folder = folder)
        ExportSheet(vm, listOf(n), onDismiss = { exporting = false })
    }

    if (confirmDelete) {
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            title = { Text("Supprimer cette note ?") },
            text = { Text("La note « ${title.ifBlank { "Sans titre" }} » sera définitivement effacée.") },
            confirmButton = {
                TextButton(onClick = {
                    confirmDelete = false
                    vm.delete(id)
                    onClose()
                }) { Text("Supprimer", color = MaterialTheme.colorScheme.error) }
            },
            dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text("Annuler") } },
        )
    }
}

@Composable
private fun linkified(
    text: String,
    entities: List<Entity>,
    onClick: (Entity) -> Unit,
    onNoteLink: (String) -> Unit = {},
    /** Résultats de la recherche dans la note, et celui en cours. */
    highlights: List<IntRange> = emptyList(),
    current: Int = -1,
    /** Fichiers des photos placées dans le texte (affichées à la place de leur repère). */
    inlineFiles: Set<String> = emptySet(),
): AnnotatedString {
    val linkStyle = TextLinkStyles(
        style = SpanStyle(
            color = MaterialTheme.colorScheme.primary,
            fontWeight = FontWeight.Medium,
            textDecoration = TextDecoration.Underline,
        ),
    )
    return buildAnnotatedString {
        var pos = 0
        for (e in entities) {
            if (e.start < pos || e.end > text.length) continue
            append(text.substring(pos, e.start))
            withLink(
                LinkAnnotation.Clickable(
                    tag = "e${e.start}",
                    styles = linkStyle,
                    linkInteractionListener = LinkInteractionListener { onClick(e) },
                ),
            ) {
                append(text.substring(e.start, e.end))
            }
            pos = e.end
        }
        append(text.substring(pos))
        // Listes à cocher : cases colorées, éléments faits barrés et grisés
        val box = SpanStyle(color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
        val doneStyle = SpanStyle(textDecoration = TextDecoration.LineThrough, color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f))
        Checklist.boxPositions(text).forEach { p -> if (p < text.length) addStyle(box, p, p + 1) }
        Checklist.doneRanges(text).forEach { r -> if (r.last < text.length) addStyle(doneStyle, r.first, r.last + 1) }
        // Mise en forme simple : # titres, **gras**, *italique*, ~~barré~~, listes « - », liens [[Autre note]].
        // Les signes restent (estompés) pour que toucher le texte place le curseur au bon endroit.
        val dim = SpanStyle(color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.35f))
        val primary = MaterialTheme.colorScheme.primary
        // En lecture, les signes (** _ ~~ #) disparaissent : seul le texte mis en forme se voit
        Markdown.styleInto(this, text, Markdown.HIDDEN, primary)
        // Couleurs, surlignage, souligné et alignement choisis (repères cachés)
        RichStyle.spansInto(this, text, Markdown.HIDDEN)
        RichStyle.alignInto(this, text)
        Markdown.links.findAll(text).forEach { m ->
            val target = m.groupValues[1]
            addStyle(dim, m.range.first, m.range.first + 2)
            addStyle(dim, m.range.last - 1, m.range.last + 1)
            addLink(
                LinkAnnotation.Clickable(
                    tag = "n${m.range.first}",
                    styles = TextLinkStyles(style = SpanStyle(color = MaterialTheme.colorScheme.tertiary, fontWeight = FontWeight.SemiBold, textDecoration = TextDecoration.Underline)),
                    linkInteractionListener = LinkInteractionListener { onNoteLink(target) },
                ),
                m.range.first + 2, m.range.last - 1,
            )
        }
        // Photos et vidéos placées dans le texte : le repère est remplacé par l'image (même longueur de texte)
        InlineMedia.marker.findAll(text).forEach { m ->
            val file = m.groupValues[2]
            if (file in inlineFiles) addStringAnnotation(INLINE_CONTENT_TAG, "m:$file", m.range.first, m.range.last + 1)
            else addStyle(dim, m.range.first, m.range.last + 1)
        }
        // Recherche dans la note
        val hl = SpanStyle(background = MaterialTheme.colorScheme.tertiaryContainer, color = MaterialTheme.colorScheme.onTertiaryContainer)
        val hlCur = SpanStyle(background = MaterialTheme.colorScheme.tertiary, color = MaterialTheme.colorScheme.onTertiary)
        highlights.forEachIndexed { i, r -> if (r.last < text.length) addStyle(if (i == current) hlCur else hl, r.first, r.last + 1) }
    }
}

/** Repère utilisé par Compose pour les contenus insérés dans un texte (comme appendInlineContent). */
private const val INLINE_CONTENT_TAG = "androidx.compose.foundation.text.inlineContent"

/** Surlignage des résultats de recherche et repères de photos estompés, dans la zone d'écriture. */
private class EditHighlights(
    private val highlights: List<IntRange>,
    private val current: Int,
    private val hl: SpanStyle,
    private val hlCur: SpanStyle,
    private val markerStyle: SpanStyle,
    private val dimStyle: SpanStyle = SpanStyle(color = androidx.compose.ui.graphics.Color.Gray.copy(alpha = 0.5f)),
    private val primary: androidx.compose.ui.graphics.Color = androidx.compose.ui.graphics.Color.Unspecified,
) : androidx.compose.ui.text.input.VisualTransformation {
    override fun filter(text: AnnotatedString): androidx.compose.ui.text.input.TransformedText {
        val b = AnnotatedString.Builder(text)
        // En écriture : gras, italique, barré et titres visibles tout de suite, signes estompés
        Markdown.styleInto(b, text.text, dimStyle, primary)
        // Couleurs, surlignage et souligné visibles tout de suite ; leurs repères sont cachés
        RichStyle.spansInto(b, text.text, null)
        InlineMedia.marker.findAll(text.text).forEach { b.addStyle(markerStyle, it.range.first, it.range.last + 1) }
        highlights.forEachIndexed { i, r -> if (r.last < text.length) b.addStyle(if (i == current) hlCur else hl, r.first, r.last + 1) }
        val styled = b.toAnnotatedString()
        val map = fr.jeremy.calepin.text.RichText.Mapping(text.text)
        if (map.isIdentity) {
            return androidx.compose.ui.text.input.TransformedText(styled, androidx.compose.ui.text.input.OffsetMapping.Identity)
        }
        val out = AnnotatedString.Builder()
        var p = 0
        map.hiddenRanges().forEach { r -> if (r.first > p) out.append(styled.subSequence(p, r.first)); p = r.last + 1 }
        if (p < styled.length) out.append(styled.subSequence(p, styled.length))
        // Alignement : appliqué au texte affiché, ligne par ligne
        RichStyle.alignInto(out, text.text) { map.toVisible(it) }
        return androidx.compose.ui.text.input.TransformedText(
            out.toAnnotatedString(),
            object : androidx.compose.ui.text.input.OffsetMapping {
                override fun originalToTransformed(offset: Int) = map.toVisible(offset)
                override fun transformedToOriginal(offset: Int) = map.toOriginal(offset)
            },
        )
    }

    override fun equals(other: Any?) = other is EditHighlights && other.highlights == highlights && other.current == current && other.hl == hl
    override fun hashCode() = highlights.hashCode() * 31 + current
}

/** Repères de mise en forme reconnus dans le texte des notes. */
object Markdown {
    val headings = Regex("(?m)^(#{1,3}) (.+)$")
    val bold = Regex("\\*\\*(?!\\s)(.+?)(?<!\\s)\\*\\*")
    val italic = Regex("(?<![*\\w])\\*(?![*\\s])(.+?)(?<![*\\s])\\*(?![*\\w])")
    val strike = Regex("~~(?!\\s)(.+?)(?<!\\s)~~")
    val bullets = Regex("(?m)^\\s*[-•] ")
    val links = Regex("\\[\\[([^\\[\\]\\n]{1,80})\\]\\]")

    /** Signes cachés en lecture (presque invisibles, mais ils gardent leur place dans le texte). */
    val HIDDEN = SpanStyle(color = androidx.compose.ui.graphics.Color.Transparent, fontSize = 0.01.em)

    /** Applique la mise en forme (titres, gras, italique, barré, puces) ; [marker] : style des signes. */
    fun styleInto(b: AnnotatedString.Builder, text: String, marker: SpanStyle, primary: androidx.compose.ui.graphics.Color) {
        headings.findAll(text).forEach { m ->
            val level = m.groupValues[1].length
            b.addStyle(marker, m.range.first, m.range.first + level + 1)
            b.addStyle(SpanStyle(fontWeight = FontWeight.Bold, color = primary, fontSize = when (level) { 1 -> 1.45.em; 2 -> 1.25.em; else -> 1.1.em }), m.range.first + level + 1, m.range.last + 1)
        }
        fun wrapped(rx: Regex, n: Int, style: SpanStyle) = rx.findAll(text).forEach { m ->
            b.addStyle(marker, m.range.first, m.range.first + n)
            b.addStyle(marker, m.range.last + 1 - n, m.range.last + 1)
            b.addStyle(style, m.range.first + n, m.range.last + 1 - n)
        }
        wrapped(bold, 2, SpanStyle(fontWeight = FontWeight.Bold))
        wrapped(italic, 1, SpanStyle(fontStyle = androidx.compose.ui.text.font.FontStyle.Italic))
        wrapped(strike, 2, SpanStyle(textDecoration = TextDecoration.LineThrough))
        bullets.findAll(text).forEach { m -> b.addStyle(SpanStyle(color = primary, fontWeight = FontWeight.Bold), m.range.last - 1, m.range.last) }
    }

    /** Entoure la sélection de [mark] (ou l'enlève si elle l'est déjà) ; sans sélection, insère les repères autour du curseur. */
    fun wrap(f: TextFieldValue, mark: String, close: String = mark): TextFieldValue {
        var a = f.selection.min.coerceIn(0, f.text.length)
        var b = f.selection.max.coerceIn(0, f.text.length)
        val t = f.text
        // Les espaces au bord de la sélection restent dehors (« **mot** », pas « **mot ** », qui ne serait pas reconnu)
        while (a < b && t[a].isWhitespace()) a++
        while (b > a && t[b - 1].isWhitespace()) b--
        if (a >= mark.length && b + close.length <= t.length && t.substring(a - mark.length, a) == mark && t.substring(b, b + close.length) == close) {
            val nt = t.substring(0, a - mark.length) + t.substring(a, b) + t.substring(b + close.length)
            return TextFieldValue(nt, TextRange(a - mark.length, b - mark.length))
        }
        val nt = t.substring(0, a) + mark + t.substring(a, b) + close + t.substring(b)
        return TextFieldValue(nt, if (a == b) TextRange(a + mark.length) else TextRange(a + mark.length, b + mark.length))
    }

    /** Ajoute (ou retire) [prefix] au début de la ligne du curseur. */
    fun linePrefix(f: TextFieldValue, prefix: String): TextFieldValue {
        val t = f.text
        val pos = f.selection.start.coerceIn(0, t.length)
        val ls = t.lastIndexOf('\n', pos - 1).let { if (it < 0) 0 else it + 1 }
        return if (t.startsWith(prefix, ls)) {
            TextFieldValue(t.removeRange(ls, ls + prefix.length), TextRange((pos - prefix.length).coerceAtLeast(ls)))
        } else {
            TextFieldValue(t.substring(0, ls) + prefix + t.substring(ls), TextRange(pos + prefix.length))
        }
    }
}

private class EntityAction(val label: String, val icon: ImageVector, val run: (Context) -> Unit)

private fun actionsFor(
    e: Entity,
    all: List<Entity>,
    title: String,
    content: String,
    onCalepinEvent: (Entity, Boolean) -> Unit,
): List<EntityAction> {
    val firstOf = { t: EntityType -> all.firstOrNull { it.type == t }?.value }
    val contactName = title.ifBlank { "" }
    return when (e.type) {
        EntityType.PHONE -> listOf(
            EntityAction("Appeler", Icons.Filled.Phone) { Actions.dial(it, e.value) },
            EntityAction("Envoyer un SMS", Icons.Filled.Sms) { Actions.sms(it, e.value) },
            EntityAction("Créer un contact (avec les infos de la note)", Icons.Filled.PersonAdd) {
                Actions.addContact(it, contactName, e.value, firstOf(EntityType.EMAIL), firstOf(EntityType.ADDRESS), content)
            },
            EntityAction("Copier le numéro", Icons.Filled.ContentCopy) { Actions.copy(it, e.text) },
        )
        EntityType.EMAIL -> listOf(
            EntityAction("Écrire un e-mail", Icons.Filled.Email) { Actions.email(it, e.value, title) },
            EntityAction("Créer un contact (avec les infos de la note)", Icons.Filled.PersonAdd) {
                Actions.addContact(it, contactName, firstOf(EntityType.PHONE), e.value, firstOf(EntityType.ADDRESS), content)
            },
            EntityAction("Copier l'adresse e-mail", Icons.Filled.ContentCopy) { Actions.copy(it, e.value) },
        )
        EntityType.ADDRESS -> listOf(
            EntityAction("Voir sur la carte", Icons.Filled.Map) { Actions.showOnMap(it, e.value) },
            EntityAction("Itinéraire Google Maps", Icons.Filled.Directions) { Actions.directions(it, e.value) },
            EntityAction("Itinéraire Waze", Icons.Filled.Navigation) { Actions.waze(it, e.value) },
            EntityAction("Ajouter à un contact", Icons.Filled.PersonAdd) {
                Actions.addContact(it, contactName, firstOf(EntityType.PHONE), firstOf(EntityType.EMAIL), e.value, content)
            },
            EntityAction("Copier l'adresse", Icons.Filled.ContentCopy) { Actions.copy(it, e.value) },
        )
        EntityType.DATE -> buildList {
            val t = e.timeMillis ?: return@buildList
            add(EntityAction("Ajouter à l'agenda Calepin (avec rappel)", Icons.Filled.EventAvailable) { onCalepinEvent(e, false) })
            add(EntityAction("Programmer une alarme qui sonne", Icons.Filled.Alarm) { onCalepinEvent(e, true) })
            add(EntityAction("Ajouter à l'agenda du téléphone", Icons.Filled.Today) {
                Actions.addEvent(it, title, content, t, e.hasTime, firstOf(EntityType.ADDRESS), e.endMillis)
            })
            add(EntityAction("Ouvrir l'agenda à cette date", Icons.Filled.CalendarMonth) { Actions.openCalendarAt(it, t) })
            if (Actions.canSetAlarm(t, e.hasTime)) {
                add(EntityAction("Régler le réveil du téléphone", Icons.Filled.AccessAlarm) { Actions.setAlarm(it, t, title) })
            }
            add(EntityAction("Copier la date", Icons.Filled.ContentCopy) { Actions.copy(it, e.value) })
        }
        EntityType.URL -> listOf(
            EntityAction("Ouvrir le lien", Icons.Filled.Language) { Actions.openUrl(it, e.value) },
            EntityAction("Copier le lien", Icons.Filled.ContentCopy) { Actions.copy(it, e.value) },
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun EntitySheet(
    entity: Entity,
    all: List<Entity>,
    noteTitle: String,
    noteContent: String,
    onDismiss: () -> Unit,
    onCalepinEvent: (Entity, Boolean) -> Unit,
) {
    val ctx = LocalContext.current
    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(Modifier.padding(bottom = 24.dp)) {
            ListItem(
                overlineContent = { Text(entity.type.label) },
                headlineContent = {
                    Text(
                        if (entity.type == EntityType.DATE) entity.value else entity.text,
                        style = MaterialTheme.typography.titleMedium,
                    )
                },
                supportingContent = when {
                    entity.type == EntityType.DATE -> {
                        { Text("Écrit « ${entity.text} »") }
                    }
                    entity.country != null -> {
                        { Text(entity.country) }
                    }
                    else -> null
                },
                leadingContent = { Icon(entity.type.icon(), contentDescription = null, tint = MaterialTheme.colorScheme.primary) },
            )
            HorizontalDivider()
            actionsFor(entity, all, noteTitle, noteContent, onCalepinEvent).forEach { a ->
                ListItem(
                    headlineContent = { Text(a.label) },
                    leadingContent = { Icon(a.icon, contentDescription = null) },
                    modifier = Modifier.clickable {
                        a.run(ctx)
                        onDismiss()
                    },
                )
            }
        }
    }
}

/**
 * Modification d'une note, façon messagerie : l'écran se réduit au-dessus du clavier, le texte défile
 * à l'intérieur de sa zone et garde le curseur (ou la sélection) visible. Une barre fixe juste au-dessus
 * du clavier donne les actions ; quand du texte est sélectionné, elle propose d'en faire un rendez-vous
 * ou une alarme, sans rien déplacer à l'écran.
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun EditPane(
    pad: androidx.compose.foundation.layout.PaddingValues,
    scanning: Boolean,
    title: String, onTitle: (String) -> Unit,
    tag: String, onTag: (String) -> Unit,
    folderText: String, folderEmpty: Boolean, onFolder: () -> Unit,
    field: TextFieldValue, onField: (TextFieldValue) -> Unit,
    focus: FocusRequester,
    onTextLayout: (TextLayoutResult) -> Unit,
    onChecklist: () -> Unit,
    onDictate: () -> Unit,
    onScan: () -> Unit,
    onSelectAll: () -> Unit,
    onAgenda: (String) -> Unit,
    onAlarm: (String) -> Unit,
    onDone: () -> Unit,
    onFormat: (String) -> Unit = {},
    highlights: List<IntRange> = emptyList(),
    current: Int = -1,
    onMedia: () -> Unit = {},
    mediaMenu: @Composable () -> Unit = {},
    /** Mise en forme enrichie : « u » (souligné), « c » (couleur), « bg » (surlignage), « align » ; valeur null = retirer. */
    onRich: (String, String?) -> Unit = { _, _ -> },
) {
    val cs = MaterialTheme.colorScheme
    var bodyFocused by remember { mutableStateOf(false) }
    // Positions dans le texte affiché (les repères de couleur et d'alignement sont cachés)
    val rmap = remember(field.text) { fr.jeremy.calepin.text.RichText.Mapping(field.text) }
    var palette by remember { mutableStateOf<String?>(null) }
    val keyboardOpen = androidx.compose.foundation.layout.WindowInsets.ime.getBottom(androidx.compose.ui.platform.LocalDensity.current) > 0
    // Clavier ouvert sur le texte : on garde le maximum de place pour le texte
    val compact = bodyFocused && keyboardOpen
    val bare = TextFieldDefaults.colors(
        focusedContainerColor = Color.Transparent,
        unfocusedContainerColor = Color.Transparent,
        focusedIndicatorColor = Color.Transparent,
        unfocusedIndicatorColor = Color.Transparent,
    )
    Column(
        Modifier
            .fillMaxSize()
            .padding(pad)
            .consumeWindowInsets(pad)
            .imePadding(),
    ) {
        if (scanning) {
            Row(Modifier.padding(horizontal = 16.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                androidx.compose.material3.CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp)
                Text("  Lecture du texte de l'image…", style = MaterialTheme.typography.labelLarge)
            }
        }
        if (!compact) {
            Row(
                Modifier
                    .padding(start = 16.dp, end = 16.dp, top = 4.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .clickable(onClick = onFolder)
                    .padding(horizontal = 4.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Icon(if (folderEmpty) Icons.Filled.FolderOff else Icons.Filled.Folder, null, tint = cs.primary, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(6.dp))
                Text(folderText, style = MaterialTheme.typography.labelLarge, color = if (folderEmpty) cs.onSurfaceVariant else cs.primary, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
        }
        TextField(
            value = title, onValueChange = onTitle,
            placeholder = { Text("Titre", style = if (compact) MaterialTheme.typography.titleMedium else MaterialTheme.typography.headlineSmall) },
            textStyle = if (compact) MaterialTheme.typography.titleMedium else MaterialTheme.typography.headlineSmall,
            colors = bare, singleLine = true,
            keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Sentences),
            modifier = Modifier.fillMaxWidth(),
        )
        if (!compact) {
            TextField(
                value = tag, onValueChange = onTag,
                placeholder = { Text("Étiquettes, séparées par des virgules") },
                textStyle = MaterialTheme.typography.labelLarge.copy(color = cs.secondary),
                colors = bare, singleLine = true,
                modifier = Modifier.fillMaxWidth(),
            )
        }
        HorizontalDivider(Modifier.padding(horizontal = 16.dp))
        val bodyStyle = MaterialTheme.typography.bodyLarge.copy(color = cs.onSurface)
        // Zone de texte qui occupe toute la place restante. Elle défile toute seule pour garder le curseur
        // (ou l'extrémité de la sélection) visible : quand le clavier s'ouvre, le texte remonte au lieu d'être caché.
        val density = androidx.compose.ui.platform.LocalDensity.current
        val bodyScroll = rememberScrollState()
        var viewport by remember { mutableIntStateOf(0) }
        var layout by remember { mutableStateOf<TextLayoutResult?>(null) }
        val padTop = with(density) { 10.dp.toPx() }
        val margin = with(density) { 28.dp.toPx() }
        LaunchedEffect(field.selection, field.text, viewport, layout, bodyFocused) {
            val l = layout ?: return@LaunchedEffect
            if (viewport <= 0 || !bodyFocused) return@LaunchedEffect
            val off = rmap.toVisible(field.selection.end).coerceIn(0, l.layoutInput.text.length)
            val r = l.getCursorRect(off)
            val top = r.top + padTop
            val bottom = r.bottom + padTop
            val cur = bodyScroll.value
            val target = when {
                bottom + margin > cur + viewport -> bottom + margin - viewport
                top - margin < cur -> top - margin
                else -> return@LaunchedEffect
            }
            withFrameNanos { } // la hauteur du texte vient peut-être de changer
            bodyScroll.scrollTo(target.toInt().coerceIn(0, bodyScroll.maxValue))
        }
        // Recherche : amener le résultat en cours à l'écran
        val shown = highlights.getOrNull(current)
        LaunchedEffect(shown, layout, viewport) {
            val m = shown ?: return@LaunchedEffect
            val l = layout ?: return@LaunchedEffect
            if (viewport <= 0) return@LaunchedEffect
            val r = l.getCursorRect(rmap.toVisible(m.first).coerceIn(0, l.layoutInput.text.length))
            bodyScroll.animateScrollTo((r.top + padTop - viewport / 3f).toInt().coerceIn(0, bodyScroll.maxValue))
        }
        Box(
            Modifier
                .weight(1f)
                .fillMaxWidth()
                .onSizeChanged { viewport = it.height },
        ) {
            Column(Modifier.fillMaxSize().verticalScroll(bodyScroll)) {
                BasicTextField(
                    value = field,
                    onValueChange = onField,
                    textStyle = bodyStyle,
                    cursorBrush = SolidColor(cs.primary),
                    keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Sentences),
                    visualTransformation = remember(highlights, current, cs) {
                        EditHighlights(
                            highlights, current,
                            SpanStyle(background = cs.tertiaryContainer, color = cs.onTertiaryContainer),
                            SpanStyle(background = cs.tertiary, color = cs.onTertiary),
                            SpanStyle(color = cs.primary, background = cs.primaryContainer.copy(alpha = 0.5f), fontSize = 0.85.em),
                            SpanStyle(color = cs.onSurfaceVariant.copy(alpha = 0.45f)),
                            cs.primary,
                        )
                    },
                    onTextLayout = { layout = it; onTextLayout(it) },
                    modifier = Modifier
                        .fillMaxWidth()
                        // Toute la zone est touchable, même sous la dernière ligne
                        .heightIn(min = with(density) { viewport.toDp() })
                        .padding(horizontal = 16.dp, vertical = 10.dp)
                        .focusRequester(focus)
                        .onFocusChanged { bodyFocused = it.isFocused },
                    decorationBox = { inner ->
                        Box {
                            if (field.text.isEmpty()) {
                                Text(
                                    "Écrivez… Adresses, numéros, dates et e-mails sont reconnus automatiquement.",
                                    style = bodyStyle.copy(color = cs.onSurfaceVariant),
                                )
                            }
                            inner()
                        }
                    },
                )
            }
        }
        // Barre d'actions fixe, juste au-dessus du clavier (même hauteur avec ou sans sélection : rien ne saute)
        val hasSel = !field.selection.collapsed
        Surface(color = if (hasSel) cs.secondaryContainer else cs.surfaceContainer, tonalElevation = 2.dp) {
            Row(
                Modifier
                    .fillMaxWidth()
                    .height(52.dp)
                    .padding(horizontal = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                val pal = palette
                if (pal != null) Row(
                    Modifier.weight(1f).horizontalScroll(rememberScrollState()),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    // Couleurs du texte ou du surlignage, appliquées à la sélection (ou à ce qu'on va écrire)
                    IconButton(onClick = { palette = null }) { Icon(Icons.Filled.Close, "Fermer les couleurs") }
                    val a = field.selection.min.coerceIn(0, field.text.length)
                    val b = field.selection.max.coerceIn(0, field.text.length)
                    val current = remember(field.text, a, b, pal) { fr.jeremy.calepin.text.RichText.valueOver(field.text, a, b, pal) }
                    ColorSwatches(if (pal == "bg") HIGHLIGHT_COLORS else TEXT_COLORS, current) { hex -> onRich(pal, hex) }
                } else Row(
                    Modifier.weight(1f).horizontalScroll(rememberScrollState()),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    if (hasSel) {
                        val sel = fr.jeremy.calepin.text.RichText.strip(
                            field.text.substring(
                                field.selection.min.coerceIn(0, field.text.length),
                                field.selection.max.coerceIn(0, field.text.length),
                            ),
                        )
                        Text(
                            fr.jeremy.calepin.i18n.I18n.trf("{0} caractères", sel.length),
                            style = MaterialTheme.typography.labelMedium, color = cs.onSecondaryContainer,
                            modifier = Modifier.padding(horizontal = 8.dp),
                        )
                        TextButton(onClick = { onAgenda(sel) }) { Icon(Icons.Filled.EventAvailable, null, Modifier.size(18.dp)); Text(" Agenda") }
                        TextButton(onClick = { onAlarm(sel) }) { Icon(Icons.Filled.Alarm, null, Modifier.size(18.dp)); Text(" Alarme") }
                        TextButton(onClick = onSelectAll) { Text("Tout") }
                    } else {
                        IconButton(onClick = onChecklist) { Icon(Icons.Filled.Checklist, "Liste à cocher") }
                        IconButton(onClick = onDictate) { Icon(Icons.Filled.KeyboardVoice, "Dicter du texte") }
                        IconButton(onClick = onScan) { Icon(Icons.Filled.DocumentScanner, "Scanner du texte (photo)") }
                        Box {
                            IconButton(onClick = onMedia) { Icon(Icons.Filled.AddPhotoAlternate, "Photo ou vidéo ici") }
                            mediaMenu()
                        }
                        IconButton(onClick = onSelectAll) { Icon(Icons.Filled.SelectAll, "Tout sélectionner") }
                    }
                    // Mise en forme : sur la sélection, ou repères insérés au curseur
                    IconButton(onClick = { onFormat("bold") }) { Icon(Icons.Filled.FormatBold, "Gras") }
                    IconButton(onClick = { onFormat("italic") }) { Icon(Icons.Filled.FormatItalic, "Italique") }
                    IconButton(onClick = { onFormat("strike") }) { Icon(Icons.Filled.FormatStrikethrough, "Barré") }
                    IconButton(onClick = { onRich("u", null) }) { Icon(Icons.Filled.FormatUnderlined, "Souligné") }
                    IconButton(onClick = { palette = "c" }) { Icon(Icons.Filled.FormatColorText, "Couleur du texte", tint = cs.primary) }
                    IconButton(onClick = { palette = "bg" }) { Icon(Icons.Filled.BorderColor, "Surligner", tint = cs.tertiary) }
                    val align = remember(field.text, field.selection.start) { fr.jeremy.calepin.text.RichText.alignAt(field.text, field.selection.start) }
                    IconButton(onClick = {
                        onRich("align", when (align) { null -> fr.jeremy.calepin.text.RichText.CENTER; fr.jeremy.calepin.text.RichText.CENTER -> fr.jeremy.calepin.text.RichText.RIGHT; else -> null })
                    }) {
                        Icon(
                            when (align) {
                                fr.jeremy.calepin.text.RichText.CENTER -> Icons.Filled.FormatAlignCenter
                                fr.jeremy.calepin.text.RichText.RIGHT -> Icons.Filled.FormatAlignRight
                                else -> Icons.Filled.FormatAlignLeft
                            },
                            "Alignement (gauche, centré, droite)",
                        )
                    }
                    IconButton(onClick = { onFormat("title") }) { Icon(Icons.Filled.Title, "Titre") }
                    IconButton(onClick = { onFormat("list") }) { Icon(Icons.Filled.FormatListBulleted, "Liste à puces") }
                    IconButton(onClick = { onFormat("link") }) { Icon(Icons.Filled.Link, "Lien vers une autre note") }
                }
                androidx.compose.material3.FilledTonalButton(onClick = onDone) {
                    Icon(Icons.Filled.Check, null, Modifier.size(18.dp)); Text(" Terminer")
                }
            }
        }
    }
}
