package fr.jeremy.calepin.ui

import android.content.Context
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Alarm
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Directions
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.EventAvailable
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Map
import androidx.compose.material.icons.filled.Navigation
import androidx.compose.material.icons.filled.PersonAdd
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.PushPin
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Sms
import androidx.compose.material.icons.outlined.PushPin
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.AssistChip
import androidx.compose.material3.AssistChipDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ListItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.LinkAnnotation
import androidx.compose.ui.text.LinkInteractionListener
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextLinkStyles
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.withLink
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import fr.jeremy.calepin.Actions
import fr.jeremy.calepin.NotesViewModel
import fr.jeremy.calepin.data.Note
import fr.jeremy.calepin.detect.Entity
import fr.jeremy.calepin.detect.EntityDetector
import fr.jeremy.calepin.detect.EntityType
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun EditorScreen(vm: NotesViewModel, noteId: Long?, initialText: String?, onClose: () -> Unit) {
    val existing = remember(noteId) { noteId?.let { vm.find(it) } }
    var id by remember { mutableLongStateOf(existing?.id ?: 0L) }
    var title by rememberSaveable { mutableStateOf(existing?.title ?: "") }
    var content by rememberSaveable { mutableStateOf(existing?.content ?: initialText ?: "") }
    var tag by rememberSaveable { mutableStateOf(existing?.tag ?: "") }
    var pinned by rememberSaveable { mutableStateOf(existing?.pinned ?: false) }
    var editing by rememberSaveable { mutableStateOf(existing == null) }
    val createdAt = remember { existing?.createdAt ?: System.currentTimeMillis() }
    var savedSnapshot by remember { mutableStateOf(existing) }
    var selected by remember { mutableStateOf<Entity?>(null) }
    var confirmDelete by remember { mutableStateOf(false) }
    val ctx = LocalContext.current

    val entities = remember(content) { EntityDetector.detect(content) }

    fun persist() {
        if (title.isBlank() && content.isBlank()) return
        val s = savedSnapshot
        if (s != null && s.title == title && s.content == content && s.tag == tag && s.pinned == pinned) return
        val note = Note(
            id = id, title = title.trim(), content = content, tag = tag.trim(), pinned = pinned,
            createdAt = createdAt, updatedAt = System.currentTimeMillis(),
        )
        id = vm.saveNow(note)
        savedSnapshot = note.copy(id = id, title = title, tag = tag)
    }

    fun close() {
        persist()
        onClose()
    }

    BackHandler { close() }

    // Sauvegarde automatique si l'appli passe en arrière-plan.
    val latestPersist by rememberUpdatedState({ persist() })
    val lifecycleOwner = LocalLifecycleOwner.current
    DisposableEffect(lifecycleOwner) {
        val obs = LifecycleEventObserver { _, e -> if (e == Lifecycle.Event.ON_STOP) latestPersist() }
        lifecycleOwner.lifecycle.addObserver(obs)
        onDispose { lifecycleOwner.lifecycle.removeObserver(obs) }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(if (editing) "Écrire" else "Note") },
                navigationIcon = {
                    IconButton(onClick = { close() }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Retour")
                    }
                },
                actions = {
                    IconButton(onClick = { pinned = !pinned }) {
                        Icon(
                            if (pinned) Icons.Filled.PushPin else Icons.Outlined.PushPin,
                            contentDescription = if (pinned) "Désépingler" else "Épingler",
                            tint = if (pinned) MaterialTheme.colorScheme.secondary else MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                    IconButton(onClick = { Actions.share(ctx, title, content) }) {
                        Icon(Icons.Filled.Share, contentDescription = "Partager")
                    }
                    if (id != 0L) {
                        IconButton(onClick = { confirmDelete = true }) {
                            Icon(Icons.Filled.Delete, contentDescription = "Supprimer")
                        }
                    }
                },
            )
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = {
                    if (editing) persist()
                    editing = !editing
                },
                icon = { Icon(if (editing) Icons.Filled.Check else Icons.Filled.Edit, contentDescription = null) },
                text = { Text(if (editing) "Terminer" else "Modifier") },
            )
        },
    ) { pad ->
        Column(
            Modifier
                .fillMaxSize()
                .padding(pad)
                .imePadding()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp)
                .padding(bottom = 96.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            if (editing) {
                val bare = TextFieldDefaults.colors(
                    focusedContainerColor = Color.Transparent,
                    unfocusedContainerColor = Color.Transparent,
                    focusedIndicatorColor = Color.Transparent,
                    unfocusedIndicatorColor = Color.Transparent,
                )
                TextField(
                    value = title, onValueChange = { title = it },
                    placeholder = { Text("Titre", style = MaterialTheme.typography.headlineSmall) },
                    textStyle = MaterialTheme.typography.headlineSmall,
                    colors = bare, singleLine = true,
                    keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Sentences),
                    modifier = Modifier.fillMaxWidth(),
                )
                TextField(
                    value = tag, onValueChange = { tag = it },
                    placeholder = { Text("Étiquettes, séparées par des virgules") },
                    textStyle = MaterialTheme.typography.labelLarge.copy(color = MaterialTheme.colorScheme.secondary),
                    colors = bare, singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                )
                HorizontalDivider()
                TextField(
                    value = content, onValueChange = { content = it },
                    placeholder = {
                        Text("Écrivez… Adresses, numéros, dates et e-mails sont reconnus automatiquement.")
                    },
                    textStyle = MaterialTheme.typography.bodyLarge,
                    colors = bare,
                    keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Sentences),
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(min = 220.dp),
                )
            } else {
                Text(
                    title.ifBlank { "Sans titre" },
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.SemiBold,
                )
                val tagList = tag.split(',').map { it.trim() }.filter { it.isNotEmpty() }
                if (tagList.isNotEmpty()) {
                    Text(
                        tagList.joinToString(" · "),
                        style = MaterialTheme.typography.labelLarge,
                        color = MaterialTheme.colorScheme.secondary,
                    )
                }
                HorizontalDivider()
                SelectionContainer {
                    Text(
                        linkified(content, entities) { selected = it },
                        style = MaterialTheme.typography.bodyLarge,
                        modifier = Modifier.fillMaxWidth(),
                    )
                }
            }

            if (entities.isNotEmpty()) {
                Spacer(Modifier.size(4.dp))
                Text(
                    "Reconnu dans la note · touchez pour agir",
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    entities.forEach { e ->
                        AssistChip(
                            onClick = { selected = e },
                            label = {
                                Text(
                                    when {
                                        e.type == EntityType.DATE -> e.value
                                        e.country != null -> e.country.substringBefore(' ') + "  " + e.text
                                        else -> e.text
                                    },
                                    maxLines = 1, overflow = TextOverflow.Ellipsis,
                                    modifier = Modifier.widthIn(max = 260.dp),
                                )
                            },
                            leadingIcon = {
                                Icon(e.type.icon(), contentDescription = e.type.label, modifier = Modifier.size(AssistChipDefaults.IconSize))
                            },
                        )
                    }
                }
            }

            if (existing != null) {
                val f = SimpleDateFormat("d MMM yyyy 'à' HH:mm", Locale.FRANCE)
                Text(
                    "Créée le ${f.format(Date(existing.createdAt))} · modifiée le ${f.format(Date(existing.updatedAt))}",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
    }

    selected?.let { e ->
        EntitySheet(
            entity = e,
            all = entities,
            noteTitle = title,
            noteContent = content,
            onDismiss = { selected = null },
        )
    }

    if (confirmDelete) {
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            title = { Text("Supprimer cette note ?") },
            text = { Text("La note « ${title.ifBlank { "Sans titre" }} » sera définitivement effacée.") },
            confirmButton = {
                TextButton(onClick = {
                    confirmDelete = false
                    vm.delete(id)
                    onClose()
                }) { Text("Supprimer", color = MaterialTheme.colorScheme.error) }
            },
            dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text("Annuler") } },
        )
    }
}

@Composable
private fun linkified(text: String, entities: List<Entity>, onClick: (Entity) -> Unit): AnnotatedString {
    val linkStyle = TextLinkStyles(
        style = SpanStyle(
            color = MaterialTheme.colorScheme.primary,
            fontWeight = FontWeight.Medium,
            textDecoration = TextDecoration.Underline,
        ),
    )
    return buildAnnotatedString {
        var pos = 0
        for (e in entities) {
            if (e.start < pos || e.end > text.length) continue
            append(text.substring(pos, e.start))
            withLink(
                LinkAnnotation.Clickable(
                    tag = "e${e.start}",
                    styles = linkStyle,
                    linkInteractionListener = LinkInteractionListener { onClick(e) },
                ),
            ) {
                append(text.substring(e.start, e.end))
            }
            pos = e.end
        }
        append(text.substring(pos))
    }
}

private class EntityAction(val label: String, val icon: ImageVector, val run: (Context) -> Unit)

private fun actionsFor(e: Entity, all: List<Entity>, title: String, content: String): List<EntityAction> {
    val firstOf = { t: EntityType -> all.firstOrNull { it.type == t }?.value }
    val contactName = title.ifBlank { "" }
    return when (e.type) {
        EntityType.PHONE -> listOf(
            EntityAction("Appeler", Icons.Filled.Phone) { Actions.dial(it, e.value) },
            EntityAction("Envoyer un SMS", Icons.Filled.Sms) { Actions.sms(it, e.value) },
            EntityAction("Écrire sur WhatsApp", Icons.Filled.Chat) { Actions.whatsapp(it, e.value) },
            EntityAction("Créer un contact (avec les infos de la note)", Icons.Filled.PersonAdd) {
                Actions.addContact(it, contactName, e.value, firstOf(EntityType.EMAIL), firstOf(EntityType.ADDRESS), content)
            },
            EntityAction("Copier le numéro", Icons.Filled.ContentCopy) { Actions.copy(it, e.text) },
        )
        EntityType.EMAIL -> listOf(
            EntityAction("Écrire un e-mail", Icons.Filled.Email) { Actions.email(it, e.value, title) },
            EntityAction("Créer un contact (avec les infos de la note)", Icons.Filled.PersonAdd) {
                Actions.addContact(it, contactName, firstOf(EntityType.PHONE), e.value, firstOf(EntityType.ADDRESS), content)
            },
            EntityAction("Copier l'adresse e-mail", Icons.Filled.ContentCopy) { Actions.copy(it, e.value) },
        )
        EntityType.ADDRESS -> listOf(
            EntityAction("Voir sur la carte", Icons.Filled.Map) { Actions.showOnMap(it, e.value) },
            EntityAction("Itinéraire Google Maps", Icons.Filled.Directions) { Actions.directions(it, e.value) },
            EntityAction("Itinéraire Waze", Icons.Filled.Navigation) { Actions.waze(it, e.value) },
            EntityAction("Ajouter à un contact", Icons.Filled.PersonAdd) {
                Actions.addContact(it, contactName, firstOf(EntityType.PHONE), firstOf(EntityType.EMAIL), e.value, content)
            },
            EntityAction("Copier l'adresse", Icons.Filled.ContentCopy) { Actions.copy(it, e.value) },
        )
        EntityType.DATE -> buildList {
            val t = e.timeMillis ?: return@buildList
            add(EntityAction("Ajouter à l'agenda", Icons.Filled.EventAvailable) {
                Actions.addEvent(it, title, content, t, e.hasTime, firstOf(EntityType.ADDRESS))
            })
            add(EntityAction("Ouvrir l'agenda à cette date", Icons.Filled.CalendarMonth) { Actions.openCalendarAt(it, t) })
            if (Actions.canSetAlarm(t, e.hasTime)) {
                add(EntityAction("Régler une alarme", Icons.Filled.Alarm) { Actions.setAlarm(it, t, title) })
            }
            add(EntityAction("Copier la date", Icons.Filled.ContentCopy) { Actions.copy(it, e.value) })
        }
        EntityType.URL -> listOf(
            EntityAction("Ouvrir le lien", Icons.Filled.Language) { Actions.openUrl(it, e.value) },
            EntityAction("Copier le lien", Icons.Filled.ContentCopy) { Actions.copy(it, e.value) },
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun EntitySheet(entity: Entity, all: List<Entity>, noteTitle: String, noteContent: String, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(Modifier.padding(bottom = 24.dp)) {
            ListItem(
                overlineContent = { Text(entity.type.label) },
                headlineContent = {
                    Text(
                        if (entity.type == EntityType.DATE) entity.value else entity.text,
                        style = MaterialTheme.typography.titleMedium,
                    )
                },
                supportingContent = when {
                    entity.type == EntityType.DATE -> {
                        { Text("Écrit « ${entity.text} »") }
                    }
                    entity.country != null -> {
                        { Text(entity.country) }
                    }
                    else -> null
                },
                leadingContent = { Icon(entity.type.icon(), contentDescription = null, tint = MaterialTheme.colorScheme.primary) },
            )
            HorizontalDivider()
            actionsFor(entity, all, noteTitle, noteContent).forEach { a ->
                ListItem(
                    headlineContent = { Text(a.label) },
                    leadingContent = { Icon(a.icon, contentDescription = null) },
                    modifier = Modifier.clickable {
                        a.run(ctx)
                        onDismiss()
                    },
                )
            }
        }
    }
}
