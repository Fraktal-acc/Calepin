package fr.jeremy.calepin.ui

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.speech.RecognizerIntent
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.filled.AccessAlarm
import androidx.compose.material.icons.filled.Today
import androidx.compose.material.icons.filled.KeyboardVoice
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material3.Surface
import androidx.compose.runtime.derivedStateOf
import androidx.compose.ui.Alignment
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.input.TextFieldValue
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import fr.jeremy.calepin.LockGuard
import fr.jeremy.calepin.data.Event
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.withFrameNanos
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInParent
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.TextLayoutResult
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Alarm
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Directions
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.EventAvailable
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Map
import androidx.compose.material.icons.filled.Navigation
import androidx.compose.material.icons.filled.PersonAdd
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.PushPin
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.SaveAlt
import androidx.compose.material.icons.filled.Sms
import androidx.compose.material.icons.outlined.PushPin
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.AssistChip
import androidx.compose.material3.AssistChipDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ListItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.LinkAnnotation
import androidx.compose.ui.text.LinkInteractionListener
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextLinkStyles
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.withLink
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import fr.jeremy.calepin.Actions
import fr.jeremy.calepin.NotesViewModel
import fr.jeremy.calepin.data.Note
import fr.jeremy.calepin.detect.Entity
import fr.jeremy.calepin.detect.EntityDetector
import fr.jeremy.calepin.detect.EntityType
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun EditorScreen(vm: NotesViewModel, noteId: Long?, initialText: String?, initialTitle: String? = null, onClose: () -> Unit) {
    val existing = remember(noteId) { noteId?.let { vm.find(it) } }
    var id by remember { mutableLongStateOf(existing?.id ?: 0L) }
    var title by rememberSaveable { mutableStateOf(existing?.title ?: initialTitle ?: "") }
    var field by rememberSaveable(stateSaver = TextFieldValue.Saver) {
        mutableStateOf(TextFieldValue(existing?.content ?: initialText ?: ""))
    }
    val content by remember { derivedStateOf { field.text } }
    var tag by rememberSaveable { mutableStateOf(existing?.tag ?: "") }
    var pinned by rememberSaveable { mutableStateOf(existing?.pinned ?: false) }
    var editing by rememberSaveable { mutableStateOf(existing == null) }
    val createdAt = remember { existing?.createdAt ?: System.currentTimeMillis() }
    var savedSnapshot by remember { mutableStateOf(existing) }
    var selected by remember { mutableStateOf<Entity?>(null) }
    var confirmDelete by remember { mutableStateOf(false) }
    var exporting by remember { mutableStateOf(false) }
    var eventDraft by remember { mutableStateOf<Event?>(null) }
    val allEvents by vm.events.collectAsStateWithLifecycle()
    val defaultRingtone by vm.settings.ringtone.collectAsStateWithLifecycle()
    val noteEvents = if (id == 0L) emptyList() else allEvents.filter { it.noteId == id }
    val ctx = LocalContext.current

    /** Insère du texte à l'emplacement du curseur (ou à la fin hors édition). */
    fun insertText(t: String) {
        val f = field
        val pos = if (editing) f.selection.end.coerceIn(0, f.text.length) else f.text.length
        val before = f.text.substring(0, pos)
        val sep = when {
            before.isEmpty() -> ""
            before.endsWith("\n") -> ""
            editing && !before.endsWith(" ") -> " "
            else -> "\n\n"
        }
        val newText = before + sep + t + f.text.substring(pos)
        field = TextFieldValue(newText, TextRange(pos + sep.length + t.length))
    }

    /** Prépare un rendez-vous à partir d'un texte : sa date s'il en contient une, sinon demain 9 h. */
    fun draftFrom(text: String, alarm: Boolean, fallbackTitle: String) {
        val d = EntityDetector.detect(text).firstOrNull { it.type == EntityType.DATE && it.timeMillis != null }
        val start = d?.timeMillis ?: java.util.Calendar.getInstance().apply {
            add(java.util.Calendar.DAY_OF_YEAR, 1)
            set(java.util.Calendar.HOUR_OF_DAY, 9); set(java.util.Calendar.MINUTE, 0); set(java.util.Calendar.SECOND, 0)
        }.timeInMillis
        val allDay = d != null && !d.hasTime
        val cleaned = text.replace(Regex("\\s+"), " ").trim().take(80)
        eventDraft = Event(
            title = cleaned.ifBlank { fallbackTitle },
            start = start,
            end = d?.endMillis ?: 0L,
            allDay = allDay,
            remindMinutes = if (allDay) -540 else if (alarm) 0 else 15,
            alarm = alarm,
        )
    }

    val dictation = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { res ->
        val text = res.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
        if (res.resultCode == Activity.RESULT_OK && !text.isNullOrBlank()) {
            insertText(text.replaceFirstChar { it.uppercase() })
        }
    }

    val entities = remember(content) { EntityDetector.detect(content) }

    fun persist() {
        if (title.isBlank() && content.isBlank()) return
        val s = savedSnapshot
        if (s != null && s.title == title && s.content == content && s.tag == tag && s.pinned == pinned) return
        val note = Note(
            id = id, title = title.trim(), content = content, tag = tag.trim(), pinned = pinned,
            createdAt = createdAt, updatedAt = System.currentTimeMillis(),
        )
        id = vm.saveNow(note)
        savedSnapshot = note.copy(id = id, title = title, tag = tag)
    }

    /** Pour un mémo vocal : la note doit exister. Une note vide reçoit un titre daté. */
    fun ensureNote(): Long {
        if (title.isBlank() && content.isBlank()) {
            title = "Mémo vocal du " + SimpleDateFormat("d MMMM 'à' HH'h'mm", Locale.FRANCE).format(Date())
        }
        persist()
        return id
    }

    fun close() {
        persist()
        onClose()
    }

    BackHandler { close() }

    // Sauvegarde automatique si l'appli passe en arrière-plan.
    val latestPersist by rememberUpdatedState({ persist() })
    val lifecycleOwner = LocalLifecycleOwner.current
    DisposableEffect(lifecycleOwner) {
        val obs = LifecycleEventObserver { _, e -> if (e == Lifecycle.Event.ON_STOP) latestPersist() }
        lifecycleOwner.lifecycle.addObserver(obs)
        onDispose { lifecycleOwner.lifecycle.removeObserver(obs) }
    }

    // --- Garder la position de lecture entre « lecture » et « modification » ---
    val scroll = rememberScrollState()
    val focus = remember { FocusRequester() }
    val focusManager = LocalFocusManager.current
    var readLayout by remember { mutableStateOf<TextLayoutResult?>(null) }
    var readTop by remember { mutableFloatStateOf(0f) }
    var editLayout by remember { mutableStateOf<TextLayoutResult?>(null) }
    var editTop by remember { mutableFloatStateOf(0f) }
    /** Après un changement de mode : (position dans le texte, hauteur voulue à l'écran pour cette ligne). */
    var anchor by remember { mutableStateOf<Pair<Int, Float>?>(null) }

    fun lineTop(l: TextLayoutResult, offset: Int): Float =
        l.getLineTop(l.getLineForOffset(offset.coerceIn(0, l.layoutInput.text.length)))

    /** Position dans le texte de la première ligne visible à l'écran. */
    fun firstVisible(l: TextLayoutResult?, top: Float): Int =
        l?.getOffsetForPosition(Offset(0f, (scroll.value - top).coerceAtLeast(0f))) ?: 0

    fun startEditing(offset: Int, screenY: Float) {
        field = field.copy(selection = TextRange(offset.coerceIn(0, field.text.length)))
        editLayout = null
        anchor = offset to screenY
        editing = true
    }

    fun startEditingHere() {
        val l = readLayout
        val off = firstVisible(l, readTop)
        startEditing(off, if (l != null) readTop + lineTop(l, off) - scroll.value else 0f)
    }

    fun stopEditing() {
        persist()
        val l = editLayout
        val off = firstVisible(l, editTop)
        anchor = off to (if (l != null) editTop + lineTop(l, off) - scroll.value else 0f)
        focusManager.clearFocus()
        readLayout = null
        editing = false
    }

    LaunchedEffect(anchor, editing, readLayout, editLayout) {
        val a = anchor ?: return@LaunchedEffect
        val l = (if (editing) editLayout else readLayout) ?: return@LaunchedEffect
        withFrameNanos { } // laisser la mise en page se terminer
        val top = if (editing) editTop else readTop
        scroll.scrollTo((top + lineTop(l, a.first) - a.second).toInt().coerceIn(0, scroll.maxValue))
        // Le curseur est déjà au bon endroit : le clavier s'ouvre sans faire sauter l'écran
        if (editing) runCatching { focus.requestFocus() }
        anchor = null
    }

    Scaffold(
        bottomBar = {
            // Barre « Sélection » toujours visible au-dessus du clavier, même dans une longue note
            if (editing && !field.selection.collapsed) {
                val sel = field.text.substring(
                    field.selection.min.coerceIn(0, field.text.length),
                    field.selection.max.coerceIn(0, field.text.length),
                )
                Surface(
                    color = MaterialTheme.colorScheme.secondaryContainer,
                    modifier = Modifier
                        .navigationBarsPadding()
                        .imePadding(),
                ) {
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Text(
                            "Sélection",
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onSecondaryContainer,
                            modifier = Modifier
                                .weight(1f)
                                .padding(start = 8.dp),
                        )
                        TextButton(onClick = { draftFrom(sel, alarm = false, fallbackTitle = title) }) {
                            Icon(Icons.Filled.EventAvailable, null, Modifier.size(18.dp)); Text(" Agenda")
                        }
                        TextButton(onClick = { draftFrom(sel, alarm = true, fallbackTitle = title) }) {
                            Icon(Icons.Filled.Alarm, null, Modifier.size(18.dp)); Text(" Alarme")
                        }
                    }
                }
            }
        },
        topBar = {
            TopAppBar(
                title = { Text(if (editing) "Écrire" else "Note") },
                navigationIcon = {
                    IconButton(onClick = { close() }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Retour")
                    }
                },
                actions = {
                    if (editing) {
                        IconButton(onClick = {
                            LockGuard.external()
                            try {
                                dictation.launch(
                                    Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                                        putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                                        putExtra(RecognizerIntent.EXTRA_LANGUAGE, "fr-FR")
                                        putExtra(RecognizerIntent.EXTRA_PROMPT, "Parlez, le texte s'écrit dans la note")
                                    }
                                )
                            } catch (e: Exception) {
                                Toast.makeText(ctx, "La dictée vocale n'est pas disponible sur ce téléphone", Toast.LENGTH_LONG).show()
                            }
                        }) {
                            Icon(Icons.Filled.KeyboardVoice, contentDescription = "Dicter du texte")
                        }
                    }
                    IconButton(onClick = { pinned = !pinned }) {
                        Icon(
                            if (pinned) Icons.Filled.PushPin else Icons.Outlined.PushPin,
                            contentDescription = if (pinned) "Désépingler" else "Épingler",
                            tint = if (pinned) MaterialTheme.colorScheme.secondary else MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                    IconButton(onClick = { Actions.share(ctx, title, content) }) {
                        Icon(Icons.Filled.Share, contentDescription = "Partager")
                    }
                    IconButton(onClick = { persist(); exporting = true }) {
                        Icon(Icons.Filled.SaveAlt, contentDescription = "Exporter (PDF, Word, Excel…)")
                    }
                    if (id != 0L) {
                        IconButton(onClick = { confirmDelete = true }) {
                            Icon(Icons.Filled.Delete, contentDescription = "Supprimer")
                        }
                    }
                },
            )
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = { if (editing) stopEditing() else startEditingHere() },
                icon = { Icon(if (editing) Icons.Filled.Check else Icons.Filled.Edit, contentDescription = null) },
                text = { Text(if (editing) "Terminer" else "Modifier") },
            )
        },
    ) { pad ->
        Column(
            Modifier
                .fillMaxSize()
                .padding(pad)
                .imePadding()
                .verticalScroll(scroll)
                .padding(horizontal = 16.dp)
                .padding(bottom = 96.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            if (editing) {
                val bare = TextFieldDefaults.colors(
                    focusedContainerColor = Color.Transparent,
                    unfocusedContainerColor = Color.Transparent,
                    focusedIndicatorColor = Color.Transparent,
                    unfocusedIndicatorColor = Color.Transparent,
                )
                TextField(
                    value = title, onValueChange = { title = it },
                    placeholder = { Text("Titre", style = MaterialTheme.typography.headlineSmall) },
                    textStyle = MaterialTheme.typography.headlineSmall,
                    colors = bare, singleLine = true,
                    keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Sentences),
                    modifier = Modifier.fillMaxWidth(),
                )
                TextField(
                    value = tag, onValueChange = { tag = it },
                    placeholder = { Text("Étiquettes, séparées par des virgules") },
                    textStyle = MaterialTheme.typography.labelLarge.copy(color = MaterialTheme.colorScheme.secondary),
                    colors = bare, singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                )
                HorizontalDivider()
                val bodyStyle = MaterialTheme.typography.bodyLarge.copy(color = MaterialTheme.colorScheme.onSurface)
                BasicTextField(
                    value = field,
                    onValueChange = { field = it },
                    textStyle = bodyStyle,
                    cursorBrush = SolidColor(MaterialTheme.colorScheme.primary),
                    keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Sentences),
                    onTextLayout = { editLayout = it },
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(min = 220.dp)
                        .focusRequester(focus)
                        .onGloballyPositioned { editTop = it.positionInParent().y },
                    decorationBox = { inner ->
                        Box {
                            if (field.text.isEmpty()) {
                                Text(
                                    "Écrivez… Adresses, numéros, dates et e-mails sont reconnus automatiquement.",
                                    style = bodyStyle.copy(color = MaterialTheme.colorScheme.onSurfaceVariant),
                                )
                            }
                            inner()
                        }
                    },
                )
            } else {
                Text(
                    title.ifBlank { "Sans titre" },
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.SemiBold,
                )
                val tagList = tag.split(',').map { it.trim() }.filter { it.isNotEmpty() }
                if (tagList.isNotEmpty()) {
                    Text(
                        tagList.joinToString(" · "),
                        style = MaterialTheme.typography.labelLarge,
                        color = MaterialTheme.colorScheme.secondary,
                    )
                }
                HorizontalDivider()
                // Toucher le texte ouvre la modification à cet endroit précis (les liens gardent leur action)
                Text(
                    linkified(content, entities) { selected = it },
                    style = MaterialTheme.typography.bodyLarge,
                    onTextLayout = { readLayout = it },
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(min = 48.dp)
                        .onGloballyPositioned { readTop = it.positionInParent().y }
                        .pointerInput(content, entities) {
                            detectTapGestures { pos ->
                                val l = readLayout
                                if (l == null || content.isEmpty()) {
                                    startEditing(content.length, 0f)
                                    return@detectTapGestures
                                }
                                val off = l.getOffsetForPosition(pos)
                                if (entities.any { off >= it.start && off < it.end }) return@detectTapGestures
                                startEditing(off, readTop + lineTop(l, off) - scroll.value)
                            }
                        },
                )
            }

            if (entities.isNotEmpty()) {
                Spacer(Modifier.size(4.dp))
                Text(
                    "Reconnu dans la note · touchez pour agir",
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    entities.forEach { e ->
                        AssistChip(
                            onClick = { selected = e },
                            label = {
                                Text(
                                    when {
                                        e.type == EntityType.DATE -> e.value
                                        e.country != null -> e.country.substringBefore(' ') + "  " + e.text
                                        else -> e.text
                                    },
                                    maxLines = 1, overflow = TextOverflow.Ellipsis,
                                    modifier = Modifier.widthIn(max = 260.dp),
                                )
                            },
                            leadingIcon = {
                                Icon(e.type.icon(), contentDescription = e.type.label, modifier = Modifier.size(AssistChipDefaults.IconSize))
                            },
                        )
                    }
                }
            }

            if (noteEvents.isNotEmpty()) {
                Text(
                    "Dans l'agenda",
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    noteEvents.forEach { ev ->
                        AssistChip(
                            onClick = { eventDraft = ev },
                            label = {
                                Text(
                                    SimpleDateFormat(if (ev.allDay) "d MMM" else "d MMM HH:mm", Locale.FRANCE).format(Date(ev.start)) +
                                        (if (ev.isPeriod) " → " + SimpleDateFormat("d MMM", Locale.FRANCE).format(Date(ev.end)) else "") +
                                        " · " + ev.title,
                                    maxLines = 1, overflow = TextOverflow.Ellipsis,
                                    modifier = Modifier.widthIn(max = 260.dp),
                                )
                            },
                            leadingIcon = {
                                Icon(
                                    when {
                                        ev.remindMinutes < 0 -> Icons.Filled.Today
                                        ev.alarm -> Icons.Filled.Alarm
                                        else -> Icons.Filled.NotificationsActive
                                    },
                                    null, Modifier.size(AssistChipDefaults.IconSize),
                                )
                            },
                        )
                    }
                }
            }

            Spacer(Modifier.size(4.dp))
            RecordingsSection(
                vm = vm, noteId = id, noteTitle = title,
                ensureNote = { ensureNote() },
                onInsertText = { insertText(it) },
            )
            MediaSection(vm = vm, noteId = id, ensureNote = { ensureNote() })

            if (existing != null) {
                val f = SimpleDateFormat("d MMM yyyy 'à' HH:mm", Locale.FRANCE)
                Text(
                    "Créée le ${f.format(Date(existing.createdAt))} · modifiée le ${f.format(Date(existing.updatedAt))}",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
    }

    selected?.let { e ->
        EntitySheet(
            entity = e,
            all = entities,
            noteTitle = title,
            noteContent = content,
            onDismiss = { selected = null },
            onCalepinEvent = { ent, alarm ->
                selected = null
                val t = ent.timeMillis
                if (t != null) {
                    eventDraft = Event(
                        title = title.ifBlank { "Rendez-vous" }, start = t, allDay = !ent.hasTime,
                        end = ent.endMillis ?: 0L,
                        remindMinutes = if (!ent.hasTime) -540 else if (alarm) 0 else 15, alarm = alarm,
                    )
                }
            },
        )
    }

    eventDraft?.let { ev ->
        EventDialog(
            initial = ev,
            defaultRingtone = defaultRingtone,
            onDismiss = { eventDraft = null },
            onSave = { saved ->
                val nid = if (saved.noteId != 0L) saved.noteId else ensureNote()
                vm.saveEvent(saved.copy(noteId = nid))
                eventDraft = null
                Toast.makeText(ctx, "Ajouté à l'agenda Calepin", Toast.LENGTH_SHORT).show()
            },
            onDelete = if (ev.id != 0L) ({ vm.deleteEvent(ev); eventDraft = null }) else null,
        )
    }

    if (exporting) {
        val n = Note(id = id, title = title, content = content, tag = tag, pinned = pinned, createdAt = createdAt)
        ExportSheet(vm, listOf(n), onDismiss = { exporting = false })
    }

    if (confirmDelete) {
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            title = { Text("Supprimer cette note ?") },
            text = { Text("La note « ${title.ifBlank { "Sans titre" }} » sera définitivement effacée.") },
            confirmButton = {
                TextButton(onClick = {
                    confirmDelete = false
                    vm.delete(id)
                    onClose()
                }) { Text("Supprimer", color = MaterialTheme.colorScheme.error) }
            },
            dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text("Annuler") } },
        )
    }
}

@Composable
private fun linkified(text: String, entities: List<Entity>, onClick: (Entity) -> Unit): AnnotatedString {
    val linkStyle = TextLinkStyles(
        style = SpanStyle(
            color = MaterialTheme.colorScheme.primary,
            fontWeight = FontWeight.Medium,
            textDecoration = TextDecoration.Underline,
        ),
    )
    return buildAnnotatedString {
        var pos = 0
        for (e in entities) {
            if (e.start < pos || e.end > text.length) continue
            append(text.substring(pos, e.start))
            withLink(
                LinkAnnotation.Clickable(
                    tag = "e${e.start}",
                    styles = linkStyle,
                    linkInteractionListener = LinkInteractionListener { onClick(e) },
                ),
            ) {
                append(text.substring(e.start, e.end))
            }
            pos = e.end
        }
        append(text.substring(pos))
    }
}

private class EntityAction(val label: String, val icon: ImageVector, val run: (Context) -> Unit)

private fun actionsFor(
    e: Entity,
    all: List<Entity>,
    title: String,
    content: String,
    onCalepinEvent: (Entity, Boolean) -> Unit,
): List<EntityAction> {
    val firstOf = { t: EntityType -> all.firstOrNull { it.type == t }?.value }
    val contactName = title.ifBlank { "" }
    return when (e.type) {
        EntityType.PHONE -> listOf(
            EntityAction("Appeler", Icons.Filled.Phone) { Actions.dial(it, e.value) },
            EntityAction("Envoyer un SMS", Icons.Filled.Sms) { Actions.sms(it, e.value) },
            EntityAction("Écrire sur WhatsApp", Icons.Filled.Chat) { Actions.whatsapp(it, e.value) },
            EntityAction("Créer un contact (avec les infos de la note)", Icons.Filled.PersonAdd) {
                Actions.addContact(it, contactName, e.value, firstOf(EntityType.EMAIL), firstOf(EntityType.ADDRESS), content)
            },
            EntityAction("Copier le numéro", Icons.Filled.ContentCopy) { Actions.copy(it, e.text) },
        )
        EntityType.EMAIL -> listOf(
            EntityAction("Écrire un e-mail", Icons.Filled.Email) { Actions.email(it, e.value, title) },
            EntityAction("Créer un contact (avec les infos de la note)", Icons.Filled.PersonAdd) {
                Actions.addContact(it, contactName, firstOf(EntityType.PHONE), e.value, firstOf(EntityType.ADDRESS), content)
            },
            EntityAction("Copier l'adresse e-mail", Icons.Filled.ContentCopy) { Actions.copy(it, e.value) },
        )
        EntityType.ADDRESS -> listOf(
            EntityAction("Voir sur la carte", Icons.Filled.Map) { Actions.showOnMap(it, e.value) },
            EntityAction("Itinéraire Google Maps", Icons.Filled.Directions) { Actions.directions(it, e.value) },
            EntityAction("Itinéraire Waze", Icons.Filled.Navigation) { Actions.waze(it, e.value) },
            EntityAction("Ajouter à un contact", Icons.Filled.PersonAdd) {
                Actions.addContact(it, contactName, firstOf(EntityType.PHONE), firstOf(EntityType.EMAIL), e.value, content)
            },
            EntityAction("Copier l'adresse", Icons.Filled.ContentCopy) { Actions.copy(it, e.value) },
        )
        EntityType.DATE -> buildList {
            val t = e.timeMillis ?: return@buildList
            add(EntityAction("Ajouter à l'agenda Calepin (avec rappel)", Icons.Filled.EventAvailable) { onCalepinEvent(e, false) })
            add(EntityAction("Programmer une alarme qui sonne", Icons.Filled.Alarm) { onCalepinEvent(e, true) })
            add(EntityAction("Ajouter à l'agenda du téléphone", Icons.Filled.Today) {
                Actions.addEvent(it, title, content, t, e.hasTime, firstOf(EntityType.ADDRESS), e.endMillis)
            })
            add(EntityAction("Ouvrir l'agenda à cette date", Icons.Filled.CalendarMonth) { Actions.openCalendarAt(it, t) })
            if (Actions.canSetAlarm(t, e.hasTime)) {
                add(EntityAction("Régler le réveil du téléphone", Icons.Filled.AccessAlarm) { Actions.setAlarm(it, t, title) })
            }
            add(EntityAction("Copier la date", Icons.Filled.ContentCopy) { Actions.copy(it, e.value) })
        }
        EntityType.URL -> listOf(
            EntityAction("Ouvrir le lien", Icons.Filled.Language) { Actions.openUrl(it, e.value) },
            EntityAction("Copier le lien", Icons.Filled.ContentCopy) { Actions.copy(it, e.value) },
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun EntitySheet(
    entity: Entity,
    all: List<Entity>,
    noteTitle: String,
    noteContent: String,
    onDismiss: () -> Unit,
    onCalepinEvent: (Entity, Boolean) -> Unit,
) {
    val ctx = LocalContext.current
    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(Modifier.padding(bottom = 24.dp)) {
            ListItem(
                overlineContent = { Text(entity.type.label) },
                headlineContent = {
                    Text(
                        if (entity.type == EntityType.DATE) entity.value else entity.text,
                        style = MaterialTheme.typography.titleMedium,
                    )
                },
                supportingContent = when {
                    entity.type == EntityType.DATE -> {
                        { Text("Écrit « ${entity.text} »") }
                    }
                    entity.country != null -> {
                        { Text(entity.country) }
                    }
                    else -> null
                },
                leadingContent = { Icon(entity.type.icon(), contentDescription = null, tint = MaterialTheme.colorScheme.primary) },
            )
            HorizontalDivider()
            actionsFor(entity, all, noteTitle, noteContent, onCalepinEvent).forEach { a ->
                ListItem(
                    headlineContent = { Text(a.label) },
                    leadingContent = { Icon(a.icon, contentDescription = null) },
                    modifier = Modifier.clickable {
                        a.run(ctx)
                        onDismiss()
                    },
                )
            }
        }
    }
}
