package fr.jeremy.calepin.care

import android.Manifest
import android.annotation.SuppressLint
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.location.LocationManager
import android.os.Build
import androidx.core.content.ContextCompat
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

/** Rappel qui se déclenche en arrivant dans un lieu (« quand j'arrive chez Marc, rappelle-moi… »). */
data class PlaceReminder(
    val id: String = UUID.randomUUID().toString(),
    val text: String,
    val place: String,
    val lat: Double,
    val lon: Double,
    val radius: Float = 200f,
    /** Vrai : à chaque arrivée ; faux : une seule fois puis supprimé. */
    val always: Boolean = false,
) {
    fun toJson(): JSONObject = JSONObject().put("id", id).put("text", text).put("place", place).put("lat", lat).put("lon", lon)
        .put("radius", radius.toDouble()).put("always", always)

    companion object {
        fun fromJson(o: JSONObject) = PlaceReminder(
            o.optString("id"), o.optString("text"), o.optString("place"), o.optDouble("lat"), o.optDouble("lon"),
            o.optDouble("radius", 200.0).toFloat(), o.optBoolean("always"),
        )
    }
}

/**
 * Rappels par lieu, avec les alertes de proximité d'Android (sans service Google).
 * Pour fonctionner appli fermée, Android demande l'autorisation de localisation « Toujours ».
 */
object PlaceReminders {
    private fun p(ctx: Context) = ctx.applicationContext.getSharedPreferences("calepin_places", Context.MODE_PRIVATE)

    fun all(ctx: Context): List<PlaceReminder> = runCatching {
        val a = JSONArray(p(ctx).getString("list", "[]"))
        (0 until a.length()).map { PlaceReminder.fromJson(a.getJSONObject(it)) }
    }.getOrDefault(emptyList())

    private fun save(ctx: Context, l: List<PlaceReminder>) {
        p(ctx).edit().putString("list", JSONArray().apply { l.forEach { put(it.toJson()) } }.toString()).apply()
    }

    fun hasPermission(ctx: Context) =
        ContextCompat.checkSelfPermission(ctx, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED

    fun hasBackground(ctx: Context) = Build.VERSION.SDK_INT < 29 ||
        ContextCompat.checkSelfPermission(ctx, Manifest.permission.ACCESS_BACKGROUND_LOCATION) == PackageManager.PERMISSION_GRANTED

    private fun pending(ctx: Context, r: PlaceReminder): PendingIntent = PendingIntent.getBroadcast(
        ctx, 7400 + (r.id.hashCode() and 0xFFF),
        Intent(ctx, CareReceiver::class.java).setAction(Care.ACTION_PLACE).putExtra("place", r.id),
        // Modifiable : Android y ajoute « entrée / sortie »
        PendingIntent.FLAG_UPDATE_CURRENT or (if (Build.VERSION.SDK_INT >= 31) PendingIntent.FLAG_MUTABLE else 0),
    )

    @SuppressLint("MissingPermission")
    private fun register(ctx: Context, r: PlaceReminder) {
        if (!hasPermission(ctx)) return
        val lm = ctx.getSystemService(LocationManager::class.java) ?: return
        runCatching { lm.addProximityAlert(r.lat, r.lon, r.radius, -1, pending(ctx, r)) }
    }

    private fun unregister(ctx: Context, r: PlaceReminder) {
        val lm = ctx.getSystemService(LocationManager::class.java) ?: return
        runCatching { lm.removeProximityAlert(pending(ctx, r)) }
    }

    fun registerAll(ctx: Context) = all(ctx).forEach { register(ctx, it) }

    fun add(ctx: Context, r: PlaceReminder) {
        save(ctx, all(ctx) + r)
        register(ctx, r)
    }

    fun remove(ctx: Context, id: String) {
        all(ctx).firstOrNull { it.id == id }?.let { unregister(ctx, it) }
        save(ctx, all(ctx).filter { it.id != id })
    }

    fun onProximity(ctx: Context, intent: Intent) {
        if (!intent.getBooleanExtra(LocationManager.KEY_PROXIMITY_ENTERING, false)) return
        val r = all(ctx).firstOrNull { it.id == intent.getStringExtra("place") } ?: return
        Care.notify(ctx, 7500 + (r.id.hashCode() and 0xFF), fr.jeremy.calepin.i18n.I18n.trf("Arrivé : {0}", r.place), r.text)
        if (!r.always) remove(ctx, r.id)
    }
}
