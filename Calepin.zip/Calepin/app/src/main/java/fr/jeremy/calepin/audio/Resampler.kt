package fr.jeremy.calepin.audio

/** Rééchantillonnage linéaire en continu (ex. 44 100 Hz → 16 000 Hz), morceau par morceau. */
class Resampler(private val inRate: Int, private val outRate: Int) {
    private val step = inRate.toDouble() / outRate
    private var pos = 0.0          // position du prochain échantillon de sortie, relative au début du bloc courant
    private var prev: Short = 0    // dernier échantillon du bloc précédent (index -1)

    fun process(input: ShortArray, n: Int): ShortArray {
        if (inRate == outRate) return input.copyOf(n)
        if (n == 0) return ShortArray(0)
        val out = ShortArray(((n - pos) / step).toInt() + 2)
        var count = 0
        while (pos < n - 1 + 1e-9) {
            val i = kotlin.math.floor(pos).toInt()
            val frac = pos - i
            val a = if (i < 0) prev.toDouble() else input[i].toDouble()
            val b = if (i + 1 < n) input[i + 1].toDouble() else input[n - 1].toDouble()
            if (count < out.size) out[count++] = (a + (b - a) * frac).toInt().toShort()
            pos += step
        }
        pos -= n
        prev = input[n - 1]
        return out.copyOf(count)
    }
}
