package fr.jeremy.calepin.audio

import java.io.Closeable
import java.io.OutputStream

/** Encodeur MP3 (Shine, code natif). Recevoir du PCM 16 bits entrelacé, écrire du MP3. */
class Mp3Encoder(sampleRate: Int, private val channels: Int, bitrateKbps: Int, private val out: OutputStream) : Closeable {

    private val handle: Long = nativeInit(sampleRate, channels, bitrateKbps)
    private val frame: ShortArray
    private var filled = 0

    init {
        require(handle != 0L) { "Configuration MP3 non prise en charge ($sampleRate Hz, $bitrateKbps kb/s)" }
        frame = ShortArray(nativeSamplesPerPass(handle) * channels)
    }

    /** Ajoute [count] échantillons ; l'encodage se fait par blocs complets. */
    fun write(pcm: ShortArray, count: Int) {
        var i = 0
        while (i < count) {
            val n = minOf(frame.size - filled, count - i)
            System.arraycopy(pcm, i, frame, filled, n)
            filled += n
            i += n
            if (filled == frame.size) {
                out.write(nativeEncode(handle, frame))
                filled = 0
            }
        }
    }

    override fun close() {
        if (filled > 0) {
            java.util.Arrays.fill(frame, filled, frame.size, 0.toShort())
            out.write(nativeEncode(handle, frame))
            filled = 0
        }
        out.write(nativeFlush(handle))
        nativeClose(handle)
        out.close()
    }

    companion object {
        init {
            System.loadLibrary("calepinmp3")
        }

        @JvmStatic private external fun nativeInit(sampleRate: Int, channels: Int, bitrate: Int): Long
        @JvmStatic private external fun nativeSamplesPerPass(h: Long): Int
        @JvmStatic private external fun nativeEncode(h: Long, pcm: ShortArray): ByteArray
        @JvmStatic private external fun nativeFlush(h: Long): ByteArray
        @JvmStatic private external fun nativeClose(h: Long)
    }
}
