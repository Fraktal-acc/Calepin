package fr.jeremy.calepin.market

import java.util.Locale
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/** Sens d'un trade de scalping : achat ou vente à découvert. */
enum class ScalpSide(val label: String) { LONG("Achat"), SHORT("Vente à découvert") }

/**
 * Que faire maintenant :
 * ENTER : entrer tout de suite (au cours) ; PREPARE : une configuration se forme, entrer si le cours franchit [ScalpSignal.entry] ;
 * WAIT : rien de net ; NO_TRADE : conditions défavorables (marché fermé, trop calme, mouvement brutal).
 */
enum class ScalpState { ENTER, PREPARE, WAIT, NO_TRADE }

/** Résultat de l'assistant de scalping sur la dernière bougie d'une minute clôturée. */
data class ScalpSignal(
    val state: ScalpState,
    val side: ScalpSide?,
    /** Force du signal (0 à 100). */
    val strength: Int,
    val price: Double,
    /** Prix d'entrée (au cours pour ENTER, prix de déclenchement pour PREPARE). */
    val entry: Double,
    val stop: Double,
    val target1: Double,
    val target2: Double,
    val rr: Double,
    /** Configurations reconnues (« Rebond sur Fibonacci 61,8 % », « Cassure du plus haut 20 min »…). */
    val setups: List<String>,
    /** Ce qui plaide pour ce sens. */
    val reasons: List<String>,
    /** Ce qui freine ou met en garde. */
    val warnings: List<String>,
    /** Heure (secondes) de la bougie clôturée analysée. */
    val candleTime: Long,
    /** Tendance de fond sur 5 minutes : +1 haussière, -1 baissière, 0 sans direction. */
    val trend5: Int,
    val atr: Double,
    val vwap: Double,
    val rsi: Double,
    /** Niveaux à tracer : Fibonacci, VWAP, entrée, stop, objectifs. */
    val levels: List<Level>,
    val longScore: Double,
    val shortScore: Double,
)

/** Ce qu'auraient donné les signaux « entrer » de l'assistant sur l'historique (objectif 1 ou stop). */
data class ScalpBacktest(val trades: Int, val wins: Int, val avgR: Double, val totalR: Double) {
    val winRate: Double get() = if (trades > 0) wins * 100.0 / trades else Double.NaN
}

/**
 * Assistant de scalping sur bougies d'une minute : tendance sur 5 minutes, moyennes exponentielles 9 / 21 / 50,
 * VWAP de la séance, Fibonacci du dernier mouvement, RSI 7, stochastique, MACD, Bollinger, cassures avec volume
 * et figures de bougies. Dit quand entrer (achat ou vente à découvert), où placer le stop et les objectifs.
 * Calculs purs, sans réseau.
 */
object Scalper {
    /** Nombre minimal de bougies d'une minute clôturées. */
    const val MIN_CANDLES = 60

    private fun f(x: Double, d: Int) = String.format(Locale.FRANCE, "%.${d}f", x)
    private fun dec(p: Double) = when { abs(p) < 2 -> 5; abs(p) < 20 -> 4; abs(p) < 1000 -> 2; else -> 1 }

    /** Bougies clôturées : la dernière est retirée si elle est encore en cours (moins d'une minute). */
    fun closed(c: List<Candle>, nowSec: Long): List<Candle> =
        if (c.isNotEmpty() && nowSec - c.last().t < 60) c.dropLast(1) else c

    /** Indicateurs calculés une fois pour toute la série (tous n'utilisent que le passé de chaque bougie). */
    private class Ctx(val c: List<Candle>) {
        val n = c.size
        val close = c.map { it.c }
        val ema9 = Indicators.ema(close, 9)
        val ema21 = Indicators.ema(close, 21)
        val ema50 = Indicators.ema(close, 50)
        val rsi = Indicators.rsi(close, 7)
        val stK = Indicators.stochastic(c, 14)
        val stD = Indicators.sma(stK.map { if (it.isNaN()) 50.0 else it }, 3)
        val macdHist = Indicators.macd(close).third
        val boll = Indicators.bollinger(close, 20, 2.0)
        val atr = Indicators.atr(c, 14)
        val volAvg = Indicators.sma(c.map { it.v }, 20)
        val hasVolume = c.takeLast(30).count { it.v > 0 } >= 20
        val vwap: List<Double>
        /** Tendance 5 minutes à chaque bougie, calculée sur les tranches de 5 minutes déjà terminées. */
        val trend5: IntArray

        init {
            // VWAP depuis le début de la séance (nouvelle séance après une pause de plus de 30 minutes)
            val vw = MutableList(n) { Double.NaN }
            var pv = 0.0; var vv = 0.0; var tpSum = 0.0; var cnt = 0
            for (i in 0 until n) {
                if (i == 0 || c[i].t - c[i - 1].t > 1800) { pv = 0.0; vv = 0.0; tpSum = 0.0; cnt = 0 }
                val tp = (c[i].h + c[i].l + c[i].c) / 3
                pv += tp * c[i].v; vv += c[i].v; tpSum += tp; cnt++
                // Sans volumes (devises, indices) : moyenne des cours typiques de la séance
                vw[i] = if (hasVolume && vv > 0) pv / vv else tpSum / cnt
            }
            vwap = vw
            val m5 = Indicators.aggregate(c, 300)
            val m5c = m5.map { it.c }
            val e20 = Indicators.ema(m5c, 20)
            val e50 = Indicators.ema(m5c, if (m5.size >= 60) 50 else 30)
            // Structure de la tendance : EMA 20 au-dessus de l'EMA 50 et qui monte (ou l'inverse) ; un repli ne l'efface pas
            val bucketTrend = IntArray(m5.size) { k ->
                val a = e20[k]; val b = e50[k]
                val ap = if (k >= 3) e20[k - 3] else Double.NaN
                when {
                    a.isNaN() || b.isNaN() || ap.isNaN() -> 0
                    a > b && a > ap -> 1
                    a < b && a < ap -> -1
                    else -> 0
                }
            }
            val idx = HashMap<Long, Int>(m5.size * 2)
            m5.forEachIndexed { k, x -> idx[x.t] = k }
            trend5 = IntArray(n) { i ->
                // Tranche précédente (terminée) : pas d'information venant du futur
                val k = idx[Math.floorDiv(c[i].t, 300L) * 300L] ?: return@IntArray 0
                if (k >= 1) bucketTrend[k - 1] else 0
            }
        }
    }

    private class Fib(val up: Boolean, val hi: Double, val lo: Double) {
        val range = hi - lo
        fun ret(r: Double) = if (up) hi - range * r else lo + range * r
        fun ext(r: Double) = if (up) lo + range * r else hi - range * r
    }

    /**
     * Dernier mouvement net (au moins 3 ATR) pour les niveaux de Fibonacci. [up] : mouvement haussier (du creux au
     * sommet de la dernière heure) pour un achat sur repli ; sinon baissier (du sommet au creux) pour une vente sur rebond.
     */
    private fun fibAt(x: Ctx, i: Int, atr: Double, up: Boolean): Fib? {
        val from = max(0, i - 60)
        if (i - from < 20) return null
        // Extrême de la dernière heure, puis point de départ du mouvement dans l'heure et demie qui précède
        var ex = from
        for (k in from..i) if (if (up) x.c[k].h > x.c[ex].h else x.c[k].l < x.c[ex].l) ex = k
        if (i - ex > 40 || ex == from) return null
        var st = max(0, ex - 90)
        for (k in max(0, ex - 90)..ex) if (if (up) x.c[k].l < x.c[st].l else x.c[k].h > x.c[st].h) st = k
        val hi = if (up) x.c[ex].h else x.c[st].h
        val lo = if (up) x.c[st].l else x.c[ex].l
        if (hi - lo < 3 * atr || st == ex) return null
        return Fib(up, hi, lo)
    }

    private class Eval(
        val score: Double,
        val setups: List<String>,
        val reasons: List<String>,
        val warnings: List<String>,
        /** Déclencheur sur la dernière bougie (pas seulement un contexte favorable). */
        val trigger: Boolean,
        /** Configuration en formation (repli en cours dans la zone de Fibonacci…). */
        val forming: Boolean,
        val stop: Double,
        val t1: Double,
        val t2: Double,
    )

    /** Note d'un sens à la bougie [i]. */
    private fun side(x: Ctx, i: Int, long: Boolean, fib: Fib?): Eval {
        val c = x.c
        val k = c[i]
        val p = k.c
        val a = x.atr[i]
        val sg = if (long) 1.0 else -1.0
        var s = 0.0
        val setups = ArrayList<String>()
        val reasons = ArrayList<String>()
        val warns = ArrayList<String>()
        var trigger = false
        var forming = false
        fun above(u: Double, v: Double) = if (long) u > v else u < v
        val word = if (long) "haussière" else "baissière"

        // 1. Tendance de fond sur 5 minutes
        val tr = x.trend5[i] * sg.toInt()
        when {
            tr > 0 -> { s += 20; reasons += "Tendance $word sur 5 minutes" }
            tr < 0 -> { s -= 25; warns += "À contre-tendance sur 5 minutes" }
        }
        // 2. Moyennes exponentielles alignées
        if (above(x.ema9[i], x.ema21[i]) && above(x.ema21[i], x.ema50[i])) { s += 10; reasons += "EMA 9 / 21 / 50 alignées" }
        // 3. Position par rapport au VWAP
        val vw = x.vwap[i]
        if (!vw.isNaN()) {
            if (above(p, vw)) { s += 10; reasons += (if (long) "Au-dessus" else "Sous") + " du VWAP (" + f(vw, dec(p)) + ")" }
            else s -= 8
            // Reprise du VWAP sur la dernière bougie
            if (i > 0 && !above(c[i - 1].c, x.vwap[i - 1]) && above(p, vw)) { s += 12; trigger = true; setups += "Reprise du VWAP" }
        }
        // 4. Croisement EMA 9 / 21 récent
        fun crossAt(j: Int) = j >= 1 && !above(x.ema9[j - 1], x.ema21[j - 1]) && above(x.ema9[j], x.ema21[j])
        // Sur la dernière bougie ou la précédente (et toujours dans le bon sens)
        val crossed = (crossAt(i) || crossAt(i - 1)) && above(x.ema9[i], x.ema21[i])
        if (crossed) { s += 15; trigger = true; setups += "Croisement EMA 9 / 21" }
        // 5. Rebond (ou rejet) sur Fibonacci dans le sens du mouvement
        if (fib != null && fib.up == long) {
            val z1 = fib.ret(0.382); val z2 = fib.ret(0.786)
            val lo5 = (max(0, i - 4)..i).minOf { c[it].l }
            val hi5 = (max(0, i - 4)..i).maxOf { c[it].h }
            val touched = if (long) lo5 <= z1 && lo5 >= z2 - 0.2 * a else hi5 >= z1 && hi5 <= z2 + 0.2 * a
            val bodyOk = if (long) k.c > k.o else k.c < k.o
            val level = listOf(0.382, 0.5, 0.618).minBy { r -> abs((if (long) lo5 else hi5) - fib.ret(r)) }
            if (touched && bodyOk && above(p, x.ema9[i])) {
                s += 25; trigger = true
                setups += (if (long) "Rebond sur Fibonacci " else "Rejet sous Fibonacci ") + f(level * 100, 1).removeSuffix(",0") + " %"
            } else if (touched || (if (long) p <= z1 && p >= z2 else p >= z1 && p <= z2)) {
                s += 10; forming = true
                reasons += "Repli dans la zone de Fibonacci 38,2 – 78,6 %"
            }
        }
        // 6. Cassure du plus haut (ou plus bas) des 20 dernières minutes
        if (i >= 21) {
            val prevHi = (i - 20 until i).maxOf { c[it].h }
            val prevLo = (i - 20 until i).minOf { c[it].l }
            val broke = if (long) p > prevHi else p < prevLo
            val volOk = if (x.hasVolume) !x.volAvg[i].isNaN() && k.v > 1.5 * x.volAvg[i] else (k.h - k.l) > 1.2 * a
            if (broke && volOk) { s += 20; trigger = true; setups += if (long) "Cassure du plus haut 20 min" else "Cassure du plus bas 20 min" }
            else if (broke) { s += 8; reasons += (if (long) "Nouveau plus haut" else "Nouveau plus bas") + " 20 min (sans volume)" }
            // Tout près du niveau : cassure possible
            val near = if (long) prevHi - p in 0.0..0.3 * a else p - prevLo in 0.0..0.3 * a
            if (!broke && near && tr > 0) forming = true
        }
        // 7. Élan : RSI 7, stochastique, MACD
        val r = x.rsi[i]; val rp = x.rsi[i - 1]
        if (!r.isNaN() && !rp.isNaN()) {
            if (above(r, 50.0) && !above(rp, 50.0)) { s += 8; reasons += "RSI 7 repasse " + (if (long) "au-dessus" else "sous") + " de 50" }
            if (long && r > 82 || !long && r < 18) { s -= 15; warns += "RSI 7 à " + f(r, 0) + " : mouvement déjà étiré" }
        }
        val kk = x.stK[i]; val dd = x.stD[i]; val kp = x.stK[i - 1]; val dp = x.stD[i - 1]
        if (!kk.isNaN() && !kp.isNaN()) {
            val cross = above(kk, dd) && !above(kp, dp)
            val zone = if (long) kp < 30 else kp > 70
            if (cross && zone) { s += 8; trigger = true; setups += "Stochastique qui repart " + if (long) "de la survente" else "du surachat" }
        }
        val h = x.macdHist[i]; val hp = x.macdHist[i - 1]
        if (!h.isNaN() && !hp.isNaN()) {
            if (above(h, 0.0) && !above(hp, 0.0)) { s += 6; reasons += "MACD qui change de signe" }
            else if (above(h, hp) && above(h, 0.0)) s += 3
        }
        // 8. Bollinger : rebond sur la bande opposée dans le sens de la tendance, ou sortie d'un resserrement
        val (lo, mid, hi) = x.boll
        if (!lo[i].isNaN()) {
            val band = if (long) lo[i] else hi[i]
            val touchedBand = if (long) k.l <= band else k.h >= band
            if (touchedBand && above(p, band) && tr >= 0 && (if (long) k.c > k.o else k.c < k.o)) {
                s += 8; trigger = true; setups += "Rebond sur la bande de Bollinger"
            }
            val widths = (max(20, i - 60)..i).mapNotNull { j -> if (lo[j].isNaN()) null else (hi[j] - lo[j]) / mid[j] }
            val squeeze = widths.size > 20 && widths.sorted()[widths.size / 5] >= ((hi[i - 1] - lo[i - 1]) / mid[i - 1])
            if (squeeze && (if (long) p > hi[i] else p < lo[i])) { s += 10; trigger = true; setups += "Sortie de resserrement de Bollinger" }
        }
        // 9. Figures de bougies
        val prev = c[i - 1]
        val body = abs(k.c - k.o)
        val engulf = if (long) k.c > k.o && prev.c < prev.o && k.c >= prev.o && k.o <= prev.c
        else k.c < k.o && prev.c > prev.o && k.c <= prev.o && k.o >= prev.c
        if (engulf && body > 0.5 * a) { s += 8; reasons += if (long) "Avalement haussier" else "Avalement baissier" }
        val wick = if (long) min(k.o, k.c) - k.l else k.h - max(k.o, k.c)
        if (wick > 2 * body && wick > 0.6 * a) { s += 6; reasons += if (long) "Mèche basse (rejet des vendeurs)" else "Mèche haute (rejet des acheteurs)" }
        // Prudence
        if (abs(p - x.ema21[i]) > 2.2 * a) { s -= 15; warns += "Loin de l'EMA 21 : entrer maintenant, c'est courir après le prix" }
        if (k.h - k.l > 3.5 * a) { s -= 10; warns += "Bougie très ample : actualité ou ordre important, prudence" }

        // Stop et objectifs : derrière le dernier creux (ou sommet), entre 0,6 et 2,5 ATR
        val swing = if (long) (max(0, i - 5)..i).minOf { c[it].l } else (max(0, i - 5)..i).maxOf { c[it].h }
        var stop = if (long) swing - 0.2 * a else swing + 0.2 * a
        if (fib != null && fib.up == long && setups.any { it.contains("Fibonacci") }) {
            val f786 = fib.ret(0.786)
            stop = if (long) min(stop, f786 - 0.2 * a) else max(stop, f786 + 0.2 * a)
        }
        var risk = abs(p - stop).coerceIn(0.6 * a, 2.5 * a)
        if (risk <= 0) risk = a
        stop = p - sg * risk
        var t1 = p + sg * 1.5 * risk
        // Le sommet (ou creux) du mouvement s'il laisse au moins 1 fois le risque
        if (fib != null && fib.up == long) {
            val end = if (long) fib.hi else fib.lo
            if ((end - p) * sg >= risk) t1 = end
        }
        var t2 = p + sg * 2.5 * risk
        if (fib != null && fib.up == long) {
            val e = fib.ext(1.272)
            if ((e - t1) * sg > 0) t2 = if ((e - t2) * sg > 0) t2 else e
        }
        if ((t2 - t1) * sg <= 0) t2 = t1 + sg * risk
        return Eval(s, setups, reasons, warns, trigger, forming, stop, t1, t2)
    }

    /** Signal à la bougie clôturée [i] (avec les indicateurs déjà calculés). */
    private fun at(x: Ctx, i: Int, price: Double): ScalpSignal {
        val k = x.c[i]
        val a = x.atr[i].takeIf { !it.isNaN() && it > 0 } ?: (k.h - k.l).coerceAtLeast(price * 0.0005)
        val fibUp = fibAt(x, i, a, true)
        val fibDown = fibAt(x, i, a, false)
        val L = side(x, i, true, fibUp)
        val S = side(x, i, false, fibDown)
        val warn = ArrayList<String>()
        // Marché trop calme : les frais mangeraient le gain
        if (a / price * 100 < 0.012) warn += "Marché très calme (ATR ${f(a / price * 100, 3)} %) : les frais et l'écart peuvent manger le gain"
        val best = if (L.score >= S.score) L else S
        val other = if (best === L) S else L
        val long = best === L
        val strength = best.score.coerceIn(0.0, 100.0)
        val clear = best.score - other.score >= 15
        val rr = abs(best.t1 - price) / abs(price - best.stop).coerceAtLeast(1e-12)
        var state = when {
            strength >= 55 && clear && best.trigger && rr >= 1.2 -> ScalpState.ENTER
            strength >= 40 && clear && (best.forming || best.trigger) -> ScalpState.PREPARE
            else -> ScalpState.WAIT
        }
        if (warn.isNotEmpty() && state == ScalpState.ENTER) state = ScalpState.PREPARE
        val side = if (state == ScalpState.WAIT && strength < 30) null else if (long) ScalpSide.LONG else ScalpSide.SHORT
        // Entrée : au cours (ENTER) ou au-delà de la bougie qui vient de clôturer (PREPARE)
        val entry = when (state) {
            ScalpState.PREPARE -> if (long) max(k.h, price) else min(k.l, price)
            else -> price
        }
        val shift = entry - price
        val stop = best.stop + shift
        val t1 = best.t1 + shift
        val t2 = best.t2 + shift
        val levels = ArrayList<Level>()
        val fib = if (long) fibUp ?: fibDown else fibDown ?: fibUp
        if (fib != null) {
            listOf(0.382, 0.5, 0.618, 0.786).forEach { r -> levels += Level(fib.ret(r), "Fibo " + f(r * 100, 1).removeSuffix(",0") + " %") }
            levels += Level(fib.ext(1.272), "Extension 127,2 %")
        }
        if (!x.vwap[i].isNaN()) levels += Level(x.vwap[i], "VWAP")
        if (side != null && state != ScalpState.WAIT) {
            levels += Level(entry, "Entrée")
            levels += Level(stop, "Stop")
            levels += Level(t1, "Objectif 1")
            levels += Level(t2, "Objectif 2")
        }
        return ScalpSignal(
            state = state, side = side, strength = strength.toInt(), price = price, entry = entry,
            stop = stop, target1 = t1, target2 = t2,
            rr = abs(t1 - entry) / abs(entry - stop).coerceAtLeast(1e-12),
            setups = best.setups, reasons = best.reasons, warnings = warn + best.warnings,
            candleTime = k.t, trend5 = x.trend5[i], atr = a, vwap = x.vwap[i], rsi = x.rsi[i],
            levels = levels, longScore = L.score, shortScore = S.score,
        )
    }

    /**
     * Signal sur la dernière bougie d'une minute clôturée. [c] : bougies d'une minute (la dernière peut être en cours),
     * [price] : dernier cours (par défaut la dernière clôture). Null s'il n'y a pas assez d'historique.
     */
    fun analyze(c: List<Candle>, nowSec: Long, price: Double = c.lastOrNull()?.c ?: Double.NaN): ScalpSignal? {
        val done = closed(c, nowSec)
        if (done.size < MIN_CANDLES || price.isNaN() || price <= 0) return null
        val x = Ctx(done)
        val sig = at(x, done.size - 1, price)
        // Marché fermé : la dernière bougie a plus de 10 minutes
        if (nowSec - done.last().t > 600) {
            return sig.copy(state = ScalpState.NO_TRADE, warnings = listOf("Pas de nouvelle bougie depuis " + ((nowSec - done.last().t) / 60) + " min : marché fermé ou cours en pause") + sig.warnings)
        }
        return sig
    }

    /**
     * Contrôle sur l'historique : à chaque signal « entrer », entrée à la clôture, sortie à l'objectif 1 (gain)
     * ou au stop (perte), sur 30 minutes au plus ; un seul trade à la fois.
     */
    fun backtest(c: List<Candle>, nowSec: Long): ScalpBacktest {
        val done = closed(c, nowSec)
        if (done.size < MIN_CANDLES + 20) return ScalpBacktest(0, 0, 0.0, 0.0)
        val x = Ctx(done)
        var trades = 0; var wins = 0; var total = 0.0
        var i = MIN_CANDLES
        while (i < done.size - 2) {
            // Pas de signal à travers une pause de séance
            if (done[i].t - done[i - 1].t > 1800) { i++; continue }
            val s = at(x, i, done[i].c)
            if (s.state != ScalpState.ENTER || s.side == null) { i++; continue }
            val long = s.side == ScalpSide.LONG
            var j = i + 1
            var r = Double.NaN
            while (j < done.size && j <= i + 30) {
                val k = done[j]
                if (k.t - done[j - 1].t > 1800) break
                val hitStop = if (long) k.l <= s.stop else k.h >= s.stop
                val hitT1 = if (long) k.h >= s.target1 else k.l <= s.target1
                if (hitStop) { r = -1.0; break }
                if (hitT1) { r = s.rr; break }
                j++
            }
            if (r.isNaN()) {
                // Ni stop ni objectif : sortie au cours atteint
                val last = done[min(j, done.size - 1)].c
                r = (if (long) last - s.entry else s.entry - last) / abs(s.entry - s.stop).coerceAtLeast(1e-12)
            }
            trades++
            if (r > 0) wins++
            total += r
            i = max(j, i + 1)
        }
        return ScalpBacktest(trades, wins, if (trades > 0) total / trades else 0.0, total)
    }

    /** Une position ouverte depuis l'assistant : que faire maintenant. */
    data class Advice(val text: String, val exit: Boolean, val pnlPct: Double, val r: Double, val reachedT1: Boolean)

    fun follow(side: ScalpSide, entry: Double, stop: Double, t1: Double, t2: Double, price: Double, sig: ScalpSignal?): Advice {
        val long = side == ScalpSide.LONG
        val pnl = (if (long) price - entry else entry - price) / entry * 100
        val risk = abs(entry - stop).coerceAtLeast(1e-12)
        val r = (if (long) price - entry else entry - price) / risk
        val hitStop = if (long) price <= stop else price >= stop
        val hitT2 = if (long) price >= t2 else price <= t2
        val hitT1 = if (long) price >= t1 else price <= t1
        val against = sig != null && sig.state == ScalpState.ENTER && sig.side != null && sig.side != side
        return when {
            hitStop -> Advice("Stop touché : sors maintenant.", true, pnl, r, false)
            hitT2 -> Advice("Objectif 2 atteint : prends tes gains.", true, pnl, r, true)
            against -> Advice("Signal contraire : sors (ou resserre ton stop au plus près).", true, pnl, r, hitT1)
            hitT1 -> Advice("Objectif 1 atteint : sécurise une partie et remonte le stop au prix d'entrée.", false, pnl, r, true)
            r >= 0.8 -> Advice("En bonne voie : stop à remonter au prix d'entrée.", false, pnl, r, false)
            r <= -0.6 -> Advice("Le cours se rapproche du stop : ne l'élargis pas.", false, pnl, r, false)
            else -> Advice("Position en cours : garde le plan (stop et objectifs).", false, pnl, r, false)
        }
    }
}
