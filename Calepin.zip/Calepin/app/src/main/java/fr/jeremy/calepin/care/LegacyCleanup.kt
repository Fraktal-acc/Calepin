package fr.jeremy.calepin.care

import android.content.Context
import java.io.File

/** Ménage après le retrait de fonctions : fait une seule fois par fonction retirée. */
object LegacyCleanup {
    fun run(ctx: Context) {
        val app = ctx.applicationContext
        val flags = app.getSharedPreferences("calepin_cleanup", Context.MODE_PRIVATE)
        // Autres langues retirées : modules vocaux et choix de langue
        if (!flags.getBoolean("languages_removed", false)) {
            listOf("en", "it", "es", "de").forEach { l ->
                runCatching { File(app.filesDir, "vosk-$l").deleteRecursively() }
                runCatching { File(app.cacheDir, "vosk-$l.zip").delete() }
            }
            runCatching { app.getSharedPreferences("calepin_settings", Context.MODE_PRIVATE).edit().remove("language").apply() }
            flags.edit().putBoolean("languages_removed", true).apply()
        }
        messages(app, flags)
        market(app, flags)
        weather(app, flags)
    }

    /** Météo retirée : prévisions et lieu gardés sur le téléphone effacés. */
    private fun weather(app: Context, flags: android.content.SharedPreferences) {
        if (flags.getBoolean("weather_removed", false)) return
        runCatching { app.getSharedPreferences("calepin_weather", Context.MODE_PRIVATE).edit().clear().commit() }
        runCatching { app.deleteSharedPreferences("calepin_weather") }
        flags.edit().putBoolean("weather_removed", true).apply()
    }

    /** Bourse retirée (robot, opportunités, scalping) : tâches, alarmes, notifications et réglages effacés. */
    private fun market(app: Context, flags: android.content.SharedPreferences) {
        if (flags.getBoolean("market_removed", false)) return
        runCatching {
            val js = app.getSystemService(android.app.job.JobScheduler::class.java)
            listOf(7300, 7310).forEach { js?.cancel(it) }
        }
        runCatching {
            val i = android.content.Intent().setClassName(app, "fr.jeremy.calepin.market.MarketAlarmReceiver")
            val pi = android.app.PendingIntent.getBroadcast(app, 7300, i, android.app.PendingIntent.FLAG_NO_CREATE or android.app.PendingIntent.FLAG_IMMUTABLE)
            if (pi != null) { app.getSystemService(android.app.AlarmManager::class.java)?.cancel(pi); pi.cancel() }
        }
        runCatching {
            val nm = app.getSystemService(android.app.NotificationManager::class.java)
            listOf("calepin_bourse", "calepin_scalping").forEach { nm?.deleteNotificationChannel(it) }
        }
        listOf("market", "market_scan", "market_scalp").forEach { name ->
            runCatching { app.getSharedPreferences(name, Context.MODE_PRIVATE).edit().clear().commit() }
            runCatching { app.deleteSharedPreferences(name) }
        }
        flags.edit().putBoolean("market_removed", true).apply()
    }

    /**
     * Menu Messages (mails et SMS) retiré : on efface ce qu'il gardait sur le téléphone
     * (adresses et mots de passe des boîtes mail, mails suivis, pièces jointes en cache, clé de chiffrement).
     */
    private fun messages(app: Context, flags: android.content.SharedPreferences) {
        if (flags.getBoolean("messages_removed", false)) return
        listOf("calepin_mail", "calepin_mail_contacts", "calepin_messages", "calepin_chat_sync").forEach { name ->
            runCatching { app.getSharedPreferences(name, Context.MODE_PRIVATE).edit().clear().commit() }
            runCatching { app.deleteSharedPreferences(name) }
        }
        runCatching { File(app.filesDir, "messages.json").delete() }
        runCatching { File(app.filesDir, "msg_media").deleteRecursively() }
        runCatching { File(app.cacheDir, "mail").deleteRecursively() }
        runCatching { File(app.cacheDir, "chat_import").deleteRecursively() }
        runCatching {
            val ks = java.security.KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
            if (ks.containsAlias("calepin_mail_key")) ks.deleteEntry("calepin_mail_key")
        }
        flags.edit().putBoolean("messages_removed", true).apply()
    }
}
