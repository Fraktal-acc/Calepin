package fr.jeremy.calepin.control;

import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.math.BigInteger;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.security.KeyFactory;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.KeyStore;
import java.security.MessageDigest;
import java.security.PrivateKey;
import java.security.SecureRandom;
import java.security.Signature;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import java.security.interfaces.RSAPublicKey;
import java.security.spec.PKCS8EncodedKeySpec;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.TimeZone;

import javax.net.ssl.KeyManagerFactory;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSocket;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

/**
 * Télécommande réseau « Android TV Remote v2 », celle de l'appli Google TV :
 * téléviseurs et boîtiers Android TV / Google TV (Sony, Philips, TCL, Xiaomi, Freebox Pop, Bbox 4K, Chromecast…).
 *
 * Appairage sur le port 6467 (code à 6 caractères affiché sur la télé), puis commandes sur le port 6466.
 * Les messages sont de petits « protobuf » encodés ici à la main, préfixés par leur longueur.
 * Toutes les méthodes sont bloquantes : à appeler hors du fil principal.
 */
public final class AndroidTvRemote {

    public static final int PAIR_PORT = 6467;
    public static final int REMOTE_PORT = 6466;
    /** PING | KEY | POWER | VOLUME | APP_LINK */
    private static final int FEATURES = 1 | 2 | 32 | 64 | 512;

    // Codes de touches Android
    public static final int KEY_HOME = 3, KEY_BACK = 4, KEY_0 = 7, KEY_UP = 19, KEY_DOWN = 20, KEY_LEFT = 21,
            KEY_RIGHT = 22, KEY_CENTER = 23, KEY_VOLUME_UP = 24, KEY_VOLUME_DOWN = 25, KEY_POWER = 26,
            KEY_PLAY_PAUSE = 85, KEY_MUTE = 164, KEY_CHANNEL_UP = 166, KEY_CHANNEL_DOWN = 167, KEY_TV_INPUT = 178,
            KEY_SLEEP = 223, KEY_WAKEUP = 224, KEY_GUIDE = 172;

    /** Identité du téléphone auprès de la télé : clé privée (PKCS#8) et certificat (DER), en Base64. */
    public static final class Identity {
        public final String privateKey;
        public final String certificate;

        public Identity(String privateKey, String certificate) {
            this.privateKey = privateKey;
            this.certificate = certificate;
        }
    }

    private final String host;
    private final Identity identity;
    private SSLSocket pairSocket;

    public AndroidTvRemote(String host, Identity identity) {
        this.host = host;
        this.identity = identity;
    }

    // ------------------------------------------------------------------ Identité (certificat auto-signé)

    public static Identity newIdentity(String commonName) throws Exception {
        KeyPairGenerator g = KeyPairGenerator.getInstance("RSA");
        g.initialize(2048, new SecureRandom());
        KeyPair kp = g.generateKeyPair();
        byte[] cert = selfSignedCertificate(kp, commonName);
        Base64.Encoder b64 = Base64.getEncoder();
        return new Identity(b64.encodeToString(kp.getPrivate().getEncoded()), b64.encodeToString(cert));
    }

    /** Certificat X.509 v3 minimal, signé SHA256withRSA, valable jusqu'en 2049. */
    static byte[] selfSignedCertificate(KeyPair kp, String cn) throws Exception {
        byte[] algId = seq(oid(new int[]{1, 2, 840, 113549, 1, 1, 11}), new byte[]{0x05, 0x00});
        byte[] name = seq(set(seq(oid(new int[]{2, 5, 4, 3}), tlv(0x0C, cn.getBytes(StandardCharsets.UTF_8)))));
        SimpleDateFormat f = new SimpleDateFormat("yyMMddHHmmss'Z'", Locale.US);
        f.setTimeZone(TimeZone.getTimeZone("UTC"));
        byte[] notBefore = tlv(0x17, f.format(new Date(System.currentTimeMillis() - 86_400_000L)).getBytes(StandardCharsets.US_ASCII));
        byte[] notAfter = tlv(0x17, "491231235959Z".getBytes(StandardCharsets.US_ASCII));
        byte[] version = tlv(0xA0, tlv(0x02, new byte[]{0x02}));
        byte[] serial = tlv(0x02, BigInteger.valueOf(System.currentTimeMillis()).toByteArray());
        byte[] tbs = seq(version, serial, algId, name, seq(notBefore, notAfter), name, kp.getPublic().getEncoded());
        Signature s = Signature.getInstance("SHA256withRSA");
        s.initSign(kp.getPrivate());
        s.update(tbs);
        byte[] sig = s.sign();
        byte[] bitString = new byte[sig.length + 1];
        System.arraycopy(sig, 0, bitString, 1, sig.length);
        return seq(tbs, algId, tlv(0x03, bitString));
    }

    private static byte[] tlv(int tag, byte[] value) {
        ByteArrayOutputStream o = new ByteArrayOutputStream();
        o.write(tag);
        int len = value.length;
        if (len < 128) {
            o.write(len);
        } else {
            byte[] l = BigInteger.valueOf(len).toByteArray();
            int start = l[0] == 0 ? 1 : 0;
            o.write(0x80 | (l.length - start));
            o.write(l, start, l.length - start);
        }
        o.write(value, 0, value.length);
        return o.toByteArray();
    }

    private static byte[] concat(byte[]... parts) {
        ByteArrayOutputStream o = new ByteArrayOutputStream();
        for (byte[] p : parts) o.write(p, 0, p.length);
        return o.toByteArray();
    }

    private static byte[] seq(byte[]... parts) {
        return tlv(0x30, concat(parts));
    }

    private static byte[] set(byte[]... parts) {
        return tlv(0x31, concat(parts));
    }

    private static byte[] oid(int[] arcs) {
        ByteArrayOutputStream o = new ByteArrayOutputStream();
        o.write(arcs[0] * 40 + arcs[1]);
        for (int i = 2; i < arcs.length; i++) {
            int v = arcs[i];
            byte[] tmp = new byte[5];
            int n = 0;
            do {
                tmp[n++] = (byte) (v & 0x7F);
                v >>>= 7;
            } while (v != 0);
            for (int j = n - 1; j >= 0; j--) o.write(tmp[j] | (j > 0 ? 0x80 : 0));
        }
        return tlv(0x06, o.toByteArray());
    }

    // ------------------------------------------------------------------ TLS

    private X509Certificate clientCert() throws Exception {
        byte[] der = Base64.getDecoder().decode(identity.certificate);
        return (X509Certificate) CertificateFactory.getInstance("X.509").generateCertificate(new java.io.ByteArrayInputStream(der));
    }

    private SSLSocket connect(int port, int timeoutMs) throws Exception {
        PrivateKey key = KeyFactory.getInstance("RSA").generatePrivate(new PKCS8EncodedKeySpec(Base64.getDecoder().decode(identity.privateKey)));
        char[] pass = "calepin".toCharArray();
        KeyStore ks = KeyStore.getInstance("PKCS12");
        ks.load(null, null);
        ks.setKeyEntry("client", key, pass, new java.security.cert.Certificate[]{clientCert()});
        KeyManagerFactory kmf = KeyManagerFactory.getInstance(KeyManagerFactory.getDefaultAlgorithm());
        kmf.init(ks, pass);
        // La télé présente un certificat auto-signé : on l'accepte (réseau local uniquement)
        TrustManager[] trustAll = new TrustManager[]{new X509TrustManager() {
            @Override public void checkClientTrusted(X509Certificate[] chain, String authType) { }
            @Override public void checkServerTrusted(X509Certificate[] chain, String authType) { }
            @Override public X509Certificate[] getAcceptedIssuers() { return new X509Certificate[0]; }
        }};
        SSLContext ctx = SSLContext.getInstance("TLS");
        ctx.init(kmf.getKeyManagers(), trustAll, new SecureRandom());
        Socket raw = new Socket();
        raw.connect(new InetSocketAddress(host, port), timeoutMs);
        raw.setSoTimeout(8000);
        SSLSocket s = (SSLSocket) ctx.getSocketFactory().createSocket(raw, host, port, true);
        s.setUseClientMode(true);
        s.startHandshake();
        return s;
    }

    /** Vrai si un service Android TV écoute à cette adresse (test rapide, sans appairage). */
    public static boolean probe(String host) {
        try (Socket s = new Socket()) {
            s.connect(new InetSocketAddress(host, REMOTE_PORT), 400);
            return true;
        } catch (IOException e) {
            return false;
        }
    }

    // ------------------------------------------------------------------ Protobuf minimal

    static final class Pb {
        private final ByteArrayOutputStream o = new ByteArrayOutputStream();

        Pb varint(int field, long v) {
            writeVarint((field << 3));
            writeVarint(v);
            return this;
        }

        Pb bytes(int field, byte[] b) {
            writeVarint((field << 3) | 2);
            writeVarint(b.length);
            o.write(b, 0, b.length);
            return this;
        }

        Pb str(int field, String s) {
            return bytes(field, s.getBytes(StandardCharsets.UTF_8));
        }

        Pb msg(int field, Pb m) {
            return bytes(field, m.build());
        }

        byte[] build() {
            return o.toByteArray();
        }

        private void writeVarint(long v) {
            while ((v & ~0x7FL) != 0) {
                o.write((int) ((v & 0x7F) | 0x80));
                v >>>= 7;
            }
            o.write((int) v);
        }
    }

    /** Champs d'un message protobuf : numéro → valeur (Long pour les entiers, byte[] pour le reste). */
    static List<Object[]> parse(byte[] b) {
        List<Object[]> out = new ArrayList<>();
        int i = 0;
        while (i < b.length) {
            long[] r = readVarint(b, i);
            int key = (int) r[0];
            i = (int) r[1];
            int field = key >>> 3, wire = key & 7;
            if (wire == 0) {
                long[] v = readVarint(b, i);
                i = (int) v[1];
                out.add(new Object[]{field, v[0]});
            } else if (wire == 2) {
                long[] len = readVarint(b, i);
                i = (int) len[1];
                byte[] v = new byte[(int) len[0]];
                System.arraycopy(b, i, v, 0, v.length);
                i += v.length;
                out.add(new Object[]{field, v});
            } else if (wire == 5) {
                i += 4;
            } else if (wire == 1) {
                i += 8;
            } else {
                break;
            }
        }
        return out;
    }

    static Object field(List<Object[]> fields, int n) {
        for (Object[] f : fields) if ((Integer) f[0] == n) return f[1];
        return null;
    }

    private static long[] readVarint(byte[] b, int i) {
        long v = 0;
        int shift = 0;
        while (i < b.length) {
            int x = b[i++] & 0xFF;
            v |= (long) (x & 0x7F) << shift;
            if ((x & 0x80) == 0) break;
            shift += 7;
        }
        return new long[]{v, i};
    }

    private static void send(OutputStream out, byte[] msg) throws IOException {
        ByteArrayOutputStream o = new ByteArrayOutputStream();
        long v = msg.length;
        while ((v & ~0x7FL) != 0) {
            o.write((int) ((v & 0x7F) | 0x80));
            v >>>= 7;
        }
        o.write((int) v);
        o.write(msg, 0, msg.length);
        out.write(o.toByteArray());
        out.flush();
    }

    private static byte[] receive(InputStream in) throws IOException {
        long len = 0;
        int shift = 0;
        while (true) {
            int x = in.read();
            if (x < 0) throw new IOException("connexion fermée par la télé");
            len |= (long) (x & 0x7F) << shift;
            if ((x & 0x80) == 0) break;
            shift += 7;
        }
        byte[] buf = new byte[(int) len];
        new DataInputStream(in).readFully(buf);
        return buf;
    }

    // ------------------------------------------------------------------ Appairage

    private static Pb outer() {
        return new Pb().varint(1, 2).varint(2, 200);
    }

    private static Pb encoding() {
        return new Pb().varint(1, 3).varint(2, 6); // hexadécimal, 6 caractères
    }

    /** Étape 1 : la télé affiche un code à 6 caractères. Garder cet objet pour l'étape 2. */
    public void startPairing(String clientName) throws Exception {
        startPairingAt(PAIR_PORT, clientName);
    }

    void startPairingAt(int port, String clientName) throws Exception {
        pairSocket = connect(port, 4000);
        pairSocket.setSoTimeout(15000);
        OutputStream out = pairSocket.getOutputStream();
        InputStream in = pairSocket.getInputStream();
        send(out, outer().msg(10, new Pb().str(1, "atvremote").str(2, clientName)).build());
        while (true) {
            List<Object[]> m = parse(receive(in));
            Object status = field(m, 2);
            if (status != null && (Long) status != 200L) throw new IOException("la télé a refusé l'appairage (" + status + ")");
            if (field(m, 11) != null) {
                send(out, outer().msg(20, new Pb().msg(1, encoding()).varint(3, 1)).build());
            } else if (field(m, 20) != null) {
                send(out, outer().msg(30, new Pb().msg(1, encoding()).varint(2, 1)).build());
            } else if (field(m, 31) != null) {
                return; // le code est affiché sur la télé
            }
        }
    }

    /** Étape 2 : envoie le code lu sur la télé. */
    public void finishPairing(String code) throws Exception {
        String c = code.trim().toUpperCase(Locale.ROOT);
        if (pairSocket == null) throw new IllegalStateException("appairage non commencé");
        if (c.length() != 6) throw new IllegalArgumentException("le code doit faire 6 caractères");
        RSAPublicKey client = (RSAPublicKey) clientCert().getPublicKey();
        RSAPublicKey server = (RSAPublicKey) ((X509Certificate) pairSocket.getSession().getPeerCertificates()[0]).getPublicKey();
        MessageDigest h = MessageDigest.getInstance("SHA-256");
        h.update(unsigned(client.getModulus()));
        h.update(unsigned(client.getPublicExponent()));
        h.update(unsigned(server.getModulus()));
        h.update(unsigned(server.getPublicExponent()));
        h.update(hex(c.substring(2)));
        byte[] secret = h.digest();
        if ((secret[0] & 0xFF) != Integer.parseInt(c.substring(0, 2), 16)) {
            throw new IllegalArgumentException("code incorrect");
        }
        try {
            OutputStream out = pairSocket.getOutputStream();
            InputStream in = pairSocket.getInputStream();
            send(out, outer().msg(40, new Pb().bytes(1, secret)).build());
            while (true) {
                List<Object[]> m = parse(receive(in));
                Object status = field(m, 2);
                if (status != null && (Long) status != 200L) throw new IOException("code refusé par la télé (" + status + ")");
                if (field(m, 41) != null) return;
            }
        } finally {
            closePairing();
        }
    }

    public void closePairing() {
        try {
            if (pairSocket != null) pairSocket.close();
        } catch (IOException ignored) {
        }
        pairSocket = null;
    }

    static byte[] unsigned(BigInteger v) {
        byte[] b = v.toByteArray();
        if (b.length > 1 && b[0] == 0) {
            byte[] t = new byte[b.length - 1];
            System.arraycopy(b, 1, t, 0, t.length);
            return t;
        }
        return b;
    }

    static byte[] hex(String s) {
        byte[] out = new byte[s.length() / 2];
        for (int i = 0; i < out.length; i++) out[i] = (byte) Integer.parseInt(s.substring(i * 2, i * 2 + 2), 16);
        return out;
    }

    // ------------------------------------------------------------------ Commandes

    /** Résultat d'une session : état d'allumage annoncé par la télé (null si inconnu). */
    public static final class Session {
        public Boolean isOn;
    }

    /**
     * Se connecte, attend que la télé soit prête, puis envoie les touches ([keys], dans l'ordre)
     * et éventuellement un lien d'appli ([appLink]). [keys] peut être vide pour seulement lire l'état.
     */
    public Session run(int[] keys, String appLink, long delayBetweenKeysMs) throws Exception {
        return runAt(REMOTE_PORT, keys, appLink, delayBetweenKeysMs);
    }

    Session runAt(int port, int[] keys, String appLink, long delayBetweenKeysMs) throws Exception {
        Session session = new Session();
        try (SSLSocket s = connect(port, 4000)) {
            OutputStream out = s.getOutputStream();
            InputStream in = s.getInputStream();
            long deadline = System.currentTimeMillis() + 6000;
            boolean ready = false;
            while (!ready && System.currentTimeMillis() < deadline) {
                List<Object[]> m = parse(receive(in));
                if (field(m, 1) != null) {
                    Pb info = new Pb().varint(3, 1).str(4, "1").str(5, "atvremote").str(6, "1.0.0");
                    send(out, new Pb().msg(1, new Pb().varint(1, FEATURES).msg(2, info)).build());
                } else if (field(m, 2) != null) {
                    send(out, new Pb().msg(2, new Pb().varint(1, FEATURES)).build());
                } else if (field(m, 8) != null) {
                    Object v = field(parse((byte[]) field(m, 8)), 1);
                    send(out, new Pb().msg(9, new Pb().varint(1, v == null ? 0 : (Long) v)).build());
                } else if (field(m, 40) != null) {
                    Object started = field(parse((byte[]) field(m, 40)), 1);
                    session.isOn = started != null && (Long) started != 0L;
                    ready = true;
                }
            }
            if (!ready) throw new IOException("la télé n'a pas répondu à temps");
            for (int k : keys) {
                send(out, new Pb().msg(10, new Pb().varint(1, k).varint(2, 3)).build());
                if (delayBetweenKeysMs > 0) Thread.sleep(delayBetweenKeysMs);
            }
            if (appLink != null && !appLink.isEmpty()) {
                send(out, new Pb().msg(90, new Pb().str(1, appLink)).build());
            }
            Thread.sleep(300);
        }
        return session;
    }

    // ------------------------------------------------------------------ Connexion permanente (télécommande)

    /** Connexion gardée ouverte : chaque touche part immédiatement. Répond seul aux « ping » de la télé. */
    public final class Live implements AutoCloseable {
        private SSLSocket socket;
        private OutputStream out;
        private volatile boolean ready;
        private volatile Boolean on;
        private Thread reader;

        public Live open() throws Exception {
            return openAt(REMOTE_PORT);
        }

        Live openAt(int port) throws Exception {
            socket = connect(port, 4000);
            socket.setSoTimeout(0);
            out = socket.getOutputStream();
            final InputStream in = socket.getInputStream();
            final Object lock = this;
            reader = new Thread(() -> {
                try {
                    while (!socket.isClosed()) {
                        List<Object[]> m = parse(receive(in));
                        if (field(m, 1) != null) {
                            Pb info = new Pb().varint(3, 1).str(4, "1").str(5, "atvremote").str(6, "1.0.0");
                            write(new Pb().msg(1, new Pb().varint(1, FEATURES).msg(2, info)).build());
                        } else if (field(m, 2) != null) {
                            write(new Pb().msg(2, new Pb().varint(1, FEATURES)).build());
                        } else if (field(m, 8) != null) {
                            Object v = field(parse((byte[]) field(m, 8)), 1);
                            write(new Pb().msg(9, new Pb().varint(1, v == null ? 0 : (Long) v)).build());
                        } else if (field(m, 40) != null) {
                            Object started = field(parse((byte[]) field(m, 40)), 1);
                            on = started != null && (Long) started != 0L;
                            synchronized (lock) {
                                ready = true;
                                lock.notifyAll();
                            }
                        }
                    }
                } catch (Exception ignored) {
                } finally {
                    ready = false;
                    synchronized (lock) {
                        lock.notifyAll();
                    }
                }
            }, "atv-remote");
            reader.setDaemon(true);
            reader.start();
            long end = System.currentTimeMillis() + 6000;
            synchronized (lock) {
                while (!ready && !socket.isClosed() && System.currentTimeMillis() < end && reader.isAlive()) {
                    lock.wait(Math.max(1, end - System.currentTimeMillis()));
                }
            }
            if (!ready) {
                close();
                throw new IOException("la télé n'a pas répondu à temps");
            }
            return this;
        }

        private synchronized void write(byte[] msg) throws IOException {
            send(out, msg);
        }

        public boolean isReady() {
            return ready && socket != null && !socket.isClosed();
        }

        /** État d'allumage annoncé par la télé (null si inconnu). */
        public Boolean isOn() {
            return on;
        }

        public void key(int code) throws IOException {
            write(new Pb().msg(10, new Pb().varint(1, code).varint(2, 3)).build());
        }

        public void appLink(String link) throws IOException {
            write(new Pb().msg(90, new Pb().str(1, link)).build());
        }

        @Override
        public void close() {
            ready = false;
            try {
                if (socket != null) socket.close();
            } catch (IOException ignored) {
            }
        }
    }
}
