package fr.jeremy.calepin.control

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.Inet4Address
import java.net.NetworkInterface
import java.net.URL

/** Réglages de la maison (adresses sur le Wi-Fi), gardés sur le téléphone. */
class HomeConfig(ctx: Context) {
    private val p = ctx.getSharedPreferences("calepin_home", Context.MODE_PRIVATE)

    var decoderIp: String
        get() = p.getString("decoder_ip", "") ?: ""
        set(v) = p.edit().putString("decoder_ip", v.trim()).apply()
    var braviaIp: String
        get() = p.getString("bravia_ip", "") ?: ""
        set(v) = p.edit().putString("bravia_ip", v.trim()).apply()
    var braviaPsk: String
        get() = p.getString("bravia_psk", "") ?: ""
        set(v) = p.edit().putString("bravia_psk", v.trim()).apply()
    var braviaMac: String
        get() = p.getString("bravia_mac", "") ?: ""
        set(v) = p.edit().putString("bravia_mac", v.trim()).apply()

    fun decoder(): OrangeDecoder? = decoderIp.takeIf { it.isNotBlank() }?.let { OrangeDecoder(it) }
    fun bravia(): BraviaTv? = braviaIp.takeIf { it.isNotBlank() }?.let { BraviaTv(it, braviaPsk, braviaMac) }
}

/** Petites requêtes HTTP sur le réseau local (sans bibliothèque externe). */
internal object Http {
    fun get(url: String, timeoutMs: Int = 3000, connectMs: Int = timeoutMs): String? = request(url, null, emptyMap(), timeoutMs, connectMs)

    fun post(url: String, body: String, headers: Map<String, String>, timeoutMs: Int = 4000, connectMs: Int = timeoutMs): String? =
        request(url, body, headers, timeoutMs, connectMs)

    private fun request(url: String, body: String?, headers: Map<String, String>, timeoutMs: Int, connectMs: Int): String? = try {
        val c = (URL(url).openConnection() as HttpURLConnection).apply {
            connectTimeout = connectMs
            readTimeout = timeoutMs
            useCaches = false
            headers.forEach { (k, v) -> setRequestProperty(k, v) }
            if (body != null) {
                requestMethod = "POST"
                doOutput = true
            }
        }
        try {
            if (body != null) c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            val stream = if (c.responseCode in 200..299) c.inputStream else c.errorStream
            stream?.use { it.readBytes().toString(Charsets.UTF_8) } ?: ""
        } finally {
            c.disconnect()
        }
    } catch (e: Exception) {
        null
    }
}

/** Recherche du décodeur Orange et du téléviseur Sony sur le Wi-Fi de la maison. */
object LanScanner {
    data class Found(val decoders: List<String>, val bravias: List<String>)

    /** Adresse IPv4 du téléphone sur le Wi-Fi (ex. 192.168.1.23), ou null hors réseau local. */
    fun localIp(): String? = runCatching {
        NetworkInterface.getNetworkInterfaces().toList()
            .filter { it.isUp && !it.isLoopback }
            .sortedBy { if (it.name.startsWith("wlan")) 0 else 1 }
            .flatMap { it.inetAddresses.toList() }
            .filterIsInstance<Inet4Address>()
            .firstOrNull { it.isSiteLocalAddress }?.hostAddress
    }.getOrNull()

    suspend fun scan(onProgress: (Int) -> Unit = {}): Found = withContext(Dispatchers.IO) {
        val ip = localIp() ?: return@withContext Found(emptyList(), emptyList())
        val prefix = ip.substringBeforeLast('.')
        val gate = Semaphore(48)
        var done = 0
        val results = coroutineScope {
            (1..254).map { i ->
                async {
                    gate.withPermit {
                        val host = "$prefix.$i"
                        val dec = OrangeDecoder.probe(host)
                        val tv = if (dec) false else BraviaTv.probe(host)
                        synchronized(this@LanScanner) { done++; onProgress(done * 100 / 254) }
                        Triple(host, dec, tv)
                    }
                }
            }.awaitAll()
        }
        Found(results.filter { it.second }.map { it.first }, results.filter { it.third }.map { it.first })
    }
}

internal fun JSONObject.firstResult(): JSONObject? = optJSONArray("result")?.let { arr ->
    when (val first = arr.opt(0)) {
        is JSONObject -> first
        is org.json.JSONArray -> first.optJSONObject(0)
        else -> null
    }
}
