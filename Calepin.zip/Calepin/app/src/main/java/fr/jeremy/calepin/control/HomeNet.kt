package fr.jeremy.calepin.control

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.Inet4Address
import java.net.NetworkInterface
import java.net.URL

/** Réglages de la maison (adresses sur le Wi-Fi), gardés sur le téléphone. */
class HomeConfig(ctx: Context) {
    private val p = ctx.getSharedPreferences("calepin_home", Context.MODE_PRIVATE)

    var decoderIp: String
        get() = p.getString("decoder_ip", "") ?: ""
        set(v) = p.edit().putString("decoder_ip", v.trim()).apply()
    var braviaIp: String
        get() = p.getString("bravia_ip", "") ?: ""
        set(v) = p.edit().putString("bravia_ip", v.trim()).apply()
    var braviaPsk: String
        get() = p.getString("bravia_psk", "") ?: ""
        set(v) = p.edit().putString("bravia_psk", v.trim()).apply()
    var braviaMac: String
        get() = p.getString("bravia_mac", "") ?: ""
        set(v) = p.edit().putString("bravia_mac", v.trim()).apply()

    fun decoder(): OrangeDecoder? = decoderIp.takeIf { it.isNotBlank() }?.let { OrangeDecoder(it) }
    fun bravia(): BraviaTv? = braviaIp.takeIf { it.isNotBlank() }?.let { BraviaTv(it, braviaPsk, braviaMac) }
}

/**
 * Réseau Wi-Fi de la maison. Quand le Wi-Fi est faible, Android (« Passer aux données mobiles » sur Samsung)
 * peut envoyer les requêtes par la 4G/5G : le décodeur et la télé, qui ne sont que sur le Wi-Fi, deviennent
 * alors injoignables. Les requêtes vers les adresses locales passent donc toujours par le Wi-Fi.
 * Garde aussi l'adresse matérielle (MAC) des décodeurs, pour les réveiller à distance.
 */
object LanNet {
    @Volatile private var wifi: android.net.Network? = null
    @Volatile private var prefs: android.content.SharedPreferences? = null

    fun init(ctx: Context) {
        val app = ctx.applicationContext
        prefs = app.getSharedPreferences("calepin_lan", Context.MODE_PRIVATE)
        runCatching {
            val cm = app.getSystemService(android.net.ConnectivityManager::class.java) ?: return
            val req = android.net.NetworkRequest.Builder().addTransportType(android.net.NetworkCapabilities.TRANSPORT_WIFI).build()
            cm.registerNetworkCallback(req, object : android.net.ConnectivityManager.NetworkCallback() {
                override fun onAvailable(network: android.net.Network) { wifi = network }
                override fun onLost(network: android.net.Network) { if (wifi == network) wifi = null }
            })
        }
    }

    /** Réseau Wi-Fi à utiliser pour joindre [host] (adresse locale), ou null (réseau par défaut). */
    fun wifiFor(host: String): android.net.Network? {
        val w = wifi ?: return null
        val local = host.endsWith(".local") || host.startsWith("192.168.") || host.startsWith("10.") ||
            Regex("^172\\.(1[6-9]|2\\d|3[01])\\.").containsMatchIn(host) || host.startsWith("169.254.")
        return if (local) w else null
    }

    /** Socket UDP envoyée par le Wi-Fi (réveil à distance). */
    fun bindUdp(socket: java.net.DatagramSocket) { runCatching { wifi?.bindSocket(socket) } }

    fun rememberMac(host: String, mac: String) {
        if (mac.replace(":", "").length == 12) prefs?.edit()?.putString("mac_$host", mac)?.putString("mac_last_decoder", mac)?.apply()
    }

    fun macFor(host: String): String? = prefs?.getString("mac_$host", null) ?: prefs?.getString("mac_last_decoder", null)
}

/** Petites requêtes HTTP sur le réseau local (sans bibliothèque externe). */
internal object Http {
    fun get(url: String, timeoutMs: Int = 3000, connectMs: Int = timeoutMs): String? = request(url, null, emptyMap(), timeoutMs, connectMs)

    /** GET avec en-têtes (jeton d'accès…). */
    fun get2(url: String, headers: Map<String, String>, timeoutMs: Int = 4000): String? = request(url, null, headers, timeoutMs, timeoutMs)

    fun post(url: String, body: String, headers: Map<String, String>, timeoutMs: Int = 4000, connectMs: Int = timeoutMs): String? =
        request(url, body, headers, timeoutMs, connectMs)

    private fun request(url: String, body: String?, headers: Map<String, String>, timeoutMs: Int, connectMs: Int): String? = try {
        val u = URL(url)
        // Appareils de la maison : toujours par le Wi-Fi, même si le téléphone est passé sur les données mobiles
        val wifi = LanNet.wifiFor(u.host)
        val c = ((wifi?.openConnection(u) ?: u.openConnection()) as HttpURLConnection).apply {
            connectTimeout = connectMs
            readTimeout = timeoutMs
            useCaches = false
            headers.forEach { (k, v) -> setRequestProperty(k, v) }
            if (body != null) {
                requestMethod = "POST"
                doOutput = true
            }
        }
        try {
            if (body != null) c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            val stream = if (c.responseCode in 200..299) c.inputStream else c.errorStream
            stream?.use { it.readBytes().toString(Charsets.UTF_8) } ?: ""
        } finally {
            c.disconnect()
        }
    } catch (e: Exception) {
        null
    }
}

/** Recherche du décodeur Orange et du téléviseur Sony sur le Wi-Fi de la maison. */
object LanScanner {
    data class Found(val decoders: List<String>, val bravias: List<String>)

    /** Adresse IPv4 du téléphone sur le Wi-Fi (ex. 192.168.1.23), ou null hors réseau local. */
    fun localIp(): String? = runCatching {
        NetworkInterface.getNetworkInterfaces().toList()
            .filter { it.isUp && !it.isLoopback }
            .sortedBy { if (it.name.startsWith("wlan")) 0 else 1 }
            .flatMap { it.inetAddresses.toList() }
            .filterIsInstance<Inet4Address>()
            .firstOrNull { it.isSiteLocalAddress }?.hostAddress
    }.getOrNull()

    suspend fun scan(onProgress: (Int) -> Unit = {}): Found = withContext(Dispatchers.IO) {
        val ip = localIp() ?: return@withContext Found(emptyList(), emptyList())
        val prefix = ip.substringBeforeLast('.')
        val gate = Semaphore(48)
        var done = 0
        val results = coroutineScope {
            (1..254).map { i ->
                async {
                    gate.withPermit {
                        val host = "$prefix.$i"
                        val dec = OrangeDecoder.probe(host)
                        val tv = if (dec) false else BraviaTv.probe(host)
                        synchronized(this@LanScanner) { done++; onProgress(done * 100 / 254) }
                        Triple(host, dec, tv)
                    }
                }
            }.awaitAll()
        }
        Found(results.filter { it.second }.map { it.first }, results.filter { it.third }.map { it.first })
    }
}

internal fun JSONObject.firstResult(): JSONObject? = optJSONArray("result")?.let { arr ->
    when (val first = arr.opt(0)) {
        is JSONObject -> first
        is org.json.JSONArray -> first.optJSONObject(0)
        else -> null
    }
}
