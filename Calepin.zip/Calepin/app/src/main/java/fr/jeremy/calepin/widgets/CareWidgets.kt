package fr.jeremy.calepin.widgets

import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.os.SystemClock
import android.view.View
import android.widget.RemoteViews
import fr.jeremy.calepin.R
import fr.jeremy.calepin.data.NoteDb
import fr.jeremy.calepin.i18n.I18n
import fr.jeremy.calepin.weather.WeatherCodes
import fr.jeremy.calepin.weather.WeatherRepo
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withTimeoutOrNull
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import kotlin.math.roundToInt

/** Météo du lieu choisi (ou de la position) : pictogramme, température, prévision du jour. */
class WeatherWidget : AppWidgetProvider() {
    override fun onUpdate(ctx: Context, mgr: AppWidgetManager, ids: IntArray) {
        I18n.init(ctx)
        val pending = goAsync()
        Thread {
            try {
                // Réseau : au plus 8 secondes (Android coupe le widget au-delà de 10)
                runCatching { runBlocking { withTimeoutOrNull(8_000L) { WeatherRepo.refresh(ctx) } } }
                WeatherRepo.loadCached(ctx)
                val f = WeatherRepo.forecast.value
                val v = RemoteViews(ctx.packageName, R.layout.widget_weather)
                Widgets.applyStyle(ctx, v, chips = emptyList(), texts = listOf(R.id.w_temp, R.id.w_place), subs = listOf(R.id.w_detail), icons = emptyList())
                if (f == null) {
                    v.setTextViewText(R.id.w_emoji, "🌡️")
                    v.setTextViewText(R.id.w_temp, "—")
                    v.setTextViewText(R.id.w_place, I18n.tr("Météo"))
                    v.setTextViewText(R.id.w_detail, I18n.tr("Touche pour choisir ta ville ou ta position."))
                } else {
                    v.setTextViewText(R.id.w_emoji, WeatherCodes.emoji(f.code, f.isDay))
                    v.setTextViewText(R.id.w_temp, "${f.temp.roundToInt()}°")
                    v.setTextViewText(R.id.w_place, f.place.name + " · " + I18n.tr(WeatherCodes.label(f.code)))
                    val d = f.days.firstOrNull()
                    val at = SimpleDateFormat(I18n.pattern("HH'h'mm"), I18n.locale).format(Date(f.fetchedAt))
                    v.setTextViewText(
                        R.id.w_detail,
                        (d?.let { I18n.trf("{0}° / {1}° · pluie {2} %", it.min.roundToInt(), it.max.roundToInt(), it.rain) + " · " } ?: "") + at,
                    )
                }
                v.setOnClickPendingIntent(R.id.w_root, Widgets.open(ctx, "weather", 501))
                ids.forEach { mgr.updateAppWidget(it, v) }
            } catch (e: Throwable) {
                fr.jeremy.calepin.care.CrashLog.note(ctx, "widget météo", e)
            } finally {
                pending.finish()
            }
        }.start()
    }
}

/** Prochaine vacation (ou fin de la vacation en cours) avec un compte à rebours. */
class ShiftWidget : AppWidgetProvider() {
    override fun onUpdate(ctx: Context, mgr: AppWidgetManager, ids: IntArray) {
        I18n.init(ctx)
        val pending = goAsync()
        Thread {
            try {
                val now = System.currentTimeMillis()
                val events = runCatching { NoteDb(ctx).events() }.getOrDefault(emptyList())
                val work = events.filter { it.isWork && !it.allDay && it.end > it.start }
                val current = work.filter { it.start <= now && it.end > now }.minByOrNull { it.end }
                val next = work.filter { it.start > now }.minByOrNull { it.start }
                val v = RemoteViews(ctx.packageName, R.layout.widget_shift)
                Widgets.applyStyle(ctx, v, chips = emptyList(), texts = listOf(R.id.w_title), subs = listOf(R.id.w_sub), icons = listOf(R.id.w_hicon))
                val st = Widgets.style(ctx)
                v.setTextColor(R.id.w_heading, st.icon)
                v.setTextColor(R.id.w_count, st.icon)
                val shown = current ?: next
                val day = SimpleDateFormat(I18n.pattern("EEEE d MMMM"), I18n.locale)
                val hm = SimpleDateFormat(I18n.pattern("HH'h'mm"), I18n.locale)
                if (shown == null) {
                    v.setTextViewText(R.id.w_heading, I18n.tr("Prochaine vacation"))
                    v.setTextViewText(R.id.w_title, I18n.tr("Aucune vacation prévue"))
                    v.setViewVisibility(R.id.w_count, View.GONE)
                    v.setTextViewText(R.id.w_sub, I18n.tr("Importe ton planning dans l'agenda."))
                } else {
                    v.setTextViewText(R.id.w_heading, I18n.tr(if (current != null) "En poste" else "Prochaine vacation"))
                    val today = Calendar.getInstance().get(Calendar.DAY_OF_YEAR)
                    val c = Calendar.getInstance().apply { timeInMillis = shown.start }
                    val dayLabel = when (c.get(Calendar.DAY_OF_YEAR) - today) {
                        0 -> I18n.tr("Aujourd'hui")
                        1 -> I18n.tr("Demain")
                        else -> day.format(Date(shown.start)).replaceFirstChar { it.uppercase() }
                    }
                    v.setTextViewText(R.id.w_title, dayLabel + " · " + hm.format(Date(shown.start)) + "–" + hm.format(Date(shown.end)))
                    val target = if (current != null) current.end else shown.start
                    v.setViewVisibility(R.id.w_count, View.VISIBLE)
                    v.setChronometer(R.id.w_count, SystemClock.elapsedRealtime() + (target - now), if (current != null) I18n.trf("Fin dans {0}", "%s") else I18n.trf("Dans {0}", "%s"), true)
                    v.setChronometerCountDown(R.id.w_count, true)
                    val wake = if (current == null) {
                        events.firstOrNull { it.category == fr.jeremy.calepin.care.WakeAlarm.CATEGORY && it.start > now && it.start <= shown.start }
                    } else null
                    v.setTextViewText(
                        R.id.w_sub,
                        wake?.let { I18n.trf("Réveil à {0}", hm.format(Date(it.start))) } ?: shown.title,
                    )
                }
                v.setOnClickPendingIntent(R.id.w_root, Widgets.open(ctx, "workhours", 601))
                ids.forEach { mgr.updateAppWidget(it, v) }
            } catch (e: Throwable) {
                fr.jeremy.calepin.care.CrashLog.note(ctx, "widget vacation", e)
            } finally {
                pending.finish()
            }
        }.start()
    }
}
