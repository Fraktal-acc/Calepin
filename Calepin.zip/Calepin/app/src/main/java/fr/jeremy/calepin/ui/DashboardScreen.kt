package fr.jeremy.calepin.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.EditNote
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Contacts
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.PushPin
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.SettingsRemote
import androidx.compose.material.icons.filled.SmartToy
import androidx.compose.material.icons.filled.SportsEsports
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import fr.jeremy.calepin.BuildConfig
import fr.jeremy.calepin.NotesViewModel
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/** Ce qu'on peut ouvrir depuis l'accueil. Les rubriques absentes (null) ne sont pas affichées. */
class DashboardActions(
    val onNotes: () -> Unit,
    val onNote: (Long) -> Unit,
    val onNewNote: () -> Unit,
    val onSearch: (String) -> Unit,
    val onCalendar: () -> Unit,
    val onContacts: () -> Unit,
    val onAssistant: () -> Unit,
    val onRemote: (() -> Unit)?,
    val onDevices: (() -> Unit)?,
    val onGames: () -> Unit,
    val onSettings: () -> Unit,
    val onAppearance: () -> Unit,
)

private class Tile(val label: String, val subtitle: String, val icon: ImageVector, val tone: Int, val onClick: () -> Unit)

@Composable
fun DashboardScreen(vm: NotesViewModel, a: DashboardActions) {
    val ctx = LocalContext.current
    val appearance = remember { Appearance.get(ctx) }
    val style by appearance.home.collectAsStateWithLifecycle()
    val total by vm.noteCount.collectAsStateWithLifecycle()
    val recent by vm.recentNotes.collectAsStateWithLifecycle()
    val events by vm.events.collectAsStateWithLifecycle()
    var query by remember { mutableStateOf("") }

    val now = System.currentTimeMillis()
    val upcoming = remember(events) {
        val endOfTomorrow = Calendar.getInstance().apply {
            add(Calendar.DAY_OF_YEAR, 1); set(Calendar.HOUR_OF_DAY, 23); set(Calendar.MINUTE, 59)
        }.timeInMillis
        events.filter { e -> (if (e.end > 0) e.end else e.start + 3_600_000) >= now && e.start <= endOfTomorrow }.sortedBy { it.start }.take(3)
    }

    val tiles = buildList {
        add(Tile("Notes", if (total == 0) "Aucune note" else "$total note${if (total > 1) "s" else ""}", Icons.Filled.EditNote, 0, a.onNotes))
        add(Tile("Agenda", if (upcoming.isEmpty()) "Rien de prévu" else "${upcoming.size} à venir", Icons.Filled.CalendarMonth, 1, a.onCalendar))
        add(Tile("Assistant", if (BuildConfig.AI) "Voix et IA" else "À la voix", Icons.Filled.SmartToy, 2, a.onAssistant))
        add(Tile("Contacts", "Téléphone", Icons.Filled.Contacts, 0, a.onContacts))
        a.onRemote?.let { add(Tile("Télécommande", "Télé et décodeur", Icons.Filled.SettingsRemote, 1, it)) }
        a.onDevices?.let { add(Tile("Maison", "Appareils connectés", Icons.Filled.Home, 2, it)) }
        add(Tile("Jeux", "Tetris, Snake…", Icons.Filled.SportsEsports, 0, a.onGames))
        add(Tile("Apparence", "Thèmes et couleurs", Icons.Filled.Palette, 1, a.onAppearance))
        add(Tile("Paramètres", "Réglages", Icons.Filled.Settings, 2, a.onSettings))
    }

    Scaffold(
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = a.onNewNote,
                icon = { Icon(Icons.Filled.Add, null) },
                text = { Text("Nouvelle note") },
            )
        },
    ) { pad ->
        Column(
            Modifier
                .fillMaxSize()
                .padding(pad)
                .verticalScroll(rememberScrollState())
                .statusBarsPadding()
                .padding(horizontal = 16.dp)
                .padding(top = 12.dp, bottom = 96.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            // En-tête : salutation et date
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    val hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
                    Text(
                        if (hour in 5..17) "Bonjour" else "Bonsoir",
                        style = MaterialTheme.typography.headlineMedium,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.primary,
                    )
                    Text(
                        SimpleDateFormat("EEEE d MMMM", Locale.FRANCE).format(Date()).replaceFirstChar { it.uppercase() } +
                            if (BuildConfig.AI) " · Calepin IA" else " · Calepin",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                Surface(shape = CircleShape, color = MaterialTheme.colorScheme.primaryContainer) {
                    IconButton(onClick = a.onAssistant) { Icon(Icons.Filled.Mic, "Parler à l'assistant", tint = MaterialTheme.colorScheme.onPrimaryContainer) }
                }
            }

            // Recherche dans les notes
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                modifier = Modifier.fillMaxWidth(),
                placeholder = { Text("Rechercher dans les notes") },
                leadingIcon = { Icon(Icons.Filled.Search, null) },
                singleLine = true,
                shape = MaterialTheme.shapes.extraLarge,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                keyboardActions = KeyboardActions(onSearch = { a.onSearch(query); query = "" }),
            )

            // Aujourd'hui
            Card(
                onClick = a.onCalendar,
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer),
                modifier = Modifier.fillMaxWidth(),
            ) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("Aujourd'hui et demain", style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.onSecondaryContainer)
                    if (upcoming.isEmpty()) {
                        Text("Rien de prévu. Profites-en !", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSecondaryContainer)
                    }
                    upcoming.forEach { e ->
                        val fmt = if (e.allDay) "EEE d" else "EEE d · HH'h'mm"
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                SimpleDateFormat(fmt, Locale.FRANCE).format(Date(e.start)),
                                style = MaterialTheme.typography.labelLarge,
                                color = MaterialTheme.colorScheme.onSecondaryContainer,
                                modifier = Modifier.width(110.dp),
                            )
                            Text(e.title, style = MaterialTheme.typography.bodyMedium, maxLines = 1, overflow = TextOverflow.Ellipsis, color = MaterialTheme.colorScheme.onSecondaryContainer)
                        }
                    }
                }
            }

            // Rubriques
            when (style) {
                HomeStyle.GRID -> tiles.chunked(2).forEach { row ->
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        row.forEach { t -> BigTile(t, Modifier.weight(1f)) }
                        if (row.size == 1) Spacer(Modifier.weight(1f))
                    }
                }
                HomeStyle.COMPACT -> tiles.chunked(4).forEach { row ->
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        row.forEach { t -> SmallTile(t, Modifier.weight(1f)) }
                        repeat(4 - row.size) { Spacer(Modifier.weight(1f)) }
                    }
                }
                HomeStyle.LIST -> Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLow)) {
                    tiles.forEach { t -> ListTile(t) }
                }
            }

            // Notes récentes
            if (recent.isNotEmpty()) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Notes récentes", style = MaterialTheme.typography.titleSmall, modifier = Modifier.weight(1f))
                    Text(
                        "Tout voir",
                        style = MaterialTheme.typography.labelLarge,
                        color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.clickable(onClick = a.onNotes).padding(6.dp),
                    )
                }
                recent.forEach { n ->
                    Card(
                        onClick = { a.onNote(n.id) },
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLow),
                        modifier = Modifier.fillMaxWidth(),
                    ) {
                        Row(Modifier.padding(horizontal = 14.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                            if (n.pinned) {
                                Icon(Icons.Filled.PushPin, "Épinglée", tint = MaterialTheme.colorScheme.secondary, modifier = Modifier.size(16.dp))
                                Spacer(Modifier.width(8.dp))
                            }
                            Column(Modifier.weight(1f)) {
                                Text(n.title.ifBlank { "Sans titre" }, style = MaterialTheme.typography.titleSmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                if (n.content.isNotBlank()) {
                                    Text(
                                        n.content.lineSequence().first { it.isNotBlank() },
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis,
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun toneColors(tone: Int): Pair<Color, Color> = when (tone % 3) {
    0 -> MaterialTheme.colorScheme.primaryContainer to MaterialTheme.colorScheme.onPrimaryContainer
    1 -> MaterialTheme.colorScheme.secondaryContainer to MaterialTheme.colorScheme.onSecondaryContainer
    else -> MaterialTheme.colorScheme.tertiaryContainer to MaterialTheme.colorScheme.onTertiaryContainer
}

@Composable
private fun BigTile(t: Tile, modifier: Modifier) {
    val (bg, fg) = toneColors(t.tone)
    Card(onClick = t.onClick, colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLow), modifier = modifier.height(116.dp)) {
        Column(Modifier.padding(14.dp).fillMaxSize(), verticalArrangement = Arrangement.SpaceBetween) {
            Surface(shape = MaterialTheme.shapes.medium, color = bg) {
                Box(Modifier.size(42.dp), contentAlignment = Alignment.Center) { Icon(t.icon, null, tint = fg) }
            }
            Column {
                Text(t.label, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold, maxLines = 1)
                Text(t.subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
        }
    }
}

@Composable
private fun SmallTile(t: Tile, modifier: Modifier) {
    val (bg, fg) = toneColors(t.tone)
    Column(
        modifier
            .clickable(onClick = t.onClick)
            .padding(vertical = 6.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        Surface(shape = MaterialTheme.shapes.large, color = bg) {
            Box(Modifier.size(56.dp), contentAlignment = Alignment.Center) { Icon(t.icon, null, tint = fg) }
        }
        Text(t.label, style = MaterialTheme.typography.labelMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
private fun ListTile(t: Tile) {
    val (bg, fg) = toneColors(t.tone)
    Row(
        Modifier
            .fillMaxWidth()
            .clickable(onClick = t.onClick)
            .padding(horizontal = 14.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Surface(shape = MaterialTheme.shapes.medium, color = bg) {
            Box(Modifier.size(40.dp), contentAlignment = Alignment.Center) { Icon(t.icon, null, tint = fg) }
        }
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(t.label, style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.Medium)
            Text(t.subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}
