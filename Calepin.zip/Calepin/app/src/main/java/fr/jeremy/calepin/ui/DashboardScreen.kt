package fr.jeremy.calepin.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.heightIn
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.EditNote
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.foundation.horizontalScroll
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Contacts
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.SettingsRemote
import androidx.compose.material.icons.filled.SmartToy
import androidx.compose.material.icons.filled.SportsEsports
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import fr.jeremy.calepin.i18n.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.material3.TextButton
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import fr.jeremy.calepin.BuildConfig
import fr.jeremy.calepin.NotesViewModel
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/** Ce qu'on peut ouvrir depuis l'accueil. Les rubriques absentes (null) ne sont pas affichées. */
class DashboardActions(
    val onNotes: () -> Unit,
    val onNote: (Long) -> Unit,
    val onNewNote: () -> Unit,
    val onSearch: (String) -> Unit,
    val onCalendar: () -> Unit,
    val onContacts: () -> Unit,
    val onAssistant: () -> Unit,
    val onRemote: (() -> Unit)?,
    val onDevices: (() -> Unit)?,
    val onGames: () -> Unit,
    val onSettings: () -> Unit,
    val onAppearance: () -> Unit,
    val onPro: () -> Unit,
    val onWeather: () -> Unit = {},
    val onPhone: () -> Unit = {},
    val onEvent: (fr.jeremy.calepin.data.Event) -> Unit = {},
    val onContact: (Long) -> Unit = {},
    val onClient: (String) -> Unit = {},
    val onRadios: () -> Unit = {},
    val onCrashLog: () -> Unit = {},
    val onOffice: () -> Unit = {},
)

private class Tile(val id: String, val label: String, val subtitle: String, val icon: AppIcon, val tone: Int, val onClick: () -> Unit)

@Composable
fun DashboardScreen(vm: NotesViewModel, a: DashboardActions) {
    val ctx = LocalContext.current
    val appearance = remember { Appearance.get(ctx) }
    val style by appearance.home.collectAsStateWithLifecycle()
    val total by vm.noteCount.collectAsStateWithLifecycle()
    val events by vm.events.collectAsStateWithLifecycle()
    var query by remember { mutableStateOf("") }

    val now = System.currentTimeMillis()
    val upcoming = remember(events) {
        val endOfTomorrow = Calendar.getInstance().apply {
            add(Calendar.DAY_OF_YEAR, 1); set(Calendar.HOUR_OF_DAY, 23); set(Calendar.MINUTE, 59)
        }.timeInMillis
        events.filter { e -> (if (e.end > 0) e.end else e.start + 3_600_000) >= now && e.start <= endOfTomorrow }.sortedBy { it.start }.take(3)
    }

    val order by appearance.homeTiles.collectAsStateWithLifecycle()
    val allTiles = buildList {
        add(Tile("notes", "Notes", if (total == 0) "Aucune note" else "$total note${if (total > 1) "s" else ""}", AppIcon.NOTES, 0, a.onNotes))
        add(Tile("agenda", "Agenda", if (upcoming.isEmpty()) "Rien de prévu" else "${upcoming.size} à venir", AppIcon.AGENDA, 1, a.onCalendar))
        add(Tile("contacts", "Contacts", "Téléphone", AppIcon.CONTACTS, 0, a.onContacts))
        a.onRemote?.let { add(Tile("remote", "Télécommande", "Télé et décodeur", AppIcon.REMOTE, 1, it)) }
        add(Tile("pro", "Pro", "Clients et interventions", AppIcon.PRO, 0, a.onPro))
        add(Tile("office", "Bureau", "PDF : lire, annoter, signer", AppIcon.OFFICE, 1, a.onOffice))
        add(Tile("phone", "Téléphone", "Entretien, nettoyage, fichiers", AppIcon.PHONE, 2, a.onPhone))
        add(Tile("games", "Détente", "Jeux et webradios", AppIcon.GAMES, 1, a.onGames))
    }
    // Rubriques choisies dans Apparence, dans l'ordre choisi
    val tiles = remember(allTiles, order) {
        val byId = allTiles.associateBy { it.id }
        order.mapNotNull { byId[it] }.ifEmpty { allTiles }
    }

    val look = LocalLook.current
    val cs = MaterialTheme.colorScheme
    val glow = titleGlow()
    Box(Modifier.fillMaxSize()) {
    Scaffold(
        containerColor = Color.Transparent,
    ) { pad ->
        Column(
            Modifier
                .fillMaxSize()
                .padding(pad)
                .verticalScroll(rememberScrollState())
                .statusBarsPadding()
                .padding(horizontal = 16.dp)
                .padding(top = 12.dp, bottom = 24.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            // En-tête : salutation et date
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    // La date sert de titre : police, couleur et effet des titres du thème
                    FitText(
                        SimpleDateFormat(fr.jeremy.calepin.i18n.I18n.pattern("EEEE d MMMM"), fr.jeremy.calepin.i18n.I18n.locale).format(Date()).replaceFirstChar { it.uppercase() },
                        style = MaterialTheme.typography.headlineMedium.copy(shadow = glow),
                        fontWeight = FontWeight.SemiBold,
                        // Couleur des titres choisie dans Apparence, sinon la couleur principale du thème
                        color = if (MaterialTheme.typography.headlineMedium.color != Color.Unspecified) Color.Unspecified else MaterialTheme.colorScheme.primary,
                        maxLines = 2,
                        minScale = 0.7f,
                        translate = false,
                    )
                }
                Surface(shape = CircleShape, color = MaterialTheme.colorScheme.primaryContainer) {
                    IconButton(onClick = a.onAssistant) { AssistantIcon(MaterialTheme.colorScheme.onPrimaryContainer, MaterialTheme.colorScheme.primaryContainer) }
                }
                Spacer(Modifier.width(8.dp))
                // Paramètres : engrenage qui tourne doucement
                val spin = rememberInfiniteTransition(label = "engrenage")
                val angle by spin.animateFloat(
                    initialValue = 0f, targetValue = 360f,
                    animationSpec = infiniteRepeatable(tween(durationMillis = 6000, easing = LinearEasing)),
                    label = "angle",
                )
                Surface(shape = CircleShape, color = MaterialTheme.colorScheme.secondaryContainer) {
                    IconButton(onClick = a.onSettings) {
                        Icon(
                            Icons.Filled.Settings, "Paramètres",
                            tint = MaterialTheme.colorScheme.onSecondaryContainer,
                            modifier = Modifier.graphicsLayer { rotationZ = angle },
                        )
                    }
                }
            }

            // Recherche : notes, agenda, contacts, pro, radios (le bouton à droite choisit où chercher)
            var scopes by remember { mutableStateOf(SearchScopes.load(ctx)) }
            HomeSearchBar(
                query = query,
                onQuery = { query = it },
                scopes = scopes,
                onScopes = { scopes = it; SearchScopes.save(ctx, it) },
                onSubmit = { if (SearchScope.NOTES in scopes && query.isNotBlank()) { a.onSearch(query); query = "" } },
            )
            GlobalSearchResults(
                vm, query, scopes,
                SearchActions(
                    onNote = { a.onNote(it); query = "" },
                    onAllNotes = { a.onSearch(it); query = "" },
                    onEvent = { a.onEvent(it); query = "" },
                    onContact = { a.onContact(it); query = "" },
                    onContacts = { a.onContacts() },
                    onClient = { a.onClient(it); query = "" },
                    onRadios = { a.onRadios() },
                ),
            )

            // Calepin a planté depuis la dernière visite : on le signale (une fois)
            var crashNew by remember { mutableStateOf(fr.jeremy.calepin.care.CrashLog.hasNew(ctx)) }
            if (crashNew) {
                Card(
                    onClick = { crashNew = false; a.onCrashLog() },
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer),
                    modifier = Modifier.fillMaxWidth(),
                ) {
                    Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text("Calepin a rencontré une erreur. Touche ici pour voir le détail et le partager.", modifier = Modifier.weight(1f), color = MaterialTheme.colorScheme.onErrorContainer)
                        TextButton(onClick = { crashNew = false; fr.jeremy.calepin.care.CrashLog.markSeen(ctx) }) { Text("Ignorer") }
                    }
                }
            }

            // Météo du lieu choisi (ou de la position du téléphone)
            val showWeather by appearance.showWeather.collectAsStateWithLifecycle()
            if (showWeather) WeatherCard(onOpen = a.onWeather)

            // Aujourd'hui
            Card(
                onClick = a.onCalendar,
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer),
                border = appBorder(),
                modifier = Modifier.fillMaxWidth(),
            ) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    FitText("Aujourd'hui et demain", style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.onSecondaryContainer)
                    if (upcoming.isEmpty()) {
                        Text("Rien de prévu. Profites-en !", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSecondaryContainer)
                    }
                    upcoming.forEach { e ->
                        val fmt = if (e.allDay) "EEE d" else "EEE d · HH'h'mm"
                        // Heure au-dessus, titre en dessous sur deux lignes : tout reste lisible, quelle que soit la police
                        Column {
                            FitText(
                                SimpleDateFormat(fr.jeremy.calepin.i18n.I18n.pattern(fmt), fr.jeremy.calepin.i18n.I18n.locale).format(Date(e.start))
                                    .replaceFirstChar { it.uppercase() },
                                style = MaterialTheme.typography.labelLarge,
                                color = MaterialTheme.colorScheme.onSecondaryContainer.copy(alpha = 0.8f),
                                translate = false,
                            )
                            FitText(
                                e.title,
                                style = MaterialTheme.typography.bodyLarge,
                                color = MaterialTheme.colorScheme.onSecondaryContainer,
                                maxLines = 2,
                                minScale = 0.8f,
                                translate = false,
                            )
                        }
                    }
                }
            }

            // Rubriques, avec le choix rapide de la présentation
            var styleMenu by remember { mutableStateOf(false) }
            Row(verticalAlignment = Alignment.CenterVertically) {
                FitText("Rubriques", style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.primary, modifier = Modifier.weight(1f))
                Box {
                    Surface(
                        onClick = { styleMenu = true },
                        shape = CircleShape,
                        color = MaterialTheme.colorScheme.surfaceContainerHigh.copy(alpha = if (look.deco == Deco.NONE) 1f else 0.85f),
                    ) {
                        Row(Modifier.padding(horizontal = 12.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Filled.Dashboard, null, Modifier.size(18.dp), tint = MaterialTheme.colorScheme.primary)
                            Spacer(Modifier.width(6.dp))
                            Text(style.label, style = MaterialTheme.typography.labelLarge, maxLines = 1)
                        }
                    }
                    DropdownMenu(expanded = styleMenu, onDismissRequest = { styleMenu = false }) {
                        HomeStyle.entries.forEach { h ->
                            DropdownMenuItem(
                                text = { Text(h.label) },
                                leadingIcon = { HomeStyleSketch(h, Modifier.size(width = 30.dp, height = 24.dp)) },
                                trailingIcon = { if (h == style) Icon(Icons.Filled.Check, null, tint = MaterialTheme.colorScheme.primary) },
                                onClick = { appearance.setHome(h); styleMenu = false },
                            )
                        }
                    }
                }
            }
            when (style) {
                HomeStyle.GRID -> tiles.chunked(2).forEach { row ->
                    // Les deux tuiles d'une ligne prennent la hauteur de la plus haute
                    Row(Modifier.height(IntrinsicSize.Min), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        row.forEach { t -> BigTile(t, Modifier.weight(1f)) }
                        if (row.size == 1) Spacer(Modifier.weight(1f))
                    }
                }
                // Grille : trois carrés par ligne (deux si le texte est très grand)
                HomeStyle.GRID3 -> {
                    val perRow = if (textGrowth() >= 1.25f) 2 else 3
                    tiles.chunked(perRow).forEach { row ->
                        Row(Modifier.height(IntrinsicSize.Min), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            row.forEach { t -> SquareTile(t, Modifier.weight(1f)) }
                            repeat(perRow - row.size) { Spacer(Modifier.weight(1f)) }
                        }
                    }
                }
                // Mosaïque : une grande carte, puis deux tuiles, deux tuiles, une grande carte…
                HomeStyle.MOSAIC -> {
                    var i = 0
                    var line = 0
                    while (i < tiles.size) {
                        val take = if (line % 3 == 0) 1 else 2
                        val row = tiles.subList(i, minOf(i + take, tiles.size))
                        if (row.size == 1) {
                            WideTile(row[0], colored = true)
                        } else {
                            Row(Modifier.height(IntrinsicSize.Min), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                row.forEach { t -> BigTile(t, Modifier.weight(1f)) }
                            }
                        }
                        i += take
                        line++
                    }
                }
                // Grandes cartes colorées, une par ligne
                HomeStyle.CARDS -> tiles.forEach { t -> WideTile(t, colored = true) }
                // Carrousel : les tuiles défilent de gauche à droite (sur deux rangées)
                HomeStyle.CAROUSEL -> {
                    val rows = if (tiles.size > 4) 2 else 1
                    val perRow = (tiles.size + rows - 1) / rows
                    val scroll = rememberScrollState()
                    Column(
                        Modifier.fillMaxWidth().horizontalScroll(scroll),
                        verticalArrangement = Arrangement.spacedBy(12.dp),
                    ) {
                        tiles.chunked(perRow).forEach { row ->
                            Row(Modifier.height(IntrinsicSize.Min), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                row.forEach { t -> BigTile(t, Modifier.width(150.dp.grow())) }
                            }
                        }
                    }
                }
                // Gros texte : trois rubriques par ligne au lieu de quatre, pour garder les noms lisibles
                HomeStyle.COMPACT -> {
                    val perRow = if (textGrowth() >= 1.25f) 3 else 4
                    tiles.chunked(perRow).forEach { row ->
                        Row(Modifier.height(IntrinsicSize.Min), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            row.forEach { t -> SmallTile(t, Modifier.weight(1f)) }
                            repeat(perRow - row.size) { Spacer(Modifier.weight(1f)) }
                        }
                    }
                }
                HomeStyle.LIST -> Card(colors = tileColors(), border = tileBorder(0)) {
                    tiles.forEach { t -> ListTile(t) }
                }
            }

        }
    }
}
}

/** Cartes légèrement translucides sur les thèmes à décor, pour laisser voir le fond. */
@Composable
private fun tileColors() = CardDefaults.cardColors(
    containerColor = MaterialTheme.colorScheme.surfaceContainerLow.copy(alpha = if (LocalLook.current.deco == Deco.NONE) 1f else 0.82f),
)

/** Liseré lumineux autour des cartes (néon, grimoire, terminal). */
@Composable
private fun tileBorder(tone: Int): BorderStroke? = appBorder(themeTileBorder(tone))

/** Liseré propre au thème (néon, grimoire, terminal…), utilisé quand les bordures sont « selon le thème ». */
@Composable
private fun themeTileBorder(tone: Int): BorderStroke? {
    val cs = MaterialTheme.colorScheme
    return when (LocalLook.current.deco) {
        Deco.NEON, Deco.SUNSET -> BorderStroke(1.dp, (if (tone % 2 == 0) cs.primary else cs.secondary).copy(alpha = 0.55f))
        Deco.TERMINAL -> BorderStroke(1.dp, cs.primary.copy(alpha = 0.45f))
        Deco.GRIMOIRE -> BorderStroke(1.dp, Color(0xFFD4AF37).copy(alpha = 0.45f))
        Deco.STARS, Deco.ENERGY, Deco.STORM -> BorderStroke(1.dp, cs.primary.copy(alpha = 0.45f))
        Deco.SNOW -> BorderStroke(1.dp, Color.White.copy(alpha = 0.25f))
        else -> null
    }
}

@Composable
private fun toneColors(tone: Int): Pair<Color, Color> = when (tone % 3) {
    0 -> MaterialTheme.colorScheme.primaryContainer to MaterialTheme.colorScheme.onPrimaryContainer
    1 -> MaterialTheme.colorScheme.secondaryContainer to MaterialTheme.colorScheme.onSecondaryContainer
    else -> MaterialTheme.colorScheme.tertiaryContainer to MaterialTheme.colorScheme.onTertiaryContainer
}

@Composable
private fun BigTile(t: Tile, modifier: Modifier) {
    // Hauteur libre (au moins 120 dp) : le nom et la description s'affichent en entier
    Card(
        onClick = t.onClick, colors = tileColors(), border = tileBorder(t.tone),
        modifier = modifier.fillMaxHeight().heightIn(min = 120.dp.grow()),
    ) {
        Column(Modifier.padding(14.dp).fillMaxSize(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            ThemedIcon(t.icon, t.tone, 44.dp)
            Spacer(Modifier.weight(1f))
            Column {
                FitText(t.label, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                FitText(
                    t.subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 2, minScale = 0.8f,
                )
            }
        }
    }
}

/** Carré de la grille : icône au centre, nom dessous. */
@Composable
private fun SquareTile(t: Tile, modifier: Modifier) {
    Card(
        onClick = t.onClick, colors = tileColors(), border = tileBorder(t.tone),
        modifier = modifier.fillMaxHeight().heightIn(min = 104.dp.grow()),
    ) {
        Column(
            Modifier.padding(horizontal = 8.dp, vertical = 12.dp).fillMaxSize(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(8.dp, Alignment.CenterVertically),
        ) {
            ThemedIcon(t.icon, t.tone, 44.dp)
            FitText(t.label, style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.SemiBold, textAlign = TextAlign.Center, maxLines = 2, minScale = 0.7f)
        }
    }
}

/** Grande carte sur toute la largeur, aux couleurs du thème. */
@Composable
private fun WideTile(t: Tile, colored: Boolean) {
    val (bg, fg) = toneColors(t.tone)
    val translucent = LocalLook.current.deco != Deco.NONE
    Card(
        onClick = t.onClick,
        colors = if (colored) CardDefaults.cardColors(containerColor = bg.copy(alpha = if (translucent) 0.88f else 1f), contentColor = fg) else tileColors(),
        border = tileBorder(t.tone),
        modifier = Modifier.fillMaxWidth().heightIn(min = 88.dp.grow()),
    ) {
        Row(Modifier.padding(horizontal = 16.dp, vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
            ThemedIcon(t.icon, t.tone, 52.dp)
            Spacer(Modifier.width(16.dp))
            Column(Modifier.weight(1f)) {
                FitText(t.label, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold, color = if (colored) fg else Color.Unspecified)
                FitText(
                    t.subtitle, style = MaterialTheme.typography.bodyMedium,
                    color = if (colored) fg.copy(alpha = 0.8f) else MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 2, minScale = 0.8f,
                )
            }
            Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, null, tint = if (colored) fg else MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun SmallTile(t: Tile, modifier: Modifier) {
    Column(
        modifier
            .clickable(onClick = t.onClick)
            .padding(vertical = 6.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        ThemedIcon(t.icon, t.tone, 56.dp)
        FitText(t.label, style = MaterialTheme.typography.labelMedium, textAlign = TextAlign.Center, minScale = 0.6f)
    }
}

@Composable
private fun ListTile(t: Tile) {
    Row(
        Modifier
            .fillMaxWidth()
            .clickable(onClick = t.onClick)
            .padding(horizontal = 14.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        ThemedIcon(t.icon, t.tone, 40.dp)
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            FitText(t.label, style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.Medium)
            Text(t.subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}


/** Icône de l'assistant : une tête de robot avec un micro en badge. */
@Composable
fun AssistantIcon(tint: Color, background: Color, size: androidx.compose.ui.unit.Dp = 26.dp) {
    Box(Modifier.size(size + 4.dp)) {
        Icon(Icons.Filled.SmartToy, contentDescription = "Parler à l'assistant", tint = tint, modifier = Modifier.size(size).align(Alignment.TopStart))
        Box(
            Modifier
                .size(size * 0.62f)
                .align(Alignment.BottomEnd)
                .background(background, CircleShape)
                .padding(1.dp)
                .background(tint, CircleShape),
            contentAlignment = Alignment.Center,
        ) {
            Icon(Icons.Filled.Mic, null, tint = background, modifier = Modifier.size(size * 0.42f))
        }
    }
}
