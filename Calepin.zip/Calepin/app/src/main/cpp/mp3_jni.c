// Pont JNI entre Kotlin (fr.jeremy.calepin.audio.Mp3Encoder) et l'encodeur Shine.
#include <jni.h>
#include <stdlib.h>
#include <string.h>
#include "layer3.h"

typedef struct {
    shine_t shine;
    int channels;
    int samplesPerPass;
} Enc;

JNIEXPORT jlong JNICALL
Java_fr_jeremy_calepin_audio_Mp3Encoder_nativeInit(JNIEnv *env, jclass cls, jint sampleRate, jint channels, jint bitrate) {
    if (shine_check_config(sampleRate, bitrate) < 0) return 0;
    shine_config_t config;
    memset(&config, 0, sizeof(config));
    shine_set_config_mpeg_defaults(&config.mpeg);
    config.wave.samplerate = sampleRate;
    config.wave.channels = channels == 2 ? PCM_STEREO : PCM_MONO;
    config.mpeg.mode = channels == 2 ? STEREO : MONO;
    config.mpeg.bitr = bitrate;
    shine_t s = shine_initialise(&config);
    if (!s) return 0;
    Enc *e = (Enc *) calloc(1, sizeof(Enc));
    e->shine = s;
    e->channels = channels;
    e->samplesPerPass = shine_samples_per_pass(s);
    return (jlong) (intptr_t) e;
}

JNIEXPORT jint JNICALL
Java_fr_jeremy_calepin_audio_Mp3Encoder_nativeSamplesPerPass(JNIEnv *env, jclass cls, jlong h) {
    Enc *e = (Enc *) (intptr_t) h;
    return e ? e->samplesPerPass : 0;
}

static jbyteArray toArray(JNIEnv *env, unsigned char *data, int written) {
    jbyteArray out = (*env)->NewByteArray(env, written > 0 ? written : 0);
    if (written > 0) (*env)->SetByteArrayRegion(env, out, 0, written, (const jbyte *) data);
    return out;
}

/* pcm : exactement samplesPerPass * channels échantillons 16 bits entrelacés. */
JNIEXPORT jbyteArray JNICALL
Java_fr_jeremy_calepin_audio_Mp3Encoder_nativeEncode(JNIEnv *env, jclass cls, jlong h, jshortArray pcm) {
    Enc *e = (Enc *) (intptr_t) h;
    if (!e) return (*env)->NewByteArray(env, 0);
    jshort *buf = (*env)->GetShortArrayElements(env, pcm, NULL);
    int written = 0;
    unsigned char *data = shine_encode_buffer_interleaved(e->shine, (int16_t *) buf, &written);
    jbyteArray out = toArray(env, data, written);
    (*env)->ReleaseShortArrayElements(env, pcm, buf, JNI_ABORT);
    return out;
}

JNIEXPORT jbyteArray JNICALL
Java_fr_jeremy_calepin_audio_Mp3Encoder_nativeFlush(JNIEnv *env, jclass cls, jlong h) {
    Enc *e = (Enc *) (intptr_t) h;
    if (!e) return (*env)->NewByteArray(env, 0);
    int written = 0;
    unsigned char *data = shine_flush(e->shine, &written);
    return toArray(env, data, written);
}

JNIEXPORT void JNICALL
Java_fr_jeremy_calepin_audio_Mp3Encoder_nativeClose(JNIEnv *env, jclass cls, jlong h) {
    Enc *e = (Enc *) (intptr_t) h;
    if (!e) return;
    shine_close(e->shine);
    free(e);
}
