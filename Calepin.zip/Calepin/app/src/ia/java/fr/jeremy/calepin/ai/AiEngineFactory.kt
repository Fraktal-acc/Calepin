package fr.jeremy.calepin.ai

import android.content.Context
import com.google.ai.edge.litertlm.Backend
import com.google.ai.edge.litertlm.Contents
import com.google.ai.edge.litertlm.Conversation
import com.google.ai.edge.litertlm.ConversationConfig
import com.google.ai.edge.litertlm.Engine
import com.google.ai.edge.litertlm.EngineConfig
import com.google.ai.edge.litertlm.SamplerConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext

/** Calepin IA : moteur LiteRT-LM de Google, sur le processeur du téléphone. */
object AiEngineFactory {
    @Volatile private var instance: LiteRtEngine? = null

    fun get(ctx: Context): AiEngine =
        instance ?: synchronized(this) {
            instance ?: LiteRtEngine(ctx.applicationContext.cacheDir.path).also { instance = it }
        }
}

private class LiteRtEngine(private val cacheDir: String) : AiEngine {
    private val mutex = Mutex()
    private var engine: Engine? = null
    private var loadedPath: String? = null
    @Volatile private var current: Conversation? = null

    /** Le processeur (CPU) est plus lent que la puce graphique mais ne plante pas faute de mémoire graphique. */
    private fun ensure(modelPath: String): Engine {
        engine?.let { if (loadedPath == modelPath) return it }
        engine?.close()
        engine = null
        val e = Engine(
            EngineConfig(
                modelPath = modelPath,
                backend = Backend.CPU(),
                maxNumTokens = 4096,
                cacheDir = cacheDir,
            )
        )
        e.initialize()
        engine = e
        loadedPath = modelPath
        return e
    }

    override suspend fun generate(modelPath: String, system: String, prompt: String, onText: (String) -> Unit): String =
        mutex.withLock {
            withContext(Dispatchers.IO) {
                val e = ensure(modelPath)
                val conv = e.createConversation(
                    ConversationConfig(
                        systemInstruction = Contents.of(system),
                        samplerConfig = SamplerConfig(topK = 40, topP = 0.9, temperature = 0.6),
                    )
                )
                current = conv
                try {
                    val sb = StringBuilder()
                    conv.sendMessageAsync(prompt).collect { msg ->
                        val piece = msg.toString()
                        if (piece.isNotEmpty()) {
                            sb.append(piece)
                            onText(sb.toString())
                        }
                    }
                    sb.toString()
                } finally {
                    current = null
                    conv.close()
                }
            }
        }

    override fun stop() {
        runCatching { current?.cancelProcess() }
    }

    override fun release() {
        stop()
        runCatching { engine?.close() }
        engine = null
        loadedPath = null
    }
}
