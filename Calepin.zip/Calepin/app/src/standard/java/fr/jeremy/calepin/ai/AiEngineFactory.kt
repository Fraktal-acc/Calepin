package fr.jeremy.calepin.ai

import android.content.Context

/** Calepin standard : pas de modèle d'IA embarqué. */
object AiEngineFactory {
    @Suppress("UNUSED_PARAMETER")
    fun get(ctx: Context): AiEngine? = null
}
