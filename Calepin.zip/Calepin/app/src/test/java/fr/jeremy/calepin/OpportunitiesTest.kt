package fr.jeremy.calepin

import fr.jeremy.calepin.market.AnalysisResult
import fr.jeremy.calepin.market.Analyzer
import fr.jeremy.calepin.market.Backtest
import fr.jeremy.calepin.market.Candle
import fr.jeremy.calepin.market.Factor
import fr.jeremy.calepin.market.Instrument
import fr.jeremy.calepin.market.Opportunities
import fr.jeremy.calepin.market.TradePlan
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.math.sin

/** Détecteur d'opportunités : note de potentiel, classement, listes d'instruments. */
class OpportunitiesTest {
    private fun result(score: Double, plan: TradePlan? = null, bt: Backtest? = null, factors: List<Factor> = emptyList()) =
        AnalysisResult(score, factors, emptyList(), emptyList(), emptyList(), plan, bt, 1.0, 25.0)

    private val plan = TradePlan(true, 100.0, 95.0, 110.0, 120.0)
    private val inst = Instrument("AIR.PA", "Airbus", "Paris", "Action")

    @Test
    fun pasDOpportuniteSansSignalDAchat() {
        assertNull(Opportunities.potential(result(-40.0, plan)))
        assertNull(Opportunities.potential(result(0.0, plan)))
        assertNull(Opportunities.from(inst, 100.0, "EUR", result(-10.0), 0L))
    }

    @Test
    fun potentielCroissant() {
        val weak = Opportunities.potential(result(30.0))!!
        val strong = Opportunities.potential(result(70.0))!!
        val withPlan = Opportunities.potential(result(70.0, plan))!!
        val withSignal = Opportunities.potential(result(70.0, plan), recentBuySignal = true)!!
        assertTrue(strong > weak)
        assertTrue(withPlan > strong)
        assertTrue(withSignal > withPlan)
        listOf(weak, strong, withPlan, withSignal).forEach { assertTrue(it in 0.0..100.0) }
        // Une bonne réussite passée augmente la confiance, donc le potentiel
        val good = Opportunities.potential(result(60.0, plan, Backtest(20, 15, 1.2)))!!
        val bad = Opportunities.potential(result(60.0, plan, Backtest(20, 3, -0.5)))!!
        assertTrue(good > bad)
    }

    @Test
    fun detailDeLOpportunite() {
        val f = listOf(
            Factor("RSI", 0.5, 10.0, "RSI 45, en hausse"),
            Factor("Tendance", 0.9, 15.0, "au-dessus des moyennes"),
            Factor("Actualités", -0.6, 9.0, "mauvaises nouvelles"),
        )
        val o = Opportunities.from(inst, 100.0, "EUR", result(55.0, plan, factors = f), 1L, robotSignal = "Rebond RSI")!!
        assertEquals(10.0, o.upside, 1e-9)
        assertEquals(5.0, o.downside, 1e-9)
        assertEquals(2.0, o.rr, 1e-9)
        assertTrue(o.reasons.first().contains("Rebond RSI"))
        // Le plus fort élément favorable d'abord
        assertTrue(o.reasons[1].startsWith("Tendance"))
        assertTrue(o.risks.single().startsWith("Actualités"))
        assertTrue(o.winRate.isNaN())
    }

    @Test
    fun classement() {
        val a = Opportunities.from(inst, 100.0, "EUR", result(40.0), 1L)!!
        val b = Opportunities.from(inst.copy(symbol = "SAF.PA", name = "Safran"), 100.0, "EUR", result(80.0, plan), 1L)!!
        val a2 = a.copy(potential = a.potential + 1)
        val r = Opportunities.rank(listOf(a, b, a2))
        assertEquals(listOf("SAF.PA", "AIR.PA"), r.map { it.symbol })
        assertEquals(a2.potential, r[1].potential, 1e-9)
    }

    @Test
    fun listesDInstruments() {
        Opportunities.UNIVERSES.forEach { u ->
            assertTrue(u.label, u.instruments.isNotEmpty())
            assertEquals(u.label, u.instruments.size, u.instruments.map { it.symbol }.distinct().size)
        }
        val watch = listOf(Instrument("AIR.PA", "Airbus"), Instrument("XYZ", "Autre"))
        val l = Opportunities.instruments(setOf(Opportunities.WATCH, "cac40"), watch, emptyList())
        assertEquals(l.size, l.map { it.symbol }.distinct().size)
        assertTrue(l.any { it.symbol == "XYZ" })
        assertTrue(l.any { it.symbol == "MC.PA" })
        val t = Opportunities.instruments(setOf(Opportunities.TRENDING), emptyList(), listOf(Instrument("PLTR", "Palantir")))
        assertEquals(listOf("PLTR"), t.map { it.symbol })
    }

    @Test
    fun surDeVraisCours() {
        // Hausse régulière avec des vagues : l'analyse penche à l'achat, le détecteur la retient
        val closes = List(300) { 100.0 + it * 0.5 + 4 * sin(it / 4.0) }
        val c = closes.mapIndexed { i, x ->
            val o = if (i == 0) x else closes[i - 1]
            Candle(1_700_000_000L + i * 86_400L, o, maxOf(o, x) * 1.002, minOf(o, x) * 0.998, x, 1000.0)
        }
        val r = Analyzer(c).analyze()!!
        val o = Opportunities.from(inst, c.last().c, "EUR", r, 1L)
        assertNotNull(o)
        assertTrue(o!!.potential > 0)
        assertTrue(Opportunities.level(o.potential).isNotBlank())
    }
}
