package fr.jeremy.calepin

import fr.jeremy.calepin.data.Event
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test
import java.util.Calendar

/** Rendez-vous qui se répètent. */
class EventRepeatTest {
    private fun at(y: Int, m: Int, d: Int, h: Int) = Calendar.getInstance().apply { clear(); set(y, m - 1, d, h, 0) }.timeInMillis

    @Test
    fun sansRepetition() {
        assertNull(Event(title = "x", start = at(2026, 10, 1, 9)).nextOccurrence(at(2026, 10, 2, 0)))
    }

    @Test
    fun chaqueSemaineGardeLaDuree() {
        val e = Event(title = "Sport", start = at(2026, 10, 5, 18), end = at(2026, 10, 5, 19), repeat = "week")
        val n = e.nextOccurrence(at(2026, 10, 6, 0))!!
        assertEquals(at(2026, 10, 12, 18), n.start)
        assertEquals(at(2026, 10, 12, 19), n.end)
    }

    @Test
    fun duLundiAuVendrediSauteLeWeekEnd() {
        // Vendredi 9 octobre 2026 → lundi 12
        val e = Event(title = "Bus", start = at(2026, 10, 9, 7), repeat = "weekdays")
        assertEquals(at(2026, 10, 12, 7), e.nextOccurrence(at(2026, 10, 9, 8))!!.start)
    }

    @Test
    fun chaqueMois() {
        val e = Event(title = "Loyer", start = at(2026, 1, 5, 9), repeat = "month")
        assertEquals(at(2026, 3, 5, 9), e.nextOccurrence(at(2026, 2, 6, 0))!!.start)
    }
}
