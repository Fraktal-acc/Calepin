package fr.jeremy.calepin

import fr.jeremy.calepin.search.NoteOrder
import org.junit.Assert.assertEquals
import org.junit.Test

/** Ordre des notes au glisser-déposer : seules les notes affichées changent de place. */
class NoteOrderTest {
    @Test
    fun deplacementDansLaListeAffichee() {
        // Toutes les notes : 1 2 3 4 5 ; dans le dossier affiché : 2 4 5
        val all = listOf(1L, 2L, 3L, 4L, 5L)
        val r = NoteOrder.reorder(all, listOf(2L, 4L, 5L), from = 5L, to = 2L)
        assertEquals(listOf(1L, 5L, 3L, 2L, 4L), r)
    }

    @Test
    fun nouvellesNotesPlaceesDevant() {
        // Ordre enregistré vide : la liste affichée devient l'ordre
        val r = NoteOrder.reorder(emptyList(), listOf(7L, 8L, 9L), from = 7L, to = 9L)
        assertEquals(listOf(8L, 9L, 7L), r)
    }

    @Test
    fun rienAChanger() {
        val all = listOf(1L, 2L)
        assertEquals(all, NoteOrder.reorder(all, listOf(1L, 2L), 1L, 1L))
        assertEquals(all, NoteOrder.reorder(all, listOf(1L, 2L), 1L, 3L))
    }
}
