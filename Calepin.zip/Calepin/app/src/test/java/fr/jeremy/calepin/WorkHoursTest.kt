package fr.jeremy.calepin

import fr.jeremy.calepin.care.WorkHours
import fr.jeremy.calepin.data.Event
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.util.Calendar

/** Calcul des heures de travail : nuit, dimanche, fériés, heures au-delà du contrat. */
class WorkHoursTest {
    private fun at(y: Int, m: Int, d: Int, h: Int, min: Int = 0) =
        Calendar.getInstance().apply { clear(); set(y, m - 1, d, h, min) }.timeInMillis

    private fun doy(y: Int, m: Int, d: Int) = Calendar.getInstance().apply { clear(); set(y, m - 1, d) }.get(Calendar.DAY_OF_YEAR)

    private fun shift(s: Long, e: Long) = Event(title = "Poste", start = s, end = e, category = Event.CATEGORY_WORK)

    @Test
    fun joursFeries2026() {
        val h = WorkHours.holidays(2026)
        assertEquals(11, h.size)
        assertTrue(doy(2026, 1, 1) in h)
        assertTrue("lundi de Pâques", doy(2026, 4, 6) in h)
        assertTrue(doy(2026, 5, 1) in h)
        assertTrue("Ascension", doy(2026, 5, 14) in h)
        assertTrue("lundi de Pentecôte", doy(2026, 5, 25) in h)
        assertTrue(doy(2026, 7, 14) in h)
        assertTrue(doy(2026, 12, 25) in h)
    }

    @Test
    fun heuresDeNuit() {
        // Mardi 6 octobre 2026, 21 h → mercredi 7 h ; nuit de 21 h à 6 h
        val s = WorkHours.shift(shift(at(2026, 10, 6, 21), at(2026, 10, 7, 7)), 21 * 60, 6 * 60)!!
        assertEquals(600, s.minutes)
        assertEquals(540, s.night)
        assertEquals(0, s.sunday)
    }

    @Test
    fun heuresDuDimanche() {
        // Samedi 3 octobre 2026, 22 h → dimanche 6 h
        val s = WorkHours.shift(shift(at(2026, 10, 3, 22), at(2026, 10, 4, 6)), 21 * 60, 6 * 60)!!
        assertEquals(480, s.minutes)
        assertEquals(360, s.sunday)
    }

    @Test
    fun ferie() {
        val s = WorkHours.shift(shift(at(2026, 7, 14, 8), at(2026, 7, 14, 12)), 21 * 60, 6 * 60)!!
        assertEquals(240, s.holiday)
    }

    @Test
    fun journeeEntiereIgnoree() {
        assertNull(WorkHours.shift(Event(title = "Repos", start = at(2026, 10, 6, 0), allDay = true, category = Event.CATEGORY_WORK), 21 * 60, 6 * 60))
    }

    @Test
    fun heuresAuDelaDuContrat() {
        // Semaine du lundi 5 octobre 2026 : 5 × 8 h = 40 h pour un contrat de 35 h
        val events = (5..9).map { d -> shift(at(2026, 10, d, 6), at(2026, 10, d, 14)) }
        val m = WorkHours.month(events, 2026, Calendar.OCTOBER, 35 * 60, 21 * 60, 6 * 60)
        assertEquals(40 * 60, m.total)
        assertEquals(5 * 60, m.over)
        assertEquals(5, m.shifts.size)
    }

    @Test
    fun formatHeures() {
        assertEquals("7 h", WorkHours.hm(420))
        assertEquals("7 h 05", WorkHours.hm(425))
    }
}
