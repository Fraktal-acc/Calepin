package fr.jeremy.calepin

import fr.jeremy.calepin.market.Candle
import fr.jeremy.calepin.market.ScalpSide
import fr.jeremy.calepin.market.ScalpState
import fr.jeremy.calepin.market.Scalper
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.math.sin

/** Assistant de scalping sur bougies d'une minute. */
class ScalperTest {
    private val base = 1_760_000_000L - 1_760_000_000L % 300

    /** Bougies d'une minute à partir des clôtures, avec un volume. */
    private fun candles(closes: List<Double>, vol: (Int) -> Double = { 1000.0 }): List<Candle> = closes.mapIndexed { i, c ->
        val o = if (i == 0) c else closes[i - 1]
        Candle(base + i * 60L, o, maxOf(o, c) + 0.03, minOf(o, c) - 0.03, c, vol(i))
    }

    private fun now(c: List<Candle>) = c.last().t + 61

    /** Forte hausse, repli d'environ 50 %, puis reprise franche (rebond sur Fibonacci). */
    private fun pullbackUp(): List<Double> {
        val up = List(150) { 100.0 + it * 0.05 + 0.05 * sin(it / 3.0) }      // 100 → 107,5
        val top = up.last()
        val down = List(10) { top - (it + 1) * 0.25 }                          // repli de 2,5 (environ 55 %)
        val low = down.last()
        val again = List(4) { low + (it + 1) * 0.35 }                          // reprise nette
        return up + down + again
    }

    @Test
    fun pasAssezDHistorique() {
        assertNull(Scalper.analyze(candles(List(30) { 100.0 + it * 0.01 }), now(candles(List(30) { 100.0 }))))
    }

    @Test
    fun bougieEnCoursIgnoree() {
        val c = candles(List(100) { 100.0 + it * 0.01 })
        assertEquals(c.size - 1, Scalper.closed(c, c.last().t + 10).size)
        assertEquals(c.size, Scalper.closed(c, c.last().t + 61).size)
    }

    @Test
    fun repliPuisRepriseALAchat() {
        val c = candles(pullbackUp())
        val s = Scalper.analyze(c, now(c))!!
        assertEquals(ScalpSide.LONG, s.side)
        assertTrue("état ${s.state} force ${s.strength}", s.state == ScalpState.ENTER || s.state == ScalpState.PREPARE)
        assertTrue(s.stop < s.entry)
        assertTrue(s.target1 > s.entry)
        assertTrue(s.target2 >= s.target1)
        assertTrue(s.rr > 0)
        assertTrue(s.longScore > s.shortScore)
        assertTrue(s.levels.any { it.label.startsWith("Fibo") })
        assertTrue(s.levels.any { it.label == "Stop" })
    }

    @Test
    fun mouvementInverseALaVente() {
        // Même chose à l'envers : forte baisse, rebond, puis reprise de la baisse
        val c = candles(pullbackUp().map { 214.0 - it })
        val s = Scalper.analyze(c, now(c))!!
        assertEquals(ScalpSide.SHORT, s.side)
        assertTrue(s.state == ScalpState.ENTER || s.state == ScalpState.PREPARE)
        assertTrue(s.stop > s.entry)
        assertTrue(s.target1 < s.entry)
        assertTrue(s.shortScore > s.longScore)
    }

    @Test
    fun marcheFerme() {
        val c = candles(pullbackUp())
        val s = Scalper.analyze(c, c.last().t + 3600)!!
        assertEquals(ScalpState.NO_TRADE, s.state)
        assertTrue(s.warnings.first().contains("marché fermé"))
    }

    @Test
    fun marcheSansDirection() {
        val c = candles(List(200) { 100.0 + 0.02 * sin(it / 2.0) })
        val s = Scalper.analyze(c, now(c))!!
        assertTrue("état ${s.state}", s.state != ScalpState.ENTER)
    }

    @Test
    fun controleSurLHistorique() {
        val waves = List(900) { 100.0 + it * 0.01 + 1.5 * sin(it / 25.0) + 0.2 * sin(it / 3.0) }
        val c = candles(waves) { i -> if (i % 37 == 0) 5000.0 else 1000.0 }
        val bt = Scalper.backtest(c, now(c))
        assertTrue(bt.trades >= 0)
        assertTrue(bt.wins <= bt.trades)
        if (bt.trades > 0) assertTrue(bt.winRate in 0.0..100.0)
        assertEquals(0, Scalper.backtest(candles(List(50) { 100.0 }), now(candles(List(50) { 100.0 }))).trades)
    }

    @Test
    fun suiviDePosition() {
        val stopHit = Scalper.follow(ScalpSide.LONG, 100.0, 99.0, 101.5, 102.5, 98.9, null)
        assertTrue(stopHit.exit)
        val t1 = Scalper.follow(ScalpSide.LONG, 100.0, 99.0, 101.5, 102.5, 101.6, null)
        assertFalse(t1.exit)
        assertTrue(t1.reachedT1)
        val t2 = Scalper.follow(ScalpSide.SHORT, 100.0, 101.0, 98.5, 97.5, 97.4, null)
        assertTrue(t2.exit)
        assertTrue(t2.pnlPct > 0)
        val running = Scalper.follow(ScalpSide.SHORT, 100.0, 101.0, 98.5, 97.5, 100.3, null)
        assertFalse(running.exit)
        assertEquals(-0.3, running.r, 1e-9)
        val c = candles(pullbackUp())
        val sig = Scalper.analyze(c, now(c))
        assertNotNull(sig)
    }
}
