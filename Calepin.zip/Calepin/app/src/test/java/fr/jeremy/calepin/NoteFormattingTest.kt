package fr.jeremy.calepin

import fr.jeremy.calepin.text.DisplayMap
import fr.jeremy.calepin.text.MarkdownSigns
import fr.jeremy.calepin.text.NoteLayout
import fr.jeremy.calepin.text.RichText
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/** Mise en forme des notes : signes cachés, correspondance des positions, couleurs, alignement, photos. */
class NoteFormattingTest {

    // ------------------------------------------------------------ Signes (gras, italique, titres, liens)

    @Test
    fun texteSansSignesInchange() {
        val t = "Liste des courses : pain, lait"
        assertTrue(MarkdownSigns.hidden(t).isEmpty())
        assertEquals(t, MarkdownSigns.plain(t))
    }

    @Test
    fun grasItaliqueBarreTitre() {
        assertEquals("Titre", MarkdownSigns.plain("# Titre"))
        assertEquals("Sous-titre", MarkdownSigns.plain("### Sous-titre"))
        assertEquals("un mot important ici", MarkdownSigns.plain("un **mot important** ici"))
        assertEquals("un mot penché", MarkdownSigns.plain("un *mot* penché"))
        assertEquals("prix barré", MarkdownSigns.plain("prix ~~barré~~"))
        assertEquals("gras et italique", MarkdownSigns.plain("**gras** et *italique*"))
    }

    @Test
    fun etoilesIsoleesGardees() {
        // Une multiplication ou une étoile seule ne sont pas de la mise en forme
        assertEquals("3 * 4 = 12", MarkdownSigns.plain("3 * 4 = 12"))
        assertEquals("note*", MarkdownSigns.plain("note*"))
        assertEquals("** pas gras **", MarkdownSigns.plain("** pas gras **"))
    }

    @Test
    fun liens() {
        assertEquals("voir Recette", MarkdownSigns.plain("voir [[Recette]]"))
        assertEquals("site Calepin (https://exemple.fr)", MarkdownSigns.plain("site [Calepin](https://exemple.fr)"))
        assertEquals("écrire à moi (a@b.fr)", MarkdownSigns.plain("écrire à [moi](mailto:a@b.fr)"))
        assertEquals("appeler Paul (0612345678)", MarkdownSigns.plain("appeler [Paul](tel:0612345678)"))
        // Adresse non reconnue : laissée telle quelle
        assertEquals("[x](ftp://a)", MarkdownSigns.plain("[x](ftp://a)"))
    }

    @Test
    fun signesCachesPositions() {
        val t = "a **b** c"
        val h = MarkdownSigns.hidden(t).sortedBy { it.start }
        assertEquals(2, h.size)
        assertEquals(2, h[0].start); assertEquals(4, h[0].end)
        assertEquals(5, h[1].start); assertEquals(7, h[1].end)
        // Titre : le curseur posé devant va après « # »
        val title = MarkdownSigns.hidden("## Titre").single()
        assertEquals(0, title.start); assertEquals(3, title.end); assertTrue(title.after)
    }

    @Test
    fun lienWebNeGardeQueLeTexte() {
        val t = "[ici](https://a.fr) ok"
        val m = DisplayMap(t, MarkdownSigns.hidden(t), emptyList())
        assertEquals("ici ok", m.visible)
    }

    // ------------------------------------------------------------ Correspondance des positions

    @Test
    fun correspondanceIdentite() {
        val m = DisplayMap("bonjour", emptyList(), emptyList())
        assertTrue(m.isIdentity)
        assertEquals("bonjour", m.visible)
        for (i in 0..7) {
            assertEquals(i, m.toVisible(i))
            assertEquals(i, m.toOriginal(i))
        }
    }

    @Test
    fun correspondanceAvecSignesCaches() {
        val t = "a **b** c"
        val m = DisplayMap(t, MarkdownSigns.hidden(t), emptyList())
        assertFalse(m.isIdentity)
        assertEquals("a b c", m.visible)
        // « b » : position 4 dans le texte, 2 à l'écran
        assertEquals(2, m.toVisible(4))
        // Fin du texte
        assertEquals(m.visible.length, m.toVisible(t.length))
        // Chaque caractère affiché correspond au bon caractère du texte
        for (v in m.visible.indices) {
            val o = m.toOriginal(v)
            assertTrue("position $v", o in 0..t.length)
            assertEquals(v, m.toVisible(o))
        }
    }

    @Test
    fun correspondanceAvecAjouts() {
        val m = DisplayMap("ab", emptyList(), listOf(DisplayMap.Insert(1, "\n", false)))
        assertEquals("a\nb", m.visible)
        assertEquals(0, m.toVisible(0))
        assertEquals(3, m.toVisible(2))
        assertEquals(2, m.toOriginal(3))
    }

    @Test
    fun correspondancePositionsHorsLimites() {
        val m = DisplayMap("abc", listOf(DisplayMap.Hidden(0, 1, false)), emptyList())
        assertEquals("bc", m.visible)
        assertEquals(0, m.toVisible(-5))
        assertEquals(2, m.toVisible(99))
    }

    // ------------------------------------------------------------ Couleurs, surlignage, souligné

    @Test
    fun couleurAppliqueeEtRetiree() {
        val t = "un mot rouge"
        val e = RichText.apply(t, 3, 6, "c", "#ff0000")
        assertEquals("un [c=#FF0000]mot[/c] rouge", e.text)
        assertEquals("mot", e.text.substring(e.start, e.end))
        assertEquals(t, RichText.strip(e.text))
        val span = RichText.spans(e.text).single()
        assertEquals("c", span.kind); assertEquals("#FF0000", span.value)
        assertEquals("mot", e.text.substring(span.start, span.end))
        // Retrait de la couleur : retour au texte d'origine
        val back = RichText.apply(e.text, e.start, e.end, "c", null)
        assertEquals(t, back.text)
    }

    @Test
    fun couleurSurUnePartieDejaColoree() {
        val t = "[c=#FF0000]abcdef[/c]"
        // « cd » en bleu au milieu du rouge
        val e = RichText.apply(t, 13, 15, "c", "#0000FF")
        assertEquals("abcdef", RichText.strip(e.text))
        val sp = RichText.spans(e.text).map { e.text.substring(it.start, it.end) to it.value }
        assertEquals(listOf("ab" to "#FF0000", "cd" to "#0000FF", "ef" to "#FF0000"), sp)
        assertEquals("#0000FF", RichText.valueOver(e.text, e.start, e.end, "c"))
    }

    @Test
    fun soulignePuisRetire() {
        val t = "texte souligné"
        val on = RichText.toggleUnderline(t, 0, 5)
        assertEquals("[u]texte[/u] souligné", on.text)
        val off = RichText.toggleUnderline(on.text, on.start, on.end)
        assertEquals(t, off.text)
    }

    @Test
    fun reperesSansFinIgnores() {
        assertTrue(RichText.spans("[c=#112233]pas fini").isEmpty())
        assertEquals("rien", RichText.clean("[c=#112233][/c]rien"))
    }

    @Test
    fun alignement() {
        val t = "ligne 1\nligne 2"
        val e = RichText.setAlign(t, 9, 9, RichText.CENTER)
        assertEquals("ligne 1\nligne 2[center]", e.text)
        assertNull(RichText.alignAt(e.text, 2))
        assertEquals(RichText.CENTER, RichText.alignAt(e.text, 10))
        assertEquals("ligne 1\nligne 2", RichText.strip(e.text))
        val a = RichText.aligns(e.text).single()
        assertEquals(8, a.first); assertEquals("center", a.third)
        // Retour à gauche
        assertEquals(t, RichText.setAlign(e.text, 9, 9, null).text)
    }

    @Test
    fun alignementGardeSurNouvelleLigne() {
        val old = "titre[center]"
        val new = "titre\n[center]"
        val (fixed, cursor) = RichText.afterEdit(old, new, 6)!!
        assertEquals("titre[center]\n[center]", fixed)
        assertTrue(cursor in 0..fixed.length)
        // Saisie sans retour à la ligne : rien à corriger
        assertNull(RichText.afterEdit("ab", "abc", 3))
    }

    // ------------------------------------------------------------ Photos dans le texte

    @Test
    fun repereDePhoto() {
        val t = "Avant\n{{photo:a.jpg|right|50}}\nAprès"
        val spec = NoteLayout.specFor(t, "a.jpg")!!
        assertEquals(NoteLayout.Side.RIGHT, spec.side)
        assertEquals(50, spec.width)
        assertFalse(spec.video)
        assertEquals("{{photo:a.jpg|right|50}}", spec.marker)
        assertEquals(setOf("a.jpg"), NoteLayout.aloneFiles(t))
        assertNull(NoteLayout.specFor(t, "b.jpg"))
    }

    @Test
    fun largeurBornee() {
        val s = NoteLayout.specFor("{{photo:x.png|left|5}}", "x.png")!!
        assertEquals(20, s.width)
        val full = NoteLayout.specFor("{{video:v.mp4|full}}", "v.mp4")!!
        assertTrue(full.video)
        assertEquals(100, full.width)
    }

    @Test
    fun photoRemiseSeuleSurSaLigne() {
        val t = "texte{{photo:a.jpg}}suite"
        val (fixed, added) = NoteLayout.repair(t, setOf("a.jpg"))
        assertEquals("texte\n{{photo:a.jpg}}\nsuite", fixed)
        assertEquals(2, added.size)
        assertEquals(setOf("a.jpg"), NoteLayout.aloneFiles(fixed))
        // Déjà bien placée : rien ne change
        val (same, none) = NoteLayout.repair(fixed, setOf("a.jpg"))
        assertEquals(fixed, same)
        assertTrue(none.isEmpty())
    }

    @Test
    fun morceauxDeLaNote() {
        val t = "Début\n{{photo:a.jpg}}\n{{photo:b.jpg}}\nFin"
        val segs = NoteLayout.segments(t)
        val photos = segs.mapNotNull { it.files }.flatten()
        assertEquals(listOf("a.jpg", "b.jpg"), photos)
        val texts = segs.filter { it.files == null }.map { t.substring(it.start, it.end).trim() }.filter { it.isNotEmpty() }
        assertEquals(listOf("Début", "Fin"), texts)
    }

    @Test
    fun photoPlaceeChangee() {
        val t = "{{photo:a.jpg}}\ntexte"
        // Vignette placée à gauche : largeur par défaut
        val r = NoteLayout.setSpec(t, "a.jpg", NoteLayout.Side.LEFT, 30)
        assertEquals(NoteLayout.Side.LEFT, NoteLayout.specFor(r, "a.jpg")!!.side)
        assertEquals(NoteLayout.DEFAULT_WIDTH, NoteLayout.specFor(r, "a.jpg")!!.width)
        // Vignette : la largeur ne change pas
        assertEquals(t, NoteLayout.setWidth(t, "a.jpg", 60))
        val w = NoteLayout.setWidth(r, "a.jpg", 60)
        assertEquals(60, NoteLayout.specFor(w, "a.jpg")!!.width)
        assertTrue(w.endsWith("texte"))
    }
}
