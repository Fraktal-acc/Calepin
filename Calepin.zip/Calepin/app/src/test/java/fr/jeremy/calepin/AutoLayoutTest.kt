package fr.jeremy.calepin

import fr.jeremy.calepin.text.AutoLayout
import fr.jeremy.calepin.text.AutoLayout.Block
import fr.jeremy.calepin.text.NoteLayout
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/** Mise en page automatique des notes (assistant PDF). */
class AutoLayoutTest {
    private fun b(t: String) = AutoLayout.blocks(t)

    @Test
    fun titresListesTaches() {
        val bl = b("# Chantier\n\nMATÉRIEL\n- vis\n- chevilles\n\nÀ faire :\n☐ appeler le client\n☑ devis envoyé")
        assertEquals(Block.Heading(1, "Chantier"), bl[0])
        assertEquals(1, (bl[1] as Block.Heading).level)
        assertEquals("Matériel", (bl[1] as Block.Heading).text)
        val list = bl[2] as Block.ListBlock
        assertFalse(list.numbered)
        assertEquals(listOf("Vis", "Chevilles"), list.items.map { it.text })
        assertEquals("À faire", (bl[3] as Block.Heading).text)
        val tasks = bl[4] as Block.Tasks
        assertEquals(listOf(false, true), tasks.items.map { it.done })
        assertEquals("Appeler le client", tasks.items[0].text)
    }

    @Test
    fun listeNumeroteeEtSousNiveaux() {
        val l = b("1. Couper l'eau\n2. Démonter\n  - joint\n3. Remonter").single() as Block.ListBlock
        assertTrue(l.numbered)
        assertEquals(4, l.items.size)
        assertEquals(1, l.items[2].level)
    }

    @Test
    fun clesValeursEtTableau() {
        val kv = b("Client : Martin\nAdresse : 12 rue de la Paix\nTarif : 25 €/h").single() as Block.KeyValues
        assertEquals("Client", kv.rows[0].first)
        assertEquals("25 €/h", kv.rows[2].second)
        val t = b("| Jour | Heures |\n|---|---|\n| Lundi | 7 |\n| Mardi | 8 |").single() as Block.Table
        assertEquals(listOf("Jour", "Heures"), t.header)
        assertEquals(2, t.rows.size)
        // Une seule ligne « clé : valeur » reste une phrase ; une heure n'est pas une clé
        assertTrue(b("Note : penser au pain").single() is Block.Paragraph)
        assertTrue(b("Rendez-vous à 14:30\nPuis 16:00").single() is Block.Paragraph)
    }

    @Test
    fun photosCitationsSeparateurs() {
        val bl = b("{{photo:a.jpg}}\n{{photo:b.jpg}}\n> Une citation\n---\n{{photo:c.jpg|left|40}}\nTexte à côté")
        assertEquals(Block.Thumbs(listOf("a.jpg", "b.jpg")), bl[0])
        assertTrue(bl[1] is Block.Quote)
        assertEquals(Block.Divider, bl[2])
        assertEquals(NoteLayout.Side.LEFT, (bl[3] as Block.Photo).side)
        assertTrue(bl[4] is Block.Paragraph)
    }

    @Test
    fun paragrapheGardeSesLignes() {
        val p = b("Jean Dupont\n12 rue Verte\n06190 Roquebrune").single() as Block.Paragraph
        assertEquals(3, p.text.lines().size)
    }

    @Test
    fun typographie() {
        assertEquals("Bonjour ! Ça va ?", AutoLayout.typo("Bonjour ! Ça va?"))
        assertEquals("Il a dit « oui »", AutoLayout.typo("Il a dit \"oui\""))
        assertEquals("Attends…", AutoLayout.typo("Attends..."))
        // Adresses web et heures intactes
        assertEquals("https://a.fr/x?y=1 à 14:30", AutoLayout.typo("https://a.fr/x?y=1 à 14:30"))
        assertEquals("Prix : 12 €", AutoLayout.typo("Prix : 12 €"))
    }

    @Test
    fun titreEtEnBref() {
        val d = AutoLayout.build("", "Réunion de chantier\nRendez-vous le 12/10/2026 à 14h30, appeler le 06 12 34 56 78.", 0L)
        assertEquals("Réunion de chantier", d.title)
        assertTrue(d.facts.any { it.label == "Date" })
        assertTrue(d.facts.any { it.label == "Téléphone" })
        assertTrue(d.meta.startsWith("Mise à jour le"))
    }

    @Test
    fun photosPourIa() {
        val (t, m) = AutoLayout.hidePhotos("Avant\n{{photo:a.jpg|right|40}}\nAprès")
        assertTrue("[PHOTO 1]" in t)
        val back = AutoLayout.restorePhotos("# Titre\n[PHOTO 1]\nTexte", m)
        assertTrue("{{photo:a.jpg|right|40}}" in back)
        // Photo oubliée par l'IA : remise à la fin
        assertTrue(AutoLayout.restorePhotos("Texte", m).trimEnd().endsWith("{{photo:a.jpg|right|40}}"))
        assertEquals("# T", AutoLayout.cleanAi("Voici le texte mis en page :\n```\n# T\n```"))
    }
}
