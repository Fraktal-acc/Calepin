package fr.jeremy.calepin

import fr.jeremy.calepin.office.word.DocBlock
import fr.jeremy.calepin.office.word.DocxReader
import fr.jeremy.calepin.office.word.DocxWriter
import fr.jeremy.calepin.office.word.ImageSize
import fr.jeremy.calepin.office.word.PageSetup
import fr.jeremy.calepin.office.word.Paper
import fr.jeremy.calepin.office.word.WordDoc
import fr.jeremy.calepin.office.word.WordMarkup
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.util.zip.ZipInputStream

/** Documents Word du Bureau : écriture des paragraphes, lecture et écriture des fichiers .docx. */
class WordDocxTest {
    // Petit PNG 2×1 (rouge, bleu)
    private val png = java.util.Base64.getDecoder().decode("iVBORw0KGgoAAAANSUhEUgAAAAIAAAABCAIAAAB7QOjdAAAAEElEQVR4nGP4z8DAwMDwHwAF/QH/1qXqUQAAAABJRU5ErkJggg==")

    private val sample = WordDoc(
        listOf(
            DocBlock.Text(text = "# Compte rendu\nTexte **gras**, *italique*, [u]souligné[/u], ~~barré~~ et [c=#C00000]rouge[/c].\n" +
                "## Points[center]\n- premier\n  - sous-point\n- second\n1. un\n2. deux\n☐ à faire\n☑ fait\n> Une citation\nVoir [le site](https://exemple.fr) ici."),
            DocBlock.Table(rows = listOf(listOf("Jour", "Heures"), listOf("Lundi", "**7**"), listOf("Mardi", "8"))),
            DocBlock.Text(text = "Après le tableau"),
            DocBlock.Image(file = "photo.png", widthPct = 50),
            DocBlock.Text(text = ""),
            DocBlock.PageBreak(),
            DocBlock.Text(text = "Page 2[right]"),
        ),
        PageSetup(paper = Paper.A4, marginMm = 20, font = "Georgia", sizePt = 12, header = "Mon en-tête", footer = "Calepin", pageNumbers = true),
    )

    private fun entries(b: ByteArray): Map<String, String> {
        val out = HashMap<String, String>()
        ZipInputStream(b.inputStream()).use { z -> var e = z.nextEntry; while (e != null) { out[e.name] = String(z.readBytes()); e = z.nextEntry } }
        return out
    }

    @Test
    fun ecritureLisibleParWord() {
        val bytes = DocxWriter.write(sample, "Compte rendu") { if (it == "photo.png") png else null }
        val e = entries(bytes)
        assertTrue("[Content_Types].xml" in e && "word/document.xml" in e && "word/styles.xml" in e && "word/numbering.xml" in e)
        val d = e["word/document.xml"]!!
        assertTrue(d.contains("w:val=\"Heading1\""))
        assertTrue(d.contains("<w:b/>"))
        assertTrue(d.contains("<w:u w:val=\"single\"/>"))
        assertTrue(d.contains("<w:numId w:val=\"1\"/>")) // puces
        assertTrue(d.contains("<w:tbl>"))
        assertTrue(d.contains("<w:br w:type=\"page\"/>"))
        assertTrue(d.contains("<w:hyperlink"))
        assertTrue("word/media/image1.png" in e)
        assertTrue("word/footer1.xml" in e && e["word/footer1.xml"]!!.contains("PAGE"))
        // XML bien formé
        e.filterKeys { it.endsWith(".xml") || it.endsWith(".rels") }.forEach { (n, x) ->
            javax.xml.parsers.DocumentBuilderFactory.newInstance().apply { isNamespaceAware = true }.newDocumentBuilder().parse(x.byteInputStream())
        }
    }

    @Test
    fun allerRetour() {
        val bytes = DocxWriter.write(sample, "Compte rendu") { if (it == "photo.png") png else null }
        val r = DocxReader.read(bytes)
        val texts = r.doc.blocks.filterIsInstance<DocBlock.Text>().map { it.text }
        val first = texts.first()
        val orig = (sample.blocks[0] as DocBlock.Text).text
        assertEquals(orig, first)
        val t = r.doc.blocks.filterIsInstance<DocBlock.Table>().single()
        assertEquals(listOf("Jour", "Heures"), t.rows[0].map { WordMarkup.stripInline(it) })
        assertEquals("**7**", t.rows[1][1])
        assertTrue(t.header)
        val img = r.doc.blocks.filterIsInstance<DocBlock.Image>().single()
        assertEquals(50, img.widthPct)
        assertTrue(r.images[img.file]!!.contentEquals(png))
        assertEquals(1, r.doc.blocks.count { it is DocBlock.PageBreak })
        assertTrue(texts.any { it.contains("Page 2[right]") })
        assertEquals("Georgia", r.doc.page.font)
        assertEquals(12, r.doc.page.sizePt)
        assertEquals(20, r.doc.page.marginMm)
        assertEquals("Mon en-tête", r.doc.page.header)
        assertTrue(r.doc.page.pageNumbers)
        assertEquals("Calepin", r.doc.page.footer)
        assertEquals("Compte rendu", r.title)
    }

    @Test
    fun morceauxDeTexte() {
        val runs = WordMarkup.runs("a **b** [c=#FF0000]c[/c] [l](https://x.fr)")
        assertEquals("a b c l", runs.joinToString("") { it.text })
        assertTrue(runs.first { it.text == "b" }.bold)
        assertEquals("#FF0000", runs.first { it.text == "c" }.color)
        assertEquals("https://x.fr", runs.first { it.text == "l" }.link)
        assertEquals("a **b** [c=#FF0000]c[/c] [l](https://x.fr)", WordMarkup.markup(runs))
        // Espaces hors des signes
        assertEquals("**mot** suite", WordMarkup.markup(listOf(WordMarkup.Run("mot ", bold = true), WordMarkup.Run("suite"))))
    }

    @Test
    fun listesEtStyles() {
        val t = "un\ndeux"
        assertEquals("- un\n- deux", WordMarkup.toggleList(t, 0, t.length, WordMarkup.Kind.BULLET).text)
        assertEquals("1. un\n2. deux", WordMarkup.toggleList(t, 0, t.length, WordMarkup.Kind.NUMBER).text)
        assertEquals(t, WordMarkup.toggleList("- un\n- deux", 0, 10, WordMarkup.Kind.BULLET).text)
        assertEquals("## un\ndeux", WordMarkup.setStyle(t, 0, 0, WordMarkup.Kind.H2).text)
        assertEquals("un\ndeux", WordMarkup.setStyle("## un\ndeux", 0, 0, WordMarkup.Kind.NORMAL).text)
        assertEquals("- a\n  - b", WordMarkup.indent("- a\n- b", 5, 5, 1).text)
        // Entrée : élément suivant, numéro suivant ; élément vide : fin de liste
        assertEquals("1. a\n2. " to 8, WordMarkup.afterEnter("1. a", "1. a\n", 5))
        assertEquals("- a\n" to 4, WordMarkup.afterEnter("- a\n- ", "- a\n- \n", 7))
        assertNull(WordMarkup.afterEnter("texte", "texte\n", 6))
        assertEquals("1. a\n2. b\n\n1. c", WordMarkup.renumber("1. a\n5. b\n\n1. c"))
        assertEquals("☑ x", WordMarkup.toggleCheck("☐ x", 1).text)
        assertEquals("# Titre gras", WordMarkup.clearFormatting("# Titre **gras**", 0, 0).text)
    }

    @Test
    fun rechercheHorsRepères() {
        val t = "**gras** et gras"
        assertEquals(2, WordMarkup.find(t, "gras").size)
        assertEquals(0, WordMarkup.find("[c=#FF0000]x[/c]", "c=").size)
    }

    @Test
    fun tailleDesImages() {
        assertEquals(2 to 1, ImageSize.of(png))
        assertNull(ImageSize.of(byteArrayOf(1, 2, 3)))
    }

    @Test
    fun statistiques() {
        val s = WordDoc(listOf(DocBlock.Text(text = "# Titre\nBonjour tout le monde."))).stats()
        assertEquals(5, s.words)
        assertEquals(2, s.paragraphs)
        assertNotNull(s)
    }
}
