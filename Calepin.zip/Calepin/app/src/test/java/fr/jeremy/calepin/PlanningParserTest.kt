package fr.jeremy.calepin

import fr.jeremy.calepin.detect.PlanningParser
import fr.jeremy.calepin.detect.Shift
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.util.Calendar

/** Lecture des plannings : formats de dates et d'horaires, postes de nuit, jours de repos. */
class PlanningParserTest {
    private fun at(y: Int, m: Int, d: Int, h: Int = 0, min: Int = 0) =
        Calendar.getInstance().apply { clear(); set(y, m - 1, d, h, min) }.timeInMillis

    private val now = at(2026, 10, 1, 12)

    private fun work(shifts: List<Shift>) = shifts.filter { !it.absence }

    @Test
    fun uneLigneParJour() {
        val text = """
            Lundi 12/10/2026  Site A  08:00 - 16:00
            Mardi 13/10/2026  Site B  09:30 - 17:45
        """.trimIndent()
        val s = work(PlanningParser.parse(text, now)).sortedBy { it.start }
        assertEquals(2, s.size)
        assertEquals(at(2026, 10, 12, 8), s[0].start)
        assertEquals(at(2026, 10, 12, 16), s[0].end)
        assertTrue(s[0].label, s[0].label.contains("Site A"))
        assertEquals(at(2026, 10, 13, 9, 30), s[1].start)
        assertEquals(at(2026, 10, 13, 17, 45), s[1].end)
    }

    @Test
    fun posteDeNuitFinitLeLendemain() {
        val s = work(PlanningParser.parse("Vendredi 16/10/2026 19:00 - 07:00", now)).single()
        assertEquals(at(2026, 10, 16, 19), s.start)
        assertEquals(at(2026, 10, 17, 7), s.end)
    }

    @Test
    fun deuxCreneauxLeMemeJour() {
        val s = work(PlanningParser.parse("Mardi 13/10/2026 : 8h-12h / 14h-18h", now)).sortedBy { it.start }
        assertEquals(2, s.size)
        assertEquals(at(2026, 10, 13, 8), s[0].start)
        assertEquals(at(2026, 10, 13, 12), s[0].end)
        assertEquals(at(2026, 10, 13, 14), s[1].start)
        assertEquals(at(2026, 10, 13, 18), s[1].end)
    }

    @Test
    fun joursDeReposSansVacation() {
        val text = """
            Lundi 12/10/2026  08:00 - 16:00
            Mardi 13/10/2026  Repos
            Mercredi 14/10/2026  RH
            Jeudi 15/10/2026  CP
        """.trimIndent()
        val s = work(PlanningParser.parse(text, now))
        assertEquals(1, s.size)
        assertEquals(at(2026, 10, 12, 8), s[0].start)
    }

    @Test
    fun dateEnLettres() {
        val s = work(PlanningParser.parse("12 octobre 2026 : 06h00 - 14h00", now)).single()
        assertEquals(at(2026, 10, 12, 6), s.start)
        assertEquals(at(2026, 10, 12, 14), s.end)
    }

    @Test
    fun dateSurUneLigneHorairesSurLaSuivante() {
        val s = work(PlanningParser.parse("Jeudi 15/10/2026\n07:00 - 15:00", now)).single()
        assertEquals(at(2026, 10, 15, 7), s.start)
        assertEquals(at(2026, 10, 15, 15), s.end)
    }

    @Test
    fun texteSansPlanning() {
        assertTrue(work(PlanningParser.parse("Bonjour, voici le compte rendu de la réunion.", now)).isEmpty())
        assertTrue(PlanningParser.parse("", now).isEmpty())
    }

    @Test
    fun creneauxCoherents() {
        val text = """
            Octobre 2026
            Lun 12  Mar 13  Mer 14
            08:00-16:00  14:00-22:00  22:00-06:00
        """.trimIndent()
        val s = work(PlanningParser.parse(text, now))
        assertTrue(s.isNotEmpty())
        s.forEach { assertTrue("fin après début", it.end > it.start) }
        s.forEach { assertTrue("moins de 24 h", it.end - it.start <= 24 * 3_600_000L) }
    }
}
