package fr.jeremy.calepin

import fr.jeremy.calepin.detect.EntityDetector
import fr.jeremy.calepin.detect.EntityType
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

/** Éléments reconnus dans les notes : téléphones, e-mails, liens, dates, adresses. */
class EntityDetectorTest {
    private fun of(text: String, type: EntityType) = EntityDetector.detect(text).filter { it.type == type }

    @Test
    fun telephone() {
        val p = of("Appeler le 06 12 34 56 78 demain", EntityType.PHONE).single()
        assertTrue(p.value, p.value.filter { it.isDigit() }.endsWith("612345678"))
        assertTrue(of("Italie : +39 06 1234 5678", EntityType.PHONE).isNotEmpty())
    }

    @Test
    fun emailEtLien() {
        val t = "Écrire à jean.dupont@exemple.fr ou voir www.exemple.fr/page"
        assertEquals("jean.dupont@exemple.fr", of(t, EntityType.EMAIL).single().text)
        assertTrue(of(t, EntityType.URL).single().value.startsWith("http"))
    }

    @Test
    fun dates() {
        assertTrue(of("Rendez-vous le 12/10/2026 à 14h30", EntityType.DATE).single().hasTime)
        assertTrue(of("Anniversaire le 1er mai 2027", EntityType.DATE).isNotEmpty())
        assertTrue(of("On se voit demain", EntityType.DATE).isNotEmpty())
    }

    @Test
    fun adresse() {
        assertTrue(of("Livraison au 12 avenue Winston Churchill, 06190 Roquebrune-Cap-Martin", EntityType.ADDRESS).isNotEmpty())
    }

    @Test
    fun positionsDansLeTexte() {
        val t = "Mail : a@b.fr, tél 06 12 34 56 78"
        EntityDetector.detect(t).forEach { e ->
            assertTrue(e.start in 0 until e.end)
            assertTrue(e.end <= t.length)
            assertEquals(e.text, t.substring(e.start, e.end))
        }
        assertTrue(EntityDetector.detect("Texte tout simple").isEmpty())
    }
}
