package fr.jeremy.calepin

import fr.jeremy.calepin.market.Action
import fr.jeremy.calepin.market.Analyzer
import fr.jeremy.calepin.market.AssetKind
import fr.jeremy.calepin.market.Candle
import fr.jeremy.calepin.market.CondType
import fr.jeremy.calepin.market.Condition
import fr.jeremy.calepin.market.ContextScore
import fr.jeremy.calepin.market.Factor
import fr.jeremy.calepin.market.Indicators
import fr.jeremy.calepin.market.NewsItem
import fr.jeremy.calepin.market.NewsText
import fr.jeremy.calepin.market.Portfolio
import fr.jeremy.calepin.market.Rule
import fr.jeremy.calepin.market.Strategy
import fr.jeremy.calepin.market.Timeframe
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.math.sin

/** Robot de bourse : indicateurs, conditions des règles, analyse, portefeuille simulé, actualités, contexte. */
class MarketRobotTest {
    private val eps = 1e-9

    /** Bougies d'un jour à partir des clôtures (ouverture = clôture de la veille). */
    private fun candles(closes: List<Double>, vol: Double = 1000.0): List<Candle> = closes.mapIndexed { i, c ->
        val o = if (i == 0) c else closes[i - 1]
        Candle(1_700_000_000L + i * 86_400L, o, maxOf(o, c) * 1.002, minOf(o, c) * 0.998, c, vol)
    }

    private fun rising(n: Int, from: Double = 100.0, step: Double = 1.0) = List(n) { from + it * step }
    private fun falling(n: Int, from: Double = 300.0, step: Double = 1.0) = List(n) { from - it * step }
    /** Hausse avec des vagues (plus réaliste : replis, rebonds). */
    private fun wavyUp(n: Int) = List(n) { 100.0 + it * 0.5 + 4 * sin(it / 4.0) }

    // ------------------------------------------------------------ Indicateurs

    @Test
    fun moyennesMobiles() {
        val x = listOf(1.0, 2.0, 3.0, 4.0, 5.0)
        val s = Indicators.sma(x, 3)
        assertEquals(5, s.size)
        assertTrue(s[0].isNaN() && s[1].isNaN())
        assertEquals(2.0, s[2], eps); assertEquals(3.0, s[3], eps); assertEquals(4.0, s[4], eps)
        val e = Indicators.ema(List(30) { 10.0 }, 5)
        assertEquals(10.0, e.last(), eps)
        // Après un saut, la moyenne exponentielle réagit plus vite que la simple
        val jump = List(40) { 10.0 } + List(3) { 20.0 }
        assertTrue(Indicators.ema(jump, 20).last() > Indicators.sma(jump, 20).last())
    }

    @Test
    fun rsiExtremes() {
        assertEquals(100.0, Indicators.rsi(rising(40)).last(), 1e-6)
        assertEquals(0.0, Indicators.rsi(falling(40)).last(), 1e-6)
        val r = Indicators.rsi(wavyUp(120)).filter { !it.isNaN() }
        assertTrue(r.all { it in 0.0..100.0 })
        assertTrue(Indicators.rsi(rising(10), 14).all { it.isNaN() })
    }

    @Test
    fun macdEtBollinger() {
        val (line, sig, hist) = Indicators.macd(rising(80))
        assertTrue(line.last() > 0)
        assertEquals(line.last() - sig.last(), hist.last(), 1e-6)
        val (low, mid, up) = Indicators.bollinger(List(30) { 50.0 }, 20, 2.0)
        assertEquals(50.0, mid.last(), eps)
        assertEquals(50.0, up.last(), eps)
        assertEquals(50.0, low.last(), eps)
        val (l2, m2, u2) = Indicators.bollinger(wavyUp(60), 20, 2.0)
        assertTrue(u2.last() > m2.last() && m2.last() > l2.last())
    }

    @Test
    fun stochastiqueAtrAdx() {
        val c = candles(rising(60))
        val st = Indicators.stochastic(c).last()
        assertTrue(st > 80)
        assertTrue(Indicators.atr(c).last() > 0)
        // Tendance nette : ADX fort
        assertTrue(Indicators.adx(c).last() > 25)
        val obv = Indicators.obv(c)
        assertTrue(obv.last() > obv[10])
    }

    @Test
    fun bougiesRegroupees() {
        // 8 bougies d'une heure → 2 bougies de 4 heures
        val base = 1_700_006_400L - 1_700_006_400L % 14_400L
        val h = List(8) { i -> Candle(base + i * 3600L, 10.0 + i, 12.0 + i, 9.0 + i, 11.0 + i, 100.0) }
        val g = Indicators.aggregate(h, 4 * 3600L)
        assertEquals(2, g.size)
        assertEquals(10.0, g[0].o, eps)
        assertEquals(14.0, g[0].c, eps)
        assertEquals(15.0, g[0].h, eps)
        assertEquals(9.0, g[0].l, eps)
        assertEquals(400.0, g[0].v, eps)
        assertEquals(18.0, g[1].c, eps)
    }

    // ------------------------------------------------------------ Conditions des règles

    @Test
    fun conditionsSimples() {
        val up = candles(rising(80))
        assertTrue(Strategy.evaluate(Condition(CondType.RSI_ABOVE, 70.0, 14.0), up).ok)
        assertFalse(Strategy.evaluate(Condition(CondType.RSI_BELOW, 30.0, 14.0), up).ok)
        assertTrue(Strategy.evaluate(Condition(CondType.PRICE_ABOVE_SMA, 50.0), up).ok)
        assertTrue(Strategy.evaluate(Condition(CondType.BREAKOUT_HIGH, 20.0), up).ok)
        assertTrue(Strategy.evaluate(Condition(CondType.PRICE_ABOVE, 150.0), up).ok)
        assertFalse(Strategy.evaluate(Condition(CondType.PRICE_BELOW, 150.0), up).ok)
        val down = candles(falling(80))
        assertTrue(Strategy.evaluate(Condition(CondType.RSI_BELOW, 30.0, 14.0), down).ok)
        assertTrue(Strategy.evaluate(Condition(CondType.BREAKDOWN_LOW, 20.0), down).ok)
    }

    @Test
    fun historiqueInsuffisant() {
        val r = Strategy.evaluate(Condition(CondType.SMA_CROSS_UP, 50.0, 200.0), candles(rising(60)))
        assertFalse(r.ok)
        assertFalse(r.known)
        assertFalse(Strategy.evaluate(Condition(CondType.RSI_ABOVE), candles(rising(2))).known)
    }

    @Test
    fun croisementDeMoyenne() {
        // Baisse puis forte hausse sur la dernière bougie : le cours repasse au-dessus de la moyenne 10
        val closes = falling(30, 130.0) + listOf(150.0)
        val c = candles(closes)
        assertTrue(Strategy.evaluate(Condition(CondType.PRICE_CROSS_UP_SMA, 10.0), c).ok)
        assertFalse(Strategy.evaluate(Condition(CondType.PRICE_CROSS_DOWN_SMA, 10.0), c).ok)
        // Une bougie de plus au-dessus : ce n'est plus un croisement
        assertFalse(Strategy.evaluate(Condition(CondType.PRICE_CROSS_UP_SMA, 10.0), candles(closes + 152.0)).ok)
    }

    @Test
    fun variationEtVolume() {
        val c = candles(List(30) { 100.0 } + 106.0)
        assertTrue(Strategy.evaluate(Condition(CondType.CHANGE_UP, 5.0, 1.0), c).ok)
        assertFalse(Strategy.evaluate(Condition(CondType.CHANGE_DOWN, 5.0, 1.0), c).ok)
        val v = candles(List(31) { 100.0 }).mapIndexed { i, k -> if (i == 30) k.copy(v = 5000.0) else k }
        assertTrue(Strategy.evaluate(Condition(CondType.VOLUME_SPIKE, 2.0, 20.0), v).ok)
    }

    @Test
    fun regleEtOu() {
        val up = candles(rising(80))
        val yes = Condition(CondType.RSI_ABOVE, 70.0, 14.0)
        val no = Condition(CondType.RSI_BELOW, 30.0, 14.0)
        val and = Rule("1", "et", listOf("X"), Timeframe.D1, Action.BUY, all = true, conditions = listOf(yes, no))
        val or = and.copy(all = false)
        assertFalse(Strategy.evaluate(and, up).first)
        assertTrue(Strategy.evaluate(or, up).first)
        assertEquals(2, Strategy.evaluate(or, up).second.size)
    }

    @Test
    fun conditionsActualites() {
        val c = candles(rising(40))
        val good = NewsText.tone(listOf(NewsItem("Apple bondit, résultats solides", "x", "", 0L, 0.8)), 0L)
        val r = Rule("1", "n", listOf("AAPL"), conditions = listOf(Condition(CondType.NEWS_POSITIVE, 30.0)))
        assertTrue(Strategy.needsNews(r))
        assertTrue(Strategy.evaluate(Condition(CondType.NEWS_POSITIVE, 30.0), c, good).ok)
        assertFalse(Strategy.evaluate(Condition(CondType.NEWS_NEGATIVE, 30.0), c, good).ok)
        assertFalse(Strategy.needsNews(r.copy(conditions = listOf(Condition(CondType.RSI_BELOW)))))
    }

    @Test
    fun descriptionsEtModeles() {
        CondType.entries.forEach { assertTrue(Strategy.describe(Condition(it)).isNotBlank()) }
        val t = Strategy.templates()
        assertTrue(t.isNotEmpty())
        t.forEach { (name, rule) -> assertTrue(name, rule.conditions.isNotEmpty()) }
    }

    @Test
    fun uniteDeTempsSuperieure() {
        assertEquals(Timeframe.H4, Analyzer.higher(Timeframe.H1))
        assertEquals(Timeframe.W1, Analyzer.higher(Timeframe.D1))
        assertNull(Analyzer.higher(Timeframe.W1))
        Timeframe.entries.forEach { tf -> Analyzer.higher(tf)?.let { assertTrue(it.ordinal > tf.ordinal) } }
    }

    // ------------------------------------------------------------ Analyse complète

    @Test
    fun analyseHausseEtBaisse() {
        assertNull("pas assez de bougies", Analyzer(candles(rising(30))).analyze())
        val up = Analyzer(candles(wavyUp(260))).analyze(withBacktest = true)!!
        assertTrue("score ${up.score}", up.score > 0)
        assertTrue(up.score in -100.0..100.0)
        assertTrue(up.confidence in 0.0..100.0)
        assertTrue(up.factors.isNotEmpty())
        val down = Analyzer(candles(wavyUp(260).map { 400 - it })).analyze()!!
        assertTrue("score ${down.score}", down.score < 0)
    }

    @Test
    fun planCoherent() {
        val r = Analyzer(candles(wavyUp(260))).analyze() ?: return
        val p = r.plan ?: return
        if (p.buy) {
            assertTrue(p.stop < p.entry)
            assertTrue(p.target1 > p.entry)
        } else {
            assertTrue(p.stop > p.entry)
            assertTrue(p.target1 < p.entry)
        }
        assertTrue(p.rr >= 1.3)
    }

    @Test
    fun elementsEnPlusComptent() {
        val c = candles(wavyUp(260))
        val base = Analyzer(c).analyze(withBacktest = false)!!.score
        val bad = listOf(Factor("Actualités", -1.0, 40.0, "très mauvaises nouvelles"))
        val worse = Analyzer(c).analyze(withBacktest = false, extra = bad)!!.score
        assertTrue("$worse < $base", worse < base)
    }

    @Test
    fun fibonacci() {
        val levels = Analyzer(candles(wavyUp(200))).fibonacci()
        assertTrue(levels.isNotEmpty())
        val prices = levels.map { it.price }
        assertTrue(prices.all { it > 0 })
    }

    // ------------------------------------------------------------ Portefeuille simulé

    @Test
    fun achatVenteSimules() {
        var p = Portfolio()
        p = p.buy("AIR.PA", "Airbus", 100.0, "EUR", 1.0, 1000.0, 5.0, 10.0, "test", 1L)!!
        assertEquals(9000.0, p.cash, eps)
        val pos = p.positions.single()
        assertEquals(10.0, pos.qty, eps)
        assertEquals(95.0, pos.stop, eps)
        assertEquals(110.0, pos.take, eps)
        // Pas deux fois la même ligne
        assertNull(p.buy("AIR.PA", "Airbus", 100.0, "EUR", 1.0, 1000.0, 5.0, 10.0, "test", 2L))
        assertEquals(10_100.0, p.value(mapOf("AIR.PA" to 110.0)), eps)
        p = p.sell("AIR.PA", 110.0, 1.0, "objectif", 3L)!!
        assertEquals(10_100.0, p.cash, eps)
        assertTrue(p.positions.isEmpty())
        assertEquals(100.0, p.realized, eps)
        assertEquals(2, p.trades.size)
        assertNull(p.sell("AIR.PA", 110.0, 1.0, "rien", 4L))
    }

    @Test
    fun achatEnDevise() {
        // Action en dollars, 1 $ = 0,9 €
        val p = Portfolio().buy("AAPL", "Apple", 200.0, "USD", 0.9, 900.0, 0.0, 0.0, "test", 1L)!!
        assertEquals(5.0, p.positions.single().qty, eps)
        assertEquals(0.0, p.positions.single().stop, eps)
        // Pas de taux de change : achat refusé
        assertNull(Portfolio().buy("AAPL", "Apple", 200.0, "USD", 0.0, 900.0, 0.0, 0.0, "test", 1L))
        // Pas plus que l'argent disponible
        val all = Portfolio(cash = 500.0).buy("X", "X", 10.0, "EUR", 1.0, 1000.0, 0.0, 0.0, "t", 1L)!!
        assertEquals(0.0, all.cash, eps)
    }

    // ------------------------------------------------------------ Actualités

    @Test
    fun tonDesTitres() {
        assertTrue(NewsText.scoreTitle("Airbus relève ses objectifs, l'action bondit") > 0.3)
        assertTrue(NewsText.scoreTitle("Apple beats estimates and raises guidance") > 0.3)
        assertTrue(NewsText.scoreTitle("Le titre chute après un avertissement sur résultats") < -0.3)
        assertTrue(NewsText.scoreTitle("Tesla shares plunge on weak demand") < -0.3)
        assertEquals(0.0, NewsText.scoreTitle("Assemblée générale le 12 mai"), eps)
        // Négation : « pas de rebond » n'est pas une bonne nouvelle
        assertTrue(NewsText.scoreTitle("Pas de rebond pour le titre") <= 0.0)
        assertTrue(NewsText.scoreTitle("Le titre +5 % en séance") > 0)
    }

    @Test
    fun tonGeneralPondereParFraicheur() {
        val now = 1_000_000_000_000L
        val fresh = NewsItem("bon", "a", "", now - 3_600_000L, 1.0)
        val old = NewsItem("mauvais", "b", "", now - 10 * 24 * 3_600_000L, -1.0)
        val t = NewsText.tone(listOf(fresh, old), now)
        assertTrue(t.score > 0.5)
        assertEquals(1, t.positive); assertEquals(1, t.negative); assertEquals(1, t.recent)
        assertEquals(0.0, NewsText.tone(emptyList(), now).score, eps)
        assertNull(NewsText.factor(NewsText.tone(emptyList(), now)))
        val f = NewsText.factor(t)!!
        assertEquals("Actualités", f.name)
        assertTrue(f.value in -1.0..1.0)
    }

    @Test
    fun fluxRss() {
        val xml = """<?xml version="1.0"?><rss><channel>
            <item><title>Airbus bondit en Bourse - Les Echos</title><link>https://a.fr/1</link>
            <pubDate>Mon, 12 Oct 2026 08:00:00 GMT</pubDate><source url="x">Les Echos</source></item>
            <item><title><![CDATA[Chute &amp; inquiétudes]]></title><link>https://a.fr/2</link></item>
            </channel></rss>"""
        val items = NewsText.parseRss(xml, "Google")
        assertEquals(2, items.size)
        assertEquals("Airbus bondit en Bourse", items[0].title)
        assertEquals("Les Echos", items[0].source)
        assertTrue(items[0].time > 0)
        assertTrue(items[0].score > 0)
        assertEquals("Chute & inquiétudes", items[1].title)
        assertEquals("Google", items[1].source)
        assertTrue(items[1].score < 0)
    }

    @Test
    fun nomDeRechercheEtDoublons() {
        assertEquals("Apple", NewsText.queryName("Apple Inc.", "AAPL"))
        assertEquals("Brent Oil", NewsText.queryName("Brent Oil (Derivatives) USD", "BZ=F"))
        assertEquals("FCHI", NewsText.queryName("", "^FCHI"))
        val a = NewsItem("Airbus bondit !", "x", "", 2L, 1.0)
        val b = NewsItem("Airbus bondit", "y", "", 1L, 1.0)
        assertEquals(listOf(a), NewsText.dedupe(listOf(b, a)))
    }

    // ------------------------------------------------------------ Contexte de marché (autres sources)

    @Test
    fun genreDInstrument() {
        assertEquals(AssetKind.CRYPTO, ContextScore.kindOf("BTC-USD"))
        assertEquals(AssetKind.CURRENCY, ContextScore.kindOf("EURUSD=X"))
        assertEquals(AssetKind.INDEX, ContextScore.kindOf("^FCHI"))
        assertEquals(AssetKind.COMMODITY, ContextScore.kindOf("GC=F"))
        assertEquals(AssetKind.STOCK, ContextScore.kindOf("AIR.PA"))
        assertEquals(AssetKind.CRYPTO, ContextScore.kindOf("XYZ", "Crypto"))
    }

    @Test
    fun indiceDeReference() {
        assertEquals("^FCHI", ContextScore.benchmarkFor("AIR.PA", AssetKind.STOCK))
        assertEquals("^GSPC", ContextScore.benchmarkFor("AAPL", AssetKind.STOCK))
        assertEquals("^GDAXI", ContextScore.benchmarkFor("SAP.DE", AssetKind.STOCK))
        assertNull(ContextScore.benchmarkFor("BTC-USD", AssetKind.CRYPTO))
    }

    @Test
    fun peurDesMarches() {
        assertTrue(ContextScore.vixFactor(12.0, 13.0)!!.value > 0)
        assertTrue(ContextScore.vixFactor(30.0, 24.0)!!.value < 0)
        assertNull(ContextScore.vixFactor(Double.NaN, 1.0))
        assertTrue(ContextScore.vixFactor(80.0, 40.0)!!.value in -1.0..1.0)
    }

    @Test
    fun forceRelative() {
        val stock = List(100) { 100.0 + it }
        val bench = List(100) { 100.0 }
        val f = ContextScore.relativeStrength(stock, bench, "CAC 40")!!
        assertTrue(f.value > 0)
        assertTrue(f.detail.contains("CAC 40"))
        assertTrue(ContextScore.relativeStrength(bench, stock, "CAC 40")!!.value < 0)
        assertNull(ContextScore.relativeStrength(stock.take(10), bench, "CAC 40"))
        assertEquals(10.0, ContextScore.change(listOf(100.0, 105.0, 110.0), 2), 1e-9)
    }

    @Test
    fun humeurCryptoEtDollar() {
        assertTrue(ContextScore.fearGreedFactor(10)!!.value > 0)
        assertTrue(ContextScore.fearGreedFactor(90)!!.value < 0)
        assertEquals(0.0, ContextScore.fearGreedFactor(50)!!.value, eps)
        assertNull(ContextScore.fearGreedFactor(150))
        assertTrue(ContextScore.dollarFactor(List(30) { 100.0 + it * 0.2 })!!.value < 0)
        assertTrue(ContextScore.dollarFactor(List(30) { 100.0 - it * 0.2 })!!.value > 0)
    }

    @Test
    fun sourceDeSecoursStooq() {
        assertEquals("^cac", ContextScore.stooqSymbol("^FCHI"))
        assertEquals("aapl.us", ContextScore.stooqSymbol("AAPL"))
        assertEquals("eurusd", ContextScore.stooqSymbol("EURUSD=X"))
        assertEquals("btcusd", ContextScore.stooqSymbol("BTC-USD"))
        assertEquals("gc.f", ContextScore.stooqSymbol("GC=F"))
        assertEquals("sap.de", ContextScore.stooqSymbol("SAP.DE"))
        assertNull(ContextScore.stooqSymbol("AIR.PA"))
        val csv = "Date,Open,High,Low,Close,Volume\n2026-10-13,10,12,9,11,100\n2026-10-12,9,10,8,10,50\nmauvaise ligne\n"
        val c = ContextScore.parseStooqCsv(csv)
        assertEquals(2, c.size)
        assertTrue(c[0].t < c[1].t)
        assertEquals(11.0, c[1].c, eps)
        assertEquals(0, ContextScore.parseStooqCsv("Pas de données").size)
        assertNotNull(c.first())
    }
}
