package fr.jeremy.calepin

import fr.jeremy.calepin.assistant.Assistant
import fr.jeremy.calepin.assistant.AssistantContact
import fr.jeremy.calepin.assistant.AssistantData
import fr.jeremy.calepin.data.Event
import fr.jeremy.calepin.data.Note
import fr.jeremy.calepin.detect.Entity
import fr.jeremy.calepin.detect.EntityDetector
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.util.Calendar

/** Vérifie à chaque compilation que l'assistant comprend toujours les phrases de base. */
class AssistantTest {
    private class FakeData : AssistantData {
        override val notes = mutableListOf(Note(id = 1, title = "Courses", content = "Œufs\nLait"))
        override val events = mutableListOf<Event>()
        private var nextId = 10L
        override fun entities(n: Note): List<Entity> = EntityDetector.detect(n.content)
        override fun createNote(title: String, content: String): Long { notes += Note(id = nextId, title = title, content = content); return nextId++ }
        override fun updateNote(n: Note) { notes.replaceAll { if (it.id == n.id) n else it } }
        override fun createEvent(e: Event): Event { val x = e.copy(id = nextId++); events += x; return x }
        override fun deleteEvent(e: Event) { events.removeIf { it.id == e.id } }
        override val contacts = listOf<AssistantContact>()
    }

    @Test
    fun rendezVousDemain() {
        val d = FakeData()
        Assistant(d).handle("rendez-vous demain à 15h chez le dentiste")
        assertEquals(1, d.events.size)
        val c = Calendar.getInstance().apply { timeInMillis = d.events[0].start }
        assertEquals(15, c.get(Calendar.HOUR_OF_DAY))
        val tomorrow = Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, 1) }
        assertEquals(tomorrow.get(Calendar.DAY_OF_YEAR), c.get(Calendar.DAY_OF_YEAR))
        assertTrue(d.events[0].title.contains("dentiste", ignoreCase = true))
    }

    @Test
    fun ajoutALaListe() {
        val d = FakeData()
        Assistant(d).handle("ajoute du pain à la liste courses")
        assertTrue(d.notes.first { it.id == 1L }.content.contains("pain", ignoreCase = true))
    }

    @Test
    fun noteRapide() {
        val d = FakeData()
        Assistant(d).handle("note : appeler le garage")
        assertTrue(d.notes.any { it.content.contains("garage", ignoreCase = true) && it.id != 1L })
    }

    @Test
    fun suppressionAvecConfirmation() {
        val d = FakeData()
        val a = Assistant(d)
        a.handle("rendez-vous demain à 15h chez le dentiste")
        a.handle("supprime le rendez-vous dentiste")
        assertEquals("rien n'est supprimé avant la confirmation", 1, d.events.size)
        a.handle("oui")
        assertEquals(0, d.events.size)
    }

    @Test
    fun annulationDeLaSuppression() {
        val d = FakeData()
        val a = Assistant(d)
        a.handle("rendez-vous demain à 15h chez le dentiste")
        a.handle("supprime le rendez-vous dentiste")
        a.handle("non")
        assertEquals(1, d.events.size)
    }
}
