package fr.jeremy.calepin

import fr.jeremy.calepin.vehicle.AiFinding
import fr.jeremy.calepin.vehicle.Part
import fr.jeremy.calepin.vehicle.Verdict
import fr.jeremy.calepin.vehicle.VehicleKind
import fr.jeremy.calepin.vehicle.WearRules
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.util.Calendar

/** Assistant du menu Véhicule : usure des pneus, âge, contrôle guidé, lecture de la réponse de l'IA. */
class WearRulesTest {
    @Test
    fun profondeurDesPneus() {
        assertEquals(Verdict.REMPLACER, WearRules.tread(1.2f).first)
        assertEquals(Verdict.REMPLACER, WearRules.tread(1.8f).first)
        assertEquals(Verdict.SURVEILLER, WearRules.tread(2.5f).first)
        assertEquals(Verdict.BON, WearRules.tread(5f).first)
        // Deux-roues : minimum 1 mm
        assertEquals(Verdict.REMPLACER, WearRules.tread(0.8f, twoWheels = true).first)
    }

    @Test
    fun codeDot() {
        assertEquals(23 to 2019, WearRules.dot("DOT 4B9X KL7R 2319", now = 2026))
        // Lecture imparfaite (O au lieu de 0, symboles)
        assertEquals(5 to 2021, WearRules.dot("D0T XJ 9AB3 O521.", now = 2026))
        // Sans le mot DOT : le groupe de 4 chiffres plausible
        assertEquals(44 to 2024, WearRules.dot("Made in France 4424", now = 2026))
        // Semaine impossible ou année future : rien
        assertNull(WearRules.dot("DOT ABC 9930", now = 2026))
        assertNull(WearRules.dot("DOT ABC 1230", now = 2026))
    }

    @Test
    fun ageDuPneu() {
        val now = Calendar.getInstance().apply { set(2026, Calendar.NOVEMBER, 5) }.timeInMillis
        assertEquals(Verdict.REMPLACER, WearRules.age(10, 2014, now).first)
        assertEquals(Verdict.SURVEILLER, WearRules.age(10, 2019, now).first)
        assertEquals(Verdict.BON, WearRules.age(10, 2024, now).first)
    }

    @Test
    fun controleGuide() {
        val (v, f) = WearRules.guided(Part.PNEU, setOf("craquelures", "twi"))
        assertEquals(Verdict.REMPLACER, v)
        assertEquals(2, f.size)
        assertEquals(Verdict.BON, WearRules.guided(Part.FREINS, emptySet()).first)
        assertEquals(Verdict.INCONNU, WearRules.guided(Part.AUTRE, emptySet()).first)
        // Pièces selon le véhicule
        assertTrue(Part.CHAINE in Part.forVehicle(VehicleKind.MOTO))
        assertFalse(Part.PARE_BRISE in Part.forVehicle(VehicleKind.VELO))
    }

    @Test
    fun reponseDeLIa() {
        val r = WearRules.parseAi(
            """**ÉTAT :** surveiller
            CONFIANCE : haute
            PROFONDEUR : environ 2,5 mm
            CONSTATS :
            - Usure plus marquée sur l'épaule intérieure
            - Pas de coupure visible
            CONSEIL : Faire vérifier le parallélisme.""".trimIndent()
        )
        assertEquals(Verdict.SURVEILLER, r.verdict)
        assertTrue(r.confident)
        assertEquals(2.5f, r.treadMm)
        assertEquals(2, r.findings.size)
        assertEquals("Faire vérifier le parallélisme.", r.advice)
        assertEquals(Verdict.INCONNU, WearRules.parseAi("Je ne vois pas bien.").verdict)
    }

    @Test
    fun verdictFinalPrudent() {
        // IA peu sûre qui dit « bon » : ne rassure pas seule
        assertEquals(Verdict.INCONNU, WearRules.combine(AiFinding(Verdict.BON, emptyList(), "", confident = false), emptyList()))
        // Mesure et IA : la pire l'emporte
        assertEquals(Verdict.REMPLACER, WearRules.combine(AiFinding(Verdict.BON, emptyList(), "", true), listOf(Verdict.REMPLACER)))
        // Photo illisible mais mesure correcte : la mesure compte
        assertEquals(Verdict.BON, WearRules.combine(AiFinding(Verdict.INCONNU, emptyList(), "", false), listOf(Verdict.BON)))
    }
}
