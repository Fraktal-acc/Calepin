# Calepin — optimisation (R8) : on retire le code inutilisé des bibliothèques (icônes, Compose, PDF…)
# et on optimise, sans renommer les classes : les réglages enregistrés utilisent les noms des énumérations
# (palettes, présentations, durées de bougies…) et doivent rester lisibles d'une version à l'autre.
-dontobfuscate
# Classes absentes signalées par des bibliothèques (parties pour ordinateur, jamais appelées sur Android) : pas bloquant
-ignorewarnings
-keepattributes *Annotation*,Signature,InnerClasses,EnclosingMethod,SourceFile,LineNumberTable,Exceptions

# Tout le code de Calepin est gardé tel quel (écrans, récepteurs, tâches, widgets déclarés dans le manifeste)
-keep class fr.jeremy.calepin.** { *; }

-dontwarn java.awt.**
-dontwarn javax.security.**
-dontwarn javax.naming.**

# PDF (pdfbox-android) : polices et tables chargées dynamiquement
-keep class com.tom_roush.** { *; }
-dontwarn com.tom_roush.**
-dontwarn com.gemalto.jp2.**
-dontwarn org.bouncycastle.**

# Transcription vocale hors ligne (Vosk + JNA : appels natifs)
-keep class com.sun.jna.** { *; }
-keep class * implements com.sun.jna.** { *; }
-keep class org.vosk.** { *; }
-dontwarn com.sun.jna.**
-dontwarn org.vosk.**

# IA hors ligne (Calepin IA)
-keep class com.google.ai.edge.** { *; }
-dontwarn com.google.ai.edge.**

# Reconnaissance de texte (ML Kit), lecteur audio, réseau
-keep class com.google.mlkit.** { *; }
-dontwarn com.google.mlkit.**
-dontwarn okhttp3.**
-dontwarn okio.**
-dontwarn org.conscrypt.**
-dontwarn org.openjsse.**
-dontwarn com.google.common.**
-dontwarn com.google.errorprone.annotations.**
-dontwarn com.google.j2objc.annotations.**
-dontwarn org.checkerframework.**
-dontwarn javax.annotation.**
-dontwarn kotlin.**
-dontwarn kotlinx.**

# Méthodes natives (encodeur MP3)
-keepclasseswithmembernames class * { native <methods>; }
