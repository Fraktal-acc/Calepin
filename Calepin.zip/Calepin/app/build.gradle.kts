import java.net.URI
import java.net.URLConnection

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

android {
    namespace = "fr.jeremy.calepin"
    compileSdk = 35

    // NDK (encodeur MP3) : on prend celui déjà installé sur la machine de compilation s'il y en a un récent,
    // pour ne pas dépendre d'un téléchargement qui peut échouer (« Failed to install … NDK »)
    val sdkDir = System.getenv("ANDROID_HOME") ?: System.getenv("ANDROID_SDK_ROOT")
    val installedNdk = sdkDir?.let { java.io.File(it, "ndk").listFiles() }.orEmpty()
        .filter { it.isDirectory && java.io.File(it, "source.properties").exists() }
        .map { it.name }
        .filter { (it.substringBefore('.').toIntOrNull() ?: 0) in 26..29 }
        .maxWithOrNull(compareBy<String>({ v -> v.split('.').getOrNull(0)?.toIntOrNull() ?: 0 }, { v -> v.split('.').getOrNull(1)?.toIntOrNull() ?: 0 }, { v -> v.split('.').getOrNull(2)?.toIntOrNull() ?: 0 }))
    if (installedNdk != null) ndkVersion = installedNdk

    defaultConfig {
        applicationId = "fr.jeremy.calepin"
        minSdk = 26
        targetSdk = 35
        // Numéro de compilation GitHub = numéro de version affiché dans l'appli
        val build = (System.getenv("GITHUB_RUN_NUMBER") ?: "1").toInt()
        versionCode = build
        versionName = "$build"
        // Appli en français seulement : les traductions des bibliothèques ne sont pas embarquées
        resourceConfigurations += listOf("fr")

        ndk {
            // Téléphones actuels (64 bits), anciens (32 bits) et émulateurs
            abiFilters += listOf("arm64-v8a", "armeabi-v7a", "x86_64")
        }
    }

    // Clé fixe : chaque version compilée sur GitHub peut s'installer par-dessus la précédente.
    signingConfigs {
        getByName("debug") {
            storeFile = file("debug.keystore")
            storePassword = "android"
            keyAlias = "androiddebugkey"
            keyPassword = "android"
        }
    }

    // Deux applis depuis le même code, installables côte à côte :
    // « standard » = Calepin habituel ; « ia » = Calepin IA, avec un modèle d'IA hors ligne (téléchargé à part).
    flavorDimensions += "edition"
    productFlavors {
        create("standard") {
            dimension = "edition"
            buildConfigField("boolean", "AI", "false")
        }
        create("ia") {
            dimension = "edition"
            applicationIdSuffix = ".ia"
            versionNameSuffix = " IA"
            buildConfigField("boolean", "AI", "true")
        }
    }

    buildTypes {
        // L'APK publié sur GitHub est la version « debug » (même clé, s'installe par-dessus) : elle est
        // maintenant optimisée comme une version finale — code inutilisé retiré, code optimisé, appli
        // non « débogable » (Android l'exécute alors plus vite).
        debug {
            isMinifyEnabled = true
            isShrinkResources = true
            isDebuggable = false
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            signingConfig = signingConfigs.getByName("debug")
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    // Encodeur MP3 natif (Shine) pour les mémos vocaux
    externalNativeBuild {
        cmake {
            path = file("src/main/cpp/CMakeLists.txt")
        }
    }

    buildFeatures {
        buildConfig = true
        compose = true
    }

    // Fichiers de licence en double dans les bibliothèques
    packaging {
        resources {
            excludes += setOf("META-INF/NOTICE.md", "META-INF/LICENSE.md", "META-INF/NOTICE", "META-INF/LICENSE", "META-INF/DEPENDENCIES")
        }
    }

    // Tests automatiques : les classes Android répondent « vide » au lieu de planter
    testOptions {
        unitTests.isReturnDefaultValues = true
    }
}

kotlin {
    compilerOptions {
        jvmTarget.set(org.jetbrains.kotlin.gradle.dsl.JvmTarget.JVM_17)
    }
}

// Compatibilité avec l'ancien workflow GitHub : l'APK habituel reste à app/build/outputs/apk/debug/app-debug.apk,
// et celui de Calepin IA est copié à côté sous le nom app-ia-debug.apk.
val legacyApkPaths = tasks.register<Copy>("legacyApkPaths") {
    dependsOn("assembleStandardDebug", "assembleIaDebug")
    from(layout.buildDirectory.dir("outputs/apk/standard/debug")) {
        include("*.apk")
        rename { "app-debug.apk" }
    }
    from(layout.buildDirectory.dir("outputs/apk/ia/debug")) {
        include("*.apk")
        rename { "app-ia-debug.apk" }
    }
    into(layout.buildDirectory.dir("outputs/apk/debug"))
}
tasks.matching { it.name == "assembleDebug" }.configureEach { finalizedBy(legacyApkPaths) }

// Tests automatiques à chaque compilation (assistant, heures de travail, répétitions) : si l'un échoue,
// la compilation s'arrête et le rapport dit lequel.
tasks.matching { it.name == "assembleStandardDebug" || it.name == "assembleIaDebug" }.configureEach {
    dependsOn("testStandardDebugUnitTest")
}

dependencies {
    val composeBom = platform("androidx.compose:compose-bom:2024.12.01")
    implementation(composeBom)

    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.activity:activity-ktx:1.9.3")
    implementation("androidx.activity:activity-compose:1.9.3")
    implementation("androidx.fragment:fragment-ktx:1.8.5")
    implementation("androidx.biometric:biometric:1.1.0")
    // Transcription vocale hors ligne (Vosk)
    implementation("com.alphacephei:vosk-android:0.3.47@aar")
    implementation("net.java.dev.jna:jna:5.13.0@aar")
    // Lecture des plannings PDF : texte direct, ou reconnaissance de caractères pour les scans et photos
    implementation("com.tom-roush:pdfbox-android:2.0.27.0")
    implementation("com.google.mlkit:text-recognition:16.0.1")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.7")
    implementation("androidx.lifecycle:lifecycle-runtime-compose:2.8.7")

    // Webradios : lecture des flux (MP3, AAC, HLS) en arrière-plan avec notification
    implementation("androidx.media3:media3-exoplayer:1.4.1")
    implementation("androidx.media3:media3-exoplayer-hls:1.4.1")
    implementation("androidx.media3:media3-session:1.4.1")
    implementation("com.google.guava:guava:33.3.1-android")
    // Télécommande réseau des téléviseurs Samsung et LG (WebSocket)
    implementation("com.squareup.okhttp3:okhttp:4.12.0")
    // Moteur d'IA générative hors ligne : uniquement dans Calepin IA
    "iaImplementation"("com.google.ai.edge.litertlm:litertlm-android:0.17.1")

    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended")
    implementation("androidx.compose.ui:ui-tooling-preview")
    debugImplementation("androidx.compose.ui:ui-tooling")

    testImplementation("junit:junit:4.13.2")
}


// ---------------------------------------------------------------------------------------------
// Polices libres (Google Fonts, licences OFL / Apache) téléchargées pendant la compilation sur GitHub.
// Si une police ne se télécharge pas, l'appli utilise simplement la police classique à la place.
val fontAssetsDir = layout.buildDirectory.dir("generated/fontAssets")
val downloadFonts = tasks.register("downloadFonts") {
    val outDir = fontAssetsDir
    outputs.dir(outDir)
    doLast {
        val dir = outDir.get().asFile.resolve("fonts").apply { mkdirs() }
        val base = "https://raw.githubusercontent.com/google/fonts/main/"
        val fonts = mapOf(
            "orbitron.ttf" to listOf("ofl/orbitron/Orbitron%5Bwght%5D.ttf"),
            "audiowide.ttf" to listOf("ofl/audiowide/Audiowide-Regular.ttf"),
            "cinzel.ttf" to listOf("ofl/cinzel/Cinzel%5Bwght%5D.ttf"),
            "unifraktur.ttf" to listOf("ofl/unifrakturmaguntia/UnifrakturMaguntia-Book.ttf", "ofl/unifrakturmaguntia/UnifrakturMaguntia-Regular.ttf"),
            "creepster.ttf" to listOf("ofl/creepster/Creepster-Regular.ttf", "apache/creepster/Creepster-Regular.ttf"),
            "nosifer.ttf" to listOf("ofl/nosifer/Nosifer-Regular.ttf"),
            "bebasneue.ttf" to listOf("ofl/bebasneue/BebasNeue-Regular.ttf"),
            "bangers.ttf" to listOf("ofl/bangers/Bangers-Regular.ttf"),
            "shojumaru.ttf" to listOf("ofl/shojumaru/Shojumaru-Regular.ttf"),
            "permanentmarker.ttf" to listOf("apache/permanentmarker/PermanentMarker-Regular.ttf", "ofl/permanentmarker/PermanentMarker-Regular.ttf"),
            "pressstart2p.ttf" to listOf("ofl/pressstart2p/PressStart2P-Regular.ttf"),
            "pacifico.ttf" to listOf("ofl/pacifico/Pacifico-Regular.ttf"),
            "specialelite.ttf" to listOf("apache/specialelite/SpecialElite-Regular.ttf", "ofl/specialelite/SpecialElite-Regular.ttf"),
            "caveat.ttf" to listOf("ofl/caveat/Caveat%5Bwght%5D.ttf"),
        )
        for ((name, paths) in fonts) {
            val f = dir.resolve(name)
            if (f.exists() && f.length() > 1000) continue
            for (p in paths) {
                try {
                    val c: URLConnection = URI(base + p).toURL().openConnection()
                    c.connectTimeout = 15000
                    c.readTimeout = 30000
                    c.getInputStream().use { input -> f.outputStream().use { input.copyTo(it) } }
                    if (f.length() > 1000) break
                } catch (e: Exception) {
                    f.delete()
                }
            }
            if (!f.exists()) logger.warn("Police non téléchargée : $name")
        }
    }
}
android.sourceSets.getByName("main").assets.srcDir(fontAssetsDir)
tasks.named("preBuild") { dependsOn(downloadFonts) }
