plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

android {
    namespace = "fr.jeremy.calepin"
    compileSdk = 35

    defaultConfig {
        applicationId = "fr.jeremy.calepin"
        minSdk = 26
        targetSdk = 35
        // Numéro de compilation GitHub = numéro de version affiché dans l'appli
        val build = (System.getenv("GITHUB_RUN_NUMBER") ?: "1").toInt()
        versionCode = build
        versionName = "$build"

        ndk {
            // Téléphones actuels (64 bits), anciens (32 bits) et émulateurs
            abiFilters += listOf("arm64-v8a", "armeabi-v7a", "x86_64")
        }
    }

    // Clé fixe : chaque version compilée sur GitHub peut s'installer par-dessus la précédente.
    signingConfigs {
        getByName("debug") {
            storeFile = file("debug.keystore")
            storePassword = "android"
            keyAlias = "androiddebugkey"
            keyPassword = "android"
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    // Encodeur MP3 natif (Shine) pour les mémos vocaux
    externalNativeBuild {
        cmake {
            path = file("src/main/cpp/CMakeLists.txt")
        }
    }

    buildFeatures {
        buildConfig = true
        compose = true
    }
}

dependencies {
    val composeBom = platform("androidx.compose:compose-bom:2024.12.01")
    implementation(composeBom)

    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.activity:activity-ktx:1.9.3")
    implementation("androidx.activity:activity-compose:1.9.3")
    implementation("androidx.fragment:fragment-ktx:1.8.5")
    implementation("androidx.biometric:biometric:1.1.0")
    // Transcription vocale hors ligne (Vosk)
    implementation("com.alphacephei:vosk-android:0.3.47@aar")
    implementation("net.java.dev.jna:jna:5.13.0@aar")
    // Lecture des plannings PDF : texte direct, ou reconnaissance de caractères pour les scans et photos
    implementation("com.tom-roush:pdfbox-android:2.0.27.0")
    implementation("com.google.mlkit:text-recognition:16.0.1")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.7")
    implementation("androidx.lifecycle:lifecycle-runtime-compose:2.8.7")

    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended")
    implementation("androidx.compose.ui:ui-tooling-preview")
    debugImplementation("androidx.compose.ui:ui-tooling")
}

// Sur GitHub, les erreurs de compilation sont recopiées en « annotations » :
// elles s'affichent sur la page du build, même sans être connecté.
if (System.getenv("GITHUB_ACTIONS") == "true") {
    val reported = java.util.Collections.synchronizedSet(mutableSetOf<String>())
    fun annotate(message: String) {
        val m = message.trim().take(900)
        if (m.isNotEmpty() && reported.size < 40 && reported.add(m)) {
            println("::error::" + m.replace("%", "%25").replace("\r", "").replace("\n", "%0A"))
        }
    }
    val catcher = object : org.gradle.api.logging.StandardOutputListener {
        override fun onOutput(output: CharSequence) {
            output.toString().lineSequence()
                .filter { it.startsWith("e: ") || it.startsWith("ERROR: ") || it.contains(": error: ") }
                .forEach { line -> annotate(line.removePrefix("e: ").substringAfter("/fr/jeremy/calepin/")) }
        }
    }
    tasks.configureEach {
        logging.addStandardOutputListener(catcher)
        logging.addStandardErrorListener(catcher)
    }
    gradle.taskGraph.afterTask {
        var t: Throwable? = state.failure
        val parts = mutableListOf<String>()
        while (t != null && parts.size < 6) {
            t.message?.let { if (it.isNotBlank()) parts += it.lines().take(8).joinToString("\n") }
            t = t.cause
        }
        if (parts.isNotEmpty()) annotate("$path : " + parts.joinToString("\n"))
    }
}
