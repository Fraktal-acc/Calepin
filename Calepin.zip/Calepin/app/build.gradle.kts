plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

android {
    namespace = "fr.jeremy.calepin"
    compileSdk = 35

    defaultConfig {
        applicationId = "fr.jeremy.calepin"
        minSdk = 26
        targetSdk = 35
        // Numéro de compilation GitHub = numéro de version affiché dans l'appli
        val build = (System.getenv("GITHUB_RUN_NUMBER") ?: "1").toInt()
        versionCode = build
        versionName = "$build"

        ndk {
            // Téléphones actuels (64 bits), anciens (32 bits) et émulateurs
            abiFilters += listOf("arm64-v8a", "armeabi-v7a", "x86_64")
        }
    }

    // Clé fixe : chaque version compilée sur GitHub peut s'installer par-dessus la précédente.
    signingConfigs {
        getByName("debug") {
            storeFile = file("debug.keystore")
            storePassword = "android"
            keyAlias = "androiddebugkey"
            keyPassword = "android"
        }
    }

    // Deux applis depuis le même code, installables côte à côte :
    // « standard » = Calepin habituel ; « ia » = Calepin IA, avec un modèle d'IA hors ligne (téléchargé à part).
    flavorDimensions += "edition"
    productFlavors {
        create("standard") {
            dimension = "edition"
            buildConfigField("boolean", "AI", "false")
        }
        create("ia") {
            dimension = "edition"
            applicationIdSuffix = ".ia"
            versionNameSuffix = " IA"
            buildConfigField("boolean", "AI", "true")
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    // Encodeur MP3 natif (Shine) pour les mémos vocaux
    externalNativeBuild {
        cmake {
            path = file("src/main/cpp/CMakeLists.txt")
        }
    }

    buildFeatures {
        buildConfig = true
        compose = true
    }
}

kotlin {
    compilerOptions {
        jvmTarget.set(org.jetbrains.kotlin.gradle.dsl.JvmTarget.JVM_17)
    }
}

// Compatibilité avec l'ancien workflow GitHub : l'APK habituel reste à app/build/outputs/apk/debug/app-debug.apk,
// et celui de Calepin IA est copié à côté sous le nom app-ia-debug.apk.
val legacyApkPaths = tasks.register<Copy>("legacyApkPaths") {
    dependsOn("assembleStandardDebug", "assembleIaDebug")
    from(layout.buildDirectory.dir("outputs/apk/standard/debug")) {
        include("*.apk")
        rename { "app-debug.apk" }
    }
    from(layout.buildDirectory.dir("outputs/apk/ia/debug")) {
        include("*.apk")
        rename { "app-ia-debug.apk" }
    }
    into(layout.buildDirectory.dir("outputs/apk/debug"))
}
tasks.matching { it.name == "assembleDebug" }.configureEach { finalizedBy(legacyApkPaths) }

dependencies {
    val composeBom = platform("androidx.compose:compose-bom:2024.12.01")
    implementation(composeBom)

    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.activity:activity-ktx:1.9.3")
    implementation("androidx.activity:activity-compose:1.9.3")
    implementation("androidx.fragment:fragment-ktx:1.8.5")
    implementation("androidx.biometric:biometric:1.1.0")
    // Transcription vocale hors ligne (Vosk)
    implementation("com.alphacephei:vosk-android:0.3.47@aar")
    implementation("net.java.dev.jna:jna:5.13.0@aar")
    // Lecture des plannings PDF : texte direct, ou reconnaissance de caractères pour les scans et photos
    implementation("com.tom-roush:pdfbox-android:2.0.27.0")
    implementation("com.google.mlkit:text-recognition:16.0.1")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.7")
    implementation("androidx.lifecycle:lifecycle-runtime-compose:2.8.7")

    // Moteur d'IA générative hors ligne : uniquement dans Calepin IA
    "iaImplementation"("com.google.ai.edge.litertlm:litertlm-android:0.17.1")

    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended")
    implementation("androidx.compose.ui:ui-tooling-preview")
    debugImplementation("androidx.compose.ui:ui-tooling")
}

