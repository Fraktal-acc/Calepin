# Politique de confidentialité de Calepin

*Dernière mise à jour : octobre 2026*

## En résumé
Calepin fonctionne sans compte et sans serveur. Tes notes, ton agenda, tes photos, tes mémos vocaux, tes clients et tes réglages
sont enregistrés uniquement sur ton téléphone. Aucune donnée n'est vendue, partagée, ni envoyée à l'éditeur.
Il n'y a ni publicité ni mesure d'audience.

## Autorisations et à quoi elles servent
- **Micro** : dictée, mémos vocaux et commandes à la voix, seulement quand tu appuies sur le bouton.
- **Appareil photo** : photos des notes, scanner de texte, photos avant/après — l'image reste sur le téléphone.
- **Contacts (lecture)** : afficher tes contacts et les retrouver dans tes notes ; rien n'est copié ailleurs.
- **Appels** : uniquement quand tu demandes à l'assistant d'appeler quelqu'un.
- **Notifications, alarmes exactes, démarrage** : pour que tes rappels sonnent à l'heure, même après un redémarrage.
- **Empreinte / visage** : verrouillage facultatif de l'appli, géré par Android.
- **Internet** : téléchargements que tu demandes (module de transcription vocale, modèles d'IA de Calepin IA) et, dans Calepin IA,
  commande des appareils de ton réseau Wi-Fi local (télé, décodeur, lumières).

## Intelligence artificielle (Calepin IA)
Les modèles d'IA sont téléchargés depuis Hugging Face uniquement si tu le choisis, puis fonctionnent entièrement sur le téléphone,
sans Internet. Tes questions et tes notes ne quittent pas l'appareil.

## Appareils de la maison (Calepin IA)
Les commandes de la télé, du décodeur et des objets connectés passent directement sur ton réseau Wi-Fi, sans serveur extérieur.

## Partages et sauvegardes
Quand tu partages une note, un export ou une sauvegarde, c'est toi qui choisis l'application de destination (mail, Drive, WhatsApp…),
dont la politique de confidentialité s'applique alors. Une sauvegarde protégée par mot de passe est chiffrée (AES-256).

## Effacer tes données
Désinstaller Calepin efface toutes ses données du téléphone. Tu peux aussi supprimer chaque note, photo ou mémo,
ou effacer les données de l'appli dans les réglages d'Android.

## Contact
contact@lintendantadomicile.fr
