pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
    }
}
rootProject.name = "Calepin"
include(":app")

// Sur GitHub, les erreurs sont recopiées en « annotations » :
// elles s'affichent sur la page du build, même sans être connecté.
if (System.getenv("GITHUB_ACTIONS") == "true") {
    val reported = java.util.Collections.synchronizedSet(mutableSetOf<String>())
    fun annotate(message: String) {
        val m = message.trim().take(1500)
        if (m.isNotEmpty() && reported.size < 40 && reported.add(m)) {
            println("::error::" + m.replace("%", "%25").replace("\r", "").replace("\n", "%0A"))
        }
    }
    val catcher = object : org.gradle.api.logging.StandardOutputListener {
        override fun onOutput(output: CharSequence) {
            output.toString().lineSequence()
                .filter { it.startsWith("e: ") || it.startsWith("ERROR: ") || it.contains(": error: ") }
                .forEach { line -> annotate(line.removePrefix("e: ").substringAfter("/fr/jeremy/calepin/")) }
        }
    }
    gradle.beforeProject {
        tasks.configureEach {
            logging.addStandardOutputListener(catcher)
            logging.addStandardErrorListener(catcher)
        }
    }
    gradle.buildFinished {
        val parts = mutableListOf<String>()
        fun walk(t: Throwable?, depth: Int) {
            if (t == null || depth > 8 || parts.size > 10) return
            t.message?.takeIf { it.isNotBlank() }?.let { parts += it.lines().take(15).joinToString("\n") }
            if (t is org.gradle.internal.exceptions.MultiCauseException) t.causes.forEach { walk(it, depth + 1) }
            else walk(t.cause, depth + 1)
        }
        walk(failure, 0)
        if (parts.isNotEmpty()) annotate(parts.distinct().joinToString("\n"))
    }
}
