package fr.jeremy.calepin

import android.app.Application
import android.content.Context
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import fr.jeremy.calepin.data.Note
import fr.jeremy.calepin.data.NoteDb
import fr.jeremy.calepin.detect.Entity
import fr.jeremy.calepin.detect.EntityDetector
import fr.jeremy.calepin.search.SearchEngine
import fr.jeremy.calepin.search.SearchOptions
import fr.jeremy.calepin.search.SearchResult
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.FlowPreview
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.debounce
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.concurrent.ConcurrentHashMap

@OptIn(FlowPreview::class)
class NotesViewModel(app: Application) : AndroidViewModel(app) {

    private val db = NoteDb(app)
    private val notes = MutableStateFlow<List<Note>>(emptyList())

    val query = MutableStateFlow("")
    val options = MutableStateFlow(SearchOptions())

    private val entityCache = ConcurrentHashMap<Long, Pair<String, List<Entity>>>()

    fun entitiesOf(n: Note): List<Entity> {
        val cached = entityCache[n.id]
        if (cached != null && cached.first == n.content) return cached.second
        return EntityDetector.detect(n.content).also { entityCache[n.id] = n.content to it }
    }

    val results: StateFlow<List<SearchResult>> =
        combine(notes, query.debounce(120), options) { n, q, o ->
            SearchEngine.search(n, q, o, ::entitiesOf)
        }
            .flowOn(Dispatchers.Default)
            .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    val noteCount: StateFlow<Int> =
        notes.map { it.size }.stateIn(viewModelScope, SharingStarted.Eagerly, 0)

    val allTags: StateFlow<List<String>> =
        notes.map { list -> list.flatMap { it.tags }.distinctBy { it.lowercase() }.sortedBy { it.lowercase() } }
            .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    init {
        viewModelScope.launch {
            withContext(Dispatchers.IO) { seedIfFirstLaunch() }
            refresh()
        }
    }

    private suspend fun refresh() {
        notes.value = withContext(Dispatchers.IO) { db.all() }
    }

    fun find(id: Long): Note? = notes.value.firstOrNull { it.id == id }

    fun setQuery(q: String) { query.value = q }
    fun updateOptions(f: SearchOptions.() -> SearchOptions) { options.value = options.value.f() }

    /** Écriture immédiate (petite requête SQLite) pour obtenir l'identifiant sans risque de doublon. */
    fun saveNow(n: Note): Long {
        val id = db.upsert(n)
        viewModelScope.launch { refresh() }
        return id
    }

    fun delete(id: Long) {
        viewModelScope.launch {
            withContext(Dispatchers.IO) { db.delete(id) }
            entityCache.remove(id)
            refresh()
        }
    }

    fun togglePin(n: Note) {
        viewModelScope.launch {
            withContext(Dispatchers.IO) { db.upsert(n.copy(pinned = !n.pinned)) }
            refresh()
        }
    }

    private fun seedIfFirstLaunch() {
        val prefs = getApplication<Application>().getSharedPreferences("calepin", Context.MODE_PRIVATE)
        if (prefs.getBoolean("seeded", false)) return
        val now = System.currentTimeMillis()
        listOf(
            Note(
                title = "Visite villa Cap-Martin",
                content = "Visite de la villa avec M. Rossi le 14 octobre à 10h30.\n" +
                    "Adresse : 12 avenue Winston Churchill, 06190 Roquebrune-Cap-Martin\n" +
                    "Tél : 06 12 34 56 78\nMail : rossi.exemple@gmail.com\n" +
                    "Prévoir les clés et le relevé des compteurs.",
                tag = "Exemple, Clients", pinned = true, createdAt = now - 3_600_000, updatedAt = now - 3_600_000,
            ),
            Note(
                title = "Fournisseurs Monaco",
                content = "Pressing du port : +377 93 50 12 34\nPlombier (urgence) : 07 98 76 54 32\n" +
                    "Électricien à rappeler mardi à 9h.\nSite du pressing : www.exemple-pressing.mc",
                tag = "Exemple, Fournisseurs", createdAt = now - 7_200_000, updatedAt = now - 7_200_000,
            ),
            Note(
                title = "Courses marché",
                content = "Marché demain 18h, place aux Herbes, 06500 Menton.\nŒufs, pâtes fraîches, café, citrons.",
                tag = "Exemple, Perso", createdAt = now - 10_800_000, updatedAt = now - 10_800_000,
            ),
        ).forEach { db.upsert(it) }
        prefs.edit().putBoolean("seeded", true).apply()
    }
}
